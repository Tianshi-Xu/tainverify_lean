import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0013
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_96_0 (z : Store) : (s_96 z) 476 = (v_95_0 z) := w_95_0 z
 #a r_96_0
 def v_96_0 (z : Store) : Tensor := fw_gelu (v_95_0 z)
 def s_97 (z : Store) : Store := storeSet (s_96 z) [(478, fw_gelu ((s_96 z) 476))]
 theorem t_96 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_283) (pmPeers pmNode_283) (s_96 z) pmNode_283 none = some (s_97 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_96
 theorem k_96 (z : Store) (tid : Tid) (h : tid ∉ [478]) : (s_97 z) tid = (s_96 z) tid := by
   unfold s_97
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_96
 theorem w_96_0 (z : Store) : (s_97 z) 478 = v_96_0 z := by
   unfold s_97
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_96_0, r_96_0 z] <;> rfl
 #a w_96_0
 theorem h_96_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_96_0 z).shape = [1, 8, 256] := by
   unfold v_96_0
   exact h_95_0 z z_
 #a h_96_0
 attribute [local irreducible] v_96_0
 attribute [local irreducible] s_97
 theorem n_92_96 (z : Store) (tid : Tid) (h : tid ∉ ([177, 472, 473, 476] : List Tid)) : (s_96 z) tid = (s_92 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_92 z) (k_93 z)) (pF _ _ _ _ _ (k_94 z) (k_95 z)) tid h
 #a n_92_96
 theorem n_88_96 (z : Store) (tid : Tid) (h : tid ∉ ([169, 170, 173, 175, 177, 472, 473, 476] : List Tid)) : (s_96 z) tid = (s_88 z) tid := by
   exact pF _ _ _ _ _ (n_88_92 z) (n_92_96 z) tid h
 #a n_88_96
 theorem n_80_96 (z : Store) (tid : Tid) (h : tid ∉ ([462, 463, 164, 165, 289, 179, 467, 468, 592, 482, 169, 170, 173, 175, 177, 472, 473, 476] : List Tid)) : (s_96 z) tid = (s_80 z) tid := by
   exact pF _ _ _ _ _ (n_80_88 z) (n_88_96 z) tid h
 #a n_80_96
 theorem n_64_96 (z : Store) (tid : Tid) (h : tid ∉ ([446, 146, 147, 151, 153, 381, 449, 450, 454, 456, 155, 156, 458, 459, 159, 160, 462, 463, 164, 165, 289, 179, 467, 468, 592, 482, 169, 170, 173, 175, 177, 472, 473, 476] : List Tid)) : (s_96 z) tid = (s_64 z) tid := by
   exact pF _ _ _ _ _ (n_64_80 z) (n_80_96 z) tid h
 #a n_64_96
 theorem r_97_0 (z : Store) : (s_97 z) 478 = (v_96_0 z) := w_96_0 z
 #a r_97_0
 theorem r_97_1 (z : Store) : (s_97 z) 311 = (z 311) := pR (k_96 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_23 z)))
 #a r_97_1
 def v_97_0 (z : Store) : Tensor := fw_linear (v_96_0 z) (z 311)
 def s_98 (z : Store) : Store := storeSet (s_97 z) [(480, fw_linear ((s_97 z) 478) ((s_97 z) 311))]
 theorem t_97 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_284) (pmPeers pmNode_284) (s_97 z) pmNode_284 none = some (s_98 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_97
 theorem k_97 (z : Store) (tid : Tid) (h : tid ∉ [480]) : (s_98 z) tid = (s_97 z) tid := by
   unfold s_98
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_97
 theorem w_97_0 (z : Store) : (s_98 z) 480 = v_97_0 z := by
   unfold s_98
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_97_0, r_97_0 z, r_97_1 z] <;> rfl
 #a w_97_0
 theorem h_97_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_97_0 z).shape = [1, 8, 64] := by
   unfold v_97_0
   exact fw_linear_3d_shape 1 8 256 64 (v_96_0 z) (z 311) (h_96_0 z z_) (i_23 z z_)
 #a h_97_0
 attribute [local irreducible] v_97_0
 attribute [local irreducible] s_98
 theorem r_98_0 (z : Store) : (s_98 z) 177 = (v_92_0 z) := pR (k_97 z) (pR (k_96 z) (pR (k_95 z) (pR (k_94 z) (pR (k_93 z) (w_92_0 z)))))
 #a r_98_0
 theorem r_98_1 (z : Store) : (s_98 z) 480 = (v_97_0 z) := w_97_0 z
 #a r_98_1
 def v_98_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_92_0 z), (v_97_0 z)]
 theorem g_98 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_49) (s_98 z) pmNode_49 1 2 180 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_49, r_98_0 z, r_98_1 z, h_92_0 z z_, h_97_0 z z_]
 #a g_98
 def s_99 (z : Store) : Store := pL [0, 1] (s_98 z) pmNode_49 1 2
 theorem t_98 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_49) (pmPeers pmNode_49) (s_98 z) pmNode_49 none = some (s_99 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_49) (s_98 z) pmNode_49).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 180 (by decide) (g_98 z z_)]
   rfl
 #a t_98
 theorem k_98 (z : Store) (tid : Tid) (h : tid ∉ [180]) : (s_99 z) tid = (s_98 z) tid := by
   unfold s_99
   dsimp only [pL, pmNode_49, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_98
 theorem w_98_0 (z : Store) : (s_99 z) 180 = v_98_0 z := by
   unfold s_99
   dsimp only [pL, pmNode_49, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_98_0, r_98_0 z, r_98_1 z] <;> rfl
 #a w_98_0
 theorem h_98_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_98_0 z).shape = [1, 16, 32] := by
   unfold v_98_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_92_0 z z_]
 #a h_98_0
 attribute [local irreducible] v_98_0
 attribute [local irreducible] s_99
 theorem r_99_0 (z : Store) : (s_99 z) 179 = (v_84_1 z) := pR (k_98 z) (pR (k_97 z) (pR (k_96 z) (pR (n_88_96 z) (pR (k_87 z) (pR (k_86 z) (pR (k_85 z) (w_84_1 z)))))))
 #a r_99_0
 theorem r_99_1 (z : Store) : (s_99 z) 180 = (v_98_0 z) := w_98_0 z
 #a r_99_1
 def v_99_0 (z : Store) : Tensor := elemwiseAdd (v_84_1 z) (v_98_0 z)
 def s_100 (z : Store) : Store := storeSet (s_99 z) [(181, elemwiseAdd ((s_99 z) 179) ((s_99 z) 180))]
 theorem t_99 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_50) (pmPeers pmNode_50) (s_99 z) pmNode_50 none = some (s_100 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_99
 theorem k_99 (z : Store) (tid : Tid) (h : tid ∉ [181]) : (s_100 z) tid = (s_99 z) tid := by
   unfold s_100
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_99
 theorem w_99_0 (z : Store) : (s_100 z) 181 = v_99_0 z := by
   unfold s_100
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_99_0, r_99_0 z, r_99_1 z] <;> rfl
 #a w_99_0
 theorem h_99_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_99_0 z).shape = [1, 16, 32] := by
   unfold v_99_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_84_1 z z_, h_98_0 z z_]
 #a h_99_0
 attribute [local irreducible] v_99_0
 attribute [local irreducible] s_100
 theorem r_100_0 (z : Store) : (s_100 z) 181 = (v_99_0 z) := w_99_0 z
 #a r_100_0
 def v_100_0 (z : Store) : Tensor := (v_99_0 z)
 def v_100_1 (z : Store) : Tensor := (v_99_0 z)
 def s_101 (z : Store) : Store := storeSet (s_100 z) [(291, ((s_100 z) 181)), (252, ((s_100 z) 181))]
 theorem t_100 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_51) (pmPeers pmNode_51) (s_100 z) pmNode_51 none = some (s_101 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_100
 theorem k_100 (z : Store) (tid : Tid) (h : tid ∉ [291, 252]) : (s_101 z) tid = (s_100 z) tid := by
   unfold s_101
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_100
 theorem w_100_0 (z : Store) : (s_101 z) 291 = v_100_0 z := by
   unfold s_101
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_100_0, r_100_0 z] <;> rfl
 #a w_100_0
 theorem h_100_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_100_0 z).shape = [1, 16, 32] := by
   unfold v_100_0
   exact h_99_0 z z_
 #a h_100_0
 attribute [local irreducible] v_100_0
 theorem w_100_1 (z : Store) : (s_101 z) 252 = v_100_1 z := by
   unfold s_101
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_100_1, r_100_0 z] <;> rfl
 #a w_100_1
 theorem h_100_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_100_1 z).shape = [1, 16, 32] := by
   unfold v_100_1
   exact h_99_0 z z_
 #a h_100_1
 attribute [local irreducible] v_100_1
 attribute [local irreducible] s_101
 theorem r_101_0 (z : Store) : (s_101 z) 177 = (v_92_0 z) := pR (k_100 z) (pR (k_99 z) (pR (k_98 z) (r_98_0 z)))
 #a r_101_0
 theorem r_101_1 (z : Store) : (s_101 z) 480 = (v_97_0 z) := pR (k_100 z) (pR (k_99 z) (pR (k_98 z) (r_98_1 z)))
 #a r_101_1
 def v_101_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_92_0 z), (v_97_0 z)]
 theorem g_101 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_285) (s_101 z) pmNode_285 1 2 483 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_285, r_101_0 z, r_101_1 z, h_92_0 z z_, h_97_0 z z_]
 #a g_101
 def s_102 (z : Store) : Store := pL [0, 1] (s_101 z) pmNode_285 1 2
 theorem t_101 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_285) (pmPeers pmNode_285) (s_101 z) pmNode_285 none = some (s_102 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_285) (s_101 z) pmNode_285).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 483 (by decide) (g_101 z z_)]
   rfl
 #a t_101
 theorem k_101 (z : Store) (tid : Tid) (h : tid ∉ [483]) : (s_102 z) tid = (s_101 z) tid := by
   unfold s_102
   dsimp only [pL, pmNode_285, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_101
 theorem w_101_0 (z : Store) : (s_102 z) 483 = v_101_0 z := by
   unfold s_102
   dsimp only [pL, pmNode_285, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_101_0, r_101_0 z, r_101_1 z] <;> rfl
 #a w_101_0
 theorem h_101_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_101_0 z).shape = [1, 16, 32] := by
   unfold v_101_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_92_0 z z_]
 #a h_101_0
 attribute [local irreducible] v_101_0
 attribute [local irreducible] s_102
 theorem n_96_100 (z : Store) (tid : Tid) (h : tid ∉ ([478, 480, 180, 181] : List Tid)) : (s_100 z) tid = (s_96 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_96 z) (k_97 z)) (pF _ _ _ _ _ (k_98 z) (k_99 z)) tid h
 #a n_96_100
 theorem r_102_0 (z : Store) : (s_102 z) 482 = (v_87_1 z) := pR (k_101 z) (pR (k_100 z) (pR (n_96_100 z) (pR (n_88_96 z) (w_87_1 z))))
 #a r_102_0
 theorem r_102_1 (z : Store) : (s_102 z) 483 = (v_101_0 z) := w_101_0 z
 #a r_102_1
 def v_102_0 (z : Store) : Tensor := elemwiseAdd (v_87_1 z) (v_101_0 z)
 def s_103 (z : Store) : Store := storeSet (s_102 z) [(484, elemwiseAdd ((s_102 z) 482) ((s_102 z) 483))]
 theorem t_102 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_286) (pmPeers pmNode_286) (s_102 z) pmNode_286 none = some (s_103 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_102
 theorem k_102 (z : Store) (tid : Tid) (h : tid ∉ [484]) : (s_103 z) tid = (s_102 z) tid := by
   unfold s_103
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_102
 theorem w_102_0 (z : Store) : (s_103 z) 484 = v_102_0 z := by
   unfold s_103
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_102_0, r_102_0 z, r_102_1 z] <;> rfl
 #a w_102_0
 theorem h_102_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_102_0 z).shape = [1, 16, 32] := by
   unfold v_102_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_87_1 z z_, h_101_0 z z_]
 #a h_102_0
 attribute [local irreducible] v_102_0
 attribute [local irreducible] s_103
 theorem r_103_0 (z : Store) : (s_103 z) 484 = (v_102_0 z) := w_102_0 z
 #a r_103_0
 def v_103_0 (z : Store) : Tensor := (v_102_0 z)
 def v_103_1 (z : Store) : Tensor := (v_102_0 z)
 def s_104 (z : Store) : Store := storeSet (s_103 z) [(594, ((s_103 z) 484)), (555, ((s_103 z) 484))]
 theorem t_103 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_287) (pmPeers pmNode_287) (s_103 z) pmNode_287 none = some (s_104 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_103
 theorem k_103 (z : Store) (tid : Tid) (h : tid ∉ [594, 555]) : (s_104 z) tid = (s_103 z) tid := by
   unfold s_104
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_103
 theorem w_103_0 (z : Store) : (s_104 z) 594 = v_103_0 z := by
   unfold s_104
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_103_0, r_103_0 z] <;> rfl
 #a w_103_0
 theorem h_103_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_103_0 z).shape = [1, 16, 32] := by
   unfold v_103_0
   exact h_102_0 z z_
 #a h_103_0
 attribute [local irreducible] v_103_0
 theorem w_103_1 (z : Store) : (s_104 z) 555 = v_103_1 z := by
   unfold s_104
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_103_1, r_103_0 z] <;> rfl
 #a w_103_1
 theorem h_103_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_103_1 z).shape = [1, 16, 32] := by
   unfold v_103_1
   exact h_102_0 z z_
 #a h_103_1
 attribute [local irreducible] v_103_1
 attribute [local irreducible] s_104
 record_prefix_opacity v_96_0 s_97 v_97_0 s_98 v_98_0 s_99 v_99_0 s_100 v_100_0 v_100_1 s_101 v_101_0 s_102 v_102_0 s_103 v_103_0 v_103_1 s_104

 end
 end TrainVerify.Denote.RuntimeWorld
