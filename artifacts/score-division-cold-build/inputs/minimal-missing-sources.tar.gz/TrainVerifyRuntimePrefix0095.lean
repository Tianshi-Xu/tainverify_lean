import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0094
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_750_0 (z : Store) : (s_750 z) 782 = (v_749_0 z) := w_749_0 z
 #a r_750_0
 theorem r_750_1 (z : Store) : (s_750 z) 779 = (v_512_0 z) := pR (k_749 z) (pR (k_748 z) (pR (n_744_748 z) (pR (n_736_744 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (n_516_520 z) (pR (k_515 z) (pR (k_514 z) (pR (k_513 z) (r_513_0 z))))))))))))))
 #a r_750_1
 def v_750_0 (z : Store) : Tensor := bw_gelu (v_749_0 z) (v_512_0 z)
 def s_751 (z : Store) : Store := storeSet (s_750 z) [(780, bw_gelu ((s_750 z) 782) ((s_750 z) 779))]
 theorem t_750 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_637) (pmPeers pmNode_637) (s_750 z) pmNode_637 none = some (s_751 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_750
 theorem k_750 (z : Store) (tid : Tid) (h : tid ∉ [780]) : (s_751 z) tid = (s_750 z) tid := by
   unfold s_751
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_750
 theorem w_750_0 (z : Store) : (s_751 z) 780 = v_750_0 z := by
   unfold s_751
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_750_0, r_750_0 z, r_750_1 z] <;> rfl
 #a w_750_0
 theorem h_750_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_750_0 z).shape = [1, 8, 256] := by
   unfold v_750_0
   exact h_512_0 z z_
 #a h_750_0
 attribute [local irreducible] v_750_0
 attribute [local irreducible] s_751
 theorem n_512_640 (z : Store) (tid : Tid) (h : tid ∉ ([779, 781, 783, 1078, 1079, 1082, 1084, 1086, 786, 787, 897, 858, 1089, 1090, 1200, 1161, 791, 792, 899, 901, 903, 1094, 1095, 1202, 1204, 1206, 694, 795, 798, 799, 801, 802, 997, 1098, 804, 805, 1101, 1102, 1104, 1105, 1107, 1108, 808, 809, 812, 813, 1111, 1112, 1115, 1116, 816, 817, 820, 821, 1119, 1120, 1123, 1124, 824, 825, 828, 1127, 1128, 1131, 830, 831, 1133, 1134, 834, 835, 1137, 1138, 838, 839, 685, 842, 1141, 1142, 988, 1145, 845, 846, 1148, 1149, 849, 850, 1152, 1153, 853, 854, 857, 1156, 1157, 1160, 859, 860, 905, 907, 1162, 1163, 1208, 1210, 864, 865, 1167, 1168, 868, 869, 1171, 1172, 871, 872, 875, 877, 878, 881, 1174, 1175, 1178, 1180, 1181, 1184, 686, 883, 989, 1186, 886, 887, 1189, 1190, 683, 888, 986, 1191, 884, 885, 679] : List Tid)) : (s_640 z) tid = (s_512 z) tid := by
   exact pF _ _ _ _ _ (n_512_576 z) (n_576_640 z) tid h
 #a n_512_640
 theorem r_751_0 (z : Store) : (s_751 z) 780 = (v_750_0 z) := w_750_0 z
 #a r_751_0
 theorem r_751_1 (z : Store) : (s_751 z) 776 = (v_511_0 z) := pR (k_750 z) (pR (k_749 z) (pR (k_748 z) (pR (n_744_748 z) (pR (n_736_744 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (r_512_0 z))))))))
 #a r_751_1
 theorem r_751_2 (z : Store) : (s_751 z) 613 = (z 613) := pR (k_750 z) (pR (k_749 z) (pR (k_748 z) (pR (n_744_748 z) (pR (n_736_744 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (r_512_1 z))))))))
 #a r_751_2
 def v_751_0 (z : Store) : Tensor := (bw_linear (v_750_0 z) (v_511_0 z) (z 613)).1
 def v_751_1 (z : Store) : Tensor := (bw_linear (v_750_0 z) (v_511_0 z) (z 613)).2
 def s_752 (z : Store) : Store := storeSet (s_751 z) [(778, (bw_linear ((s_751 z) 780) ((s_751 z) 776) ((s_751 z) 613)).1), (645, (bw_linear ((s_751 z) 780) ((s_751 z) 776) ((s_751 z) 613)).2)]
 theorem t_751 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_638) (pmPeers pmNode_638) (s_751 z) pmNode_638 none = some (s_752 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_751
 theorem k_751 (z : Store) (tid : Tid) (h : tid ∉ [778, 645]) : (s_752 z) tid = (s_751 z) tid := by
   unfold s_752
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_751
 theorem w_751_0 (z : Store) : (s_752 z) 778 = v_751_0 z := by
   unfold s_752
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_751_0, r_751_0 z, r_751_1 z, r_751_2 z] <;> rfl
 #a w_751_0
 theorem h_751_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_751_0 z).shape = [1, 8, 64] := by
   unfold v_751_0
   exact bw_linear_3d_fst_shape 1 8 256 64 (v_750_0 z) (v_511_0 z) (z 613) (h_750_0 z z_) (h_511_0 z z_) (i_68 z z_)
 #a h_751_0
 attribute [local irreducible] v_751_0
 theorem w_751_1 (z : Store) : (s_752 z) 645 = v_751_1 z := by
   unfold s_752
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_751_1, r_751_0 z, r_751_1 z, r_751_2 z] <;> rfl
 #a w_751_1
 theorem h_751_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_751_1 z).shape = [256, 64] := by
   unfold v_751_1
   exact bw_linear_3d_snd_shape 1 8 256 64 (v_750_0 z) (v_511_0 z) (z 613) (h_750_0 z z_) (h_511_0 z z_) (i_68 z z_)
 #a h_751_1
 attribute [local irreducible] v_751_1
 attribute [local irreducible] s_752
 theorem n_748_752 (z : Store) (tid : Tid) (h : tid ∉ ([784, 782, 647, 780, 778, 645] : List Tid)) : (s_752 z) tid = (s_748 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_748 z) (k_749 z)) (pF _ _ _ _ _ (k_750 z) (k_751 z)) tid h
 #a n_748_752
 theorem n_744_752 (z : Store) (tid : Tid) (h : tid ∉ ([788, 789, 1201, 1093, 1091, 1092, 784, 782, 647, 780, 778, 645] : List Tid)) : (s_752 z) tid = (s_744 z) tid := by
   exact pF _ _ _ _ _ (n_744_748 z) (n_748_752 z) tid h
 #a n_744_752
 theorem n_736_752 (z : Store) (tid : Tid) (h : tid ∉ ([900, 794, 793, 649, 651, 1203, 1097, 1096, 952, 954, 898, 790, 788, 789, 1201, 1093, 1091, 1092, 784, 782, 647, 780, 778, 645] : List Tid)) : (s_752 z) tid = (s_736 z) tid := by
   exact pF _ _ _ _ _ (n_736_744 z) (n_744_752 z) tid h
 #a n_736_752
 theorem r_752_0 (z : Store) : (s_752 z) 778 = (v_751_0 z) := w_751_0 z
 #a r_752_0
 theorem r_752_1 (z : Store) : (s_752 z) 775 = (v_510_0 z) := pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (k_511 z) (r_511_0 z)))))
 #a r_752_1
 theorem r_752_2 (z : Store) : (s_752 z) 611 = (z 611) := pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (k_511 z) (r_511_1 z)))))
 #a r_752_2
 theorem r_752_3 (z : Store) : (s_752 z) 612 = (z 612) := pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (k_511 z) (r_511_2 z)))))
 #a r_752_3
 def v_752_0 (z : Store) : Tensor := (bw_layernorm (v_751_0 z) (v_510_0 z) (z 611) (z 612)).1
 def v_752_1 (z : Store) : Tensor := (bw_layernorm (v_751_0 z) (v_510_0 z) (z 611) (z 612)).2.1
 def v_752_2 (z : Store) : Tensor := (bw_layernorm (v_751_0 z) (v_510_0 z) (z 611) (z 612)).2.2
 def s_753 (z : Store) : Store := storeSet (s_752 z) [(777, (bw_layernorm ((s_752 z) 778) ((s_752 z) 775) ((s_752 z) 611) ((s_752 z) 612)).1), (641, (bw_layernorm ((s_752 z) 778) ((s_752 z) 775) ((s_752 z) 611) ((s_752 z) 612)).2.1), (643, (bw_layernorm ((s_752 z) 778) ((s_752 z) 775) ((s_752 z) 611) ((s_752 z) 612)).2.2)]
 theorem t_752 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_639) (pmPeers pmNode_639) (s_752 z) pmNode_639 none = some (s_753 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_752
 theorem k_752 (z : Store) (tid : Tid) (h : tid ∉ [777, 641, 643]) : (s_753 z) tid = (s_752 z) tid := by
   unfold s_753
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_752
 theorem w_752_0 (z : Store) : (s_753 z) 777 = v_752_0 z := by
   unfold s_753
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_752_0, r_752_0 z, r_752_1 z, r_752_2 z, r_752_3 z] <;> rfl
 #a w_752_0
 theorem h_752_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_752_0 z).shape = [1, 8, 64] := by
   unfold v_752_0
   rw [bw_layernorm_dx_shape (v_751_0 z) (v_510_0 z) (z 611) (z 612) 64 [8, 1] (by rw [h_510_0 z z_]; rfl)]
   exact h_510_0 z z_
 #a h_752_0
 attribute [local irreducible] v_752_0
 theorem w_752_1 (z : Store) : (s_753 z) 641 = v_752_1 z := by
   unfold s_753
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_752_1, r_752_0 z, r_752_1 z, r_752_2 z, r_752_3 z] <;> rfl
 #a w_752_1
 theorem h_752_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_752_1 z).shape = [64] := by
   unfold v_752_1
   rw [bw_layernorm_dw_shape (v_751_0 z) (v_510_0 z) (z 611) (z 612) 64 [8, 1] (by rw [h_510_0 z z_]; rfl)]
   exact i_66 z z_
 #a h_752_1
 attribute [local irreducible] v_752_1
 theorem w_752_2 (z : Store) : (s_753 z) 643 = v_752_2 z := by
   unfold s_753
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_752_2, r_752_0 z, r_752_1 z, r_752_2 z, r_752_3 z] <;> rfl
 #a w_752_2
 theorem h_752_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_752_2 z).shape = [64] := by
   unfold v_752_2
   rw [bw_layernorm_db_shape (v_751_0 z) (v_510_0 z) (z 611) (z 612) 64 [8, 1] (by rw [h_510_0 z z_]; rfl)]
   exact i_67 z z_
 #a h_752_2
 attribute [local irreducible] v_752_2
 attribute [local irreducible] s_753
 theorem r_753_0 (z : Store) : (s_753 z) 789 = (v_744_1 z) := pR (k_752 z) (pR (n_748_752 z) (r_748_0 z))
 #a r_753_0
 theorem r_753_1 (z : Store) : (s_753 z) 1092 = (v_747_1 z) := pR (k_752 z) (pR (n_748_752 z) (r_748_1 z))
 #a r_753_1
 def v_753_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_744_1 z), (v_747_1 z)]
 theorem g_753 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_871) (s_753 z) pmNode_871 2 1 1087 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_871, r_753_0 z, r_753_1 z, h_744_1 z z_, h_747_1 z z_]
 #a g_753
 def s_754 (z : Store) : Store := pL [2, 3] (s_753 z) pmNode_871 2 1
 theorem t_753 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_871) (pmPeers pmNode_871) (s_753 z) pmNode_871 none = some (s_754 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_871) (s_753 z) pmNode_871).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1087 (by decide) (g_753 z z_)]
   rfl
 #a t_753
 theorem k_753 (z : Store) (tid : Tid) (h : tid ∉ [1087]) : (s_754 z) tid = (s_753 z) tid := by
   unfold s_754
   dsimp only [pL, pmNode_871, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_753
 theorem w_753_0 (z : Store) : (s_754 z) 1087 = v_753_0 z := by
   unfold s_754
   dsimp only [pL, pmNode_871, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_753_0, r_753_0 z, r_753_1 z] <;> rfl
 #a w_753_0
 theorem h_753_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_753_0 z).shape = [1, 8, 64] := by
   unfold v_753_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_744_1 z z_]
 #a h_753_0
 attribute [local irreducible] v_753_0
 attribute [local irreducible] s_754
 theorem r_754_0 (z : Store) : (s_754 z) 1087 = (v_753_0 z) := w_753_0 z
 #a r_754_0
 theorem r_754_1 (z : Store) : (s_754 z) 1084 = (v_518_0 z) := pR (k_753 z) (pR (k_752 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (k_519 z) (r_519_0 z))))))))))
 #a r_754_1
 theorem r_754_2 (z : Store) : (s_754 z) 917 = (z 917) := pR (k_753 z) (pR (k_752 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (k_519 z) (r_519_1 z))))))))))
 #a r_754_2
 def v_754_0 (z : Store) : Tensor := (bw_linear (v_753_0 z) (v_518_0 z) (z 917)).1
 def v_754_1 (z : Store) : Tensor := (bw_linear (v_753_0 z) (v_518_0 z) (z 917)).2
 def s_755 (z : Store) : Store := storeSet (s_754 z) [(1085, (bw_linear ((s_754 z) 1087) ((s_754 z) 1084) ((s_754 z) 917)).1), (950, (bw_linear ((s_754 z) 1087) ((s_754 z) 1084) ((s_754 z) 917)).2)]
 theorem t_754 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_872) (pmPeers pmNode_872) (s_754 z) pmNode_872 none = some (s_755 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_754
 theorem k_754 (z : Store) (tid : Tid) (h : tid ∉ [1085, 950]) : (s_755 z) tid = (s_754 z) tid := by
   unfold s_755
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_754
 theorem w_754_0 (z : Store) : (s_755 z) 1085 = v_754_0 z := by
   unfold s_755
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_754_0, r_754_0 z, r_754_1 z, r_754_2 z] <;> rfl
 #a w_754_0
 theorem h_754_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_754_0 z).shape = [1, 8, 256] := by
   unfold v_754_0
   exact bw_linear_3d_fst_shape 1 8 64 256 (v_753_0 z) (v_518_0 z) (z 917) (h_753_0 z z_) (h_518_0 z z_) (i_73 z z_)
 #a h_754_0
 attribute [local irreducible] v_754_0
 theorem w_754_1 (z : Store) : (s_755 z) 950 = v_754_1 z := by
   unfold s_755
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_754_1, r_754_0 z, r_754_1 z, r_754_2 z] <;> rfl
 #a w_754_1
 theorem h_754_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_754_1 z).shape = [64, 256] := by
   unfold v_754_1
   exact bw_linear_3d_snd_shape 1 8 64 256 (v_753_0 z) (v_518_0 z) (z 917) (h_753_0 z z_) (h_518_0 z z_) (i_73 z z_)
 #a h_754_1
 attribute [local irreducible] v_754_1
 attribute [local irreducible] s_755
 theorem r_755_0 (z : Store) : (s_755 z) 1085 = (v_754_0 z) := w_754_0 z
 #a r_755_0
 theorem r_755_1 (z : Store) : (s_755 z) 1082 = (v_517_0 z) := pR (k_754 z) (pR (k_753 z) (pR (k_752 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (k_519 z) (pR (k_518 z) (r_518_0 z))))))))))))
 #a r_755_1
 def v_755_0 (z : Store) : Tensor := bw_gelu (v_754_0 z) (v_517_0 z)
 def s_756 (z : Store) : Store := storeSet (s_755 z) [(1083, bw_gelu ((s_755 z) 1085) ((s_755 z) 1082))]
 theorem t_755 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_873) (pmPeers pmNode_873) (s_755 z) pmNode_873 none = some (s_756 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_755
 theorem k_755 (z : Store) (tid : Tid) (h : tid ∉ [1083]) : (s_756 z) tid = (s_755 z) tid := by
   unfold s_756
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_755
 theorem w_755_0 (z : Store) : (s_756 z) 1083 = v_755_0 z := by
   unfold s_756
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_755_0, r_755_0 z, r_755_1 z] <;> rfl
 #a w_755_0
 theorem h_755_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_755_0 z).shape = [1, 8, 256] := by
   unfold v_755_0
   exact h_517_0 z z_
 #a h_755_0
 attribute [local irreducible] v_755_0
 attribute [local irreducible] s_756
 theorem n_752_756 (z : Store) (tid : Tid) (h : tid ∉ ([777, 641, 643, 1087, 1085, 950, 1083] : List Tid)) : (s_756 z) tid = (s_752 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_752 z) (k_753 z)) (pF _ _ _ _ _ (k_754 z) (k_755 z)) tid h
 #a n_752_756
 record_prefix_opacity v_750_0 s_751 v_751_0 v_751_1 s_752 v_752_0 v_752_1 v_752_2 s_753 v_753_0 s_754 v_754_0 v_754_1 s_755 v_755_0 s_756

 end
 end TrainVerify.Denote.RuntimeWorld
