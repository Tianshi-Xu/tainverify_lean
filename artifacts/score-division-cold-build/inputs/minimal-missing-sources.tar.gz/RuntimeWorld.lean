import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import denote.SourceParameterFrame
import denote.SourceInitialInputEncoding
import denote.SourceEmbeddingRead
import denote.SourceEmbeddingFacts
import denote.SourceAddRead
import denote.SourceAddUnit
import denote.SourceAddFacts
import denote.SourceMultirefRead
import denote.SourceHiddenSequenceExchange
import denote.SourceLayernormRead
import denote.SourceLayernormUnit
import denote.SourceLinearRead
import denote.SourceAllGatherRead
import denote.SourceLinearUnit
import denote.SourceLayoutRead
import denote.SourceViewUnit
import denote.SourceRank4Exchange
import denote.SourceTransposeUnit
import denote.SourceTranspose23Unit
import denote.SourceRank4ReverseExchange
import denote.SourceRank4MiddleExchange
import denote.SourceMatmulRead
import denote.SourceMatmulUnit
import denote.SourceDivRead
import denote.SourceDivUnit
import denote.SourceSoftmaxRead
import denote.SourceSoftmaxUnit
import denote.SourceRank4InnerExchange
import denote.SourceQueryMatmulUnit
import denote.SourceQueryTransposeUnit
import denote.SourceContiguousRead
import denote.SourceViewFlattenUnit
import denote.SourceSequenceHiddenExchange
import denote.SourceGeluRead
import denote.SourceGeluUnit
import denote.SourcePrimitiveRead
import denote.SourceEmbeddingPositionUnit
import denote.SourceEmbeddingUnit
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0126
section RuntimeReadSource
open TrainVerify.Denote TrainVerify.Denote.RuntimeWorld
-- RuntimeReadSource v2
local notation "vP0" => SourceInitialInputRead.input_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests -- r5
local notation "vP1" => SourceEmbeddingRead.embedding_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests
local notation "vP2" => SourceEmbeddingRead.embedding_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests -- r7
local notation "vP3" => SourceAddRead.add_value_of_split smGraph smScope smPeers smGraph.nodes smInputRequests
local notation "vP4" => SourceAddRead.add_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests
local notation "vP5" => SourcePrimitiveRead.chunk_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests
local notation "vP6" => SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests
local notation "vP7" => SourceMultirefRead.multiref_value_of_split smGraph smScope smPeers smGraph.nodes smInputRequests
local notation "vP8" => SourceMultirefRead.multiref_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests
local notation "vP9" => SourceAllGatherRead.allGather_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests
local notation "vP10" => SourceLayernormRead.layernorm_value_of_split smGraph smScope smPeers smGraph.nodes smInputRequests
local notation "vP11" => SourceLayernormRead.layernorm_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests
local notation "vP12" => SourceLayoutRead.transposeAxes_value_of_split smGraph smScope smPeers smGraph.nodes smInputRequests
local notation "vP13" => SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests
local notation "vP14" => SourceLayoutRead.view_value_of_split smGraph smScope smPeers smGraph.nodes smInputRequests
local notation "vP15" => SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests
local notation "vP16" => SourceLinearRead.linear_value_of_split smGraph smScope smPeers smGraph.nodes smInputRequests
local notation "vP17" => SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes pmInputRequests
local notation:max "c0" n:max => pmInputRequests.drop n
local notation:max "c1" n:max => pmInputRequests.take n
local notation "c2" => pmInputRequests
local notation "c3" => chunkPrimDimN
local notation "c4" => List.take_append_drop
local notation "c5" => AllToAllSourceFaithful.tensor
local notation "c6" => List.mem_cons_self
local notation "c7" => pmDenoteWithInputs
local notation "c8" => allGatherPrimDimN
local notation "c9" => smInputRequests
local notation:max "c10" n:max => smInputRequests.drop n
local notation "c11" => smDenoteWithInputs
local notation "c12" => List.mem_cons_of_mem
local notation "c13" => congrArg₂
local notation "c14" => fw_embedding
local notation "c15" => List.Forall₂.cons
local notation "c16" => RelationCompiler.ReplicatedRel
local notation "c17" => fw_layernorm
local notation:max "c18" n:max => smInputRequests.take n
local notation "c19" => List.not_mem_nil
local notation "c20" => List.cons
local notation "c21" => chunkPrimDimN_shape
local notation "c22" => TrainVerify.Denote.source_add_unit_output_facts
prefix_names pmSeededPrefix ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem pmSeededPrefixSuccess (z : Store) (z_ : pmSeededPrefixInitShapes z) : runUsing (fun row s => stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) (c1 944) (some (pmInitialWithSeeds z)) = some (s_944 z) := by
   rw [pmSeededPrefixRequestsCoverage]
   exact u_0_944 z z_
 #a pmSeededPrefixSuccess
 theorem pmSeededPrefixOutput (z : Store) : (s_944 z) 964 = (v_943_0 z) := w_943_0 z
 #a pmSeededPrefixOutput
 theorem pmSeededPrefixOutputShape (z : Store) (z_ : pmSeededPrefixInitShapes z) : ((s_944 z) 964).shape = [64, 32] := by
   rw [pmSeededPrefixOutput]
   exact h_943_0 z z_
 #a pmSeededPrefixOutputShape
 theorem pmSeededPrefixFrame (z : Store) (z_ : pmSeededPrefixInitShapes z) (tid : Tid) (ht : ∀ row ∈ c1 944, tid ∉ row.1.outs) : (s_944 z) tid = (pmInitialWithSeeds z) tid := SourceScopedPrefix.frame pmGraph pmScope pmPeers _ (pmInitialWithSeeds z) (s_944 z) tid ht (pmSeededPrefixSuccess z z_)
 #a pmSeededPrefixFrame
 theorem pmSeededPrefixContinuation (z : Store) (z_ : pmSeededPrefixInitShapes z) : pmSeededDenoteWithInputs z = runUsing (fun row s => stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) (c0 944) (some (s_944 z)) := by
   unfold pmSeededDenoteWithInputs
   rw [pmDenoteWithInputs_entry]
   exact SourceScopedPrefix.continuation _ _ 944 (pmInitialWithSeeds z) (s_944 z) (pmSeededPrefixSuccess z z_)
 #a pmSeededPrefixContinuation
 theorem smSeededWholeRun (z : Store) : runUsing (fun row s => stepWithInputs smGraph (smScope row.1) (smPeers row.1) s row.1 row.2) c9 (some (smInitialWithSeeds z)) = some (smSeededWholeState z) := smSeededWholeFold c9 smSeededWholeSteps (smInitialWithSeeds z)
 #a smSeededWholeRun
 theorem smSeededWholeSuccess (z : Store) : smSeededDenoteWithInputs z = some (smSeededWholeState z) := by
   unfold smSeededDenoteWithInputs
   rw [smDenoteWithInputs_entry]
   exact smSeededWholeRun z
 #a smSeededWholeSuccess
 theorem smSeededWholeFrame (z : Store) (tid : Tid) (h : ∀ row ∈ c9, tid ∉ row.1.outs) :
     (smSeededWholeState z) tid = (smInitialWithSeeds z) tid := SourceScopedPrefix.frame smGraph smScope smPeers _ (smInitialWithSeeds z) (smSeededWholeState z) tid h (smSeededWholeRun z)
 #a smSeededWholeFrame

 end
 end TrainVerify.Denote.RuntimeWorld

section RuntimeRelationSource
open TrainVerify.Denote TrainVerify.Denote.RuntimeWorld
local notation "r0" => pmInputRequests.drop
local notation "r1" => pmInputRequests.take
local notation "r2" => smInputRequests.drop
local notation "r3" => smInputRequests.take
local notation "r4" => SourceInitialInputEncoding.emitted_ordered_slice_eq_chunk
local notation "r5" => SourceInitialInputRead.input_value_of_split
local notation "r6" => RelationCompiler.RelationFact.chunked
local notation "r7" => SourceEmbeddingRead.embedding_value_of_split
local notation "r8" => List.take_append_drop
local notation "r9" => List.mem_cons_self
local notation "r10" => List.mem_cons_of_mem
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
open SourceInitialParameterSpecs
set_option maxHeartbeats 500000
private def initialParameterSpecs : List Spec := [
.sharded 1212 [16, 319] 1 [256, 64] [256, 32],
.sharded 1212 [622, 925] 1 [256, 64] [256, 32],
.replicated 1213 [0, 303] [16, 64],
.replicated 1213 [606, 909] [16, 64],
.replicated 1214 [1, 304] [64],
.replicated 1214 [607, 910] [64],
.replicated 1215 [2, 305] [64],
.replicated 1215 [608, 911] [64],
.replicated 1216 [3, 306] [64, 64],
.replicated 1216 [609, 912] [64, 64],
.sharded 1217 [27, 330] 0 [64, 64] [32, 64],
.sharded 1217 [633, 936] 0 [64, 64] [32, 64],
.sharded 1218 [30, 333] 0 [64, 64] [32, 64],
.sharded 1218 [636, 939] 0 [64, 64] [32, 64],
.replicated 1219 [4, 307] [64, 64],
.replicated 1219 [610, 913] [64, 64],
.replicated 1220 [5, 308] [64],
.replicated 1220 [611, 914] [64],
.replicated 1221 [6, 309] [64],
.replicated 1221 [612, 915] [64],
.replicated 1222 [7, 310] [256, 64],
.replicated 1222 [613, 916] [256, 64],
.replicated 1223 [8, 311] [64, 256],
.replicated 1223 [614, 917] [64, 256],
.replicated 1224 [9, 312] [64],
.replicated 1224 [615, 918] [64],
.replicated 1225 [10, 313] [64],
.replicated 1225 [616, 919] [64],
.sharded 1226 [47, 350] 0 [64, 64] [32, 64],
.sharded 1226 [653, 956] 0 [64, 64] [32, 64],
.sharded 1227 [50, 353] 1 [64, 64] [64, 32],
.sharded 1227 [656, 959] 1 [64, 64] [64, 32],
.sharded 1228 [53, 356] 1 [64, 64] [64, 32],
.sharded 1228 [659, 962] 1 [64, 64] [64, 32],
.sharded 1229 [56, 359] 1 [64, 64] [64, 32],
.sharded 1229 [662, 965] 1 [64, 64] [64, 32],
.replicated 1230 [11, 314] [64],
.replicated 1230 [617, 920] [64],
.replicated 1231 [12, 315] [64],
.replicated 1231 [618, 921] [64],
.sharded 1232 [63, 366] 1 [256, 64] [256, 32],
.sharded 1232 [669, 972] 1 [256, 64] [256, 32],
.replicated 1233 [13, 316] [64, 256],
.replicated 1233 [619, 922] [64, 256],
.replicated 1234 [14, 317] [64],
.replicated 1234 [620, 923] [64],
.replicated 1235 [15, 318] [64],
.replicated 1235 [621, 924] [64],
.sharded 1236 [72, 375] 0 [256, 64] [128, 64],
.sharded 1236 [678, 981] 0 [256, 64] [128, 64]]
private theorem initialParameterSpecs_valid : All Spec.valid initialParameterSpecs := by decide
def InitialParameterValues (initSM initPM : Store) : Prop :=
  All (fun spec => spec.values initSM initPM) initialParameterSpecs
def InitialParameterRelations (initSM initPM : Store) : Prop :=
  All (fun spec => spec.fact.Holds initSM initPM) initialParameterSpecs
theorem initialParameterRelations_of_values (initSM initPM : Store)
    (h : InitialParameterValues initSM initPM) : InitialParameterRelations initSM initPM :=
  all_of_values initialParameterSpecs initSM initPM initialParameterSpecs_valid h
#print axioms initialParameterRelations_of_values
end
end TrainVerify.Denote.RuntimeWorld

namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem inputSlice_1262_75 : pmNode_0_port0 = c3 0 2 0 smNode_0_port0 :=
  r4 smNode_0_port0 pmNode_0_port0
    smNode_0_port0_values pmNode_0_port0_values 2 0 1 16
    rfl rfl (by decide) (by decide) (by decide) rfl rfl (by decide)
#print axioms inputSlice_1262_75
theorem inputSlice_1262_378 : pmNode_236_port0 = c3 0 2 0 smNode_0_port0 :=
  r4 smNode_0_port0 pmNode_236_port0
    smNode_0_port0_values pmNode_236_port0_values 2 0 1 16
    rfl rfl (by decide) (by decide) (by decide) rfl rfl (by decide)
#print axioms inputSlice_1262_378
theorem inputSlice_1262_681 : pmNode_472_port0 = c3 0 2 1 smNode_0_port0 :=
  r4 smNode_0_port0 pmNode_472_port0
    smNode_0_port0_values pmNode_472_port0_values 2 1 1 16
    rfl rfl (by decide) (by decide) (by decide) rfl rfl (by decide)
#print axioms inputSlice_1262_681
theorem inputSlice_1262_984 : pmNode_708_port0 = c3 0 2 1 smNode_0_port0 :=
  r4 smNode_0_port0 pmNode_708_port0
    smNode_0_port0_values pmNode_708_port0_values 2 1 1 16
    rfl rfl (by decide) (by decide) (by decide) rfl rfl (by decide)
#print axioms inputSlice_1262_984
theorem inputSlice_1263_76 : pmNode_0_port1 = c3 0 2 0 smNode_0_port1 :=
  r4 smNode_0_port1 pmNode_0_port1
    smNode_0_port1_values pmNode_0_port1_values 2 0 1 16
    rfl rfl (by decide) (by decide) (by decide) rfl rfl (by decide)
#print axioms inputSlice_1263_76
theorem inputSlice_1263_379 : pmNode_236_port1 = c3 0 2 0 smNode_0_port1 :=
  r4 smNode_0_port1 pmNode_236_port1
    smNode_0_port1_values pmNode_236_port1_values 2 0 1 16
    rfl rfl (by decide) (by decide) (by decide) rfl rfl (by decide)
#print axioms inputSlice_1263_379
theorem inputSlice_1263_682 : pmNode_472_port1 = c3 0 2 1 smNode_0_port1 :=
  r4 smNode_0_port1 pmNode_472_port1
    smNode_0_port1_values pmNode_472_port1_values 2 1 1 16
    rfl rfl (by decide) (by decide) (by decide) rfl rfl (by decide)
#print axioms inputSlice_1263_682
theorem inputSlice_1263_985 : pmNode_708_port1 = c3 0 2 1 smNode_0_port1 :=
  r4 smNode_0_port1 pmNode_708_port1
    smNode_0_port1_values pmNode_708_port1_values 2 1 1 16
    rfl rfl (by decide) (by decide) (by decide) rfl rfl (by decide)
#print axioms inputSlice_1263_985
theorem inputSplit_sm_0 : c9 = (r3 0) ++ (smNode_0, some smNode_0_feed) :: (r2 1) := by
  calc
    c9 = (r3 0) ++ r2 0 := (r8 0 c9).symm
    _ = _ := rfl
#print axioms inputSplit_sm_0
section RBS_0
variable (init final : Store) (h : c11 init = some final)
include init final h
theorem inputRead_1262 :
    final 1262 = smNode_0_port0 :=
  r5 smGraph smScope smPeers smGraph.nodes
    c9 (r3 0) (r2 1) smNode_0 smNode_0_feed init final
    1262 smNode_0_port0 inputSplit_sm_0 rfl smNode_0_contract r9 h
#print axioms inputRead_1262
theorem inputRead_1263 :
    final 1263 = smNode_0_port1 :=
  r5 smGraph smScope smPeers smGraph.nodes
    c9 (r3 0) (r2 1) smNode_0 smNode_0_feed init final
    1263 smNode_0_port1 inputSplit_sm_0 rfl smNode_0_contract (r10 _ r9) h
#print axioms inputRead_1263
end RBS_0
theorem inputSplit_pm_0 : c2 = (r1 0) ++ (pmNode_0, some pmNode_0_feed) :: (r0 1) := by
  calc
    c2 = (r1 0) ++ r0 0 := (r8 0 c2).symm
    _ = _ := rfl
#print axioms inputSplit_pm_0
section RBS_1
variable (init final : Store) (h : c7 init = some final)
include init final h
theorem inputRead_75 :
    final 75 = pmNode_0_port0 :=
  vP0 (r1 0) (r0 1) pmNode_0 pmNode_0_feed init final
    75 pmNode_0_port0 inputSplit_pm_0 rfl pmNode_0_contract r9 h
#print axioms inputRead_75
theorem inputRead_76 :
    final 76 = pmNode_0_port1 :=
  vP0 (r1 0) (r0 1) pmNode_0 pmNode_0_feed init final
    76 pmNode_0_port1 inputSplit_pm_0 rfl pmNode_0_contract (r10 _ r9) h
#print axioms inputRead_76
end RBS_1
theorem inputSplit_pm_236 : c2 = (r1 4) ++ (pmNode_236, some pmNode_236_feed) :: (r0 5) := by
  calc
    c2 = (r1 4) ++ r0 4 := (r8 4 c2).symm
    _ = _ := rfl
#print axioms inputSplit_pm_236
section RBS_2
variable (init final : Store) (h : c7 init = some final)
include init final h
theorem inputRead_378 :
    final 378 = pmNode_236_port0 :=
  vP0 (r1 4) (r0 5) pmNode_236 pmNode_236_feed init final
    378 pmNode_236_port0 inputSplit_pm_236 rfl pmNode_236_contract r9 h
#print axioms inputRead_378
theorem inputRead_379 :
    final 379 = pmNode_236_port1 :=
  vP0 (r1 4) (r0 5) pmNode_236 pmNode_236_feed init final
    379 pmNode_236_port1 inputSplit_pm_236 rfl pmNode_236_contract (r10 _ r9) h
#print axioms inputRead_379
end RBS_2
theorem inputSplit_pm_472 : c2 = (r1 422) ++ (pmNode_472, some pmNode_472_feed) :: (r0 423) := by
  calc
    c2 = (r1 422) ++ r0 422 := (r8 422 c2).symm
    _ = _ := rfl
#print axioms inputSplit_pm_472
section RBS_3
variable (init final : Store) (h : c7 init = some final)
include init final h
theorem inputRead_681 :
    final 681 = pmNode_472_port0 :=
  vP0 (r1 422) (r0 423) pmNode_472 pmNode_472_feed init final
    681 pmNode_472_port0 inputSplit_pm_472 rfl pmNode_472_contract r9 h
#print axioms inputRead_681
theorem inputRead_682 :
    final 682 = pmNode_472_port1 :=
  vP0 (r1 422) (r0 423) pmNode_472 pmNode_472_feed init final
    682 pmNode_472_port1 inputSplit_pm_472 rfl pmNode_472_contract (r10 _ r9) h
#print axioms inputRead_682
end RBS_3
theorem inputSplit_pm_708 : c2 = (r1 426) ++ (pmNode_708, some pmNode_708_feed) :: (r0 427) := by
  calc
    c2 = (r1 426) ++ r0 426 := (r8 426 c2).symm
    _ = _ := rfl
#print axioms inputSplit_pm_708
section RBS_4
variable (init final : Store) (h : c7 init = some final)
include init final h
theorem inputRead_984 :
    final 984 = pmNode_708_port0 :=
  vP0 (r1 426) (r0 427) pmNode_708 pmNode_708_feed init final
    984 pmNode_708_port0 inputSplit_pm_708 rfl pmNode_708_contract r9 h
#print axioms inputRead_984
theorem inputRead_985 :
    final 985 = pmNode_708_port1 :=
  vP0 (r1 426) (r0 427) pmNode_708 pmNode_708_feed init final
    985 pmNode_708_port1 inputSplit_pm_708 rfl pmNode_708_contract (r10 _ r9) h
#print axioms inputRead_985
end RBS_4
section RBS_5
variable (smInit pmInit smFinal pmFinal : Store) (hs : c11 smInit = some smFinal) (hp : c7 pmInit = some pmFinal)
include smInit pmInit smFinal pmFinal hs hp
theorem inputStoreRelation_1262_0 : (r6 1262 [75, 681] 0 [2, 16] [1, 16]).Holds smFinal pmFinal := by
  apply SourceInitialParameters.chunked_of_exact_slices smFinal pmFinal 1262 [75, 681] 0 2 [2, 16] [1, 16] (by decide) (by decide)
  · rw [inputRead_1262 smInit smFinal hs]; rfl
  · decide
  · change [pmFinal 75, pmFinal 681] = [c3 0 2 0 (smFinal 1262), c3 0 2 1 (smFinal 1262)]
    rw [inputRead_75 pmInit pmFinal hp, inputRead_681 pmInit pmFinal hp, inputRead_1262 smInit smFinal hs]
    rw [inputSlice_1262_75, inputSlice_1262_681]
#print axioms inputStoreRelation_1262_0
theorem inputStoreRelation_1262_1 : (r6 1262 [378, 984] 0 [2, 16] [1, 16]).Holds smFinal pmFinal := by
  apply SourceInitialParameters.chunked_of_exact_slices smFinal pmFinal 1262 [378, 984] 0 2 [2, 16] [1, 16] (by decide) (by decide)
  · rw [inputRead_1262 smInit smFinal hs]; rfl
  · decide
  · change [pmFinal 378, pmFinal 984] = [c3 0 2 0 (smFinal 1262), c3 0 2 1 (smFinal 1262)]
    rw [inputRead_378 pmInit pmFinal hp, inputRead_984 pmInit pmFinal hp, inputRead_1262 smInit smFinal hs]
    rw [inputSlice_1262_378, inputSlice_1262_984]
#print axioms inputStoreRelation_1262_1
theorem inputStoreRelation_1263_0 : (r6 1263 [76, 682] 0 [2, 16] [1, 16]).Holds smFinal pmFinal := by
  apply SourceInitialParameters.chunked_of_exact_slices smFinal pmFinal 1263 [76, 682] 0 2 [2, 16] [1, 16] (by decide) (by decide)
  · rw [inputRead_1263 smInit smFinal hs]; rfl
  · decide
  · change [pmFinal 76, pmFinal 682] = [c3 0 2 0 (smFinal 1263), c3 0 2 1 (smFinal 1263)]
    rw [inputRead_76 pmInit pmFinal hp, inputRead_682 pmInit pmFinal hp, inputRead_1263 smInit smFinal hs]
    rw [inputSlice_1263_76, inputSlice_1263_682]
#print axioms inputStoreRelation_1263_0
theorem inputStoreRelation_1263_1 : (r6 1263 [379, 985] 0 [2, 16] [1, 16]).Holds smFinal pmFinal := by
  apply SourceInitialParameters.chunked_of_exact_slices smFinal pmFinal 1263 [379, 985] 0 2 [2, 16] [1, 16] (by decide) (by decide)
  · rw [inputRead_1263 smInit smFinal hs]; rfl
  · decide
  · change [pmFinal 379, pmFinal 985] = [c3 0 2 0 (smFinal 1263), c3 0 2 1 (smFinal 1263)]
    rw [inputRead_379 pmInit pmFinal hp, inputRead_985 pmInit pmFinal hp, inputRead_1263 smInit smFinal hs]
    rw [inputSlice_1263_379, inputSlice_1263_985]
#print axioms inputStoreRelation_1263_1
end RBS_5
def InputStoreRelations (smFinal pmFinal : Store) : Prop :=
  (r6 1262 [75, 681] 0 [2, 16] [1, 16]).Holds smFinal pmFinal ∧
  (r6 1262 [378, 984] 0 [2, 16] [1, 16]).Holds smFinal pmFinal ∧
  (r6 1263 [76, 682] 0 [2, 16] [1, 16]).Holds smFinal pmFinal ∧
  (r6 1263 [379, 985] 0 [2, 16] [1, 16]).Holds smFinal pmFinal
theorem inputStoreRelations_of_success (smInit pmInit smFinal pmFinal : Store) (hs : c11 smInit = some smFinal) (hp : c7 pmInit = some pmFinal) : InputStoreRelations smFinal pmFinal :=
  ⟨inputStoreRelation_1262_0 smInit pmInit smFinal pmFinal hs hp, inputStoreRelation_1262_1 smInit pmInit smFinal pmFinal hs hp, inputStoreRelation_1263_0 smInit pmInit smFinal pmFinal hs hp, inputStoreRelation_1263_1 smInit pmInit smFinal pmFinal hs hp⟩
#print axioms inputStoreRelations_of_success
end
end TrainVerify.Denote.RuntimeWorld

namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem embeddingRead_1265 (s t : Store) (h : c11 s = some t) :
    t 1265 = c14 (t 1262) (t 1212) := by
  apply r7 smGraph smScope smPeers smGraph.nodes
    c9 (r3 1) (r2 2) smNode_1 0 1262 1212 1265 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = r3 1 ++ r2 1 := (r8 1 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ r2 1, 1262 ∉ row.1.outs
    decide
  · change ∀ row ∈ r2 1, 1212 ∉ row.1.outs
    decide
#print axioms embeddingRead_1265
section RBS_6
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem embeddingRead_89 :
    t 89 = c14 (t 75) (t 16) := by
  apply vP2 (r1 1) (r0 2) pmNode_1 0 75 16 89 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = r1 1 ++ r0 1 := (r8 1 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ r0 1, 75 ∉ row.1.outs
    decide
  · change ∀ row ∈ r0 1, 16 ∉ row.1.outs
    decide
#print axioms embeddingRead_89
theorem embeddingRead_392 :
    t 392 = c14 (t 378) (t 319) := by
  apply vP2 (r1 5) (r0 6) pmNode_237 1 378 319 392 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = r1 5 ++ r0 5 := (r8 5 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ r0 5, 378 ∉ row.1.outs
    decide
  · change ∀ row ∈ r0 5, 319 ∉ row.1.outs
    decide
#print axioms embeddingRead_392
theorem embeddingRead_695 :
    t 695 = c14 (t 681) (t 622) := by
  apply vP2 (r1 423) (r0 424) pmNode_473 2 681 622 695 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = r1 423 ++ r0 423 := (r8 423 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ r0 423, 681 ∉ row.1.outs
    decide
  · change ∀ row ∈ r0 423, 622 ∉ row.1.outs
    decide
#print axioms embeddingRead_695
theorem embeddingRead_998 :
    t 998 = c14 (t 984) (t 925) := by
  apply vP2 (r1 427) (r0 428) pmNode_709 3 984 925 998 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = r1 427 ++ r0 427 := (r8 427 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ r0 427, 984 ∉ row.1.outs
    decide
  · change ∀ row ∈ r0 427, 925 ∉ row.1.outs
    decide
#print axioms embeddingRead_998
end RBS_6
end
end TrainVerify.Denote.RuntimeWorld

namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
private theorem parameterUnwritten : SourceInitialParameterSpecs.All
    (fun spec => SourceParameterFrame.SpecUnwritten spec
      (smInputRequests.flatMap (fun r => r.1.outs))
      (pmInputRequests.flatMap (fun r => r.1.outs))) initialParameterSpecs := by decide
theorem initialParameterValues_final (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) : InitialParameterValues t q :=
  SourceParameterFrame.all_values_runWithInputs initialParameterSpecs smGraph pmGraph
    smScope pmScope smPeers pmPeers smGraph.nodes pmGraph.nodes c9 c2
    s p t q parameterUnwritten hs hp h
#print axioms initialParameterValues_final
end
end TrainVerify.Denote.RuntimeWorld

namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_7
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p)
include s p t q hs hp h
theorem embeddingUnitFacts_1265_0 :
    (t 1265).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 89, q 392], x.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1265) =
    c8 2 2 0 [q 89, q 392] := by
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have weights : RelationCompiler.ShardedRel (t 1212) [q 16, q 319] 1 [256, 64] [256, 32] := hrels.1
  have ids0 : q 75 = c3 0 2 0 (t 1262) :=
    (inputStoreRelation_1262_0 s p t q hs hp).chunk_values 0 (by change 0 < 2; decide)
  have ids1 : q 378 = c3 0 2 0 (t 1262) :=
    (inputStoreRelation_1262_1 s p t q hs hp).chunk_values 0 (by change 0 < 2; decide)
  exact fw_embedding_dp_tp_unit_facts_of_source_eqs 2 0 2 1 16 256 32
    (t 1262) (q 75) (t 1212) [q 16, q 319] (t 1265) [q 89, q 392]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    (inputStoreRelation_1262_0 s p t q hs hp).full_shape ids0 rfl
    weights.shard_shapes weights.full_value (embeddingRead_1265 s t hs)
    (c15 (embeddingRead_89 p q hp) (c15 ((embeddingRead_392 p q hp).trans (congrArg (fun x => c14 x (q 319)) (ids1.trans ids0.symm))) (List.Forall₂.nil)))
#print axioms embeddingUnitFacts_1265_0
theorem embeddingUnit_1265_0 :
    c3 0 2 0 (t 1265) =
    c8 2 2 0 [q 89, q 392] := by
  exact (embeddingUnitFacts_1265_0 s p t q hs hp h).2.2
#print axioms embeddingUnit_1265_0
theorem embeddingUnitFacts_1265_1 :
    (t 1265).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 695, q 998], x.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1265) =
    c8 2 2 0 [q 695, q 998] := by
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have weights : RelationCompiler.ShardedRel (t 1212) [q 622, q 925] 1 [256, 64] [256, 32] := hrels.2.1
  have ids0 : q 681 = c3 0 2 1 (t 1262) :=
    (inputStoreRelation_1262_0 s p t q hs hp).chunk_values 1 (by change 1 < 2; decide)
  have ids1 : q 984 = c3 0 2 1 (t 1262) :=
    (inputStoreRelation_1262_1 s p t q hs hp).chunk_values 1 (by change 1 < 2; decide)
  exact fw_embedding_dp_tp_unit_facts_of_source_eqs 2 1 2 1 16 256 32
    (t 1262) (q 681) (t 1212) [q 622, q 925] (t 1265) [q 695, q 998]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    (inputStoreRelation_1262_0 s p t q hs hp).full_shape ids0 rfl
    weights.shard_shapes weights.full_value (embeddingRead_1265 s t hs)
    (c15 (embeddingRead_695 p q hp) (c15 ((embeddingRead_998 p q hp).trans (congrArg (fun x => c14 x (q 925)) (ids1.trans ids0.symm))) (List.Forall₂.nil)))
#print axioms embeddingUnitFacts_1265_1
theorem embeddingUnit_1265_1 :
    c3 0 2 1 (t 1265) =
    c8 2 2 0 [q 695, q 998] := by
  exact (embeddingUnitFacts_1265_1 s p t q hs hp h).2.2
#print axioms embeddingUnit_1265_1
end RBS_7
end
end TrainVerify.Denote.RuntimeWorld
end RuntimeRelationSource

-- Generated source reads: UNCOMPILED until parent kernel verification.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem embeddingRouteRead_sm_1266 (s t : Store) (h : c11 s = some t) :
    t 1266 = c14 (t 1263) (t 1213) := by
  apply SourceEmbeddingRead.embedding_value_of_split smGraph smScope smPeers smGraph.nodes
    c9 (c18 2) (c10 3) smNode_2 0 1263 1213 1266 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 2 ++ c10 2 := (c4 2 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 2, 1263 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 2, 1213 ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_sm_1266
section RBS_8
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem embeddingRouteRead_pm_91 :
    t 91 = c3 1 2 0 (t 76) := by
  apply vP5 (c1 2) (c0 3) pmNode_2 0 [0, 1] 76 91 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 2 ++ c0 2 := (c4 2 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 2, 76 ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_91
theorem embeddingRouteRead_pm_92 :
    t 92 = c14 (t 91) (t 0) := by
  apply vP1 (c1 3) (c0 4) pmNode_3 0 91 0 92 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 3 ++ c0 3 := (c4 3 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 3, 91 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 3, 0 ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_92
theorem embeddingRouteRead_pm_94 :
    t 94 = c5 2 0 1 2 (([92, 395] : List Tid).map t) := by
  apply vP6 (c1 8) (c0 9) pmNode_4 0 [0, 1] [92, 395] 94 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 8 ++ c0 8 := (c4 8 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([92, 395] : List Tid), ∀ row ∈ c0 8, tid ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_94
theorem embeddingRouteRead_pm_394 :
    t 394 = c3 1 2 1 (t 379) := by
  apply vP5 (c1 6) (c0 7) pmNode_238 1 [0, 1] 379 394 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 6 ++ c0 6 := (c4 6 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 6, 379 ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_394
theorem embeddingRouteRead_pm_395 :
    t 395 = c14 (t 394) (t 303) := by
  apply vP1 (c1 7) (c0 8) pmNode_239 1 394 303 395 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 7 ++ c0 7 := (c4 7 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 7, 394 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 7, 303 ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_395
theorem embeddingRouteRead_pm_397 :
    t 397 = c5 2 1 1 2 (([92, 395] : List Tid).map t) := by
  apply vP6 (c1 11) (c0 12) pmNode_240 1 [0, 1] [92, 395] 397 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 11 ++ c0 11 := (c4 11 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([92, 395] : List Tid), ∀ row ∈ c0 11, tid ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_397
theorem embeddingRouteRead_pm_697 :
    t 697 = c3 1 2 0 (t 682) := by
  apply vP5 (c1 424) (c0 425) pmNode_474 2 [2, 3] 682 697 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 424 ++ c0 424 := (c4 424 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 424, 682 ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_697
theorem embeddingRouteRead_pm_698 :
    t 698 = c14 (t 697) (t 606) := by
  apply vP1 (c1 425) (c0 426) pmNode_475 2 697 606 698 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 425 ++ c0 425 := (c4 425 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 425, 697 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 425, 606 ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_698
theorem embeddingRouteRead_pm_700 :
    t 700 = c5 2 0 1 2 (([698, 1001] : List Tid).map t) := by
  apply vP6 (c1 430) (c0 431) pmNode_476 2 [2, 3] [698, 1001] 700 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 430 ++ c0 430 := (c4 430 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([698, 1001] : List Tid), ∀ row ∈ c0 430, tid ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_700
theorem embeddingRouteRead_pm_1000 :
    t 1000 = c3 1 2 1 (t 985) := by
  apply vP5 (c1 428) (c0 429) pmNode_710 3 [2, 3] 985 1000 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 428 ++ c0 428 := (c4 428 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 428, 985 ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_1000
theorem embeddingRouteRead_pm_1001 :
    t 1001 = c14 (t 1000) (t 909) := by
  apply vP1 (c1 429) (c0 430) pmNode_711 3 1000 909 1001 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 429 ++ c0 429 := (c4 429 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 429, 1000 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 429, 909 ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_1001
theorem embeddingRouteRead_pm_1003 :
    t 1003 = c5 2 1 1 2 (([698, 1001] : List Tid).map t) := by
  apply vP6 (c1 433) (c0 434) pmNode_712 3 [2, 3] [698, 1001] 1003 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 433 ++ c0 433 := (c4 433 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([698, 1001] : List Tid), ∀ row ∈ c0 433, tid ∉ row.1.outs
    decide
#print axioms embeddingRouteRead_pm_1003
end RBS_8
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent-owned kernel check and source-read integration required.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_9
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p)
include s p t q hs hp h
theorem embeddingPositionUnitFacts_1266_0 :
    (t 1266).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 94, q 397], x.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1266) =
    c8 2 2 0 [q 94, q 397] := by
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have weights : c16 (t 1213) [q 0, q 303] [16, 64] := hrels.2.2.1
  have fullShape : (t 1263).shape = [2, 16] :=
    (inputStoreRelation_1263_0 s p t q hs hp).full_shape
  have ids0 : q 76 = c3 0 2 0 (t 1263) :=
    (inputStoreRelation_1263_0 s p t q hs hp).chunk_values 0 (by change 0 < 2; decide)
  have ids1 : q 379 = c3 0 2 0 (t 1263) :=
    (inputStoreRelation_1263_1 s p t q hs hp).chunk_values 0 (by change 0 < 2; decide)
  have unitShape : (q 76).shape = [1, 16] := by
    rw [ids0]
    exact c21 0 2 0 (t 1263) [2, 16] fullShape (by decide)
  have chunk0 : q 91 = c3 1 2 0 (q 76) :=
    (embeddingRouteRead_pm_91 p q hp).trans
      (congrArg (fun x => c3 1 2 0 x) (ids0.trans ids0.symm))
  have shardShape0 : (q 91).shape = [1, 8] := by
    rw [chunk0]
    exact c21 1 2 0 (q 76) [1, 16] unitShape (by decide)
  have weight0 : q 0 = t 1213 :=
    weights.replica_values (q 0) (by simp only [List.mem_cons, c19, or_false, true_or, or_true, eq_self])
  have local0 : q 92 = c14 (q 91) (t 1213) :=
    (embeddingRouteRead_pm_92 p q hp).trans
      (congrArg (fun w => c14 (q 91) w) weight0)
  have chunk1 : q 394 = c3 1 2 1 (q 76) :=
    (embeddingRouteRead_pm_394 p q hp).trans
      (congrArg (fun x => c3 1 2 1 x) (ids1.trans ids0.symm))
  have shardShape1 : (q 394).shape = [1, 8] := by
    rw [chunk1]
    exact c21 1 2 1 (q 76) [1, 16] unitShape (by decide)
  have weight1 : q 303 = t 1213 :=
    weights.replica_values (q 303) (by simp only [List.mem_cons, c19, or_false, true_or, or_true, eq_self])
  have local1 : q 395 = c14 (q 394) (t 1213) :=
    (embeddingRouteRead_pm_395 p q hp).trans
      (congrArg (fun w => c14 (q 394) w) weight1)
  have chunks : [q 91, q 394] = List.ofFn (fun r : Fin 2 => c3 1 2 r.val (q 76)) := by
    change [q 91, q 394] = [c3 1 2 0 (q 76), c3 1 2 1 (q 76)]
    exact c13 c20 (chunk0) (c13 c20 (chunk1) (rfl))
  have unitGather : (q 76) = c8 1 2 0 [q 91, q 394] := by
    rw [chunks]
    exact (TrainVerify.Denote.allGatherPrimDimN_chunks_ofFn 1 2 (q 76)
      (by decide) (by rw [unitShape]; decide) (by rw [unitShape]; decide)).symm
  have shardShapes : ∀ x ∈ [q 91, q 394], x.shape = [1, 8] := by
    intro x hx
    simp only [List.mem_cons, c19, or_false] at hx
    rcases hx with rfl | rfl
    · exact shardShape0
    · exact shardShape1
  have aaOutputs : [q 94, q 397] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 2 [q 92, q 395]) := by
    change [q 94, q 397] = [c5 2 0 1 2 [q 92, q 395], c5 2 1 1 2 [q 92, q 395]]
    exact c13 c20 (embeddingRouteRead_pm_94 p q hp) (c13 c20 (embeddingRouteRead_pm_397 p q hp) (rfl))
  exact fw_embedding_dp_tp_position_unit_facts_of_source_eqs 2 0 2 1 8 16 32
    (t 1263) (q 76) (t 1213) [q 91, q 394] (t 1266) [q 92, q 395] [q 94, q 397]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    fullShape weights.full_shape ids0 rfl shardShapes unitGather
    (embeddingRouteRead_sm_1266 s t hs) (c15 local0 (c15 local1 (List.Forall₂.nil))) aaOutputs
#print axioms embeddingPositionUnitFacts_1266_0
theorem embeddingPositionUnit_1266_0 :
    c3 0 2 0 (t 1266) =
    c8 2 2 0 [q 94, q 397] := by
  exact (embeddingPositionUnitFacts_1266_0 s p t q hs hp h).2.2
#print axioms embeddingPositionUnit_1266_0
theorem embeddingPositionUnitFacts_1266_1 :
    (t 1266).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 700, q 1003], x.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1266) =
    c8 2 2 0 [q 700, q 1003] := by
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have weights : c16 (t 1213) [q 606, q 909] [16, 64] := hrels.2.2.2.1
  have fullShape : (t 1263).shape = [2, 16] :=
    (inputStoreRelation_1263_0 s p t q hs hp).full_shape
  have ids0 : q 682 = c3 0 2 1 (t 1263) :=
    (inputStoreRelation_1263_0 s p t q hs hp).chunk_values 1 (by change 1 < 2; decide)
  have ids1 : q 985 = c3 0 2 1 (t 1263) :=
    (inputStoreRelation_1263_1 s p t q hs hp).chunk_values 1 (by change 1 < 2; decide)
  have unitShape : (q 682).shape = [1, 16] := by
    rw [ids0]
    exact c21 0 2 1 (t 1263) [2, 16] fullShape (by decide)
  have chunk0 : q 697 = c3 1 2 0 (q 682) :=
    (embeddingRouteRead_pm_697 p q hp).trans
      (congrArg (fun x => c3 1 2 0 x) (ids0.trans ids0.symm))
  have shardShape0 : (q 697).shape = [1, 8] := by
    rw [chunk0]
    exact c21 1 2 0 (q 682) [1, 16] unitShape (by decide)
  have weight0 : q 606 = t 1213 :=
    weights.replica_values (q 606) (by simp only [List.mem_cons, c19, or_false, true_or, or_true, eq_self])
  have local0 : q 698 = c14 (q 697) (t 1213) :=
    (embeddingRouteRead_pm_698 p q hp).trans
      (congrArg (fun w => c14 (q 697) w) weight0)
  have chunk1 : q 1000 = c3 1 2 1 (q 682) :=
    (embeddingRouteRead_pm_1000 p q hp).trans
      (congrArg (fun x => c3 1 2 1 x) (ids1.trans ids0.symm))
  have shardShape1 : (q 1000).shape = [1, 8] := by
    rw [chunk1]
    exact c21 1 2 1 (q 682) [1, 16] unitShape (by decide)
  have weight1 : q 909 = t 1213 :=
    weights.replica_values (q 909) (by simp only [List.mem_cons, c19, or_false, true_or, or_true, eq_self])
  have local1 : q 1001 = c14 (q 1000) (t 1213) :=
    (embeddingRouteRead_pm_1001 p q hp).trans
      (congrArg (fun w => c14 (q 1000) w) weight1)
  have chunks : [q 697, q 1000] = List.ofFn (fun r : Fin 2 => c3 1 2 r.val (q 682)) := by
    change [q 697, q 1000] = [c3 1 2 0 (q 682), c3 1 2 1 (q 682)]
    exact c13 c20 (chunk0) (c13 c20 (chunk1) (rfl))
  have unitGather : (q 682) = c8 1 2 0 [q 697, q 1000] := by
    rw [chunks]
    exact (TrainVerify.Denote.allGatherPrimDimN_chunks_ofFn 1 2 (q 682)
      (by decide) (by rw [unitShape]; decide) (by rw [unitShape]; decide)).symm
  have shardShapes : ∀ x ∈ [q 697, q 1000], x.shape = [1, 8] := by
    intro x hx
    simp only [List.mem_cons, c19, or_false] at hx
    rcases hx with rfl | rfl
    · exact shardShape0
    · exact shardShape1
  have aaOutputs : [q 700, q 1003] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 2 [q 698, q 1001]) := by
    change [q 700, q 1003] = [c5 2 0 1 2 [q 698, q 1001], c5 2 1 1 2 [q 698, q 1001]]
    exact c13 c20 (embeddingRouteRead_pm_700 p q hp) (c13 c20 (embeddingRouteRead_pm_1003 p q hp) (rfl))
  exact fw_embedding_dp_tp_position_unit_facts_of_source_eqs 2 1 2 1 8 16 32
    (t 1263) (q 682) (t 1213) [q 697, q 1000] (t 1266) [q 698, q 1001] [q 700, q 1003]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    fullShape weights.full_shape ids0 rfl shardShapes unitGather
    (embeddingRouteRead_sm_1266 s t hs) (c15 local0 (c15 local1 (List.Forall₂.nil))) aaOutputs
#print axioms embeddingPositionUnitFacts_1266_1
theorem embeddingPositionUnit_1266_1 :
    c3 0 2 1 (t 1266) =
    c8 2 2 0 [q 700, q 1003] := by
  exact (embeddingPositionUnitFacts_1266_1 s p t q hs hp h).2.2
#print axioms embeddingPositionUnit_1266_1
end RBS_9
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent-owned imports, integration, cost cap and kernel check required.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem addRead_sm_1267 (s t : Store) (h : c11 s = some t) :
    t 1267 = elemwiseAdd (t 1265) (t 1266) := by
  apply vP3 (c18 3) (c10 4) smNode_3
    0 1265 1266 1267 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 3 ++ c10 3 := (c4 3 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 3, 1265 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 3, 1266 ∉ row.1.outs
    decide
#print axioms addRead_sm_1267
section RBS_10
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem addRead_pm_95 :
    t 95 = elemwiseAdd (t 89) (t 94) := by
  apply vP4 (c1 9) (c0 10) pmNode_5
    0 89 94 95 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 9 ++ c0 9 := (c4 9 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 9, 89 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 9, 94 ∉ row.1.outs
    decide
#print axioms addRead_pm_95
theorem addRead_pm_398 :
    t 398 = elemwiseAdd (t 392) (t 397) := by
  apply vP4 (c1 12) (c0 13) pmNode_241
    1 392 397 398 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 12 ++ c0 12 := (c4 12 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 12, 392 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 12, 397 ∉ row.1.outs
    decide
#print axioms addRead_pm_398
end RBS_10
section RBS_11
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p)
include s p t q hs hp h
theorem addUnitFacts_1267_0 :
    (t 1267).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 95, q 398], x.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1267) =
    c8 2 2 0 [q 95, q 398] := by
  have a := embeddingUnitFacts_1265_0 s p t q hs hp h
  have b := embeddingPositionUnitFacts_1266_0 s p t q hs hp h
  have localAdds : [q 95, q 398] = List.zipWith elemwiseAdd [q 89, q 392] [q 94, q 397] := by
    change [q 95, q 398] = [elemwiseAdd (q 89) (q 94), elemwiseAdd (q 392) (q 397)]
    exact c13 c20 (addRead_pm_95 p q hp) (c13 c20 (addRead_pm_398 p q hp) (rfl))
  exact c22 2 2 1 16 32 0
    (t 1265) (t 1266) (t 1267) [q 89, q 392] [q 94, q 397] [q 95, q 398]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    a.1 b.1 rfl rfl (fun r hr => a.2.1 _ (List.get_mem _ _))
    (fun r hr => b.2.1 _ (List.get_mem _ _)) a.2.2 b.2.2
    (addRead_sm_1267 s t hs) localAdds
#print axioms addUnitFacts_1267_0
theorem addUnit_1267_0 :
    c3 0 2 0 (t 1267) =
    c8 2 2 0 [q 95, q 398] :=
  (addUnitFacts_1267_0 s p t q hs hp h).2.2
#print axioms addUnit_1267_0
end RBS_11
section RBS_12
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem addRead_pm_701 :
    t 701 = elemwiseAdd (t 695) (t 700) := by
  apply vP4 (c1 431) (c0 432) pmNode_477
    2 695 700 701 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 431 ++ c0 431 := (c4 431 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 431, 695 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 431, 700 ∉ row.1.outs
    decide
#print axioms addRead_pm_701
theorem addRead_pm_1004 :
    t 1004 = elemwiseAdd (t 998) (t 1003) := by
  apply vP4 (c1 434) (c0 435) pmNode_713
    3 998 1003 1004 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 434 ++ c0 434 := (c4 434 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 434, 998 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 434, 1003 ∉ row.1.outs
    decide
#print axioms addRead_pm_1004
end RBS_12
section RBS_13
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p)
include s p t q hs hp h
theorem addUnitFacts_1267_1 :
    (t 1267).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 701, q 1004], x.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1267) =
    c8 2 2 0 [q 701, q 1004] := by
  have a := embeddingUnitFacts_1265_1 s p t q hs hp h
  have b := embeddingPositionUnitFacts_1266_1 s p t q hs hp h
  have localAdds : [q 701, q 1004] = List.zipWith elemwiseAdd [q 695, q 998] [q 700, q 1003] := by
    change [q 701, q 1004] = [elemwiseAdd (q 695) (q 700), elemwiseAdd (q 998) (q 1003)]
    exact c13 c20 (addRead_pm_701 p q hp) (c13 c20 (addRead_pm_1004 p q hp) (rfl))
  exact c22 2 2 1 16 32 1
    (t 1265) (t 1266) (t 1267) [q 695, q 998] [q 700, q 1003] [q 701, q 1004]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    a.1 b.1 rfl rfl (fun r hr => a.2.1 _ (List.get_mem _ _))
    (fun r hr => b.2.1 _ (List.get_mem _ _)) a.2.2 b.2.2
    (addRead_sm_1267 s t hs) localAdds
#print axioms addUnitFacts_1267_1
theorem addUnit_1267_1 :
    c3 0 2 1 (t 1267) =
    c8 2 2 0 [q 701, q 1004] :=
  (addUnitFacts_1267_1 s p t q hs hp h).2.2
#print axioms addUnit_1267_1
end RBS_13
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent imports/integration/cost/kernel verification required.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem postAddMultirefRead_sm_1376 (s t : Store) (h : c11 s = some t) :
    ∀ output ∈ ([1376, 1377] : List Tid), t output = t 1267 := by
  intro output houtput
  apply vP7 (c18 4) (c10 5) smNode_4
    0 1267 [1376, 1377] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c9 = c18 4 ++ c10 4 := (c4 4 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 4, 1267 ∉ row.1.outs
    decide
#print axioms postAddMultirefRead_sm_1376
section RBS_14
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem postAddMultirefRead_pm_283 :
    ∀ output ∈ ([283, 163] : List Tid), t output = t 95 := by
  intro output houtput
  apply vP8 (c1 10) (c0 11) pmNode_6
    0 95 [283, 163] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 10 ++ c0 10 := (c4 10 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 10, 95 ∉ row.1.outs
    decide
#print axioms postAddMultirefRead_pm_283
theorem postAddMultirefRead_pm_586 :
    ∀ output ∈ ([586, 466] : List Tid), t output = t 398 := by
  intro output houtput
  apply vP8 (c1 13) (c0 14) pmNode_242
    1 398 [586, 466] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 13 ++ c0 13 := (c4 13 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 13, 398 ∉ row.1.outs
    decide
#print axioms postAddMultirefRead_pm_586
theorem postAddAllToAllRead_pm_98 :
    t 98 = c5 2 0 2 1 (([283, 586] : List Tid).map t) := by
  apply vP6 (c1 14) (c0 15) pmNode_7 0 [0, 1] [283, 586] 98 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 14 ++ c0 14 := (c4 14 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([283, 586] : List Tid), ∀ row ∈ c0 14, tid ∉ row.1.outs
    decide
#print axioms postAddAllToAllRead_pm_98
theorem postAddAllToAllRead_pm_401 :
    t 401 = c5 2 1 2 1 (([283, 586] : List Tid).map t) := by
  apply vP6 (c1 18) (c0 19) pmNode_243 1 [0, 1] [283, 586] 401 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 18 ++ c0 18 := (c4 18 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([283, 586] : List Tid), ∀ row ∈ c0 18, tid ∉ row.1.outs
    decide
#print axioms postAddAllToAllRead_pm_401
end RBS_14
section RBS_15
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p)
include s p t q hs hp h
theorem postAddAliasUnit_1376_0_slot0 :
    c3 0 2 0 (t 1376) =
    c8 2 2 0 [q 283, q 586] := by
  rw [postAddMultirefRead_sm_1376 s t hs 1376 c6, postAddMultirefRead_pm_283 p q hp 283 c6, postAddMultirefRead_pm_586 p q hp 586 c6]
  exact addUnit_1267_0 s p t q hs hp h
#print axioms postAddAliasUnit_1376_0_slot0
theorem postAddAliasUnit_1377_0_slot1 :
    c3 0 2 0 (t 1377) =
    c8 2 2 0 [q 163, q 466] := by
  rw [postAddMultirefRead_sm_1376 s t hs 1377 (c12 _ c6), postAddMultirefRead_pm_283 p q hp 163 (c12 _ c6), postAddMultirefRead_pm_586 p q hp 466 (c12 _ c6)]
  exact addUnit_1267_0 s p t q hs hp h
#print axioms postAddAliasUnit_1377_0_slot1
theorem postAddExchangeFacts_1376_0 :
    (t 1376).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 98, q 401], x.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1376) = c8 1 2 0 [q 98, q 401] := by
  have af := addUnitFacts_1267_0 s p t q hs hp h
  have hx : ∀ x ∈ [q 283, q 586], x.shape = [1, 16, 32] := by
    intro x hx
    simp only [List.mem_cons, c19, or_false] at hx
    rcases hx with rfl | rfl
    · exact (congrArg Tensor.shape (postAddMultirefRead_pm_283 p q hp 283 c6)).trans
        (af.2.1 (q 95) c6)
    · exact (congrArg Tensor.shape (postAddMultirefRead_pm_586 p q hp 586 c6)).trans
        (af.2.1 (q 398) (c12 _ c6))
  have hy : [q 98, q 401] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 283, q 586]) := by
    change [q 98, q 401] = [c5 2 0 2 1 [q 283, q 586], c5 2 1 2 1 [q 283, q 586]]
    exact c13 c20 (postAddAllToAllRead_pm_98 p q hp) (c13 c20 (postAddAllToAllRead_pm_401 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 0 2 1 8 32 (t 1376) [q 283, q 586] [q 98, q 401]
    (by decide) (by decide) (by decide) (by decide) rfl hx
    ((congrArg Tensor.shape (postAddMultirefRead_sm_1376 s t hs 1376 c6)).trans af.1)
    (postAddAliasUnit_1376_0_slot0 s p t q hs hp h) hy
#print axioms postAddExchangeFacts_1376_0
end RBS_15
section RBS_16
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem postAddMultirefRead_pm_889 :
    ∀ output ∈ ([889, 769] : List Tid), t output = t 701 := by
  intro output houtput
  apply vP8 (c1 432) (c0 433) pmNode_478
    2 701 [889, 769] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 432 ++ c0 432 := (c4 432 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 432, 701 ∉ row.1.outs
    decide
#print axioms postAddMultirefRead_pm_889
theorem postAddMultirefRead_pm_1192 :
    ∀ output ∈ ([1192, 1072] : List Tid), t output = t 1004 := by
  intro output houtput
  apply vP8 (c1 435) (c0 436) pmNode_714
    3 1004 [1192, 1072] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 435 ++ c0 435 := (c4 435 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 435, 1004 ∉ row.1.outs
    decide
#print axioms postAddMultirefRead_pm_1192
theorem postAddAllToAllRead_pm_704 :
    t 704 = c5 2 0 2 1 (([889, 1192] : List Tid).map t) := by
  apply vP6 (c1 436) (c0 437) pmNode_479 2 [2, 3] [889, 1192] 704 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 436 ++ c0 436 := (c4 436 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([889, 1192] : List Tid), ∀ row ∈ c0 436, tid ∉ row.1.outs
    decide
#print axioms postAddAllToAllRead_pm_704
theorem postAddAllToAllRead_pm_1007 :
    t 1007 = c5 2 1 2 1 (([889, 1192] : List Tid).map t) := by
  apply vP6 (c1 440) (c0 441) pmNode_715 3 [2, 3] [889, 1192] 1007 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 440 ++ c0 440 := (c4 440 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([889, 1192] : List Tid), ∀ row ∈ c0 440, tid ∉ row.1.outs
    decide
#print axioms postAddAllToAllRead_pm_1007
end RBS_16
section RBS_17
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p)
include s p t q hs hp h
theorem postAddAliasUnit_1376_1_slot0 :
    c3 0 2 1 (t 1376) =
    c8 2 2 0 [q 889, q 1192] := by
  rw [postAddMultirefRead_sm_1376 s t hs 1376 c6, postAddMultirefRead_pm_889 p q hp 889 c6, postAddMultirefRead_pm_1192 p q hp 1192 c6]
  exact addUnit_1267_1 s p t q hs hp h
#print axioms postAddAliasUnit_1376_1_slot0
theorem postAddAliasUnit_1377_1_slot1 :
    c3 0 2 1 (t 1377) =
    c8 2 2 0 [q 769, q 1072] := by
  rw [postAddMultirefRead_sm_1376 s t hs 1377 (c12 _ c6), postAddMultirefRead_pm_889 p q hp 769 (c12 _ c6), postAddMultirefRead_pm_1192 p q hp 1072 (c12 _ c6)]
  exact addUnit_1267_1 s p t q hs hp h
#print axioms postAddAliasUnit_1377_1_slot1
theorem postAddExchangeFacts_1376_1 :
    (t 1376).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 704, q 1007], x.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1376) = c8 1 2 0 [q 704, q 1007] := by
  have af := addUnitFacts_1267_1 s p t q hs hp h
  have hx : ∀ x ∈ [q 889, q 1192], x.shape = [1, 16, 32] := by
    intro x hx
    simp only [List.mem_cons, c19, or_false] at hx
    rcases hx with rfl | rfl
    · exact (congrArg Tensor.shape (postAddMultirefRead_pm_889 p q hp 889 c6)).trans
        (af.2.1 (q 701) c6)
    · exact (congrArg Tensor.shape (postAddMultirefRead_pm_1192 p q hp 1192 c6)).trans
        (af.2.1 (q 1004) (c12 _ c6))
  have hy : [q 704, q 1007] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 889, q 1192]) := by
    change [q 704, q 1007] = [c5 2 0 2 1 [q 889, q 1192], c5 2 1 2 1 [q 889, q 1192]]
    exact c13 c20 (postAddAllToAllRead_pm_704 p q hp) (c13 c20 (postAddAllToAllRead_pm_1007 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 1 2 1 8 32 (t 1376) [q 889, q 1192] [q 704, q 1007]
    (by decide) (by decide) (by decide) (by decide) rfl hx
    ((congrArg Tensor.shape (postAddMultirefRead_sm_1376 s t hs 1376 c6)).trans af.1)
    (postAddAliasUnit_1376_1_slot0 s p t q hs hp h) hy
#print axioms postAddExchangeFacts_1376_1
end RBS_17
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, predecessors, aggregate cost and kernel verification.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem layernormRead_sm_1268 (s t : Store) (h : c11 s = some t) :
    t 1268 = c17 (t 1376) (t 1214) (t 1215) := by
  apply vP10 (c18 5) (c10 6) smNode_5
    0 1376 1214 1215 1268 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c9 = c18 5 ++ c10 5 := (c4 5 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 5, 1376 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 5, 1214 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 5, 1215 ∉ row.1.outs
    decide
#print axioms layernormRead_sm_1268
section RBS_18
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem layernormRead_pm_99 :
    t 99 = c17 (t 98) (t 1) (t 2) := by
  apply vP11 (c1 15) (c0 16) pmNode_8
    0 98 1 2 99 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 15 ++ c0 15 := (c4 15 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 15, 98 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 15, 1 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 15, 2 ∉ row.1.outs
    decide
#print axioms layernormRead_pm_99
theorem layernormRead_pm_402 :
    t 402 = c17 (t 401) (t 304) (t 305) := by
  apply vP11 (c1 19) (c0 20) pmNode_244
    1 401 304 305 402 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 19 ++ c0 19 := (c4 19 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 19, 401 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 19, 304 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 19, 305 ∉ row.1.outs
    decide
#print axioms layernormRead_pm_402
end RBS_18
theorem layernormUnitFacts_1268_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1268).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 99, q 402], y.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1268) = c8 1 2 0 [q 99, q 402] := by
  have predecessor := postAddExchangeFacts_1376_0 s p t q hs hp h
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have gammaRel : c16 (t 1214) [q 1, q 304] [64] := hrels.2.2.2.2.1
  have betaRel : c16 (t 1215) [q 2, q 305] [64] := hrels.2.2.2.2.2.2.1
  have local0 : q 99 = c17 (q 98) (t 1214) (t 1215) :=
    (layernormRead_pm_99 p q hp).trans
      (c13 (fun g b => c17 (q 98) g b)
        (gammaRel.replica_values (q 1) c6)
        (betaRel.replica_values (q 2) c6))
  have local1 : q 402 = c17 (q 401) (t 1214) (t 1215) :=
    (layernormRead_pm_402 p q hp).trans
      (c13 (fun g b => c17 (q 401) g b)
        (gammaRel.replica_values (q 304) (c12 _ c6))
        (betaRel.replica_values (q 305) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = c17 x (t 1214) (t 1215)) [q 98, q 401] [q 99, q 402] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_layernorm_unit_output_reconstruct 2 2 1 8 64 0
    (t 1376) (t 1214) (t 1215) (t 1268) [q 98, q 401] [q 99, q 402]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 gammaRel.full_shape betaRel.full_shape predecessor.2.2
    (layernormRead_sm_1268 s t hs) localReads
#print axioms layernormUnitFacts_1268_0
section RBS_19
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem layernormRead_pm_705 :
    t 705 = c17 (t 704) (t 607) (t 608) := by
  apply vP11 (c1 437) (c0 438) pmNode_480
    2 704 607 608 705 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 437 ++ c0 437 := (c4 437 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 437, 704 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 437, 607 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 437, 608 ∉ row.1.outs
    decide
#print axioms layernormRead_pm_705
theorem layernormRead_pm_1008 :
    t 1008 = c17 (t 1007) (t 910) (t 911) := by
  apply vP11 (c1 441) (c0 442) pmNode_716
    3 1007 910 911 1008 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 441 ++ c0 441 := (c4 441 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 441, 1007 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 441, 910 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 441, 911 ∉ row.1.outs
    decide
#print axioms layernormRead_pm_1008
end RBS_19
theorem layernormUnitFacts_1268_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1268).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 705, q 1008], y.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1268) = c8 1 2 0 [q 705, q 1008] := by
  have predecessor := postAddExchangeFacts_1376_1 s p t q hs hp h
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have gammaRel : c16 (t 1214) [q 607, q 910] [64] := hrels.2.2.2.2.2.1
  have betaRel : c16 (t 1215) [q 608, q 911] [64] := hrels.2.2.2.2.2.2.2.1
  have local0 : q 705 = c17 (q 704) (t 1214) (t 1215) :=
    (layernormRead_pm_705 p q hp).trans
      (c13 (fun g b => c17 (q 704) g b)
        (gammaRel.replica_values (q 607) c6)
        (betaRel.replica_values (q 608) c6))
  have local1 : q 1008 = c17 (q 1007) (t 1214) (t 1215) :=
    (layernormRead_pm_1008 p q hp).trans
      (c13 (fun g b => c17 (q 1007) g b)
        (gammaRel.replica_values (q 910) (c12 _ c6))
        (betaRel.replica_values (q 911) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = c17 x (t 1214) (t 1215)) [q 704, q 1007] [q 705, q 1008] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_layernorm_unit_output_reconstruct 2 2 1 8 64 1
    (t 1376) (t 1214) (t 1215) (t 1268) [q 704, q 1007] [q 705, q 1008]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 gammaRel.full_shape betaRel.full_shape predecessor.2.2
    (layernormRead_sm_1268 s t hs) localReads
#print axioms layernormUnitFacts_1268_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, fresh predecessors, frame, aggregate cost and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem projectionMultirefRead_sm_1380 (s t : Store) (h : c11 s = some t) :
    ∀ output ∈ ([1380, 1381, 1382] : List Tid), t output = t 1268 := by
  intro output houtput
  apply vP7 (c18 6) (c10 7) smNode_6
    0 1268 [1380, 1381, 1382] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c9 = c18 6 ++ c10 6 := (c4 6 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 6, 1268 ∉ row.1.outs
    decide
#print axioms projectionMultirefRead_sm_1380
section RBS_20
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionMultirefRead_pm_102 :
    ∀ output ∈ ([102, 285, 287] : List Tid), t output = t 99 := by
  intro output houtput
  apply vP8 (c1 16) (c0 17) pmNode_9
    0 99 [102, 285, 287] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 16 ++ c0 16 := (c4 16 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 16, 99 ∉ row.1.outs
    decide
#print axioms projectionMultirefRead_pm_102
theorem projectionMultirefRead_pm_405 :
    ∀ output ∈ ([405, 588, 590] : List Tid), t output = t 402 := by
  intro output houtput
  apply vP8 (c1 20) (c0 21) pmNode_245
    1 402 [405, 588, 590] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 20 ++ c0 20 := (c4 20 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 20, 402 ∉ row.1.outs
    decide
#print axioms projectionMultirefRead_pm_405
end RBS_20
theorem projectionLinearRead_sm_1269 (s t : Store) (h : c11 s = some t) :
    t 1269 = fw_linear (t 1380) (t 1216) := by
  apply vP16 (c18 7) (c10 8) smNode_7
    0 1380 1216 1269 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 7 ++ c10 7 := (c4 7 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 7, 1380 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 7, 1216 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_sm_1269
section RBS_21
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionLinearRead_pm_103 :
    t 103 = fw_linear (t 102) (t 3) := by
  apply vP17 (c1 17) (c0 18) pmNode_10
    0 102 3 103 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 17 ++ c0 17 := (c4 17 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 17, 102 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 17, 3 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_103
theorem projectionLinearRead_pm_406 :
    t 406 = fw_linear (t 405) (t 306) := by
  apply vP17 (c1 26) (c0 27) pmNode_246
    1 405 306 406 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 26 ++ c0 26 := (c4 26 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 26, 405 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 26, 306 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_406
end RBS_21
theorem projectionLinearUnitFacts_1269_0_slot0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1269).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 103, q 406], y.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1269) = c8 1 2 0 [q 103, q 406] := by
  have predecessor := layernormUnitFacts_1268_0 s p t q hs hp h
  have globalAlias := projectionMultirefRead_sm_1380 s t hs 1380 c6
  have alias0 := projectionMultirefRead_pm_102 p q hp 102 c6
  have alias1 := projectionMultirefRead_pm_405 p q hp 405 c6
  have fullShape : (t 1380).shape = [2, 16, 64] :=
    (congrArg Tensor.shape globalAlias).trans predecessor.1
  have inputShapes : ∀ x ∈ [q 102, q 405], x.shape = [1, 8, 64] := by
    intro x hx
    simp only [List.mem_cons, c19, or_false] at hx
    rcases hx with rfl | rfl
    · exact (congrArg Tensor.shape alias0).trans
        (predecessor.2.1 (q 99) c6)
    · exact (congrArg Tensor.shape alias1).trans
        (predecessor.2.1 (q 402) (c12 _ c6))
  have inputValue : c3 0 2 0 (t 1380) = c8 1 2 0 [q 102, q 405] := by
    rw [globalAlias, alias0, alias1]
    exact predecessor.2.2
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have weightRel : c16 (t 1216) [q 3, q 306] [64, 64] := hrels.2.2.2.2.2.2.2.2.1
  have local0 : q 103 = fw_linear (q 102) (t 1216) :=
    (projectionLinearRead_pm_103 p q hp).trans (congrArg (fw_linear (q 102))
      (weightRel.replica_values (q 3) c6))
  have local1 : q 406 = fw_linear (q 405) (t 1216) :=
    (projectionLinearRead_pm_406 p q hp).trans (congrArg (fw_linear (q 405))
      (weightRel.replica_values (q 306) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = fw_linear x (t 1216)) [q 102, q 405] [q 103, q 406] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_sequence_unit_output_reconstruct 2 2 1 8 64 64 0
    (t 1380) (t 1216) (t 1269) [q 102, q 405] [q 103, q 406]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    fullShape rfl inputShapes weightRel.full_shape inputValue
    (projectionLinearRead_sm_1269 s t hs) localReads
#print axioms projectionLinearUnitFacts_1269_0_slot0
section RBS_22
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionAllGatherRead_pm_86 :
    t 86 = c8 1 2 0 [t 285, t 588] := by
  apply vP9 (c1 21) (c0 22) pmNode_11
    0 [0, 1] [285, 588] 86 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 21 ++ c0 21 := (c4 21 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([285, 588] : List Tid), ∀ row ∈ c0 21, tid ∉ row.1.outs
    decide
#print axioms projectionAllGatherRead_pm_86
theorem projectionAllGatherRead_pm_389 :
    t 389 = c8 1 2 1 [t 285, t 588] := by
  apply vP9 (c1 27) (c0 28) pmNode_247
    1 [0, 1] [285, 588] 389 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 27 ++ c0 27 := (c4 27 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([285, 588] : List Tid), ∀ row ∈ c0 27, tid ∉ row.1.outs
    decide
#print axioms projectionAllGatherRead_pm_389
end RBS_22
theorem projectionLinearRead_sm_1270 (s t : Store) (h : c11 s = some t) :
    t 1270 = fw_linear (t 1381) (t 1217) := by
  apply vP16 (c18 8) (c10 9) smNode_8
    0 1381 1217 1270 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 8 ++ c10 8 := (c4 8 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 8, 1381 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 8, 1217 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_sm_1270
section RBS_23
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionLinearRead_pm_106 :
    t 106 = fw_linear (t 86) (t 27) := by
  apply vP17 (c1 22) (c0 23) pmNode_12
    0 86 27 106 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 22 ++ c0 22 := (c4 22 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 22, 86 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 22, 27 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_106
theorem projectionLinearRead_pm_409 :
    t 409 = fw_linear (t 389) (t 330) := by
  apply vP17 (c1 28) (c0 29) pmNode_248
    1 389 330 409 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 28 ++ c0 28 := (c4 28 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 28, 389 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 28, 330 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_409
end RBS_23
theorem projectionLinearUnitFacts_1270_0_slot1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1270).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 106, q 409], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1270) = c8 2 2 0 [q 106, q 409] := by
  have predecessor := layernormUnitFacts_1268_0 s p t q hs hp h
  have globalAlias := projectionMultirefRead_sm_1380 s t hs 1381 (c12 _ c6)
  have alias0 := projectionMultirefRead_pm_102 p q hp 285 (c12 _ c6)
  have alias1 := projectionMultirefRead_pm_405 p q hp 588 (c12 _ c6)
  have fullShape : (t 1381).shape = [2, 16, 64] :=
    (congrArg Tensor.shape globalAlias).trans predecessor.1
  have inputShapes : ∀ x ∈ [q 285, q 588], x.shape = [1, 8, 64] := by
    intro x hx
    simp only [List.mem_cons, c19, or_false] at hx
    rcases hx with rfl | rfl
    · exact (congrArg Tensor.shape alias0).trans
        (predecessor.2.1 (q 99) c6)
    · exact (congrArg Tensor.shape alias1).trans
        (predecessor.2.1 (q 402) (c12 _ c6))
  have inputValue : c3 0 2 0 (t 1381) = c8 1 2 0 [q 285, q 588] := by
    rw [globalAlias, alias0, alias1]
    exact predecessor.2.2
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have weightRel : RelationCompiler.ShardedRel (t 1217) [q 27, q 330] 0 [64, 64] [32, 64] := hrels.2.2.2.2.2.2.2.2.2.2.1
  have gathered0 : q 86 = (c3 0 2 0 (t 1381)) :=
    (projectionAllGatherRead_pm_86 p q hp).trans inputValue.symm
  have local0 : q 106 = fw_linear (c3 0 2 0 (t 1381)) (q 27) := by
    rw [projectionLinearRead_pm_106 p q hp, gathered0]
  have gathered1 : q 389 = (c3 0 2 0 (t 1381)) :=
    (projectionAllGatherRead_pm_389 p q hp).trans inputValue.symm
  have local1 : q 409 = fw_linear (c3 0 2 0 (t 1381)) (q 330) := by
    rw [projectionLinearRead_pm_409 p q hp, gathered1]
  have localReads : List.Forall₂ (fun w y => y = fw_linear (c3 0 2 0 (t 1381)) w) [q 27, q 330] [q 106, q 409] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_weight_unit_output_reconstruct 2 2 1 16 64 32 0
    (t 1381) (c3 0 2 0 (t 1381)) (t 1217) (t 1270) [q 27, q 330] [q 106, q 409]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    fullShape rfl weightRel.shard_shapes rfl weightRel.full_value
    (projectionLinearRead_sm_1270 s t hs) localReads
#print axioms projectionLinearUnitFacts_1270_0_slot1
section RBS_24
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionAllGatherRead_pm_87 :
    t 87 = c8 1 2 0 [t 287, t 590] := by
  apply vP9 (c1 23) (c0 24) pmNode_13
    0 [0, 1] [287, 590] 87 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 23 ++ c0 23 := (c4 23 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([287, 590] : List Tid), ∀ row ∈ c0 23, tid ∉ row.1.outs
    decide
#print axioms projectionAllGatherRead_pm_87
theorem projectionAllGatherRead_pm_390 :
    t 390 = c8 1 2 1 [t 287, t 590] := by
  apply vP9 (c1 29) (c0 30) pmNode_249
    1 [0, 1] [287, 590] 390 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 29 ++ c0 29 := (c4 29 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([287, 590] : List Tid), ∀ row ∈ c0 29, tid ∉ row.1.outs
    decide
#print axioms projectionAllGatherRead_pm_390
end RBS_24
theorem projectionLinearRead_sm_1271 (s t : Store) (h : c11 s = some t) :
    t 1271 = fw_linear (t 1382) (t 1218) := by
  apply vP16 (c18 9) (c10 10) smNode_9
    0 1382 1218 1271 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 9 ++ c10 9 := (c4 9 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 9, 1382 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 9, 1218 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_sm_1271
section RBS_25
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionLinearRead_pm_109 :
    t 109 = fw_linear (t 87) (t 30) := by
  apply vP17 (c1 24) (c0 25) pmNode_14
    0 87 30 109 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 24 ++ c0 24 := (c4 24 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 24, 87 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 24, 30 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_109
theorem projectionLinearRead_pm_412 :
    t 412 = fw_linear (t 390) (t 333) := by
  apply vP17 (c1 30) (c0 31) pmNode_250
    1 390 333 412 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 30 ++ c0 30 := (c4 30 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 30, 390 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 30, 333 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_412
end RBS_25
theorem projectionLinearUnitFacts_1271_0_slot2 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1271).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 109, q 412], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1271) = c8 2 2 0 [q 109, q 412] := by
  have predecessor := layernormUnitFacts_1268_0 s p t q hs hp h
  have globalAlias := projectionMultirefRead_sm_1380 s t hs 1382 (c12 _ (c12 _ c6))
  have alias0 := projectionMultirefRead_pm_102 p q hp 287 (c12 _ (c12 _ c6))
  have alias1 := projectionMultirefRead_pm_405 p q hp 590 (c12 _ (c12 _ c6))
  have fullShape : (t 1382).shape = [2, 16, 64] :=
    (congrArg Tensor.shape globalAlias).trans predecessor.1
  have inputShapes : ∀ x ∈ [q 287, q 590], x.shape = [1, 8, 64] := by
    intro x hx
    simp only [List.mem_cons, c19, or_false] at hx
    rcases hx with rfl | rfl
    · exact (congrArg Tensor.shape alias0).trans
        (predecessor.2.1 (q 99) c6)
    · exact (congrArg Tensor.shape alias1).trans
        (predecessor.2.1 (q 402) (c12 _ c6))
  have inputValue : c3 0 2 0 (t 1382) = c8 1 2 0 [q 287, q 590] := by
    rw [globalAlias, alias0, alias1]
    exact predecessor.2.2
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have weightRel : RelationCompiler.ShardedRel (t 1218) [q 30, q 333] 0 [64, 64] [32, 64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.1
  have gathered0 : q 87 = (c3 0 2 0 (t 1382)) :=
    (projectionAllGatherRead_pm_87 p q hp).trans inputValue.symm
  have local0 : q 109 = fw_linear (c3 0 2 0 (t 1382)) (q 30) := by
    rw [projectionLinearRead_pm_109 p q hp, gathered0]
  have gathered1 : q 390 = (c3 0 2 0 (t 1382)) :=
    (projectionAllGatherRead_pm_390 p q hp).trans inputValue.symm
  have local1 : q 412 = fw_linear (c3 0 2 0 (t 1382)) (q 333) := by
    rw [projectionLinearRead_pm_412 p q hp, gathered1]
  have localReads : List.Forall₂ (fun w y => y = fw_linear (c3 0 2 0 (t 1382)) w) [q 30, q 333] [q 109, q 412] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_weight_unit_output_reconstruct 2 2 1 16 64 32 0
    (t 1382) (c3 0 2 0 (t 1382)) (t 1218) (t 1271) [q 30, q 333] [q 109, q 412]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    fullShape rfl weightRel.shard_shapes rfl weightRel.full_value
    (projectionLinearRead_sm_1271 s t hs) localReads
#print axioms projectionLinearUnitFacts_1271_0_slot2
section RBS_26
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionMultirefRead_pm_708 :
    ∀ output ∈ ([708, 891, 893] : List Tid), t output = t 705 := by
  intro output houtput
  apply vP8 (c1 438) (c0 439) pmNode_481
    2 705 [708, 891, 893] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 438 ++ c0 438 := (c4 438 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 438, 705 ∉ row.1.outs
    decide
#print axioms projectionMultirefRead_pm_708
theorem projectionMultirefRead_pm_1011 :
    ∀ output ∈ ([1011, 1194, 1196] : List Tid), t output = t 1008 := by
  intro output houtput
  apply vP8 (c1 442) (c0 443) pmNode_717
    3 1008 [1011, 1194, 1196] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 442 ++ c0 442 := (c4 442 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 442, 1008 ∉ row.1.outs
    decide
#print axioms projectionMultirefRead_pm_1011
theorem projectionLinearRead_pm_709 :
    t 709 = fw_linear (t 708) (t 609) := by
  apply vP17 (c1 439) (c0 440) pmNode_482
    2 708 609 709 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 439 ++ c0 439 := (c4 439 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 439, 708 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 439, 609 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_709
theorem projectionLinearRead_pm_1012 :
    t 1012 = fw_linear (t 1011) (t 912) := by
  apply vP17 (c1 448) (c0 449) pmNode_718
    3 1011 912 1012 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 448 ++ c0 448 := (c4 448 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 448, 1011 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 448, 912 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_1012
end RBS_26
theorem projectionLinearUnitFacts_1269_1_slot0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1269).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 709, q 1012], y.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1269) = c8 1 2 0 [q 709, q 1012] := by
  have predecessor := layernormUnitFacts_1268_1 s p t q hs hp h
  have globalAlias := projectionMultirefRead_sm_1380 s t hs 1380 c6
  have alias0 := projectionMultirefRead_pm_708 p q hp 708 c6
  have alias1 := projectionMultirefRead_pm_1011 p q hp 1011 c6
  have fullShape : (t 1380).shape = [2, 16, 64] :=
    (congrArg Tensor.shape globalAlias).trans predecessor.1
  have inputShapes : ∀ x ∈ [q 708, q 1011], x.shape = [1, 8, 64] := by
    intro x hx
    simp only [List.mem_cons, c19, or_false] at hx
    rcases hx with rfl | rfl
    · exact (congrArg Tensor.shape alias0).trans
        (predecessor.2.1 (q 705) c6)
    · exact (congrArg Tensor.shape alias1).trans
        (predecessor.2.1 (q 1008) (c12 _ c6))
  have inputValue : c3 0 2 1 (t 1380) = c8 1 2 0 [q 708, q 1011] := by
    rw [globalAlias, alias0, alias1]
    exact predecessor.2.2
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have weightRel : c16 (t 1216) [q 609, q 912] [64, 64] := hrels.2.2.2.2.2.2.2.2.2.1
  have local0 : q 709 = fw_linear (q 708) (t 1216) :=
    (projectionLinearRead_pm_709 p q hp).trans (congrArg (fw_linear (q 708))
      (weightRel.replica_values (q 609) c6))
  have local1 : q 1012 = fw_linear (q 1011) (t 1216) :=
    (projectionLinearRead_pm_1012 p q hp).trans (congrArg (fw_linear (q 1011))
      (weightRel.replica_values (q 912) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = fw_linear x (t 1216)) [q 708, q 1011] [q 709, q 1012] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_sequence_unit_output_reconstruct 2 2 1 8 64 64 1
    (t 1380) (t 1216) (t 1269) [q 708, q 1011] [q 709, q 1012]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    fullShape rfl inputShapes weightRel.full_shape inputValue
    (projectionLinearRead_sm_1269 s t hs) localReads
#print axioms projectionLinearUnitFacts_1269_1_slot0
section RBS_27
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionAllGatherRead_pm_692 :
    t 692 = c8 1 2 0 [t 891, t 1194] := by
  apply vP9 (c1 443) (c0 444) pmNode_483
    2 [2, 3] [891, 1194] 692 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 443 ++ c0 443 := (c4 443 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([891, 1194] : List Tid), ∀ row ∈ c0 443, tid ∉ row.1.outs
    decide
#print axioms projectionAllGatherRead_pm_692
theorem projectionAllGatherRead_pm_995 :
    t 995 = c8 1 2 1 [t 891, t 1194] := by
  apply vP9 (c1 449) (c0 450) pmNode_719
    3 [2, 3] [891, 1194] 995 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 449 ++ c0 449 := (c4 449 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([891, 1194] : List Tid), ∀ row ∈ c0 449, tid ∉ row.1.outs
    decide
#print axioms projectionAllGatherRead_pm_995
theorem projectionLinearRead_pm_712 :
    t 712 = fw_linear (t 692) (t 633) := by
  apply vP17 (c1 444) (c0 445) pmNode_484
    2 692 633 712 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 444 ++ c0 444 := (c4 444 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 444, 692 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 444, 633 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_712
theorem projectionLinearRead_pm_1015 :
    t 1015 = fw_linear (t 995) (t 936) := by
  apply vP17 (c1 450) (c0 451) pmNode_720
    3 995 936 1015 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 450 ++ c0 450 := (c4 450 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 450, 995 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 450, 936 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_1015
end RBS_27
theorem projectionLinearUnitFacts_1270_1_slot1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1270).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 712, q 1015], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1270) = c8 2 2 0 [q 712, q 1015] := by
  have predecessor := layernormUnitFacts_1268_1 s p t q hs hp h
  have globalAlias := projectionMultirefRead_sm_1380 s t hs 1381 (c12 _ c6)
  have alias0 := projectionMultirefRead_pm_708 p q hp 891 (c12 _ c6)
  have alias1 := projectionMultirefRead_pm_1011 p q hp 1194 (c12 _ c6)
  have fullShape : (t 1381).shape = [2, 16, 64] :=
    (congrArg Tensor.shape globalAlias).trans predecessor.1
  have inputShapes : ∀ x ∈ [q 891, q 1194], x.shape = [1, 8, 64] := by
    intro x hx
    simp only [List.mem_cons, c19, or_false] at hx
    rcases hx with rfl | rfl
    · exact (congrArg Tensor.shape alias0).trans
        (predecessor.2.1 (q 705) c6)
    · exact (congrArg Tensor.shape alias1).trans
        (predecessor.2.1 (q 1008) (c12 _ c6))
  have inputValue : c3 0 2 1 (t 1381) = c8 1 2 0 [q 891, q 1194] := by
    rw [globalAlias, alias0, alias1]
    exact predecessor.2.2
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have weightRel : RelationCompiler.ShardedRel (t 1217) [q 633, q 936] 0 [64, 64] [32, 64] := hrels.2.2.2.2.2.2.2.2.2.2.2.1
  have gathered0 : q 692 = (c3 0 2 1 (t 1381)) :=
    (projectionAllGatherRead_pm_692 p q hp).trans inputValue.symm
  have local0 : q 712 = fw_linear (c3 0 2 1 (t 1381)) (q 633) := by
    rw [projectionLinearRead_pm_712 p q hp, gathered0]
  have gathered1 : q 995 = (c3 0 2 1 (t 1381)) :=
    (projectionAllGatherRead_pm_995 p q hp).trans inputValue.symm
  have local1 : q 1015 = fw_linear (c3 0 2 1 (t 1381)) (q 936) := by
    rw [projectionLinearRead_pm_1015 p q hp, gathered1]
  have localReads : List.Forall₂ (fun w y => y = fw_linear (c3 0 2 1 (t 1381)) w) [q 633, q 936] [q 712, q 1015] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_weight_unit_output_reconstruct 2 2 1 16 64 32 1
    (t 1381) (c3 0 2 1 (t 1381)) (t 1217) (t 1270) [q 633, q 936] [q 712, q 1015]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    fullShape rfl weightRel.shard_shapes rfl weightRel.full_value
    (projectionLinearRead_sm_1270 s t hs) localReads
#print axioms projectionLinearUnitFacts_1270_1_slot1
section RBS_28
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionAllGatherRead_pm_693 :
    t 693 = c8 1 2 0 [t 893, t 1196] := by
  apply vP9 (c1 445) (c0 446) pmNode_485
    2 [2, 3] [893, 1196] 693 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 445 ++ c0 445 := (c4 445 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([893, 1196] : List Tid), ∀ row ∈ c0 445, tid ∉ row.1.outs
    decide
#print axioms projectionAllGatherRead_pm_693
theorem projectionAllGatherRead_pm_996 :
    t 996 = c8 1 2 1 [t 893, t 1196] := by
  apply vP9 (c1 451) (c0 452) pmNode_721
    3 [2, 3] [893, 1196] 996 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 451 ++ c0 451 := (c4 451 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([893, 1196] : List Tid), ∀ row ∈ c0 451, tid ∉ row.1.outs
    decide
#print axioms projectionAllGatherRead_pm_996
theorem projectionLinearRead_pm_715 :
    t 715 = fw_linear (t 693) (t 636) := by
  apply vP17 (c1 446) (c0 447) pmNode_486
    2 693 636 715 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 446 ++ c0 446 := (c4 446 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 446, 693 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 446, 636 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_715
theorem projectionLinearRead_pm_1018 :
    t 1018 = fw_linear (t 996) (t 939) := by
  apply vP17 (c1 452) (c0 453) pmNode_722
    3 996 939 1018 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 452 ++ c0 452 := (c4 452 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 452, 996 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 452, 939 ∉ row.1.outs
    decide
#print axioms projectionLinearRead_pm_1018
end RBS_28
theorem projectionLinearUnitFacts_1271_1_slot2 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1271).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 715, q 1018], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1271) = c8 2 2 0 [q 715, q 1018] := by
  have predecessor := layernormUnitFacts_1268_1 s p t q hs hp h
  have globalAlias := projectionMultirefRead_sm_1380 s t hs 1382 (c12 _ (c12 _ c6))
  have alias0 := projectionMultirefRead_pm_708 p q hp 893 (c12 _ (c12 _ c6))
  have alias1 := projectionMultirefRead_pm_1011 p q hp 1196 (c12 _ (c12 _ c6))
  have fullShape : (t 1382).shape = [2, 16, 64] :=
    (congrArg Tensor.shape globalAlias).trans predecessor.1
  have inputShapes : ∀ x ∈ [q 893, q 1196], x.shape = [1, 8, 64] := by
    intro x hx
    simp only [List.mem_cons, c19, or_false] at hx
    rcases hx with rfl | rfl
    · exact (congrArg Tensor.shape alias0).trans
        (predecessor.2.1 (q 705) c6)
    · exact (congrArg Tensor.shape alias1).trans
        (predecessor.2.1 (q 1008) (c12 _ c6))
  have inputValue : c3 0 2 1 (t 1382) = c8 1 2 0 [q 893, q 1196] := by
    rw [globalAlias, alias0, alias1]
    exact predecessor.2.2
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have weightRel : RelationCompiler.ShardedRel (t 1218) [q 636, q 939] 0 [64, 64] [32, 64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have gathered0 : q 693 = (c3 0 2 1 (t 1382)) :=
    (projectionAllGatherRead_pm_693 p q hp).trans inputValue.symm
  have local0 : q 715 = fw_linear (c3 0 2 1 (t 1382)) (q 636) := by
    rw [projectionLinearRead_pm_715 p q hp, gathered0]
  have gathered1 : q 996 = (c3 0 2 1 (t 1382)) :=
    (projectionAllGatherRead_pm_996 p q hp).trans inputValue.symm
  have local1 : q 1018 = fw_linear (c3 0 2 1 (t 1382)) (q 939) := by
    rw [projectionLinearRead_pm_1018 p q hp, gathered1]
  have localReads : List.Forall₂ (fun w y => y = fw_linear (c3 0 2 1 (t 1382)) w) [q 636, q 939] [q 715, q 1018] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_weight_unit_output_reconstruct 2 2 1 16 64 32 1
    (t 1382) (c3 0 2 1 (t 1382)) (t 1218) (t 1271) [q 636, q 939] [q 715, q 1018]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    fullShape rfl weightRel.shard_shapes rfl weightRel.full_value
    (projectionLinearRead_sm_1271 s t hs) localReads
#print axioms projectionLinearUnitFacts_1271_1_slot2
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, fresh predecessors, frame, aggregate cost and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem viewRead_sm_1272 (s t : Store) (h : c11 s = some t) :
    t 1272 = fw_view [2, 16, 4, 16] (t 1269) := by
  apply vP14 (c18 10) (c10 11) smNode_10
    0 1269 1272 2 [16, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 10 ++ c10 10 := (c4 10 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 10, 1269 ∉ row.1.outs
    decide
#print axioms viewRead_sm_1272
section RBS_29
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem viewRead_pm_112 :
    t 112 = fw_view [1, 8, 4, 16] (t 103) := by
  apply vP15 (c1 25) (c0 26) pmNode_15
    0 103 112 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 25 ++ c0 25 := (c4 25 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 25, 103 ∉ row.1.outs
    decide
#print axioms viewRead_pm_112
theorem viewRead_pm_415 :
    t 415 = fw_view [1, 8, 4, 16] (t 406) := by
  apply vP15 (c1 31) (c0 32) pmNode_251
    1 406 415 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 31 ++ c0 31 := (c4 31 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 31, 406 ∉ row.1.outs
    decide
#print axioms viewRead_pm_415
end RBS_29
theorem viewUnitFacts_1272_0_slot0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1272).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 112, q 415], y.shape = [1, 8, 4, 16]) ∧
    c3 0 2 0 (t 1272) = c8 1 2 0 [q 112, q 415] := by
  have predecessor := projectionLinearUnitFacts_1269_0_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 8, 4, 16] x) [q 103, q 406] [q 112, q 415] :=
    c15 (viewRead_pm_112 p q hp) (c15 (viewRead_pm_415 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_sequence_unit_output_reconstruct 2 2 1 8 4 16 0
    (t 1269) (t 1272) [q 103, q 406] [q 112, q 415]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (viewRead_sm_1272 s t hs) localReads
#print axioms viewUnitFacts_1272_0_slot0
theorem viewRead_sm_1274 (s t : Store) (h : c11 s = some t) :
    t 1274 = fw_view [2, 16, 4, 16] (t 1270) := by
  apply vP14 (c18 12) (c10 13) smNode_12
    0 1270 1274 2 [16, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 12 ++ c10 12 := (c4 12 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 12, 1270 ∉ row.1.outs
    decide
#print axioms viewRead_sm_1274
section RBS_30
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem viewRead_pm_118 :
    t 118 = fw_view [1, 16, 2, 16] (t 106) := by
  apply vP15 (c1 34) (c0 35) pmNode_18
    0 106 118 1 [16, 2, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 34 ++ c0 34 := (c4 34 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 34, 106 ∉ row.1.outs
    decide
#print axioms viewRead_pm_118
theorem viewRead_pm_421 :
    t 421 = fw_view [1, 16, 2, 16] (t 409) := by
  apply vP15 (c1 37) (c0 38) pmNode_254
    1 409 421 1 [16, 2, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 37 ++ c0 37 := (c4 37 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 37, 409 ∉ row.1.outs
    decide
#print axioms viewRead_pm_421
end RBS_30
theorem viewUnitFacts_1274_0_slot1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1274).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 118, q 421], y.shape = [1, 16, 2, 16]) ∧
    c3 0 2 0 (t 1274) = c8 2 2 0 [q 118, q 421] := by
  have predecessor := projectionLinearUnitFacts_1270_0_slot1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 16, 2, 16] x) [q 106, q 409] [q 118, q 421] :=
    c15 (viewRead_pm_118 p q hp) (c15 (viewRead_pm_421 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_head_unit_output_reconstruct 2 2 1 16 2 16 0
    (t 1270) (t 1274) [q 106, q 409] [q 118, q 421]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (viewRead_sm_1274 s t hs) localReads
#print axioms viewUnitFacts_1274_0_slot1
theorem viewRead_sm_1276 (s t : Store) (h : c11 s = some t) :
    t 1276 = fw_view [2, 16, 4, 16] (t 1271) := by
  apply vP14 (c18 14) (c10 15) smNode_14
    0 1271 1276 2 [16, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 14 ++ c10 14 := (c4 14 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 14, 1271 ∉ row.1.outs
    decide
#print axioms viewRead_sm_1276
section RBS_31
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem viewRead_pm_718 :
    t 718 = fw_view [1, 8, 4, 16] (t 709) := by
  apply vP15 (c1 447) (c0 448) pmNode_487
    2 709 718 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 447 ++ c0 447 := (c4 447 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 447, 709 ∉ row.1.outs
    decide
#print axioms viewRead_pm_718
theorem viewRead_pm_1021 :
    t 1021 = fw_view [1, 8, 4, 16] (t 1012) := by
  apply vP15 (c1 453) (c0 454) pmNode_723
    3 1012 1021 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 453 ++ c0 453 := (c4 453 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 453, 1012 ∉ row.1.outs
    decide
#print axioms viewRead_pm_1021
end RBS_31
theorem viewUnitFacts_1272_1_slot0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1272).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 718, q 1021], y.shape = [1, 8, 4, 16]) ∧
    c3 0 2 1 (t 1272) = c8 1 2 0 [q 718, q 1021] := by
  have predecessor := projectionLinearUnitFacts_1269_1_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 8, 4, 16] x) [q 709, q 1012] [q 718, q 1021] :=
    c15 (viewRead_pm_718 p q hp) (c15 (viewRead_pm_1021 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_sequence_unit_output_reconstruct 2 2 1 8 4 16 1
    (t 1269) (t 1272) [q 709, q 1012] [q 718, q 1021]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (viewRead_sm_1272 s t hs) localReads
#print axioms viewUnitFacts_1272_1_slot0
section RBS_32
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem viewRead_pm_724 :
    t 724 = fw_view [1, 16, 2, 16] (t 712) := by
  apply vP15 (c1 456) (c0 457) pmNode_490
    2 712 724 1 [16, 2, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 456 ++ c0 456 := (c4 456 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 456, 712 ∉ row.1.outs
    decide
#print axioms viewRead_pm_724
theorem viewRead_pm_1027 :
    t 1027 = fw_view [1, 16, 2, 16] (t 1015) := by
  apply vP15 (c1 459) (c0 460) pmNode_726
    3 1015 1027 1 [16, 2, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 459 ++ c0 459 := (c4 459 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 459, 1015 ∉ row.1.outs
    decide
#print axioms viewRead_pm_1027
end RBS_32
theorem viewUnitFacts_1274_1_slot1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1274).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 724, q 1027], y.shape = [1, 16, 2, 16]) ∧
    c3 0 2 1 (t 1274) = c8 2 2 0 [q 724, q 1027] := by
  have predecessor := projectionLinearUnitFacts_1270_1_slot1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 16, 2, 16] x) [q 712, q 1015] [q 724, q 1027] :=
    c15 (viewRead_pm_724 p q hp) (c15 (viewRead_pm_1027 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_head_unit_output_reconstruct 2 2 1 16 2 16 1
    (t 1270) (t 1274) [q 712, q 1015] [q 724, q 1027]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (viewRead_sm_1274 s t hs) localReads
#print axioms viewUnitFacts_1274_1_slot1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, predecessor/frame, full cost and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_33
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionExchangeRead_pm_114 :
    t 114 = c5 2 0 1 3 (([112, 415] : List Tid).map t) := by
  apply vP6 (c1 32) (c0 33) pmNode_16 0 [0, 1] [112, 415] 114 1 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 32 ++ c0 32 := (c4 32 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([112, 415] : List Tid), ∀ row ∈ c0 32, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_114
theorem projectionExchangeRead_pm_417 :
    t 417 = c5 2 1 1 3 (([112, 415] : List Tid).map t) := by
  apply vP6 (c1 35) (c0 36) pmNode_252 1 [0, 1] [112, 415] 417 1 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 35 ++ c0 35 := (c4 35 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([112, 415] : List Tid), ∀ row ∈ c0 35, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_417
end RBS_33
theorem projectionExchangeUnitFacts_1272_0_slot0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1272).shape = [2, 16, 4, 16] ∧
    (∀ x ∈ [q 114, q 417], x.shape = [1, 16, 4, 8]) ∧
    c3 0 2 0 (t 1272) = c8 3 2 0 [q 114, q 417] := by
  have predecessor := viewUnitFacts_1272_0_slot0 s p t q hs hp hvalues
  have outputs : [q 114, q 417] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 3 [q 112, q 415]) := by
    change [q 114, q 417] = [c5 2 0 1 3 [q 112, q 415], c5 2 1 1 3 [q 112, q 415]]
    exact c13 c20 (projectionExchangeRead_pm_114 p q hp) (c13 c20 (projectionExchangeRead_pm_417 p q hp) (rfl))
  exact SourceRank4Exchange.axis1_output_facts 2 0 2 1 8 4 8 (t 1272) [q 112, q 415] [q 114, q 417]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms projectionExchangeUnitFacts_1272_0_slot0
section RBS_34
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionExchangeRead_pm_120 :
    t 120 = c5 2 0 2 3 (([118, 421] : List Tid).map t) := by
  apply vP6 (c1 38) (c0 39) pmNode_19 0 [0, 1] [118, 421] 120 2 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 38 ++ c0 38 := (c4 38 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([118, 421] : List Tid), ∀ row ∈ c0 38, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_120
theorem projectionExchangeRead_pm_423 :
    t 423 = c5 2 1 2 3 (([118, 421] : List Tid).map t) := by
  apply vP6 (c1 45) (c0 46) pmNode_255 1 [0, 1] [118, 421] 423 2 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 45 ++ c0 45 := (c4 45 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([118, 421] : List Tid), ∀ row ∈ c0 45, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_423
end RBS_34
theorem projectionExchangeUnitFacts_1274_0_slot1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1274).shape = [2, 16, 4, 16] ∧
    (∀ x ∈ [q 120, q 423], x.shape = [1, 16, 4, 8]) ∧
    c3 0 2 0 (t 1274) = c8 3 2 0 [q 120, q 423] := by
  have predecessor := viewUnitFacts_1274_0_slot1 s p t q hs hp hvalues
  have outputs : [q 120, q 423] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 3 [q 118, q 421]) := by
    change [q 120, q 423] = [c5 2 0 2 3 [q 118, q 421], c5 2 1 2 3 [q 118, q 421]]
    exact c13 c20 (projectionExchangeRead_pm_120 p q hp) (c13 c20 (projectionExchangeRead_pm_423 p q hp) (rfl))
  exact SourceRank4Exchange.axis2_output_facts 2 0 2 1 16 2 8 (t 1274) [q 118, q 421] [q 120, q 423]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms projectionExchangeUnitFacts_1274_0_slot1
section RBS_35
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionExchangeRead_pm_124 :
    t 124 = c5 2 0 2 1 (([109, 412] : List Tid).map t) := by
  apply vP6 (c1 40) (c0 41) pmNode_21 0 [0, 1] [109, 412] 124 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 40 ++ c0 40 := (c4 40 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([109, 412] : List Tid), ∀ row ∈ c0 40, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_124
theorem projectionExchangeRead_pm_427 :
    t 427 = c5 2 1 2 1 (([109, 412] : List Tid).map t) := by
  apply vP6 (c1 47) (c0 48) pmNode_257 1 [0, 1] [109, 412] 427 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 47 ++ c0 47 := (c4 47 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([109, 412] : List Tid), ∀ row ∈ c0 47, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_427
end RBS_35
theorem projectionExchangeUnitFacts_1271_0_slot2 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1271).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 124, q 427], x.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1271) = c8 1 2 0 [q 124, q 427] := by
  have predecessor := projectionLinearUnitFacts_1271_0_slot2 s p t q hs hp hvalues
  have outputs : [q 124, q 427] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 109, q 412]) := by
    change [q 124, q 427] = [c5 2 0 2 1 [q 109, q 412], c5 2 1 2 1 [q 109, q 412]]
    exact c13 c20 (projectionExchangeRead_pm_124 p q hp) (c13 c20 (projectionExchangeRead_pm_427 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 0 2 1 8 32 (t 1271) [q 109, q 412] [q 124, q 427]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms projectionExchangeUnitFacts_1271_0_slot2
section RBS_36
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionExchangeRead_pm_720 :
    t 720 = c5 2 0 1 3 (([718, 1021] : List Tid).map t) := by
  apply vP6 (c1 454) (c0 455) pmNode_488 2 [2, 3] [718, 1021] 720 1 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 454 ++ c0 454 := (c4 454 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([718, 1021] : List Tid), ∀ row ∈ c0 454, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_720
theorem projectionExchangeRead_pm_1023 :
    t 1023 = c5 2 1 1 3 (([718, 1021] : List Tid).map t) := by
  apply vP6 (c1 457) (c0 458) pmNode_724 3 [2, 3] [718, 1021] 1023 1 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 457 ++ c0 457 := (c4 457 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([718, 1021] : List Tid), ∀ row ∈ c0 457, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_1023
end RBS_36
theorem projectionExchangeUnitFacts_1272_1_slot0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1272).shape = [2, 16, 4, 16] ∧
    (∀ x ∈ [q 720, q 1023], x.shape = [1, 16, 4, 8]) ∧
    c3 0 2 1 (t 1272) = c8 3 2 0 [q 720, q 1023] := by
  have predecessor := viewUnitFacts_1272_1_slot0 s p t q hs hp hvalues
  have outputs : [q 720, q 1023] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 3 [q 718, q 1021]) := by
    change [q 720, q 1023] = [c5 2 0 1 3 [q 718, q 1021], c5 2 1 1 3 [q 718, q 1021]]
    exact c13 c20 (projectionExchangeRead_pm_720 p q hp) (c13 c20 (projectionExchangeRead_pm_1023 p q hp) (rfl))
  exact SourceRank4Exchange.axis1_output_facts 2 1 2 1 8 4 8 (t 1272) [q 718, q 1021] [q 720, q 1023]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms projectionExchangeUnitFacts_1272_1_slot0
section RBS_37
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionExchangeRead_pm_726 :
    t 726 = c5 2 0 2 3 (([724, 1027] : List Tid).map t) := by
  apply vP6 (c1 460) (c0 461) pmNode_491 2 [2, 3] [724, 1027] 726 2 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 460 ++ c0 460 := (c4 460 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([724, 1027] : List Tid), ∀ row ∈ c0 460, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_726
theorem projectionExchangeRead_pm_1029 :
    t 1029 = c5 2 1 2 3 (([724, 1027] : List Tid).map t) := by
  apply vP6 (c1 467) (c0 468) pmNode_727 3 [2, 3] [724, 1027] 1029 2 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 467 ++ c0 467 := (c4 467 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([724, 1027] : List Tid), ∀ row ∈ c0 467, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_1029
end RBS_37
theorem projectionExchangeUnitFacts_1274_1_slot1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1274).shape = [2, 16, 4, 16] ∧
    (∀ x ∈ [q 726, q 1029], x.shape = [1, 16, 4, 8]) ∧
    c3 0 2 1 (t 1274) = c8 3 2 0 [q 726, q 1029] := by
  have predecessor := viewUnitFacts_1274_1_slot1 s p t q hs hp hvalues
  have outputs : [q 726, q 1029] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 3 [q 724, q 1027]) := by
    change [q 726, q 1029] = [c5 2 0 2 3 [q 724, q 1027], c5 2 1 2 3 [q 724, q 1027]]
    exact c13 c20 (projectionExchangeRead_pm_726 p q hp) (c13 c20 (projectionExchangeRead_pm_1029 p q hp) (rfl))
  exact SourceRank4Exchange.axis2_output_facts 2 1 2 1 16 2 8 (t 1274) [q 724, q 1027] [q 726, q 1029]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms projectionExchangeUnitFacts_1274_1_slot1
section RBS_38
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem projectionExchangeRead_pm_730 :
    t 730 = c5 2 0 2 1 (([715, 1018] : List Tid).map t) := by
  apply vP6 (c1 462) (c0 463) pmNode_493 2 [2, 3] [715, 1018] 730 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 462 ++ c0 462 := (c4 462 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([715, 1018] : List Tid), ∀ row ∈ c0 462, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_730
theorem projectionExchangeRead_pm_1033 :
    t 1033 = c5 2 1 2 1 (([715, 1018] : List Tid).map t) := by
  apply vP6 (c1 469) (c0 470) pmNode_729 3 [2, 3] [715, 1018] 1033 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 469 ++ c0 469 := (c4 469 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([715, 1018] : List Tid), ∀ row ∈ c0 469, tid ∉ row.1.outs
    decide
#print axioms projectionExchangeRead_pm_1033
end RBS_38
theorem projectionExchangeUnitFacts_1271_1_slot2 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1271).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 730, q 1033], x.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1271) = c8 1 2 0 [q 730, q 1033] := by
  have predecessor := projectionLinearUnitFacts_1271_1_slot2 s p t q hs hp hvalues
  have outputs : [q 730, q 1033] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 715, q 1018]) := by
    change [q 730, q 1033] = [c5 2 0 2 1 [q 715, q 1018], c5 2 1 2 1 [q 715, q 1018]]
    exact c13 c20 (projectionExchangeRead_pm_730 p q hp) (c13 c20 (projectionExchangeRead_pm_1033 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 1 2 1 8 32 (t 1271) [q 715, q 1018] [q 730, q 1033]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms projectionExchangeUnitFacts_1271_1_slot2
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, predecessors, frame, full cost and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem transposeRead_sm_1273 (s t : Store) (h : c11 s = some t) :
    t 1273 = transposeAxes 1 2 (t 1272) := by
  apply vP12 (c18 11) (c10 12) smNode_11
    0 1272 1273 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 11 ++ c10 11 := (c4 11 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 11, 1272 ∉ row.1.outs
    decide
#print axioms transposeRead_sm_1273
section RBS_39
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem transposeRead_pm_115 :
    t 115 = transposeAxes 1 2 (t 114) := by
  apply vP13 (c1 33) (c0 34) pmNode_17
    0 114 115 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 33 ++ c0 33 := (c4 33 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 33, 114 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_115
theorem transposeRead_pm_418 :
    t 418 = transposeAxes 1 2 (t 417) := by
  apply vP13 (c1 36) (c0 37) pmNode_253
    1 417 418 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 36 ++ c0 36 := (c4 36 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 36, 417 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_418
end RBS_39
theorem transposeUnitFacts_1273_0_slot0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1273).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 115, q 418], y.shape = [1, 4, 16, 8]) ∧
    c3 0 2 0 (t 1273) = c8 3 2 0 [q 115, q 418] := by
  have predecessor := projectionExchangeUnitFacts_1272_0_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 114, q 417] [q 115, q 418] :=
    c15 (transposeRead_pm_115 p q hp) (c15 (transposeRead_pm_418 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_inner_unit_output_reconstruct 2 2 1 16 4 8 0
    (t 1272) (t 1273) [q 114, q 417] [q 115, q 418]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (transposeRead_sm_1273 s t hs) localReads
#print axioms transposeUnitFacts_1273_0_slot0
theorem transposeRead_sm_1275 (s t : Store) (h : c11 s = some t) :
    t 1275 = transposeAxes 1 2 (t 1274) := by
  apply vP12 (c18 13) (c10 14) smNode_13
    0 1274 1275 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 13 ++ c10 13 := (c4 13 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 13, 1274 ∉ row.1.outs
    decide
#print axioms transposeRead_sm_1275
section RBS_40
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem transposeRead_pm_121 :
    t 121 = transposeAxes 1 2 (t 120) := by
  apply vP13 (c1 39) (c0 40) pmNode_20
    0 120 121 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 39 ++ c0 39 := (c4 39 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 39, 120 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_121
theorem transposeRead_pm_424 :
    t 424 = transposeAxes 1 2 (t 423) := by
  apply vP13 (c1 46) (c0 47) pmNode_256
    1 423 424 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 46 ++ c0 46 := (c4 46 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 46, 423 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_424
end RBS_40
theorem transposeUnitFacts_1275_0_slot1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1275).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 121, q 424], y.shape = [1, 4, 16, 8]) ∧
    c3 0 2 0 (t 1275) = c8 3 2 0 [q 121, q 424] := by
  have predecessor := projectionExchangeUnitFacts_1274_0_slot1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 120, q 423] [q 121, q 424] :=
    c15 (transposeRead_pm_121 p q hp) (c15 (transposeRead_pm_424 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_inner_unit_output_reconstruct 2 2 1 16 4 8 0
    (t 1274) (t 1275) [q 120, q 423] [q 121, q 424]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (transposeRead_sm_1275 s t hs) localReads
#print axioms transposeUnitFacts_1275_0_slot1
section RBS_41
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem viewRead_pm_125 :
    t 125 = fw_view [1, 8, 4, 16] (t 124) := by
  apply vP15 (c1 41) (c0 42) pmNode_22
    0 124 125 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 41 ++ c0 41 := (c4 41 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 41, 124 ∉ row.1.outs
    decide
#print axioms viewRead_pm_125
theorem viewRead_pm_428 :
    t 428 = fw_view [1, 8, 4, 16] (t 427) := by
  apply vP15 (c1 48) (c0 49) pmNode_258
    1 427 428 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 48 ++ c0 48 := (c4 48 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 48, 427 ∉ row.1.outs
    decide
#print axioms viewRead_pm_428
end RBS_41
theorem transposePreViewUnitFacts_1276_0_slot2 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1276).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 125, q 428], y.shape = [1, 8, 4, 16]) ∧
    c3 0 2 0 (t 1276) = c8 1 2 0 [q 125, q 428] := by
  have predecessor := projectionExchangeUnitFacts_1271_0_slot2 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 8, 4, 16] x) [q 124, q 427] [q 125, q 428] :=
    c15 (viewRead_pm_125 p q hp) (c15 (viewRead_pm_428 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_sequence_unit_output_reconstruct 2 2 1 8 4 16 0
    (t 1271) (t 1276) [q 124, q 427] [q 125, q 428]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (viewRead_sm_1276 s t hs) localReads
#print axioms transposePreViewUnitFacts_1276_0_slot2
theorem transposeRead_sm_1277 (s t : Store) (h : c11 s = some t) :
    t 1277 = transposeAxes 1 2 (t 1276) := by
  apply vP12 (c18 15) (c10 16) smNode_15
    0 1276 1277 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 15 ++ c10 15 := (c4 15 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 15, 1276 ∉ row.1.outs
    decide
#print axioms transposeRead_sm_1277
section RBS_42
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem transposeRead_pm_128 :
    t 128 = transposeAxes 1 2 (t 125) := by
  apply vP13 (c1 42) (c0 43) pmNode_23
    0 125 128 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 42 ++ c0 42 := (c4 42 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 42, 125 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_128
theorem transposeRead_pm_431 :
    t 431 = transposeAxes 1 2 (t 428) := by
  apply vP13 (c1 49) (c0 50) pmNode_259
    1 428 431 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 49 ++ c0 49 := (c4 49 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 49, 428 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_431
end RBS_42
theorem transposeUnitFacts_1277_0_slot2 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1277).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 128, q 431], y.shape = [1, 4, 8, 16]) ∧
    c3 0 2 0 (t 1277) = c8 2 2 0 [q 128, q 431] := by
  have predecessor := transposePreViewUnitFacts_1276_0_slot2 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 125, q 428] [q 128, q 431] :=
    c15 (transposeRead_pm_128 p q hp) (c15 (transposeRead_pm_431 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_sequence_unit_output_reconstruct 2 2 1 8 4 16 0
    (t 1276) (t 1277) [q 125, q 428] [q 128, q 431]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (transposeRead_sm_1277 s t hs) localReads
#print axioms transposeUnitFacts_1277_0_slot2
section RBS_43
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem transposeRead_pm_721 :
    t 721 = transposeAxes 1 2 (t 720) := by
  apply vP13 (c1 455) (c0 456) pmNode_489
    2 720 721 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 455 ++ c0 455 := (c4 455 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 455, 720 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_721
theorem transposeRead_pm_1024 :
    t 1024 = transposeAxes 1 2 (t 1023) := by
  apply vP13 (c1 458) (c0 459) pmNode_725
    3 1023 1024 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 458 ++ c0 458 := (c4 458 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 458, 1023 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_1024
end RBS_43
theorem transposeUnitFacts_1273_1_slot0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1273).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 721, q 1024], y.shape = [1, 4, 16, 8]) ∧
    c3 0 2 1 (t 1273) = c8 3 2 0 [q 721, q 1024] := by
  have predecessor := projectionExchangeUnitFacts_1272_1_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 720, q 1023] [q 721, q 1024] :=
    c15 (transposeRead_pm_721 p q hp) (c15 (transposeRead_pm_1024 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_inner_unit_output_reconstruct 2 2 1 16 4 8 1
    (t 1272) (t 1273) [q 720, q 1023] [q 721, q 1024]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (transposeRead_sm_1273 s t hs) localReads
#print axioms transposeUnitFacts_1273_1_slot0
section RBS_44
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem transposeRead_pm_727 :
    t 727 = transposeAxes 1 2 (t 726) := by
  apply vP13 (c1 461) (c0 462) pmNode_492
    2 726 727 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 461 ++ c0 461 := (c4 461 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 461, 726 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_727
theorem transposeRead_pm_1030 :
    t 1030 = transposeAxes 1 2 (t 1029) := by
  apply vP13 (c1 468) (c0 469) pmNode_728
    3 1029 1030 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 468 ++ c0 468 := (c4 468 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 468, 1029 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_1030
end RBS_44
theorem transposeUnitFacts_1275_1_slot1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1275).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 727, q 1030], y.shape = [1, 4, 16, 8]) ∧
    c3 0 2 1 (t 1275) = c8 3 2 0 [q 727, q 1030] := by
  have predecessor := projectionExchangeUnitFacts_1274_1_slot1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 726, q 1029] [q 727, q 1030] :=
    c15 (transposeRead_pm_727 p q hp) (c15 (transposeRead_pm_1030 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_inner_unit_output_reconstruct 2 2 1 16 4 8 1
    (t 1274) (t 1275) [q 726, q 1029] [q 727, q 1030]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (transposeRead_sm_1275 s t hs) localReads
#print axioms transposeUnitFacts_1275_1_slot1
section RBS_45
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem viewRead_pm_731 :
    t 731 = fw_view [1, 8, 4, 16] (t 730) := by
  apply vP15 (c1 463) (c0 464) pmNode_494
    2 730 731 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 463 ++ c0 463 := (c4 463 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 463, 730 ∉ row.1.outs
    decide
#print axioms viewRead_pm_731
theorem viewRead_pm_1034 :
    t 1034 = fw_view [1, 8, 4, 16] (t 1033) := by
  apply vP15 (c1 470) (c0 471) pmNode_730
    3 1033 1034 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 470 ++ c0 470 := (c4 470 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 470, 1033 ∉ row.1.outs
    decide
#print axioms viewRead_pm_1034
end RBS_45
theorem transposePreViewUnitFacts_1276_1_slot2 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1276).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 731, q 1034], y.shape = [1, 8, 4, 16]) ∧
    c3 0 2 1 (t 1276) = c8 1 2 0 [q 731, q 1034] := by
  have predecessor := projectionExchangeUnitFacts_1271_1_slot2 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 8, 4, 16] x) [q 730, q 1033] [q 731, q 1034] :=
    c15 (viewRead_pm_731 p q hp) (c15 (viewRead_pm_1034 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_sequence_unit_output_reconstruct 2 2 1 8 4 16 1
    (t 1271) (t 1276) [q 730, q 1033] [q 731, q 1034]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (viewRead_sm_1276 s t hs) localReads
#print axioms transposePreViewUnitFacts_1276_1_slot2
section RBS_46
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem transposeRead_pm_734 :
    t 734 = transposeAxes 1 2 (t 731) := by
  apply vP13 (c1 464) (c0 465) pmNode_495
    2 731 734 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 464 ++ c0 464 := (c4 464 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 464, 731 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_734
theorem transposeRead_pm_1037 :
    t 1037 = transposeAxes 1 2 (t 1034) := by
  apply vP13 (c1 471) (c0 472) pmNode_731
    3 1034 1037 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 471 ++ c0 471 := (c4 471 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 471, 1034 ∉ row.1.outs
    decide
#print axioms transposeRead_pm_1037
end RBS_46
theorem transposeUnitFacts_1277_1_slot2 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1277).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 734, q 1037], y.shape = [1, 4, 8, 16]) ∧
    c3 0 2 1 (t 1277) = c8 2 2 0 [q 734, q 1037] := by
  have predecessor := transposePreViewUnitFacts_1276_1_slot2 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 731, q 1034] [q 734, q 1037] :=
    c15 (transposeRead_pm_734 p q hp) (c15 (transposeRead_pm_1037 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_sequence_unit_output_reconstruct 2 2 1 8 4 16 1
    (t 1276) (t 1277) [q 731, q 1034] [q 734, q 1037]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (transposeRead_sm_1277 s t hs) localReads
#print axioms transposeUnitFacts_1277_1_slot2
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, full assembly, canonical costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_47
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem postTransposeRead_pm_132 :
    t 132 = c5 2 0 3 1 (([115, 418] : List Tid).map t) := by
  apply vP6 (c1 44) (c0 45) pmNode_25 0 [0, 1] [115, 418] 132 3 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 44 ++ c0 44 := (c4 44 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([115, 418] : List Tid), ∀ row ∈ c0 44, tid ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_132
theorem postTransposeRead_pm_435 :
    t 435 = c5 2 1 3 1 (([115, 418] : List Tid).map t) := by
  apply vP6 (c1 53) (c0 54) pmNode_261 1 [0, 1] [115, 418] 435 3 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 53 ++ c0 53 := (c4 53 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([115, 418] : List Tid), ∀ row ∈ c0 53, tid ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_435
end RBS_47
theorem postTransposeUnitFacts_1273_0_slot0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1273).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 132, q 435], y.shape = [1, 2, 16, 16]) ∧
    c3 0 2 0 (t 1273) = c8 1 2 0 [q 132, q 435] := by
  have predecessor := transposeUnitFacts_1273_0_slot0 s p t q hs hp hvalues
  have outputs : [q 132, q 435] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 3 1 [q 115, q 418]) := by
    change [q 132, q 435] = [c5 2 0 3 1 [q 115, q 418], c5 2 1 3 1 [q 115, q 418]]
    exact c13 c20 (postTransposeRead_pm_132 p q hp) (c13 c20 (postTransposeRead_pm_435 p q hp) (rfl))
  exact SourceRank4ReverseExchange.axis3_output_facts 2 0 2 1 2 16 8 (t 1273) [q 115, q 418] [q 132, q 435]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms postTransposeUnitFacts_1273_0_slot0
theorem postTransposeRead_sm_1278 (s t : Store) (h : c11 s = some t) :
    t 1278 = transposeAxes 2 3 (t 1275) := by
  apply vP12 (c18 16) (c10 17) smNode_16
    0 1275 1278 2 3 s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 16 ++ c10 16 := (c4 16 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 16, 1275 ∉ row.1.outs
    decide
#print axioms postTransposeRead_sm_1278
section RBS_48
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem postTransposeRead_pm_130 :
    t 130 = transposeAxes 2 3 (t 121) := by
  apply vP13 (c1 43) (c0 44) pmNode_24
    0 121 130 2 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 43 ++ c0 43 := (c4 43 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 43, 121 ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_130
theorem postTransposeRead_pm_433 :
    t 433 = transposeAxes 2 3 (t 424) := by
  apply vP13 (c1 50) (c0 51) pmNode_260
    1 424 433 2 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 50 ++ c0 50 := (c4 50 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 50, 424 ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_433
end RBS_48
theorem postTransposeUnitFacts_1278_0_slot1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1278).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 130, q 433], y.shape = [1, 4, 8, 16]) ∧
    c3 0 2 0 (t 1278) = c8 2 2 0 [q 130, q 433] := by
  have predecessor := transposeUnitFacts_1275_0_slot1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 2 3 x) [q 121, q 424] [q 130, q 433] :=
    c15 (postTransposeRead_pm_130 p q hp) (c15 (postTransposeRead_pm_433 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose23_inner_unit_output_reconstruct 2 2 1 4 16 8 0
    (t 1275) (t 1278) [q 121, q 424] [q 130, q 433]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (postTransposeRead_sm_1278 s t hs) localReads
#print axioms postTransposeUnitFacts_1278_0_slot1
section RBS_49
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem postTransposeRead_pm_78 :
    t 78 = c8 2 2 0 (([128, 431] : List Tid).map t) := by
  apply vP9 (c1 62) (c0 63) pmNode_32
    0 [0, 1] [128, 431] 78 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 62 ++ c0 62 := (c4 62 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([128, 431] : List Tid), ∀ row ∈ c0 62, tid ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_78
theorem postTransposeRead_pm_381 :
    t 381 = c8 2 2 1 (([128, 431] : List Tid).map t) := by
  apply vP9 (c1 69) (c0 70) pmNode_268
    1 [0, 1] [128, 431] 381 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 69 ++ c0 69 := (c4 69 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([128, 431] : List Tid), ∀ row ∈ c0 69, tid ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_381
end RBS_49
theorem postTransposeUnitFacts_1277_0_slot2 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1277).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 78, q 381], y.shape = [1, 4, 16, 16]) ∧
    ∀ y ∈ [q 78, q 381], y = c3 0 2 0 (t 1277) := by
  have predecessor := transposeUnitFacts_1277_0_slot2 s p t q hs hp hvalues
  have outputs : ∀ y ∈ [q 78, q 381], y = c3 0 2 0 (t 1277) := by
    intro y hy
    simp only [List.mem_cons, c19, or_false] at hy
    rcases hy with rfl | rfl
    · exact (postTransposeRead_pm_78 p q hp).trans predecessor.2.2.symm
    · exact (postTransposeRead_pm_381 p q hp).trans predecessor.2.2.symm
  refine ⟨predecessor.1, ?_, outputs⟩
  intro y hy
  rw [outputs y hy]
  rw [c21 0 2 0 (t 1277) [2, 4, 16, 16] predecessor.1 (by decide)]
  rfl
#print axioms postTransposeUnitFacts_1277_0_slot2
section RBS_50
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem postTransposeRead_pm_738 :
    t 738 = c5 2 0 3 1 (([721, 1024] : List Tid).map t) := by
  apply vP6 (c1 466) (c0 467) pmNode_497 2 [2, 3] [721, 1024] 738 3 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 466 ++ c0 466 := (c4 466 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([721, 1024] : List Tid), ∀ row ∈ c0 466, tid ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_738
theorem postTransposeRead_pm_1041 :
    t 1041 = c5 2 1 3 1 (([721, 1024] : List Tid).map t) := by
  apply vP6 (c1 475) (c0 476) pmNode_733 3 [2, 3] [721, 1024] 1041 3 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 475 ++ c0 475 := (c4 475 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([721, 1024] : List Tid), ∀ row ∈ c0 475, tid ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_1041
end RBS_50
theorem postTransposeUnitFacts_1273_1_slot0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1273).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 738, q 1041], y.shape = [1, 2, 16, 16]) ∧
    c3 0 2 1 (t 1273) = c8 1 2 0 [q 738, q 1041] := by
  have predecessor := transposeUnitFacts_1273_1_slot0 s p t q hs hp hvalues
  have outputs : [q 738, q 1041] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 3 1 [q 721, q 1024]) := by
    change [q 738, q 1041] = [c5 2 0 3 1 [q 721, q 1024], c5 2 1 3 1 [q 721, q 1024]]
    exact c13 c20 (postTransposeRead_pm_738 p q hp) (c13 c20 (postTransposeRead_pm_1041 p q hp) (rfl))
  exact SourceRank4ReverseExchange.axis3_output_facts 2 1 2 1 2 16 8 (t 1273) [q 721, q 1024] [q 738, q 1041]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms postTransposeUnitFacts_1273_1_slot0
section RBS_51
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem postTransposeRead_pm_736 :
    t 736 = transposeAxes 2 3 (t 727) := by
  apply vP13 (c1 465) (c0 466) pmNode_496
    2 727 736 2 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 465 ++ c0 465 := (c4 465 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 465, 727 ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_736
theorem postTransposeRead_pm_1039 :
    t 1039 = transposeAxes 2 3 (t 1030) := by
  apply vP13 (c1 472) (c0 473) pmNode_732
    3 1030 1039 2 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 472 ++ c0 472 := (c4 472 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 472, 1030 ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_1039
end RBS_51
theorem postTransposeUnitFacts_1278_1_slot1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1278).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 736, q 1039], y.shape = [1, 4, 8, 16]) ∧
    c3 0 2 1 (t 1278) = c8 2 2 0 [q 736, q 1039] := by
  have predecessor := transposeUnitFacts_1275_1_slot1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 2 3 x) [q 727, q 1030] [q 736, q 1039] :=
    c15 (postTransposeRead_pm_736 p q hp) (c15 (postTransposeRead_pm_1039 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose23_inner_unit_output_reconstruct 2 2 1 4 16 8 1
    (t 1275) (t 1278) [q 727, q 1030] [q 736, q 1039]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (postTransposeRead_sm_1278 s t hs) localReads
#print axioms postTransposeUnitFacts_1278_1_slot1
section RBS_52
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem postTransposeRead_pm_684 :
    t 684 = c8 2 2 0 (([734, 1037] : List Tid).map t) := by
  apply vP9 (c1 484) (c0 485) pmNode_504
    2 [2, 3] [734, 1037] 684 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 484 ++ c0 484 := (c4 484 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([734, 1037] : List Tid), ∀ row ∈ c0 484, tid ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_684
theorem postTransposeRead_pm_987 :
    t 987 = c8 2 2 1 (([734, 1037] : List Tid).map t) := by
  apply vP9 (c1 491) (c0 492) pmNode_740
    3 [2, 3] [734, 1037] 987 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 491 ++ c0 491 := (c4 491 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([734, 1037] : List Tid), ∀ row ∈ c0 491, tid ∉ row.1.outs
    decide
#print axioms postTransposeRead_pm_987
end RBS_52
theorem postTransposeUnitFacts_1277_1_slot2 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1277).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 684, q 987], y.shape = [1, 4, 16, 16]) ∧
    ∀ y ∈ [q 684, q 987], y = c3 0 2 1 (t 1277) := by
  have predecessor := transposeUnitFacts_1277_1_slot2 s p t q hs hp hvalues
  have outputs : ∀ y ∈ [q 684, q 987], y = c3 0 2 1 (t 1277) := by
    intro y hy
    simp only [List.mem_cons, c19, or_false] at hy
    rcases hy with rfl | rfl
    · exact (postTransposeRead_pm_684 p q hp).trans predecessor.2.2.symm
    · exact (postTransposeRead_pm_987 p q hp).trans predecessor.2.2.symm
  refine ⟨predecessor.1, ?_, outputs⟩
  intro y hy
  rw [outputs y hy]
  rw [c21 0 2 1 (t 1277) [2, 4, 16, 16] predecessor.1 (by decide)]
  rfl
#print axioms postTransposeUnitFacts_1277_1_slot2
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, assembly, actual capture/caps and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_53
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem middleExchangeRead_pm_133 :
    t 133 = c5 2 0 2 1 (([130, 433] : List Tid).map t) := by
  apply vP6 (c1 51) (c0 52) pmNode_26 0 [0, 1] [130, 433] 133 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 51 ++ c0 51 := (c4 51 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([130, 433] : List Tid), ∀ row ∈ c0 51, tid ∉ row.1.outs
    decide
#print axioms middleExchangeRead_pm_133
theorem middleExchangeRead_pm_436 :
    t 436 = c5 2 1 2 1 (([130, 433] : List Tid).map t) := by
  apply vP6 (c1 54) (c0 55) pmNode_262 1 [0, 1] [130, 433] 436 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 54 ++ c0 54 := (c4 54 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([130, 433] : List Tid), ∀ row ∈ c0 54, tid ∉ row.1.outs
    decide
#print axioms middleExchangeRead_pm_436
end RBS_53
theorem middleExchangeUnitFacts_1278_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1278).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 133, q 436], y.shape = [1, 2, 16, 16]) ∧
    c3 0 2 0 (t 1278) = c8 1 2 0 [q 133, q 436] := by
  have predecessor := postTransposeUnitFacts_1278_0_slot1 s p t q hs hp hvalues
  have outputs : [q 133, q 436] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 130, q 433]) := by
    change [q 133, q 436] = [c5 2 0 2 1 [q 130, q 433], c5 2 1 2 1 [q 130, q 433]]
    exact c13 c20 (middleExchangeRead_pm_133 p q hp) (c13 c20 (middleExchangeRead_pm_436 p q hp) (rfl))
  exact SourceRank4MiddleExchange.axis2_output_facts 2 0 2 1 2 8 16 (t 1278) [q 130, q 433] [q 133, q 436]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms middleExchangeUnitFacts_1278_0
section RBS_54
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem middleExchangeRead_pm_739 :
    t 739 = c5 2 0 2 1 (([736, 1039] : List Tid).map t) := by
  apply vP6 (c1 473) (c0 474) pmNode_498 2 [2, 3] [736, 1039] 739 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 473 ++ c0 473 := (c4 473 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([736, 1039] : List Tid), ∀ row ∈ c0 473, tid ∉ row.1.outs
    decide
#print axioms middleExchangeRead_pm_739
theorem middleExchangeRead_pm_1042 :
    t 1042 = c5 2 1 2 1 (([736, 1039] : List Tid).map t) := by
  apply vP6 (c1 476) (c0 477) pmNode_734 3 [2, 3] [736, 1039] 1042 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 476 ++ c0 476 := (c4 476 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([736, 1039] : List Tid), ∀ row ∈ c0 476, tid ∉ row.1.outs
    decide
#print axioms middleExchangeRead_pm_1042
end RBS_54
theorem middleExchangeUnitFacts_1278_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1278).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 739, q 1042], y.shape = [1, 2, 16, 16]) ∧
    c3 0 2 1 (t 1278) = c8 1 2 0 [q 739, q 1042] := by
  have predecessor := postTransposeUnitFacts_1278_1_slot1 s p t q hs hp hvalues
  have outputs : [q 739, q 1042] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 736, q 1039]) := by
    change [q 739, q 1042] = [c5 2 0 2 1 [q 736, q 1039], c5 2 1 2 1 [q 736, q 1039]]
    exact c13 c20 (middleExchangeRead_pm_739 p q hp) (c13 c20 (middleExchangeRead_pm_1042 p q hp) (rfl))
  exact SourceRank4MiddleExchange.axis2_output_facts 2 1 2 1 2 8 16 (t 1278) [q 736, q 1039] [q 739, q 1042]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms middleExchangeUnitFacts_1278_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns actual capture, caps, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem matmulRead_sm_1279 (s t : Store) (h : c11 s = some t) :
    t 1279 = fw_matmul (t 1273) (t 1278) := by
  apply SourceMatmulRead.matmul_value_of_split smGraph smScope smPeers smGraph.nodes
    c9 (c18 17) (c10 18) smNode_17
    0 1273 1278 1279 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 17 ++ c10 17 := (c4 17 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 17, 1273 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 17, 1278 ∉ row.1.outs
    decide
#print axioms matmulRead_sm_1279
section RBS_55
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem matmulRead_pm_134 :
    t 134 = fw_matmul (t 132) (t 133) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 52) (c0 53) pmNode_27
    0 132 133 134 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 52 ++ c0 52 := (c4 52 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 52, 132 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 52, 133 ∉ row.1.outs
    decide
#print axioms matmulRead_pm_134
theorem matmulRead_pm_437 :
    t 437 = fw_matmul (t 435) (t 436) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 55) (c0 56) pmNode_263
    1 435 436 437 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 55 ++ c0 55 := (c4 55 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 55, 435 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 55, 436 ∉ row.1.outs
    decide
#print axioms matmulRead_pm_437
end RBS_55
theorem matmulUnitFacts_1279_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1279).shape = [2, 4, 16, 16] ∧
    (∀ z ∈ [q 134, q 437], z.shape = [1, 2, 16, 16]) ∧
    c3 0 2 0 (t 1279) = c8 1 2 0 [q 134, q 437] := by
  have left := postTransposeUnitFacts_1273_0_slot0 s p t q hs hp hvalues
  have right := middleExchangeUnitFacts_1278_0 s p t q hs hp hvalues
  have outputs : [q 134, q 437] = List.zipWith fw_matmul [q 132, q 435] [q 133, q 436] := by
    change [q 134, q 437] = [fw_matmul (q 132) (q 133), fw_matmul (q 435) (q 436)]
    exact c13 c20 (matmulRead_pm_134 p q hp) (c13 c20 (matmulRead_pm_437 p q hp) (rfl))
  exact TrainVerify.Denote.source_matmul_unit_output_reconstruct 2 2 1 2 16 16 16 0
    (t 1273) (t 1278) (t 1279) [q 132, q 435] [q 133, q 436] [q 134, q 437]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    left.1 right.1 rfl rfl left.2.1 right.2.1 left.2.2 right.2.2
    (matmulRead_sm_1279 s t hs) outputs
#print axioms matmulUnitFacts_1279_0
section RBS_56
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem matmulRead_pm_740 :
    t 740 = fw_matmul (t 738) (t 739) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 474) (c0 475) pmNode_499
    2 738 739 740 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 474 ++ c0 474 := (c4 474 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 474, 738 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 474, 739 ∉ row.1.outs
    decide
#print axioms matmulRead_pm_740
theorem matmulRead_pm_1043 :
    t 1043 = fw_matmul (t 1041) (t 1042) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 477) (c0 478) pmNode_735
    3 1041 1042 1043 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 477 ++ c0 477 := (c4 477 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 477, 1041 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 477, 1042 ∉ row.1.outs
    decide
#print axioms matmulRead_pm_1043
end RBS_56
theorem matmulUnitFacts_1279_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1279).shape = [2, 4, 16, 16] ∧
    (∀ z ∈ [q 740, q 1043], z.shape = [1, 2, 16, 16]) ∧
    c3 0 2 1 (t 1279) = c8 1 2 0 [q 740, q 1043] := by
  have left := postTransposeUnitFacts_1273_1_slot0 s p t q hs hp hvalues
  have right := middleExchangeUnitFacts_1278_1 s p t q hs hp hvalues
  have outputs : [q 740, q 1043] = List.zipWith fw_matmul [q 738, q 1041] [q 739, q 1042] := by
    change [q 740, q 1043] = [fw_matmul (q 738) (q 739), fw_matmul (q 1041) (q 1042)]
    exact c13 c20 (matmulRead_pm_740 p q hp) (c13 c20 (matmulRead_pm_1043 p q hp) (rfl))
  exact TrainVerify.Denote.source_matmul_unit_output_reconstruct 2 2 1 2 16 16 16 1
    (t 1273) (t 1278) (t 1279) [q 738, q 1041] [q 739, q 1042] [q 740, q 1043]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    left.1 right.1 rfl rfl left.2.1 right.2.1 left.2.2 right.2.2
    (matmulRead_sm_1279 s t hs) outputs
#print axioms matmulUnitFacts_1279_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns actual capture, caps, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_57
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem matmulExchangeRead_pm_138 :
    t 138 = c5 2 0 1 3 (([134, 437] : List Tid).map t) := by
  apply vP6 (c1 56) (c0 57) pmNode_28 0 [0, 1] [134, 437] 138 1 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 56 ++ c0 56 := (c4 56 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([134, 437] : List Tid), ∀ row ∈ c0 56, tid ∉ row.1.outs
    decide
#print axioms matmulExchangeRead_pm_138
theorem matmulExchangeRead_pm_441 :
    t 441 = c5 2 1 1 3 (([134, 437] : List Tid).map t) := by
  apply vP6 (c1 58) (c0 59) pmNode_264 1 [0, 1] [134, 437] 441 1 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 58 ++ c0 58 := (c4 58 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([134, 437] : List Tid), ∀ row ∈ c0 58, tid ∉ row.1.outs
    decide
#print axioms matmulExchangeRead_pm_441
end RBS_57
theorem matmulExchangeUnitFacts_1279_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1279).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 138, q 441], y.shape = [1, 4, 16, 8]) ∧
    c3 0 2 0 (t 1279) = c8 3 2 0 [q 138, q 441] := by
  have predecessor := matmulUnitFacts_1279_0 s p t q hs hp hvalues
  have outputs : [q 138, q 441] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 3 [q 134, q 437]) := by
    change [q 138, q 441] = [c5 2 0 1 3 [q 134, q 437], c5 2 1 1 3 [q 134, q 437]]
    exact c13 c20 (matmulExchangeRead_pm_138 p q hp) (c13 c20 (matmulExchangeRead_pm_441 p q hp) (rfl))
  exact SourceRank4Exchange.axis1_output_facts 2 0 2 1 2 16 8 (t 1279) [q 134, q 437] [q 138, q 441]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms matmulExchangeUnitFacts_1279_0
section RBS_58
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem matmulExchangeRead_pm_744 :
    t 744 = c5 2 0 1 3 (([740, 1043] : List Tid).map t) := by
  apply vP6 (c1 478) (c0 479) pmNode_500 2 [2, 3] [740, 1043] 744 1 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 478 ++ c0 478 := (c4 478 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([740, 1043] : List Tid), ∀ row ∈ c0 478, tid ∉ row.1.outs
    decide
#print axioms matmulExchangeRead_pm_744
theorem matmulExchangeRead_pm_1047 :
    t 1047 = c5 2 1 1 3 (([740, 1043] : List Tid).map t) := by
  apply vP6 (c1 480) (c0 481) pmNode_736 3 [2, 3] [740, 1043] 1047 1 3 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 480 ++ c0 480 := (c4 480 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([740, 1043] : List Tid), ∀ row ∈ c0 480, tid ∉ row.1.outs
    decide
#print axioms matmulExchangeRead_pm_1047
end RBS_58
theorem matmulExchangeUnitFacts_1279_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1279).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 744, q 1047], y.shape = [1, 4, 16, 8]) ∧
    c3 0 2 1 (t 1279) = c8 3 2 0 [q 744, q 1047] := by
  have predecessor := matmulUnitFacts_1279_1 s p t q hs hp hvalues
  have outputs : [q 744, q 1047] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 3 [q 740, q 1043]) := by
    change [q 744, q 1047] = [c5 2 0 1 3 [q 740, q 1043], c5 2 1 1 3 [q 740, q 1043]]
    exact c13 c20 (matmulExchangeRead_pm_744 p q hp) (c13 c20 (matmulExchangeRead_pm_1047 p q hp) (rfl))
  exact SourceRank4Exchange.axis1_output_facts 2 1 2 1 2 16 8 (t 1279) [q 740, q 1043] [q 744, q 1047]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms matmulExchangeUnitFacts_1279_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns actual capture, caps, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem divRead_sm_1280 (s t : Store) (h : c11 s = some t) :
    t 1280 = fw_div (4 : Scalar) (t 1279) := by
  apply SourceDivRead.div_value_of_split smGraph smScope smPeers smGraph.nodes
    c9 (c18 18) (c10 19) smNode_18
    0 4 1279 1280 s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 18 ++ c10 18 := (c4 18 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 18, 1279 ∉ row.1.outs
    decide
#print axioms divRead_sm_1280
section RBS_59
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem divRead_pm_139 :
    t 139 = fw_div (4 : Scalar) (t 138) := by
  apply SourceDivRead.div_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 57) (c0 58) pmNode_29
    0 4 138 139 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 57 ++ c0 57 := (c4 57 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 57, 138 ∉ row.1.outs
    decide
#print axioms divRead_pm_139
theorem divRead_pm_442 :
    t 442 = fw_div (4 : Scalar) (t 441) := by
  apply SourceDivRead.div_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 59) (c0 60) pmNode_265
    1 4 441 442 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 59 ++ c0 59 := (c4 59 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 59, 441 ∉ row.1.outs
    decide
#print axioms divRead_pm_442
end RBS_59
theorem divUnitFacts_1280_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1280).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 139, q 442], y.shape = [1, 4, 16, 8]) ∧
    c3 0 2 0 (t 1280) = c8 3 2 0 [q 139, q 442] := by
  have predecessor := matmulExchangeUnitFacts_1279_0 s p t q hs hp hvalues
  have outputs : [q 139, q 442] = List.map (fw_div (4 : Scalar)) [q 138, q 441] := by
    change [q 139, q 442] = [fw_div (4 : Scalar) (q 138), fw_div (4 : Scalar) (q 441)]
    exact c13 c20 (divRead_pm_139 p q hp) (c13 c20 (divRead_pm_442 p q hp) (rfl))
  exact TrainVerify.Denote.source_div_unit_output_reconstruct (4 : Scalar) 2 2 1 4 16 8 0
    (t 1279) (t 1280) [q 138, q 441] [q 139, q 442]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2
    (divRead_sm_1280 s t hs) outputs
#print axioms divUnitFacts_1280_0
section RBS_60
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem divRead_pm_745 :
    t 745 = fw_div (4 : Scalar) (t 744) := by
  apply SourceDivRead.div_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 479) (c0 480) pmNode_501
    2 4 744 745 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 479 ++ c0 479 := (c4 479 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 479, 744 ∉ row.1.outs
    decide
#print axioms divRead_pm_745
theorem divRead_pm_1048 :
    t 1048 = fw_div (4 : Scalar) (t 1047) := by
  apply SourceDivRead.div_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 481) (c0 482) pmNode_737
    3 4 1047 1048 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 481 ++ c0 481 := (c4 481 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 481, 1047 ∉ row.1.outs
    decide
#print axioms divRead_pm_1048
end RBS_60
theorem divUnitFacts_1280_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1280).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 745, q 1048], y.shape = [1, 4, 16, 8]) ∧
    c3 0 2 1 (t 1280) = c8 3 2 0 [q 745, q 1048] := by
  have predecessor := matmulExchangeUnitFacts_1279_1 s p t q hs hp hvalues
  have outputs : [q 745, q 1048] = List.map (fw_div (4 : Scalar)) [q 744, q 1047] := by
    change [q 745, q 1048] = [fw_div (4 : Scalar) (q 744), fw_div (4 : Scalar) (q 1047)]
    exact c13 c20 (divRead_pm_745 p q hp) (c13 c20 (divRead_pm_1048 p q hp) (rfl))
  exact TrainVerify.Denote.source_div_unit_output_reconstruct (4 : Scalar) 2 2 1 4 16 8 1
    (t 1279) (t 1280) [q 744, q 1047] [q 745, q 1048]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2
    (divRead_sm_1280 s t hs) outputs
#print axioms divUnitFacts_1280_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns actual capture, caps, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_61
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem divExchangeRead_pm_142 :
    t 142 = c5 2 0 3 1 (([139, 442] : List Tid).map t) := by
  apply vP6 (c1 60) (c0 61) pmNode_30 0 [0, 1] [139, 442] 142 3 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 60 ++ c0 60 := (c4 60 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([139, 442] : List Tid), ∀ row ∈ c0 60, tid ∉ row.1.outs
    decide
#print axioms divExchangeRead_pm_142
theorem divExchangeRead_pm_445 :
    t 445 = c5 2 1 3 1 (([139, 442] : List Tid).map t) := by
  apply vP6 (c1 63) (c0 64) pmNode_266 1 [0, 1] [139, 442] 445 3 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 63 ++ c0 63 := (c4 63 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([139, 442] : List Tid), ∀ row ∈ c0 63, tid ∉ row.1.outs
    decide
#print axioms divExchangeRead_pm_445
end RBS_61
theorem divExchangeUnitFacts_1280_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1280).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 142, q 445], y.shape = [1, 2, 16, 16]) ∧
    c3 0 2 0 (t 1280) = c8 1 2 0 [q 142, q 445] := by
  have predecessor := divUnitFacts_1280_0 s p t q hs hp hvalues
  have outputs : [q 142, q 445] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 3 1 [q 139, q 442]) := by
    change [q 142, q 445] = [c5 2 0 3 1 [q 139, q 442], c5 2 1 3 1 [q 139, q 442]]
    exact c13 c20 (divExchangeRead_pm_142 p q hp) (c13 c20 (divExchangeRead_pm_445 p q hp) (rfl))
  exact SourceRank4ReverseExchange.axis3_output_facts 2 0 2 1 2 16 8 (t 1280) [q 139, q 442] [q 142, q 445]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms divExchangeUnitFacts_1280_0
section RBS_62
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem divExchangeRead_pm_748 :
    t 748 = c5 2 0 3 1 (([745, 1048] : List Tid).map t) := by
  apply vP6 (c1 482) (c0 483) pmNode_502 2 [2, 3] [745, 1048] 748 3 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 482 ++ c0 482 := (c4 482 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([745, 1048] : List Tid), ∀ row ∈ c0 482, tid ∉ row.1.outs
    decide
#print axioms divExchangeRead_pm_748
theorem divExchangeRead_pm_1051 :
    t 1051 = c5 2 1 3 1 (([745, 1048] : List Tid).map t) := by
  apply vP6 (c1 485) (c0 486) pmNode_738 3 [2, 3] [745, 1048] 1051 3 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 485 ++ c0 485 := (c4 485 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([745, 1048] : List Tid), ∀ row ∈ c0 485, tid ∉ row.1.outs
    decide
#print axioms divExchangeRead_pm_1051
end RBS_62
theorem divExchangeUnitFacts_1280_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1280).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 748, q 1051], y.shape = [1, 2, 16, 16]) ∧
    c3 0 2 1 (t 1280) = c8 1 2 0 [q 748, q 1051] := by
  have predecessor := divUnitFacts_1280_1 s p t q hs hp hvalues
  have outputs : [q 748, q 1051] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 3 1 [q 745, q 1048]) := by
    change [q 748, q 1051] = [c5 2 0 3 1 [q 745, q 1048], c5 2 1 3 1 [q 745, q 1048]]
    exact c13 c20 (divExchangeRead_pm_748 p q hp) (c13 c20 (divExchangeRead_pm_1051 p q hp) (rfl))
  exact SourceRank4ReverseExchange.axis3_output_facts 2 1 2 1 2 16 8 (t 1280) [q 745, q 1048] [q 748, q 1051]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms divExchangeUnitFacts_1280_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns actual capture, caps, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem softmaxRead_sm_1281 (s t : Store) (h : c11 s = some t) :
    t 1281 = fw_softmax (t 1280) := by
  apply SourceSoftmaxRead.softmax_value_of_split smGraph smScope smPeers smGraph.nodes
    c9 (c18 19) (c10 20) smNode_19
    0 1280 1281 s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 19 ++ c10 19 := (c4 19 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 19, 1280 ∉ row.1.outs
    decide
#print axioms softmaxRead_sm_1281
section RBS_63
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem softmaxRead_pm_143 :
    t 143 = fw_softmax (t 142) := by
  apply SourceSoftmaxRead.softmax_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 61) (c0 62) pmNode_31
    0 142 143 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 61 ++ c0 61 := (c4 61 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 61, 142 ∉ row.1.outs
    decide
#print axioms softmaxRead_pm_143
theorem softmaxRead_pm_446 :
    t 446 = fw_softmax (t 445) := by
  apply SourceSoftmaxRead.softmax_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 64) (c0 65) pmNode_267
    1 445 446 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 64 ++ c0 64 := (c4 64 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 64, 445 ∉ row.1.outs
    decide
#print axioms softmaxRead_pm_446
end RBS_63
theorem softmaxUnitFacts_1281_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1281).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 143, q 446], y.shape = [1, 2, 16, 16]) ∧
    c3 0 2 0 (t 1281) = c8 1 2 0 [q 143, q 446] := by
  have predecessor := divExchangeUnitFacts_1280_0 s p t q hs hp hvalues
  have outputs : [q 143, q 446] = List.map fw_softmax [q 142, q 445] := by
    change [q 143, q 446] = [fw_softmax (q 142), fw_softmax (q 445)]
    exact c13 c20 (softmaxRead_pm_143 p q hp) (c13 c20 (softmaxRead_pm_446 p q hp) (rfl))
  exact TrainVerify.Denote.source_softmax_unit_output_reconstruct 2 2 1 2 16 16 0
    (t 1280) (t 1281) [q 142, q 445] [q 143, q 446]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2
    (softmaxRead_sm_1281 s t hs) outputs
#print axioms softmaxUnitFacts_1281_0
section RBS_64
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem softmaxRead_pm_749 :
    t 749 = fw_softmax (t 748) := by
  apply SourceSoftmaxRead.softmax_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 483) (c0 484) pmNode_503
    2 748 749 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 483 ++ c0 483 := (c4 483 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 483, 748 ∉ row.1.outs
    decide
#print axioms softmaxRead_pm_749
theorem softmaxRead_pm_1052 :
    t 1052 = fw_softmax (t 1051) := by
  apply SourceSoftmaxRead.softmax_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 486) (c0 487) pmNode_739
    3 1051 1052 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 486 ++ c0 486 := (c4 486 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 486, 1051 ∉ row.1.outs
    decide
#print axioms softmaxRead_pm_1052
end RBS_64
theorem softmaxUnitFacts_1281_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1281).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 749, q 1052], y.shape = [1, 2, 16, 16]) ∧
    c3 0 2 1 (t 1281) = c8 1 2 0 [q 749, q 1052] := by
  have predecessor := divExchangeUnitFacts_1280_1 s p t q hs hp hvalues
  have outputs : [q 749, q 1052] = List.map fw_softmax [q 748, q 1051] := by
    change [q 749, q 1052] = [fw_softmax (q 748), fw_softmax (q 1051)]
    exact c13 c20 (softmaxRead_pm_749 p q hp) (c13 c20 (softmaxRead_pm_1052 p q hp) (rfl))
  exact TrainVerify.Denote.source_softmax_unit_output_reconstruct 2 2 1 2 16 16 1
    (t 1280) (t 1281) [q 748, q 1051] [q 749, q 1052]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2
    (softmaxRead_sm_1281 s t hs) outputs
#print axioms softmaxUnitFacts_1281_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns actual capture, caps, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_65
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem softmaxExchangeRead_pm_146 :
    t 146 = c5 2 0 1 2 (([143, 446] : List Tid).map t) := by
  apply vP6 (c1 65) (c0 66) pmNode_33 0 [0, 1] [143, 446] 146 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 65 ++ c0 65 := (c4 65 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([143, 446] : List Tid), ∀ row ∈ c0 65, tid ∉ row.1.outs
    decide
#print axioms softmaxExchangeRead_pm_146
theorem softmaxExchangeRead_pm_449 :
    t 449 = c5 2 1 1 2 (([143, 446] : List Tid).map t) := by
  apply vP6 (c1 70) (c0 71) pmNode_269 1 [0, 1] [143, 446] 449 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 70 ++ c0 70 := (c4 70 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([143, 446] : List Tid), ∀ row ∈ c0 70, tid ∉ row.1.outs
    decide
#print axioms softmaxExchangeRead_pm_449
end RBS_65
theorem softmaxExchangeUnitFacts_1281_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1281).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 146, q 449], y.shape = [1, 4, 8, 16]) ∧
    c3 0 2 0 (t 1281) = c8 2 2 0 [q 146, q 449] := by
  have predecessor := softmaxUnitFacts_1281_0 s p t q hs hp hvalues
  have outputs : [q 146, q 449] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 2 [q 143, q 446]) := by
    change [q 146, q 449] = [c5 2 0 1 2 [q 143, q 446], c5 2 1 1 2 [q 143, q 446]]
    exact c13 c20 (softmaxExchangeRead_pm_146 p q hp) (c13 c20 (softmaxExchangeRead_pm_449 p q hp) (rfl))
  exact SourceRank4InnerExchange.axis1_output_facts 2 0 2 1 2 8 16 (t 1281) [q 143, q 446] [q 146, q 449]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms softmaxExchangeUnitFacts_1281_0
section RBS_66
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem softmaxExchangeRead_pm_752 :
    t 752 = c5 2 0 1 2 (([749, 1052] : List Tid).map t) := by
  apply vP6 (c1 487) (c0 488) pmNode_505 2 [2, 3] [749, 1052] 752 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 487 ++ c0 487 := (c4 487 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([749, 1052] : List Tid), ∀ row ∈ c0 487, tid ∉ row.1.outs
    decide
#print axioms softmaxExchangeRead_pm_752
theorem softmaxExchangeRead_pm_1055 :
    t 1055 = c5 2 1 1 2 (([749, 1052] : List Tid).map t) := by
  apply vP6 (c1 492) (c0 493) pmNode_741 3 [2, 3] [749, 1052] 1055 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 492 ++ c0 492 := (c4 492 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([749, 1052] : List Tid), ∀ row ∈ c0 492, tid ∉ row.1.outs
    decide
#print axioms softmaxExchangeRead_pm_1055
end RBS_66
theorem softmaxExchangeUnitFacts_1281_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1281).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 752, q 1055], y.shape = [1, 4, 8, 16]) ∧
    c3 0 2 1 (t 1281) = c8 2 2 0 [q 752, q 1055] := by
  have predecessor := softmaxUnitFacts_1281_1 s p t q hs hp hvalues
  have outputs : [q 752, q 1055] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 2 [q 749, q 1052]) := by
    change [q 752, q 1055] = [c5 2 0 1 2 [q 749, q 1052], c5 2 1 1 2 [q 749, q 1052]]
    exact c13 c20 (softmaxExchangeRead_pm_752 p q hp) (c13 c20 (softmaxExchangeRead_pm_1055 p q hp) (rfl))
  exact SourceRank4InnerExchange.axis1_output_facts 2 1 2 1 2 8 16 (t 1281) [q 749, q 1052] [q 752, q 1055]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms softmaxExchangeUnitFacts_1281_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns actual capture, caps, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem queryMatmulRead_sm_1282 (s t : Store) (h : c11 s = some t) :
    t 1282 = fw_matmul (t 1281) (t 1277) := by
  apply SourceMatmulRead.matmul_value_of_split smGraph smScope smPeers smGraph.nodes
    c9 (c18 20) (c10 21) smNode_20
    0 1281 1277 1282 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 20 ++ c10 20 := (c4 20 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 20, 1281 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 20, 1277 ∉ row.1.outs
    decide
#print axioms queryMatmulRead_sm_1282
section RBS_67
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem queryMatmulRead_pm_147 :
    t 147 = fw_matmul (t 146) (t 78) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 66) (c0 67) pmNode_34
    0 146 78 147 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 66 ++ c0 66 := (c4 66 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 66, 146 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 66, 78 ∉ row.1.outs
    decide
#print axioms queryMatmulRead_pm_147
theorem queryMatmulRead_pm_450 :
    t 450 = fw_matmul (t 449) (t 381) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 71) (c0 72) pmNode_270
    1 449 381 450 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 71 ++ c0 71 := (c4 71 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 71, 449 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 71, 381 ∉ row.1.outs
    decide
#print axioms queryMatmulRead_pm_450
end RBS_67
theorem queryMatmulUnitFacts_1282_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1282).shape = [2, 4, 16, 16] ∧
    (∀ z ∈ [q 147, q 450], z.shape = [1, 4, 8, 16]) ∧
    c3 0 2 0 (t 1282) = c8 2 2 0 [q 147, q 450] := by
  have left := softmaxExchangeUnitFacts_1281_0 s p t q hs hp hvalues
  have right := postTransposeUnitFacts_1277_0_slot2 s p t q hs hp hvalues
  have outputs : [q 147, q 450] = List.zipWith fw_matmul [q 146, q 449] [q 78, q 381] := by
    change [q 147, q 450] = [fw_matmul (q 146) (q 78), fw_matmul (q 449) (q 381)]
    exact c13 c20 (queryMatmulRead_pm_147 p q hp) (c13 c20 (queryMatmulRead_pm_450 p q hp) (rfl))
  exact TrainVerify.Denote.source_query_matmul_unit_output_reconstruct 2 2 1 4 8 16 16 0
    (t 1281) (t 1277) (t 1282) [q 146, q 449] [q 78, q 381] [q 147, q 450]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    left.1 right.1 rfl rfl left.2.1 right.2.2 left.2.2
    (queryMatmulRead_sm_1282 s t hs) outputs
#print axioms queryMatmulUnitFacts_1282_0
section RBS_68
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem queryMatmulRead_pm_753 :
    t 753 = fw_matmul (t 752) (t 684) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 488) (c0 489) pmNode_506
    2 752 684 753 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 488 ++ c0 488 := (c4 488 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 488, 752 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 488, 684 ∉ row.1.outs
    decide
#print axioms queryMatmulRead_pm_753
theorem queryMatmulRead_pm_1056 :
    t 1056 = fw_matmul (t 1055) (t 987) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 493) (c0 494) pmNode_742
    3 1055 987 1056 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 493 ++ c0 493 := (c4 493 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 493, 1055 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 493, 987 ∉ row.1.outs
    decide
#print axioms queryMatmulRead_pm_1056
end RBS_68
theorem queryMatmulUnitFacts_1282_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1282).shape = [2, 4, 16, 16] ∧
    (∀ z ∈ [q 753, q 1056], z.shape = [1, 4, 8, 16]) ∧
    c3 0 2 1 (t 1282) = c8 2 2 0 [q 753, q 1056] := by
  have left := softmaxExchangeUnitFacts_1281_1 s p t q hs hp hvalues
  have right := postTransposeUnitFacts_1277_1_slot2 s p t q hs hp hvalues
  have outputs : [q 753, q 1056] = List.zipWith fw_matmul [q 752, q 1055] [q 684, q 987] := by
    change [q 753, q 1056] = [fw_matmul (q 752) (q 684), fw_matmul (q 1055) (q 987)]
    exact c13 c20 (queryMatmulRead_pm_753 p q hp) (c13 c20 (queryMatmulRead_pm_1056 p q hp) (rfl))
  exact TrainVerify.Denote.source_query_matmul_unit_output_reconstruct 2 2 1 4 8 16 16 1
    (t 1281) (t 1277) (t 1282) [q 752, q 1055] [q 684, q 987] [q 753, q 1056]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    left.1 right.1 rfl rfl left.2.1 right.2.2 left.2.2
    (queryMatmulRead_sm_1282 s t hs) outputs
#print axioms queryMatmulUnitFacts_1282_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns capture, receipt wiring, imports, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem queryTransposeRead_sm_1283 (s t : Store) (h : c11 s = some t) :
    t 1283 = transposeAxes 1 2 (t 1282) := by
  apply vP12 (c18 21) (c10 22) smNode_21
    0 1282 1283 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 21 ++ c10 21 := (c4 21 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 21, 1282 ∉ row.1.outs
    decide
#print axioms queryTransposeRead_sm_1283
section RBS_69
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem queryTransposeRead_pm_151 :
    t 151 = transposeAxes 1 2 (t 147) := by
  apply vP13 (c1 67) (c0 68) pmNode_35
    0 147 151 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 67 ++ c0 67 := (c4 67 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 67, 147 ∉ row.1.outs
    decide
#print axioms queryTransposeRead_pm_151
theorem queryTransposeRead_pm_454 :
    t 454 = transposeAxes 1 2 (t 450) := by
  apply vP13 (c1 72) (c0 73) pmNode_271
    1 450 454 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 72 ++ c0 72 := (c4 72 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 72, 450 ∉ row.1.outs
    decide
#print axioms queryTransposeRead_pm_454
end RBS_69
theorem queryTransposeUnitFacts_1283_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1283).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 151, q 454], y.shape = [1, 8, 4, 16]) ∧
    c3 0 2 0 (t 1283) = c8 1 2 0 [q 151, q 454] := by
  have predecessor := queryMatmulUnitFacts_1282_0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 147, q 450] [q 151, q 454] :=
    c15 (queryTransposeRead_pm_151 p q hp) (c15 (queryTransposeRead_pm_454 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_query_unit_output_reconstruct 2 2 1 4 8 16 0
    (t 1282) (t 1283) [q 147, q 450] [q 151, q 454]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (queryTransposeRead_sm_1283 s t hs) localReads
#print axioms queryTransposeUnitFacts_1283_0
section RBS_70
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem queryTransposeRead_pm_757 :
    t 757 = transposeAxes 1 2 (t 753) := by
  apply vP13 (c1 489) (c0 490) pmNode_507
    2 753 757 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 489 ++ c0 489 := (c4 489 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 489, 753 ∉ row.1.outs
    decide
#print axioms queryTransposeRead_pm_757
theorem queryTransposeRead_pm_1060 :
    t 1060 = transposeAxes 1 2 (t 1056) := by
  apply vP13 (c1 494) (c0 495) pmNode_743
    3 1056 1060 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 494 ++ c0 494 := (c4 494 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 494, 1056 ∉ row.1.outs
    decide
#print axioms queryTransposeRead_pm_1060
end RBS_70
theorem queryTransposeUnitFacts_1283_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1283).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 757, q 1060], y.shape = [1, 8, 4, 16]) ∧
    c3 0 2 1 (t 1283) = c8 1 2 0 [q 757, q 1060] := by
  have predecessor := queryMatmulUnitFacts_1282_1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 753, q 1056] [q 757, q 1060] :=
    c15 (queryTransposeRead_pm_757 p q hp) (c15 (queryTransposeRead_pm_1060 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_query_unit_output_reconstruct 2 2 1 4 8 16 1
    (t 1282) (t 1283) [q 753, q 1056] [q 757, q 1060]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (queryTransposeRead_sm_1283 s t hs) localReads
#print axioms queryTransposeUnitFacts_1283_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns capture, receipt wiring, imports, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem contiguousRead_sm_1284 (s t : Store) (h : c11 s = some t) :
    t 1284 = t 1283 := by
  apply SourceContiguousRead.contiguous_value_of_split smGraph smScope smPeers smGraph.nodes
    c9 (c18 22) (c10 23) smNode_22
    0 1283 1284 s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 22 ++ c10 22 := (c4 22 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 22, 1283 ∉ row.1.outs
    decide
#print axioms contiguousRead_sm_1284
section RBS_71
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem contiguousRead_pm_153 :
    t 153 = t 151 := by
  apply SourceContiguousRead.contiguous_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 68) (c0 69) pmNode_36
    0 151 153 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 68 ++ c0 68 := (c4 68 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 68, 151 ∉ row.1.outs
    decide
#print axioms contiguousRead_pm_153
theorem contiguousRead_pm_456 :
    t 456 = t 454 := by
  apply SourceContiguousRead.contiguous_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 73) (c0 74) pmNode_272
    1 454 456 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 73 ++ c0 73 := (c4 73 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 73, 454 ∉ row.1.outs
    decide
#print axioms contiguousRead_pm_456
end RBS_71
theorem contiguousUnitFacts_1284_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1284).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 153, q 456], y.shape = [1, 8, 4, 16]) ∧
    c3 0 2 0 (t 1284) = c8 1 2 0 [q 153, q 456] := by
  have predecessor := queryTransposeUnitFacts_1283_0 s p t q hs hp hvalues
  rw [contiguousRead_sm_1284 s t hs, contiguousRead_pm_153 p q hp, contiguousRead_pm_456 p q hp]
  exact predecessor
#print axioms contiguousUnitFacts_1284_0
section RBS_72
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem contiguousRead_pm_759 :
    t 759 = t 757 := by
  apply SourceContiguousRead.contiguous_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 490) (c0 491) pmNode_508
    2 757 759 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 490 ++ c0 490 := (c4 490 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 490, 757 ∉ row.1.outs
    decide
#print axioms contiguousRead_pm_759
theorem contiguousRead_pm_1062 :
    t 1062 = t 1060 := by
  apply SourceContiguousRead.contiguous_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 495) (c0 496) pmNode_744
    3 1060 1062 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 495 ++ c0 495 := (c4 495 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 495, 1060 ∉ row.1.outs
    decide
#print axioms contiguousRead_pm_1062
end RBS_72
theorem contiguousUnitFacts_1284_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1284).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 759, q 1062], y.shape = [1, 8, 4, 16]) ∧
    c3 0 2 1 (t 1284) = c8 1 2 0 [q 759, q 1062] := by
  have predecessor := queryTransposeUnitFacts_1283_1 s p t q hs hp hvalues
  rw [contiguousRead_sm_1284 s t hs, contiguousRead_pm_759 p q hp, contiguousRead_pm_1062 p q hp]
  exact predecessor
#print axioms contiguousUnitFacts_1284_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns actual capture, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_73
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem contiguousExchangeRead_pm_155 :
    t 155 = c5 2 0 1 2 (([153, 456] : List Tid).map t) := by
  apply vP6 (c1 74) (c0 75) pmNode_37 0 [0, 1] [153, 456] 155 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 74 ++ c0 74 := (c4 74 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([153, 456] : List Tid), ∀ row ∈ c0 74, tid ∉ row.1.outs
    decide
#print axioms contiguousExchangeRead_pm_155
theorem contiguousExchangeRead_pm_458 :
    t 458 = c5 2 1 1 2 (([153, 456] : List Tid).map t) := by
  apply vP6 (c1 76) (c0 77) pmNode_273 1 [0, 1] [153, 456] 458 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 76 ++ c0 76 := (c4 76 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([153, 456] : List Tid), ∀ row ∈ c0 76, tid ∉ row.1.outs
    decide
#print axioms contiguousExchangeRead_pm_458
end RBS_73
theorem contiguousExchangeUnitFacts_1284_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1284).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 155, q 458], y.shape = [1, 16, 2, 16]) ∧
    c3 0 2 0 (t 1284) = c8 2 2 0 [q 155, q 458] := by
  have predecessor := contiguousUnitFacts_1284_0 s p t q hs hp hvalues
  have outputs : [q 155, q 458] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 2 [q 153, q 456]) := by
    change [q 155, q 458] = [c5 2 0 1 2 [q 153, q 456], c5 2 1 1 2 [q 153, q 456]]
    exact c13 c20 (contiguousExchangeRead_pm_155 p q hp) (c13 c20 (contiguousExchangeRead_pm_458 p q hp) (rfl))
  exact SourceRank4InnerExchange.axis1_output_facts 2 0 2 1 8 2 16 (t 1284) [q 153, q 456] [q 155, q 458]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms contiguousExchangeUnitFacts_1284_0
section RBS_74
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem contiguousExchangeRead_pm_761 :
    t 761 = c5 2 0 1 2 (([759, 1062] : List Tid).map t) := by
  apply vP6 (c1 496) (c0 497) pmNode_509 2 [2, 3] [759, 1062] 761 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 496 ++ c0 496 := (c4 496 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([759, 1062] : List Tid), ∀ row ∈ c0 496, tid ∉ row.1.outs
    decide
#print axioms contiguousExchangeRead_pm_761
theorem contiguousExchangeRead_pm_1064 :
    t 1064 = c5 2 1 1 2 (([759, 1062] : List Tid).map t) := by
  apply vP6 (c1 498) (c0 499) pmNode_745 3 [2, 3] [759, 1062] 1064 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 498 ++ c0 498 := (c4 498 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([759, 1062] : List Tid), ∀ row ∈ c0 498, tid ∉ row.1.outs
    decide
#print axioms contiguousExchangeRead_pm_1064
end RBS_74
theorem contiguousExchangeUnitFacts_1284_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1284).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 761, q 1064], y.shape = [1, 16, 2, 16]) ∧
    c3 0 2 1 (t 1284) = c8 2 2 0 [q 761, q 1064] := by
  have predecessor := contiguousUnitFacts_1284_1 s p t q hs hp hvalues
  have outputs : [q 761, q 1064] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 2 [q 759, q 1062]) := by
    change [q 761, q 1064] = [c5 2 0 1 2 [q 759, q 1062], c5 2 1 1 2 [q 759, q 1062]]
    exact c13 c20 (contiguousExchangeRead_pm_761 p q hp) (c13 c20 (contiguousExchangeRead_pm_1064 p q hp) (rfl))
  exact SourceRank4InnerExchange.axis1_output_facts 2 1 2 1 8 2 16 (t 1284) [q 759, q 1062] [q 761, q 1064]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms contiguousExchangeUnitFacts_1284_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns capture, receipt wiring, imports, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem viewFlattenRead_sm_1285 (s t : Store) (h : c11 s = some t) :
    t 1285 = fw_view [2, 16, 64] (t 1284) := by
  apply vP14 (c18 23) (c10 24) smNode_23
    0 1284 1285 2 [16, 64] s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 23 ++ c10 23 := (c4 23 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 23, 1284 ∉ row.1.outs
    decide
#print axioms viewFlattenRead_sm_1285
section RBS_75
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem viewFlattenRead_pm_156 :
    t 156 = fw_view [1, 16, 32] (t 155) := by
  apply vP15 (c1 75) (c0 76) pmNode_38
    0 155 156 1 [16, 32] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 75 ++ c0 75 := (c4 75 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 75, 155 ∉ row.1.outs
    decide
#print axioms viewFlattenRead_pm_156
theorem viewFlattenRead_pm_459 :
    t 459 = fw_view [1, 16, 32] (t 458) := by
  apply vP15 (c1 77) (c0 78) pmNode_274
    1 458 459 1 [16, 32] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 77 ++ c0 77 := (c4 77 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 77, 458 ∉ row.1.outs
    decide
#print axioms viewFlattenRead_pm_459
end RBS_75
theorem viewFlattenUnitFacts_1285_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1285).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 156, q 459], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1285) = c8 2 2 0 [q 156, q 459] := by
  have predecessor := contiguousExchangeUnitFacts_1284_0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 16, 32] x) [q 155, q 458] [q 156, q 459] :=
    c15 (viewFlattenRead_pm_156 p q hp) (c15 (viewFlattenRead_pm_459 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_flatten_head_unit_output_reconstruct 2 2 1 16 2 16 0
    (t 1284) (t 1285) [q 155, q 458] [q 156, q 459]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (viewFlattenRead_sm_1285 s t hs) localReads
#print axioms viewFlattenUnitFacts_1285_0
section RBS_76
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem viewFlattenRead_pm_762 :
    t 762 = fw_view [1, 16, 32] (t 761) := by
  apply vP15 (c1 497) (c0 498) pmNode_510
    2 761 762 1 [16, 32] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 497 ++ c0 497 := (c4 497 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 497, 761 ∉ row.1.outs
    decide
#print axioms viewFlattenRead_pm_762
theorem viewFlattenRead_pm_1065 :
    t 1065 = fw_view [1, 16, 32] (t 1064) := by
  apply vP15 (c1 499) (c0 500) pmNode_746
    3 1064 1065 1 [16, 32] s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 499 ++ c0 499 := (c4 499 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 499, 1064 ∉ row.1.outs
    decide
#print axioms viewFlattenRead_pm_1065
end RBS_76
theorem viewFlattenUnitFacts_1285_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1285).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 762, q 1065], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1285) = c8 2 2 0 [q 762, q 1065] := by
  have predecessor := contiguousExchangeUnitFacts_1284_1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 16, 32] x) [q 761, q 1064] [q 762, q 1065] :=
    c15 (viewFlattenRead_pm_762 p q hp) (c15 (viewFlattenRead_pm_1065 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_flatten_head_unit_output_reconstruct 2 2 1 16 2 16 1
    (t 1284) (t 1285) [q 761, q 1064] [q 762, q 1065]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (viewFlattenRead_sm_1285 s t hs) localReads
#print axioms viewFlattenUnitFacts_1285_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns actual capture, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_77
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem viewFlattenExchangeRead_pm_159 :
    t 159 = c5 2 0 2 1 (([156, 459] : List Tid).map t) := by
  apply vP6 (c1 78) (c0 79) pmNode_39 0 [0, 1] [156, 459] 159 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 78 ++ c0 78 := (c4 78 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([156, 459] : List Tid), ∀ row ∈ c0 78, tid ∉ row.1.outs
    decide
#print axioms viewFlattenExchangeRead_pm_159
theorem viewFlattenExchangeRead_pm_462 :
    t 462 = c5 2 1 2 1 (([156, 459] : List Tid).map t) := by
  apply vP6 (c1 80) (c0 81) pmNode_275 1 [0, 1] [156, 459] 462 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 80 ++ c0 80 := (c4 80 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([156, 459] : List Tid), ∀ row ∈ c0 80, tid ∉ row.1.outs
    decide
#print axioms viewFlattenExchangeRead_pm_462
end RBS_77
theorem viewFlattenExchangeUnitFacts_1285_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1285).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 159, q 462], y.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1285) = c8 1 2 0 [q 159, q 462] := by
  have predecessor := viewFlattenUnitFacts_1285_0 s p t q hs hp hvalues
  have outputs : [q 159, q 462] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 156, q 459]) := by
    change [q 159, q 462] = [c5 2 0 2 1 [q 156, q 459], c5 2 1 2 1 [q 156, q 459]]
    exact c13 c20 (viewFlattenExchangeRead_pm_159 p q hp) (c13 c20 (viewFlattenExchangeRead_pm_462 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 0 2 1 8 32 (t 1285) [q 156, q 459] [q 159, q 462]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms viewFlattenExchangeUnitFacts_1285_0
section RBS_78
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem viewFlattenExchangeRead_pm_765 :
    t 765 = c5 2 0 2 1 (([762, 1065] : List Tid).map t) := by
  apply vP6 (c1 500) (c0 501) pmNode_511 2 [2, 3] [762, 1065] 765 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 500 ++ c0 500 := (c4 500 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([762, 1065] : List Tid), ∀ row ∈ c0 500, tid ∉ row.1.outs
    decide
#print axioms viewFlattenExchangeRead_pm_765
theorem viewFlattenExchangeRead_pm_1068 :
    t 1068 = c5 2 1 2 1 (([762, 1065] : List Tid).map t) := by
  apply vP6 (c1 502) (c0 503) pmNode_747 3 [2, 3] [762, 1065] 1068 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 502 ++ c0 502 := (c4 502 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([762, 1065] : List Tid), ∀ row ∈ c0 502, tid ∉ row.1.outs
    decide
#print axioms viewFlattenExchangeRead_pm_1068
end RBS_78
theorem viewFlattenExchangeUnitFacts_1285_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1285).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 765, q 1068], y.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1285) = c8 1 2 0 [q 765, q 1068] := by
  have predecessor := viewFlattenUnitFacts_1285_1 s p t q hs hp hvalues
  have outputs : [q 765, q 1068] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 762, q 1065]) := by
    change [q 765, q 1068] = [c5 2 0 2 1 [q 762, q 1065], c5 2 1 2 1 [q 762, q 1065]]
    exact c13 c20 (viewFlattenExchangeRead_pm_765 p q hp) (c13 c20 (viewFlattenExchangeRead_pm_1068 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 1 2 1 8 32 (t 1285) [q 762, q 1065] [q 765, q 1068]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms viewFlattenExchangeUnitFacts_1285_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns capture, assembly, imports and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem outputProjectionRead_sm_1286 (s t : Store) (h : c11 s = some t) :
    t 1286 = fw_linear (t 1285) (t 1219) := by
  apply vP16 (c18 24) (c10 25) smNode_24
    0 1285 1219 1286 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 24 ++ c10 24 := (c4 24 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 24, 1285 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 24, 1219 ∉ row.1.outs
    decide
#print axioms outputProjectionRead_sm_1286
section RBS_79
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem outputProjectionRead_pm_160 :
    t 160 = fw_linear (t 159) (t 4) := by
  apply vP17 (c1 79) (c0 80) pmNode_40
    0 159 4 160 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 79 ++ c0 79 := (c4 79 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 79, 159 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 79, 4 ∉ row.1.outs
    decide
#print axioms outputProjectionRead_pm_160
theorem outputProjectionRead_pm_463 :
    t 463 = fw_linear (t 462) (t 307) := by
  apply vP17 (c1 81) (c0 82) pmNode_276
    1 462 307 463 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 81 ++ c0 81 := (c4 81 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 81, 462 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 81, 307 ∉ row.1.outs
    decide
#print axioms outputProjectionRead_pm_463
end RBS_79
theorem outputProjectionUnitFacts_1286_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1286).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 160, q 463], y.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1286) = c8 1 2 0 [q 160, q 463] := by
  have predecessor := viewFlattenExchangeUnitFacts_1285_0 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : c16 (t 1219) [q 4, q 307] [64, 64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 : q 160 = fw_linear (q 159) (t 1219) :=
    (outputProjectionRead_pm_160 p q hp).trans (congrArg (fw_linear (q 159))
      (weightRel.replica_values (q 4) c6))
  have local1 : q 463 = fw_linear (q 462) (t 1219) :=
    (outputProjectionRead_pm_463 p q hp).trans (congrArg (fw_linear (q 462))
      (weightRel.replica_values (q 307) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = fw_linear x (t 1219)) [q 159, q 462] [q 160, q 463] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_sequence_unit_output_reconstruct 2 2 1 8 64 64 0
    (t 1285) (t 1219) (t 1286) [q 159, q 462] [q 160, q 463]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 weightRel.full_shape predecessor.2.2
    (outputProjectionRead_sm_1286 s t hs) localReads
#print axioms outputProjectionUnitFacts_1286_0
section RBS_80
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem outputProjectionRead_pm_766 :
    t 766 = fw_linear (t 765) (t 610) := by
  apply vP17 (c1 501) (c0 502) pmNode_512
    2 765 610 766 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 501 ++ c0 501 := (c4 501 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 501, 765 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 501, 610 ∉ row.1.outs
    decide
#print axioms outputProjectionRead_pm_766
theorem outputProjectionRead_pm_1069 :
    t 1069 = fw_linear (t 1068) (t 913) := by
  apply vP17 (c1 503) (c0 504) pmNode_748
    3 1068 913 1069 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 503 ++ c0 503 := (c4 503 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 503, 1068 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 503, 913 ∉ row.1.outs
    decide
#print axioms outputProjectionRead_pm_1069
end RBS_80
theorem outputProjectionUnitFacts_1286_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1286).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 766, q 1069], y.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1286) = c8 1 2 0 [q 766, q 1069] := by
  have predecessor := viewFlattenExchangeUnitFacts_1285_1 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : c16 (t 1219) [q 610, q 913] [64, 64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 : q 766 = fw_linear (q 765) (t 1219) :=
    (outputProjectionRead_pm_766 p q hp).trans (congrArg (fw_linear (q 765))
      (weightRel.replica_values (q 610) c6))
  have local1 : q 1069 = fw_linear (q 1068) (t 1219) :=
    (outputProjectionRead_pm_1069 p q hp).trans (congrArg (fw_linear (q 1068))
      (weightRel.replica_values (q 913) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = fw_linear x (t 1219)) [q 765, q 1068] [q 766, q 1069] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_sequence_unit_output_reconstruct 2 2 1 8 64 64 1
    (t 1285) (t 1219) (t 1286) [q 765, q 1068] [q 766, q 1069]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 weightRel.full_shape predecessor.2.2
    (outputProjectionRead_sm_1286 s t hs) localReads
#print axioms outputProjectionUnitFacts_1286_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns actual capture, assembly and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
section RBS_81
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem outputProjectionExchangeRead_pm_164 :
    t 164 = c5 2 0 1 2 (([160, 463] : List Tid).map t) := by
  apply vP6 (c1 82) (c0 83) pmNode_41 0 [0, 1] [160, 463] 164 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 82 ++ c0 82 := (c4 82 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([160, 463] : List Tid), ∀ row ∈ c0 82, tid ∉ row.1.outs
    decide
#print axioms outputProjectionExchangeRead_pm_164
theorem outputProjectionExchangeRead_pm_467 :
    t 467 = c5 2 1 1 2 (([160, 463] : List Tid).map t) := by
  apply vP6 (c1 85) (c0 86) pmNode_277 1 [0, 1] [160, 463] 467 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 85 ++ c0 85 := (c4 85 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([160, 463] : List Tid), ∀ row ∈ c0 85, tid ∉ row.1.outs
    decide
#print axioms outputProjectionExchangeRead_pm_467
end RBS_81
theorem outputProjectionExchangeUnitFacts_1286_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1286).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 164, q 467], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1286) = c8 2 2 0 [q 164, q 467] := by
  have predecessor := outputProjectionUnitFacts_1286_0 s p t q hs hp hvalues
  have outputs : [q 164, q 467] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 2 [q 160, q 463]) := by
    change [q 164, q 467] = [c5 2 0 1 2 [q 160, q 463], c5 2 1 1 2 [q 160, q 463]]
    exact c13 c20 (outputProjectionExchangeRead_pm_164 p q hp) (c13 c20 (outputProjectionExchangeRead_pm_467 p q hp) (rfl))
  exact SourceSequenceHiddenExchange.output_facts 2 0 2 1 8 32 (t 1286) [q 160, q 463] [q 164, q 467]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms outputProjectionExchangeUnitFacts_1286_0
section RBS_82
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem outputProjectionExchangeRead_pm_770 :
    t 770 = c5 2 0 1 2 (([766, 1069] : List Tid).map t) := by
  apply vP6 (c1 504) (c0 505) pmNode_513 2 [2, 3] [766, 1069] 770 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 504 ++ c0 504 := (c4 504 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([766, 1069] : List Tid), ∀ row ∈ c0 504, tid ∉ row.1.outs
    decide
#print axioms outputProjectionExchangeRead_pm_770
theorem outputProjectionExchangeRead_pm_1073 :
    t 1073 = c5 2 1 1 2 (([766, 1069] : List Tid).map t) := by
  apply vP6 (c1 507) (c0 508) pmNode_749 3 [2, 3] [766, 1069] 1073 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 507 ++ c0 507 := (c4 507 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([766, 1069] : List Tid), ∀ row ∈ c0 507, tid ∉ row.1.outs
    decide
#print axioms outputProjectionExchangeRead_pm_1073
end RBS_82
theorem outputProjectionExchangeUnitFacts_1286_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1286).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 770, q 1073], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1286) = c8 2 2 0 [q 770, q 1073] := by
  have predecessor := outputProjectionUnitFacts_1286_1 s p t q hs hp hvalues
  have outputs : [q 770, q 1073] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 2 [q 766, q 1069]) := by
    change [q 770, q 1073] = [c5 2 0 1 2 [q 766, q 1069], c5 2 1 1 2 [q 766, q 1069]]
    exact c13 c20 (outputProjectionExchangeRead_pm_770 p q hp) (c13 c20 (outputProjectionExchangeRead_pm_1073 p q hp) (rfl))
  exact SourceSequenceHiddenExchange.output_facts 2 1 2 1 8 32 (t 1286) [q 766, q 1069] [q 770, q 1073]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms outputProjectionExchangeUnitFacts_1286_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, integration and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem attentionResidualAliasFacts_1377_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1377).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 163, q 466], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1377) = c8 2 2 0 [q 163, q 466] := by
  rw [postAddMultirefRead_sm_1376 s t hs 1377 (c12 _ c6), postAddMultirefRead_pm_283 p q hp 163 (c12 _ c6), postAddMultirefRead_pm_586 p q hp 466 (c12 _ c6)]
  exact addUnitFacts_1267_0 s p t q hs hp hvalues
#print axioms attentionResidualAliasFacts_1377_0
theorem attentionResidualRead_sm_1287 (s t : Store) (h : c11 s = some t) :
    t 1287 = elemwiseAdd (t 1377) (t 1286) := by
  apply vP3 (c18 25) (c10 26) smNode_25
    0 1377 1286 1287 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 25 ++ c10 25 := (c4 25 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 25, 1377 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 25, 1286 ∉ row.1.outs
    decide
#print axioms attentionResidualRead_sm_1287
section RBS_83
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem attentionResidualRead_pm_165 :
    t 165 = elemwiseAdd (t 163) (t 164) := by
  apply vP4 (c1 83) (c0 84) pmNode_42
    0 163 164 165 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 83 ++ c0 83 := (c4 83 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 83, 163 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 83, 164 ∉ row.1.outs
    decide
#print axioms attentionResidualRead_pm_165
theorem attentionResidualRead_pm_468 :
    t 468 = elemwiseAdd (t 466) (t 467) := by
  apply vP4 (c1 86) (c0 87) pmNode_278
    1 466 467 468 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 86 ++ c0 86 := (c4 86 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 86, 466 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 86, 467 ∉ row.1.outs
    decide
#print axioms attentionResidualRead_pm_468
end RBS_83
section RBS_84
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p)
include s p t q hs hp hvalues
theorem attentionResidualUnitFacts_1287_0 :
    (t 1287).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 165, q 468], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1287) = c8 2 2 0 [q 165, q 468] := by
  have a := attentionResidualAliasFacts_1377_0 s p t q hs hp hvalues
  have b := outputProjectionExchangeUnitFacts_1286_0 s p t q hs hp hvalues
  have localAdds : [q 165, q 468] = List.zipWith elemwiseAdd [q 163, q 466] [q 164, q 467] := by
    change [q 165, q 468] = [elemwiseAdd (q 163) (q 164), elemwiseAdd (q 466) (q 467)]
    exact c13 c20 (attentionResidualRead_pm_165 p q hp) (c13 c20 (attentionResidualRead_pm_468 p q hp) (rfl))
  exact c22 2 2 1 16 32 0
    (t 1377) (t 1286) (t 1287) [q 163, q 466] [q 164, q 467] [q 165, q 468]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    a.1 b.1 rfl rfl (fun r hr => a.2.1 _ (List.get_mem _ _))
    (fun r hr => b.2.1 _ (List.get_mem _ _)) a.2.2 b.2.2
    (attentionResidualRead_sm_1287 s t hs) localAdds
#print axioms attentionResidualUnitFacts_1287_0
theorem attentionResidualAliasFacts_1377_1 :
    (t 1377).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 769, q 1072], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1377) = c8 2 2 0 [q 769, q 1072] := by
  rw [postAddMultirefRead_sm_1376 s t hs 1377 (c12 _ c6), postAddMultirefRead_pm_889 p q hp 769 (c12 _ c6), postAddMultirefRead_pm_1192 p q hp 1072 (c12 _ c6)]
  exact addUnitFacts_1267_1 s p t q hs hp hvalues
#print axioms attentionResidualAliasFacts_1377_1
end RBS_84
section RBS_85
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem attentionResidualRead_pm_771 :
    t 771 = elemwiseAdd (t 769) (t 770) := by
  apply vP4 (c1 505) (c0 506) pmNode_514
    2 769 770 771 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 505 ++ c0 505 := (c4 505 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 505, 769 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 505, 770 ∉ row.1.outs
    decide
#print axioms attentionResidualRead_pm_771
theorem attentionResidualRead_pm_1074 :
    t 1074 = elemwiseAdd (t 1072) (t 1073) := by
  apply vP4 (c1 508) (c0 509) pmNode_750
    3 1072 1073 1074 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 508 ++ c0 508 := (c4 508 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 508, 1072 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 508, 1073 ∉ row.1.outs
    decide
#print axioms attentionResidualRead_pm_1074
end RBS_85
theorem attentionResidualUnitFacts_1287_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1287).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 771, q 1074], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1287) = c8 2 2 0 [q 771, q 1074] := by
  have a := attentionResidualAliasFacts_1377_1 s p t q hs hp hvalues
  have b := outputProjectionExchangeUnitFacts_1286_1 s p t q hs hp hvalues
  have localAdds : [q 771, q 1074] = List.zipWith elemwiseAdd [q 769, q 1072] [q 770, q 1073] := by
    change [q 771, q 1074] = [elemwiseAdd (q 769) (q 770), elemwiseAdd (q 1072) (q 1073)]
    exact c13 c20 (attentionResidualRead_pm_771 p q hp) (c13 c20 (attentionResidualRead_pm_1074 p q hp) (rfl))
  exact c22 2 2 1 16 32 1
    (t 1377) (t 1286) (t 1287) [q 769, q 1072] [q 770, q 1073] [q 771, q 1074]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    a.1 b.1 rfl rfl (fun r hr => a.2.1 _ (List.get_mem _ _))
    (fun r hr => b.2.1 _ (List.get_mem _ _)) a.2.2 b.2.2
    (attentionResidualRead_sm_1287 s t hs) localAdds
#print axioms attentionResidualUnitFacts_1287_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, integration, cost and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierMultirefRead_sm_1386 (s t : Store) (h : c11 s = some t) :
    ∀ output ∈ ([1386, 1387] : List Tid), t output = t 1287 := by
  intro output houtput
  apply vP7 (c18 26) (c10 27) smNode_26
    0 1287 [1386, 1387] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c9 = c18 26 ++ c10 26 := (c4 26 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 26, 1287 ∉ row.1.outs
    decide
#print axioms frontierMultirefRead_sm_1386
section RBS_86
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierMultirefRead_pm_289 :
    ∀ output ∈ ([289, 179] : List Tid), t output = t 165 := by
  intro output houtput
  apply vP8 (c1 84) (c0 85) pmNode_43
    0 165 [289, 179] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 84 ++ c0 84 := (c4 84 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 84, 165 ∉ row.1.outs
    decide
#print axioms frontierMultirefRead_pm_289
theorem frontierMultirefRead_pm_592 :
    ∀ output ∈ ([592, 482] : List Tid), t output = t 468 := by
  intro output houtput
  apply vP8 (c1 87) (c0 88) pmNode_279
    1 468 [592, 482] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 87 ++ c0 87 := (c4 87 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 87, 468 ∉ row.1.outs
    decide
#print axioms frontierMultirefRead_pm_592
end RBS_86
theorem frontierAliasFacts_1386_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1386).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 289, q 592], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1386) = c8 2 2 0 [q 289, q 592] := by
  rw [frontierMultirefRead_sm_1386 s t hs 1386 c6, frontierMultirefRead_pm_289 p q hp 289 c6, frontierMultirefRead_pm_592 p q hp 592 c6]
  exact attentionResidualUnitFacts_1287_0 s p t q hs hp hvalues
#print axioms frontierAliasFacts_1386_0
section RBS_87
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierAllToAllRead_pm_169 :
    t 169 = c5 2 0 2 1 (([289, 592] : List Tid).map t) := by
  apply vP6 (c1 88) (c0 89) pmNode_44 0 [0, 1] [289, 592] 169 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 88 ++ c0 88 := (c4 88 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([289, 592] : List Tid), ∀ row ∈ c0 88, tid ∉ row.1.outs
    decide
#print axioms frontierAllToAllRead_pm_169
theorem frontierAllToAllRead_pm_472 :
    t 472 = c5 2 1 2 1 (([289, 592] : List Tid).map t) := by
  apply vP6 (c1 93) (c0 94) pmNode_280 1 [0, 1] [289, 592] 472 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 93 ++ c0 93 := (c4 93 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([289, 592] : List Tid), ∀ row ∈ c0 93, tid ∉ row.1.outs
    decide
#print axioms frontierAllToAllRead_pm_472
end RBS_87
section RBS_88
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p)
include s p t q hs hp hvalues
theorem frontierExchangeFacts_1386_0 :
    (t 1386).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 169, q 472], y.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1386) = c8 1 2 0 [q 169, q 472] := by
  have predecessor := frontierAliasFacts_1386_0 s p t q hs hp hvalues
  have outputs : [q 169, q 472] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 289, q 592]) := by
    change [q 169, q 472] = [c5 2 0 2 1 [q 289, q 592], c5 2 1 2 1 [q 289, q 592]]
    exact c13 c20 (frontierAllToAllRead_pm_169 p q hp) (c13 c20 (frontierAllToAllRead_pm_472 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 0 2 1 8 32 (t 1386) [q 289, q 592] [q 169, q 472]
    (by decide) (by decide) (by decide) (by decide)
    rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierExchangeFacts_1386_0
theorem frontierAliasFacts_1387_0 :
    (t 1387).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 179, q 482], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1387) = c8 2 2 0 [q 179, q 482] := by
  rw [frontierMultirefRead_sm_1386 s t hs 1387 (c12 _ c6), frontierMultirefRead_pm_289 p q hp 179 (c12 _ c6), frontierMultirefRead_pm_592 p q hp 482 (c12 _ c6)]
  exact attentionResidualUnitFacts_1287_0 s p t q hs hp hvalues
#print axioms frontierAliasFacts_1387_0
end RBS_88
section RBS_89
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierMultirefRead_pm_895 :
    ∀ output ∈ ([895, 785] : List Tid), t output = t 771 := by
  intro output houtput
  apply vP8 (c1 506) (c0 507) pmNode_515
    2 771 [895, 785] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 506 ++ c0 506 := (c4 506 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 506, 771 ∉ row.1.outs
    decide
#print axioms frontierMultirefRead_pm_895
theorem frontierMultirefRead_pm_1198 :
    ∀ output ∈ ([1198, 1088] : List Tid), t output = t 1074 := by
  intro output houtput
  apply vP8 (c1 509) (c0 510) pmNode_751
    3 1074 [1198, 1088] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 509 ++ c0 509 := (c4 509 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 509, 1074 ∉ row.1.outs
    decide
#print axioms frontierMultirefRead_pm_1198
end RBS_89
theorem frontierAliasFacts_1386_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1386).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 895, q 1198], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1386) = c8 2 2 0 [q 895, q 1198] := by
  rw [frontierMultirefRead_sm_1386 s t hs 1386 c6, frontierMultirefRead_pm_895 p q hp 895 c6, frontierMultirefRead_pm_1198 p q hp 1198 c6]
  exact attentionResidualUnitFacts_1287_1 s p t q hs hp hvalues
#print axioms frontierAliasFacts_1386_1
section RBS_90
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierAllToAllRead_pm_775 :
    t 775 = c5 2 0 2 1 (([895, 1198] : List Tid).map t) := by
  apply vP6 (c1 510) (c0 511) pmNode_516 2 [2, 3] [895, 1198] 775 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 510 ++ c0 510 := (c4 510 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([895, 1198] : List Tid), ∀ row ∈ c0 510, tid ∉ row.1.outs
    decide
#print axioms frontierAllToAllRead_pm_775
theorem frontierAllToAllRead_pm_1078 :
    t 1078 = c5 2 1 2 1 (([895, 1198] : List Tid).map t) := by
  apply vP6 (c1 515) (c0 516) pmNode_752 3 [2, 3] [895, 1198] 1078 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 515 ++ c0 515 := (c4 515 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([895, 1198] : List Tid), ∀ row ∈ c0 515, tid ∉ row.1.outs
    decide
#print axioms frontierAllToAllRead_pm_1078
end RBS_90
section RBS_91
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p)
include s p t q hs hp hvalues
theorem frontierExchangeFacts_1386_1 :
    (t 1386).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 775, q 1078], y.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1386) = c8 1 2 0 [q 775, q 1078] := by
  have predecessor := frontierAliasFacts_1386_1 s p t q hs hp hvalues
  have outputs : [q 775, q 1078] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 895, q 1198]) := by
    change [q 775, q 1078] = [c5 2 0 2 1 [q 895, q 1198], c5 2 1 2 1 [q 895, q 1198]]
    exact c13 c20 (frontierAllToAllRead_pm_775 p q hp) (c13 c20 (frontierAllToAllRead_pm_1078 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 1 2 1 8 32 (t 1386) [q 895, q 1198] [q 775, q 1078]
    (by decide) (by decide) (by decide) (by decide)
    rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierExchangeFacts_1386_1
theorem frontierAliasFacts_1387_1 :
    (t 1387).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 785, q 1088], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1387) = c8 2 2 0 [q 785, q 1088] := by
  rw [frontierMultirefRead_sm_1386 s t hs 1387 (c12 _ c6), frontierMultirefRead_pm_895 p q hp 785 (c12 _ c6), frontierMultirefRead_pm_1198 p q hp 1088 (c12 _ c6)]
  exact attentionResidualUnitFacts_1287_1 s p t q hs hp hvalues
#print axioms frontierAliasFacts_1387_1
end RBS_91
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, predecessors, frame, costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierLayernormRead_sm_1288 (s t : Store) (h : c11 s = some t) :
    t 1288 = c17 (t 1386) (t 1220) (t 1221) := by
  apply vP10 (c18 27) (c10 28) smNode_27
    0 1386 1220 1221 1288 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c9 = c18 27 ++ c10 27 := (c4 27 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 27, 1386 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 27, 1220 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 27, 1221 ∉ row.1.outs
    decide
#print axioms frontierLayernormRead_sm_1288
section RBS_92
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierLayernormRead_pm_170 :
    t 170 = c17 (t 169) (t 5) (t 6) := by
  apply vP11 (c1 89) (c0 90) pmNode_45
    0 169 5 6 170 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 89 ++ c0 89 := (c4 89 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 89, 169 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 89, 5 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 89, 6 ∉ row.1.outs
    decide
#print axioms frontierLayernormRead_pm_170
theorem frontierLayernormRead_pm_473 :
    t 473 = c17 (t 472) (t 308) (t 309) := by
  apply vP11 (c1 94) (c0 95) pmNode_281
    1 472 308 309 473 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 94 ++ c0 94 := (c4 94 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 94, 472 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 94, 308 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 94, 309 ∉ row.1.outs
    decide
#print axioms frontierLayernormRead_pm_473
end RBS_92
theorem frontierLayernormUnitFacts_1288_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1288).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 170, q 473], y.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1288) = c8 1 2 0 [q 170, q 473] := by
  have predecessor := frontierExchangeFacts_1386_0 s p t q hs hp h
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have gammaRel : c16 (t 1220) [q 5, q 308] [64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have betaRel : c16 (t 1221) [q 6, q 309] [64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 : q 170 = c17 (q 169) (t 1220) (t 1221) :=
    (frontierLayernormRead_pm_170 p q hp).trans
      (c13 (fun g b => c17 (q 169) g b)
        (gammaRel.replica_values (q 5) c6)
        (betaRel.replica_values (q 6) c6))
  have local1 : q 473 = c17 (q 472) (t 1220) (t 1221) :=
    (frontierLayernormRead_pm_473 p q hp).trans
      (c13 (fun g b => c17 (q 472) g b)
        (gammaRel.replica_values (q 308) (c12 _ c6))
        (betaRel.replica_values (q 309) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = c17 x (t 1220) (t 1221)) [q 169, q 472] [q 170, q 473] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_layernorm_unit_output_reconstruct 2 2 1 8 64 0
    (t 1386) (t 1220) (t 1221) (t 1288) [q 169, q 472] [q 170, q 473]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 gammaRel.full_shape betaRel.full_shape predecessor.2.2
    (frontierLayernormRead_sm_1288 s t hs) localReads
#print axioms frontierLayernormUnitFacts_1288_0
section RBS_93
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierLayernormRead_pm_776 :
    t 776 = c17 (t 775) (t 611) (t 612) := by
  apply vP11 (c1 511) (c0 512) pmNode_517
    2 775 611 612 776 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 511 ++ c0 511 := (c4 511 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 511, 775 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 511, 611 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 511, 612 ∉ row.1.outs
    decide
#print axioms frontierLayernormRead_pm_776
theorem frontierLayernormRead_pm_1079 :
    t 1079 = c17 (t 1078) (t 914) (t 915) := by
  apply vP11 (c1 516) (c0 517) pmNode_753
    3 1078 914 915 1079 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 516 ++ c0 516 := (c4 516 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 516, 1078 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 516, 914 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 516, 915 ∉ row.1.outs
    decide
#print axioms frontierLayernormRead_pm_1079
end RBS_93
theorem frontierLayernormUnitFacts_1288_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1288).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 776, q 1079], y.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1288) = c8 1 2 0 [q 776, q 1079] := by
  have predecessor := frontierExchangeFacts_1386_1 s p t q hs hp h
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have gammaRel : c16 (t 1220) [q 611, q 914] [64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have betaRel : c16 (t 1221) [q 612, q 915] [64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 : q 776 = c17 (q 775) (t 1220) (t 1221) :=
    (frontierLayernormRead_pm_776 p q hp).trans
      (c13 (fun g b => c17 (q 775) g b)
        (gammaRel.replica_values (q 611) c6)
        (betaRel.replica_values (q 612) c6))
  have local1 : q 1079 = c17 (q 1078) (t 1220) (t 1221) :=
    (frontierLayernormRead_pm_1079 p q hp).trans
      (c13 (fun g b => c17 (q 1078) g b)
        (gammaRel.replica_values (q 914) (c12 _ c6))
        (betaRel.replica_values (q 915) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = c17 x (t 1220) (t 1221)) [q 775, q 1078] [q 776, q 1079] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_layernorm_unit_output_reconstruct 2 2 1 8 64 1
    (t 1386) (t 1220) (t 1221) (t 1288) [q 775, q 1078] [q 776, q 1079]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 gammaRel.full_shape betaRel.full_shape predecessor.2.2
    (frontierLayernormRead_sm_1288 s t hs) localReads
#print axioms frontierLayernormUnitFacts_1288_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, predecessors, frame, costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierLinearRead_sm_1289 (s t : Store) (h : c11 s = some t) :
    t 1289 = fw_linear (t 1288) (t 1222) := by
  apply vP16 (c18 28) (c10 29) smNode_28
    0 1288 1222 1289 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 28 ++ c10 28 := (c4 28 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 28, 1288 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 28, 1222 ∉ row.1.outs
    decide
#print axioms frontierLinearRead_sm_1289
section RBS_94
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierLinearRead_pm_173 :
    t 173 = fw_linear (t 170) (t 7) := by
  apply vP17 (c1 90) (c0 91) pmNode_46
    0 170 7 173 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 90 ++ c0 90 := (c4 90 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 90, 170 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 90, 7 ∉ row.1.outs
    decide
#print axioms frontierLinearRead_pm_173
theorem frontierLinearRead_pm_476 :
    t 476 = fw_linear (t 473) (t 310) := by
  apply vP17 (c1 95) (c0 96) pmNode_282
    1 473 310 476 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 95 ++ c0 95 := (c4 95 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 95, 473 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 95, 310 ∉ row.1.outs
    decide
#print axioms frontierLinearRead_pm_476
end RBS_94
theorem frontierLinearUnitFacts_1289_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1289).shape = [2, 16, 256] ∧
    (∀ y ∈ [q 173, q 476], y.shape = [1, 8, 256]) ∧
    c3 0 2 0 (t 1289) = c8 1 2 0 [q 173, q 476] := by
  have predecessor := frontierLayernormUnitFacts_1288_0 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : c16 (t 1222) [q 7, q 310] [256, 64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 : q 173 = fw_linear (q 170) (t 1222) :=
    (frontierLinearRead_pm_173 p q hp).trans (congrArg (fw_linear (q 170))
      (weightRel.replica_values (q 7) c6))
  have local1 : q 476 = fw_linear (q 473) (t 1222) :=
    (frontierLinearRead_pm_476 p q hp).trans (congrArg (fw_linear (q 473))
      (weightRel.replica_values (q 310) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = fw_linear x (t 1222)) [q 170, q 473] [q 173, q 476] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_sequence_unit_output_reconstruct 2 2 1 8 64 256 0
    (t 1288) (t 1222) (t 1289) [q 170, q 473] [q 173, q 476]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 weightRel.full_shape predecessor.2.2
    (frontierLinearRead_sm_1289 s t hs) localReads
#print axioms frontierLinearUnitFacts_1289_0
section RBS_95
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierLinearRead_pm_779 :
    t 779 = fw_linear (t 776) (t 613) := by
  apply vP17 (c1 512) (c0 513) pmNode_518
    2 776 613 779 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 512 ++ c0 512 := (c4 512 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 512, 776 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 512, 613 ∉ row.1.outs
    decide
#print axioms frontierLinearRead_pm_779
theorem frontierLinearRead_pm_1082 :
    t 1082 = fw_linear (t 1079) (t 916) := by
  apply vP17 (c1 517) (c0 518) pmNode_754
    3 1079 916 1082 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 517 ++ c0 517 := (c4 517 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 517, 1079 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 517, 916 ∉ row.1.outs
    decide
#print axioms frontierLinearRead_pm_1082
end RBS_95
theorem frontierLinearUnitFacts_1289_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1289).shape = [2, 16, 256] ∧
    (∀ y ∈ [q 779, q 1082], y.shape = [1, 8, 256]) ∧
    c3 0 2 1 (t 1289) = c8 1 2 0 [q 779, q 1082] := by
  have predecessor := frontierLayernormUnitFacts_1288_1 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : c16 (t 1222) [q 613, q 916] [256, 64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 : q 779 = fw_linear (q 776) (t 1222) :=
    (frontierLinearRead_pm_779 p q hp).trans (congrArg (fw_linear (q 776))
      (weightRel.replica_values (q 613) c6))
  have local1 : q 1082 = fw_linear (q 1079) (t 1222) :=
    (frontierLinearRead_pm_1082 p q hp).trans (congrArg (fw_linear (q 1079))
      (weightRel.replica_values (q 916) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = fw_linear x (t 1222)) [q 776, q 1079] [q 779, q 1082] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_sequence_unit_output_reconstruct 2 2 1 8 64 256 1
    (t 1288) (t 1222) (t 1289) [q 776, q 1079] [q 779, q 1082]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 weightRel.full_shape predecessor.2.2
    (frontierLinearRead_sm_1289 s t hs) localReads
#print axioms frontierLinearUnitFacts_1289_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, predecessors, frame, costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierGeluRead_sm_1290 (s t : Store) (h : c11 s = some t) :
    t 1290 = fw_gelu (t 1289) := by
  apply SourceGeluRead.gelu_value_of_split smGraph smScope smPeers smGraph.nodes
    c9 (c18 29) (c10 30) smNode_29
    0 1289 1290 s t rfl ?_ rfl ?_ h
  · calc
      c9 = c18 29 ++ c10 29 := (c4 29 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 29, 1289 ∉ row.1.outs
    decide
#print axioms frontierGeluRead_sm_1290
section RBS_96
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierGeluRead_pm_175 :
    t 175 = fw_gelu (t 173) := by
  apply SourceGeluRead.gelu_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 91) (c0 92) pmNode_47
    0 173 175 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 91 ++ c0 91 := (c4 91 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 91, 173 ∉ row.1.outs
    decide
#print axioms frontierGeluRead_pm_175
theorem frontierGeluRead_pm_478 :
    t 478 = fw_gelu (t 476) := by
  apply SourceGeluRead.gelu_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 96) (c0 97) pmNode_283
    1 476 478 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 96 ++ c0 96 := (c4 96 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 96, 476 ∉ row.1.outs
    decide
#print axioms frontierGeluRead_pm_478
end RBS_96
theorem frontierGeluUnitFacts_1290_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1290).shape = [2, 16, 256] ∧
    (∀ y ∈ [q 175, q 478], y.shape = [1, 8, 256]) ∧
    c3 0 2 0 (t 1290) = c8 1 2 0 [q 175, q 478] := by
  have predecessor := frontierLinearUnitFacts_1289_0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_gelu x) [q 173, q 476] [q 175, q 478] :=
    c15 (frontierGeluRead_pm_175 p q hp) (c15 (frontierGeluRead_pm_478 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_gelu_unit_output_reconstruct 2 2 1 8 256 0
    (t 1289) (t 1290) [q 173, q 476] [q 175, q 478]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2
    (frontierGeluRead_sm_1290 s t hs) localReads
#print axioms frontierGeluUnitFacts_1290_0
section RBS_97
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierGeluRead_pm_781 :
    t 781 = fw_gelu (t 779) := by
  apply SourceGeluRead.gelu_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 513) (c0 514) pmNode_519
    2 779 781 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 513 ++ c0 513 := (c4 513 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 513, 779 ∉ row.1.outs
    decide
#print axioms frontierGeluRead_pm_781
theorem frontierGeluRead_pm_1084 :
    t 1084 = fw_gelu (t 1082) := by
  apply SourceGeluRead.gelu_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    c2 (c1 518) (c0 519) pmNode_755
    3 1082 1084 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 518 ++ c0 518 := (c4 518 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 518, 1082 ∉ row.1.outs
    decide
#print axioms frontierGeluRead_pm_1084
end RBS_97
theorem frontierGeluUnitFacts_1290_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1290).shape = [2, 16, 256] ∧
    (∀ y ∈ [q 781, q 1084], y.shape = [1, 8, 256]) ∧
    c3 0 2 1 (t 1290) = c8 1 2 0 [q 781, q 1084] := by
  have predecessor := frontierLinearUnitFacts_1289_1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_gelu x) [q 779, q 1082] [q 781, q 1084] :=
    c15 (frontierGeluRead_pm_781 p q hp) (c15 (frontierGeluRead_pm_1084 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_gelu_unit_output_reconstruct 2 2 1 8 256 1
    (t 1289) (t 1290) [q 779, q 1082] [q 781, q 1084]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2
    (frontierGeluRead_sm_1290 s t hs) localReads
#print axioms frontierGeluUnitFacts_1290_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, predecessors, frame, costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierLinearRead_sm_1291 (s t : Store) (h : c11 s = some t) :
    t 1291 = fw_linear (t 1290) (t 1223) := by
  apply vP16 (c18 30) (c10 31) smNode_30
    0 1290 1223 1291 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 30 ++ c10 30 := (c4 30 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 30, 1290 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 30, 1223 ∉ row.1.outs
    decide
#print axioms frontierLinearRead_sm_1291
section RBS_98
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierLinearRead_pm_177 :
    t 177 = fw_linear (t 175) (t 8) := by
  apply vP17 (c1 92) (c0 93) pmNode_48
    0 175 8 177 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 92 ++ c0 92 := (c4 92 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 92, 175 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 92, 8 ∉ row.1.outs
    decide
#print axioms frontierLinearRead_pm_177
theorem frontierLinearRead_pm_480 :
    t 480 = fw_linear (t 478) (t 311) := by
  apply vP17 (c1 97) (c0 98) pmNode_284
    1 478 311 480 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 97 ++ c0 97 := (c4 97 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 97, 478 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 97, 311 ∉ row.1.outs
    decide
#print axioms frontierLinearRead_pm_480
end RBS_98
theorem frontierLinearUnitFacts_1291_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1291).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 177, q 480], y.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1291) = c8 1 2 0 [q 177, q 480] := by
  have predecessor := frontierGeluUnitFacts_1290_0 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : c16 (t 1223) [q 8, q 311] [64, 256] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 : q 177 = fw_linear (q 175) (t 1223) :=
    (frontierLinearRead_pm_177 p q hp).trans (congrArg (fw_linear (q 175))
      (weightRel.replica_values (q 8) c6))
  have local1 : q 480 = fw_linear (q 478) (t 1223) :=
    (frontierLinearRead_pm_480 p q hp).trans (congrArg (fw_linear (q 478))
      (weightRel.replica_values (q 311) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = fw_linear x (t 1223)) [q 175, q 478] [q 177, q 480] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_sequence_unit_output_reconstruct 2 2 1 8 256 64 0
    (t 1290) (t 1223) (t 1291) [q 175, q 478] [q 177, q 480]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 weightRel.full_shape predecessor.2.2
    (frontierLinearRead_sm_1291 s t hs) localReads
#print axioms frontierLinearUnitFacts_1291_0
section RBS_99
variable (s t : Store) (h : c7 s = some t)
include s t h
theorem frontierLinearRead_pm_783 :
    t 783 = fw_linear (t 781) (t 614) := by
  apply vP17 (c1 514) (c0 515) pmNode_520
    2 781 614 783 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 514 ++ c0 514 := (c4 514 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 514, 781 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 514, 614 ∉ row.1.outs
    decide
#print axioms frontierLinearRead_pm_783
theorem frontierLinearRead_pm_1086 :
    t 1086 = fw_linear (t 1084) (t 917) := by
  apply vP17 (c1 519) (c0 520) pmNode_756
    3 1084 917 1086 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 519 ++ c0 519 := (c4 519 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 519, 1084 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 519, 917 ∉ row.1.outs
    decide
#print axioms frontierLinearRead_pm_1086
end RBS_99
theorem frontierLinearUnitFacts_1291_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1291).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 783, q 1086], y.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1291) = c8 1 2 0 [q 783, q 1086] := by
  have predecessor := frontierGeluUnitFacts_1290_1 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : c16 (t 1223) [q 614, q 917] [64, 256] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 : q 783 = fw_linear (q 781) (t 1223) :=
    (frontierLinearRead_pm_783 p q hp).trans (congrArg (fw_linear (q 781))
      (weightRel.replica_values (q 614) c6))
  have local1 : q 1086 = fw_linear (q 1084) (t 1223) :=
    (frontierLinearRead_pm_1086 p q hp).trans (congrArg (fw_linear (q 1084))
      (weightRel.replica_values (q 917) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = fw_linear x (t 1223)) [q 781, q 1084] [q 783, q 1086] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_sequence_unit_output_reconstruct 2 2 1 8 256 64 1
    (t 1290) (t 1223) (t 1291) [q 781, q 1084] [q 783, q 1086]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 weightRel.full_shape predecessor.2.2
    (frontierLinearRead_sm_1291 s t hs) localReads
#print axioms frontierLinearUnitFacts_1291_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, predecessors, frame, costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierSequenceHiddenRead_pm_180 (s t : Store) (h : c7 s = some t) :
    t 180 = c5 2 0 1 2 (([177, 480] : List Tid).map t) := by
  apply vP6 (c1 98) (c0 99) pmNode_49 0 [0, 1] [177, 480] 180 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 98 ++ c0 98 := (c4 98 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([177, 480] : List Tid), ∀ row ∈ c0 98, tid ∉ row.1.outs
    decide
#print axioms frontierSequenceHiddenRead_pm_180
theorem frontierSequenceHiddenRead_pm_483 (s t : Store) (h : c7 s = some t) :
    t 483 = c5 2 1 1 2 (([177, 480] : List Tid).map t) := by
  apply vP6 (c1 101) (c0 102) pmNode_285 1 [0, 1] [177, 480] 483 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 101 ++ c0 101 := (c4 101 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([177, 480] : List Tid), ∀ row ∈ c0 101, tid ∉ row.1.outs
    decide
#print axioms frontierSequenceHiddenRead_pm_483
theorem frontierSequenceHiddenUnitFacts_1291_0_180_483 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1291).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 180, q 483], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1291) = c8 2 2 0 [q 180, q 483] := by
  have predecessor := frontierLinearUnitFacts_1291_0 s p t q hs hp hvalues
  have outputs : [q 180, q 483] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 2 [q 177, q 480]) := by
    change [q 180, q 483] = [c5 2 0 1 2 [q 177, q 480], c5 2 1 1 2 [q 177, q 480]]
    exact c13 c20 (frontierSequenceHiddenRead_pm_180 p q hp) (c13 c20 (frontierSequenceHiddenRead_pm_483 p q hp) (rfl))
  exact SourceSequenceHiddenExchange.output_facts 2 0 2 1 8 32 (t 1291) [q 177, q 480] [q 180, q 483]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierSequenceHiddenUnitFacts_1291_0_180_483
theorem frontierSequenceHiddenRead_pm_786 (s t : Store) (h : c7 s = some t) :
    t 786 = c5 2 0 1 2 (([783, 1086] : List Tid).map t) := by
  apply vP6 (c1 520) (c0 521) pmNode_521 2 [2, 3] [783, 1086] 786 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 520 ++ c0 520 := (c4 520 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([783, 1086] : List Tid), ∀ row ∈ c0 520, tid ∉ row.1.outs
    decide
#print axioms frontierSequenceHiddenRead_pm_786
theorem frontierSequenceHiddenRead_pm_1089 (s t : Store) (h : c7 s = some t) :
    t 1089 = c5 2 1 1 2 (([783, 1086] : List Tid).map t) := by
  apply vP6 (c1 523) (c0 524) pmNode_757 3 [2, 3] [783, 1086] 1089 1 2 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 523 ++ c0 523 := (c4 523 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([783, 1086] : List Tid), ∀ row ∈ c0 523, tid ∉ row.1.outs
    decide
#print axioms frontierSequenceHiddenRead_pm_1089
theorem frontierSequenceHiddenUnitFacts_1291_1_786_1089 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1291).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 786, q 1089], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1291) = c8 2 2 0 [q 786, q 1089] := by
  have predecessor := frontierLinearUnitFacts_1291_1 s p t q hs hp hvalues
  have outputs : [q 786, q 1089] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 1 2 [q 783, q 1086]) := by
    change [q 786, q 1089] = [c5 2 0 1 2 [q 783, q 1086], c5 2 1 1 2 [q 783, q 1086]]
    exact c13 c20 (frontierSequenceHiddenRead_pm_786 p q hp) (c13 c20 (frontierSequenceHiddenRead_pm_1089 p q hp) (rfl))
  exact SourceSequenceHiddenExchange.output_facts 2 1 2 1 8 32 (t 1291) [q 783, q 1086] [q 786, q 1089]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierSequenceHiddenUnitFacts_1291_1_786_1089
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, predecessors, frame, costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierAddRead_sm_1292 (s t : Store) (h : c11 s = some t) :
    t 1292 = elemwiseAdd (t 1387) (t 1291) := by
  apply vP3 (c18 31) (c10 32) smNode_31
    0 1387 1291 1292 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c9 = c18 31 ++ c10 31 := (c4 31 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 31, 1387 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 31, 1291 ∉ row.1.outs
    decide
#print axioms frontierAddRead_sm_1292
theorem frontierAddRead_pm_181 (s t : Store) (h : c7 s = some t) :
    t 181 = elemwiseAdd (t 179) (t 180) := by
  apply vP4 (c1 99) (c0 100) pmNode_50
    0 179 180 181 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 99 ++ c0 99 := (c4 99 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 99, 179 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 99, 180 ∉ row.1.outs
    decide
#print axioms frontierAddRead_pm_181
theorem frontierAddRead_pm_484 (s t : Store) (h : c7 s = some t) :
    t 484 = elemwiseAdd (t 482) (t 483) := by
  apply vP4 (c1 102) (c0 103) pmNode_286
    1 482 483 484 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 102 ++ c0 102 := (c4 102 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 102, 482 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 102, 483 ∉ row.1.outs
    decide
#print axioms frontierAddRead_pm_484
theorem frontierAddUnitFacts_1292_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1292).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 181, q 484], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1292) = c8 2 2 0 [q 181, q 484] := by
  have a := frontierAliasFacts_1387_0 s p t q hs hp hvalues
  have b := frontierSequenceHiddenUnitFacts_1291_0_180_483 s p t q hs hp hvalues
  have localAdds : [q 181, q 484] = List.zipWith elemwiseAdd [q 179, q 482] [q 180, q 483] := by
    change [q 181, q 484] = [elemwiseAdd (q 179) (q 180), elemwiseAdd (q 482) (q 483)]
    exact c13 c20 (frontierAddRead_pm_181 p q hp) (c13 c20 (frontierAddRead_pm_484 p q hp) (rfl))
  exact c22 2 2 1 16 32 0
    (t 1387) (t 1291) (t 1292) [q 179, q 482] [q 180, q 483] [q 181, q 484]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    a.1 b.1 rfl rfl (fun r hr => a.2.1 _ (List.get_mem _ _))
    (fun r hr => b.2.1 _ (List.get_mem _ _)) a.2.2 b.2.2
    (frontierAddRead_sm_1292 s t hs) localAdds
#print axioms frontierAddUnitFacts_1292_0
theorem frontierAddRead_pm_787 (s t : Store) (h : c7 s = some t) :
    t 787 = elemwiseAdd (t 785) (t 786) := by
  apply vP4 (c1 521) (c0 522) pmNode_522
    2 785 786 787 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 521 ++ c0 521 := (c4 521 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 521, 785 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 521, 786 ∉ row.1.outs
    decide
#print axioms frontierAddRead_pm_787
theorem frontierAddRead_pm_1090 (s t : Store) (h : c7 s = some t) :
    t 1090 = elemwiseAdd (t 1088) (t 1089) := by
  apply vP4 (c1 524) (c0 525) pmNode_758
    3 1088 1089 1090 s t rfl ?_ rfl ?_ ?_ h
  · calc
      c2 = c1 524 ++ c0 524 := (c4 524 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 524, 1088 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 524, 1089 ∉ row.1.outs
    decide
#print axioms frontierAddRead_pm_1090
theorem frontierAddUnitFacts_1292_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1292).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 787, q 1090], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1292) = c8 2 2 0 [q 787, q 1090] := by
  have a := frontierAliasFacts_1387_1 s p t q hs hp hvalues
  have b := frontierSequenceHiddenUnitFacts_1291_1_786_1089 s p t q hs hp hvalues
  have localAdds : [q 787, q 1090] = List.zipWith elemwiseAdd [q 785, q 1088] [q 786, q 1089] := by
    change [q 787, q 1090] = [elemwiseAdd (q 785) (q 786), elemwiseAdd (q 1088) (q 1089)]
    exact c13 c20 (frontierAddRead_pm_787 p q hp) (c13 c20 (frontierAddRead_pm_1090 p q hp) (rfl))
  exact c22 2 2 1 16 32 1
    (t 1387) (t 1291) (t 1292) [q 785, q 1088] [q 786, q 1089] [q 787, q 1090]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    a.1 b.1 rfl rfl (fun r hr => a.2.1 _ (List.get_mem _ _))
    (fun r hr => b.2.1 _ (List.get_mem _ _)) a.2.2 b.2.2
    (frontierAddRead_sm_1292 s t hs) localAdds
#print axioms frontierAddUnitFacts_1292_1
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, integration, cost and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierMultirefRead_sm_1390 (s t : Store) (h : c11 s = some t) :
    ∀ output ∈ ([1390, 1391] : List Tid), t output = t 1292 := by
  intro output houtput
  apply vP7 (c18 32) (c10 33) smNode_32
    0 1292 [1390, 1391] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c9 = c18 32 ++ c10 32 := (c4 32 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 32, 1292 ∉ row.1.outs
    decide
#print axioms frontierMultirefRead_sm_1390
theorem frontierMultirefRead_pm_291 (s t : Store) (h : c7 s = some t) :
    ∀ output ∈ ([291, 252] : List Tid), t output = t 181 := by
  intro output houtput
  apply vP8 (c1 100) (c0 101) pmNode_51
    0 181 [291, 252] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 100 ++ c0 100 := (c4 100 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 100, 181 ∉ row.1.outs
    decide
#print axioms frontierMultirefRead_pm_291
theorem frontierMultirefRead_pm_594 (s t : Store) (h : c7 s = some t) :
    ∀ output ∈ ([594, 555] : List Tid), t output = t 484 := by
  intro output houtput
  apply vP8 (c1 103) (c0 104) pmNode_287
    1 484 [594, 555] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 103 ++ c0 103 := (c4 103 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 103, 484 ∉ row.1.outs
    decide
#print axioms frontierMultirefRead_pm_594
theorem frontierAliasFacts_1390_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1390).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 291, q 594], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1390) = c8 2 2 0 [q 291, q 594] := by
  rw [frontierMultirefRead_sm_1390 s t hs 1390 c6, frontierMultirefRead_pm_291 p q hp 291 c6, frontierMultirefRead_pm_594 p q hp 594 c6]
  exact frontierAddUnitFacts_1292_0 s p t q hs hp hvalues
#print axioms frontierAliasFacts_1390_0
theorem frontierAllToAllRead_pm_185 (s t : Store) (h : c7 s = some t) :
    t 185 = c5 2 0 2 1 (([291, 594] : List Tid).map t) := by
  apply vP6 (c1 104) (c0 105) pmNode_52 0 [0, 1] [291, 594] 185 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 104 ++ c0 104 := (c4 104 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([291, 594] : List Tid), ∀ row ∈ c0 104, tid ∉ row.1.outs
    decide
#print axioms frontierAllToAllRead_pm_185
theorem frontierAllToAllRead_pm_488 (s t : Store) (h : c7 s = some t) :
    t 488 = c5 2 1 2 1 (([291, 594] : List Tid).map t) := by
  apply vP6 (c1 107) (c0 108) pmNode_288 1 [0, 1] [291, 594] 488 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 107 ++ c0 107 := (c4 107 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([291, 594] : List Tid), ∀ row ∈ c0 107, tid ∉ row.1.outs
    decide
#print axioms frontierAllToAllRead_pm_488
section RBS_100
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p)
include s p t q hs hp hvalues
theorem frontierExchangeFacts_1390_0 :
    (t 1390).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 185, q 488], y.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1390) = c8 1 2 0 [q 185, q 488] := by
  have predecessor := frontierAliasFacts_1390_0 s p t q hs hp hvalues
  have outputs : [q 185, q 488] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 291, q 594]) := by
    change [q 185, q 488] = [c5 2 0 2 1 [q 291, q 594], c5 2 1 2 1 [q 291, q 594]]
    exact c13 c20 (frontierAllToAllRead_pm_185 p q hp) (c13 c20 (frontierAllToAllRead_pm_488 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 0 2 1 8 32 (t 1390) [q 291, q 594] [q 185, q 488]
    (by decide) (by decide) (by decide) (by decide)
    rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierExchangeFacts_1390_0
theorem frontierAliasFacts_1391_0 :
    (t 1391).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 252, q 555], y.shape = [1, 16, 32]) ∧
    c3 0 2 0 (t 1391) = c8 2 2 0 [q 252, q 555] := by
  rw [frontierMultirefRead_sm_1390 s t hs 1391 (c12 _ c6), frontierMultirefRead_pm_291 p q hp 252 (c12 _ c6), frontierMultirefRead_pm_594 p q hp 555 (c12 _ c6)]
  exact frontierAddUnitFacts_1292_0 s p t q hs hp hvalues
#print axioms frontierAliasFacts_1391_0
end RBS_100
theorem frontierMultirefRead_pm_897 (s t : Store) (h : c7 s = some t) :
    ∀ output ∈ ([897, 858] : List Tid), t output = t 787 := by
  intro output houtput
  apply vP8 (c1 522) (c0 523) pmNode_523
    2 787 [897, 858] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 522 ++ c0 522 := (c4 522 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 522, 787 ∉ row.1.outs
    decide
#print axioms frontierMultirefRead_pm_897
theorem frontierMultirefRead_pm_1200 (s t : Store) (h : c7 s = some t) :
    ∀ output ∈ ([1200, 1161] : List Tid), t output = t 1090 := by
  intro output houtput
  apply vP8 (c1 525) (c0 526) pmNode_759
    3 1090 [1200, 1161] output s t rfl ?_ rfl ?_ houtput h
  · calc
      c2 = c1 525 ++ c0 525 := (c4 525 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 525, 1090 ∉ row.1.outs
    decide
#print axioms frontierMultirefRead_pm_1200
theorem frontierAliasFacts_1390_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1390).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 897, q 1200], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1390) = c8 2 2 0 [q 897, q 1200] := by
  rw [frontierMultirefRead_sm_1390 s t hs 1390 c6, frontierMultirefRead_pm_897 p q hp 897 c6, frontierMultirefRead_pm_1200 p q hp 1200 c6]
  exact frontierAddUnitFacts_1292_1 s p t q hs hp hvalues
#print axioms frontierAliasFacts_1390_1
theorem frontierAllToAllRead_pm_791 (s t : Store) (h : c7 s = some t) :
    t 791 = c5 2 0 2 1 (([897, 1200] : List Tid).map t) := by
  apply vP6 (c1 526) (c0 527) pmNode_524 2 [2, 3] [897, 1200] 791 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 526 ++ c0 526 := (c4 526 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([897, 1200] : List Tid), ∀ row ∈ c0 526, tid ∉ row.1.outs
    decide
#print axioms frontierAllToAllRead_pm_791
theorem frontierAllToAllRead_pm_1094 (s t : Store) (h : c7 s = some t) :
    t 1094 = c5 2 1 2 1 (([897, 1200] : List Tid).map t) := by
  apply vP6 (c1 529) (c0 530) pmNode_760 3 [2, 3] [897, 1200] 1094 2 1 s t rfl ?_ rfl ?_ h
  · calc
      c2 = c1 529 ++ c0 529 := (c4 529 c2).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([897, 1200] : List Tid), ∀ row ∈ c0 529, tid ∉ row.1.outs
    decide
#print axioms frontierAllToAllRead_pm_1094
section RBS_101
variable (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (hvalues : InitialParameterValues s p)
include s p t q hs hp hvalues
theorem frontierExchangeFacts_1390_1 :
    (t 1390).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 791, q 1094], y.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1390) = c8 1 2 0 [q 791, q 1094] := by
  have predecessor := frontierAliasFacts_1390_1 s p t q hs hp hvalues
  have outputs : [q 791, q 1094] = List.ofFn (fun dst : Fin 2 => c5 2 dst.val 2 1 [q 897, q 1200]) := by
    change [q 791, q 1094] = [c5 2 0 2 1 [q 897, q 1200], c5 2 1 2 1 [q 897, q 1200]]
    exact c13 c20 (frontierAllToAllRead_pm_791 p q hp) (c13 c20 (frontierAllToAllRead_pm_1094 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 1 2 1 8 32 (t 1390) [q 897, q 1200] [q 791, q 1094]
    (by decide) (by decide) (by decide) (by decide)
    rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierExchangeFacts_1390_1
theorem frontierAliasFacts_1391_1 :
    (t 1391).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 858, q 1161], y.shape = [1, 16, 32]) ∧
    c3 0 2 1 (t 1391) = c8 2 2 0 [q 858, q 1161] := by
  rw [frontierMultirefRead_sm_1390 s t hs 1391 (c12 _ c6), frontierMultirefRead_pm_897 p q hp 858 (c12 _ c6), frontierMultirefRead_pm_1200 p q hp 1161 (c12 _ c6)]
  exact frontierAddUnitFacts_1292_1 s p t q hs hp hvalues
#print axioms frontierAliasFacts_1391_1
end RBS_101
end
end TrainVerify.Denote.RuntimeWorld

-- UNCOMPILED: parent owns imports, predecessors, frame, costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierLayernormRead_sm_1293 (s t : Store) (h : c11 s = some t) :
    t 1293 = c17 (t 1390) (t 1224) (t 1225) := by
  apply vP10 (c18 33) (c10 34) smNode_33
    0 1390 1224 1225 1293 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c9 = c18 33 ++ c10 33 := (c4 33 c9).symm
      _ = _ := rfl
  · change ∀ row ∈ c10 33, 1390 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 33, 1224 ∉ row.1.outs
    decide
  · change ∀ row ∈ c10 33, 1225 ∉ row.1.outs
    decide
#print axioms frontierLayernormRead_sm_1293
theorem frontierLayernormRead_pm_186 (s t : Store) (h : c7 s = some t) :
    t 186 = c17 (t 185) (t 9) (t 10) := by
  apply vP11 (c1 105) (c0 106) pmNode_53
    0 185 9 10 186 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 105 ++ c0 105 := (c4 105 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 105, 185 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 105, 9 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 105, 10 ∉ row.1.outs
    decide
#print axioms frontierLayernormRead_pm_186
theorem frontierLayernormRead_pm_489 (s t : Store) (h : c7 s = some t) :
    t 489 = c17 (t 488) (t 312) (t 313) := by
  apply vP11 (c1 108) (c0 109) pmNode_289
    1 488 312 313 489 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 108 ++ c0 108 := (c4 108 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 108, 488 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 108, 312 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 108, 313 ∉ row.1.outs
    decide
#print axioms frontierLayernormRead_pm_489
theorem frontierLayernormUnitFacts_1293_0 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1293).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 186, q 489], y.shape = [1, 8, 64]) ∧
    c3 0 2 0 (t 1293) = c8 1 2 0 [q 186, q 489] := by
  have predecessor := frontierExchangeFacts_1390_0 s p t q hs hp h
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have gammaRel : c16 (t 1224) [q 9, q 312] [64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have betaRel : c16 (t 1225) [q 10, q 313] [64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 : q 186 = c17 (q 185) (t 1224) (t 1225) :=
    (frontierLayernormRead_pm_186 p q hp).trans
      (c13 (fun g b => c17 (q 185) g b)
        (gammaRel.replica_values (q 9) c6)
        (betaRel.replica_values (q 10) c6))
  have local1 : q 489 = c17 (q 488) (t 1224) (t 1225) :=
    (frontierLayernormRead_pm_489 p q hp).trans
      (c13 (fun g b => c17 (q 488) g b)
        (gammaRel.replica_values (q 312) (c12 _ c6))
        (betaRel.replica_values (q 313) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = c17 x (t 1224) (t 1225)) [q 185, q 488] [q 186, q 489] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_layernorm_unit_output_reconstruct 2 2 1 8 64 0
    (t 1390) (t 1224) (t 1225) (t 1293) [q 185, q 488] [q 186, q 489]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 gammaRel.full_shape betaRel.full_shape predecessor.2.2
    (frontierLayernormRead_sm_1293 s t hs) localReads
#print axioms frontierLayernormUnitFacts_1293_0
theorem frontierLayernormRead_pm_792 (s t : Store) (h : c7 s = some t) :
    t 792 = c17 (t 791) (t 615) (t 616) := by
  apply vP11 (c1 527) (c0 528) pmNode_525
    2 791 615 616 792 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 527 ++ c0 527 := (c4 527 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 527, 791 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 527, 615 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 527, 616 ∉ row.1.outs
    decide
#print axioms frontierLayernormRead_pm_792
theorem frontierLayernormRead_pm_1095 (s t : Store) (h : c7 s = some t) :
    t 1095 = c17 (t 1094) (t 918) (t 919) := by
  apply vP11 (c1 530) (c0 531) pmNode_761
    3 1094 918 919 1095 s t rfl ?_ rfl ?_ ?_ ?_ h
  · calc
      c2 = c1 530 ++ c0 530 := (c4 530 c2).symm
      _ = _ := rfl
  · change ∀ row ∈ c0 530, 1094 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 530, 918 ∉ row.1.outs
    decide
  · change ∀ row ∈ c0 530, 919 ∉ row.1.outs
    decide
#print axioms frontierLayernormRead_pm_1095
theorem frontierLayernormUnitFacts_1293_1 (s p t q : Store)
    (hs : c11 s = some t) (hp : c7 p = some q)
    (h : InitialParameterValues s p) :
    (t 1293).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 792, q 1095], y.shape = [1, 8, 64]) ∧
    c3 0 2 1 (t 1293) = c8 1 2 0 [q 792, q 1095] := by
  have predecessor := frontierExchangeFacts_1390_1 s p t q hs hp h
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp h)
  have gammaRel : c16 (t 1224) [q 615, q 918] [64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have betaRel : c16 (t 1225) [q 616, q 919] [64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 : q 792 = c17 (q 791) (t 1224) (t 1225) :=
    (frontierLayernormRead_pm_792 p q hp).trans
      (c13 (fun g b => c17 (q 791) g b)
        (gammaRel.replica_values (q 615) c6)
        (betaRel.replica_values (q 616) c6))
  have local1 : q 1095 = c17 (q 1094) (t 1224) (t 1225) :=
    (frontierLayernormRead_pm_1095 p q hp).trans
      (c13 (fun g b => c17 (q 1094) g b)
        (gammaRel.replica_values (q 918) (c12 _ c6))
        (betaRel.replica_values (q 919) (c12 _ c6)))
  have localReads : List.Forall₂ (fun x y => y = c17 x (t 1224) (t 1225)) [q 791, q 1094] [q 792, q 1095] :=
    c15 local0 (c15 local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_layernorm_unit_output_reconstruct 2 2 1 8 64 1
    (t 1390) (t 1224) (t 1225) (t 1293) [q 791, q 1094] [q 792, q 1095]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 gammaRel.full_shape betaRel.full_shape predecessor.2.2
    (frontierLayernormRead_sm_1293 s t hs) localReads
#print axioms frontierLayernormUnitFacts_1293_1
end
end TrainVerify.Denote.RuntimeWorld
end RuntimeReadSource
