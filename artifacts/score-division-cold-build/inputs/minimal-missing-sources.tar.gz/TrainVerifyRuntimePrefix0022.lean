import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0021
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_166_0 (z : Store) : (s_166 z) 236 = (v_159_0 z) := pR (k_165 z) (pR (k_164 z) (r_164_0 z))
 #a r_166_0
 theorem r_166_1 (z : Store) : (s_166 z) 539 = (v_163_0 z) := pR (k_165 z) (pR (k_164 z) (r_164_1 z))
 #a r_166_1
 def v_166_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_159_0 z), (v_163_0 z)]
 theorem g_166 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_318) (s_166 z) pmNode_318 2 1 542 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_318, r_166_0 z, r_166_1 z, h_159_0 z z_, h_163_0 z z_]
 #a g_166
 def s_167 (z : Store) : Store := pL [0, 1] (s_166 z) pmNode_318 2 1
 theorem t_166 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_318) (pmPeers pmNode_318) (s_166 z) pmNode_318 none = some (s_167 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_318) (s_166 z) pmNode_318).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 542 (by decide) (g_166 z z_)]
   rfl
 #a t_166
 theorem k_166 (z : Store) (tid : Tid) (h : tid ∉ [542]) : (s_167 z) tid = (s_166 z) tid := by
   unfold s_167
   dsimp only [pL, pmNode_318, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_166
 theorem w_166_0 (z : Store) : (s_167 z) 542 = v_166_0 z := by
   unfold s_167
   dsimp only [pL, pmNode_318, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_166_0, r_166_0 z, r_166_1 z] <;> rfl
 #a w_166_0
 theorem h_166_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_166_0 z).shape = [1, 2, 16, 16] := by
   unfold v_166_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_159_0 z z_]
 #a h_166_0
 attribute [local irreducible] v_166_0
 attribute [local irreducible] s_167
 theorem r_167_0 (z : Store) : (s_167 z) 542 = (v_166_0 z) := w_166_0 z
 #a r_167_0
 def v_167_0 (z : Store) : Tensor := transposeAxes 1 2 (v_166_0 z)
 def s_168 (z : Store) : Store := storeSet (s_167 z) [(543, transposeAxes 1 2 ((s_167 z) 542))]
 theorem t_167 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_319) (pmPeers pmNode_319) (s_167 z) pmNode_319 none = some (s_168 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_167
 theorem k_167 (z : Store) (tid : Tid) (h : tid ∉ [543]) : (s_168 z) tid = (s_167 z) tid := by
   unfold s_168
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_167
 theorem w_167_0 (z : Store) : (s_168 z) 543 = v_167_0 z := by
   unfold s_168
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_167_0, r_167_0 z] <;> rfl
 #a w_167_0
 theorem h_167_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_167_0 z).shape = [1, 16, 2, 16] := by
   unfold v_167_0
   change listSwapAt _ _ _ = _
   rw [h_166_0 z z_]
   rfl
 #a h_167_0
 attribute [local irreducible] v_167_0
 attribute [local irreducible] s_168
 theorem r_168_0 (z : Store) : (s_168 z) 240 = (v_165_0 z) := pR (k_167 z) (pR (k_166 z) (w_165_0 z))
 #a r_168_0
 theorem r_168_1 (z : Store) : (s_168 z) 543 = (v_167_0 z) := w_167_0 z
 #a r_168_1
 def v_168_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_165_0 z), (v_167_0 z)]
 theorem g_168 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_84) (s_168 z) pmNode_84 2 1 243 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_84, r_168_0 z, r_168_1 z, h_165_0 z z_, h_167_0 z z_]
 #a g_168
 def s_169 (z : Store) : Store := pL [0, 1] (s_168 z) pmNode_84 2 1
 theorem t_168 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_84) (pmPeers pmNode_84) (s_168 z) pmNode_84 none = some (s_169 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_84) (s_168 z) pmNode_84).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 243 (by decide) (g_168 z z_)]
   rfl
 #a t_168
 theorem k_168 (z : Store) (tid : Tid) (h : tid ∉ [243]) : (s_169 z) tid = (s_168 z) tid := by
   unfold s_169
   dsimp only [pL, pmNode_84, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_168
 theorem w_168_0 (z : Store) : (s_169 z) 243 = v_168_0 z := by
   unfold s_169
   dsimp only [pL, pmNode_84, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_168_0, r_168_0 z, r_168_1 z] <;> rfl
 #a w_168_0
 theorem h_168_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_168_0 z).shape = [1, 8, 4, 16] := by
   unfold v_168_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_165_0 z z_]
 #a h_168_0
 attribute [local irreducible] v_168_0
 attribute [local irreducible] s_169
 theorem r_169_0 (z : Store) : (s_169 z) 243 = (v_168_0 z) := w_168_0 z
 #a r_169_0
 def v_169_0 (z : Store) : Tensor := (v_168_0 z)
 def s_170 (z : Store) : Store := storeSet (s_169 z) [(244, ((s_169 z) 243))]
 theorem t_169 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_85) (pmPeers pmNode_85) (s_169 z) pmNode_85 none = some (s_170 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_169
 theorem k_169 (z : Store) (tid : Tid) (h : tid ∉ [244]) : (s_170 z) tid = (s_169 z) tid := by
   unfold s_170
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_169
 theorem w_169_0 (z : Store) : (s_170 z) 244 = v_169_0 z := by
   unfold s_170
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_169_0, r_169_0 z] <;> rfl
 #a w_169_0
 theorem h_169_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_169_0 z).shape = [1, 8, 4, 16] := by
   unfold v_169_0
   exact h_168_0 z z_
 #a h_169_0
 attribute [local irreducible] v_169_0
 attribute [local irreducible] s_170
 theorem r_170_0 (z : Store) : (s_170 z) 240 = (v_165_0 z) := pR (k_169 z) (pR (k_168 z) (r_168_0 z))
 #a r_170_0
 theorem r_170_1 (z : Store) : (s_170 z) 543 = (v_167_0 z) := pR (k_169 z) (pR (k_168 z) (r_168_1 z))
 #a r_170_1
 def v_170_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_165_0 z), (v_167_0 z)]
 theorem g_170 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_320) (s_170 z) pmNode_320 2 1 546 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_320, r_170_0 z, r_170_1 z, h_165_0 z z_, h_167_0 z z_]
 #a g_170
 def s_171 (z : Store) : Store := pL [0, 1] (s_170 z) pmNode_320 2 1
 theorem t_170 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_320) (pmPeers pmNode_320) (s_170 z) pmNode_320 none = some (s_171 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_320) (s_170 z) pmNode_320).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 546 (by decide) (g_170 z z_)]
   rfl
 #a t_170
 theorem k_170 (z : Store) (tid : Tid) (h : tid ∉ [546]) : (s_171 z) tid = (s_170 z) tid := by
   unfold s_171
   dsimp only [pL, pmNode_320, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_170
 theorem w_170_0 (z : Store) : (s_171 z) 546 = v_170_0 z := by
   unfold s_171
   dsimp only [pL, pmNode_320, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_170_0, r_170_0 z, r_170_1 z] <;> rfl
 #a w_170_0
 theorem h_170_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_170_0 z).shape = [1, 8, 4, 16] := by
   unfold v_170_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_165_0 z z_]
 #a h_170_0
 attribute [local irreducible] v_170_0
 attribute [local irreducible] s_171
 theorem r_171_0 (z : Store) : (s_171 z) 546 = (v_170_0 z) := w_170_0 z
 #a r_171_0
 def v_171_0 (z : Store) : Tensor := (v_170_0 z)
 def s_172 (z : Store) : Store := storeSet (s_171 z) [(547, ((s_171 z) 546))]
 theorem t_171 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_321) (pmPeers pmNode_321) (s_171 z) pmNode_321 none = some (s_172 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_171
 theorem k_171 (z : Store) (tid : Tid) (h : tid ∉ [547]) : (s_172 z) tid = (s_171 z) tid := by
   unfold s_172
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_171
 theorem w_171_0 (z : Store) : (s_172 z) 547 = v_171_0 z := by
   unfold s_172
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_171_0, r_171_0 z] <;> rfl
 #a w_171_0
 theorem h_171_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_171_0 z).shape = [1, 8, 4, 16] := by
   unfold v_171_0
   exact h_170_0 z z_
 #a h_171_0
 attribute [local irreducible] v_171_0
 attribute [local irreducible] s_172
 theorem r_172_0 (z : Store) : (s_172 z) 244 = (v_169_0 z) := pR (k_171 z) (pR (k_170 z) (w_169_0 z))
 #a r_172_0
 theorem r_172_1 (z : Store) : (s_172 z) 547 = (v_171_0 z) := w_171_0 z
 #a r_172_1
 def v_172_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_169_0 z), (v_171_0 z)]
 theorem g_172 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_86) (s_172 z) pmNode_86 1 2 247 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_86, r_172_0 z, r_172_1 z, h_169_0 z z_, h_171_0 z z_]
 #a g_172
 def s_173 (z : Store) : Store := pL [0, 1] (s_172 z) pmNode_86 1 2
 theorem t_172 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_86) (pmPeers pmNode_86) (s_172 z) pmNode_86 none = some (s_173 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_86) (s_172 z) pmNode_86).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 247 (by decide) (g_172 z z_)]
   rfl
 #a t_172
 theorem k_172 (z : Store) (tid : Tid) (h : tid ∉ [247]) : (s_173 z) tid = (s_172 z) tid := by
   unfold s_173
   dsimp only [pL, pmNode_86, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_172
 theorem w_172_0 (z : Store) : (s_173 z) 247 = v_172_0 z := by
   unfold s_173
   dsimp only [pL, pmNode_86, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_172_0, r_172_0 z, r_172_1 z] <;> rfl
 #a w_172_0
 theorem h_172_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_172_0 z).shape = [1, 16, 2, 16] := by
   unfold v_172_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_169_0 z z_]
 #a h_172_0
 attribute [local irreducible] v_172_0
 attribute [local irreducible] s_173
 theorem r_173_0 (z : Store) : (s_173 z) 247 = (v_172_0 z) := w_172_0 z
 #a r_173_0
 def v_173_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_172_0 z)
 def s_174 (z : Store) : Store := storeSet (s_173 z) [(248, fw_view [1, 16, 32] ((s_173 z) 247))]
 theorem t_173 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_87) (pmPeers pmNode_87) (s_173 z) pmNode_87 none = some (s_174 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_173
 theorem k_173 (z : Store) (tid : Tid) (h : tid ∉ [248]) : (s_174 z) tid = (s_173 z) tid := by
   unfold s_174
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_173
 theorem w_173_0 (z : Store) : (s_174 z) 248 = v_173_0 z := by
   unfold s_174
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_173_0, r_173_0 z] <;> rfl
 #a w_173_0
 theorem h_173_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_173_0 z).shape = [1, 16, 32] := by
   unfold v_173_0
   rfl
 #a h_173_0
 attribute [local irreducible] v_173_0
 attribute [local irreducible] s_174
 theorem n_168_172 (z : Store) (tid : Tid) (h : tid ∉ ([243, 244, 546, 547] : List Tid)) : (s_172 z) tid = (s_168 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_168 z) (k_169 z)) (pF _ _ _ _ _ (k_170 z) (k_171 z)) tid h
 #a n_168_172
 theorem n_164_168 (z : Store) (tid : Tid) (h : tid ∉ ([239, 240, 542, 543] : List Tid)) : (s_168 z) tid = (s_164 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_164 z) (k_165 z)) (pF _ _ _ _ _ (k_166 z) (k_167 z)) tid h
 #a n_164_168
 theorem n_160_168 (z : Store) (tid : Tid) (h : tid ∉ ([535, 536, 382, 539, 239, 240, 542, 543] : List Tid)) : (s_168 z) tid = (s_160 z) tid := by
   exact pF _ _ _ _ _ (n_160_164 z) (n_164_168 z) tid h
 #a n_160_168
 theorem n_152_160 (z : Store) (tid : Tid) (h : tid ∉ ([228, 229, 531, 532, 232, 233, 79, 236] : List Tid)) : (s_160 z) tid = (s_152 z) tid := by
   exact pF _ _ _ _ _ (n_152_156 z) (n_156_160 z) tid h
 #a n_152_160
 theorem n_144_160 (z : Store) (tid : Tid) (h : tid ∉ ([222, 521, 522, 525, 224, 225, 527, 528, 228, 229, 531, 532, 232, 233, 79, 236] : List Tid)) : (s_160 z) tid = (s_144 z) tid := by
   exact pF _ _ _ _ _ (n_144_152 z) (n_152_160 z) tid h
 #a n_144_160
 theorem n_128_160 (z : Store) (tid : Tid) (h : tid ∉ ([206, 207, 505, 506, 509, 510, 210, 211, 214, 215, 513, 514, 517, 518, 218, 219, 222, 521, 522, 525, 224, 225, 527, 528, 228, 229, 531, 532, 232, 233, 79, 236] : List Tid)) : (s_160 z) tid = (s_128 z) tid := by
   exact pF _ _ _ _ _ (n_128_144 z) (n_144_160 z) tid h
 #a n_128_160
 theorem n_112_128 (z : Store) (tid : Tid) (h : tid ∉ ([192, 193, 195, 196, 391, 492, 198, 199, 495, 496, 498, 499, 501, 502, 202, 203] : List Tid)) : (s_128 z) tid = (s_112 z) tid := by
   exact pF _ _ _ _ _ (n_112_120 z) (n_120_128 z) tid h
 #a n_112_128
 theorem n_96_128 (z : Store) (tid : Tid) (h : tid ∉ ([478, 480, 180, 181, 291, 252, 483, 484, 594, 555, 185, 186, 293, 295, 297, 488, 489, 596, 598, 600, 88, 189, 192, 193, 195, 196, 391, 492, 198, 199, 495, 496, 498, 499, 501, 502, 202, 203] : List Tid)) : (s_128 z) tid = (s_96 z) tid := by
   exact pF _ _ _ _ _ (n_96_112 z) (n_112_128 z) tid h
 #a n_96_128
 theorem n_64_128 (z : Store) (tid : Tid) (h : tid ∉ ([446, 146, 147, 151, 153, 381, 449, 450, 454, 456, 155, 156, 458, 459, 159, 160, 462, 463, 164, 165, 289, 179, 467, 468, 592, 482, 169, 170, 173, 175, 177, 472, 473, 476, 478, 480, 180, 181, 291, 252, 483, 484, 594, 555, 185, 186, 293, 295, 297, 488, 489, 596, 598, 600, 88, 189, 192, 193, 195, 196, 391, 492, 198, 199, 495, 496, 498, 499, 501, 502, 202, 203] : List Tid)) : (s_128 z) tid = (s_64 z) tid := by
   exact pF _ _ _ _ _ (n_64_96 z) (n_96_128 z) tid h
 #a n_64_128
 theorem n_0_128 (z : Store) (tid : Tid) (h : tid ∉ ([75, 76, 89, 91, 92, 378, 379, 392, 394, 395, 94, 95, 283, 163, 397, 398, 586, 466, 98, 99, 102, 285, 287, 103, 401, 402, 405, 588, 590, 86, 106, 87, 109, 112, 406, 389, 409, 390, 412, 415, 114, 115, 118, 417, 418, 421, 120, 121, 124, 125, 128, 130, 132, 423, 424, 427, 428, 431, 433, 133, 134, 435, 436, 437, 138, 139, 441, 442, 142, 143, 78, 445, 446, 146, 147, 151, 153, 381, 449, 450, 454, 456, 155, 156, 458, 459, 159, 160, 462, 463, 164, 165, 289, 179, 467, 468, 592, 482, 169, 170, 173, 175, 177, 472, 473, 476, 478, 480, 180, 181, 291, 252, 483, 484, 594, 555, 185, 186, 293, 295, 297, 488, 489, 596, 598, 600, 88, 189, 192, 193, 195, 196, 391, 492, 198, 199, 495, 496, 498, 499, 501, 502, 202, 203] : List Tid)) : (s_128 z) tid = (s_0 z) tid := by
   exact pF _ _ _ _ _ (n_0_64 z) (n_64_128 z) tid h
 #a n_0_128
 record_prefix_opacity v_166_0 s_167 v_167_0 s_168 v_168_0 s_169 v_169_0 s_170 v_170_0 s_171 v_171_0 s_172 v_172_0 s_173 v_173_0 s_174

 end
 end TrainVerify.Denote.RuntimeWorld
