import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0008
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_53_0 (z : Store) : (s_53 z) 115 = (v_33_0 z) := pR (k_52 z) (pR (n_48_52 z) (pR (n_44_48 z) (r_44_0 z)))
 #a r_53_0
 theorem r_53_1 (z : Store) : (s_53 z) 418 = (v_36_0 z) := pR (k_52 z) (pR (n_48_52 z) (pR (n_44_48 z) (r_44_1 z)))
 #a r_53_1
 def v_53_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_33_0 z), (v_36_0 z)]
 theorem g_53 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_261) (s_53 z) pmNode_261 3 1 435 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_261, r_53_0 z, r_53_1 z, h_33_0 z z_, h_36_0 z z_]
 #a g_53
 def s_54 (z : Store) : Store := pL [0, 1] (s_53 z) pmNode_261 3 1
 theorem t_53 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_261) (pmPeers pmNode_261) (s_53 z) pmNode_261 none = some (s_54 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_261) (s_53 z) pmNode_261).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 435 (by decide) (g_53 z z_)]
   rfl
 #a t_53
 theorem k_53 (z : Store) (tid : Tid) (h : tid ∉ [435]) : (s_54 z) tid = (s_53 z) tid := by
   unfold s_54
   dsimp only [pL, pmNode_261, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_53
 theorem w_53_0 (z : Store) : (s_54 z) 435 = v_53_0 z := by
   unfold s_54
   dsimp only [pL, pmNode_261, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_53_0, r_53_0 z, r_53_1 z] <;> rfl
 #a w_53_0
 theorem h_53_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_53_0 z).shape = [1, 2, 16, 16] := by
   unfold v_53_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_33_0 z z_]
 #a h_53_0
 attribute [local irreducible] v_53_0
 attribute [local irreducible] s_54
 theorem r_54_0 (z : Store) : (s_54 z) 130 = (v_43_0 z) := pR (k_53 z) (pR (k_52 z) (pR (k_51 z) (r_51_0 z)))
 #a r_54_0
 theorem r_54_1 (z : Store) : (s_54 z) 433 = (v_50_0 z) := pR (k_53 z) (pR (k_52 z) (pR (k_51 z) (r_51_1 z)))
 #a r_54_1
 def v_54_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_43_0 z), (v_50_0 z)]
 theorem g_54 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_262) (s_54 z) pmNode_262 2 1 436 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_262, r_54_0 z, r_54_1 z, h_43_0 z z_, h_50_0 z z_]
 #a g_54
 def s_55 (z : Store) : Store := pL [0, 1] (s_54 z) pmNode_262 2 1
 theorem t_54 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_262) (pmPeers pmNode_262) (s_54 z) pmNode_262 none = some (s_55 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_262) (s_54 z) pmNode_262).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 436 (by decide) (g_54 z z_)]
   rfl
 #a t_54
 theorem k_54 (z : Store) (tid : Tid) (h : tid ∉ [436]) : (s_55 z) tid = (s_54 z) tid := by
   unfold s_55
   dsimp only [pL, pmNode_262, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_54
 theorem w_54_0 (z : Store) : (s_55 z) 436 = v_54_0 z := by
   unfold s_55
   dsimp only [pL, pmNode_262, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_54_0, r_54_0 z, r_54_1 z] <;> rfl
 #a w_54_0
 theorem h_54_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_54_0 z).shape = [1, 2, 16, 16] := by
   unfold v_54_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_43_0 z z_]
 #a h_54_0
 attribute [local irreducible] v_54_0
 attribute [local irreducible] s_55
 theorem r_55_0 (z : Store) : (s_55 z) 435 = (v_53_0 z) := pR (k_54 z) (w_53_0 z)
 #a r_55_0
 theorem r_55_1 (z : Store) : (s_55 z) 436 = (v_54_0 z) := w_54_0 z
 #a r_55_1
 def v_55_0 (z : Store) : Tensor := fw_matmul (v_53_0 z) (v_54_0 z)
 def s_56 (z : Store) : Store := storeSet (s_55 z) [(437, fw_matmul ((s_55 z) 435) ((s_55 z) 436))]
 theorem t_55 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_263) (pmPeers pmNode_263) (s_55 z) pmNode_263 none = some (s_56 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_55
 theorem k_55 (z : Store) (tid : Tid) (h : tid ∉ [437]) : (s_56 z) tid = (s_55 z) tid := by
   unfold s_56
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_55
 theorem w_55_0 (z : Store) : (s_56 z) 437 = v_55_0 z := by
   unfold s_56
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_55_0, r_55_0 z, r_55_1 z] <;> rfl
 #a w_55_0
 theorem h_55_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_55_0 z).shape = [1, 2, 16, 16] := by
   unfold v_55_0
   unfold fw_matmul batchedMatmul
   rw [h_53_0 z z_, h_54_0 z z_]
   rfl
 #a h_55_0
 attribute [local irreducible] v_55_0
 attribute [local irreducible] s_56
 theorem r_56_0 (z : Store) : (s_56 z) 134 = (v_52_0 z) := pR (k_55 z) (pR (k_54 z) (pR (k_53 z) (w_52_0 z)))
 #a r_56_0
 theorem r_56_1 (z : Store) : (s_56 z) 437 = (v_55_0 z) := w_55_0 z
 #a r_56_1
 def v_56_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_52_0 z), (v_55_0 z)]
 theorem g_56 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_28) (s_56 z) pmNode_28 1 3 138 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_28, r_56_0 z, r_56_1 z, h_52_0 z z_, h_55_0 z z_]
 #a g_56
 def s_57 (z : Store) : Store := pL [0, 1] (s_56 z) pmNode_28 1 3
 theorem t_56 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_28) (pmPeers pmNode_28) (s_56 z) pmNode_28 none = some (s_57 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_28) (s_56 z) pmNode_28).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 138 (by decide) (g_56 z z_)]
   rfl
 #a t_56
 theorem k_56 (z : Store) (tid : Tid) (h : tid ∉ [138]) : (s_57 z) tid = (s_56 z) tid := by
   unfold s_57
   dsimp only [pL, pmNode_28, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_56
 theorem w_56_0 (z : Store) : (s_57 z) 138 = v_56_0 z := by
   unfold s_57
   dsimp only [pL, pmNode_28, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_56_0, r_56_0 z, r_56_1 z] <;> rfl
 #a w_56_0
 theorem h_56_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_56_0 z).shape = [1, 4, 16, 8] := by
   unfold v_56_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_52_0 z z_]
 #a h_56_0
 attribute [local irreducible] v_56_0
 attribute [local irreducible] s_57
 theorem r_57_0 (z : Store) : (s_57 z) 138 = (v_56_0 z) := w_56_0 z
 #a r_57_0
 def v_57_0 (z : Store) : Tensor := fw_div ((4 : Nat) : Scalar) (v_56_0 z)
 def s_58 (z : Store) : Store := storeSet (s_57 z) [(139, fw_div ((4 : Nat) : Scalar) ((s_57 z) 138))]
 theorem t_57 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_29) (pmPeers pmNode_29) (s_57 z) pmNode_29 none = some (s_58 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_57
 theorem k_57 (z : Store) (tid : Tid) (h : tid ∉ [139]) : (s_58 z) tid = (s_57 z) tid := by
   unfold s_58
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_57
 theorem w_57_0 (z : Store) : (s_58 z) 139 = v_57_0 z := by
   unfold s_58
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_57_0, r_57_0 z] <;> rfl
 #a w_57_0
 theorem h_57_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_57_0 z).shape = [1, 4, 16, 8] := by
   unfold v_57_0
   exact h_56_0 z z_
 #a h_57_0
 attribute [local irreducible] v_57_0
 attribute [local irreducible] s_58
 theorem r_58_0 (z : Store) : (s_58 z) 134 = (v_52_0 z) := pR (k_57 z) (pR (k_56 z) (r_56_0 z))
 #a r_58_0
 theorem r_58_1 (z : Store) : (s_58 z) 437 = (v_55_0 z) := pR (k_57 z) (pR (k_56 z) (r_56_1 z))
 #a r_58_1
 def v_58_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_52_0 z), (v_55_0 z)]
 theorem g_58 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_264) (s_58 z) pmNode_264 1 3 441 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_264, r_58_0 z, r_58_1 z, h_52_0 z z_, h_55_0 z z_]
 #a g_58
 def s_59 (z : Store) : Store := pL [0, 1] (s_58 z) pmNode_264 1 3
 theorem t_58 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_264) (pmPeers pmNode_264) (s_58 z) pmNode_264 none = some (s_59 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_264) (s_58 z) pmNode_264).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 441 (by decide) (g_58 z z_)]
   rfl
 #a t_58
 theorem k_58 (z : Store) (tid : Tid) (h : tid ∉ [441]) : (s_59 z) tid = (s_58 z) tid := by
   unfold s_59
   dsimp only [pL, pmNode_264, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_58
 theorem w_58_0 (z : Store) : (s_59 z) 441 = v_58_0 z := by
   unfold s_59
   dsimp only [pL, pmNode_264, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_58_0, r_58_0 z, r_58_1 z] <;> rfl
 #a w_58_0
 theorem h_58_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_58_0 z).shape = [1, 4, 16, 8] := by
   unfold v_58_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_52_0 z z_]
 #a h_58_0
 attribute [local irreducible] v_58_0
 attribute [local irreducible] s_59
 theorem r_59_0 (z : Store) : (s_59 z) 441 = (v_58_0 z) := w_58_0 z
 #a r_59_0
 def v_59_0 (z : Store) : Tensor := fw_div ((4 : Nat) : Scalar) (v_58_0 z)
 def s_60 (z : Store) : Store := storeSet (s_59 z) [(442, fw_div ((4 : Nat) : Scalar) ((s_59 z) 441))]
 theorem t_59 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_265) (pmPeers pmNode_265) (s_59 z) pmNode_265 none = some (s_60 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_59
 theorem k_59 (z : Store) (tid : Tid) (h : tid ∉ [442]) : (s_60 z) tid = (s_59 z) tid := by
   unfold s_60
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_59
 theorem w_59_0 (z : Store) : (s_60 z) 442 = v_59_0 z := by
   unfold s_60
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_59_0, r_59_0 z] <;> rfl
 #a w_59_0
 theorem h_59_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_59_0 z).shape = [1, 4, 16, 8] := by
   unfold v_59_0
   exact h_58_0 z z_
 #a h_59_0
 attribute [local irreducible] v_59_0
 attribute [local irreducible] s_60
 theorem r_60_0 (z : Store) : (s_60 z) 139 = (v_57_0 z) := pR (k_59 z) (pR (k_58 z) (w_57_0 z))
 #a r_60_0
 theorem r_60_1 (z : Store) : (s_60 z) 442 = (v_59_0 z) := w_59_0 z
 #a r_60_1
 def v_60_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_57_0 z), (v_59_0 z)]
 theorem g_60 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_30) (s_60 z) pmNode_30 3 1 142 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_30, r_60_0 z, r_60_1 z, h_57_0 z z_, h_59_0 z z_]
 #a g_60
 def s_61 (z : Store) : Store := pL [0, 1] (s_60 z) pmNode_30 3 1
 theorem t_60 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_30) (pmPeers pmNode_30) (s_60 z) pmNode_30 none = some (s_61 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_30) (s_60 z) pmNode_30).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 142 (by decide) (g_60 z z_)]
   rfl
 #a t_60
 theorem k_60 (z : Store) (tid : Tid) (h : tid ∉ [142]) : (s_61 z) tid = (s_60 z) tid := by
   unfold s_61
   dsimp only [pL, pmNode_30, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_60
 theorem w_60_0 (z : Store) : (s_61 z) 142 = v_60_0 z := by
   unfold s_61
   dsimp only [pL, pmNode_30, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_60_0, r_60_0 z, r_60_1 z] <;> rfl
 #a w_60_0
 theorem h_60_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_60_0 z).shape = [1, 2, 16, 16] := by
   unfold v_60_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_57_0 z z_]
 #a h_60_0
 attribute [local irreducible] v_60_0
 attribute [local irreducible] s_61
 theorem r_61_0 (z : Store) : (s_61 z) 142 = (v_60_0 z) := w_60_0 z
 #a r_61_0
 def v_61_0 (z : Store) : Tensor := fw_softmax (v_60_0 z)
 def s_62 (z : Store) : Store := storeSet (s_61 z) [(143, fw_softmax ((s_61 z) 142))]
 theorem t_61 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_31) (pmPeers pmNode_31) (s_61 z) pmNode_31 none = some (s_62 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_61
 theorem k_61 (z : Store) (tid : Tid) (h : tid ∉ [143]) : (s_62 z) tid = (s_61 z) tid := by
   unfold s_62
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_61
 theorem w_61_0 (z : Store) : (s_62 z) 143 = v_61_0 z := by
   unfold s_62
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_61_0, r_61_0 z] <;> rfl
 #a w_61_0
 theorem h_61_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_61_0 z).shape = [1, 2, 16, 16] := by
   unfold v_61_0
   unfold fw_softmax softmax
   split <;> exact h_60_0 z z_
 #a h_61_0
 attribute [local irreducible] v_61_0
 attribute [local irreducible] s_62
 theorem n_56_60 (z : Store) (tid : Tid) (h : tid ∉ ([138, 139, 441, 442] : List Tid)) : (s_60 z) tid = (s_56 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_56 z) (k_57 z)) (pF _ _ _ _ _ (k_58 z) (k_59 z)) tid h
 #a n_56_60
 theorem n_52_56 (z : Store) (tid : Tid) (h : tid ∉ ([134, 435, 436, 437] : List Tid)) : (s_56 z) tid = (s_52 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_52 z) (k_53 z)) (pF _ _ _ _ _ (k_54 z) (k_55 z)) tid h
 #a n_52_56
 theorem n_48_56 (z : Store) (tid : Tid) (h : tid ∉ ([428, 431, 433, 133, 134, 435, 436, 437] : List Tid)) : (s_56 z) tid = (s_48 z) tid := by
   exact pF _ _ _ _ _ (n_48_52 z) (n_52_56 z) tid h
 #a n_48_56
 record_prefix_opacity v_53_0 s_54 v_54_0 s_55 v_55_0 s_56 v_56_0 s_57 v_57_0 s_58 v_58_0 s_59 v_59_0 s_60 v_60_0 s_61 v_61_0 s_62

 end
 end TrainVerify.Denote.RuntimeWorld
