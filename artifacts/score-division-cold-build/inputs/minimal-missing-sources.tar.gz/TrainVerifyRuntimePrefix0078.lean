import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0077
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_622_0 (z : Store) : (s_622 z) 1175 = (v_621_0 z) := w_621_0 z
 #a r_622_0
 theorem r_622_1 (z : Store) : (s_622 z) 922 = (z 922) := pR (k_621 z) (pR (k_620 z) (pR (n_616_620 z) (pR (n_608_616 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_95 z)))))))
 #a r_622_1
 def v_622_0 (z : Store) : Tensor := fw_linear (v_621_0 z) (z 922)
 def s_623 (z : Store) : Store := storeSet (s_622 z) [(1178, fw_linear ((s_622 z) 1175) ((s_622 z) 922))]
 theorem t_622 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_806) (pmPeers pmNode_806) (s_622 z) pmNode_806 none = some (s_623 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_622
 theorem k_622 (z : Store) (tid : Tid) (h : tid ∉ [1178]) : (s_623 z) tid = (s_622 z) tid := by
   unfold s_623
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_622
 theorem w_622_0 (z : Store) : (s_623 z) 1178 = v_622_0 z := by
   unfold s_623
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_622_0, r_622_0 z, r_622_1 z] <;> rfl
 #a w_622_0
 theorem h_622_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_622_0 z).shape = [1, 8, 64] := by
   unfold v_622_0
   exact fw_linear_3d_shape 1 8 256 64 (v_621_0 z) (z 922) (h_621_0 z z_) (i_95 z z_)
 #a h_622_0
 attribute [local irreducible] v_622_0
 attribute [local irreducible] s_623
 theorem r_623_0 (z : Store) : (s_623 z) 907 = (v_602_1 z) := pR (k_622 z) (pR (k_621 z) (pR (k_620 z) (pR (k_619 z) (pR (k_618 z) (pR (k_617 z) (r_617_0 z))))))
 #a r_623_0
 theorem r_623_1 (z : Store) : (s_623 z) 1210 = (v_605_1 z) := pR (k_622 z) (pR (k_621 z) (pR (k_620 z) (pR (k_619 z) (pR (k_618 z) (pR (k_617 z) (r_617_1 z))))))
 #a r_623_1
 def v_623_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_602_1 z), (v_605_1 z)]
 theorem g_623 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_807) (s_623 z) pmNode_807 2 1 1180 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_807, r_623_0 z, r_623_1 z, h_602_1 z z_, h_605_1 z z_]
 #a g_623
 def s_624 (z : Store) : Store := pL [2, 3] (s_623 z) pmNode_807 2 1
 theorem t_623 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_807) (pmPeers pmNode_807) (s_623 z) pmNode_807 none = some (s_624 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_807) (s_623 z) pmNode_807).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1180 (by decide) (g_623 z z_)]
   rfl
 #a t_623
 theorem k_623 (z : Store) (tid : Tid) (h : tid ∉ [1180]) : (s_624 z) tid = (s_623 z) tid := by
   unfold s_624
   dsimp only [pL, pmNode_807, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_623
 theorem w_623_0 (z : Store) : (s_624 z) 1180 = v_623_0 z := by
   unfold s_624
   dsimp only [pL, pmNode_807, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_623_0, r_623_0 z, r_623_1 z] <;> rfl
 #a w_623_0
 theorem h_623_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_623_0 z).shape = [1, 8, 64] := by
   unfold v_623_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_602_1 z z_]
 #a h_623_0
 attribute [local irreducible] v_623_0
 attribute [local irreducible] s_624
 theorem r_624_0 (z : Store) : (s_624 z) 1180 = (v_623_0 z) := w_623_0 z
 #a r_624_0
 theorem r_624_1 (z : Store) : (s_624 z) 1178 = (v_622_0 z) := pR (k_623 z) (w_622_0 z)
 #a r_624_1
 def v_624_0 (z : Store) : Tensor := elemwiseAdd (v_623_0 z) (v_622_0 z)
 def s_625 (z : Store) : Store := storeSet (s_624 z) [(1181, elemwiseAdd ((s_624 z) 1180) ((s_624 z) 1178))]
 theorem t_624 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_808) (pmPeers pmNode_808) (s_624 z) pmNode_808 none = some (s_625 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_624
 theorem k_624 (z : Store) (tid : Tid) (h : tid ∉ [1181]) : (s_625 z) tid = (s_624 z) tid := by
   unfold s_625
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_624
 theorem w_624_0 (z : Store) : (s_625 z) 1181 = v_624_0 z := by
   unfold s_625
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_624_0, r_624_0 z, r_624_1 z] <;> rfl
 #a w_624_0
 theorem h_624_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_624_0 z).shape = [1, 8, 64] := by
   unfold v_624_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_623_0 z z_, h_622_0 z z_]
 #a h_624_0
 attribute [local irreducible] v_624_0
 attribute [local irreducible] s_625
 theorem n_620_624 (z : Store) (tid : Tid) (h : tid ∉ ([1174, 1175, 1178, 1180] : List Tid)) : (s_624 z) tid = (s_620 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_620 z) (k_621 z)) (pF _ _ _ _ _ (k_622 z) (k_623 z)) tid h
 #a n_620_624
 theorem n_616_624 (z : Store) (tid : Tid) (h : tid ∉ ([875, 877, 878, 881, 1174, 1175, 1178, 1180] : List Tid)) : (s_624 z) tid = (s_616 z) tid := by
   exact pF _ _ _ _ _ (n_616_620 z) (n_620_624 z) tid h
 #a n_616_624
 theorem n_608_624 (z : Store) (tid : Tid) (h : tid ∉ ([1167, 1168, 868, 869, 1171, 1172, 871, 872, 875, 877, 878, 881, 1174, 1175, 1178, 1180] : List Tid)) : (s_624 z) tid = (s_608 z) tid := by
   exact pF _ _ _ _ _ (n_608_616 z) (n_616_624 z) tid h
 #a n_608_624
 theorem r_625_0 (z : Store) : (s_625 z) 1181 = (v_624_0 z) := w_624_0 z
 #a r_625_0
 theorem r_625_1 (z : Store) : (s_625 z) 923 = (z 923) := pR (k_624 z) (pR (n_608_624 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_96 z)))))
 #a r_625_1
 theorem r_625_2 (z : Store) : (s_625 z) 924 = (z 924) := pR (k_624 z) (pR (n_608_624 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_97 z)))))
 #a r_625_2
 def v_625_0 (z : Store) : Tensor := fw_layernorm (v_624_0 z) (z 923) (z 924)
 def s_626 (z : Store) : Store := storeSet (s_625 z) [(1184, fw_layernorm ((s_625 z) 1181) ((s_625 z) 923) ((s_625 z) 924))]
 theorem t_625 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_809) (pmPeers pmNode_809) (s_625 z) pmNode_809 none = some (s_626 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_625
 theorem k_625 (z : Store) (tid : Tid) (h : tid ∉ [1184]) : (s_626 z) tid = (s_625 z) tid := by
   unfold s_626
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_625
 theorem w_625_0 (z : Store) : (s_626 z) 1184 = v_625_0 z := by
   unfold s_626
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_625_0, r_625_0 z, r_625_1 z, r_625_2 z] <;> rfl
 #a w_625_0
 theorem h_625_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_625_0 z).shape = [1, 8, 64] := by
   unfold v_625_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_624_0 z z_
 #a h_625_0
 attribute [local irreducible] v_625_0
 attribute [local irreducible] s_626
 theorem r_626_0 (z : Store) : (s_626 z) 881 = (v_619_0 z) := pR (k_625 z) (pR (k_624 z) (pR (n_620_624 z) (w_619_0 z)))
 #a r_626_0
 theorem r_626_1 (z : Store) : (s_626 z) 1184 = (v_625_0 z) := w_625_0 z
 #a r_626_1
 def v_626_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_619_0 z), (v_625_0 z)]
 def s_627 (z : Store) : Store := storeSet (s_626 z) [(686, allGatherPrimDimN 1 2 0 [((s_626 z) 881), ((s_626 z) 1184)])]
 theorem t_626 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_574) (pmPeers pmNode_574) (s_626 z) pmNode_574 none = some (s_627 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_626 z) pmNode_574 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_626
 theorem k_626 (z : Store) (tid : Tid) (h : tid ∉ [686]) : (s_627 z) tid = (s_626 z) tid := by
   unfold s_627
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_626
 theorem w_626_0 (z : Store) : (s_627 z) 686 = v_626_0 z := by
   unfold s_627
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_626_0, r_626_0 z, r_626_1 z] <;> rfl
 #a w_626_0
 theorem h_626_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_626_0 z).shape = [1, 16, 64] := by
   unfold v_626_0
   exact allGatherPrimDimN_shape 1 2 [(v_619_0 z), (v_625_0 z)] [1, 8, 64] (h_619_0 z z_)
 #a h_626_0
 attribute [local irreducible] v_626_0
 attribute [local irreducible] s_627
 theorem r_627_0 (z : Store) : (s_627 z) 686 = (v_626_0 z) := w_626_0 z
 #a r_627_0
 theorem r_627_1 (z : Store) : (s_627 z) 678 = (z 678) := pR (k_626 z) (pR (k_625 z) (pR (k_624 z) (pR (n_608_624 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_98 z)))))))
 #a r_627_1
 def v_627_0 (z : Store) : Tensor := fw_linear (v_626_0 z) (z 678)
 def s_628 (z : Store) : Store := storeSet (s_627 z) [(883, fw_linear ((s_627 z) 686) ((s_627 z) 678))]
 theorem t_627 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_575) (pmPeers pmNode_575) (s_627 z) pmNode_575 none = some (s_628 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_627
 theorem k_627 (z : Store) (tid : Tid) (h : tid ∉ [883]) : (s_628 z) tid = (s_627 z) tid := by
   unfold s_628
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_627
 theorem w_627_0 (z : Store) : (s_628 z) 883 = v_627_0 z := by
   unfold s_628
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_627_0, r_627_0 z, r_627_1 z] <;> rfl
 #a w_627_0
 theorem h_627_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_627_0 z).shape = [1, 16, 128] := by
   unfold v_627_0
   exact fw_linear_3d_shape 1 16 64 128 (v_626_0 z) (z 678) (h_626_0 z z_) (i_98 z z_)
 #a h_627_0
 attribute [local irreducible] v_627_0
 attribute [local irreducible] s_628
 theorem r_628_0 (z : Store) : (s_628 z) 881 = (v_619_0 z) := pR (k_627 z) (pR (k_626 z) (r_626_0 z))
 #a r_628_0
 theorem r_628_1 (z : Store) : (s_628 z) 1184 = (v_625_0 z) := pR (k_627 z) (pR (k_626 z) (r_626_1 z))
 #a r_628_1
 def v_628_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_619_0 z), (v_625_0 z)]
 def s_629 (z : Store) : Store := storeSet (s_628 z) [(989, allGatherPrimDimN 1 2 1 [((s_628 z) 881), ((s_628 z) 1184)])]
 theorem t_628 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_810) (pmPeers pmNode_810) (s_628 z) pmNode_810 none = some (s_629 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_628 z) pmNode_810 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_628
 theorem k_628 (z : Store) (tid : Tid) (h : tid ∉ [989]) : (s_629 z) tid = (s_628 z) tid := by
   unfold s_629
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_628
 theorem w_628_0 (z : Store) : (s_629 z) 989 = v_628_0 z := by
   unfold s_629
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_628_0, r_628_0 z, r_628_1 z] <;> rfl
 #a w_628_0
 theorem h_628_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_628_0 z).shape = [1, 16, 64] := by
   unfold v_628_0
   exact allGatherPrimDimN_shape 1 2 [(v_619_0 z), (v_625_0 z)] [1, 8, 64] (h_619_0 z z_)
 #a h_628_0
 attribute [local irreducible] v_628_0
 attribute [local irreducible] s_629
 theorem n_624_628 (z : Store) (tid : Tid) (h : tid ∉ ([1181, 1184, 686, 883] : List Tid)) : (s_628 z) tid = (s_624 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_624 z) (k_625 z)) (pF _ _ _ _ _ (k_626 z) (k_627 z)) tid h
 #a n_624_628
 theorem r_629_0 (z : Store) : (s_629 z) 989 = (v_628_0 z) := w_628_0 z
 #a r_629_0
 theorem r_629_1 (z : Store) : (s_629 z) 981 = (z 981) := pR (k_628 z) (pR (n_624_628 z) (pR (n_608_624 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_99 z))))))
 #a r_629_1
 def v_629_0 (z : Store) : Tensor := fw_linear (v_628_0 z) (z 981)
 def s_630 (z : Store) : Store := storeSet (s_629 z) [(1186, fw_linear ((s_629 z) 989) ((s_629 z) 981))]
 theorem t_629 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_811) (pmPeers pmNode_811) (s_629 z) pmNode_811 none = some (s_630 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_629
 theorem k_629 (z : Store) (tid : Tid) (h : tid ∉ [1186]) : (s_630 z) tid = (s_629 z) tid := by
   unfold s_630
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_629
 theorem w_629_0 (z : Store) : (s_630 z) 1186 = v_629_0 z := by
   unfold s_630
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_629_0, r_629_0 z, r_629_1 z] <;> rfl
 #a w_629_0
 theorem h_629_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_629_0 z).shape = [1, 16, 128] := by
   unfold v_629_0
   exact fw_linear_3d_shape 1 16 64 128 (v_628_0 z) (z 981) (h_628_0 z z_) (i_99 z z_)
 #a h_629_0
 attribute [local irreducible] v_629_0
 attribute [local irreducible] s_630
 theorem r_630_0 (z : Store) : (s_630 z) 883 = (v_627_0 z) := pR (k_629 z) (pR (k_628 z) (w_627_0 z))
 #a r_630_0
 theorem r_630_1 (z : Store) : (s_630 z) 1186 = (v_629_0 z) := w_629_0 z
 #a r_630_1
 def v_630_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_627_0 z), (v_629_0 z)]
 theorem g_630 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_576) (s_630 z) pmNode_576 2 1 886 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 128], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_576, r_630_0 z, r_630_1 z, h_627_0 z z_, h_629_0 z z_]
 #a g_630
 def s_631 (z : Store) : Store := pL [2, 3] (s_630 z) pmNode_576 2 1
 theorem t_630 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_576) (pmPeers pmNode_576) (s_630 z) pmNode_576 none = some (s_631 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_576) (s_630 z) pmNode_576).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 886 (by decide) (g_630 z z_)]
   rfl
 #a t_630
 theorem k_630 (z : Store) (tid : Tid) (h : tid ∉ [886]) : (s_631 z) tid = (s_630 z) tid := by
   unfold s_631
   dsimp only [pL, pmNode_576, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_630
 theorem w_630_0 (z : Store) : (s_631 z) 886 = v_630_0 z := by
   unfold s_631
   dsimp only [pL, pmNode_576, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_630_0, r_630_0 z, r_630_1 z] <;> rfl
 #a w_630_0
 theorem h_630_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_630_0 z).shape = [1, 8, 256] := by
   unfold v_630_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_627_0 z z_]
 #a h_630_0
 attribute [local irreducible] v_630_0
 attribute [local irreducible] s_631
 record_prefix_opacity v_622_0 s_623 v_623_0 s_624 v_624_0 s_625 v_625_0 s_626 v_626_0 s_627 v_627_0 s_628 v_628_0 s_629 v_629_0 s_630 v_630_0 s_631

 end
 end TrainVerify.Denote.RuntimeWorld
