import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0082
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_659_0 (z : Store) : (s_659 z) 867 = (v_658_0 z) := w_658_0 z
 #a r_659_0
 theorem r_659_1 (z : Store) : (s_659 z) 864 = (v_606_0 z) := pR (k_658 z) (pR (k_657 z) (pR (k_656 z) (pR (n_640_656 z) (pR (n_608_640 z) (pR (k_607 z) (r_607_0 z))))))
 #a r_659_1
 theorem r_659_2 (z : Store) : (s_659 z) 617 = (z 617) := pR (k_658 z) (pR (k_657 z) (pR (k_656 z) (pR (n_640_656 z) (pR (n_608_640 z) (pR (k_607 z) (r_607_1 z))))))
 #a r_659_2
 theorem r_659_3 (z : Store) : (s_659 z) 618 = (z 618) := pR (k_658 z) (pR (k_657 z) (pR (k_656 z) (pR (n_640_656 z) (pR (n_608_640 z) (pR (k_607 z) (r_607_2 z))))))
 #a r_659_3
 def v_659_0 (z : Store) : Tensor := (bw_layernorm (v_658_0 z) (v_606_0 z) (z 617) (z 618)).1
 def v_659_1 (z : Store) : Tensor := (bw_layernorm (v_658_0 z) (v_606_0 z) (z 617) (z 618)).2.1
 def v_659_2 (z : Store) : Tensor := (bw_layernorm (v_658_0 z) (v_606_0 z) (z 617) (z 618)).2.2
 def s_660 (z : Store) : Store := storeSet (s_659 z) [(866, (bw_layernorm ((s_659 z) 867) ((s_659 z) 864) ((s_659 z) 617) ((s_659 z) 618)).1), (665, (bw_layernorm ((s_659 z) 867) ((s_659 z) 864) ((s_659 z) 617) ((s_659 z) 618)).2.1), (667, (bw_layernorm ((s_659 z) 867) ((s_659 z) 864) ((s_659 z) 617) ((s_659 z) 618)).2.2)]
 theorem t_659 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_591) (pmPeers pmNode_591) (s_659 z) pmNode_591 none = some (s_660 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_659
 theorem k_659 (z : Store) (tid : Tid) (h : tid ∉ [866, 665, 667]) : (s_660 z) tid = (s_659 z) tid := by
   unfold s_660
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_659
 theorem w_659_0 (z : Store) : (s_660 z) 866 = v_659_0 z := by
   unfold s_660
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_659_0, r_659_0 z, r_659_1 z, r_659_2 z, r_659_3 z] <;> rfl
 #a w_659_0
 theorem h_659_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_659_0 z).shape = [1, 8, 64] := by
   unfold v_659_0
   rw [bw_layernorm_dx_shape (v_658_0 z) (v_606_0 z) (z 617) (z 618) 64 [8, 1] (by rw [h_606_0 z z_]; rfl)]
   exact h_606_0 z z_
 #a h_659_0
 attribute [local irreducible] v_659_0
 theorem w_659_1 (z : Store) : (s_660 z) 665 = v_659_1 z := by
   unfold s_660
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_659_1, r_659_0 z, r_659_1 z, r_659_2 z, r_659_3 z] <;> rfl
 #a w_659_1
 theorem h_659_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_659_1 z).shape = [64] := by
   unfold v_659_1
   rw [bw_layernorm_dw_shape (v_658_0 z) (v_606_0 z) (z 617) (z 618) 64 [8, 1] (by rw [h_606_0 z z_]; rfl)]
   exact i_86 z z_
 #a h_659_1
 attribute [local irreducible] v_659_1
 theorem w_659_2 (z : Store) : (s_660 z) 667 = v_659_2 z := by
   unfold s_660
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_659_2, r_659_0 z, r_659_1 z, r_659_2 z, r_659_3 z] <;> rfl
 #a w_659_2
 theorem h_659_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_659_2 z).shape = [64] := by
   unfold v_659_2
   rw [bw_layernorm_db_shape (v_658_0 z) (v_606_0 z) (z 617) (z 618) 64 [8, 1] (by rw [h_606_0 z z_]; rfl)]
   exact i_87 z z_
 #a h_659_2
 attribute [local irreducible] v_659_2
 attribute [local irreducible] s_660
 theorem r_660_0 (z : Store) : (s_660 z) 870 = (v_655_0 z) := pR (k_659 z) (pR (k_658 z) (r_658_0 z))
 #a r_660_0
 theorem r_660_1 (z : Store) : (s_660 z) 1173 = (v_657_0 z) := pR (k_659 z) (pR (k_658 z) (r_658_1 z))
 #a r_660_1
 def v_660_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_655_0 z), (v_657_0 z)]
 theorem g_660 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_826) (s_660 z) pmNode_826 2 1 1170 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_826, r_660_0 z, r_660_1 z, h_655_0 z z_, h_657_0 z z_]
 #a g_660
 def s_661 (z : Store) : Store := pL [2, 3] (s_660 z) pmNode_826 2 1
 theorem t_660 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_826) (pmPeers pmNode_826) (s_660 z) pmNode_826 none = some (s_661 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_826) (s_660 z) pmNode_826).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1170 (by decide) (g_660 z z_)]
   rfl
 #a t_660
 theorem k_660 (z : Store) (tid : Tid) (h : tid ∉ [1170]) : (s_661 z) tid = (s_660 z) tid := by
   unfold s_661
   dsimp only [pL, pmNode_826, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_660
 theorem w_660_0 (z : Store) : (s_661 z) 1170 = v_660_0 z := by
   unfold s_661
   dsimp only [pL, pmNode_826, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_660_0, r_660_0 z, r_660_1 z] <;> rfl
 #a w_660_0
 theorem h_660_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_660_0 z).shape = [1, 8, 64] := by
   unfold v_660_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_655_0 z z_]
 #a h_660_0
 attribute [local irreducible] v_660_0
 attribute [local irreducible] s_661
 theorem n_656_660 (z : Store) (tid : Tid) (h : tid ∉ ([994, 1173, 973, 867, 866, 665, 667] : List Tid)) : (s_660 z) tid = (s_656 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_656 z) (k_657 z)) (pF _ _ _ _ _ (k_658 z) (k_659 z)) tid h
 #a n_656_660
 theorem r_661_0 (z : Store) : (s_661 z) 1170 = (v_660_0 z) := w_660_0 z
 #a r_661_0
 theorem r_661_1 (z : Store) : (s_661 z) 1167 = (v_608_0 z) := pR (k_660 z) (pR (n_656_660 z) (pR (n_640_656 z) (pR (n_624_640 z) (pR (n_616_624 z) (pR (n_612_616 z) (pR (k_611 z) (pR (k_610 z) (pR (k_609 z) (r_609_0 z)))))))))
 #a r_661_1
 theorem r_661_2 (z : Store) : (s_661 z) 920 = (z 920) := pR (k_660 z) (pR (n_656_660 z) (pR (n_640_656 z) (pR (n_624_640 z) (pR (n_616_624 z) (pR (n_612_616 z) (pR (k_611 z) (pR (k_610 z) (pR (k_609 z) (r_609_1 z)))))))))
 #a r_661_2
 theorem r_661_3 (z : Store) : (s_661 z) 921 = (z 921) := pR (k_660 z) (pR (n_656_660 z) (pR (n_640_656 z) (pR (n_624_640 z) (pR (n_616_624 z) (pR (n_612_616 z) (pR (k_611 z) (pR (k_610 z) (pR (k_609 z) (r_609_2 z)))))))))
 #a r_661_3
 def v_661_0 (z : Store) : Tensor := (bw_layernorm (v_660_0 z) (v_608_0 z) (z 920) (z 921)).1
 def v_661_1 (z : Store) : Tensor := (bw_layernorm (v_660_0 z) (v_608_0 z) (z 920) (z 921)).2.1
 def v_661_2 (z : Store) : Tensor := (bw_layernorm (v_660_0 z) (v_608_0 z) (z 920) (z 921)).2.2
 def s_662 (z : Store) : Store := storeSet (s_661 z) [(1169, (bw_layernorm ((s_661 z) 1170) ((s_661 z) 1167) ((s_661 z) 920) ((s_661 z) 921)).1), (968, (bw_layernorm ((s_661 z) 1170) ((s_661 z) 1167) ((s_661 z) 920) ((s_661 z) 921)).2.1), (970, (bw_layernorm ((s_661 z) 1170) ((s_661 z) 1167) ((s_661 z) 920) ((s_661 z) 921)).2.2)]
 theorem t_661 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_827) (pmPeers pmNode_827) (s_661 z) pmNode_827 none = some (s_662 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_661
 theorem k_661 (z : Store) (tid : Tid) (h : tid ∉ [1169, 968, 970]) : (s_662 z) tid = (s_661 z) tid := by
   unfold s_662
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_661
 theorem w_661_0 (z : Store) : (s_662 z) 1169 = v_661_0 z := by
   unfold s_662
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_661_0, r_661_0 z, r_661_1 z, r_661_2 z, r_661_3 z] <;> rfl
 #a w_661_0
 theorem h_661_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_661_0 z).shape = [1, 8, 64] := by
   unfold v_661_0
   rw [bw_layernorm_dx_shape (v_660_0 z) (v_608_0 z) (z 920) (z 921) 64 [8, 1] (by rw [h_608_0 z z_]; rfl)]
   exact h_608_0 z z_
 #a h_661_0
 attribute [local irreducible] v_661_0
 theorem w_661_1 (z : Store) : (s_662 z) 968 = v_661_1 z := by
   unfold s_662
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_661_1, r_661_0 z, r_661_1 z, r_661_2 z, r_661_3 z] <;> rfl
 #a w_661_1
 theorem h_661_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_661_1 z).shape = [64] := by
   unfold v_661_1
   rw [bw_layernorm_dw_shape (v_660_0 z) (v_608_0 z) (z 920) (z 921) 64 [8, 1] (by rw [h_608_0 z z_]; rfl)]
   exact i_88 z z_
 #a h_661_1
 attribute [local irreducible] v_661_1
 theorem w_661_2 (z : Store) : (s_662 z) 970 = v_661_2 z := by
   unfold s_662
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_661_2, r_661_0 z, r_661_1 z, r_661_2 z, r_661_3 z] <;> rfl
 #a w_661_2
 theorem h_661_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_661_2 z).shape = [64] := by
   unfold v_661_2
   rw [bw_layernorm_db_shape (v_660_0 z) (v_608_0 z) (z 920) (z 921) 64 [8, 1] (by rw [h_608_0 z z_]; rfl)]
   exact i_89 z z_
 #a h_661_2
 attribute [local irreducible] v_661_2
 attribute [local irreducible] s_662
 theorem r_662_0 (z : Store) : (s_662 z) 866 = (v_659_0 z) := pR (k_661 z) (pR (k_660 z) (w_659_0 z))
 #a r_662_0
 theorem r_662_1 (z : Store) : (s_662 z) 1169 = (v_661_0 z) := w_661_0 z
 #a r_662_1
 def v_662_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_659_0 z), (v_661_0 z)]
 theorem g_662 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_592) (s_662 z) pmNode_592 1 2 906 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_592, r_662_0 z, r_662_1 z, h_659_0 z z_, h_661_0 z z_]
 #a g_662
 def s_663 (z : Store) : Store := pL [2, 3] (s_662 z) pmNode_592 1 2
 theorem t_662 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_592) (pmPeers pmNode_592) (s_662 z) pmNode_592 none = some (s_663 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_592) (s_662 z) pmNode_592).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 906 (by decide) (g_662 z z_)]
   rfl
 #a t_662
 theorem k_662 (z : Store) (tid : Tid) (h : tid ∉ [906]) : (s_663 z) tid = (s_662 z) tid := by
   unfold s_663
   dsimp only [pL, pmNode_592, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_662
 theorem w_662_0 (z : Store) : (s_663 z) 906 = v_662_0 z := by
   unfold s_663
   dsimp only [pL, pmNode_592, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_662_0, r_662_0 z, r_662_1 z] <;> rfl
 #a w_662_0
 theorem h_662_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_662_0 z).shape = [1, 16, 32] := by
   unfold v_662_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_659_0 z z_]
 #a h_662_0
 attribute [local irreducible] v_662_0
 attribute [local irreducible] s_663
 theorem r_663_0 (z : Store) : (s_663 z) 906 = (v_662_0 z) := w_662_0 z
 #a r_663_0
 theorem r_663_1 (z : Store) : (s_663 z) 908 = (v_648_0 z) := pR (k_662 z) (pR (k_661 z) (pR (k_660 z) (pR (n_656_660 z) (pR (n_652_656 z) (pR (k_651 z) (pR (k_650 z) (pR (k_649 z) (w_648_0 z))))))))
 #a r_663_1
 def v_663_0 (z : Store) : Tensor := tensorSum [(v_662_0 z), (v_648_0 z)]
 def s_664 (z : Store) : Store := storeSet (s_663 z) [(863, tensorSum [((s_663 z) 906), ((s_663 z) 908)])]
 theorem t_663 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_593) (pmPeers pmNode_593) (s_663 z) pmNode_593 none = some (s_664 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_663
 theorem k_663 (z : Store) (tid : Tid) (h : tid ∉ [863]) : (s_664 z) tid = (s_663 z) tid := by
   unfold s_664
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_663
 theorem w_663_0 (z : Store) : (s_664 z) 863 = v_663_0 z := by
   unfold s_664
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_663_0, r_663_0 z, r_663_1 z] <;> rfl
 #a w_663_0
 theorem h_663_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_663_0 z).shape = [1, 16, 32] := by
   unfold v_663_0
   rw [tensorSum_shape]
   exact h_662_0 z z_
 #a h_663_0
 attribute [local irreducible] v_663_0
 attribute [local irreducible] s_664
 theorem n_660_664 (z : Store) (tid : Tid) (h : tid ∉ ([1170, 1169, 968, 970, 906, 863] : List Tid)) : (s_664 z) tid = (s_660 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_660 z) (k_661 z)) (pF _ _ _ _ _ (k_662 z) (k_663 z)) tid h
 #a n_660_664
 theorem n_656_664 (z : Store) (tid : Tid) (h : tid ∉ ([994, 1173, 973, 867, 866, 665, 667, 1170, 1169, 968, 970, 906, 863] : List Tid)) : (s_664 z) tid = (s_656 z) tid := by
   exact pF _ _ _ _ _ (n_656_660 z) (n_660_664 z) tid h
 #a n_656_664
 theorem r_664_0 (z : Store) : (s_664 z) 863 = (v_663_0 z) := w_663_0 z
 #a r_664_0
 theorem r_664_1 (z : Store) : (s_664 z) 858 = (v_522_1 z) := pR (n_656_664 z) (pR (n_640_656 z) (pR (n_608_640 z) (pR (n_604_608 z) (pR (k_603 z) (pR (k_602 z) (pR (k_601 z) (r_601_0 z)))))))
 #a r_664_1
 theorem r_664_2 (z : Store) : (s_664 z) 859 = (v_600_0 z) := pR (n_656_664 z) (pR (n_640_656 z) (pR (n_608_640 z) (pR (n_604_608 z) (pR (k_603 z) (pR (k_602 z) (pR (k_601 z) (r_601_1 z)))))))
 #a r_664_2
 def v_664_0 (z : Store) : Tensor := (bw_add2 (v_663_0 z) (v_522_1 z) (v_600_0 z)).1
 def v_664_1 (z : Store) : Tensor := (bw_add2 (v_663_0 z) (v_522_1 z) (v_600_0 z)).2
 def s_665 (z : Store) : Store := storeSet (s_664 z) [(861, (bw_add2 ((s_664 z) 863) ((s_664 z) 858) ((s_664 z) 859)).1), (862, (bw_add2 ((s_664 z) 863) ((s_664 z) 858) ((s_664 z) 859)).2)]
 theorem t_664 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_594) (pmPeers pmNode_594) (s_664 z) pmNode_594 none = some (s_665 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_664
 theorem k_664 (z : Store) (tid : Tid) (h : tid ∉ [861, 862]) : (s_665 z) tid = (s_664 z) tid := by
   unfold s_665
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_664
 theorem w_664_0 (z : Store) : (s_665 z) 861 = v_664_0 z := by
   unfold s_665
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_664_0, r_664_0 z, r_664_1 z, r_664_2 z] <;> rfl
 #a w_664_0
 theorem h_664_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_664_0 z).shape = [1, 16, 32] := by
   unfold v_664_0
   exact h_522_1 z z_
 #a h_664_0
 attribute [local irreducible] v_664_0
 theorem w_664_1 (z : Store) : (s_665 z) 862 = v_664_1 z := by
   unfold s_665
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_664_1, r_664_0 z, r_664_1 z, r_664_2 z] <;> rfl
 #a w_664_1
 theorem h_664_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_664_1 z).shape = [1, 16, 32] := by
   unfold v_664_1
   exact h_600_0 z z_
 #a h_664_1
 attribute [local irreducible] v_664_1
 attribute [local irreducible] s_665
 record_prefix_opacity v_659_0 v_659_1 v_659_2 s_660 v_660_0 s_661 v_661_0 v_661_1 v_661_2 s_662 v_662_0 s_663 v_663_0 s_664 v_664_0 v_664_1 s_665

 end
 end TrainVerify.Denote.RuntimeWorld
