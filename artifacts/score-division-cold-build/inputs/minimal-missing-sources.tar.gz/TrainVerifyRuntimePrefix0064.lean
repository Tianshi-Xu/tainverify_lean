import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0063
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_502_0 (z : Store) : (s_502 z) 762 = (v_497_0 z) := pR (k_501 z) (pR (k_500 z) (r_500_0 z))
 #a r_502_0
 theorem r_502_1 (z : Store) : (s_502 z) 1065 = (v_499_0 z) := pR (k_501 z) (pR (k_500 z) (r_500_1 z))
 #a r_502_1
 def v_502_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_497_0 z), (v_499_0 z)]
 theorem g_502 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_747) (s_502 z) pmNode_747 2 1 1068 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_747, r_502_0 z, r_502_1 z, h_497_0 z z_, h_499_0 z z_]
 #a g_502
 def s_503 (z : Store) : Store := pL [2, 3] (s_502 z) pmNode_747 2 1
 theorem t_502 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_747) (pmPeers pmNode_747) (s_502 z) pmNode_747 none = some (s_503 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_747) (s_502 z) pmNode_747).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1068 (by decide) (g_502 z z_)]
   rfl
 #a t_502
 theorem k_502 (z : Store) (tid : Tid) (h : tid ∉ [1068]) : (s_503 z) tid = (s_502 z) tid := by
   unfold s_503
   dsimp only [pL, pmNode_747, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_502
 theorem w_502_0 (z : Store) : (s_503 z) 1068 = v_502_0 z := by
   unfold s_503
   dsimp only [pL, pmNode_747, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_502_0, r_502_0 z, r_502_1 z] <;> rfl
 #a w_502_0
 theorem h_502_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_502_0 z).shape = [1, 8, 64] := by
   unfold v_502_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_497_0 z z_]
 #a h_502_0
 attribute [local irreducible] v_502_0
 attribute [local irreducible] s_503
 theorem r_503_0 (z : Store) : (s_503 z) 1068 = (v_502_0 z) := w_502_0 z
 #a r_503_0
 theorem r_503_1 (z : Store) : (s_503 z) 913 = (z 913) := pR (k_502 z) (pR (k_501 z) (pR (k_500 z) (pR (n_496_500 z) (pR (n_480_496 z) (pR (n_448_480 z) (pR (n_384_448 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_65 z)))))))))
 #a r_503_1
 def v_503_0 (z : Store) : Tensor := fw_linear (v_502_0 z) (z 913)
 def s_504 (z : Store) : Store := storeSet (s_503 z) [(1069, fw_linear ((s_503 z) 1068) ((s_503 z) 913))]
 theorem t_503 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_748) (pmPeers pmNode_748) (s_503 z) pmNode_748 none = some (s_504 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_503
 theorem k_503 (z : Store) (tid : Tid) (h : tid ∉ [1069]) : (s_504 z) tid = (s_503 z) tid := by
   unfold s_504
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_503
 theorem w_503_0 (z : Store) : (s_504 z) 1069 = v_503_0 z := by
   unfold s_504
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_503_0, r_503_0 z, r_503_1 z] <;> rfl
 #a w_503_0
 theorem h_503_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_503_0 z).shape = [1, 8, 64] := by
   unfold v_503_0
   exact fw_linear_3d_shape 1 8 64 64 (v_502_0 z) (z 913) (h_502_0 z z_) (i_65 z z_)
 #a h_503_0
 attribute [local irreducible] v_503_0
 attribute [local irreducible] s_504
 theorem r_504_0 (z : Store) : (s_504 z) 766 = (v_501_0 z) := pR (k_503 z) (pR (k_502 z) (w_501_0 z))
 #a r_504_0
 theorem r_504_1 (z : Store) : (s_504 z) 1069 = (v_503_0 z) := w_503_0 z
 #a r_504_1
 def v_504_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_501_0 z), (v_503_0 z)]
 theorem g_504 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_513) (s_504 z) pmNode_513 1 2 770 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_513, r_504_0 z, r_504_1 z, h_501_0 z z_, h_503_0 z z_]
 #a g_504
 def s_505 (z : Store) : Store := pL [2, 3] (s_504 z) pmNode_513 1 2
 theorem t_504 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_513) (pmPeers pmNode_513) (s_504 z) pmNode_513 none = some (s_505 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_513) (s_504 z) pmNode_513).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 770 (by decide) (g_504 z z_)]
   rfl
 #a t_504
 theorem k_504 (z : Store) (tid : Tid) (h : tid ∉ [770]) : (s_505 z) tid = (s_504 z) tid := by
   unfold s_505
   dsimp only [pL, pmNode_513, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_504
 theorem w_504_0 (z : Store) : (s_505 z) 770 = v_504_0 z := by
   unfold s_505
   dsimp only [pL, pmNode_513, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_504_0, r_504_0 z, r_504_1 z] <;> rfl
 #a w_504_0
 theorem h_504_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_504_0 z).shape = [1, 16, 32] := by
   unfold v_504_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_501_0 z z_]
 #a h_504_0
 attribute [local irreducible] v_504_0
 attribute [local irreducible] s_505
 theorem n_500_504 (z : Store) (tid : Tid) (h : tid ∉ ([765, 766, 1068, 1069] : List Tid)) : (s_504 z) tid = (s_500 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_500 z) (k_501 z)) (pF _ _ _ _ _ (k_502 z) (k_503 z)) tid h
 #a n_500_504
 theorem n_496_504 (z : Store) (tid : Tid) (h : tid ∉ ([761, 762, 1064, 1065, 765, 766, 1068, 1069] : List Tid)) : (s_504 z) tid = (s_496 z) tid := by
   exact pF _ _ _ _ _ (n_496_500 z) (n_500_504 z) tid h
 #a n_496_504
 theorem r_505_0 (z : Store) : (s_505 z) 769 = (v_432_1 z) := pR (k_504 z) (pR (n_496_504 z) (pR (n_480_496 z) (pR (n_448_480 z) (pR (n_440_448 z) (pR (n_436_440 z) (pR (k_435 z) (pR (k_434 z) (pR (k_433 z) (w_432_1 z)))))))))
 #a r_505_0
 theorem r_505_1 (z : Store) : (s_505 z) 770 = (v_504_0 z) := w_504_0 z
 #a r_505_1
 def v_505_0 (z : Store) : Tensor := elemwiseAdd (v_432_1 z) (v_504_0 z)
 def s_506 (z : Store) : Store := storeSet (s_505 z) [(771, elemwiseAdd ((s_505 z) 769) ((s_505 z) 770))]
 theorem t_505 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_514) (pmPeers pmNode_514) (s_505 z) pmNode_514 none = some (s_506 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_505
 theorem k_505 (z : Store) (tid : Tid) (h : tid ∉ [771]) : (s_506 z) tid = (s_505 z) tid := by
   unfold s_506
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_505
 theorem w_505_0 (z : Store) : (s_506 z) 771 = v_505_0 z := by
   unfold s_506
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_505_0, r_505_0 z, r_505_1 z] <;> rfl
 #a w_505_0
 theorem h_505_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_505_0 z).shape = [1, 16, 32] := by
   unfold v_505_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_432_1 z z_, h_504_0 z z_]
 #a h_505_0
 attribute [local irreducible] v_505_0
 attribute [local irreducible] s_506
 theorem r_506_0 (z : Store) : (s_506 z) 771 = (v_505_0 z) := w_505_0 z
 #a r_506_0
 def v_506_0 (z : Store) : Tensor := (v_505_0 z)
 def v_506_1 (z : Store) : Tensor := (v_505_0 z)
 def s_507 (z : Store) : Store := storeSet (s_506 z) [(895, ((s_506 z) 771)), (785, ((s_506 z) 771))]
 theorem t_506 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_515) (pmPeers pmNode_515) (s_506 z) pmNode_515 none = some (s_507 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_506
 theorem k_506 (z : Store) (tid : Tid) (h : tid ∉ [895, 785]) : (s_507 z) tid = (s_506 z) tid := by
   unfold s_507
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_506
 theorem w_506_0 (z : Store) : (s_507 z) 895 = v_506_0 z := by
   unfold s_507
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_506_0, r_506_0 z] <;> rfl
 #a w_506_0
 theorem h_506_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_506_0 z).shape = [1, 16, 32] := by
   unfold v_506_0
   exact h_505_0 z z_
 #a h_506_0
 attribute [local irreducible] v_506_0
 theorem w_506_1 (z : Store) : (s_507 z) 785 = v_506_1 z := by
   unfold s_507
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_506_1, r_506_0 z] <;> rfl
 #a w_506_1
 theorem h_506_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_506_1 z).shape = [1, 16, 32] := by
   unfold v_506_1
   exact h_505_0 z z_
 #a h_506_1
 attribute [local irreducible] v_506_1
 attribute [local irreducible] s_507
 theorem r_507_0 (z : Store) : (s_507 z) 766 = (v_501_0 z) := pR (k_506 z) (pR (k_505 z) (pR (k_504 z) (r_504_0 z)))
 #a r_507_0
 theorem r_507_1 (z : Store) : (s_507 z) 1069 = (v_503_0 z) := pR (k_506 z) (pR (k_505 z) (pR (k_504 z) (r_504_1 z)))
 #a r_507_1
 def v_507_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_501_0 z), (v_503_0 z)]
 theorem g_507 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_749) (s_507 z) pmNode_749 1 2 1073 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_749, r_507_0 z, r_507_1 z, h_501_0 z z_, h_503_0 z z_]
 #a g_507
 def s_508 (z : Store) : Store := pL [2, 3] (s_507 z) pmNode_749 1 2
 theorem t_507 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_749) (pmPeers pmNode_749) (s_507 z) pmNode_749 none = some (s_508 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_749) (s_507 z) pmNode_749).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1073 (by decide) (g_507 z z_)]
   rfl
 #a t_507
 theorem k_507 (z : Store) (tid : Tid) (h : tid ∉ [1073]) : (s_508 z) tid = (s_507 z) tid := by
   unfold s_508
   dsimp only [pL, pmNode_749, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_507
 theorem w_507_0 (z : Store) : (s_508 z) 1073 = v_507_0 z := by
   unfold s_508
   dsimp only [pL, pmNode_749, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_507_0, r_507_0 z, r_507_1 z] <;> rfl
 #a w_507_0
 theorem h_507_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_507_0 z).shape = [1, 16, 32] := by
   unfold v_507_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_501_0 z z_]
 #a h_507_0
 attribute [local irreducible] v_507_0
 attribute [local irreducible] s_508
 theorem n_504_508 (z : Store) (tid : Tid) (h : tid ∉ ([770, 771, 895, 785, 1073] : List Tid)) : (s_508 z) tid = (s_504 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_504 z) (k_505 z)) (pF _ _ _ _ _ (k_506 z) (k_507 z)) tid h
 #a n_504_508
 theorem r_508_0 (z : Store) : (s_508 z) 1072 = (v_435_1 z) := pR (n_504_508 z) (pR (n_496_504 z) (pR (n_480_496 z) (pR (n_448_480 z) (pR (n_440_448 z) (pR (n_436_440 z) (w_435_1 z))))))
 #a r_508_0
 theorem r_508_1 (z : Store) : (s_508 z) 1073 = (v_507_0 z) := w_507_0 z
 #a r_508_1
 def v_508_0 (z : Store) : Tensor := elemwiseAdd (v_435_1 z) (v_507_0 z)
 def s_509 (z : Store) : Store := storeSet (s_508 z) [(1074, elemwiseAdd ((s_508 z) 1072) ((s_508 z) 1073))]
 theorem t_508 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_750) (pmPeers pmNode_750) (s_508 z) pmNode_750 none = some (s_509 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_508
 theorem k_508 (z : Store) (tid : Tid) (h : tid ∉ [1074]) : (s_509 z) tid = (s_508 z) tid := by
   unfold s_509
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_508
 theorem w_508_0 (z : Store) : (s_509 z) 1074 = v_508_0 z := by
   unfold s_509
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_508_0, r_508_0 z, r_508_1 z] <;> rfl
 #a w_508_0
 theorem h_508_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_508_0 z).shape = [1, 16, 32] := by
   unfold v_508_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_435_1 z z_, h_507_0 z z_]
 #a h_508_0
 attribute [local irreducible] v_508_0
 attribute [local irreducible] s_509
 theorem r_509_0 (z : Store) : (s_509 z) 1074 = (v_508_0 z) := w_508_0 z
 #a r_509_0
 def v_509_0 (z : Store) : Tensor := (v_508_0 z)
 def v_509_1 (z : Store) : Tensor := (v_508_0 z)
 def s_510 (z : Store) : Store := storeSet (s_509 z) [(1198, ((s_509 z) 1074)), (1088, ((s_509 z) 1074))]
 theorem t_509 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_751) (pmPeers pmNode_751) (s_509 z) pmNode_751 none = some (s_510 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_509
 theorem k_509 (z : Store) (tid : Tid) (h : tid ∉ [1198, 1088]) : (s_510 z) tid = (s_509 z) tid := by
   unfold s_510
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_509
 theorem w_509_0 (z : Store) : (s_510 z) 1198 = v_509_0 z := by
   unfold s_510
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_509_0, r_509_0 z] <;> rfl
 #a w_509_0
 theorem h_509_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_509_0 z).shape = [1, 16, 32] := by
   unfold v_509_0
   exact h_508_0 z z_
 #a h_509_0
 attribute [local irreducible] v_509_0
 theorem w_509_1 (z : Store) : (s_510 z) 1088 = v_509_1 z := by
   unfold s_510
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_509_1, r_509_0 z] <;> rfl
 #a w_509_1
 theorem h_509_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_509_1 z).shape = [1, 16, 32] := by
   unfold v_509_1
   exact h_508_0 z z_
 #a h_509_1
 attribute [local irreducible] v_509_1
 attribute [local irreducible] s_510
 record_prefix_opacity v_502_0 s_503 v_503_0 s_504 v_504_0 s_505 v_505_0 s_506 v_506_0 v_506_1 s_507 v_507_0 s_508 v_508_0 s_509 v_509_0 v_509_1 s_510

 end
 end TrainVerify.Denote.RuntimeWorld
