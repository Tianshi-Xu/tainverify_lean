import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0017
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_129_0 (z : Store) : (s_129 z) 206 = (v_128_0 z) := w_128_0 z
 #a r_129_0
 def v_129_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_128_0 z)
 def s_130 (z : Store) : Store := storeSet (s_129 z) [(207, fw_view [1, 8, 4, 16] ((s_129 z) 206))]
 theorem t_129 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_66) (pmPeers pmNode_66) (s_129 z) pmNode_66 none = some (s_130 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_129
 theorem k_129 (z : Store) (tid : Tid) (h : tid ∉ [207]) : (s_130 z) tid = (s_129 z) tid := by
   unfold s_130
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_129
 theorem w_129_0 (z : Store) : (s_130 z) 207 = v_129_0 z := by
   unfold s_130
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_129_0, r_129_0 z] <;> rfl
 #a w_129_0
 theorem h_129_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_129_0 z).shape = [1, 8, 4, 16] := by
   unfold v_129_0
   rfl
 #a h_129_0
 attribute [local irreducible] v_129_0
 attribute [local irreducible] s_130
 theorem r_130_0 (z : Store) : (s_130 z) 199 = (v_119_0 z) := pR (k_129 z) (pR (k_128 z) (pR (k_127 z) (pR (k_126 z) (r_126_0 z))))
 #a r_130_0
 theorem r_130_1 (z : Store) : (s_130 z) 502 = (v_125_0 z) := pR (k_129 z) (pR (k_128 z) (pR (k_127 z) (pR (k_126 z) (r_126_1 z))))
 #a r_130_1
 def v_130_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_119_0 z), (v_125_0 z)]
 theorem g_130 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_299) (s_130 z) pmNode_299 1 2 505 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_299, r_130_0 z, r_130_1 z, h_119_0 z z_, h_125_0 z z_]
 #a g_130
 def s_131 (z : Store) : Store := pL [0, 1] (s_130 z) pmNode_299 1 2
 theorem t_130 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_299) (pmPeers pmNode_299) (s_130 z) pmNode_299 none = some (s_131 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_299) (s_130 z) pmNode_299).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 505 (by decide) (g_130 z z_)]
   rfl
 #a t_130
 theorem k_130 (z : Store) (tid : Tid) (h : tid ∉ [505]) : (s_131 z) tid = (s_130 z) tid := by
   unfold s_131
   dsimp only [pL, pmNode_299, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_130
 theorem w_130_0 (z : Store) : (s_131 z) 505 = v_130_0 z := by
   unfold s_131
   dsimp only [pL, pmNode_299, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_130_0, r_130_0 z, r_130_1 z] <;> rfl
 #a w_130_0
 theorem h_130_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_130_0 z).shape = [1, 16, 2, 16] := by
   unfold v_130_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_119_0 z z_]
 #a h_130_0
 attribute [local irreducible] v_130_0
 attribute [local irreducible] s_131
 theorem r_131_0 (z : Store) : (s_131 z) 505 = (v_130_0 z) := w_130_0 z
 #a r_131_0
 def v_131_0 (z : Store) : Tensor := transposeAxes 1 2 (v_130_0 z)
 def s_132 (z : Store) : Store := storeSet (s_131 z) [(506, transposeAxes 1 2 ((s_131 z) 505))]
 theorem t_131 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_300) (pmPeers pmNode_300) (s_131 z) pmNode_300 none = some (s_132 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_131
 theorem k_131 (z : Store) (tid : Tid) (h : tid ∉ [506]) : (s_132 z) tid = (s_131 z) tid := by
   unfold s_132
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_131
 theorem w_131_0 (z : Store) : (s_132 z) 506 = v_131_0 z := by
   unfold s_132
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_131_0, r_131_0 z] <;> rfl
 #a w_131_0
 theorem h_131_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_131_0 z).shape = [1, 2, 16, 16] := by
   unfold v_131_0
   change listSwapAt _ _ _ = _
   rw [h_130_0 z z_]
   rfl
 #a h_131_0
 attribute [local irreducible] v_131_0
 attribute [local irreducible] s_132
 theorem n_128_132 (z : Store) (tid : Tid) (h : tid ∉ ([206, 207, 505, 506] : List Tid)) : (s_132 z) tid = (s_128 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_128 z) (k_129 z)) (pF _ _ _ _ _ (k_130 z) (k_131 z)) tid h
 #a n_128_132
 theorem r_132_0 (z : Store) : (s_132 z) 193 = (v_113_0 z) := pR (n_128_132 z) (r_128_0 z)
 #a r_132_0
 theorem r_132_1 (z : Store) : (s_132 z) 496 = (v_121_0 z) := pR (n_128_132 z) (r_128_1 z)
 #a r_132_1
 def v_132_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_113_0 z), (v_121_0 z)]
 def s_133 (z : Store) : Store := storeSet (s_132 z) [(509, reduceScatterPrimDimN 1 2 1 [((s_132 z) 193), ((s_132 z) 496)])]
 theorem t_132 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_301) (pmPeers pmNode_301) (s_132 z) pmNode_301 none = some (s_133 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_132 z) pmNode_301 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_132
 theorem k_132 (z : Store) (tid : Tid) (h : tid ∉ [509]) : (s_133 z) tid = (s_132 z) tid := by
   unfold s_133
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_132
 theorem w_132_0 (z : Store) : (s_133 z) 509 = v_132_0 z := by
   unfold s_133
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_132_0, r_132_0 z, r_132_1 z] <;> rfl
 #a w_132_0
 theorem h_132_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_132_0 z).shape = [1, 8, 64] := by
   unfold v_132_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_113_0 z) rfl]
     exact h_113_0 z z_
   · decide
 #a h_132_0
 attribute [local irreducible] v_132_0
 attribute [local irreducible] s_133
 theorem r_133_0 (z : Store) : (s_133 z) 509 = (v_132_0 z) := w_132_0 z
 #a r_133_0
 def v_133_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_132_0 z)
 def s_134 (z : Store) : Store := storeSet (s_133 z) [(510, fw_view [1, 8, 4, 16] ((s_133 z) 509))]
 theorem t_133 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_302) (pmPeers pmNode_302) (s_133 z) pmNode_302 none = some (s_134 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_133
 theorem k_133 (z : Store) (tid : Tid) (h : tid ∉ [510]) : (s_134 z) tid = (s_133 z) tid := by
   unfold s_134
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_133
 theorem w_133_0 (z : Store) : (s_134 z) 510 = v_133_0 z := by
   unfold s_134
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_133_0, r_133_0 z] <;> rfl
 #a w_133_0
 theorem h_133_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_133_0 z).shape = [1, 8, 4, 16] := by
   unfold v_133_0
   rfl
 #a h_133_0
 attribute [local irreducible] v_133_0
 attribute [local irreducible] s_134
 theorem r_134_0 (z : Store) : (s_134 z) 207 = (v_129_0 z) := pR (k_133 z) (pR (k_132 z) (pR (k_131 z) (pR (k_130 z) (w_129_0 z))))
 #a r_134_0
 theorem r_134_1 (z : Store) : (s_134 z) 510 = (v_133_0 z) := w_133_0 z
 #a r_134_1
 def v_134_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_129_0 z), (v_133_0 z)]
 theorem g_134 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_67) (s_134 z) pmNode_67 1 3 210 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_67, r_134_0 z, r_134_1 z, h_129_0 z z_, h_133_0 z z_]
 #a g_134
 def s_135 (z : Store) : Store := pL [0, 1] (s_134 z) pmNode_67 1 3
 theorem t_134 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_67) (pmPeers pmNode_67) (s_134 z) pmNode_67 none = some (s_135 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_67) (s_134 z) pmNode_67).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 210 (by decide) (g_134 z z_)]
   rfl
 #a t_134
 theorem k_134 (z : Store) (tid : Tid) (h : tid ∉ [210]) : (s_135 z) tid = (s_134 z) tid := by
   unfold s_135
   dsimp only [pL, pmNode_67, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_134
 theorem w_134_0 (z : Store) : (s_135 z) 210 = v_134_0 z := by
   unfold s_135
   dsimp only [pL, pmNode_67, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_134_0, r_134_0 z, r_134_1 z] <;> rfl
 #a w_134_0
 theorem h_134_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_134_0 z).shape = [1, 16, 4, 8] := by
   unfold v_134_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_129_0 z z_]
 #a h_134_0
 attribute [local irreducible] v_134_0
 attribute [local irreducible] s_135
 theorem r_135_0 (z : Store) : (s_135 z) 210 = (v_134_0 z) := w_134_0 z
 #a r_135_0
 def v_135_0 (z : Store) : Tensor := transposeAxes 1 2 (v_134_0 z)
 def s_136 (z : Store) : Store := storeSet (s_135 z) [(211, transposeAxes 1 2 ((s_135 z) 210))]
 theorem t_135 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_68) (pmPeers pmNode_68) (s_135 z) pmNode_68 none = some (s_136 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_135
 theorem k_135 (z : Store) (tid : Tid) (h : tid ∉ [211]) : (s_136 z) tid = (s_135 z) tid := by
   unfold s_136
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_135
 theorem w_135_0 (z : Store) : (s_136 z) 211 = v_135_0 z := by
   unfold s_136
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_135_0, r_135_0 z] <;> rfl
 #a w_135_0
 theorem h_135_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_135_0 z).shape = [1, 4, 16, 8] := by
   unfold v_135_0
   change listSwapAt _ _ _ = _
   rw [h_134_0 z z_]
   rfl
 #a h_135_0
 attribute [local irreducible] v_135_0
 attribute [local irreducible] s_136
 theorem n_132_136 (z : Store) (tid : Tid) (h : tid ∉ ([509, 510, 210, 211] : List Tid)) : (s_136 z) tid = (s_132 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_132 z) (k_133 z)) (pF _ _ _ _ _ (k_134 z) (k_135 z)) tid h
 #a n_132_136
 theorem n_128_136 (z : Store) (tid : Tid) (h : tid ∉ ([206, 207, 505, 506, 509, 510, 210, 211] : List Tid)) : (s_136 z) tid = (s_128 z) tid := by
   exact pF _ _ _ _ _ (n_128_132 z) (n_132_136 z) tid h
 #a n_128_136
 theorem r_136_0 (z : Store) : (s_136 z) 196 = (v_115_0 z) := pR (n_128_136 z) (pR (n_120_128 z) (pR (n_116_120 z) (w_115_0 z)))
 #a r_136_0
 theorem r_136_1 (z : Store) : (s_136 z) 499 = (v_123_0 z) := pR (n_128_136 z) (pR (n_124_128 z) (w_123_0 z))
 #a r_136_1
 def v_136_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 0 [(v_115_0 z), (v_123_0 z)]
 def s_137 (z : Store) : Store := storeSet (s_136 z) [(214, reduceScatterPrimDimN 2 2 0 [((s_136 z) 196), ((s_136 z) 499)])]
 theorem t_136 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_69) (pmPeers pmNode_69) (s_136 z) pmNode_69 none = some (s_137 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_136 z) pmNode_69 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_136
 theorem k_136 (z : Store) (tid : Tid) (h : tid ∉ [214]) : (s_137 z) tid = (s_136 z) tid := by
   unfold s_137
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_136
 theorem w_136_0 (z : Store) : (s_137 z) 214 = v_136_0 z := by
   unfold s_137
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_136_0, r_136_0 z, r_136_1 z] <;> rfl
 #a w_136_0
 theorem h_136_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_136_0 z).shape = [1, 16, 32] := by
   unfold v_136_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_115_0 z) rfl]
     exact h_115_0 z z_
   · decide
 #a h_136_0
 attribute [local irreducible] v_136_0
 attribute [local irreducible] s_137
 theorem r_137_0 (z : Store) : (s_137 z) 214 = (v_136_0 z) := w_136_0 z
 #a r_137_0
 def v_137_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_136_0 z)
 def s_138 (z : Store) : Store := storeSet (s_137 z) [(215, fw_view [1, 16, 2, 16] ((s_137 z) 214))]
 theorem t_137 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_70) (pmPeers pmNode_70) (s_137 z) pmNode_70 none = some (s_138 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_137
 theorem k_137 (z : Store) (tid : Tid) (h : tid ∉ [215]) : (s_138 z) tid = (s_137 z) tid := by
   unfold s_138
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_137
 theorem w_137_0 (z : Store) : (s_138 z) 215 = v_137_0 z := by
   unfold s_138
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_137_0, r_137_0 z] <;> rfl
 #a w_137_0
 theorem h_137_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_137_0 z).shape = [1, 16, 2, 16] := by
   unfold v_137_0
   rfl
 #a h_137_0
 attribute [local irreducible] v_137_0
 attribute [local irreducible] s_138
 record_prefix_opacity v_129_0 s_130 v_130_0 s_131 v_131_0 s_132 v_132_0 s_133 v_133_0 s_134 v_134_0 s_135 v_135_0 s_136 v_136_0 s_137 v_137_0 s_138

 end
 end TrainVerify.Denote.RuntimeWorld
