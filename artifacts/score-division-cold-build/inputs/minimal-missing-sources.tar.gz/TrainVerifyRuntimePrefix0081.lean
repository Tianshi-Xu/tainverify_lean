import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0080
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_646_0 (z : Store) : (s_646 z) 1185 = (v_645_0 z) := w_645_0 z
 #a r_646_0
 theorem r_646_1 (z : Store) : (s_646 z) 1181 = (v_624_0 z) := pR (k_645 z) (pR (k_644 z) (pR (n_640_644 z) (pR (n_632_640 z) (pR (n_628_632 z) (pR (k_627 z) (pR (k_626 z) (pR (k_625 z) (r_625_0 z))))))))
 #a r_646_1
 theorem r_646_2 (z : Store) : (s_646 z) 923 = (z 923) := pR (k_645 z) (pR (k_644 z) (pR (n_640_644 z) (pR (n_632_640 z) (pR (n_628_632 z) (pR (k_627 z) (pR (k_626 z) (pR (k_625 z) (r_625_1 z))))))))
 #a r_646_2
 theorem r_646_3 (z : Store) : (s_646 z) 924 = (z 924) := pR (k_645 z) (pR (k_644 z) (pR (n_640_644 z) (pR (n_632_640 z) (pR (n_628_632 z) (pR (k_627 z) (pR (k_626 z) (pR (k_625 z) (r_625_2 z))))))))
 #a r_646_3
 def v_646_0 (z : Store) : Tensor := (bw_layernorm (v_645_0 z) (v_624_0 z) (z 923) (z 924)).1
 def v_646_1 (z : Store) : Tensor := (bw_layernorm (v_645_0 z) (v_624_0 z) (z 923) (z 924)).2.1
 def v_646_2 (z : Store) : Tensor := (bw_layernorm (v_645_0 z) (v_624_0 z) (z 923) (z 924)).2.2
 def s_647 (z : Store) : Store := storeSet (s_646 z) [(1183, (bw_layernorm ((s_646 z) 1185) ((s_646 z) 1181) ((s_646 z) 923) ((s_646 z) 924)).1), (977, (bw_layernorm ((s_646 z) 1185) ((s_646 z) 1181) ((s_646 z) 923) ((s_646 z) 924)).2.1), (979, (bw_layernorm ((s_646 z) 1185) ((s_646 z) 1181) ((s_646 z) 923) ((s_646 z) 924)).2.2)]
 theorem t_646 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_819) (pmPeers pmNode_819) (s_646 z) pmNode_819 none = some (s_647 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_646
 theorem k_646 (z : Store) (tid : Tid) (h : tid ∉ [1183, 977, 979]) : (s_647 z) tid = (s_646 z) tid := by
   unfold s_647
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_646
 theorem w_646_0 (z : Store) : (s_647 z) 1183 = v_646_0 z := by
   unfold s_647
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_646_0, r_646_0 z, r_646_1 z, r_646_2 z, r_646_3 z] <;> rfl
 #a w_646_0
 theorem h_646_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_646_0 z).shape = [1, 8, 64] := by
   unfold v_646_0
   rw [bw_layernorm_dx_shape (v_645_0 z) (v_624_0 z) (z 923) (z 924) 64 [8, 1] (by rw [h_624_0 z z_]; rfl)]
   exact h_624_0 z z_
 #a h_646_0
 attribute [local irreducible] v_646_0
 theorem w_646_1 (z : Store) : (s_647 z) 977 = v_646_1 z := by
   unfold s_647
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_646_1, r_646_0 z, r_646_1 z, r_646_2 z, r_646_3 z] <;> rfl
 #a w_646_1
 theorem h_646_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_646_1 z).shape = [64] := by
   unfold v_646_1
   rw [bw_layernorm_dw_shape (v_645_0 z) (v_624_0 z) (z 923) (z 924) 64 [8, 1] (by rw [h_624_0 z z_]; rfl)]
   exact i_96 z z_
 #a h_646_1
 attribute [local irreducible] v_646_1
 theorem w_646_2 (z : Store) : (s_647 z) 979 = v_646_2 z := by
   unfold s_647
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_646_2, r_646_0 z, r_646_1 z, r_646_2 z, r_646_3 z] <;> rfl
 #a w_646_2
 theorem h_646_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_646_2 z).shape = [64] := by
   unfold v_646_2
   rw [bw_layernorm_db_shape (v_645_0 z) (v_624_0 z) (z 923) (z 924) 64 [8, 1] (by rw [h_624_0 z z_]; rfl)]
   exact i_97 z z_
 #a h_646_2
 attribute [local irreducible] v_646_2
 attribute [local irreducible] s_647
 theorem r_647_0 (z : Store) : (s_647 z) 1183 = (v_646_0 z) := w_646_0 z
 #a r_647_0
 theorem r_647_1 (z : Store) : (s_647 z) 1180 = (v_623_0 z) := pR (k_646 z) (pR (k_645 z) (pR (k_644 z) (pR (n_640_644 z) (pR (n_624_640 z) (r_624_0 z)))))
 #a r_647_1
 theorem r_647_2 (z : Store) : (s_647 z) 1178 = (v_622_0 z) := pR (k_646 z) (pR (k_645 z) (pR (k_644 z) (pR (n_640_644 z) (pR (n_624_640 z) (r_624_1 z)))))
 #a r_647_2
 def v_647_0 (z : Store) : Tensor := (bw_add2 (v_646_0 z) (v_623_0 z) (v_622_0 z)).1
 def v_647_1 (z : Store) : Tensor := (bw_add2 (v_646_0 z) (v_623_0 z) (v_622_0 z)).2
 def s_648 (z : Store) : Store := storeSet (s_647 z) [(1182, (bw_add2 ((s_647 z) 1183) ((s_647 z) 1180) ((s_647 z) 1178)).1), (1179, (bw_add2 ((s_647 z) 1183) ((s_647 z) 1180) ((s_647 z) 1178)).2)]
 theorem t_647 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_820) (pmPeers pmNode_820) (s_647 z) pmNode_820 none = some (s_648 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_647
 theorem k_647 (z : Store) (tid : Tid) (h : tid ∉ [1182, 1179]) : (s_648 z) tid = (s_647 z) tid := by
   unfold s_648
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_647
 theorem w_647_0 (z : Store) : (s_648 z) 1182 = v_647_0 z := by
   unfold s_648
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_647_0, r_647_0 z, r_647_1 z, r_647_2 z] <;> rfl
 #a w_647_0
 theorem h_647_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_647_0 z).shape = [1, 8, 64] := by
   unfold v_647_0
   exact h_623_0 z z_
 #a h_647_0
 attribute [local irreducible] v_647_0
 theorem w_647_1 (z : Store) : (s_648 z) 1179 = v_647_1 z := by
   unfold s_648
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_647_1, r_647_0 z, r_647_1 z, r_647_2 z] <;> rfl
 #a w_647_1
 theorem h_647_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_647_1 z).shape = [1, 8, 64] := by
   unfold v_647_1
   exact h_622_0 z z_
 #a h_647_1
 attribute [local irreducible] v_647_1
 attribute [local irreducible] s_648
 theorem r_648_0 (z : Store) : (s_648 z) 879 = (v_644_0 z) := pR (k_647 z) (pR (k_646 z) (pR (k_645 z) (w_644_0 z)))
 #a r_648_0
 theorem r_648_1 (z : Store) : (s_648 z) 1182 = (v_647_0 z) := w_647_0 z
 #a r_648_1
 def v_648_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_644_0 z), (v_647_0 z)]
 theorem g_648 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_585) (s_648 z) pmNode_585 1 2 908 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_585, r_648_0 z, r_648_1 z, h_644_0 z z_, h_647_0 z z_]
 #a g_648
 def s_649 (z : Store) : Store := pL [2, 3] (s_648 z) pmNode_585 1 2
 theorem t_648 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_585) (pmPeers pmNode_585) (s_648 z) pmNode_585 none = some (s_649 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_585) (s_648 z) pmNode_585).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 908 (by decide) (g_648 z z_)]
   rfl
 #a t_648
 theorem k_648 (z : Store) (tid : Tid) (h : tid ∉ [908]) : (s_649 z) tid = (s_648 z) tid := by
   unfold s_649
   dsimp only [pL, pmNode_585, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_648
 theorem w_648_0 (z : Store) : (s_649 z) 908 = v_648_0 z := by
   unfold s_649
   dsimp only [pL, pmNode_585, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_648_0, r_648_0 z, r_648_1 z] <;> rfl
 #a w_648_0
 theorem h_648_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_648_0 z).shape = [1, 16, 32] := by
   unfold v_648_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_644_0 z z_]
 #a h_648_0
 attribute [local irreducible] v_648_0
 attribute [local irreducible] s_649
 theorem n_644_648 (z : Store) (tid : Tid) (h : tid ∉ ([879, 876, 1185, 1183, 977, 979, 1182, 1179] : List Tid)) : (s_648 z) tid = (s_644 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_644 z) (k_645 z)) (pF _ _ _ _ _ (k_646 z) (k_647 z)) tid h
 #a n_644_648
 theorem n_640_648 (z : Store) (tid : Tid) (h : tid ∉ ([1188, 1187, 982, 882, 880, 674, 676, 879, 876, 1185, 1183, 977, 979, 1182, 1179] : List Tid)) : (s_648 z) tid = (s_640 z) tid := by
   exact pF _ _ _ _ _ (n_640_644 z) (n_644_648 z) tid h
 #a n_640_648
 theorem r_649_0 (z : Store) : (s_649 z) 876 = (v_644_1 z) := pR (k_648 z) (pR (k_647 z) (pR (k_646 z) (pR (k_645 z) (w_644_1 z))))
 #a r_649_0
 theorem r_649_1 (z : Store) : (s_649 z) 872 = (v_615_0 z) := pR (k_648 z) (pR (n_640_648 z) (pR (n_624_640 z) (pR (n_616_624 z) (r_616_0 z))))
 #a r_649_1
 theorem r_649_2 (z : Store) : (s_649 z) 619 = (z 619) := pR (k_648 z) (pR (n_640_648 z) (pR (n_624_640 z) (pR (n_616_624 z) (r_616_1 z))))
 #a r_649_2
 def v_649_0 (z : Store) : Tensor := (bw_linear (v_644_1 z) (v_615_0 z) (z 619)).1
 def v_649_1 (z : Store) : Tensor := (bw_linear (v_644_1 z) (v_615_0 z) (z 619)).2
 def s_650 (z : Store) : Store := storeSet (s_649 z) [(874, (bw_linear ((s_649 z) 876) ((s_649 z) 872) ((s_649 z) 619)).1), (672, (bw_linear ((s_649 z) 876) ((s_649 z) 872) ((s_649 z) 619)).2)]
 theorem t_649 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_586) (pmPeers pmNode_586) (s_649 z) pmNode_586 none = some (s_650 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_649
 theorem k_649 (z : Store) (tid : Tid) (h : tid ∉ [874, 672]) : (s_650 z) tid = (s_649 z) tid := by
   unfold s_650
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_649
 theorem w_649_0 (z : Store) : (s_650 z) 874 = v_649_0 z := by
   unfold s_650
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_649_0, r_649_0 z, r_649_1 z, r_649_2 z] <;> rfl
 #a w_649_0
 theorem h_649_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_649_0 z).shape = [1, 8, 256] := by
   unfold v_649_0
   exact bw_linear_3d_fst_shape 1 8 64 256 (v_644_1 z) (v_615_0 z) (z 619) (h_644_1 z z_) (h_615_0 z z_) (i_92 z z_)
 #a h_649_0
 attribute [local irreducible] v_649_0
 theorem w_649_1 (z : Store) : (s_650 z) 672 = v_649_1 z := by
   unfold s_650
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_649_1, r_649_0 z, r_649_1 z, r_649_2 z] <;> rfl
 #a w_649_1
 theorem h_649_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_649_1 z).shape = [64, 256] := by
   unfold v_649_1
   exact bw_linear_3d_snd_shape 1 8 64 256 (v_644_1 z) (v_615_0 z) (z 619) (h_644_1 z z_) (h_615_0 z z_) (i_92 z z_)
 #a h_649_1
 attribute [local irreducible] v_649_1
 attribute [local irreducible] s_650
 theorem r_650_0 (z : Store) : (s_650 z) 874 = (v_649_0 z) := w_649_0 z
 #a r_650_0
 theorem r_650_1 (z : Store) : (s_650 z) 871 = (v_614_0 z) := pR (k_649 z) (pR (k_648 z) (pR (n_640_648 z) (pR (n_624_640 z) (pR (n_616_624 z) (pR (k_615 z) (r_615_0 z))))))
 #a r_650_1
 def v_650_0 (z : Store) : Tensor := bw_gelu (v_649_0 z) (v_614_0 z)
 def s_651 (z : Store) : Store := storeSet (s_650 z) [(873, bw_gelu ((s_650 z) 874) ((s_650 z) 871))]
 theorem t_650 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_587) (pmPeers pmNode_587) (s_650 z) pmNode_587 none = some (s_651 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_650
 theorem k_650 (z : Store) (tid : Tid) (h : tid ∉ [873]) : (s_651 z) tid = (s_650 z) tid := by
   unfold s_651
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_650
 theorem w_650_0 (z : Store) : (s_651 z) 873 = v_650_0 z := by
   unfold s_651
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_650_0, r_650_0 z, r_650_1 z] <;> rfl
 #a w_650_0
 theorem h_650_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_650_0 z).shape = [1, 8, 256] := by
   unfold v_650_0
   exact h_614_0 z z_
 #a h_650_0
 attribute [local irreducible] v_650_0
 attribute [local irreducible] s_651
 theorem r_651_0 (z : Store) : (s_651 z) 879 = (v_644_0 z) := pR (k_650 z) (pR (k_649 z) (pR (k_648 z) (r_648_0 z)))
 #a r_651_0
 theorem r_651_1 (z : Store) : (s_651 z) 1182 = (v_647_0 z) := pR (k_650 z) (pR (k_649 z) (pR (k_648 z) (r_648_1 z)))
 #a r_651_1
 def v_651_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_644_0 z), (v_647_0 z)]
 theorem g_651 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_821) (s_651 z) pmNode_821 1 2 1211 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_821, r_651_0 z, r_651_1 z, h_644_0 z z_, h_647_0 z z_]
 #a g_651
 def s_652 (z : Store) : Store := pL [2, 3] (s_651 z) pmNode_821 1 2
 theorem t_651 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_821) (pmPeers pmNode_821) (s_651 z) pmNode_821 none = some (s_652 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_821) (s_651 z) pmNode_821).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1211 (by decide) (g_651 z z_)]
   rfl
 #a t_651
 theorem k_651 (z : Store) (tid : Tid) (h : tid ∉ [1211]) : (s_652 z) tid = (s_651 z) tid := by
   unfold s_652
   dsimp only [pL, pmNode_821, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_651
 theorem w_651_0 (z : Store) : (s_652 z) 1211 = v_651_0 z := by
   unfold s_652
   dsimp only [pL, pmNode_821, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_651_0, r_651_0 z, r_651_1 z] <;> rfl
 #a w_651_0
 theorem h_651_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_651_0 z).shape = [1, 16, 32] := by
   unfold v_651_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_644_0 z z_]
 #a h_651_0
 attribute [local irreducible] v_651_0
 attribute [local irreducible] s_652
 theorem n_648_652 (z : Store) (tid : Tid) (h : tid ∉ ([908, 874, 672, 873, 1211] : List Tid)) : (s_652 z) tid = (s_648 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_648 z) (k_649 z)) (pF _ _ _ _ _ (k_650 z) (k_651 z)) tid h
 #a n_648_652
 record_prefix_opacity v_646_0 v_646_1 v_646_2 s_647 v_647_0 v_647_1 s_648 v_648_0 s_649 v_649_0 v_649_1 s_650 v_650_0 s_651 v_651_0 s_652

 end
 end TrainVerify.Denote.RuntimeWorld
