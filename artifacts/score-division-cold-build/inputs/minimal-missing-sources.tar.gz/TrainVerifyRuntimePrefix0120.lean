import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0119
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_930_0 (z : Store) : (s_930 z) 37 = (v_330_2 z) := pR (k_929 z) (pR (k_928 z) (pR (n_896_928 z) (pR (k_895 z) (r_895_0 z))))
 #a r_930_0
 theorem r_930_1 (z : Store) : (s_930 z) 340 = (v_335_2 z) := pR (k_929 z) (pR (k_928 z) (pR (n_896_928 z) (pR (k_895 z) (r_895_1 z))))
 #a r_930_1
 theorem r_930_2 (z : Store) : (s_930 z) 643 = (v_752_2 z) := pR (k_929 z) (pR (k_928 z) (pR (n_896_928 z) (pR (k_895 z) (r_895_2 z))))
 #a r_930_2
 theorem r_930_3 (z : Store) : (s_930 z) 946 = (v_757_2 z) := pR (k_929 z) (pR (k_928 z) (pR (n_896_928 z) (pR (k_895 z) (r_895_3 z))))
 #a r_930_3
 def v_930_0 (z : Store) : Tensor := cross_dp_wred [(v_330_2 z), (v_335_2 z), (v_752_2 z), (v_757_2 z)]
 theorem g_930 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_930) (s_930 z) pmNode_930 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_930, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_930_1 z, r_930_0 z]
     exact (h_335_2 z z_).trans (h_330_2 z z_).symm
   · rw [r_930_2 z, r_930_0 z]
     exact (h_752_2 z z_).trans (h_330_2 z z_).symm
   · rw [r_930_3 z, r_930_0 z]
     exact (h_757_2 z z_).trans (h_330_2 z z_).symm
 #a g_930
 def s_931 (z : Store) : Store := storeSet (s_930 z) [(947, cross_dp_wred [((s_930 z) 37), ((s_930 z) 340), ((s_930 z) 643), ((s_930 z) 946)])]
 theorem t_930 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_930) (pmPeers pmNode_930) (s_930 z) pmNode_930 none = some (s_931 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_930) (s_930 z) pmNode_930 = _
   rw [wredStep, if_pos ⟨by decide, g_930 z z_⟩]
   rfl
 #a t_930
 theorem k_930 (z : Store) (tid : Tid) (h : tid ∉ [947]) : (s_931 z) tid = (s_930 z) tid := by
   unfold s_931
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_930
 theorem w_930_0 (z : Store) : (s_931 z) 947 = v_930_0 z := by
   unfold s_931
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_930_0, r_930_0 z, r_930_1 z, r_930_2 z, r_930_3 z] <;> rfl
 #a w_930_0
 theorem h_930_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_930_0 z).shape = [64] := by
   unfold v_930_0
   rw [tensorSum_shape]
   exact h_330_2 z z_
 #a h_930_0
 attribute [local irreducible] v_930_0
 attribute [local irreducible] s_931
 theorem r_931_0 (z : Store) : (s_931 z) 39 = (v_329_1 z) := pR (k_930 z) (pR (k_929 z) (pR (k_928 z) (pR (n_896_928 z) (r_896_0 z))))
 #a r_931_0
 theorem r_931_1 (z : Store) : (s_931 z) 342 = (v_334_1 z) := pR (k_930 z) (pR (k_929 z) (pR (k_928 z) (pR (n_896_928 z) (r_896_1 z))))
 #a r_931_1
 theorem r_931_2 (z : Store) : (s_931 z) 645 = (v_751_1 z) := pR (k_930 z) (pR (k_929 z) (pR (k_928 z) (pR (n_896_928 z) (r_896_2 z))))
 #a r_931_2
 theorem r_931_3 (z : Store) : (s_931 z) 948 = (v_756_1 z) := pR (k_930 z) (pR (k_929 z) (pR (k_928 z) (pR (n_896_928 z) (r_896_3 z))))
 #a r_931_3
 def v_931_0 (z : Store) : Tensor := cross_dp_wred [(v_329_1 z), (v_334_1 z), (v_751_1 z), (v_756_1 z)]
 theorem g_931 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_931) (s_931 z) pmNode_931 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_931, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_931_1 z, r_931_0 z]
     exact (h_334_1 z z_).trans (h_329_1 z z_).symm
   · rw [r_931_2 z, r_931_0 z]
     exact (h_751_1 z z_).trans (h_329_1 z z_).symm
   · rw [r_931_3 z, r_931_0 z]
     exact (h_756_1 z z_).trans (h_329_1 z z_).symm
 #a g_931
 def s_932 (z : Store) : Store := storeSet (s_931 z) [(949, cross_dp_wred [((s_931 z) 39), ((s_931 z) 342), ((s_931 z) 645), ((s_931 z) 948)])]
 theorem t_931 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_931) (pmPeers pmNode_931) (s_931 z) pmNode_931 none = some (s_932 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_931) (s_931 z) pmNode_931 = _
   rw [wredStep, if_pos ⟨by decide, g_931 z z_⟩]
   rfl
 #a t_931
 theorem k_931 (z : Store) (tid : Tid) (h : tid ∉ [949]) : (s_932 z) tid = (s_931 z) tid := by
   unfold s_932
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_931
 theorem w_931_0 (z : Store) : (s_932 z) 949 = v_931_0 z := by
   unfold s_932
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_931_0, r_931_0 z, r_931_1 z, r_931_2 z, r_931_3 z] <;> rfl
 #a w_931_0
 theorem h_931_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_931_0 z).shape = [256, 64] := by
   unfold v_931_0
   rw [tensorSum_shape]
   exact h_329_1 z z_
 #a h_931_0
 attribute [local irreducible] v_931_0
 attribute [local irreducible] s_932
 theorem n_928_932 (z : Store) (tid : Tid) (h : tid ∉ ([943, 945, 947, 949] : List Tid)) : (s_932 z) tid = (s_928 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_928 z) (k_929 z)) (pF _ _ _ _ _ (k_930 z) (k_931 z)) tid h
 #a n_928_932
 theorem r_932_0 (z : Store) : (s_932 z) 41 = (v_327_1 z) := pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (pR (k_898 z) (pR (k_897 z) (r_897_0 z)))))))
 #a r_932_0
 theorem r_932_1 (z : Store) : (s_932 z) 344 = (v_332_1 z) := pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (pR (k_898 z) (pR (k_897 z) (r_897_1 z)))))))
 #a r_932_1
 theorem r_932_2 (z : Store) : (s_932 z) 647 = (v_749_1 z) := pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (pR (k_898 z) (pR (k_897 z) (r_897_2 z)))))))
 #a r_932_2
 theorem r_932_3 (z : Store) : (s_932 z) 950 = (v_754_1 z) := pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (pR (k_898 z) (pR (k_897 z) (r_897_3 z)))))))
 #a r_932_3
 def v_932_0 (z : Store) : Tensor := cross_dp_wred [(v_327_1 z), (v_332_1 z), (v_749_1 z), (v_754_1 z)]
 theorem g_932 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_932) (s_932 z) pmNode_932 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_932, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_932_1 z, r_932_0 z]
     exact (h_332_1 z z_).trans (h_327_1 z z_).symm
   · rw [r_932_2 z, r_932_0 z]
     exact (h_749_1 z z_).trans (h_327_1 z z_).symm
   · rw [r_932_3 z, r_932_0 z]
     exact (h_754_1 z z_).trans (h_327_1 z z_).symm
 #a g_932
 def s_933 (z : Store) : Store := storeSet (s_932 z) [(951, cross_dp_wred [((s_932 z) 41), ((s_932 z) 344), ((s_932 z) 647), ((s_932 z) 950)])]
 theorem t_932 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_932) (pmPeers pmNode_932) (s_932 z) pmNode_932 none = some (s_933 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_932) (s_932 z) pmNode_932 = _
   rw [wredStep, if_pos ⟨by decide, g_932 z z_⟩]
   rfl
 #a t_932
 theorem k_932 (z : Store) (tid : Tid) (h : tid ∉ [951]) : (s_933 z) tid = (s_932 z) tid := by
   unfold s_933
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_932
 theorem w_932_0 (z : Store) : (s_933 z) 951 = v_932_0 z := by
   unfold s_933
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_932_0, r_932_0 z, r_932_1 z, r_932_2 z, r_932_3 z] <;> rfl
 #a w_932_0
 theorem h_932_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_932_0 z).shape = [64, 256] := by
   unfold v_932_0
   rw [tensorSum_shape]
   exact h_327_1 z z_
 #a h_932_0
 attribute [local irreducible] v_932_0
 attribute [local irreducible] s_933
 theorem r_933_0 (z : Store) : (s_933 z) 43 = (v_316_1 z) := pR (k_932 z) (pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (pR (k_898 z) (r_898_0 z)))))))
 #a r_933_0
 theorem r_933_1 (z : Store) : (s_933 z) 346 = (v_319_1 z) := pR (k_932 z) (pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (pR (k_898 z) (r_898_1 z)))))))
 #a r_933_1
 theorem r_933_2 (z : Store) : (s_933 z) 649 = (v_738_1 z) := pR (k_932 z) (pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (pR (k_898 z) (r_898_2 z)))))))
 #a r_933_2
 theorem r_933_3 (z : Store) : (s_933 z) 952 = (v_741_1 z) := pR (k_932 z) (pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (pR (k_898 z) (r_898_3 z)))))))
 #a r_933_3
 def v_933_0 (z : Store) : Tensor := cross_dp_wred [(v_316_1 z), (v_319_1 z), (v_738_1 z), (v_741_1 z)]
 theorem g_933 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_933) (s_933 z) pmNode_933 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_933, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_933_1 z, r_933_0 z]
     exact (h_319_1 z z_).trans (h_316_1 z z_).symm
   · rw [r_933_2 z, r_933_0 z]
     exact (h_738_1 z z_).trans (h_316_1 z z_).symm
   · rw [r_933_3 z, r_933_0 z]
     exact (h_741_1 z z_).trans (h_316_1 z z_).symm
 #a g_933
 def s_934 (z : Store) : Store := storeSet (s_933 z) [(953, cross_dp_wred [((s_933 z) 43), ((s_933 z) 346), ((s_933 z) 649), ((s_933 z) 952)])]
 theorem t_933 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_933) (pmPeers pmNode_933) (s_933 z) pmNode_933 none = some (s_934 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_933) (s_933 z) pmNode_933 = _
   rw [wredStep, if_pos ⟨by decide, g_933 z z_⟩]
   rfl
 #a t_933
 theorem k_933 (z : Store) (tid : Tid) (h : tid ∉ [953]) : (s_934 z) tid = (s_933 z) tid := by
   unfold s_934
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_933
 theorem w_933_0 (z : Store) : (s_934 z) 953 = v_933_0 z := by
   unfold s_934
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_933_0, r_933_0 z, r_933_1 z, r_933_2 z, r_933_3 z] <;> rfl
 #a w_933_0
 theorem h_933_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_933_0 z).shape = [64] := by
   unfold v_933_0
   rw [tensorSum_shape]
   exact h_316_1 z z_
 #a h_933_0
 attribute [local irreducible] v_933_0
 attribute [local irreducible] s_934
 theorem r_934_0 (z : Store) : (s_934 z) 45 = (v_316_2 z) := pR (k_933 z) (pR (k_932 z) (pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (r_899_0 z)))))))
 #a r_934_0
 theorem r_934_1 (z : Store) : (s_934 z) 348 = (v_319_2 z) := pR (k_933 z) (pR (k_932 z) (pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (r_899_1 z)))))))
 #a r_934_1
 theorem r_934_2 (z : Store) : (s_934 z) 651 = (v_738_2 z) := pR (k_933 z) (pR (k_932 z) (pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (r_899_2 z)))))))
 #a r_934_2
 theorem r_934_3 (z : Store) : (s_934 z) 954 = (v_741_2 z) := pR (k_933 z) (pR (k_932 z) (pR (n_928_932 z) (pR (n_912_928 z) (pR (n_904_912 z) (pR (n_900_904 z) (pR (k_899 z) (r_899_3 z)))))))
 #a r_934_3
 def v_934_0 (z : Store) : Tensor := cross_dp_wred [(v_316_2 z), (v_319_2 z), (v_738_2 z), (v_741_2 z)]
 theorem g_934 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_934) (s_934 z) pmNode_934 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_934, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_934_1 z, r_934_0 z]
     exact (h_319_2 z z_).trans (h_316_2 z z_).symm
   · rw [r_934_2 z, r_934_0 z]
     exact (h_738_2 z z_).trans (h_316_2 z z_).symm
   · rw [r_934_3 z, r_934_0 z]
     exact (h_741_2 z z_).trans (h_316_2 z z_).symm
 #a g_934
 def s_935 (z : Store) : Store := storeSet (s_934 z) [(955, cross_dp_wred [((s_934 z) 45), ((s_934 z) 348), ((s_934 z) 651), ((s_934 z) 954)])]
 theorem t_934 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_934) (pmPeers pmNode_934) (s_934 z) pmNode_934 none = some (s_935 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_934) (s_934 z) pmNode_934 = _
   rw [wredStep, if_pos ⟨by decide, g_934 z z_⟩]
   rfl
 #a t_934
 theorem k_934 (z : Store) (tid : Tid) (h : tid ∉ [955]) : (s_935 z) tid = (s_934 z) tid := by
   unfold s_935
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_934
 theorem w_934_0 (z : Store) : (s_935 z) 955 = v_934_0 z := by
   unfold s_935
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_934_0, r_934_0 z, r_934_1 z, r_934_2 z, r_934_3 z] <;> rfl
 #a w_934_0
 theorem h_934_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_934_0 z).shape = [64] := by
   unfold v_934_0
   rw [tensorSum_shape]
   exact h_316_2 z z_
 #a h_934_0
 attribute [local irreducible] v_934_0
 attribute [local irreducible] s_935
 theorem r_935_0 (z : Store) : (s_935 z) 320 = (v_421_0 z) := pR (k_934 z) (pR (k_933 z) (pR (k_932 z) (pR (n_928_932 z) (pR (n_912_928 z) (pR (k_911 z) (pR (k_910 z) (r_910_0 z)))))))
 #a r_935_0
 theorem r_935_1 (z : Store) : (s_935 z) 926 = (v_909_0 z) := pR (k_934 z) (pR (k_933 z) (pR (k_932 z) (pR (n_928_932 z) (pR (n_912_928 z) (pR (k_911 z) (pR (k_910 z) (r_910_1 z)))))))
 #a r_935_1
 def v_935_0 (z : Store) : Tensor := cross_dp_wred [(v_421_0 z), (v_909_0 z)]
 theorem g_935 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_935) (s_935 z) pmNode_935 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_935, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_935_1 z, r_935_0 z]
     exact (h_909_0 z z_).trans (h_421_0 z z_).symm
 #a g_935
 def s_936 (z : Store) : Store := storeSet (s_935 z) [(927, cross_dp_wred [((s_935 z) 320), ((s_935 z) 926)])]
 theorem t_935 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_935) (pmPeers pmNode_935) (s_935 z) pmNode_935 none = some (s_936 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_935) (s_935 z) pmNode_935 = _
   rw [wredStep, if_pos ⟨by decide, g_935 z z_⟩]
   rfl
 #a t_935
 theorem k_935 (z : Store) (tid : Tid) (h : tid ∉ [927]) : (s_936 z) tid = (s_935 z) tid := by
   unfold s_936
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_935
 theorem w_935_0 (z : Store) : (s_936 z) 927 = v_935_0 z := by
   unfold s_936
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_935_0, r_935_0 z, r_935_1 z] <;> rfl
 #a w_935_0
 theorem h_935_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_935_0 z).shape = [256, 32] := by
   unfold v_935_0
   rw [tensorSum_shape]
   exact h_421_0 z z_
 #a h_935_0
 attribute [local irreducible] v_935_0
 attribute [local irreducible] s_936
 theorem n_932_936 (z : Store) (tid : Tid) (h : tid ∉ ([951, 953, 955, 927] : List Tid)) : (s_936 z) tid = (s_932 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_932 z) (k_933 z)) (pF _ _ _ _ _ (k_934 z) (k_935 z)) tid h
 #a n_932_936
 theorem n_928_936 (z : Store) (tid : Tid) (h : tid ∉ ([943, 945, 947, 949, 951, 953, 955, 927] : List Tid)) : (s_936 z) tid = (s_928 z) tid := by
   exact pF _ _ _ _ _ (n_928_932 z) (n_932_936 z) tid h
 #a n_928_936
 theorem r_936_0 (z : Store) : (s_936 z) 360 = (v_250_1 z) := pR (n_928_936 z) (pR (n_912_928 z) (pR (k_911 z) (r_911_0 z)))
 #a r_936_0
 theorem r_936_1 (z : Store) : (s_936 z) 966 = (v_672_1 z) := pR (n_928_936 z) (pR (n_912_928 z) (pR (k_911 z) (r_911_1 z)))
 #a r_936_1
 def v_936_0 (z : Store) : Tensor := cross_dp_wred [(v_250_1 z), (v_672_1 z)]
 theorem g_936 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_936) (s_936 z) pmNode_936 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_936, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_936_1 z, r_936_0 z]
     exact (h_672_1 z z_).trans (h_250_1 z z_).symm
 #a g_936
 def s_937 (z : Store) : Store := storeSet (s_936 z) [(967, cross_dp_wred [((s_936 z) 360), ((s_936 z) 966)])]
 theorem t_936 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_936) (pmPeers pmNode_936) (s_936 z) pmNode_936 none = some (s_937 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_936) (s_936 z) pmNode_936 = _
   rw [wredStep, if_pos ⟨by decide, g_936 z z_⟩]
   rfl
 #a t_936
 theorem k_936 (z : Store) (tid : Tid) (h : tid ∉ [967]) : (s_937 z) tid = (s_936 z) tid := by
   unfold s_937
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_936
 theorem w_936_0 (z : Store) : (s_937 z) 967 = v_936_0 z := by
   unfold s_937
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_936_0, r_936_0 z, r_936_1 z] <;> rfl
 #a w_936_0
 theorem h_936_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_936_0 z).shape = [64, 32] := by
   unfold v_936_0
   rw [tensorSum_shape]
   exact h_250_1 z z_
 #a h_936_0
 attribute [local irreducible] v_936_0
 attribute [local irreducible] s_937
 record_prefix_opacity v_930_0 s_931 v_931_0 s_932 v_932_0 s_933 v_933_0 s_934 v_934_0 s_935 v_935_0 s_936 v_936_0 s_937

 end
 end TrainVerify.Denote.RuntimeWorld
