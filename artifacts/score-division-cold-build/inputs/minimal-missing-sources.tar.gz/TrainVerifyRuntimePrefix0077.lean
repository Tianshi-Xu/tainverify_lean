import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0076
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_613_0 (z : Store) : (s_613 z) 1171 = (v_612_0 z) := w_612_0 z
 #a r_613_0
 theorem r_613_1 (z : Store) : (s_613 z) 972 = (z 972) := pR (k_612 z) (pR (n_608_612 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_91 z)))))
 #a r_613_1
 def v_613_0 (z : Store) : Tensor := fw_linear (v_612_0 z) (z 972)
 def s_614 (z : Store) : Store := storeSet (s_613 z) [(1172, fw_linear ((s_613 z) 1171) ((s_613 z) 972))]
 theorem t_613 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_803) (pmPeers pmNode_803) (s_613 z) pmNode_803 none = some (s_614 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_613
 theorem k_613 (z : Store) (tid : Tid) (h : tid ∉ [1172]) : (s_614 z) tid = (s_613 z) tid := by
   unfold s_614
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_613
 theorem w_613_0 (z : Store) : (s_614 z) 1172 = v_613_0 z := by
   unfold s_614
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_613_0, r_613_0 z, r_613_1 z] <;> rfl
 #a w_613_0
 theorem h_613_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_613_0 z).shape = [1, 16, 256] := by
   unfold v_613_0
   exact fw_linear_3d_shape 1 16 32 256 (v_612_0 z) (z 972) (h_612_0 z z_) (i_91 z z_)
 #a h_613_0
 attribute [local irreducible] v_613_0
 attribute [local irreducible] s_614
 theorem r_614_0 (z : Store) : (s_614 z) 869 = (v_611_0 z) := pR (k_613 z) (pR (k_612 z) (w_611_0 z))
 #a r_614_0
 theorem r_614_1 (z : Store) : (s_614 z) 1172 = (v_613_0 z) := w_613_0 z
 #a r_614_1
 def v_614_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_611_0 z), (v_613_0 z)]
 def s_615 (z : Store) : Store := storeSet (s_614 z) [(871, reduceScatterPrimDimN 1 2 0 [((s_614 z) 869), ((s_614 z) 1172)])]
 theorem t_614 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_568) (pmPeers pmNode_568) (s_614 z) pmNode_568 none = some (s_615 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_614 z) pmNode_568 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_614
 theorem k_614 (z : Store) (tid : Tid) (h : tid ∉ [871]) : (s_615 z) tid = (s_614 z) tid := by
   unfold s_615
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_614
 theorem w_614_0 (z : Store) : (s_615 z) 871 = v_614_0 z := by
   unfold s_615
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_614_0, r_614_0 z, r_614_1 z] <;> rfl
 #a w_614_0
 theorem h_614_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_614_0 z).shape = [1, 8, 256] := by
   unfold v_614_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 256]
   · rw [allReducePrim_shape _ _ _ (v_611_0 z) rfl]
     exact h_611_0 z z_
   · decide
 #a h_614_0
 attribute [local irreducible] v_614_0
 attribute [local irreducible] s_615
 theorem r_615_0 (z : Store) : (s_615 z) 871 = (v_614_0 z) := w_614_0 z
 #a r_615_0
 def v_615_0 (z : Store) : Tensor := fw_gelu (v_614_0 z)
 def s_616 (z : Store) : Store := storeSet (s_615 z) [(872, fw_gelu ((s_615 z) 871))]
 theorem t_615 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_569) (pmPeers pmNode_569) (s_615 z) pmNode_569 none = some (s_616 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_615
 theorem k_615 (z : Store) (tid : Tid) (h : tid ∉ [872]) : (s_616 z) tid = (s_615 z) tid := by
   unfold s_616
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_615
 theorem w_615_0 (z : Store) : (s_616 z) 872 = v_615_0 z := by
   unfold s_616
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_615_0, r_615_0 z] <;> rfl
 #a w_615_0
 theorem h_615_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_615_0 z).shape = [1, 8, 256] := by
   unfold v_615_0
   exact h_614_0 z z_
 #a h_615_0
 attribute [local irreducible] v_615_0
 attribute [local irreducible] s_616
 theorem n_612_616 (z : Store) (tid : Tid) (h : tid ∉ ([1171, 1172, 871, 872] : List Tid)) : (s_616 z) tid = (s_612 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_612 z) (k_613 z)) (pF _ _ _ _ _ (k_614 z) (k_615 z)) tid h
 #a n_612_616
 theorem n_608_616 (z : Store) (tid : Tid) (h : tid ∉ ([1167, 1168, 868, 869, 1171, 1172, 871, 872] : List Tid)) : (s_616 z) tid = (s_608 z) tid := by
   exact pF _ _ _ _ _ (n_608_612 z) (n_612_616 z) tid h
 #a n_608_616
 theorem r_616_0 (z : Store) : (s_616 z) 872 = (v_615_0 z) := w_615_0 z
 #a r_616_0
 theorem r_616_1 (z : Store) : (s_616 z) 619 = (z 619) := pR (n_608_616 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_92 z))))
 #a r_616_1
 def v_616_0 (z : Store) : Tensor := fw_linear (v_615_0 z) (z 619)
 def s_617 (z : Store) : Store := storeSet (s_616 z) [(875, fw_linear ((s_616 z) 872) ((s_616 z) 619))]
 theorem t_616 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_570) (pmPeers pmNode_570) (s_616 z) pmNode_570 none = some (s_617 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_616
 theorem k_616 (z : Store) (tid : Tid) (h : tid ∉ [875]) : (s_617 z) tid = (s_616 z) tid := by
   unfold s_617
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_616
 theorem w_616_0 (z : Store) : (s_617 z) 875 = v_616_0 z := by
   unfold s_617
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_616_0, r_616_0 z, r_616_1 z] <;> rfl
 #a w_616_0
 theorem h_616_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_616_0 z).shape = [1, 8, 64] := by
   unfold v_616_0
   exact fw_linear_3d_shape 1 8 256 64 (v_615_0 z) (z 619) (h_615_0 z z_) (i_92 z z_)
 #a h_616_0
 attribute [local irreducible] v_616_0
 attribute [local irreducible] s_617
 theorem r_617_0 (z : Store) : (s_617 z) 907 = (v_602_1 z) := pR (k_616 z) (pR (n_608_616 z) (pR (n_604_608 z) (pR (k_603 z) (w_602_1 z))))
 #a r_617_0
 theorem r_617_1 (z : Store) : (s_617 z) 1210 = (v_605_1 z) := pR (k_616 z) (pR (n_608_616 z) (pR (k_607 z) (pR (k_606 z) (w_605_1 z))))
 #a r_617_1
 def v_617_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_602_1 z), (v_605_1 z)]
 theorem g_617 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_571) (s_617 z) pmNode_571 2 1 877 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_571, r_617_0 z, r_617_1 z, h_602_1 z z_, h_605_1 z z_]
 #a g_617
 def s_618 (z : Store) : Store := pL [2, 3] (s_617 z) pmNode_571 2 1
 theorem t_617 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_571) (pmPeers pmNode_571) (s_617 z) pmNode_571 none = some (s_618 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_571) (s_617 z) pmNode_571).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 877 (by decide) (g_617 z z_)]
   rfl
 #a t_617
 theorem k_617 (z : Store) (tid : Tid) (h : tid ∉ [877]) : (s_618 z) tid = (s_617 z) tid := by
   unfold s_618
   dsimp only [pL, pmNode_571, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_617
 theorem w_617_0 (z : Store) : (s_618 z) 877 = v_617_0 z := by
   unfold s_618
   dsimp only [pL, pmNode_571, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_617_0, r_617_0 z, r_617_1 z] <;> rfl
 #a w_617_0
 theorem h_617_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_617_0 z).shape = [1, 8, 64] := by
   unfold v_617_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_602_1 z z_]
 #a h_617_0
 attribute [local irreducible] v_617_0
 attribute [local irreducible] s_618
 theorem r_618_0 (z : Store) : (s_618 z) 877 = (v_617_0 z) := w_617_0 z
 #a r_618_0
 theorem r_618_1 (z : Store) : (s_618 z) 875 = (v_616_0 z) := pR (k_617 z) (w_616_0 z)
 #a r_618_1
 def v_618_0 (z : Store) : Tensor := elemwiseAdd (v_617_0 z) (v_616_0 z)
 def s_619 (z : Store) : Store := storeSet (s_618 z) [(878, elemwiseAdd ((s_618 z) 877) ((s_618 z) 875))]
 theorem t_618 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_572) (pmPeers pmNode_572) (s_618 z) pmNode_572 none = some (s_619 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_618
 theorem k_618 (z : Store) (tid : Tid) (h : tid ∉ [878]) : (s_619 z) tid = (s_618 z) tid := by
   unfold s_619
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_618
 theorem w_618_0 (z : Store) : (s_619 z) 878 = v_618_0 z := by
   unfold s_619
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_618_0, r_618_0 z, r_618_1 z] <;> rfl
 #a w_618_0
 theorem h_618_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_618_0 z).shape = [1, 8, 64] := by
   unfold v_618_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_617_0 z z_, h_616_0 z z_]
 #a h_618_0
 attribute [local irreducible] v_618_0
 attribute [local irreducible] s_619
 theorem r_619_0 (z : Store) : (s_619 z) 878 = (v_618_0 z) := w_618_0 z
 #a r_619_0
 theorem r_619_1 (z : Store) : (s_619 z) 620 = (z 620) := pR (k_618 z) (pR (k_617 z) (pR (k_616 z) (pR (n_608_616 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_93 z)))))))
 #a r_619_1
 theorem r_619_2 (z : Store) : (s_619 z) 621 = (z 621) := pR (k_618 z) (pR (k_617 z) (pR (k_616 z) (pR (n_608_616 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_94 z)))))))
 #a r_619_2
 def v_619_0 (z : Store) : Tensor := fw_layernorm (v_618_0 z) (z 620) (z 621)
 def s_620 (z : Store) : Store := storeSet (s_619 z) [(881, fw_layernorm ((s_619 z) 878) ((s_619 z) 620) ((s_619 z) 621))]
 theorem t_619 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_573) (pmPeers pmNode_573) (s_619 z) pmNode_573 none = some (s_620 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_619
 theorem k_619 (z : Store) (tid : Tid) (h : tid ∉ [881]) : (s_620 z) tid = (s_619 z) tid := by
   unfold s_620
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_619
 theorem w_619_0 (z : Store) : (s_620 z) 881 = v_619_0 z := by
   unfold s_620
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_619_0, r_619_0 z, r_619_1 z, r_619_2 z] <;> rfl
 #a w_619_0
 theorem h_619_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_619_0 z).shape = [1, 8, 64] := by
   unfold v_619_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_618_0 z z_
 #a h_619_0
 attribute [local irreducible] v_619_0
 attribute [local irreducible] s_620
 theorem n_616_620 (z : Store) (tid : Tid) (h : tid ∉ ([875, 877, 878, 881] : List Tid)) : (s_620 z) tid = (s_616 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_616 z) (k_617 z)) (pF _ _ _ _ _ (k_618 z) (k_619 z)) tid h
 #a n_616_620
 theorem r_620_0 (z : Store) : (s_620 z) 869 = (v_611_0 z) := pR (n_616_620 z) (pR (k_615 z) (pR (k_614 z) (r_614_0 z)))
 #a r_620_0
 theorem r_620_1 (z : Store) : (s_620 z) 1172 = (v_613_0 z) := pR (n_616_620 z) (pR (k_615 z) (pR (k_614 z) (r_614_1 z)))
 #a r_620_1
 def v_620_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_611_0 z), (v_613_0 z)]
 def s_621 (z : Store) : Store := storeSet (s_620 z) [(1174, reduceScatterPrimDimN 1 2 1 [((s_620 z) 869), ((s_620 z) 1172)])]
 theorem t_620 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_804) (pmPeers pmNode_804) (s_620 z) pmNode_804 none = some (s_621 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_620 z) pmNode_804 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_620
 theorem k_620 (z : Store) (tid : Tid) (h : tid ∉ [1174]) : (s_621 z) tid = (s_620 z) tid := by
   unfold s_621
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_620
 theorem w_620_0 (z : Store) : (s_621 z) 1174 = v_620_0 z := by
   unfold s_621
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_620_0, r_620_0 z, r_620_1 z] <;> rfl
 #a w_620_0
 theorem h_620_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_620_0 z).shape = [1, 8, 256] := by
   unfold v_620_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 256]
   · rw [allReducePrim_shape _ _ _ (v_611_0 z) rfl]
     exact h_611_0 z z_
   · decide
 #a h_620_0
 attribute [local irreducible] v_620_0
 attribute [local irreducible] s_621
 theorem r_621_0 (z : Store) : (s_621 z) 1174 = (v_620_0 z) := w_620_0 z
 #a r_621_0
 def v_621_0 (z : Store) : Tensor := fw_gelu (v_620_0 z)
 def s_622 (z : Store) : Store := storeSet (s_621 z) [(1175, fw_gelu ((s_621 z) 1174))]
 theorem t_621 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_805) (pmPeers pmNode_805) (s_621 z) pmNode_805 none = some (s_622 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_621
 theorem k_621 (z : Store) (tid : Tid) (h : tid ∉ [1175]) : (s_622 z) tid = (s_621 z) tid := by
   unfold s_622
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_621
 theorem w_621_0 (z : Store) : (s_622 z) 1175 = v_621_0 z := by
   unfold s_622
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_621_0, r_621_0 z] <;> rfl
 #a w_621_0
 theorem h_621_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_621_0 z).shape = [1, 8, 256] := by
   unfold v_621_0
   exact h_620_0 z z_
 #a h_621_0
 attribute [local irreducible] v_621_0
 attribute [local irreducible] s_622
 record_prefix_opacity v_613_0 s_614 v_614_0 s_615 v_615_0 s_616 v_616_0 s_617 v_617_0 s_618 v_618_0 s_619 v_619_0 s_620 v_620_0 s_621 v_621_0 s_622

 end
 end TrainVerify.Denote.RuntimeWorld
