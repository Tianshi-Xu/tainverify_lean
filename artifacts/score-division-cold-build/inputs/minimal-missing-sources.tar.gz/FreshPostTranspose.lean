import FreshProjectionTranspose
-- UNCOMPILED: parent owns imports, predecessors, frame, aggregate costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierPostTransposeRead_sm_1303 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1303 = transposeAxes 2 3 (t 1300) := by
  apply SourceLayoutRead.transposeAxes_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 44) (smInputRequests.drop 45) smNode_44
    0 1300 1303 2 3 s t rfl ?_ rfl ?_ h
  · calc
      smInputRequests = smInputRequests.take 44 ++ smInputRequests.drop 44 := (List.take_append_drop 44 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 44, 1300 ∉ row.1.outs
    decide
#print axioms frontierPostTransposeRead_sm_1303
theorem frontierPostTransposeRead_pm_222 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 222 = transposeAxes 2 3 (t 211) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 144) (pmInputRequests.drop 145) pmNode_73
    0 211 222 2 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 144 ++ pmInputRequests.drop 144 := (List.take_append_drop 144 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 144, 211 ∉ row.1.outs
    decide
#print axioms frontierPostTransposeRead_pm_222
theorem frontierPostTransposeRead_pm_525 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 525 = transposeAxes 2 3 (t 514) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 147) (pmInputRequests.drop 148) pmNode_309
    1 514 525 2 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 147 ++ pmInputRequests.drop 147 := (List.take_append_drop 147 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 147, 514 ∉ row.1.outs
    decide
#print axioms frontierPostTransposeRead_pm_525
theorem frontierPostTransposeUnitFacts_1303_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1303).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 222, q 525], y.shape = [1, 4, 8, 16]) ∧
    chunkPrimDimN 0 2 0 (t 1303) = allGatherPrimDimN 2 2 0 [q 222, q 525] := by
  have predecessor := frontierProjectionTransposeUnitFacts_1300_0_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 2 3 x) [q 211, q 514] [q 222, q 525] :=
    List.Forall₂.cons (frontierPostTransposeRead_pm_222 p q hp) (List.Forall₂.cons (frontierPostTransposeRead_pm_525 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose23_inner_unit_output_reconstruct 2 2 1 4 16 8 0
    (t 1300) (t 1303) [q 211, q 514] [q 222, q 525]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierPostTransposeRead_sm_1303 s t hs) localReads
#print axioms frontierPostTransposeUnitFacts_1303_0_slot0
theorem frontierPostTransposeRead_pm_79 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 79 = allGatherPrimDimN 2 2 0 (([219, 522] : List Tid).map t) := by
  apply SourceAllGatherRead.allGather_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 158) (pmInputRequests.drop 159) pmNode_80
    0 [0, 1] [219, 522] 79 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 158 ++ pmInputRequests.drop 158 := (List.take_append_drop 158 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([219, 522] : List Tid), ∀ row ∈ pmInputRequests.drop 158, tid ∉ row.1.outs
    decide
#print axioms frontierPostTransposeRead_pm_79
theorem frontierPostTransposeRead_pm_382 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 382 = allGatherPrimDimN 2 2 1 (([219, 522] : List Tid).map t) := by
  apply SourceAllGatherRead.allGather_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 162) (pmInputRequests.drop 163) pmNode_316
    1 [0, 1] [219, 522] 382 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 162 ++ pmInputRequests.drop 162 := (List.take_append_drop 162 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([219, 522] : List Tid), ∀ row ∈ pmInputRequests.drop 162, tid ∉ row.1.outs
    decide
#print axioms frontierPostTransposeRead_pm_382
theorem frontierPostTransposeUnitFacts_1302_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1302).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 79, q 382], y.shape = [1, 4, 16, 16]) ∧
    ∀ y ∈ [q 79, q 382], y = chunkPrimDimN 0 2 0 (t 1302) := by
  have predecessor := frontierProjectionTransposeUnitFacts_1302_0_slot0 s p t q hs hp hvalues
  have outputs : ∀ y ∈ [q 79, q 382], y = chunkPrimDimN 0 2 0 (t 1302) := by
    intro y hy
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
    rcases hy with rfl | rfl
    · exact (frontierPostTransposeRead_pm_79 p q hp).trans predecessor.2.2.symm
    · exact (frontierPostTransposeRead_pm_382 p q hp).trans predecessor.2.2.symm
  refine ⟨predecessor.1, ?_, outputs⟩
  intro y hy
  rw [outputs y hy]
  rw [chunkPrimDimN_shape 0 2 0 (t 1302) [2, 4, 16, 16] predecessor.1 (by decide)]
  rfl
#print axioms frontierPostTransposeUnitFacts_1302_0_slot0
theorem frontierPostTransposeRead_pm_828 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 828 = transposeAxes 2 3 (t 817) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 566) (pmInputRequests.drop 567) pmNode_545
    2 817 828 2 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 566 ++ pmInputRequests.drop 566 := (List.take_append_drop 566 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 566, 817 ∉ row.1.outs
    decide
#print axioms frontierPostTransposeRead_pm_828
theorem frontierPostTransposeRead_pm_1131 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1131 = transposeAxes 2 3 (t 1120) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 569) (pmInputRequests.drop 570) pmNode_781
    3 1120 1131 2 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 569 ++ pmInputRequests.drop 569 := (List.take_append_drop 569 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 569, 1120 ∉ row.1.outs
    decide
#print axioms frontierPostTransposeRead_pm_1131
theorem frontierPostTransposeUnitFacts_1303_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1303).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 828, q 1131], y.shape = [1, 4, 8, 16]) ∧
    chunkPrimDimN 0 2 1 (t 1303) = allGatherPrimDimN 2 2 0 [q 828, q 1131] := by
  have predecessor := frontierProjectionTransposeUnitFacts_1300_1_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 2 3 x) [q 817, q 1120] [q 828, q 1131] :=
    List.Forall₂.cons (frontierPostTransposeRead_pm_828 p q hp) (List.Forall₂.cons (frontierPostTransposeRead_pm_1131 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose23_inner_unit_output_reconstruct 2 2 1 4 16 8 1
    (t 1300) (t 1303) [q 817, q 1120] [q 828, q 1131]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierPostTransposeRead_sm_1303 s t hs) localReads
#print axioms frontierPostTransposeUnitFacts_1303_1_slot0
theorem frontierPostTransposeRead_pm_685 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 685 = allGatherPrimDimN 2 2 0 (([825, 1128] : List Tid).map t) := by
  apply SourceAllGatherRead.allGather_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 580) (pmInputRequests.drop 581) pmNode_552
    2 [2, 3] [825, 1128] 685 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 580 ++ pmInputRequests.drop 580 := (List.take_append_drop 580 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([825, 1128] : List Tid), ∀ row ∈ pmInputRequests.drop 580, tid ∉ row.1.outs
    decide
#print axioms frontierPostTransposeRead_pm_685
theorem frontierPostTransposeRead_pm_988 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 988 = allGatherPrimDimN 2 2 1 (([825, 1128] : List Tid).map t) := by
  apply SourceAllGatherRead.allGather_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 584) (pmInputRequests.drop 585) pmNode_788
    3 [2, 3] [825, 1128] 988 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 584 ++ pmInputRequests.drop 584 := (List.take_append_drop 584 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([825, 1128] : List Tid), ∀ row ∈ pmInputRequests.drop 584, tid ∉ row.1.outs
    decide
#print axioms frontierPostTransposeRead_pm_988
theorem frontierPostTransposeUnitFacts_1302_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1302).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 685, q 988], y.shape = [1, 4, 16, 16]) ∧
    ∀ y ∈ [q 685, q 988], y = chunkPrimDimN 0 2 1 (t 1302) := by
  have predecessor := frontierProjectionTransposeUnitFacts_1302_1_slot0 s p t q hs hp hvalues
  have outputs : ∀ y ∈ [q 685, q 988], y = chunkPrimDimN 0 2 1 (t 1302) := by
    intro y hy
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
    rcases hy with rfl | rfl
    · exact (frontierPostTransposeRead_pm_685 p q hp).trans predecessor.2.2.symm
    · exact (frontierPostTransposeRead_pm_988 p q hp).trans predecessor.2.2.symm
  refine ⟨predecessor.1, ?_, outputs⟩
  intro y hy
  rw [outputs y hy]
  rw [chunkPrimDimN_shape 0 2 1 (t 1302) [2, 4, 16, 16] predecessor.1 (by decide)]
  rfl
#print axioms frontierPostTransposeUnitFacts_1302_1_slot0
end
end TrainVerify.Denote.RuntimeWorld
