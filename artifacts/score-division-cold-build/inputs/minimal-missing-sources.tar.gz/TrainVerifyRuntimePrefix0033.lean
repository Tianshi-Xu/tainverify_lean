import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0032
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_253_0 (z : Store) : (s_253 z) 246 = (v_252_0 z) := w_252_0 z
 #a r_253_0
 theorem r_253_1 (z : Store) : (s_253 z) 243 = (v_168_0 z) := pR (k_252 z) (pR (n_248_252 z) (pR (n_240_248 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_176_192 z) (pR (n_172_176 z) (pR (k_171 z) (pR (k_170 z) (pR (k_169 z) (r_169_0 z))))))))))
 #a r_253_1
 def v_253_0 (z : Store) : Tensor := (v_252_0 z)
 def s_254 (z : Store) : Store := storeSet (s_253 z) [(245, ((s_253 z) 246))]
 theorem t_253 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_127) (pmPeers pmNode_127) (s_253 z) pmNode_127 none = some (s_254 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_253
 theorem k_253 (z : Store) (tid : Tid) (h : tid ∉ [245]) : (s_254 z) tid = (s_253 z) tid := by
   unfold s_254
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_253
 theorem w_253_0 (z : Store) : (s_254 z) 245 = v_253_0 z := by
   unfold s_254
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_253_0, r_253_0 z, r_253_1 z] <;> rfl
 #a w_253_0
 theorem h_253_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_253_0 z).shape = [1, 8, 4, 16] := by
   unfold v_253_0
   exact h_252_0 z z_
 #a h_253_0
 attribute [local irreducible] v_253_0
 attribute [local irreducible] s_254
 theorem r_254_0 (z : Store) : (s_254 z) 249 = (v_248_0 z) := pR (k_253 z) (pR (k_252 z) (r_252_0 z))
 #a r_254_0
 theorem r_254_1 (z : Store) : (s_254 z) 552 = (v_251_0 z) := pR (k_253 z) (pR (k_252 z) (r_252_1 z))
 #a r_254_1
 def v_254_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_248_0 z), (v_251_0 z)]
 theorem g_254 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_362) (s_254 z) pmNode_362 2 1 549 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_362, r_254_0 z, r_254_1 z, h_248_0 z z_, h_251_0 z z_]
 #a g_254
 def s_255 (z : Store) : Store := pL [0, 1] (s_254 z) pmNode_362 2 1
 theorem t_254 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_362) (pmPeers pmNode_362) (s_254 z) pmNode_362 none = some (s_255 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_362) (s_254 z) pmNode_362).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 549 (by decide) (g_254 z z_)]
   rfl
 #a t_254
 theorem k_254 (z : Store) (tid : Tid) (h : tid ∉ [549]) : (s_255 z) tid = (s_254 z) tid := by
   unfold s_255
   dsimp only [pL, pmNode_362, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_254
 theorem w_254_0 (z : Store) : (s_255 z) 549 = v_254_0 z := by
   unfold s_255
   dsimp only [pL, pmNode_362, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_254_0, r_254_0 z, r_254_1 z] <;> rfl
 #a w_254_0
 theorem h_254_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_254_0 z).shape = [1, 8, 4, 16] := by
   unfold v_254_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_248_0 z z_]
 #a h_254_0
 attribute [local irreducible] v_254_0
 attribute [local irreducible] s_255
 theorem r_255_0 (z : Store) : (s_255 z) 549 = (v_254_0 z) := w_254_0 z
 #a r_255_0
 theorem r_255_1 (z : Store) : (s_255 z) 546 = (v_170_0 z) := pR (k_254 z) (pR (k_253 z) (pR (k_252 z) (pR (n_248_252 z) (pR (n_240_248 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_176_192 z) (pR (n_172_176 z) (pR (k_171 z) (r_171_0 z))))))))))
 #a r_255_1
 def v_255_0 (z : Store) : Tensor := (v_254_0 z)
 def s_256 (z : Store) : Store := storeSet (s_255 z) [(548, ((s_255 z) 549))]
 theorem t_255 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_363) (pmPeers pmNode_363) (s_255 z) pmNode_363 none = some (s_256 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_255
 theorem k_255 (z : Store) (tid : Tid) (h : tid ∉ [548]) : (s_256 z) tid = (s_255 z) tid := by
   unfold s_256
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_255
 theorem w_255_0 (z : Store) : (s_256 z) 548 = v_255_0 z := by
   unfold s_256
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_255_0, r_255_0 z, r_255_1 z] <;> rfl
 #a w_255_0
 theorem h_255_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_255_0 z).shape = [1, 8, 4, 16] := by
   unfold v_255_0
   exact h_254_0 z z_
 #a h_255_0
 attribute [local irreducible] v_255_0
 attribute [local irreducible] s_256
 theorem r_256_0 (z : Store) : (s_256 z) 245 = (v_253_0 z) := pR (k_255 z) (pR (k_254 z) (w_253_0 z))
 #a r_256_0
 theorem r_256_1 (z : Store) : (s_256 z) 548 = (v_255_0 z) := w_255_0 z
 #a r_256_1
 def v_256_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_253_0 z), (v_255_0 z)]
 theorem g_256 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_128) (s_256 z) pmNode_128 1 2 242 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_128, r_256_0 z, r_256_1 z, h_253_0 z z_, h_255_0 z z_]
 #a g_256
 def s_257 (z : Store) : Store := pL [0, 1] (s_256 z) pmNode_128 1 2
 theorem t_256 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_128) (pmPeers pmNode_128) (s_256 z) pmNode_128 none = some (s_257 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_128) (s_256 z) pmNode_128).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 242 (by decide) (g_256 z z_)]
   rfl
 #a t_256
 theorem k_256 (z : Store) (tid : Tid) (h : tid ∉ [242]) : (s_257 z) tid = (s_256 z) tid := by
   unfold s_257
   dsimp only [pL, pmNode_128, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_256
 theorem w_256_0 (z : Store) : (s_257 z) 242 = v_256_0 z := by
   unfold s_257
   dsimp only [pL, pmNode_128, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_256_0, r_256_0 z, r_256_1 z] <;> rfl
 #a w_256_0
 theorem h_256_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_256_0 z).shape = [1, 16, 2, 16] := by
   unfold v_256_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_253_0 z z_]
 #a h_256_0
 attribute [local irreducible] v_256_0
 attribute [local irreducible] s_257
 theorem n_252_256 (z : Store) (tid : Tid) (h : tid ∉ ([246, 245, 549, 548] : List Tid)) : (s_256 z) tid = (s_252 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_252 z) (k_253 z)) (pF _ _ _ _ _ (k_254 z) (k_255 z)) tid h
 #a n_252_256
 theorem n_248_256 (z : Store) (tid : Tid) (h : tid ∉ ([249, 387, 553, 360, 552, 246, 245, 549, 548] : List Tid)) : (s_256 z) tid = (s_248 z) tid := by
   exact pF _ _ _ _ _ (n_248_252 z) (n_252_256 z) tid h
 #a n_248_256
 theorem n_240_256 (z : Store) (tid : Tid) (h : tid ∉ ([300, 257, 255, 256, 603, 560, 558, 559, 84, 250, 57, 249, 387, 553, 360, 552, 246, 245, 549, 548] : List Tid)) : (s_256 z) tid = (s_240 z) tid := by
   exact pF _ _ _ _ _ (n_240_248 z) (n_248_256 z) tid h
 #a n_240_256
 theorem n_224_256 (z : Store) (tid : Tid) (h : tid ∉ ([577, 371, 373, 576, 573, 302, 268, 66, 267, 605, 571, 369, 570, 85, 264, 64, 388, 567, 367, 261, 260, 59, 61, 564, 563, 362, 364, 300, 257, 255, 256, 603, 560, 558, 559, 84, 250, 57, 249, 387, 553, 360, 552, 246, 245, 549, 548] : List Tid)) : (s_256 z) tid = (s_224 z) tid := by
   exact pF _ _ _ _ _ (n_224_240 z) (n_240_256 z) tid h
 #a n_224_256
 theorem n_192_256 (z : Store) (tid : Tid) (h : tid ∉ ([265, 266, 269, 271, 272, 275, 568, 569, 572, 574, 575, 578, 80, 277, 383, 580, 280, 281, 583, 584, 77, 282, 380, 585, 278, 279, 73, 582, 581, 376, 276, 274, 68, 70, 273, 270, 579, 577, 371, 373, 576, 573, 302, 268, 66, 267, 605, 571, 369, 570, 85, 264, 64, 388, 567, 367, 261, 260, 59, 61, 564, 563, 362, 364, 300, 257, 255, 256, 603, 560, 558, 559, 84, 250, 57, 249, 387, 553, 360, 552, 246, 245, 549, 548] : List Tid)) : (s_256 z) tid = (s_192 z) tid := by
   exact pF _ _ _ _ _ (n_192_224 z) (n_224_256 z) tid h
 #a n_192_256
 theorem r_257_0 (z : Store) : (s_257 z) 242 = (v_256_0 z) := w_256_0 z
 #a r_257_0
 theorem r_257_1 (z : Store) : (s_257 z) 239 = (v_164_0 z) := pR (k_256 z) (pR (n_192_256 z) (pR (n_176_192 z) (pR (n_168_176 z) (pR (k_167 z) (pR (k_166 z) (pR (k_165 z) (r_165_0 z)))))))
 #a r_257_1
 def v_257_0 (z : Store) : Tensor := transposeAxes 1 2 (v_256_0 z)
 def s_258 (z : Store) : Store := storeSet (s_257 z) [(241, transposeAxes 1 2 ((s_257 z) 242))]
 theorem t_257 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_129) (pmPeers pmNode_129) (s_257 z) pmNode_129 none = some (s_258 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_257
 theorem k_257 (z : Store) (tid : Tid) (h : tid ∉ [241]) : (s_258 z) tid = (s_257 z) tid := by
   unfold s_258
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_257
 theorem w_257_0 (z : Store) : (s_258 z) 241 = v_257_0 z := by
   unfold s_258
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_257_0, r_257_0 z, r_257_1 z] <;> rfl
 #a w_257_0
 theorem h_257_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_257_0 z).shape = [1, 2, 16, 16] := by
   unfold v_257_0
   change listSwapAt _ _ _ = _
   rw [h_256_0 z z_]
   rfl
 #a h_257_0
 attribute [local irreducible] v_257_0
 attribute [local irreducible] s_258
 theorem r_258_0 (z : Store) : (s_258 z) 245 = (v_253_0 z) := pR (k_257 z) (pR (k_256 z) (r_256_0 z))
 #a r_258_0
 theorem r_258_1 (z : Store) : (s_258 z) 548 = (v_255_0 z) := pR (k_257 z) (pR (k_256 z) (r_256_1 z))
 #a r_258_1
 def v_258_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_253_0 z), (v_255_0 z)]
 theorem g_258 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_364) (s_258 z) pmNode_364 1 2 545 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_364, r_258_0 z, r_258_1 z, h_253_0 z z_, h_255_0 z z_]
 #a g_258
 def s_259 (z : Store) : Store := pL [0, 1] (s_258 z) pmNode_364 1 2
 theorem t_258 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_364) (pmPeers pmNode_364) (s_258 z) pmNode_364 none = some (s_259 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_364) (s_258 z) pmNode_364).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 545 (by decide) (g_258 z z_)]
   rfl
 #a t_258
 theorem k_258 (z : Store) (tid : Tid) (h : tid ∉ [545]) : (s_259 z) tid = (s_258 z) tid := by
   unfold s_259
   dsimp only [pL, pmNode_364, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_258
 theorem w_258_0 (z : Store) : (s_259 z) 545 = v_258_0 z := by
   unfold s_259
   dsimp only [pL, pmNode_364, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_258_0, r_258_0 z, r_258_1 z] <;> rfl
 #a w_258_0
 theorem h_258_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_258_0 z).shape = [1, 16, 2, 16] := by
   unfold v_258_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_253_0 z z_]
 #a h_258_0
 attribute [local irreducible] v_258_0
 attribute [local irreducible] s_259
 theorem r_259_0 (z : Store) : (s_259 z) 545 = (v_258_0 z) := w_258_0 z
 #a r_259_0
 theorem r_259_1 (z : Store) : (s_259 z) 542 = (v_166_0 z) := pR (k_258 z) (pR (k_257 z) (pR (k_256 z) (pR (n_192_256 z) (pR (n_176_192 z) (pR (n_168_176 z) (pR (k_167 z) (r_167_0 z)))))))
 #a r_259_1
 def v_259_0 (z : Store) : Tensor := transposeAxes 1 2 (v_258_0 z)
 def s_260 (z : Store) : Store := storeSet (s_259 z) [(544, transposeAxes 1 2 ((s_259 z) 545))]
 theorem t_259 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_365) (pmPeers pmNode_365) (s_259 z) pmNode_365 none = some (s_260 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_259
 theorem k_259 (z : Store) (tid : Tid) (h : tid ∉ [544]) : (s_260 z) tid = (s_259 z) tid := by
   unfold s_260
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_259
 theorem w_259_0 (z : Store) : (s_260 z) 544 = v_259_0 z := by
   unfold s_260
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_259_0, r_259_0 z, r_259_1 z] <;> rfl
 #a w_259_0
 theorem h_259_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_259_0 z).shape = [1, 2, 16, 16] := by
   unfold v_259_0
   change listSwapAt _ _ _ = _
   rw [h_258_0 z z_]
   rfl
 #a h_259_0
 attribute [local irreducible] v_259_0
 attribute [local irreducible] s_260
 theorem r_260_0 (z : Store) : (s_260 z) 241 = (v_257_0 z) := pR (k_259 z) (pR (k_258 z) (w_257_0 z))
 #a r_260_0
 theorem r_260_1 (z : Store) : (s_260 z) 544 = (v_259_0 z) := w_259_0 z
 #a r_260_1
 def v_260_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_257_0 z), (v_259_0 z)]
 theorem g_260 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_130) (s_260 z) pmNode_130 1 2 237 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_130, r_260_0 z, r_260_1 z, h_257_0 z z_, h_259_0 z z_]
 #a g_260
 def s_261 (z : Store) : Store := pL [0, 1] (s_260 z) pmNode_130 1 2
 theorem t_260 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_130) (pmPeers pmNode_130) (s_260 z) pmNode_130 none = some (s_261 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_130) (s_260 z) pmNode_130).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 237 (by decide) (g_260 z z_)]
   rfl
 #a t_260
 theorem k_260 (z : Store) (tid : Tid) (h : tid ∉ [237]) : (s_261 z) tid = (s_260 z) tid := by
   unfold s_261
   dsimp only [pL, pmNode_130, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_260
 theorem w_260_0 (z : Store) : (s_261 z) 237 = v_260_0 z := by
   unfold s_261
   dsimp only [pL, pmNode_130, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_260_0, r_260_0 z, r_260_1 z] <;> rfl
 #a w_260_0
 theorem h_260_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_260_0 z).shape = [1, 4, 8, 16] := by
   unfold v_260_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_257_0 z z_]
 #a h_260_0
 attribute [local irreducible] v_260_0
 attribute [local irreducible] s_261
 theorem n_256_260 (z : Store) (tid : Tid) (h : tid ∉ ([242, 241, 545, 544] : List Tid)) : (s_260 z) tid = (s_256 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_256 z) (k_257 z)) (pF _ _ _ _ _ (k_258 z) (k_259 z)) tid h
 #a n_256_260
 record_prefix_opacity v_253_0 s_254 v_254_0 s_255 v_255_0 s_256 v_256_0 s_257 v_257_0 s_258 v_258_0 s_259 v_259_0 s_260 v_260_0 s_261

 end
 end TrainVerify.Denote.RuntimeWorld
