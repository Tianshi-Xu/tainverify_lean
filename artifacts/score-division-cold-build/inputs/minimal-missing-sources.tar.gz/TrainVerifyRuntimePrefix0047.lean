import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0046
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_361_0 (z : Store) : (s_361 z) 148 = (v_353_0 z) := pR (k_360 z) (pR (k_359 z) (pR (k_358 z) (r_358_0 z)))
 #a r_361_0
 theorem r_361_1 (z : Store) : (s_361 z) 452 = (v_357_0 z) := pR (k_360 z) (pR (k_359 z) (pR (k_358 z) (r_358_1 z)))
 #a r_361_1
 def v_361_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_353_0 z), (v_357_0 z)]
 theorem g_361 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_415) (s_361 z) pmNode_415 2 1 448 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_415, r_361_0 z, r_361_1 z, h_353_0 z z_, h_357_0 z z_]
 #a g_361
 def s_362 (z : Store) : Store := pL [0, 1] (s_361 z) pmNode_415 2 1
 theorem t_361 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_415) (pmPeers pmNode_415) (s_361 z) pmNode_415 none = some (s_362 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_415) (s_361 z) pmNode_415).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 448 (by decide) (g_361 z z_)]
   rfl
 #a t_361
 theorem k_361 (z : Store) (tid : Tid) (h : tid ∉ [448]) : (s_362 z) tid = (s_361 z) tid := by
   unfold s_362
   dsimp only [pL, pmNode_415, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_361
 theorem w_361_0 (z : Store) : (s_362 z) 448 = v_361_0 z := by
   unfold s_362
   dsimp only [pL, pmNode_415, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_361_0, r_361_0 z, r_361_1 z] <;> rfl
 #a w_361_0
 theorem h_361_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_361_0 z).shape = [1, 2, 16, 16] := by
   unfold v_361_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_353_0 z z_]
 #a h_361_0
 attribute [local irreducible] v_361_0
 attribute [local irreducible] s_362
 theorem r_362_0 (z : Store) : (s_362 z) 150 = (v_353_1 z) := pR (k_361 z) (pR (k_360 z) (pR (k_359 z) (r_359_0 z)))
 #a r_362_0
 theorem r_362_1 (z : Store) : (s_362 z) 451 = (v_357_1 z) := pR (k_361 z) (pR (k_360 z) (pR (k_359 z) (r_359_1 z)))
 #a r_362_1
 def v_362_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 1 [(v_353_1 z), (v_357_1 z)]
 def s_363 (z : Store) : Store := storeSet (s_362 z) [(432, reduceScatterPrimDimN 2 2 1 [((s_362 z) 150), ((s_362 z) 451)])]
 theorem t_362 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_416) (pmPeers pmNode_416) (s_362 z) pmNode_416 none = some (s_363 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_362 z) pmNode_416 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_362
 theorem k_362 (z : Store) (tid : Tid) (h : tid ∉ [432]) : (s_363 z) tid = (s_362 z) tid := by
   unfold s_363
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_362
 theorem w_362_0 (z : Store) : (s_363 z) 432 = v_362_0 z := by
   unfold s_363
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_362_0, r_362_0 z, r_362_1 z] <;> rfl
 #a w_362_0
 theorem h_362_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_362_0 z).shape = [1, 4, 8, 16] := by
   unfold v_362_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 1 _ [1, 4, 16, 16]
   · rw [allReducePrim_shape _ _ _ (v_353_1 z) rfl]
     exact h_353_1 z z_
   · decide
 #a h_362_0
 attribute [local irreducible] v_362_0
 attribute [local irreducible] s_363
 theorem r_363_0 (z : Store) : (s_363 z) 448 = (v_361_0 z) := pR (k_362 z) (w_361_0 z)
 #a r_363_0
 theorem r_363_1 (z : Store) : (s_363 z) 445 = (v_63_0 z) := pR (k_362 z) (pR (k_361 z) (pR (k_360 z) (pR (n_352_360 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (r_64_0 z))))))))
 #a r_363_1
 def v_363_0 (z : Store) : Tensor := bw_softmax (v_361_0 z) (v_63_0 z)
 def s_364 (z : Store) : Store := storeSet (s_363 z) [(447, bw_softmax ((s_363 z) 448) ((s_363 z) 445))]
 theorem t_363 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_417) (pmPeers pmNode_417) (s_363 z) pmNode_417 none = some (s_364 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_363
 theorem k_363 (z : Store) (tid : Tid) (h : tid ∉ [447]) : (s_364 z) tid = (s_363 z) tid := by
   unfold s_364
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_363
 theorem w_363_0 (z : Store) : (s_364 z) 447 = v_363_0 z := by
   unfold s_364
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_363_0, r_363_0 z, r_363_1 z] <;> rfl
 #a w_363_0
 theorem h_363_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_363_0 z).shape = [1, 2, 16, 16] := by
   unfold v_363_0
   unfold bw_softmax softmaxBwd softmaxBwdFromOutput softmax
   rw [h_63_0 z z_]
   rfl
 #a h_363_0
 attribute [local irreducible] v_363_0
 attribute [local irreducible] s_364
 theorem r_364_0 (z : Store) : (s_364 z) 144 = (v_360_0 z) := pR (k_363 z) (pR (k_362 z) (pR (k_361 z) (w_360_0 z)))
 #a r_364_0
 theorem r_364_1 (z : Store) : (s_364 z) 447 = (v_363_0 z) := w_363_0 z
 #a r_364_1
 def v_364_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_360_0 z), (v_363_0 z)]
 theorem g_364 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_182) (s_364 z) pmNode_182 1 3 141 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_182, r_364_0 z, r_364_1 z, h_360_0 z z_, h_363_0 z z_]
 #a g_364
 def s_365 (z : Store) : Store := pL [0, 1] (s_364 z) pmNode_182 1 3
 theorem t_364 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_182) (pmPeers pmNode_182) (s_364 z) pmNode_182 none = some (s_365 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_182) (s_364 z) pmNode_182).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 141 (by decide) (g_364 z z_)]
   rfl
 #a t_364
 theorem k_364 (z : Store) (tid : Tid) (h : tid ∉ [141]) : (s_365 z) tid = (s_364 z) tid := by
   unfold s_365
   dsimp only [pL, pmNode_182, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_364
 theorem w_364_0 (z : Store) : (s_365 z) 141 = v_364_0 z := by
   unfold s_365
   dsimp only [pL, pmNode_182, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_364_0, r_364_0 z, r_364_1 z] <;> rfl
 #a w_364_0
 theorem h_364_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_364_0 z).shape = [1, 4, 16, 8] := by
   unfold v_364_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_360_0 z z_]
 #a h_364_0
 attribute [local irreducible] v_364_0
 attribute [local irreducible] s_365
 theorem n_360_364 (z : Store) (tid : Tid) (h : tid ∉ ([144, 448, 432, 447] : List Tid)) : (s_364 z) tid = (s_360 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_360 z) (k_361 z)) (pF _ _ _ _ _ (k_362 z) (k_363 z)) tid h
 #a n_360_364
 theorem r_365_0 (z : Store) : (s_365 z) 141 = (v_364_0 z) := w_364_0 z
 #a r_365_0
 theorem r_365_1 (z : Store) : (s_365 z) 138 = (v_56_0 z) := pR (k_364 z) (pR (n_360_364 z) (pR (n_352_360 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_60_64 z) (pR (k_59 z) (pR (k_58 z) (pR (k_57 z) (r_57_0 z)))))))))))
 #a r_365_1
 def v_365_0 (z : Store) : Tensor := bw_div ((4 : Nat) : Scalar) (v_364_0 z)
 def s_366 (z : Store) : Store := storeSet (s_365 z) [(140, bw_div ((4 : Nat) : Scalar) ((s_365 z) 141))]
 theorem t_365 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_183) (pmPeers pmNode_183) (s_365 z) pmNode_183 none = some (s_366 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_365
 theorem k_365 (z : Store) (tid : Tid) (h : tid ∉ [140]) : (s_366 z) tid = (s_365 z) tid := by
   unfold s_366
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_365
 theorem w_365_0 (z : Store) : (s_366 z) 140 = v_365_0 z := by
   unfold s_366
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_365_0, r_365_0 z, r_365_1 z] <;> rfl
 #a w_365_0
 theorem h_365_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_365_0 z).shape = [1, 4, 16, 8] := by
   unfold v_365_0
   exact h_364_0 z z_
 #a h_365_0
 attribute [local irreducible] v_365_0
 attribute [local irreducible] s_366
 theorem r_366_0 (z : Store) : (s_366 z) 144 = (v_360_0 z) := pR (k_365 z) (pR (k_364 z) (r_364_0 z))
 #a r_366_0
 theorem r_366_1 (z : Store) : (s_366 z) 447 = (v_363_0 z) := pR (k_365 z) (pR (k_364 z) (r_364_1 z))
 #a r_366_1
 def v_366_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_360_0 z), (v_363_0 z)]
 theorem g_366 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_418) (s_366 z) pmNode_418 1 3 444 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_418, r_366_0 z, r_366_1 z, h_360_0 z z_, h_363_0 z z_]
 #a g_366
 def s_367 (z : Store) : Store := pL [0, 1] (s_366 z) pmNode_418 1 3
 theorem t_366 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_418) (pmPeers pmNode_418) (s_366 z) pmNode_418 none = some (s_367 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_418) (s_366 z) pmNode_418).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 444 (by decide) (g_366 z z_)]
   rfl
 #a t_366
 theorem k_366 (z : Store) (tid : Tid) (h : tid ∉ [444]) : (s_367 z) tid = (s_366 z) tid := by
   unfold s_367
   dsimp only [pL, pmNode_418, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_366
 theorem w_366_0 (z : Store) : (s_367 z) 444 = v_366_0 z := by
   unfold s_367
   dsimp only [pL, pmNode_418, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_366_0, r_366_0 z, r_366_1 z] <;> rfl
 #a w_366_0
 theorem h_366_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_366_0 z).shape = [1, 4, 16, 8] := by
   unfold v_366_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_360_0 z z_]
 #a h_366_0
 attribute [local irreducible] v_366_0
 attribute [local irreducible] s_367
 theorem r_367_0 (z : Store) : (s_367 z) 444 = (v_366_0 z) := w_366_0 z
 #a r_367_0
 theorem r_367_1 (z : Store) : (s_367 z) 441 = (v_58_0 z) := pR (k_366 z) (pR (k_365 z) (pR (k_364 z) (pR (n_360_364 z) (pR (n_352_360 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_60_64 z) (pR (k_59 z) (r_59_0 z)))))))))))
 #a r_367_1
 def v_367_0 (z : Store) : Tensor := bw_div ((4 : Nat) : Scalar) (v_366_0 z)
 def s_368 (z : Store) : Store := storeSet (s_367 z) [(443, bw_div ((4 : Nat) : Scalar) ((s_367 z) 444))]
 theorem t_367 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_419) (pmPeers pmNode_419) (s_367 z) pmNode_419 none = some (s_368 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_367
 theorem k_367 (z : Store) (tid : Tid) (h : tid ∉ [443]) : (s_368 z) tid = (s_367 z) tid := by
   unfold s_368
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_367
 theorem w_367_0 (z : Store) : (s_368 z) 443 = v_367_0 z := by
   unfold s_368
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_367_0, r_367_0 z, r_367_1 z] <;> rfl
 #a w_367_0
 theorem h_367_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_367_0 z).shape = [1, 4, 16, 8] := by
   unfold v_367_0
   exact h_366_0 z z_
 #a h_367_0
 attribute [local irreducible] v_367_0
 attribute [local irreducible] s_368
 theorem r_368_0 (z : Store) : (s_368 z) 140 = (v_365_0 z) := pR (k_367 z) (pR (k_366 z) (w_365_0 z))
 #a r_368_0
 theorem r_368_1 (z : Store) : (s_368 z) 443 = (v_367_0 z) := w_367_0 z
 #a r_368_1
 def v_368_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_365_0 z), (v_367_0 z)]
 theorem g_368 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_184) (s_368 z) pmNode_184 3 1 137 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_184, r_368_0 z, r_368_1 z, h_365_0 z z_, h_367_0 z z_]
 #a g_368
 def s_369 (z : Store) : Store := pL [0, 1] (s_368 z) pmNode_184 3 1
 theorem t_368 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_184) (pmPeers pmNode_184) (s_368 z) pmNode_184 none = some (s_369 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_184) (s_368 z) pmNode_184).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 137 (by decide) (g_368 z z_)]
   rfl
 #a t_368
 theorem k_368 (z : Store) (tid : Tid) (h : tid ∉ [137]) : (s_369 z) tid = (s_368 z) tid := by
   unfold s_369
   dsimp only [pL, pmNode_184, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_368
 theorem w_368_0 (z : Store) : (s_369 z) 137 = v_368_0 z := by
   unfold s_369
   dsimp only [pL, pmNode_184, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_368_0, r_368_0 z, r_368_1 z] <;> rfl
 #a w_368_0
 theorem h_368_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_368_0 z).shape = [1, 2, 16, 16] := by
   unfold v_368_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_365_0 z z_]
 #a h_368_0
 attribute [local irreducible] v_368_0
 attribute [local irreducible] s_369
 theorem n_364_368 (z : Store) (tid : Tid) (h : tid ∉ ([141, 140, 444, 443] : List Tid)) : (s_368 z) tid = (s_364 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_364 z) (k_365 z)) (pF _ _ _ _ _ (k_366 z) (k_367 z)) tid h
 #a n_364_368
 theorem n_360_368 (z : Store) (tid : Tid) (h : tid ∉ ([144, 448, 432, 447, 141, 140, 444, 443] : List Tid)) : (s_368 z) tid = (s_360 z) tid := by
   exact pF _ _ _ _ _ (n_360_364 z) (n_364_368 z) tid h
 #a n_360_368
 theorem n_352_368 (z : Store) (tid : Tid) (h : tid ∉ ([149, 148, 150, 457, 455, 453, 452, 451, 145, 129, 144, 448, 432, 447, 141, 140, 444, 443] : List Tid)) : (s_368 z) tid = (s_352 z) tid := by
   exact pF _ _ _ _ _ (n_352_360 z) (n_360_368 z) tid h
 #a n_352_368
 record_prefix_opacity v_361_0 s_362 v_362_0 s_363 v_363_0 s_364 v_364_0 s_365 v_365_0 s_366 v_366_0 s_367 v_367_0 s_368 v_368_0 s_369

 end
 end TrainVerify.Denote.RuntimeWorld
