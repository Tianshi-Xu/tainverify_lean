import FreshGatheredLinear
-- UNCOMPILED: parent owns imports, predecessors, frame, aggregate costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierGatheredExchangeRead_pm_198 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 198 = AllToAllSourceFaithful.tensor 2 0 2 1 (([189, 492] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 118) (pmInputRequests.drop 119) pmNode_61 0 [0, 1] [189, 492] 198 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 118 ++ pmInputRequests.drop 118 := (List.take_append_drop 118 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([189, 492] : List Tid), ∀ row ∈ pmInputRequests.drop 118, tid ∉ row.1.outs
    decide
#print axioms frontierGatheredExchangeRead_pm_198
theorem frontierGatheredExchangeRead_pm_501 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 501 = AllToAllSourceFaithful.tensor 2 1 2 1 (([189, 492] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 124) (pmInputRequests.drop 125) pmNode_297 1 [0, 1] [189, 492] 501 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 124 ++ pmInputRequests.drop 124 := (List.take_append_drop 124 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([189, 492] : List Tid), ∀ row ∈ pmInputRequests.drop 124, tid ∉ row.1.outs
    decide
#print axioms frontierGatheredExchangeRead_pm_501
theorem frontierGatheredExchangeUnitFacts_1294_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1294).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 198, q 501], x.shape = [1, 8, 64]) ∧
    chunkPrimDimN 0 2 0 (t 1294) = allGatherPrimDimN 1 2 0 [q 198, q 501] := by
  have predecessor := frontierGatheredLinearUnitFacts_1294_0 s p t q hs hp hvalues
  have outputs : [q 198, q 501] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 2 1 [q 189, q 492]) := by
    change [q 198, q 501] = [AllToAllSourceFaithful.tensor 2 0 2 1 [q 189, q 492], AllToAllSourceFaithful.tensor 2 1 2 1 [q 189, q 492]]
    exact congrArg₂ List.cons (frontierGatheredExchangeRead_pm_198 p q hp) (congrArg₂ List.cons (frontierGatheredExchangeRead_pm_501 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 0 2 1 8 32 (t 1294) [q 189, q 492] [q 198, q 501]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierGatheredExchangeUnitFacts_1294_0_slot0
theorem frontierGatheredExchangeRead_pm_804 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 804 = AllToAllSourceFaithful.tensor 2 0 2 1 (([795, 1098] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 540) (pmInputRequests.drop 541) pmNode_533 2 [2, 3] [795, 1098] 804 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 540 ++ pmInputRequests.drop 540 := (List.take_append_drop 540 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([795, 1098] : List Tid), ∀ row ∈ pmInputRequests.drop 540, tid ∉ row.1.outs
    decide
#print axioms frontierGatheredExchangeRead_pm_804
theorem frontierGatheredExchangeRead_pm_1107 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1107 = AllToAllSourceFaithful.tensor 2 1 2 1 (([795, 1098] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 546) (pmInputRequests.drop 547) pmNode_769 3 [2, 3] [795, 1098] 1107 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 546 ++ pmInputRequests.drop 546 := (List.take_append_drop 546 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([795, 1098] : List Tid), ∀ row ∈ pmInputRequests.drop 546, tid ∉ row.1.outs
    decide
#print axioms frontierGatheredExchangeRead_pm_1107
theorem frontierGatheredExchangeUnitFacts_1294_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1294).shape = [2, 16, 64] ∧
    (∀ x ∈ [q 804, q 1107], x.shape = [1, 8, 64]) ∧
    chunkPrimDimN 0 2 1 (t 1294) = allGatherPrimDimN 1 2 0 [q 804, q 1107] := by
  have predecessor := frontierGatheredLinearUnitFacts_1294_1 s p t q hs hp hvalues
  have outputs : [q 804, q 1107] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 2 1 [q 795, q 1098]) := by
    change [q 804, q 1107] = [AllToAllSourceFaithful.tensor 2 0 2 1 [q 795, q 1098], AllToAllSourceFaithful.tensor 2 1 2 1 [q 795, q 1098]]
    exact congrArg₂ List.cons (frontierGatheredExchangeRead_pm_804 p q hp) (congrArg₂ List.cons (frontierGatheredExchangeRead_pm_1107 p q hp) (rfl))
  exact SourceHiddenSequenceExchange.output_facts 2 1 2 1 8 32 (t 1294) [q 795, q 1098] [q 804, q 1107]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierGatheredExchangeUnitFacts_1294_1_slot0
end
end TrainVerify.Denote.RuntimeWorld
