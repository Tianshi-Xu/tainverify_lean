import FreshGatheredExchange
-- UNCOMPILED: parent owns imports, predecessors, frame, aggregate costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierProjectionViewRead_sm_1297 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1297 = fw_view [2, 16, 4, 16] (t 1294) := by
  apply SourceLayoutRead.view_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 38) (smInputRequests.drop 39) smNode_38
    0 1294 1297 2 [16, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      smInputRequests = smInputRequests.take 38 ++ smInputRequests.drop 38 := (List.take_append_drop 38 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 38, 1294 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_sm_1297
theorem frontierProjectionViewRead_pm_199 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 199 = fw_view [1, 8, 4, 16] (t 198) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 119) (pmInputRequests.drop 120) pmNode_62
    0 198 199 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 119 ++ pmInputRequests.drop 119 := (List.take_append_drop 119 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 119, 198 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_199
theorem frontierProjectionViewRead_pm_502 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 502 = fw_view [1, 8, 4, 16] (t 501) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 125) (pmInputRequests.drop 126) pmNode_298
    1 501 502 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 125 ++ pmInputRequests.drop 125 := (List.take_append_drop 125 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 125, 501 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_502
theorem frontierProjectionViewUnitFacts_1297_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1297).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 199, q 502], y.shape = [1, 8, 4, 16]) ∧
    chunkPrimDimN 0 2 0 (t 1297) = allGatherPrimDimN 1 2 0 [q 199, q 502] := by
  have predecessor := frontierGatheredExchangeUnitFacts_1294_0_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 8, 4, 16] x) [q 198, q 501] [q 199, q 502] :=
    List.Forall₂.cons (frontierProjectionViewRead_pm_199 p q hp) (List.Forall₂.cons (frontierProjectionViewRead_pm_502 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_sequence_unit_output_reconstruct 2 2 1 8 4 16 0
    (t 1294) (t 1297) [q 198, q 501] [q 199, q 502]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionViewRead_sm_1297 s t hs) localReads
#print axioms frontierProjectionViewUnitFacts_1297_0_slot0
theorem frontierProjectionViewRead_sm_1299 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1299 = fw_view [2, 16, 4, 16] (t 1295) := by
  apply SourceLayoutRead.view_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 40) (smInputRequests.drop 41) smNode_40
    0 1295 1299 2 [16, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      smInputRequests = smInputRequests.take 40 ++ smInputRequests.drop 40 := (List.take_append_drop 40 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 40, 1295 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_sm_1299
theorem frontierProjectionViewRead_pm_207 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 207 = fw_view [1, 8, 4, 16] (t 206) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 129) (pmInputRequests.drop 130) pmNode_66
    0 206 207 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 129 ++ pmInputRequests.drop 129 := (List.take_append_drop 129 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 129, 206 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_207
theorem frontierProjectionViewRead_pm_510 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 510 = fw_view [1, 8, 4, 16] (t 509) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 133) (pmInputRequests.drop 134) pmNode_302
    1 509 510 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 133 ++ pmInputRequests.drop 133 := (List.take_append_drop 133 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 133, 509 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_510
theorem frontierProjectionViewUnitFacts_1299_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1299).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 207, q 510], y.shape = [1, 8, 4, 16]) ∧
    chunkPrimDimN 0 2 0 (t 1299) = allGatherPrimDimN 1 2 0 [q 207, q 510] := by
  have predecessor := frontierInputLinearUnitFacts_1295_0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 8, 4, 16] x) [q 206, q 509] [q 207, q 510] :=
    List.Forall₂.cons (frontierProjectionViewRead_pm_207 p q hp) (List.Forall₂.cons (frontierProjectionViewRead_pm_510 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_sequence_unit_output_reconstruct 2 2 1 8 4 16 0
    (t 1295) (t 1299) [q 206, q 509] [q 207, q 510]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionViewRead_sm_1299 s t hs) localReads
#print axioms frontierProjectionViewUnitFacts_1299_0_slot0
theorem frontierProjectionViewRead_sm_1301 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1301 = fw_view [2, 16, 4, 16] (t 1296) := by
  apply SourceLayoutRead.view_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 42) (smInputRequests.drop 43) smNode_42
    0 1296 1301 2 [16, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      smInputRequests = smInputRequests.take 42 ++ smInputRequests.drop 42 := (List.take_append_drop 42 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 42, 1296 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_sm_1301
theorem frontierProjectionViewRead_pm_215 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 215 = fw_view [1, 16, 2, 16] (t 214) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 137) (pmInputRequests.drop 138) pmNode_70
    0 214 215 1 [16, 2, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 137 ++ pmInputRequests.drop 137 := (List.take_append_drop 137 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 137, 214 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_215
theorem frontierProjectionViewRead_pm_518 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 518 = fw_view [1, 16, 2, 16] (t 517) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 141) (pmInputRequests.drop 142) pmNode_306
    1 517 518 1 [16, 2, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 141 ++ pmInputRequests.drop 141 := (List.take_append_drop 141 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 141, 517 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_518
theorem frontierProjectionViewUnitFacts_1301_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1301).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 215, q 518], y.shape = [1, 16, 2, 16]) ∧
    chunkPrimDimN 0 2 0 (t 1301) = allGatherPrimDimN 2 2 0 [q 215, q 518] := by
  have predecessor := frontierInputLinearUnitFacts_1296_0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 16, 2, 16] x) [q 214, q 517] [q 215, q 518] :=
    List.Forall₂.cons (frontierProjectionViewRead_pm_215 p q hp) (List.Forall₂.cons (frontierProjectionViewRead_pm_518 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_head_unit_output_reconstruct 2 2 1 16 2 16 0
    (t 1296) (t 1301) [q 214, q 517] [q 215, q 518]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionViewRead_sm_1301 s t hs) localReads
#print axioms frontierProjectionViewUnitFacts_1301_0_slot0
theorem frontierProjectionViewRead_pm_805 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 805 = fw_view [1, 8, 4, 16] (t 804) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 541) (pmInputRequests.drop 542) pmNode_534
    2 804 805 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 541 ++ pmInputRequests.drop 541 := (List.take_append_drop 541 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 541, 804 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_805
theorem frontierProjectionViewRead_pm_1108 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1108 = fw_view [1, 8, 4, 16] (t 1107) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 547) (pmInputRequests.drop 548) pmNode_770
    3 1107 1108 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 547 ++ pmInputRequests.drop 547 := (List.take_append_drop 547 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 547, 1107 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_1108
theorem frontierProjectionViewUnitFacts_1297_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1297).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 805, q 1108], y.shape = [1, 8, 4, 16]) ∧
    chunkPrimDimN 0 2 1 (t 1297) = allGatherPrimDimN 1 2 0 [q 805, q 1108] := by
  have predecessor := frontierGatheredExchangeUnitFacts_1294_1_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 8, 4, 16] x) [q 804, q 1107] [q 805, q 1108] :=
    List.Forall₂.cons (frontierProjectionViewRead_pm_805 p q hp) (List.Forall₂.cons (frontierProjectionViewRead_pm_1108 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_sequence_unit_output_reconstruct 2 2 1 8 4 16 1
    (t 1294) (t 1297) [q 804, q 1107] [q 805, q 1108]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionViewRead_sm_1297 s t hs) localReads
#print axioms frontierProjectionViewUnitFacts_1297_1_slot0
theorem frontierProjectionViewRead_pm_813 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 813 = fw_view [1, 8, 4, 16] (t 812) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 551) (pmInputRequests.drop 552) pmNode_538
    2 812 813 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 551 ++ pmInputRequests.drop 551 := (List.take_append_drop 551 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 551, 812 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_813
theorem frontierProjectionViewRead_pm_1116 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1116 = fw_view [1, 8, 4, 16] (t 1115) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 555) (pmInputRequests.drop 556) pmNode_774
    3 1115 1116 1 [8, 4, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 555 ++ pmInputRequests.drop 555 := (List.take_append_drop 555 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 555, 1115 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_1116
theorem frontierProjectionViewUnitFacts_1299_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1299).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 813, q 1116], y.shape = [1, 8, 4, 16]) ∧
    chunkPrimDimN 0 2 1 (t 1299) = allGatherPrimDimN 1 2 0 [q 813, q 1116] := by
  have predecessor := frontierInputLinearUnitFacts_1295_1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 8, 4, 16] x) [q 812, q 1115] [q 813, q 1116] :=
    List.Forall₂.cons (frontierProjectionViewRead_pm_813 p q hp) (List.Forall₂.cons (frontierProjectionViewRead_pm_1116 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_sequence_unit_output_reconstruct 2 2 1 8 4 16 1
    (t 1295) (t 1299) [q 812, q 1115] [q 813, q 1116]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionViewRead_sm_1299 s t hs) localReads
#print axioms frontierProjectionViewUnitFacts_1299_1_slot0
theorem frontierProjectionViewRead_pm_821 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 821 = fw_view [1, 16, 2, 16] (t 820) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 559) (pmInputRequests.drop 560) pmNode_542
    2 820 821 1 [16, 2, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 559 ++ pmInputRequests.drop 559 := (List.take_append_drop 559 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 559, 820 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_821
theorem frontierProjectionViewRead_pm_1124 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1124 = fw_view [1, 16, 2, 16] (t 1123) := by
  apply SourceLayoutRead.view_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 563) (pmInputRequests.drop 564) pmNode_778
    3 1123 1124 1 [16, 2, 16] s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 563 ++ pmInputRequests.drop 563 := (List.take_append_drop 563 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 563, 1123 ∉ row.1.outs
    decide
#print axioms frontierProjectionViewRead_pm_1124
theorem frontierProjectionViewUnitFacts_1301_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1301).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 821, q 1124], y.shape = [1, 16, 2, 16]) ∧
    chunkPrimDimN 0 2 1 (t 1301) = allGatherPrimDimN 2 2 0 [q 821, q 1124] := by
  have predecessor := frontierInputLinearUnitFacts_1296_1 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = fw_view [1, 16, 2, 16] x) [q 820, q 1123] [q 821, q 1124] :=
    List.Forall₂.cons (frontierProjectionViewRead_pm_821 p q hp) (List.Forall₂.cons (frontierProjectionViewRead_pm_1124 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_view_head_unit_output_reconstruct 2 2 1 16 2 16 1
    (t 1296) (t 1301) [q 820, q 1123] [q 821, q 1124]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionViewRead_sm_1301 s t hs) localReads
#print axioms frontierProjectionViewUnitFacts_1301_1_slot0
end
end TrainVerify.Denote.RuntimeWorld
