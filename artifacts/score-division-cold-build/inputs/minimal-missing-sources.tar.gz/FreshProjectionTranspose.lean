import FreshHeadExchange
-- UNCOMPILED: parent owns imports, predecessors, frame, aggregate costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierProjectionTransposeRead_sm_1298 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1298 = transposeAxes 1 2 (t 1297) := by
  apply SourceLayoutRead.transposeAxes_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 39) (smInputRequests.drop 40) smNode_39
    0 1297 1298 1 2 s t rfl ?_ rfl ?_ h
  · calc
      smInputRequests = smInputRequests.take 39 ++ smInputRequests.drop 39 := (List.take_append_drop 39 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 39, 1297 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_sm_1298
theorem frontierProjectionTransposeRead_pm_203 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 203 = transposeAxes 1 2 (t 202) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 127) (pmInputRequests.drop 128) pmNode_64
    0 202 203 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 127 ++ pmInputRequests.drop 127 := (List.take_append_drop 127 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 127, 202 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_203
theorem frontierProjectionTransposeRead_pm_506 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 506 = transposeAxes 1 2 (t 505) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 131) (pmInputRequests.drop 132) pmNode_300
    1 505 506 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 131 ++ pmInputRequests.drop 131 := (List.take_append_drop 131 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 131, 505 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_506
theorem frontierProjectionTransposeUnitFacts_1298_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1298).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 203, q 506], y.shape = [1, 2, 16, 16]) ∧
    chunkPrimDimN 0 2 0 (t 1298) = allGatherPrimDimN 1 2 0 [q 203, q 506] := by
  have predecessor := frontierHeadExchangeUnitFacts_1297_0_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 202, q 505] [q 203, q 506] :=
    List.Forall₂.cons (frontierProjectionTransposeRead_pm_203 p q hp) (List.Forall₂.cons (frontierProjectionTransposeRead_pm_506 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_query_unit_output_reconstruct 2 2 1 16 2 16 0
    (t 1297) (t 1298) [q 202, q 505] [q 203, q 506]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionTransposeRead_sm_1298 s t hs) localReads
#print axioms frontierProjectionTransposeUnitFacts_1298_0_slot0
theorem frontierProjectionTransposeRead_sm_1300 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1300 = transposeAxes 1 2 (t 1299) := by
  apply SourceLayoutRead.transposeAxes_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 41) (smInputRequests.drop 42) smNode_41
    0 1299 1300 1 2 s t rfl ?_ rfl ?_ h
  · calc
      smInputRequests = smInputRequests.take 41 ++ smInputRequests.drop 41 := (List.take_append_drop 41 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 41, 1299 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_sm_1300
theorem frontierProjectionTransposeRead_pm_211 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 211 = transposeAxes 1 2 (t 210) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 135) (pmInputRequests.drop 136) pmNode_68
    0 210 211 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 135 ++ pmInputRequests.drop 135 := (List.take_append_drop 135 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 135, 210 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_211
theorem frontierProjectionTransposeRead_pm_514 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 514 = transposeAxes 1 2 (t 513) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 139) (pmInputRequests.drop 140) pmNode_304
    1 513 514 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 139 ++ pmInputRequests.drop 139 := (List.take_append_drop 139 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 139, 513 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_514
theorem frontierProjectionTransposeUnitFacts_1300_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1300).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 211, q 514], y.shape = [1, 4, 16, 8]) ∧
    chunkPrimDimN 0 2 0 (t 1300) = allGatherPrimDimN 3 2 0 [q 211, q 514] := by
  have predecessor := frontierHeadExchangeUnitFacts_1299_0_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 210, q 513] [q 211, q 514] :=
    List.Forall₂.cons (frontierProjectionTransposeRead_pm_211 p q hp) (List.Forall₂.cons (frontierProjectionTransposeRead_pm_514 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_inner_unit_output_reconstruct 2 2 1 16 4 8 0
    (t 1299) (t 1300) [q 210, q 513] [q 211, q 514]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionTransposeRead_sm_1300 s t hs) localReads
#print axioms frontierProjectionTransposeUnitFacts_1300_0_slot0
theorem frontierProjectionTransposeRead_sm_1302 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1302 = transposeAxes 1 2 (t 1301) := by
  apply SourceLayoutRead.transposeAxes_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 43) (smInputRequests.drop 44) smNode_43
    0 1301 1302 1 2 s t rfl ?_ rfl ?_ h
  · calc
      smInputRequests = smInputRequests.take 43 ++ smInputRequests.drop 43 := (List.take_append_drop 43 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 43, 1301 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_sm_1302
theorem frontierProjectionTransposeRead_pm_219 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 219 = transposeAxes 1 2 (t 218) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 143) (pmInputRequests.drop 144) pmNode_72
    0 218 219 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 143 ++ pmInputRequests.drop 143 := (List.take_append_drop 143 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 143, 218 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_219
theorem frontierProjectionTransposeRead_pm_522 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 522 = transposeAxes 1 2 (t 521) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 146) (pmInputRequests.drop 147) pmNode_308
    1 521 522 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 146 ++ pmInputRequests.drop 146 := (List.take_append_drop 146 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 146, 521 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_522
theorem frontierProjectionTransposeUnitFacts_1302_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1302).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 219, q 522], y.shape = [1, 4, 8, 16]) ∧
    chunkPrimDimN 0 2 0 (t 1302) = allGatherPrimDimN 2 2 0 [q 219, q 522] := by
  have predecessor := frontierHeadExchangeUnitFacts_1301_0_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 218, q 521] [q 219, q 522] :=
    List.Forall₂.cons (frontierProjectionTransposeRead_pm_219 p q hp) (List.Forall₂.cons (frontierProjectionTransposeRead_pm_522 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_sequence_unit_output_reconstruct 2 2 1 8 4 16 0
    (t 1301) (t 1302) [q 218, q 521] [q 219, q 522]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionTransposeRead_sm_1302 s t hs) localReads
#print axioms frontierProjectionTransposeUnitFacts_1302_0_slot0
theorem frontierProjectionTransposeRead_pm_809 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 809 = transposeAxes 1 2 (t 808) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 549) (pmInputRequests.drop 550) pmNode_536
    2 808 809 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 549 ++ pmInputRequests.drop 549 := (List.take_append_drop 549 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 549, 808 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_809
theorem frontierProjectionTransposeRead_pm_1112 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1112 = transposeAxes 1 2 (t 1111) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 553) (pmInputRequests.drop 554) pmNode_772
    3 1111 1112 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 553 ++ pmInputRequests.drop 553 := (List.take_append_drop 553 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 553, 1111 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_1112
theorem frontierProjectionTransposeUnitFacts_1298_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1298).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 809, q 1112], y.shape = [1, 2, 16, 16]) ∧
    chunkPrimDimN 0 2 1 (t 1298) = allGatherPrimDimN 1 2 0 [q 809, q 1112] := by
  have predecessor := frontierHeadExchangeUnitFacts_1297_1_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 808, q 1111] [q 809, q 1112] :=
    List.Forall₂.cons (frontierProjectionTransposeRead_pm_809 p q hp) (List.Forall₂.cons (frontierProjectionTransposeRead_pm_1112 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_query_unit_output_reconstruct 2 2 1 16 2 16 1
    (t 1297) (t 1298) [q 808, q 1111] [q 809, q 1112]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionTransposeRead_sm_1298 s t hs) localReads
#print axioms frontierProjectionTransposeUnitFacts_1298_1_slot0
theorem frontierProjectionTransposeRead_pm_817 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 817 = transposeAxes 1 2 (t 816) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 557) (pmInputRequests.drop 558) pmNode_540
    2 816 817 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 557 ++ pmInputRequests.drop 557 := (List.take_append_drop 557 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 557, 816 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_817
theorem frontierProjectionTransposeRead_pm_1120 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1120 = transposeAxes 1 2 (t 1119) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 561) (pmInputRequests.drop 562) pmNode_776
    3 1119 1120 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 561 ++ pmInputRequests.drop 561 := (List.take_append_drop 561 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 561, 1119 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_1120
theorem frontierProjectionTransposeUnitFacts_1300_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1300).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 817, q 1120], y.shape = [1, 4, 16, 8]) ∧
    chunkPrimDimN 0 2 1 (t 1300) = allGatherPrimDimN 3 2 0 [q 817, q 1120] := by
  have predecessor := frontierHeadExchangeUnitFacts_1299_1_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 816, q 1119] [q 817, q 1120] :=
    List.Forall₂.cons (frontierProjectionTransposeRead_pm_817 p q hp) (List.Forall₂.cons (frontierProjectionTransposeRead_pm_1120 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_inner_unit_output_reconstruct 2 2 1 16 4 8 1
    (t 1299) (t 1300) [q 816, q 1119] [q 817, q 1120]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionTransposeRead_sm_1300 s t hs) localReads
#print axioms frontierProjectionTransposeUnitFacts_1300_1_slot0
theorem frontierProjectionTransposeRead_pm_825 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 825 = transposeAxes 1 2 (t 824) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 565) (pmInputRequests.drop 566) pmNode_544
    2 824 825 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 565 ++ pmInputRequests.drop 565 := (List.take_append_drop 565 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 565, 824 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_825
theorem frontierProjectionTransposeRead_pm_1128 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1128 = transposeAxes 1 2 (t 1127) := by
  apply SourceLayoutRead.transposeAxes_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 568) (pmInputRequests.drop 569) pmNode_780
    3 1127 1128 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 568 ++ pmInputRequests.drop 568 := (List.take_append_drop 568 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 568, 1127 ∉ row.1.outs
    decide
#print axioms frontierProjectionTransposeRead_pm_1128
theorem frontierProjectionTransposeUnitFacts_1302_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1302).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 825, q 1128], y.shape = [1, 4, 8, 16]) ∧
    chunkPrimDimN 0 2 1 (t 1302) = allGatherPrimDimN 2 2 0 [q 825, q 1128] := by
  have predecessor := frontierHeadExchangeUnitFacts_1301_1_slot0 s p t q hs hp hvalues
  have localReads : List.Forall₂ (fun x y => y = transposeAxes 1 2 x) [q 824, q 1127] [q 825, q 1128] :=
    List.Forall₂.cons (frontierProjectionTransposeRead_pm_825 p q hp) (List.Forall₂.cons (frontierProjectionTransposeRead_pm_1128 p q hp) (List.Forall₂.nil))
  exact TrainVerify.Denote.source_transpose12_sequence_unit_output_reconstruct 2 2 1 8 4 16 1
    (t 1301) (t 1302) [q 824, q 1127] [q 825, q 1128]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2 (frontierProjectionTransposeRead_sm_1302 s t hs) localReads
#print axioms frontierProjectionTransposeUnitFacts_1302_1_slot0
end
end TrainVerify.Denote.RuntimeWorld
