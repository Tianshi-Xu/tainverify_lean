import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0061
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_484_0 (z : Store) : (s_484 z) 734 = (v_464_0 z) := pR (n_480_484 z) (pR (n_472_480 z) (pR (n_468_472 z) (pR (k_467 z) (pR (k_466 z) (pR (k_465 z) (w_464_0 z))))))
 #a r_484_0
 theorem r_484_1 (z : Store) : (s_484 z) 1037 = (v_471_0 z) := pR (n_480_484 z) (pR (n_472_480 z) (w_471_0 z))
 #a r_484_1
 def v_484_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 0 [(v_464_0 z), (v_471_0 z)]
 def s_485 (z : Store) : Store := storeSet (s_484 z) [(684, allGatherPrimDimN 2 2 0 [((s_484 z) 734), ((s_484 z) 1037)])]
 theorem t_484 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_504) (pmPeers pmNode_504) (s_484 z) pmNode_504 none = some (s_485 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_484 z) pmNode_504 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_484
 theorem k_484 (z : Store) (tid : Tid) (h : tid ∉ [684]) : (s_485 z) tid = (s_484 z) tid := by
   unfold s_485
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_484
 theorem w_484_0 (z : Store) : (s_485 z) 684 = v_484_0 z := by
   unfold s_485
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_484_0, r_484_0 z, r_484_1 z] <;> rfl
 #a w_484_0
 theorem h_484_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_484_0 z).shape = [1, 4, 16, 16] := by
   unfold v_484_0
   exact allGatherPrimDimN_shape 2 2 [(v_464_0 z), (v_471_0 z)] [1, 4, 8, 16] (h_464_0 z z_)
 #a h_484_0
 attribute [local irreducible] v_484_0
 attribute [local irreducible] s_485
 theorem r_485_0 (z : Store) : (s_485 z) 745 = (v_479_0 z) := pR (k_484 z) (pR (k_483 z) (pR (k_482 z) (r_482_0 z)))
 #a r_485_0
 theorem r_485_1 (z : Store) : (s_485 z) 1048 = (v_481_0 z) := pR (k_484 z) (pR (k_483 z) (pR (k_482 z) (r_482_1 z)))
 #a r_485_1
 def v_485_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_479_0 z), (v_481_0 z)]
 theorem g_485 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_738) (s_485 z) pmNode_738 3 1 1051 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_738, r_485_0 z, r_485_1 z, h_479_0 z z_, h_481_0 z z_]
 #a g_485
 def s_486 (z : Store) : Store := pL [2, 3] (s_485 z) pmNode_738 3 1
 theorem t_485 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_738) (pmPeers pmNode_738) (s_485 z) pmNode_738 none = some (s_486 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_738) (s_485 z) pmNode_738).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 1051 (by decide) (g_485 z z_)]
   rfl
 #a t_485
 theorem k_485 (z : Store) (tid : Tid) (h : tid ∉ [1051]) : (s_486 z) tid = (s_485 z) tid := by
   unfold s_486
   dsimp only [pL, pmNode_738, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_485
 theorem w_485_0 (z : Store) : (s_486 z) 1051 = v_485_0 z := by
   unfold s_486
   dsimp only [pL, pmNode_738, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_485_0, r_485_0 z, r_485_1 z] <;> rfl
 #a w_485_0
 theorem h_485_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_485_0 z).shape = [1, 2, 16, 16] := by
   unfold v_485_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_479_0 z z_]
 #a h_485_0
 attribute [local irreducible] v_485_0
 attribute [local irreducible] s_486
 theorem r_486_0 (z : Store) : (s_486 z) 1051 = (v_485_0 z) := w_485_0 z
 #a r_486_0
 def v_486_0 (z : Store) : Tensor := fw_softmax (v_485_0 z)
 def s_487 (z : Store) : Store := storeSet (s_486 z) [(1052, fw_softmax ((s_486 z) 1051))]
 theorem t_486 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_739) (pmPeers pmNode_739) (s_486 z) pmNode_739 none = some (s_487 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_486
 theorem k_486 (z : Store) (tid : Tid) (h : tid ∉ [1052]) : (s_487 z) tid = (s_486 z) tid := by
   unfold s_487
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_486
 theorem w_486_0 (z : Store) : (s_487 z) 1052 = v_486_0 z := by
   unfold s_487
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_486_0, r_486_0 z] <;> rfl
 #a w_486_0
 theorem h_486_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_486_0 z).shape = [1, 2, 16, 16] := by
   unfold v_486_0
   unfold fw_softmax softmax
   split <;> exact h_485_0 z z_
 #a h_486_0
 attribute [local irreducible] v_486_0
 attribute [local irreducible] s_487
 theorem r_487_0 (z : Store) : (s_487 z) 749 = (v_483_0 z) := pR (k_486 z) (pR (k_485 z) (pR (k_484 z) (w_483_0 z)))
 #a r_487_0
 theorem r_487_1 (z : Store) : (s_487 z) 1052 = (v_486_0 z) := w_486_0 z
 #a r_487_1
 def v_487_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_483_0 z), (v_486_0 z)]
 theorem g_487 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_505) (s_487 z) pmNode_505 1 2 752 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_505, r_487_0 z, r_487_1 z, h_483_0 z z_, h_486_0 z z_]
 #a g_487
 def s_488 (z : Store) : Store := pL [2, 3] (s_487 z) pmNode_505 1 2
 theorem t_487 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_505) (pmPeers pmNode_505) (s_487 z) pmNode_505 none = some (s_488 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_505) (s_487 z) pmNode_505).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 752 (by decide) (g_487 z z_)]
   rfl
 #a t_487
 theorem k_487 (z : Store) (tid : Tid) (h : tid ∉ [752]) : (s_488 z) tid = (s_487 z) tid := by
   unfold s_488
   dsimp only [pL, pmNode_505, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_487
 theorem w_487_0 (z : Store) : (s_488 z) 752 = v_487_0 z := by
   unfold s_488
   dsimp only [pL, pmNode_505, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_487_0, r_487_0 z, r_487_1 z] <;> rfl
 #a w_487_0
 theorem h_487_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_487_0 z).shape = [1, 4, 8, 16] := by
   unfold v_487_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_483_0 z z_]
 #a h_487_0
 attribute [local irreducible] v_487_0
 attribute [local irreducible] s_488
 theorem r_488_0 (z : Store) : (s_488 z) 752 = (v_487_0 z) := w_487_0 z
 #a r_488_0
 theorem r_488_1 (z : Store) : (s_488 z) 684 = (v_484_0 z) := pR (k_487 z) (pR (k_486 z) (pR (k_485 z) (w_484_0 z)))
 #a r_488_1
 def v_488_0 (z : Store) : Tensor := fw_matmul (v_487_0 z) (v_484_0 z)
 def s_489 (z : Store) : Store := storeSet (s_488 z) [(753, fw_matmul ((s_488 z) 752) ((s_488 z) 684))]
 theorem t_488 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_506) (pmPeers pmNode_506) (s_488 z) pmNode_506 none = some (s_489 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_488
 theorem k_488 (z : Store) (tid : Tid) (h : tid ∉ [753]) : (s_489 z) tid = (s_488 z) tid := by
   unfold s_489
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_488
 theorem w_488_0 (z : Store) : (s_489 z) 753 = v_488_0 z := by
   unfold s_489
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_488_0, r_488_0 z, r_488_1 z] <;> rfl
 #a w_488_0
 theorem h_488_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_488_0 z).shape = [1, 4, 8, 16] := by
   unfold v_488_0
   unfold fw_matmul batchedMatmul
   rw [h_487_0 z z_, h_484_0 z z_]
   rfl
 #a h_488_0
 attribute [local irreducible] v_488_0
 attribute [local irreducible] s_489
 theorem r_489_0 (z : Store) : (s_489 z) 753 = (v_488_0 z) := w_488_0 z
 #a r_489_0
 def v_489_0 (z : Store) : Tensor := transposeAxes 1 2 (v_488_0 z)
 def s_490 (z : Store) : Store := storeSet (s_489 z) [(757, transposeAxes 1 2 ((s_489 z) 753))]
 theorem t_489 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_507) (pmPeers pmNode_507) (s_489 z) pmNode_507 none = some (s_490 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_489
 theorem k_489 (z : Store) (tid : Tid) (h : tid ∉ [757]) : (s_490 z) tid = (s_489 z) tid := by
   unfold s_490
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_489
 theorem w_489_0 (z : Store) : (s_490 z) 757 = v_489_0 z := by
   unfold s_490
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_489_0, r_489_0 z] <;> rfl
 #a w_489_0
 theorem h_489_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_489_0 z).shape = [1, 8, 4, 16] := by
   unfold v_489_0
   change listSwapAt _ _ _ = _
   rw [h_488_0 z z_]
   rfl
 #a h_489_0
 attribute [local irreducible] v_489_0
 attribute [local irreducible] s_490
 theorem r_490_0 (z : Store) : (s_490 z) 757 = (v_489_0 z) := w_489_0 z
 #a r_490_0
 def v_490_0 (z : Store) : Tensor := (v_489_0 z)
 def s_491 (z : Store) : Store := storeSet (s_490 z) [(759, ((s_490 z) 757))]
 theorem t_490 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_508) (pmPeers pmNode_508) (s_490 z) pmNode_508 none = some (s_491 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_490
 theorem k_490 (z : Store) (tid : Tid) (h : tid ∉ [759]) : (s_491 z) tid = (s_490 z) tid := by
   unfold s_491
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_490
 theorem w_490_0 (z : Store) : (s_491 z) 759 = v_490_0 z := by
   unfold s_491
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_490_0, r_490_0 z] <;> rfl
 #a w_490_0
 theorem h_490_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_490_0 z).shape = [1, 8, 4, 16] := by
   unfold v_490_0
   exact h_489_0 z z_
 #a h_490_0
 attribute [local irreducible] v_490_0
 attribute [local irreducible] s_491
 theorem n_484_488 (z : Store) (tid : Tid) (h : tid ∉ ([684, 1051, 1052, 752] : List Tid)) : (s_488 z) tid = (s_484 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_484 z) (k_485 z)) (pF _ _ _ _ _ (k_486 z) (k_487 z)) tid h
 #a n_484_488
 theorem r_491_0 (z : Store) : (s_491 z) 734 = (v_464_0 z) := pR (k_490 z) (pR (k_489 z) (pR (k_488 z) (pR (n_484_488 z) (r_484_0 z))))
 #a r_491_0
 theorem r_491_1 (z : Store) : (s_491 z) 1037 = (v_471_0 z) := pR (k_490 z) (pR (k_489 z) (pR (k_488 z) (pR (n_484_488 z) (r_484_1 z))))
 #a r_491_1
 def v_491_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 1 [(v_464_0 z), (v_471_0 z)]
 def s_492 (z : Store) : Store := storeSet (s_491 z) [(987, allGatherPrimDimN 2 2 1 [((s_491 z) 734), ((s_491 z) 1037)])]
 theorem t_491 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_740) (pmPeers pmNode_740) (s_491 z) pmNode_740 none = some (s_492 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_491 z) pmNode_740 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_491
 theorem k_491 (z : Store) (tid : Tid) (h : tid ∉ [987]) : (s_492 z) tid = (s_491 z) tid := by
   unfold s_492
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_491
 theorem w_491_0 (z : Store) : (s_492 z) 987 = v_491_0 z := by
   unfold s_492
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_491_0, r_491_0 z, r_491_1 z] <;> rfl
 #a w_491_0
 theorem h_491_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_491_0 z).shape = [1, 4, 16, 16] := by
   unfold v_491_0
   exact allGatherPrimDimN_shape 2 2 [(v_464_0 z), (v_471_0 z)] [1, 4, 8, 16] (h_464_0 z z_)
 #a h_491_0
 attribute [local irreducible] v_491_0
 attribute [local irreducible] s_492
 theorem n_488_492 (z : Store) (tid : Tid) (h : tid ∉ ([753, 757, 759, 987] : List Tid)) : (s_492 z) tid = (s_488 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_488 z) (k_489 z)) (pF _ _ _ _ _ (k_490 z) (k_491 z)) tid h
 #a n_488_492
 theorem r_492_0 (z : Store) : (s_492 z) 749 = (v_483_0 z) := pR (n_488_492 z) (pR (k_487 z) (r_487_0 z))
 #a r_492_0
 theorem r_492_1 (z : Store) : (s_492 z) 1052 = (v_486_0 z) := pR (n_488_492 z) (pR (k_487 z) (r_487_1 z))
 #a r_492_1
 def v_492_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_483_0 z), (v_486_0 z)]
 theorem g_492 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_741) (s_492 z) pmNode_741 1 2 1055 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_741, r_492_0 z, r_492_1 z, h_483_0 z z_, h_486_0 z z_]
 #a g_492
 def s_493 (z : Store) : Store := pL [2, 3] (s_492 z) pmNode_741 1 2
 theorem t_492 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_741) (pmPeers pmNode_741) (s_492 z) pmNode_741 none = some (s_493 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_741) (s_492 z) pmNode_741).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1055 (by decide) (g_492 z z_)]
   rfl
 #a t_492
 theorem k_492 (z : Store) (tid : Tid) (h : tid ∉ [1055]) : (s_493 z) tid = (s_492 z) tid := by
   unfold s_493
   dsimp only [pL, pmNode_741, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_492
 theorem w_492_0 (z : Store) : (s_493 z) 1055 = v_492_0 z := by
   unfold s_493
   dsimp only [pL, pmNode_741, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_492_0, r_492_0 z, r_492_1 z] <;> rfl
 #a w_492_0
 theorem h_492_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_492_0 z).shape = [1, 4, 8, 16] := by
   unfold v_492_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_483_0 z z_]
 #a h_492_0
 attribute [local irreducible] v_492_0
 attribute [local irreducible] s_493
 record_prefix_opacity v_484_0 s_485 v_485_0 s_486 v_486_0 s_487 v_487_0 s_488 v_488_0 s_489 v_489_0 s_490 v_490_0 s_491 v_491_0 s_492 v_492_0 s_493

 end
 end TrainVerify.Denote.RuntimeWorld
