import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0105
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_832_0 (z : Store) : (s_832 z) 706 = (v_827_0 z) := pR (n_828_832 z) (w_827_0 z)
 #a r_832_0
 theorem r_832_1 (z : Store) : (s_832 z) 1009 = (v_831_0 z) := w_831_0 z
 #a r_832_1
 def v_832_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_827_0 z), (v_831_0 z)]
 theorem g_832 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_677) (s_832 z) pmNode_677 1 2 890 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_677, r_832_0 z, r_832_1 z, h_827_0 z z_, h_831_0 z z_]
 #a g_832
 def s_833 (z : Store) : Store := pL [2, 3] (s_832 z) pmNode_677 1 2
 theorem t_832 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_677) (pmPeers pmNode_677) (s_832 z) pmNode_677 none = some (s_833 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_677) (s_832 z) pmNode_677).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 890 (by decide) (g_832 z z_)]
   rfl
 #a t_832
 theorem k_832 (z : Store) (tid : Tid) (h : tid ∉ [890]) : (s_833 z) tid = (s_832 z) tid := by
   unfold s_833
   dsimp only [pL, pmNode_677, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_832
 theorem w_832_0 (z : Store) : (s_833 z) 890 = v_832_0 z := by
   unfold s_833
   dsimp only [pL, pmNode_677, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_832_0, r_832_0 z, r_832_1 z] <;> rfl
 #a w_832_0
 theorem h_832_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_832_0 z).shape = [1, 16, 32] := by
   unfold v_832_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_827_0 z z_]
 #a h_832_0
 attribute [local irreducible] v_832_0
 attribute [local irreducible] s_833
 theorem n_824_832 (z : Store) (tid : Tid) (h : tid ∉ ([892, 710, 631, 707, 706, 627, 629, 1195, 1013, 934, 1010, 1009, 930, 932] : List Tid)) : (s_832 z) tid = (s_824 z) tid := by
   exact pF _ _ _ _ _ (n_824_828 z) (n_828_832 z) tid h
 #a n_824_832
 theorem n_816_832 (z : Store) (tid : Tid) (h : tid ∉ ([717, 637, 1022, 1014, 1019, 940, 894, 714, 634, 1197, 1016, 937, 892, 710, 631, 707, 706, 627, 629, 1195, 1013, 934, 1010, 1009, 930, 932] : List Tid)) : (s_832 z) tid = (s_816 z) tid := by
   exact pF _ _ _ _ _ (n_816_824 z) (n_824_832 z) tid h
 #a n_816_832
 theorem n_800_832 (z : Store) (tid : Tid) (h : tid ∉ ([1026, 1032, 1036, 1035, 716, 728, 1020, 1031, 725, 713, 722, 1028, 1017, 1025, 719, 711, 717, 637, 1022, 1014, 1019, 940, 894, 714, 634, 1197, 1016, 937, 892, 710, 631, 707, 706, 627, 629, 1195, 1013, 934, 1010, 1009, 930, 932] : List Tid)) : (s_832 z) tid = (s_800 z) tid := by
   exact pF _ _ _ _ _ (n_800_816 z) (n_816_832 z) tid h
 #a n_800_832
 theorem n_768_832 (z : Store) (tid : Tid) (h : tid ∉ ([764, 763, 1067, 1066, 760, 758, 755, 754, 756, 1063, 1061, 1059, 1058, 1057, 751, 735, 750, 1054, 1038, 1053, 747, 746, 1050, 1049, 743, 741, 742, 1046, 1044, 1045, 737, 723, 729, 733, 732, 1040, 1026, 1032, 1036, 1035, 716, 728, 1020, 1031, 725, 713, 722, 1028, 1017, 1025, 719, 711, 717, 637, 1022, 1014, 1019, 940, 894, 714, 634, 1197, 1016, 937, 892, 710, 631, 707, 706, 627, 629, 1195, 1013, 934, 1010, 1009, 930, 932] : List Tid)) : (s_832 z) tid = (s_768 z) tid := by
   exact pF _ _ _ _ _ (n_768_800 z) (n_800_832 z) tid h
 #a n_768_832
 theorem r_833_0 (z : Store) : (s_833 z) 890 = (v_832_0 z) := w_832_0 z
 #a r_833_0
 theorem r_833_1 (z : Store) : (s_833 z) 772 = (v_760_0 z) := pR (k_832 z) (pR (n_768_832 z) (pR (n_764_768 z) (pR (k_763 z) (pR (k_762 z) (pR (k_761 z) (w_760_0 z))))))
 #a r_833_1
 def v_833_0 (z : Store) : Tensor := tensorSum [(v_832_0 z), (v_760_0 z)]
 def s_834 (z : Store) : Store := storeSet (s_833 z) [(703, tensorSum [((s_833 z) 890), ((s_833 z) 772)])]
 theorem t_833 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_678) (pmPeers pmNode_678) (s_833 z) pmNode_678 none = some (s_834 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_833
 theorem k_833 (z : Store) (tid : Tid) (h : tid ∉ [703]) : (s_834 z) tid = (s_833 z) tid := by
   unfold s_834
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_833
 theorem w_833_0 (z : Store) : (s_834 z) 703 = v_833_0 z := by
   unfold s_834
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_833_0, r_833_0 z, r_833_1 z] <;> rfl
 #a w_833_0
 theorem h_833_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_833_0 z).shape = [1, 16, 32] := by
   unfold v_833_0
   rw [tensorSum_shape]
   exact h_832_0 z z_
 #a h_833_0
 attribute [local irreducible] v_833_0
 attribute [local irreducible] s_834
 theorem r_834_0 (z : Store) : (s_834 z) 703 = (v_833_0 z) := w_833_0 z
 #a r_834_0
 theorem r_834_1 (z : Store) : (s_834 z) 695 = (v_423_0 z) := pR (k_833 z) (pR (k_832 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (k_431 z) (r_431_0 z)))))))
 #a r_834_1
 theorem r_834_2 (z : Store) : (s_834 z) 700 = (v_430_0 z) := pR (k_833 z) (pR (k_832 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (k_431 z) (r_431_1 z)))))))
 #a r_834_2
 def v_834_0 (z : Store) : Tensor := (bw_add2 (v_833_0 z) (v_423_0 z) (v_430_0 z)).1
 def v_834_1 (z : Store) : Tensor := (bw_add2 (v_833_0 z) (v_423_0 z) (v_430_0 z)).2
 def s_835 (z : Store) : Store := storeSet (s_834 z) [(696, (bw_add2 ((s_834 z) 703) ((s_834 z) 695) ((s_834 z) 700)).1), (702, (bw_add2 ((s_834 z) 703) ((s_834 z) 695) ((s_834 z) 700)).2)]
 theorem t_834 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_679) (pmPeers pmNode_679) (s_834 z) pmNode_679 none = some (s_835 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_834
 theorem k_834 (z : Store) (tid : Tid) (h : tid ∉ [696, 702]) : (s_835 z) tid = (s_834 z) tid := by
   unfold s_835
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_834
 theorem w_834_0 (z : Store) : (s_835 z) 696 = v_834_0 z := by
   unfold s_835
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_834_0, r_834_0 z, r_834_1 z, r_834_2 z] <;> rfl
 #a w_834_0
 theorem h_834_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_834_0 z).shape = [1, 16, 32] := by
   unfold v_834_0
   exact h_423_0 z z_
 #a h_834_0
 attribute [local irreducible] v_834_0
 theorem w_834_1 (z : Store) : (s_835 z) 702 = v_834_1 z := by
   unfold s_835
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_834_1, r_834_0 z, r_834_1 z, r_834_2 z] <;> rfl
 #a w_834_1
 theorem h_834_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_834_1 z).shape = [1, 16, 32] := by
   unfold v_834_1
   exact h_430_0 z z_
 #a h_834_1
 attribute [local irreducible] v_834_1
 attribute [local irreducible] s_835
 theorem r_835_0 (z : Store) : (s_835 z) 706 = (v_827_0 z) := pR (k_834 z) (pR (k_833 z) (pR (k_832 z) (r_832_0 z)))
 #a r_835_0
 theorem r_835_1 (z : Store) : (s_835 z) 1009 = (v_831_0 z) := pR (k_834 z) (pR (k_833 z) (pR (k_832 z) (r_832_1 z)))
 #a r_835_1
 def v_835_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_827_0 z), (v_831_0 z)]
 theorem g_835 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_913) (s_835 z) pmNode_913 1 2 1193 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_913, r_835_0 z, r_835_1 z, h_827_0 z z_, h_831_0 z z_]
 #a g_835
 def s_836 (z : Store) : Store := pL [2, 3] (s_835 z) pmNode_913 1 2
 theorem t_835 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_913) (pmPeers pmNode_913) (s_835 z) pmNode_913 none = some (s_836 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_913) (s_835 z) pmNode_913).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1193 (by decide) (g_835 z z_)]
   rfl
 #a t_835
 theorem k_835 (z : Store) (tid : Tid) (h : tid ∉ [1193]) : (s_836 z) tid = (s_835 z) tid := by
   unfold s_836
   dsimp only [pL, pmNode_913, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_835
 theorem w_835_0 (z : Store) : (s_836 z) 1193 = v_835_0 z := by
   unfold s_836
   dsimp only [pL, pmNode_913, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_835_0, r_835_0 z, r_835_1 z] <;> rfl
 #a w_835_0
 theorem h_835_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_835_0 z).shape = [1, 16, 32] := by
   unfold v_835_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_827_0 z z_]
 #a h_835_0
 attribute [local irreducible] v_835_0
 attribute [local irreducible] s_836
 theorem n_832_836 (z : Store) (tid : Tid) (h : tid ∉ ([890, 703, 696, 702, 1193] : List Tid)) : (s_836 z) tid = (s_832 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_832 z) (k_833 z)) (pF _ _ _ _ _ (k_834 z) (k_835 z)) tid h
 #a n_832_836
 theorem r_836_0 (z : Store) : (s_836 z) 1193 = (v_835_0 z) := w_835_0 z
 #a r_836_0
 theorem r_836_1 (z : Store) : (s_836 z) 1075 = (v_763_0 z) := pR (n_832_836 z) (pR (n_768_832 z) (pR (n_764_768 z) (w_763_0 z)))
 #a r_836_1
 def v_836_0 (z : Store) : Tensor := tensorSum [(v_835_0 z), (v_763_0 z)]
 def s_837 (z : Store) : Store := storeSet (s_836 z) [(1006, tensorSum [((s_836 z) 1193), ((s_836 z) 1075)])]
 theorem t_836 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_914) (pmPeers pmNode_914) (s_836 z) pmNode_914 none = some (s_837 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_836
 theorem k_836 (z : Store) (tid : Tid) (h : tid ∉ [1006]) : (s_837 z) tid = (s_836 z) tid := by
   unfold s_837
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_836
 theorem w_836_0 (z : Store) : (s_837 z) 1006 = v_836_0 z := by
   unfold s_837
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_836_0, r_836_0 z, r_836_1 z] <;> rfl
 #a w_836_0
 theorem h_836_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_836_0 z).shape = [1, 16, 32] := by
   unfold v_836_0
   rw [tensorSum_shape]
   exact h_835_0 z z_
 #a h_836_0
 attribute [local irreducible] v_836_0
 attribute [local irreducible] s_837
 theorem r_837_0 (z : Store) : (s_837 z) 1006 = (v_836_0 z) := w_836_0 z
 #a r_837_0
 theorem r_837_1 (z : Store) : (s_837 z) 998 = (v_427_0 z) := pR (k_836 z) (pR (n_832_836 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_440_448 z) (pR (n_436_440 z) (pR (k_435 z) (pR (k_434 z) (r_434_0 z)))))))))
 #a r_837_1
 theorem r_837_2 (z : Store) : (s_837 z) 1003 = (v_433_0 z) := pR (k_836 z) (pR (n_832_836 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_440_448 z) (pR (n_436_440 z) (pR (k_435 z) (pR (k_434 z) (r_434_1 z)))))))))
 #a r_837_2
 def v_837_0 (z : Store) : Tensor := (bw_add2 (v_836_0 z) (v_427_0 z) (v_433_0 z)).1
 def v_837_1 (z : Store) : Tensor := (bw_add2 (v_836_0 z) (v_427_0 z) (v_433_0 z)).2
 def s_838 (z : Store) : Store := storeSet (s_837 z) [(999, (bw_add2 ((s_837 z) 1006) ((s_837 z) 998) ((s_837 z) 1003)).1), (1005, (bw_add2 ((s_837 z) 1006) ((s_837 z) 998) ((s_837 z) 1003)).2)]
 theorem t_837 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_915) (pmPeers pmNode_915) (s_837 z) pmNode_915 none = some (s_838 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_837
 theorem k_837 (z : Store) (tid : Tid) (h : tid ∉ [999, 1005]) : (s_838 z) tid = (s_837 z) tid := by
   unfold s_838
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_837
 theorem w_837_0 (z : Store) : (s_838 z) 999 = v_837_0 z := by
   unfold s_838
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_837_0, r_837_0 z, r_837_1 z, r_837_2 z] <;> rfl
 #a w_837_0
 theorem h_837_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_837_0 z).shape = [1, 16, 32] := by
   unfold v_837_0
   exact h_427_0 z z_
 #a h_837_0
 attribute [local irreducible] v_837_0
 theorem w_837_1 (z : Store) : (s_838 z) 1005 = v_837_1 z := by
   unfold s_838
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_837_1, r_837_0 z, r_837_1 z, r_837_2 z] <;> rfl
 #a w_837_1
 theorem h_837_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_837_1 z).shape = [1, 16, 32] := by
   unfold v_837_1
   exact h_433_0 z z_
 #a h_837_1
 attribute [local irreducible] v_837_1
 attribute [local irreducible] s_838
 theorem r_838_0 (z : Store) : (s_838 z) 702 = (v_834_1 z) := pR (k_837 z) (pR (k_836 z) (pR (k_835 z) (w_834_1 z)))
 #a r_838_0
 theorem r_838_1 (z : Store) : (s_838 z) 1005 = (v_837_1 z) := w_837_1 z
 #a r_838_1
 def v_838_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_834_1 z), (v_837_1 z)]
 theorem g_838 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_680) (s_838 z) pmNode_680 2 1 699 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_680, r_838_0 z, r_838_1 z, h_834_1 z z_, h_837_1 z z_]
 #a g_838
 def s_839 (z : Store) : Store := pL [2, 3] (s_838 z) pmNode_680 2 1
 theorem t_838 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_680) (pmPeers pmNode_680) (s_838 z) pmNode_680 none = some (s_839 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_680) (s_838 z) pmNode_680).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 699 (by decide) (g_838 z z_)]
   rfl
 #a t_838
 theorem k_838 (z : Store) (tid : Tid) (h : tid ∉ [699]) : (s_839 z) tid = (s_838 z) tid := by
   unfold s_839
   dsimp only [pL, pmNode_680, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_838
 theorem w_838_0 (z : Store) : (s_839 z) 699 = v_838_0 z := by
   unfold s_839
   dsimp only [pL, pmNode_680, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_838_0, r_838_0 z, r_838_1 z] <;> rfl
 #a w_838_0
 theorem h_838_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_838_0 z).shape = [1, 8, 64] := by
   unfold v_838_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_834_1 z z_]
 #a h_838_0
 attribute [local irreducible] v_838_0
 attribute [local irreducible] s_839
 record_prefix_opacity v_832_0 s_833 v_833_0 s_834 v_834_0 v_834_1 s_835 v_835_0 s_836 v_836_0 s_837 v_837_0 v_837_1 s_838 v_838_0 s_839

 end
 end TrainVerify.Denote.RuntimeWorld
