import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0099
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_786_0 (z : Store) : (s_786 z) 750 = (v_782_0 z) := pR (k_785 z) (pR (k_784 z) (pR (k_783 z) (w_782_0 z)))
 #a r_786_0
 theorem r_786_1 (z : Store) : (s_786 z) 1053 = (v_785_0 z) := w_785_0 z
 #a r_786_1
 def v_786_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_782_0 z), (v_785_0 z)]
 theorem g_786 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_654) (s_786 z) pmNode_654 1 3 747 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_654, r_786_0 z, r_786_1 z, h_782_0 z z_, h_785_0 z z_]
 #a g_786
 def s_787 (z : Store) : Store := pL [2, 3] (s_786 z) pmNode_654 1 3
 theorem t_786 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_654) (pmPeers pmNode_654) (s_786 z) pmNode_654 none = some (s_787 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_654) (s_786 z) pmNode_654).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 747 (by decide) (g_786 z z_)]
   rfl
 #a t_786
 theorem k_786 (z : Store) (tid : Tid) (h : tid ∉ [747]) : (s_787 z) tid = (s_786 z) tid := by
   unfold s_787
   dsimp only [pL, pmNode_654, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_786
 theorem w_786_0 (z : Store) : (s_787 z) 747 = v_786_0 z := by
   unfold s_787
   dsimp only [pL, pmNode_654, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_786_0, r_786_0 z, r_786_1 z] <;> rfl
 #a w_786_0
 theorem h_786_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_786_0 z).shape = [1, 4, 16, 8] := by
   unfold v_786_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_782_0 z z_]
 #a h_786_0
 attribute [local irreducible] v_786_0
 attribute [local irreducible] s_787
 theorem r_787_0 (z : Store) : (s_787 z) 747 = (v_786_0 z) := w_786_0 z
 #a r_787_0
 theorem r_787_1 (z : Store) : (s_787 z) 744 = (v_478_0 z) := pR (k_786 z) (pR (k_785 z) (pR (k_784 z) (pR (n_768_784 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (k_479 z) (r_479_0 z)))))))
 #a r_787_1
 def v_787_0 (z : Store) : Tensor := bw_div ((4 : Nat) : Scalar) (v_786_0 z)
 def s_788 (z : Store) : Store := storeSet (s_787 z) [(746, bw_div ((4 : Nat) : Scalar) ((s_787 z) 747))]
 theorem t_787 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_655) (pmPeers pmNode_655) (s_787 z) pmNode_655 none = some (s_788 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_787
 theorem k_787 (z : Store) (tid : Tid) (h : tid ∉ [746]) : (s_788 z) tid = (s_787 z) tid := by
   unfold s_788
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_787
 theorem w_787_0 (z : Store) : (s_788 z) 746 = v_787_0 z := by
   unfold s_788
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_787_0, r_787_0 z, r_787_1 z] <;> rfl
 #a w_787_0
 theorem h_787_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_787_0 z).shape = [1, 4, 16, 8] := by
   unfold v_787_0
   exact h_786_0 z z_
 #a h_787_0
 attribute [local irreducible] v_787_0
 attribute [local irreducible] s_788
 theorem r_788_0 (z : Store) : (s_788 z) 750 = (v_782_0 z) := pR (k_787 z) (pR (k_786 z) (r_786_0 z))
 #a r_788_0
 theorem r_788_1 (z : Store) : (s_788 z) 1053 = (v_785_0 z) := pR (k_787 z) (pR (k_786 z) (r_786_1 z))
 #a r_788_1
 def v_788_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_782_0 z), (v_785_0 z)]
 theorem g_788 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_890) (s_788 z) pmNode_890 1 3 1050 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_890, r_788_0 z, r_788_1 z, h_782_0 z z_, h_785_0 z z_]
 #a g_788
 def s_789 (z : Store) : Store := pL [2, 3] (s_788 z) pmNode_890 1 3
 theorem t_788 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_890) (pmPeers pmNode_890) (s_788 z) pmNode_890 none = some (s_789 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_890) (s_788 z) pmNode_890).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 1050 (by decide) (g_788 z z_)]
   rfl
 #a t_788
 theorem k_788 (z : Store) (tid : Tid) (h : tid ∉ [1050]) : (s_789 z) tid = (s_788 z) tid := by
   unfold s_789
   dsimp only [pL, pmNode_890, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_788
 theorem w_788_0 (z : Store) : (s_789 z) 1050 = v_788_0 z := by
   unfold s_789
   dsimp only [pL, pmNode_890, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_788_0, r_788_0 z, r_788_1 z] <;> rfl
 #a w_788_0
 theorem h_788_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_788_0 z).shape = [1, 4, 16, 8] := by
   unfold v_788_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_782_0 z z_]
 #a h_788_0
 attribute [local irreducible] v_788_0
 attribute [local irreducible] s_789
 theorem n_784_788 (z : Store) (tid : Tid) (h : tid ∉ ([1038, 1053, 747, 746] : List Tid)) : (s_788 z) tid = (s_784 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_784 z) (k_785 z)) (pF _ _ _ _ _ (k_786 z) (k_787 z)) tid h
 #a n_784_788
 theorem r_789_0 (z : Store) : (s_789 z) 1050 = (v_788_0 z) := w_788_0 z
 #a r_789_0
 theorem r_789_1 (z : Store) : (s_789 z) 1047 = (v_480_0 z) := pR (k_788 z) (pR (n_784_788 z) (pR (n_768_784 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (n_488_496 z) (pR (n_484_488 z) (pR (k_483 z) (pR (k_482 z) (pR (k_481 z) (r_481_0 z))))))))))
 #a r_789_1
 def v_789_0 (z : Store) : Tensor := bw_div ((4 : Nat) : Scalar) (v_788_0 z)
 def s_790 (z : Store) : Store := storeSet (s_789 z) [(1049, bw_div ((4 : Nat) : Scalar) ((s_789 z) 1050))]
 theorem t_789 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_891) (pmPeers pmNode_891) (s_789 z) pmNode_891 none = some (s_790 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_789
 theorem k_789 (z : Store) (tid : Tid) (h : tid ∉ [1049]) : (s_790 z) tid = (s_789 z) tid := by
   unfold s_790
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_789
 theorem w_789_0 (z : Store) : (s_790 z) 1049 = v_789_0 z := by
   unfold s_790
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_789_0, r_789_0 z, r_789_1 z] <;> rfl
 #a w_789_0
 theorem h_789_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_789_0 z).shape = [1, 4, 16, 8] := by
   unfold v_789_0
   exact h_788_0 z z_
 #a h_789_0
 attribute [local irreducible] v_789_0
 attribute [local irreducible] s_790
 theorem r_790_0 (z : Store) : (s_790 z) 746 = (v_787_0 z) := pR (k_789 z) (pR (k_788 z) (w_787_0 z))
 #a r_790_0
 theorem r_790_1 (z : Store) : (s_790 z) 1049 = (v_789_0 z) := w_789_0 z
 #a r_790_1
 def v_790_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_787_0 z), (v_789_0 z)]
 theorem g_790 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_656) (s_790 z) pmNode_656 3 1 743 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_656, r_790_0 z, r_790_1 z, h_787_0 z z_, h_789_0 z z_]
 #a g_790
 def s_791 (z : Store) : Store := pL [2, 3] (s_790 z) pmNode_656 3 1
 theorem t_790 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_656) (pmPeers pmNode_656) (s_790 z) pmNode_656 none = some (s_791 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_656) (s_790 z) pmNode_656).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 743 (by decide) (g_790 z z_)]
   rfl
 #a t_790
 theorem k_790 (z : Store) (tid : Tid) (h : tid ∉ [743]) : (s_791 z) tid = (s_790 z) tid := by
   unfold s_791
   dsimp only [pL, pmNode_656, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_790
 theorem w_790_0 (z : Store) : (s_791 z) 743 = v_790_0 z := by
   unfold s_791
   dsimp only [pL, pmNode_656, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_790_0, r_790_0 z, r_790_1 z] <;> rfl
 #a w_790_0
 theorem h_790_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_790_0 z).shape = [1, 2, 16, 16] := by
   unfold v_790_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_787_0 z z_]
 #a h_790_0
 attribute [local irreducible] v_790_0
 attribute [local irreducible] s_791
 theorem r_791_0 (z : Store) : (s_791 z) 743 = (v_790_0 z) := w_790_0 z
 #a r_791_0
 theorem r_791_1 (z : Store) : (s_791 z) 738 = (v_466_0 z) := pR (k_790 z) (pR (k_789 z) (pR (k_788 z) (pR (n_784_788 z) (pR (n_768_784 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_476_480 z) (pR (k_475 z) (pR (k_474 z) (r_474_0 z))))))))))
 #a r_791_1
 theorem r_791_2 (z : Store) : (s_791 z) 739 = (v_473_0 z) := pR (k_790 z) (pR (k_789 z) (pR (k_788 z) (pR (n_784_788 z) (pR (n_768_784 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_476_480 z) (pR (k_475 z) (pR (k_474 z) (r_474_1 z))))))))))
 #a r_791_2
 def v_791_0 (z : Store) : Tensor := (batchedMatmulBwd (v_790_0 z) (v_466_0 z) (v_473_0 z)).1
 def v_791_1 (z : Store) : Tensor := (batchedMatmulBwd (v_790_0 z) (v_466_0 z) (v_473_0 z)).2
 def s_792 (z : Store) : Store := storeSet (s_791 z) [(741, (batchedMatmulBwd ((s_791 z) 743) ((s_791 z) 738) ((s_791 z) 739)).1), (742, (batchedMatmulBwd ((s_791 z) 743) ((s_791 z) 738) ((s_791 z) 739)).2)]
 theorem t_791 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_657) (pmPeers pmNode_657) (s_791 z) pmNode_657 none = some (s_792 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_791
 theorem k_791 (z : Store) (tid : Tid) (h : tid ∉ [741, 742]) : (s_792 z) tid = (s_791 z) tid := by
   unfold s_792
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_791
 theorem w_791_0 (z : Store) : (s_792 z) 741 = v_791_0 z := by
   unfold s_792
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_791_0, r_791_0 z, r_791_1 z, r_791_2 z] <;> rfl
 #a w_791_0
 theorem h_791_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_791_0 z).shape = [1, 2, 16, 16] := by
   unfold v_791_0
   change (batchedMatmul (v_790_0 z) (transpose2d (v_473_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_790_0 z z_, h_473_0 z z_]
   rfl
 #a h_791_0
 attribute [local irreducible] v_791_0
 theorem w_791_1 (z : Store) : (s_792 z) 742 = v_791_1 z := by
   unfold s_792
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_791_1, r_791_0 z, r_791_1 z, r_791_2 z] <;> rfl
 #a w_791_1
 theorem h_791_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_791_1 z).shape = [1, 2, 16, 16] := by
   unfold v_791_1
   change (batchedMatmul (transpose2d (v_466_0 z)) (v_790_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_790_0 z z_, h_466_0 z z_]
   rfl
 #a h_791_1
 attribute [local irreducible] v_791_1
 attribute [local irreducible] s_792
 theorem r_792_0 (z : Store) : (s_792 z) 746 = (v_787_0 z) := pR (k_791 z) (pR (k_790 z) (r_790_0 z))
 #a r_792_0
 theorem r_792_1 (z : Store) : (s_792 z) 1049 = (v_789_0 z) := pR (k_791 z) (pR (k_790 z) (r_790_1 z))
 #a r_792_1
 def v_792_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_787_0 z), (v_789_0 z)]
 theorem g_792 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_892) (s_792 z) pmNode_892 3 1 1046 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_892, r_792_0 z, r_792_1 z, h_787_0 z z_, h_789_0 z z_]
 #a g_792
 def s_793 (z : Store) : Store := pL [2, 3] (s_792 z) pmNode_892 3 1
 theorem t_792 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_892) (pmPeers pmNode_892) (s_792 z) pmNode_892 none = some (s_793 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_892) (s_792 z) pmNode_892).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 1046 (by decide) (g_792 z z_)]
   rfl
 #a t_792
 theorem k_792 (z : Store) (tid : Tid) (h : tid ∉ [1046]) : (s_793 z) tid = (s_792 z) tid := by
   unfold s_793
   dsimp only [pL, pmNode_892, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_792
 theorem w_792_0 (z : Store) : (s_793 z) 1046 = v_792_0 z := by
   unfold s_793
   dsimp only [pL, pmNode_892, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_792_0, r_792_0 z, r_792_1 z] <;> rfl
 #a w_792_0
 theorem h_792_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_792_0 z).shape = [1, 2, 16, 16] := by
   unfold v_792_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_787_0 z z_]
 #a h_792_0
 attribute [local irreducible] v_792_0
 attribute [local irreducible] s_793
 theorem n_788_792 (z : Store) (tid : Tid) (h : tid ∉ ([1050, 1049, 743, 741, 742] : List Tid)) : (s_792 z) tid = (s_788 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_788 z) (k_789 z)) (pF _ _ _ _ _ (k_790 z) (k_791 z)) tid h
 #a n_788_792
 theorem n_784_792 (z : Store) (tid : Tid) (h : tid ∉ ([1038, 1053, 747, 746, 1050, 1049, 743, 741, 742] : List Tid)) : (s_792 z) tid = (s_784 z) tid := by
   exact pF _ _ _ _ _ (n_784_788 z) (n_788_792 z) tid h
 #a n_784_792
 theorem r_793_0 (z : Store) : (s_793 z) 1046 = (v_792_0 z) := w_792_0 z
 #a r_793_0
 theorem r_793_1 (z : Store) : (s_793 z) 1041 = (v_475_0 z) := pR (k_792 z) (pR (n_784_792 z) (pR (n_768_784 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (k_479 z) (pR (k_478 z) (pR (k_477 z) (r_477_0 z))))))))
 #a r_793_1
 theorem r_793_2 (z : Store) : (s_793 z) 1042 = (v_476_0 z) := pR (k_792 z) (pR (n_784_792 z) (pR (n_768_784 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (k_479 z) (pR (k_478 z) (pR (k_477 z) (r_477_1 z))))))))
 #a r_793_2
 def v_793_0 (z : Store) : Tensor := (batchedMatmulBwd (v_792_0 z) (v_475_0 z) (v_476_0 z)).1
 def v_793_1 (z : Store) : Tensor := (batchedMatmulBwd (v_792_0 z) (v_475_0 z) (v_476_0 z)).2
 def s_794 (z : Store) : Store := storeSet (s_793 z) [(1044, (batchedMatmulBwd ((s_793 z) 1046) ((s_793 z) 1041) ((s_793 z) 1042)).1), (1045, (batchedMatmulBwd ((s_793 z) 1046) ((s_793 z) 1041) ((s_793 z) 1042)).2)]
 theorem t_793 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_893) (pmPeers pmNode_893) (s_793 z) pmNode_893 none = some (s_794 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_793
 theorem k_793 (z : Store) (tid : Tid) (h : tid ∉ [1044, 1045]) : (s_794 z) tid = (s_793 z) tid := by
   unfold s_794
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_793
 theorem w_793_0 (z : Store) : (s_794 z) 1044 = v_793_0 z := by
   unfold s_794
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_793_0, r_793_0 z, r_793_1 z, r_793_2 z] <;> rfl
 #a w_793_0
 theorem h_793_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_793_0 z).shape = [1, 2, 16, 16] := by
   unfold v_793_0
   change (batchedMatmul (v_792_0 z) (transpose2d (v_476_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_792_0 z z_, h_476_0 z z_]
   rfl
 #a h_793_0
 attribute [local irreducible] v_793_0
 theorem w_793_1 (z : Store) : (s_794 z) 1045 = v_793_1 z := by
   unfold s_794
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_793_1, r_793_0 z, r_793_1 z, r_793_2 z] <;> rfl
 #a w_793_1
 theorem h_793_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_793_1 z).shape = [1, 2, 16, 16] := by
   unfold v_793_1
   change (batchedMatmul (transpose2d (v_475_0 z)) (v_792_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_792_0 z z_, h_475_0 z z_]
   rfl
 #a h_793_1
 attribute [local irreducible] v_793_1
 attribute [local irreducible] s_794
 record_prefix_opacity v_786_0 s_787 v_787_0 s_788 v_788_0 s_789 v_789_0 s_790 v_790_0 s_791 v_791_0 v_791_1 s_792 v_792_0 s_793 v_793_0 v_793_1 s_794

 end
 end TrainVerify.Denote.RuntimeWorld
