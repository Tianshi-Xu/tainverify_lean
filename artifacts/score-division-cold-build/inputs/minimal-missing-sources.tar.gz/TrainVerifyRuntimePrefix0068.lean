import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0067
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_533_0 (z : Store) : (s_533 z) 694 = (v_532_0 z) := w_532_0 z
 #a r_533_0
 theorem r_533_1 (z : Store) : (s_533 z) 653 = (z 653) := pR (k_532 z) (pR (n_528_532 z) (pR (n_512_528 z) (pR (n_0_512 z) (e_78 z))))
 #a r_533_1
 def v_533_0 (z : Store) : Tensor := fw_linear (v_532_0 z) (z 653)
 def s_534 (z : Store) : Store := storeSet (s_533 z) [(795, fw_linear ((s_533 z) 694) ((s_533 z) 653))]
 theorem t_533 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_528) (pmPeers pmNode_528) (s_533 z) pmNode_528 none = some (s_534 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_533
 theorem k_533 (z : Store) (tid : Tid) (h : tid ∉ [795]) : (s_534 z) tid = (s_533 z) tid := by
   unfold s_534
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_533
 theorem w_533_0 (z : Store) : (s_534 z) 795 = v_533_0 z := by
   unfold s_534
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_533_0, r_533_0 z, r_533_1 z] <;> rfl
 #a w_533_0
 theorem h_533_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_533_0 z).shape = [1, 16, 32] := by
   unfold v_533_0
   exact fw_linear_3d_shape 1 16 64 32 (v_532_0 z) (z 653) (h_532_0 z z_) (i_78 z z_)
 #a h_533_0
 attribute [local irreducible] v_533_0
 attribute [local irreducible] s_534
 theorem r_534_0 (z : Store) : (s_534 z) 901 = (v_528_1 z) := pR (k_533 z) (pR (k_532 z) (pR (k_531 z) (pR (k_530 z) (pR (k_529 z) (w_528_1 z)))))
 #a r_534_0
 theorem r_534_1 (z : Store) : (s_534 z) 1204 = (v_531_1 z) := pR (k_533 z) (pR (k_532 z) (w_531_1 z))
 #a r_534_1
 def v_534_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_528_1 z), (v_531_1 z)]
 theorem g_534 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_529) (s_534 z) pmNode_529 1 2 798 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_529, r_534_0 z, r_534_1 z, h_528_1 z z_, h_531_1 z z_]
 #a g_534
 def s_535 (z : Store) : Store := pL [2, 3] (s_534 z) pmNode_529 1 2
 theorem t_534 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_529) (pmPeers pmNode_529) (s_534 z) pmNode_529 none = some (s_535 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_529) (s_534 z) pmNode_529).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 798 (by decide) (g_534 z z_)]
   rfl
 #a t_534
 theorem k_534 (z : Store) (tid : Tid) (h : tid ∉ [798]) : (s_535 z) tid = (s_534 z) tid := by
   unfold s_535
   dsimp only [pL, pmNode_529, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_534
 theorem w_534_0 (z : Store) : (s_535 z) 798 = v_534_0 z := by
   unfold s_535
   dsimp only [pL, pmNode_529, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_534_0, r_534_0 z, r_534_1 z] <;> rfl
 #a w_534_0
 theorem h_534_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_534_0 z).shape = [1, 16, 32] := by
   unfold v_534_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_528_1 z z_]
 #a h_534_0
 attribute [local irreducible] v_534_0
 attribute [local irreducible] s_535
 theorem r_535_0 (z : Store) : (s_535 z) 798 = (v_534_0 z) := w_534_0 z
 #a r_535_0
 theorem r_535_1 (z : Store) : (s_535 z) 656 = (z 656) := pR (k_534 z) (pR (k_533 z) (pR (k_532 z) (pR (n_528_532 z) (pR (n_512_528 z) (pR (n_0_512 z) (e_79 z))))))
 #a r_535_1
 def v_535_0 (z : Store) : Tensor := fw_linear (v_534_0 z) (z 656)
 def s_536 (z : Store) : Store := storeSet (s_535 z) [(799, fw_linear ((s_535 z) 798) ((s_535 z) 656))]
 theorem t_535 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_530) (pmPeers pmNode_530) (s_535 z) pmNode_530 none = some (s_536 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_535
 theorem k_535 (z : Store) (tid : Tid) (h : tid ∉ [799]) : (s_536 z) tid = (s_535 z) tid := by
   unfold s_536
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_535
 theorem w_535_0 (z : Store) : (s_536 z) 799 = v_535_0 z := by
   unfold s_536
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_535_0, r_535_0 z, r_535_1 z] <;> rfl
 #a w_535_0
 theorem h_535_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_535_0 z).shape = [1, 16, 64] := by
   unfold v_535_0
   exact fw_linear_3d_shape 1 16 32 64 (v_534_0 z) (z 656) (h_534_0 z z_) (i_79 z z_)
 #a h_535_0
 attribute [local irreducible] v_535_0
 attribute [local irreducible] s_536
 theorem n_532_536 (z : Store) (tid : Tid) (h : tid ∉ ([694, 795, 798, 799] : List Tid)) : (s_536 z) tid = (s_532 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_532 z) (k_533 z)) (pF _ _ _ _ _ (k_534 z) (k_535 z)) tid h
 #a n_532_536
 theorem r_536_0 (z : Store) : (s_536 z) 903 = (v_528_2 z) := pR (n_532_536 z) (pR (k_531 z) (pR (k_530 z) (pR (k_529 z) (w_528_2 z))))
 #a r_536_0
 theorem r_536_1 (z : Store) : (s_536 z) 1206 = (v_531_2 z) := pR (n_532_536 z) (w_531_2 z)
 #a r_536_1
 def v_536_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_528_2 z), (v_531_2 z)]
 theorem g_536 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_531) (s_536 z) pmNode_531 1 2 801 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_531, r_536_0 z, r_536_1 z, h_528_2 z z_, h_531_2 z z_]
 #a g_536
 def s_537 (z : Store) : Store := pL [2, 3] (s_536 z) pmNode_531 1 2
 theorem t_536 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_531) (pmPeers pmNode_531) (s_536 z) pmNode_531 none = some (s_537 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_531) (s_536 z) pmNode_531).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 801 (by decide) (g_536 z z_)]
   rfl
 #a t_536
 theorem k_536 (z : Store) (tid : Tid) (h : tid ∉ [801]) : (s_537 z) tid = (s_536 z) tid := by
   unfold s_537
   dsimp only [pL, pmNode_531, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_536
 theorem w_536_0 (z : Store) : (s_537 z) 801 = v_536_0 z := by
   unfold s_537
   dsimp only [pL, pmNode_531, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_536_0, r_536_0 z, r_536_1 z] <;> rfl
 #a w_536_0
 theorem h_536_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_536_0 z).shape = [1, 16, 32] := by
   unfold v_536_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_528_2 z z_]
 #a h_536_0
 attribute [local irreducible] v_536_0
 attribute [local irreducible] s_537
 theorem n_528_536 (z : Store) (tid : Tid) (h : tid ∉ ([899, 901, 903, 1094, 1095, 1202, 1204, 1206, 694, 795, 798, 799] : List Tid)) : (s_536 z) tid = (s_528 z) tid := by
   exact pF _ _ _ _ _ (n_528_532 z) (n_532_536 z) tid h
 #a n_528_536
 theorem r_537_0 (z : Store) : (s_537 z) 801 = (v_536_0 z) := w_536_0 z
 #a r_537_0
 theorem r_537_1 (z : Store) : (s_537 z) 659 = (z 659) := pR (k_536 z) (pR (n_528_536 z) (pR (n_512_528 z) (pR (n_0_512 z) (e_80 z))))
 #a r_537_1
 def v_537_0 (z : Store) : Tensor := fw_linear (v_536_0 z) (z 659)
 def s_538 (z : Store) : Store := storeSet (s_537 z) [(802, fw_linear ((s_537 z) 801) ((s_537 z) 659))]
 theorem t_537 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_532) (pmPeers pmNode_532) (s_537 z) pmNode_532 none = some (s_538 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_537
 theorem k_537 (z : Store) (tid : Tid) (h : tid ∉ [802]) : (s_538 z) tid = (s_537 z) tid := by
   unfold s_538
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_537
 theorem w_537_0 (z : Store) : (s_538 z) 802 = v_537_0 z := by
   unfold s_538
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_537_0, r_537_0 z, r_537_1 z] <;> rfl
 #a w_537_0
 theorem h_537_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_537_0 z).shape = [1, 16, 64] := by
   unfold v_537_0
   exact fw_linear_3d_shape 1 16 32 64 (v_536_0 z) (z 659) (h_536_0 z z_) (i_80 z z_)
 #a h_537_0
 attribute [local irreducible] v_537_0
 attribute [local irreducible] s_538
 theorem r_538_0 (z : Store) : (s_538 z) 899 = (v_528_0 z) := pR (k_537 z) (pR (k_536 z) (pR (n_532_536 z) (r_532_0 z)))
 #a r_538_0
 theorem r_538_1 (z : Store) : (s_538 z) 1202 = (v_531_0 z) := pR (k_537 z) (pR (k_536 z) (pR (n_532_536 z) (r_532_1 z)))
 #a r_538_1
 def v_538_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_528_0 z), (v_531_0 z)]
 def s_539 (z : Store) : Store := storeSet (s_538 z) [(997, allGatherPrimDimN 1 2 1 [((s_538 z) 899), ((s_538 z) 1202)])]
 theorem t_538 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_763) (pmPeers pmNode_763) (s_538 z) pmNode_763 none = some (s_539 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_538 z) pmNode_763 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_538
 theorem k_538 (z : Store) (tid : Tid) (h : tid ∉ [997]) : (s_539 z) tid = (s_538 z) tid := by
   unfold s_539
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_538
 theorem w_538_0 (z : Store) : (s_539 z) 997 = v_538_0 z := by
   unfold s_539
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_538_0, r_538_0 z, r_538_1 z] <;> rfl
 #a w_538_0
 theorem h_538_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_538_0 z).shape = [1, 16, 64] := by
   unfold v_538_0
   exact allGatherPrimDimN_shape 1 2 [(v_528_0 z), (v_531_0 z)] [1, 8, 64] (h_528_0 z z_)
 #a h_538_0
 attribute [local irreducible] v_538_0
 attribute [local irreducible] s_539
 theorem r_539_0 (z : Store) : (s_539 z) 997 = (v_538_0 z) := w_538_0 z
 #a r_539_0
 theorem r_539_1 (z : Store) : (s_539 z) 956 = (z 956) := pR (k_538 z) (pR (k_537 z) (pR (k_536 z) (pR (n_528_536 z) (pR (n_512_528 z) (pR (n_0_512 z) (e_81 z))))))
 #a r_539_1
 def v_539_0 (z : Store) : Tensor := fw_linear (v_538_0 z) (z 956)
 def s_540 (z : Store) : Store := storeSet (s_539 z) [(1098, fw_linear ((s_539 z) 997) ((s_539 z) 956))]
 theorem t_539 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_764) (pmPeers pmNode_764) (s_539 z) pmNode_764 none = some (s_540 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_539
 theorem k_539 (z : Store) (tid : Tid) (h : tid ∉ [1098]) : (s_540 z) tid = (s_539 z) tid := by
   unfold s_540
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_539
 theorem w_539_0 (z : Store) : (s_540 z) 1098 = v_539_0 z := by
   unfold s_540
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_539_0, r_539_0 z, r_539_1 z] <;> rfl
 #a w_539_0
 theorem h_539_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_539_0 z).shape = [1, 16, 32] := by
   unfold v_539_0
   exact fw_linear_3d_shape 1 16 64 32 (v_538_0 z) (z 956) (h_538_0 z z_) (i_81 z z_)
 #a h_539_0
 attribute [local irreducible] v_539_0
 attribute [local irreducible] s_540
 theorem n_536_540 (z : Store) (tid : Tid) (h : tid ∉ ([801, 802, 997, 1098] : List Tid)) : (s_540 z) tid = (s_536 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_536 z) (k_537 z)) (pF _ _ _ _ _ (k_538 z) (k_539 z)) tid h
 #a n_536_540
 theorem r_540_0 (z : Store) : (s_540 z) 795 = (v_533_0 z) := pR (n_536_540 z) (pR (k_535 z) (pR (k_534 z) (w_533_0 z)))
 #a r_540_0
 theorem r_540_1 (z : Store) : (s_540 z) 1098 = (v_539_0 z) := w_539_0 z
 #a r_540_1
 def v_540_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_533_0 z), (v_539_0 z)]
 theorem g_540 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_533) (s_540 z) pmNode_533 2 1 804 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_533, r_540_0 z, r_540_1 z, h_533_0 z z_, h_539_0 z z_]
 #a g_540
 def s_541 (z : Store) : Store := pL [2, 3] (s_540 z) pmNode_533 2 1
 theorem t_540 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_533) (pmPeers pmNode_533) (s_540 z) pmNode_533 none = some (s_541 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_533) (s_540 z) pmNode_533).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 804 (by decide) (g_540 z z_)]
   rfl
 #a t_540
 theorem k_540 (z : Store) (tid : Tid) (h : tid ∉ [804]) : (s_541 z) tid = (s_540 z) tid := by
   unfold s_541
   dsimp only [pL, pmNode_533, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_540
 theorem w_540_0 (z : Store) : (s_541 z) 804 = v_540_0 z := by
   unfold s_541
   dsimp only [pL, pmNode_533, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_540_0, r_540_0 z, r_540_1 z] <;> rfl
 #a w_540_0
 theorem h_540_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_540_0 z).shape = [1, 8, 64] := by
   unfold v_540_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_533_0 z z_]
 #a h_540_0
 attribute [local irreducible] v_540_0
 attribute [local irreducible] s_541
 theorem r_541_0 (z : Store) : (s_541 z) 804 = (v_540_0 z) := w_540_0 z
 #a r_541_0
 def v_541_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_540_0 z)
 def s_542 (z : Store) : Store := storeSet (s_541 z) [(805, fw_view [1, 8, 4, 16] ((s_541 z) 804))]
 theorem t_541 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_534) (pmPeers pmNode_534) (s_541 z) pmNode_534 none = some (s_542 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_541
 theorem k_541 (z : Store) (tid : Tid) (h : tid ∉ [805]) : (s_542 z) tid = (s_541 z) tid := by
   unfold s_542
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_541
 theorem w_541_0 (z : Store) : (s_542 z) 805 = v_541_0 z := by
   unfold s_542
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_541_0, r_541_0 z] <;> rfl
 #a w_541_0
 theorem h_541_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_541_0 z).shape = [1, 8, 4, 16] := by
   unfold v_541_0
   rfl
 #a h_541_0
 attribute [local irreducible] v_541_0
 attribute [local irreducible] s_542
 record_prefix_opacity v_533_0 s_534 v_534_0 s_535 v_535_0 s_536 v_536_0 s_537 v_537_0 s_538 v_538_0 s_539 v_539_0 s_540 v_540_0 s_541 v_541_0 s_542

 end
 end TrainVerify.Denote.RuntimeWorld
