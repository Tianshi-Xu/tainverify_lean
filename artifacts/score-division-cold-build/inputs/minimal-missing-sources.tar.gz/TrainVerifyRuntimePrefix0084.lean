import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0083
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_665_0 (z : Store) : (s_665 z) 866 = (v_659_0 z) := pR (k_664 z) (pR (k_663 z) (pR (k_662 z) (r_662_0 z)))
 #a r_665_0
 theorem r_665_1 (z : Store) : (s_665 z) 1169 = (v_661_0 z) := pR (k_664 z) (pR (k_663 z) (pR (k_662 z) (r_662_1 z)))
 #a r_665_1
 def v_665_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_659_0 z), (v_661_0 z)]
 theorem g_665 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_828) (s_665 z) pmNode_828 1 2 1209 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_828, r_665_0 z, r_665_1 z, h_659_0 z z_, h_661_0 z z_]
 #a g_665
 def s_666 (z : Store) : Store := pL [2, 3] (s_665 z) pmNode_828 1 2
 theorem t_665 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_828) (pmPeers pmNode_828) (s_665 z) pmNode_828 none = some (s_666 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_828) (s_665 z) pmNode_828).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1209 (by decide) (g_665 z z_)]
   rfl
 #a t_665
 theorem k_665 (z : Store) (tid : Tid) (h : tid ∉ [1209]) : (s_666 z) tid = (s_665 z) tid := by
   unfold s_666
   dsimp only [pL, pmNode_828, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_665
 theorem w_665_0 (z : Store) : (s_666 z) 1209 = v_665_0 z := by
   unfold s_666
   dsimp only [pL, pmNode_828, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_665_0, r_665_0 z, r_665_1 z] <;> rfl
 #a w_665_0
 theorem h_665_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_665_0 z).shape = [1, 16, 32] := by
   unfold v_665_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_659_0 z z_]
 #a h_665_0
 attribute [local irreducible] v_665_0
 attribute [local irreducible] s_666
 theorem r_666_0 (z : Store) : (s_666 z) 1209 = (v_665_0 z) := w_665_0 z
 #a r_666_0
 theorem r_666_1 (z : Store) : (s_666 z) 1211 = (v_651_0 z) := pR (k_665 z) (pR (k_664 z) (pR (n_656_664 z) (pR (n_652_656 z) (w_651_0 z))))
 #a r_666_1
 def v_666_0 (z : Store) : Tensor := tensorSum [(v_665_0 z), (v_651_0 z)]
 def s_667 (z : Store) : Store := storeSet (s_666 z) [(1166, tensorSum [((s_666 z) 1209), ((s_666 z) 1211)])]
 theorem t_666 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_829) (pmPeers pmNode_829) (s_666 z) pmNode_829 none = some (s_667 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_666
 theorem k_666 (z : Store) (tid : Tid) (h : tid ∉ [1166]) : (s_667 z) tid = (s_666 z) tid := by
   unfold s_667
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_666
 theorem w_666_0 (z : Store) : (s_667 z) 1166 = v_666_0 z := by
   unfold s_667
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_666_0, r_666_0 z, r_666_1 z] <;> rfl
 #a w_666_0
 theorem h_666_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_666_0 z).shape = [1, 16, 32] := by
   unfold v_666_0
   rw [tensorSum_shape]
   exact h_665_0 z z_
 #a h_666_0
 attribute [local irreducible] v_666_0
 attribute [local irreducible] s_667
 theorem r_667_0 (z : Store) : (s_667 z) 1166 = (v_666_0 z) := w_666_0 z
 #a r_667_0
 theorem r_667_1 (z : Store) : (s_667 z) 1161 = (v_525_1 z) := pR (k_666 z) (pR (k_665 z) (pR (k_664 z) (pR (n_656_664 z) (pR (n_640_656 z) (pR (n_608_640 z) (pR (n_604_608 z) (r_604_0 z)))))))
 #a r_667_1
 theorem r_667_2 (z : Store) : (s_667 z) 1162 = (v_603_0 z) := pR (k_666 z) (pR (k_665 z) (pR (k_664 z) (pR (n_656_664 z) (pR (n_640_656 z) (pR (n_608_640 z) (pR (n_604_608 z) (r_604_1 z)))))))
 #a r_667_2
 def v_667_0 (z : Store) : Tensor := (bw_add2 (v_666_0 z) (v_525_1 z) (v_603_0 z)).1
 def v_667_1 (z : Store) : Tensor := (bw_add2 (v_666_0 z) (v_525_1 z) (v_603_0 z)).2
 def s_668 (z : Store) : Store := storeSet (s_667 z) [(1164, (bw_add2 ((s_667 z) 1166) ((s_667 z) 1161) ((s_667 z) 1162)).1), (1165, (bw_add2 ((s_667 z) 1166) ((s_667 z) 1161) ((s_667 z) 1162)).2)]
 theorem t_667 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_830) (pmPeers pmNode_830) (s_667 z) pmNode_830 none = some (s_668 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_667
 theorem k_667 (z : Store) (tid : Tid) (h : tid ∉ [1164, 1165]) : (s_668 z) tid = (s_667 z) tid := by
   unfold s_668
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_667
 theorem w_667_0 (z : Store) : (s_668 z) 1164 = v_667_0 z := by
   unfold s_668
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_667_0, r_667_0 z, r_667_1 z, r_667_2 z] <;> rfl
 #a w_667_0
 theorem h_667_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_667_0 z).shape = [1, 16, 32] := by
   unfold v_667_0
   exact h_525_1 z z_
 #a h_667_0
 attribute [local irreducible] v_667_0
 theorem w_667_1 (z : Store) : (s_668 z) 1165 = v_667_1 z := by
   unfold s_668
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_667_1, r_667_0 z, r_667_1 z, r_667_2 z] <;> rfl
 #a w_667_1
 theorem h_667_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_667_1 z).shape = [1, 16, 32] := by
   unfold v_667_1
   exact h_603_0 z z_
 #a h_667_1
 attribute [local irreducible] v_667_1
 attribute [local irreducible] s_668
 theorem r_668_0 (z : Store) : (s_668 z) 862 = (v_664_1 z) := pR (k_667 z) (pR (k_666 z) (pR (k_665 z) (w_664_1 z)))
 #a r_668_0
 theorem r_668_1 (z : Store) : (s_668 z) 1165 = (v_667_1 z) := w_667_1 z
 #a r_668_1
 def v_668_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 0 [(v_664_1 z), (v_667_1 z)]
 def s_669 (z : Store) : Store := storeSet (s_668 z) [(690, allGatherPrimDimN 2 2 0 [((s_668 z) 862), ((s_668 z) 1165)])]
 theorem t_668 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_595) (pmPeers pmNode_595) (s_668 z) pmNode_595 none = some (s_669 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_668 z) pmNode_595 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_668
 theorem k_668 (z : Store) (tid : Tid) (h : tid ∉ [690]) : (s_669 z) tid = (s_668 z) tid := by
   unfold s_669
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_668
 theorem w_668_0 (z : Store) : (s_669 z) 690 = v_668_0 z := by
   unfold s_669
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_668_0, r_668_0 z, r_668_1 z] <;> rfl
 #a w_668_0
 theorem h_668_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_668_0 z).shape = [1, 16, 64] := by
   unfold v_668_0
   exact allGatherPrimDimN_shape 2 2 [(v_664_1 z), (v_667_1 z)] [1, 16, 32] (h_664_1 z z_)
 #a h_668_0
 attribute [local irreducible] v_668_0
 attribute [local irreducible] s_669
 theorem n_664_668 (z : Store) (tid : Tid) (h : tid ∉ ([861, 862, 1209, 1166, 1164, 1165] : List Tid)) : (s_668 z) tid = (s_664 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_664 z) (k_665 z)) (pF _ _ _ _ _ (k_666 z) (k_667 z)) tid h
 #a n_664_668
 theorem r_669_0 (z : Store) : (s_669 z) 690 = (v_668_0 z) := w_668_0 z
 #a r_669_0
 theorem r_669_1 (z : Store) : (s_669 z) 854 = (v_595_0 z) := pR (k_668 z) (pR (n_664_668 z) (pR (n_656_664 z) (pR (n_640_656 z) (pR (n_608_640 z) (pR (n_600_608 z) (pR (n_596_600 z) (r_596_0 z)))))))
 #a r_669_1
 theorem r_669_2 (z : Store) : (s_669 z) 662 = (z 662) := pR (k_668 z) (pR (n_664_668 z) (pR (n_656_664 z) (pR (n_640_656 z) (pR (n_608_640 z) (pR (n_600_608 z) (pR (n_596_600 z) (r_596_1 z)))))))
 #a r_669_2
 def v_669_0 (z : Store) : Tensor := (bw_linear (v_668_0 z) (v_595_0 z) (z 662)).1
 def v_669_1 (z : Store) : Tensor := (bw_linear (v_668_0 z) (v_595_0 z) (z 662)).2
 def s_670 (z : Store) : Store := storeSet (s_669 z) [(856, (bw_linear ((s_669 z) 690) ((s_669 z) 854) ((s_669 z) 662)).1), (663, (bw_linear ((s_669 z) 690) ((s_669 z) 854) ((s_669 z) 662)).2)]
 theorem t_669 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_596) (pmPeers pmNode_596) (s_669 z) pmNode_596 none = some (s_670 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_669
 theorem k_669 (z : Store) (tid : Tid) (h : tid ∉ [856, 663]) : (s_670 z) tid = (s_669 z) tid := by
   unfold s_670
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_669
 theorem w_669_0 (z : Store) : (s_670 z) 856 = v_669_0 z := by
   unfold s_670
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_669_0, r_669_0 z, r_669_1 z, r_669_2 z] <;> rfl
 #a w_669_0
 theorem h_669_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_669_0 z).shape = [1, 16, 32] := by
   unfold v_669_0
   exact bw_linear_3d_fst_shape 1 16 64 32 (v_668_0 z) (v_595_0 z) (z 662) (h_668_0 z z_) (h_595_0 z z_) (i_84 z z_)
 #a h_669_0
 attribute [local irreducible] v_669_0
 theorem w_669_1 (z : Store) : (s_670 z) 663 = v_669_1 z := by
   unfold s_670
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_669_1, r_669_0 z, r_669_1 z, r_669_2 z] <;> rfl
 #a w_669_1
 theorem h_669_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_669_1 z).shape = [64, 32] := by
   unfold v_669_1
   exact bw_linear_3d_snd_shape 1 16 64 32 (v_668_0 z) (v_595_0 z) (z 662) (h_668_0 z z_) (h_595_0 z z_) (i_84 z z_)
 #a h_669_1
 attribute [local irreducible] v_669_1
 attribute [local irreducible] s_670
 theorem r_670_0 (z : Store) : (s_670 z) 856 = (v_669_0 z) := w_669_0 z
 #a r_670_0
 theorem r_670_1 (z : Store) : (s_670 z) 853 = (v_594_0 z) := pR (k_669 z) (pR (k_668 z) (pR (n_664_668 z) (pR (n_656_664 z) (pR (n_640_656 z) (pR (n_608_640 z) (pR (n_600_608 z) (pR (n_596_600 z) (pR (k_595 z) (r_595_0 z)))))))))
 #a r_670_1
 def v_670_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_669_0 z)
 def s_671 (z : Store) : Store := storeSet (s_670 z) [(855, fw_view [1, 16, 2, 16] ((s_670 z) 856))]
 theorem t_670 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_597) (pmPeers pmNode_597) (s_670 z) pmNode_597 none = some (s_671 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_670
 theorem k_670 (z : Store) (tid : Tid) (h : tid ∉ [855]) : (s_671 z) tid = (s_670 z) tid := by
   unfold s_671
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_670
 theorem w_670_0 (z : Store) : (s_671 z) 855 = v_670_0 z := by
   unfold s_671
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_670_0, r_670_0 z, r_670_1 z] <;> rfl
 #a w_670_0
 theorem h_670_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_670_0 z).shape = [1, 16, 2, 16] := by
   unfold v_670_0
   rfl
 #a h_670_0
 attribute [local irreducible] v_670_0
 attribute [local irreducible] s_671
 theorem r_671_0 (z : Store) : (s_671 z) 862 = (v_664_1 z) := pR (k_670 z) (pR (k_669 z) (pR (k_668 z) (r_668_0 z)))
 #a r_671_0
 theorem r_671_1 (z : Store) : (s_671 z) 1165 = (v_667_1 z) := pR (k_670 z) (pR (k_669 z) (pR (k_668 z) (r_668_1 z)))
 #a r_671_1
 def v_671_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 1 [(v_664_1 z), (v_667_1 z)]
 def s_672 (z : Store) : Store := storeSet (s_671 z) [(993, allGatherPrimDimN 2 2 1 [((s_671 z) 862), ((s_671 z) 1165)])]
 theorem t_671 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_831) (pmPeers pmNode_831) (s_671 z) pmNode_831 none = some (s_672 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_671 z) pmNode_831 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_671
 theorem k_671 (z : Store) (tid : Tid) (h : tid ∉ [993]) : (s_672 z) tid = (s_671 z) tid := by
   unfold s_672
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_671
 theorem w_671_0 (z : Store) : (s_672 z) 993 = v_671_0 z := by
   unfold s_672
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_671_0, r_671_0 z, r_671_1 z] <;> rfl
 #a w_671_0
 theorem h_671_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_671_0 z).shape = [1, 16, 64] := by
   unfold v_671_0
   exact allGatherPrimDimN_shape 2 2 [(v_664_1 z), (v_667_1 z)] [1, 16, 32] (h_664_1 z z_)
 #a h_671_0
 attribute [local irreducible] v_671_0
 attribute [local irreducible] s_672
 theorem n_668_672 (z : Store) (tid : Tid) (h : tid ∉ ([690, 856, 663, 855, 993] : List Tid)) : (s_672 z) tid = (s_668 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_668 z) (k_669 z)) (pF _ _ _ _ _ (k_670 z) (k_671 z)) tid h
 #a n_668_672
 theorem n_664_672 (z : Store) (tid : Tid) (h : tid ∉ ([861, 862, 1209, 1166, 1164, 1165, 690, 856, 663, 855, 993] : List Tid)) : (s_672 z) tid = (s_664 z) tid := by
   exact pF _ _ _ _ _ (n_664_668 z) (n_668_672 z) tid h
 #a n_664_672
 theorem n_656_672 (z : Store) (tid : Tid) (h : tid ∉ ([994, 1173, 973, 867, 866, 665, 667, 1170, 1169, 968, 970, 906, 863, 861, 862, 1209, 1166, 1164, 1165, 690, 856, 663, 855, 993] : List Tid)) : (s_672 z) tid = (s_656 z) tid := by
   exact pF _ _ _ _ _ (n_656_664 z) (n_664_672 z) tid h
 #a n_656_672
 theorem n_640_672 (z : Store) (tid : Tid) (h : tid ∉ ([1188, 1187, 982, 882, 880, 674, 676, 879, 876, 1185, 1183, 977, 979, 1182, 1179, 908, 874, 672, 873, 1211, 1177, 975, 1176, 691, 870, 670, 994, 1173, 973, 867, 866, 665, 667, 1170, 1169, 968, 970, 906, 863, 861, 862, 1209, 1166, 1164, 1165, 690, 856, 663, 855, 993] : List Tid)) : (s_672 z) tid = (s_640 z) tid := by
   exact pF _ _ _ _ _ (n_640_656 z) (n_656_672 z) tid h
 #a n_640_672
 record_prefix_opacity v_665_0 s_666 v_666_0 s_667 v_667_0 v_667_1 s_668 v_668_0 s_669 v_669_0 v_669_1 s_670 v_670_0 s_671 v_671_0 s_672

 end
 end TrainVerify.Denote.RuntimeWorld
