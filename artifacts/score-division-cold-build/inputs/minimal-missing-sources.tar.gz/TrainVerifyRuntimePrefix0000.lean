import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 def unitSeed : Tensor := Tensor.mkShape [1] (fun _ => 1)
 def applySeeds (s : Store) (seeds : List (Tid × Tensor)) : Store := storeSet s seeds
 theorem unitSeed_shape : unitSeed.shape = [1] := rfl
 #a unitSeed_shape
 theorem unitSeed_value : valAt unitSeed 0 = 1 := rfl
 #a unitSeed_value
 theorem unitSeed_bw_sum (x : Tensor) : bw_sum unitSeed x = Tensor.mkShape x.shape (fun _ => 1) := rfl
 #a unitSeed_bw_sum
 theorem applySeeds_value (s : Store) (seeds : List (Tid × Tensor)) (tid : Tid) (v : Tensor) (hu : (seeds.map Prod.fst).Nodup) (hm : (tid, v) ∈ seeds) : applySeeds s seeds tid = v := storeSet_feed_value s seeds tid v hu hm
 #a applySeeds_value
 theorem applySeeds_frame (s : Store) (seeds : List (Tid × Tensor)) (tid : Tid) (h : tid ∉ seeds.map Prod.fst) : applySeeds s seeds tid = s tid := pS s seeds tid h
 #a applySeeds_frame
 theorem applySeeds_parameters (s : Store) (seeds : List (Tid × Tensor)) (parameters : List Tid) (hd : ∀ tid ∈ parameters, tid ∉ seeds.map Prod.fst) (tid : Tid) (hp : tid ∈ parameters) : applySeeds s seeds tid = s tid := applySeeds_frame s seeds tid (hd tid hp)
 #a applySeeds_parameters
 def smExternalSeeds : List (Tid × Tensor) := [(1320, unitSeed)]
 def smInitialWithSeeds (s : Store) : Store := applySeeds s smExternalSeeds
 def smSeededDenoteWithInputs (s : Store) : Option Store := smDenoteWithInputs (smInitialWithSeeds s)
 theorem smExternalSeeds_coverage : smExternalSeeds.map Prod.fst = [1320] := rfl
 #a smExternalSeeds_coverage
 theorem smExternalSeeds_unique : (smExternalSeeds.map Prod.fst).Nodup := by decide
 #a smExternalSeeds_unique
 theorem smInitialWithSeeds_frame (s : Store) (tid : Tid) (h : tid ∉ smExternalSeeds.map Prod.fst) : smInitialWithSeeds s tid = s tid := applySeeds_frame s smExternalSeeds tid h
 #a smInitialWithSeeds_frame
 theorem smInitialWithSeeds_seed_0 (s : Store) : smInitialWithSeeds s 1320 = unitSeed := applySeeds_value s smExternalSeeds 1320 unitSeed smExternalSeeds_unique (by simp [smExternalSeeds])
 #a smInitialWithSeeds_seed_0
 def pmExternalSeeds : List (Tid × Tensor) := [(81, unitSeed), (384, unitSeed), (687, unitSeed), (990, unitSeed)]
 def pmInitialWithSeeds (s : Store) : Store := applySeeds s pmExternalSeeds
 def pmSeededDenoteWithInputs (s : Store) : Option Store := pmDenoteWithInputs (pmInitialWithSeeds s)
 theorem pmExternalSeeds_coverage : pmExternalSeeds.map Prod.fst = [81, 384, 687, 990] := rfl
 #a pmExternalSeeds_coverage
 theorem pmExternalSeeds_unique : (pmExternalSeeds.map Prod.fst).Nodup := by decide
 #a pmExternalSeeds_unique
 theorem pmInitialWithSeeds_frame (s : Store) (tid : Tid) (h : tid ∉ pmExternalSeeds.map Prod.fst) : pmInitialWithSeeds s tid = s tid := applySeeds_frame s pmExternalSeeds tid h
 #a pmInitialWithSeeds_frame
 theorem pmInitialWithSeeds_seed_0 (s : Store) : pmInitialWithSeeds s 81 = unitSeed := applySeeds_value s pmExternalSeeds 81 unitSeed pmExternalSeeds_unique (by simp [pmExternalSeeds])
 #a pmInitialWithSeeds_seed_0
 theorem pmInitialWithSeeds_seed_1 (s : Store) : pmInitialWithSeeds s 384 = unitSeed := applySeeds_value s pmExternalSeeds 384 unitSeed pmExternalSeeds_unique (by simp [pmExternalSeeds])
 #a pmInitialWithSeeds_seed_1
 theorem pmInitialWithSeeds_seed_2 (s : Store) : pmInitialWithSeeds s 687 = unitSeed := applySeeds_value s pmExternalSeeds 687 unitSeed pmExternalSeeds_unique (by simp [pmExternalSeeds])
 #a pmInitialWithSeeds_seed_2
 theorem pmInitialWithSeeds_seed_3 (s : Store) : pmInitialWithSeeds s 990 = unitSeed := applySeeds_value s pmExternalSeeds 990 unitSeed pmExternalSeeds_unique (by simp [pmExternalSeeds])
 #a pmInitialWithSeeds_seed_3
 def pmSeededPrefixInitShapes (z : Store) : Prop := (z 16).shape = [256, 32] ∧ (z 0).shape = [16, 64] ∧ (z 319).shape = [256, 32] ∧ (z 303).shape = [16, 64] ∧ (z 1).shape = [64] ∧ (z 2).shape = [64] ∧ (z 3).shape = [64, 64] ∧ (z 304).shape = [64] ∧ (z 305).shape = [64] ∧ (z 27).shape = [32, 64] ∧ (z 30).shape = [32, 64] ∧ (z 306).shape = [64, 64] ∧ (z 330).shape = [32, 64] ∧ (z 333).shape = [32, 64] ∧ (z 4).shape = [64, 64] ∧ (z 307).shape = [64, 64] ∧ (z 5).shape = [64] ∧ (z 6).shape = [64] ∧ (z 7).shape = [256, 64] ∧ (z 8).shape = [64, 256] ∧ (z 308).shape = [64] ∧ (z 309).shape = [64] ∧ (z 310).shape = [256, 64] ∧ (z 311).shape = [64, 256] ∧ (z 9).shape = [64] ∧ (z 10).shape = [64] ∧ (z 312).shape = [64] ∧ (z 313).shape = [64] ∧ (z 47).shape = [32, 64] ∧ (z 50).shape = [64, 32] ∧ (z 53).shape = [64, 32] ∧ (z 350).shape = [32, 64] ∧ (z 353).shape = [64, 32] ∧ (z 356).shape = [64, 32] ∧ (z 56).shape = [64, 32] ∧ (z 359).shape = [64, 32] ∧ (z 11).shape = [64] ∧ (z 12).shape = [64] ∧ (z 314).shape = [64] ∧ (z 315).shape = [64] ∧ (z 63).shape = [256, 32] ∧ (z 366).shape = [256, 32] ∧ (z 13).shape = [64, 256] ∧ (z 14).shape = [64] ∧ (z 15).shape = [64] ∧ (z 316).shape = [64, 256] ∧ (z 317).shape = [64] ∧ (z 318).shape = [64] ∧ (z 72).shape = [128, 64] ∧ (z 375).shape = [128, 64] ∧ (z 622).shape = [256, 32] ∧ (z 606).shape = [16, 64] ∧ (z 925).shape = [256, 32] ∧ (z 909).shape = [16, 64] ∧ (z 607).shape = [64] ∧ (z 608).shape = [64] ∧ (z 609).shape = [64, 64] ∧ (z 910).shape = [64] ∧ (z 911).shape = [64] ∧ (z 633).shape = [32, 64] ∧ (z 636).shape = [32, 64] ∧ (z 912).shape = [64, 64] ∧ (z 936).shape = [32, 64] ∧ (z 939).shape = [32, 64] ∧ (z 610).shape = [64, 64] ∧ (z 913).shape = [64, 64] ∧ (z 611).shape = [64] ∧ (z 612).shape = [64] ∧ (z 613).shape = [256, 64] ∧ (z 614).shape = [64, 256] ∧ (z 914).shape = [64] ∧ (z 915).shape = [64] ∧ (z 916).shape = [256, 64] ∧ (z 917).shape = [64, 256] ∧ (z 615).shape = [64] ∧ (z 616).shape = [64] ∧ (z 918).shape = [64] ∧ (z 919).shape = [64] ∧ (z 653).shape = [32, 64] ∧ (z 656).shape = [64, 32] ∧ (z 659).shape = [64, 32] ∧ (z 956).shape = [32, 64] ∧ (z 959).shape = [64, 32] ∧ (z 962).shape = [64, 32] ∧ (z 662).shape = [64, 32] ∧ (z 965).shape = [64, 32] ∧ (z 617).shape = [64] ∧ (z 618).shape = [64] ∧ (z 920).shape = [64] ∧ (z 921).shape = [64] ∧ (z 669).shape = [256, 32] ∧ (z 972).shape = [256, 32] ∧ (z 619).shape = [64, 256] ∧ (z 620).shape = [64] ∧ (z 621).shape = [64] ∧ (z 922).shape = [64, 256] ∧ (z 923).shape = [64] ∧ (z 924).shape = [64] ∧ (z 678).shape = [128, 64] ∧ (z 981).shape = [128, 64]
 def s_0 (z : Store) : Store := (pmInitialWithSeeds z)
 theorem i_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 16).shape = [256, 32] := by
   exact z_.1
 #a i_0
 theorem e_0 (z : Store) : (s_0 z) 16 = z 16 := pmInitialWithSeeds_frame z 16 (by decide)
 #a e_0
 theorem i_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 0).shape = [16, 64] := by
   exact z_.2.1
 #a i_1
 theorem e_1 (z : Store) : (s_0 z) 0 = z 0 := pmInitialWithSeeds_frame z 0 (by decide)
 #a e_1
 theorem i_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 319).shape = [256, 32] := by
   exact z_.2.2.1
 #a i_2
 theorem e_2 (z : Store) : (s_0 z) 319 = z 319 := pmInitialWithSeeds_frame z 319 (by decide)
 #a e_2
 theorem i_3 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 303).shape = [16, 64] := by
   exact z_.2.2.2.1
 #a i_3
 theorem e_3 (z : Store) : (s_0 z) 303 = z 303 := pmInitialWithSeeds_frame z 303 (by decide)
 #a e_3
 theorem i_4 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 1).shape = [64] := by
   exact z_.2.2.2.2.1
 #a i_4
 theorem e_4 (z : Store) : (s_0 z) 1 = z 1 := pmInitialWithSeeds_frame z 1 (by decide)
 #a e_4
 theorem i_5 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 2).shape = [64] := by
   exact z_.2.2.2.2.2.1
 #a i_5
 theorem e_5 (z : Store) : (s_0 z) 2 = z 2 := pmInitialWithSeeds_frame z 2 (by decide)
 #a e_5
 theorem i_6 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 3).shape = [64, 64] := by
   exact z_.2.2.2.2.2.2.1
 #a i_6
 theorem e_6 (z : Store) : (s_0 z) 3 = z 3 := pmInitialWithSeeds_frame z 3 (by decide)
 #a e_6
 theorem i_7 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 304).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.1
 #a i_7
 theorem e_7 (z : Store) : (s_0 z) 304 = z 304 := pmInitialWithSeeds_frame z 304 (by decide)
 #a e_7
 theorem i_8 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 305).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.1
 #a i_8
 theorem e_8 (z : Store) : (s_0 z) 305 = z 305 := pmInitialWithSeeds_frame z 305 (by decide)
 #a e_8
 theorem i_9 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 27).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.1
 #a i_9
 theorem e_9 (z : Store) : (s_0 z) 27 = z 27 := pmInitialWithSeeds_frame z 27 (by decide)
 #a e_9
 theorem i_10 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 30).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.1
 #a i_10
 theorem e_10 (z : Store) : (s_0 z) 30 = z 30 := pmInitialWithSeeds_frame z 30 (by decide)
 #a e_10
 theorem i_11 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 306).shape = [64, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_11
 theorem e_11 (z : Store) : (s_0 z) 306 = z 306 := pmInitialWithSeeds_frame z 306 (by decide)
 #a e_11
 theorem i_12 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 330).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_12
 theorem e_12 (z : Store) : (s_0 z) 330 = z 330 := pmInitialWithSeeds_frame z 330 (by decide)
 #a e_12
 theorem i_13 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 333).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_13
 theorem e_13 (z : Store) : (s_0 z) 333 = z 333 := pmInitialWithSeeds_frame z 333 (by decide)
 #a e_13
 theorem i_14 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 4).shape = [64, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_14
 theorem e_14 (z : Store) : (s_0 z) 4 = z 4 := pmInitialWithSeeds_frame z 4 (by decide)
 #a e_14
 theorem i_15 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 307).shape = [64, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_15
 theorem e_15 (z : Store) : (s_0 z) 307 = z 307 := pmInitialWithSeeds_frame z 307 (by decide)
 #a e_15
 theorem i_16 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 5).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_16
 theorem e_16 (z : Store) : (s_0 z) 5 = z 5 := pmInitialWithSeeds_frame z 5 (by decide)
 #a e_16
 theorem i_17 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 6).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_17
 theorem e_17 (z : Store) : (s_0 z) 6 = z 6 := pmInitialWithSeeds_frame z 6 (by decide)
 #a e_17
 theorem i_18 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 7).shape = [256, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_18
 theorem e_18 (z : Store) : (s_0 z) 7 = z 7 := pmInitialWithSeeds_frame z 7 (by decide)
 #a e_18
 theorem i_19 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 8).shape = [64, 256] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_19
 theorem e_19 (z : Store) : (s_0 z) 8 = z 8 := pmInitialWithSeeds_frame z 8 (by decide)
 #a e_19
 theorem i_20 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 308).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_20
 theorem e_20 (z : Store) : (s_0 z) 308 = z 308 := pmInitialWithSeeds_frame z 308 (by decide)
 #a e_20
 theorem i_21 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 309).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_21
 theorem e_21 (z : Store) : (s_0 z) 309 = z 309 := pmInitialWithSeeds_frame z 309 (by decide)
 #a e_21
 theorem i_22 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 310).shape = [256, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_22
 theorem e_22 (z : Store) : (s_0 z) 310 = z 310 := pmInitialWithSeeds_frame z 310 (by decide)
 #a e_22
 theorem i_23 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 311).shape = [64, 256] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_23
 theorem e_23 (z : Store) : (s_0 z) 311 = z 311 := pmInitialWithSeeds_frame z 311 (by decide)
 #a e_23
 theorem i_24 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 9).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_24
 theorem e_24 (z : Store) : (s_0 z) 9 = z 9 := pmInitialWithSeeds_frame z 9 (by decide)
 #a e_24
 theorem i_25 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 10).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_25
 theorem e_25 (z : Store) : (s_0 z) 10 = z 10 := pmInitialWithSeeds_frame z 10 (by decide)
 #a e_25
 end
 end TrainVerify.Denote.RuntimeWorld
