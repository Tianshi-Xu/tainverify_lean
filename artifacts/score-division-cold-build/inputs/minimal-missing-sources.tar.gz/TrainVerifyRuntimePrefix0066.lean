import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0065
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_518_0 (z : Store) : (s_518 z) 1082 = (v_517_0 z) := w_517_0 z
 #a r_518_0
 def v_518_0 (z : Store) : Tensor := fw_gelu (v_517_0 z)
 def s_519 (z : Store) : Store := storeSet (s_518 z) [(1084, fw_gelu ((s_518 z) 1082))]
 theorem t_518 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_755) (pmPeers pmNode_755) (s_518 z) pmNode_755 none = some (s_519 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_518
 theorem k_518 (z : Store) (tid : Tid) (h : tid ∉ [1084]) : (s_519 z) tid = (s_518 z) tid := by
   unfold s_519
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_518
 theorem w_518_0 (z : Store) : (s_519 z) 1084 = v_518_0 z := by
   unfold s_519
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_518_0, r_518_0 z] <;> rfl
 #a w_518_0
 theorem h_518_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_518_0 z).shape = [1, 8, 256] := by
   unfold v_518_0
   exact h_517_0 z z_
 #a h_518_0
 attribute [local irreducible] v_518_0
 attribute [local irreducible] s_519
 theorem r_519_0 (z : Store) : (s_519 z) 1084 = (v_518_0 z) := w_518_0 z
 #a r_519_0
 theorem r_519_1 (z : Store) : (s_519 z) 917 = (z 917) := pR (k_518 z) (pR (k_517 z) (pR (k_516 z) (pR (n_512_516 z) (pR (n_0_512 z) (e_73 z)))))
 #a r_519_1
 def v_519_0 (z : Store) : Tensor := fw_linear (v_518_0 z) (z 917)
 def s_520 (z : Store) : Store := storeSet (s_519 z) [(1086, fw_linear ((s_519 z) 1084) ((s_519 z) 917))]
 theorem t_519 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_756) (pmPeers pmNode_756) (s_519 z) pmNode_756 none = some (s_520 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_519
 theorem k_519 (z : Store) (tid : Tid) (h : tid ∉ [1086]) : (s_520 z) tid = (s_519 z) tid := by
   unfold s_520
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_519
 theorem w_519_0 (z : Store) : (s_520 z) 1086 = v_519_0 z := by
   unfold s_520
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_519_0, r_519_0 z, r_519_1 z] <;> rfl
 #a w_519_0
 theorem h_519_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_519_0 z).shape = [1, 8, 64] := by
   unfold v_519_0
   exact fw_linear_3d_shape 1 8 256 64 (v_518_0 z) (z 917) (h_518_0 z z_) (i_73 z z_)
 #a h_519_0
 attribute [local irreducible] v_519_0
 attribute [local irreducible] s_520
 theorem n_516_520 (z : Store) (tid : Tid) (h : tid ∉ ([1079, 1082, 1084, 1086] : List Tid)) : (s_520 z) tid = (s_516 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_516 z) (k_517 z)) (pF _ _ _ _ _ (k_518 z) (k_519 z)) tid h
 #a n_516_520
 theorem r_520_0 (z : Store) : (s_520 z) 783 = (v_514_0 z) := pR (n_516_520 z) (pR (k_515 z) (w_514_0 z))
 #a r_520_0
 theorem r_520_1 (z : Store) : (s_520 z) 1086 = (v_519_0 z) := w_519_0 z
 #a r_520_1
 def v_520_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_514_0 z), (v_519_0 z)]
 theorem g_520 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_521) (s_520 z) pmNode_521 1 2 786 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_521, r_520_0 z, r_520_1 z, h_514_0 z z_, h_519_0 z z_]
 #a g_520
 def s_521 (z : Store) : Store := pL [2, 3] (s_520 z) pmNode_521 1 2
 theorem t_520 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_521) (pmPeers pmNode_521) (s_520 z) pmNode_521 none = some (s_521 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_521) (s_520 z) pmNode_521).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 786 (by decide) (g_520 z z_)]
   rfl
 #a t_520
 theorem k_520 (z : Store) (tid : Tid) (h : tid ∉ [786]) : (s_521 z) tid = (s_520 z) tid := by
   unfold s_521
   dsimp only [pL, pmNode_521, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_520
 theorem w_520_0 (z : Store) : (s_521 z) 786 = v_520_0 z := by
   unfold s_521
   dsimp only [pL, pmNode_521, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_520_0, r_520_0 z, r_520_1 z] <;> rfl
 #a w_520_0
 theorem h_520_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_520_0 z).shape = [1, 16, 32] := by
   unfold v_520_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_514_0 z z_]
 #a h_520_0
 attribute [local irreducible] v_520_0
 attribute [local irreducible] s_521
 theorem n_512_520 (z : Store) (tid : Tid) (h : tid ∉ ([779, 781, 783, 1078, 1079, 1082, 1084, 1086] : List Tid)) : (s_520 z) tid = (s_512 z) tid := by
   exact pF _ _ _ _ _ (n_512_516 z) (n_516_520 z) tid h
 #a n_512_520
 theorem r_521_0 (z : Store) : (s_521 z) 785 = (v_506_1 z) := pR (k_520 z) (pR (n_512_520 z) (pR (n_508_512 z) (pR (k_507 z) (w_506_1 z))))
 #a r_521_0
 theorem r_521_1 (z : Store) : (s_521 z) 786 = (v_520_0 z) := w_520_0 z
 #a r_521_1
 def v_521_0 (z : Store) : Tensor := elemwiseAdd (v_506_1 z) (v_520_0 z)
 def s_522 (z : Store) : Store := storeSet (s_521 z) [(787, elemwiseAdd ((s_521 z) 785) ((s_521 z) 786))]
 theorem t_521 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_522) (pmPeers pmNode_522) (s_521 z) pmNode_522 none = some (s_522 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_521
 theorem k_521 (z : Store) (tid : Tid) (h : tid ∉ [787]) : (s_522 z) tid = (s_521 z) tid := by
   unfold s_522
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_521
 theorem w_521_0 (z : Store) : (s_522 z) 787 = v_521_0 z := by
   unfold s_522
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_521_0, r_521_0 z, r_521_1 z] <;> rfl
 #a w_521_0
 theorem h_521_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_521_0 z).shape = [1, 16, 32] := by
   unfold v_521_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_506_1 z z_, h_520_0 z z_]
 #a h_521_0
 attribute [local irreducible] v_521_0
 attribute [local irreducible] s_522
 theorem r_522_0 (z : Store) : (s_522 z) 787 = (v_521_0 z) := w_521_0 z
 #a r_522_0
 def v_522_0 (z : Store) : Tensor := (v_521_0 z)
 def v_522_1 (z : Store) : Tensor := (v_521_0 z)
 def s_523 (z : Store) : Store := storeSet (s_522 z) [(897, ((s_522 z) 787)), (858, ((s_522 z) 787))]
 theorem t_522 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_523) (pmPeers pmNode_523) (s_522 z) pmNode_523 none = some (s_523 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_522
 theorem k_522 (z : Store) (tid : Tid) (h : tid ∉ [897, 858]) : (s_523 z) tid = (s_522 z) tid := by
   unfold s_523
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_522
 theorem w_522_0 (z : Store) : (s_523 z) 897 = v_522_0 z := by
   unfold s_523
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_522_0, r_522_0 z] <;> rfl
 #a w_522_0
 theorem h_522_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_522_0 z).shape = [1, 16, 32] := by
   unfold v_522_0
   exact h_521_0 z z_
 #a h_522_0
 attribute [local irreducible] v_522_0
 theorem w_522_1 (z : Store) : (s_523 z) 858 = v_522_1 z := by
   unfold s_523
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_522_1, r_522_0 z] <;> rfl
 #a w_522_1
 theorem h_522_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_522_1 z).shape = [1, 16, 32] := by
   unfold v_522_1
   exact h_521_0 z z_
 #a h_522_1
 attribute [local irreducible] v_522_1
 attribute [local irreducible] s_523
 theorem r_523_0 (z : Store) : (s_523 z) 783 = (v_514_0 z) := pR (k_522 z) (pR (k_521 z) (pR (k_520 z) (r_520_0 z)))
 #a r_523_0
 theorem r_523_1 (z : Store) : (s_523 z) 1086 = (v_519_0 z) := pR (k_522 z) (pR (k_521 z) (pR (k_520 z) (r_520_1 z)))
 #a r_523_1
 def v_523_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_514_0 z), (v_519_0 z)]
 theorem g_523 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_757) (s_523 z) pmNode_757 1 2 1089 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_757, r_523_0 z, r_523_1 z, h_514_0 z z_, h_519_0 z z_]
 #a g_523
 def s_524 (z : Store) : Store := pL [2, 3] (s_523 z) pmNode_757 1 2
 theorem t_523 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_757) (pmPeers pmNode_757) (s_523 z) pmNode_757 none = some (s_524 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_757) (s_523 z) pmNode_757).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1089 (by decide) (g_523 z z_)]
   rfl
 #a t_523
 theorem k_523 (z : Store) (tid : Tid) (h : tid ∉ [1089]) : (s_524 z) tid = (s_523 z) tid := by
   unfold s_524
   dsimp only [pL, pmNode_757, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_523
 theorem w_523_0 (z : Store) : (s_524 z) 1089 = v_523_0 z := by
   unfold s_524
   dsimp only [pL, pmNode_757, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_523_0, r_523_0 z, r_523_1 z] <;> rfl
 #a w_523_0
 theorem h_523_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_523_0 z).shape = [1, 16, 32] := by
   unfold v_523_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_514_0 z z_]
 #a h_523_0
 attribute [local irreducible] v_523_0
 attribute [local irreducible] s_524
 theorem n_520_524 (z : Store) (tid : Tid) (h : tid ∉ ([786, 787, 897, 858, 1089] : List Tid)) : (s_524 z) tid = (s_520 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_520 z) (k_521 z)) (pF _ _ _ _ _ (k_522 z) (k_523 z)) tid h
 #a n_520_524
 theorem r_524_0 (z : Store) : (s_524 z) 1088 = (v_509_1 z) := pR (n_520_524 z) (pR (n_512_520 z) (pR (k_511 z) (pR (k_510 z) (w_509_1 z))))
 #a r_524_0
 theorem r_524_1 (z : Store) : (s_524 z) 1089 = (v_523_0 z) := w_523_0 z
 #a r_524_1
 def v_524_0 (z : Store) : Tensor := elemwiseAdd (v_509_1 z) (v_523_0 z)
 def s_525 (z : Store) : Store := storeSet (s_524 z) [(1090, elemwiseAdd ((s_524 z) 1088) ((s_524 z) 1089))]
 theorem t_524 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_758) (pmPeers pmNode_758) (s_524 z) pmNode_758 none = some (s_525 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_524
 theorem k_524 (z : Store) (tid : Tid) (h : tid ∉ [1090]) : (s_525 z) tid = (s_524 z) tid := by
   unfold s_525
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_524
 theorem w_524_0 (z : Store) : (s_525 z) 1090 = v_524_0 z := by
   unfold s_525
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_524_0, r_524_0 z, r_524_1 z] <;> rfl
 #a w_524_0
 theorem h_524_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_524_0 z).shape = [1, 16, 32] := by
   unfold v_524_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_509_1 z z_, h_523_0 z z_]
 #a h_524_0
 attribute [local irreducible] v_524_0
 attribute [local irreducible] s_525
 theorem r_525_0 (z : Store) : (s_525 z) 1090 = (v_524_0 z) := w_524_0 z
 #a r_525_0
 def v_525_0 (z : Store) : Tensor := (v_524_0 z)
 def v_525_1 (z : Store) : Tensor := (v_524_0 z)
 def s_526 (z : Store) : Store := storeSet (s_525 z) [(1200, ((s_525 z) 1090)), (1161, ((s_525 z) 1090))]
 theorem t_525 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_759) (pmPeers pmNode_759) (s_525 z) pmNode_759 none = some (s_526 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_525
 theorem k_525 (z : Store) (tid : Tid) (h : tid ∉ [1200, 1161]) : (s_526 z) tid = (s_525 z) tid := by
   unfold s_526
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_525
 theorem w_525_0 (z : Store) : (s_526 z) 1200 = v_525_0 z := by
   unfold s_526
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_525_0, r_525_0 z] <;> rfl
 #a w_525_0
 theorem h_525_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_525_0 z).shape = [1, 16, 32] := by
   unfold v_525_0
   exact h_524_0 z z_
 #a h_525_0
 attribute [local irreducible] v_525_0
 theorem w_525_1 (z : Store) : (s_526 z) 1161 = v_525_1 z := by
   unfold s_526
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_525_1, r_525_0 z] <;> rfl
 #a w_525_1
 theorem h_525_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_525_1 z).shape = [1, 16, 32] := by
   unfold v_525_1
   exact h_524_0 z z_
 #a h_525_1
 attribute [local irreducible] v_525_1
 attribute [local irreducible] s_526
 record_prefix_opacity v_518_0 s_519 v_519_0 s_520 v_520_0 s_521 v_521_0 s_522 v_522_0 v_522_1 s_523 v_523_0 s_524 v_524_0 s_525 v_525_0 v_525_1 s_526

 end
 end TrainVerify.Denote.RuntimeWorld
