import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0071
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_570_0 (z : Store) : (s_570 z) 828 = (v_566_0 z) := pR (k_569 z) (pR (k_568 z) (pR (k_567 z) (w_566_0 z)))
 #a r_570_0
 theorem r_570_1 (z : Store) : (s_570 z) 1131 = (v_569_0 z) := w_569_0 z
 #a r_570_1
 def v_570_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_566_0 z), (v_569_0 z)]
 theorem g_570 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_546) (s_570 z) pmNode_546 2 1 830 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_546, r_570_0 z, r_570_1 z, h_566_0 z z_, h_569_0 z z_]
 #a g_570
 def s_571 (z : Store) : Store := pL [2, 3] (s_570 z) pmNode_546 2 1
 theorem t_570 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_546) (pmPeers pmNode_546) (s_570 z) pmNode_546 none = some (s_571 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_546) (s_570 z) pmNode_546).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 830 (by decide) (g_570 z z_)]
   rfl
 #a t_570
 theorem k_570 (z : Store) (tid : Tid) (h : tid ∉ [830]) : (s_571 z) tid = (s_570 z) tid := by
   unfold s_571
   dsimp only [pL, pmNode_546, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_570
 theorem w_570_0 (z : Store) : (s_571 z) 830 = v_570_0 z := by
   unfold s_571
   dsimp only [pL, pmNode_546, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_570_0, r_570_0 z, r_570_1 z] <;> rfl
 #a w_570_0
 theorem h_570_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_570_0 z).shape = [1, 2, 16, 16] := by
   unfold v_570_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_566_0 z z_]
 #a h_570_0
 attribute [local irreducible] v_570_0
 attribute [local irreducible] s_571
 theorem n_560_568 (z : Store) (tid : Tid) (h : tid ∉ ([1119, 1120, 1123, 1124, 824, 825, 828, 1127] : List Tid)) : (s_568 z) tid = (s_560 z) tid := by
   exact pF _ _ _ _ _ (n_560_564 z) (n_564_568 z) tid h
 #a n_560_568
 theorem n_552_560 (z : Store) (tid : Tid) (h : tid ∉ ([1111, 1112, 1115, 1116, 816, 817, 820, 821] : List Tid)) : (s_560 z) tid = (s_552 z) tid := by
   exact pF _ _ _ _ _ (n_552_556 z) (n_556_560 z) tid h
 #a n_552_560
 theorem r_571_0 (z : Store) : (s_571 z) 809 = (v_549_0 z) := pR (k_570 z) (pR (k_569 z) (pR (k_568 z) (pR (n_560_568 z) (pR (n_552_560 z) (pR (k_551 z) (pR (k_550 z) (w_549_0 z)))))))
 #a r_571_0
 theorem r_571_1 (z : Store) : (s_571 z) 830 = (v_570_0 z) := w_570_0 z
 #a r_571_1
 def v_571_0 (z : Store) : Tensor := fw_matmul (v_549_0 z) (v_570_0 z)
 def s_572 (z : Store) : Store := storeSet (s_571 z) [(831, fw_matmul ((s_571 z) 809) ((s_571 z) 830))]
 theorem t_571 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_547) (pmPeers pmNode_547) (s_571 z) pmNode_547 none = some (s_572 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_571
 theorem k_571 (z : Store) (tid : Tid) (h : tid ∉ [831]) : (s_572 z) tid = (s_571 z) tid := by
   unfold s_572
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_571
 theorem w_571_0 (z : Store) : (s_572 z) 831 = v_571_0 z := by
   unfold s_572
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_571_0, r_571_0 z, r_571_1 z] <;> rfl
 #a w_571_0
 theorem h_571_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_571_0 z).shape = [1, 2, 16, 16] := by
   unfold v_571_0
   unfold fw_matmul batchedMatmul
   rw [h_549_0 z z_, h_570_0 z z_]
   rfl
 #a h_571_0
 attribute [local irreducible] v_571_0
 attribute [local irreducible] s_572
 theorem r_572_0 (z : Store) : (s_572 z) 828 = (v_566_0 z) := pR (k_571 z) (pR (k_570 z) (r_570_0 z))
 #a r_572_0
 theorem r_572_1 (z : Store) : (s_572 z) 1131 = (v_569_0 z) := pR (k_571 z) (pR (k_570 z) (r_570_1 z))
 #a r_572_1
 def v_572_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_566_0 z), (v_569_0 z)]
 theorem g_572 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_782) (s_572 z) pmNode_782 2 1 1133 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_782, r_572_0 z, r_572_1 z, h_566_0 z z_, h_569_0 z z_]
 #a g_572
 def s_573 (z : Store) : Store := pL [2, 3] (s_572 z) pmNode_782 2 1
 theorem t_572 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_782) (pmPeers pmNode_782) (s_572 z) pmNode_782 none = some (s_573 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_782) (s_572 z) pmNode_782).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1133 (by decide) (g_572 z z_)]
   rfl
 #a t_572
 theorem k_572 (z : Store) (tid : Tid) (h : tid ∉ [1133]) : (s_573 z) tid = (s_572 z) tid := by
   unfold s_573
   dsimp only [pL, pmNode_782, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_572
 theorem w_572_0 (z : Store) : (s_573 z) 1133 = v_572_0 z := by
   unfold s_573
   dsimp only [pL, pmNode_782, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_572_0, r_572_0 z, r_572_1 z] <;> rfl
 #a w_572_0
 theorem h_572_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_572_0 z).shape = [1, 2, 16, 16] := by
   unfold v_572_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_566_0 z z_]
 #a h_572_0
 attribute [local irreducible] v_572_0
 attribute [local irreducible] s_573
 theorem n_568_572 (z : Store) (tid : Tid) (h : tid ∉ ([1128, 1131, 830, 831] : List Tid)) : (s_572 z) tid = (s_568 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_568 z) (k_569 z)) (pF _ _ _ _ _ (k_570 z) (k_571 z)) tid h
 #a n_568_572
 theorem r_573_0 (z : Store) : (s_573 z) 1112 = (v_553_0 z) := pR (k_572 z) (pR (n_568_572 z) (pR (n_560_568 z) (pR (n_556_560 z) (pR (k_555 z) (pR (k_554 z) (w_553_0 z))))))
 #a r_573_0
 theorem r_573_1 (z : Store) : (s_573 z) 1133 = (v_572_0 z) := w_572_0 z
 #a r_573_1
 def v_573_0 (z : Store) : Tensor := fw_matmul (v_553_0 z) (v_572_0 z)
 def s_574 (z : Store) : Store := storeSet (s_573 z) [(1134, fw_matmul ((s_573 z) 1112) ((s_573 z) 1133))]
 theorem t_573 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_783) (pmPeers pmNode_783) (s_573 z) pmNode_783 none = some (s_574 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_573
 theorem k_573 (z : Store) (tid : Tid) (h : tid ∉ [1134]) : (s_574 z) tid = (s_573 z) tid := by
   unfold s_574
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_573
 theorem w_573_0 (z : Store) : (s_574 z) 1134 = v_573_0 z := by
   unfold s_574
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_573_0, r_573_0 z, r_573_1 z] <;> rfl
 #a w_573_0
 theorem h_573_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_573_0 z).shape = [1, 2, 16, 16] := by
   unfold v_573_0
   unfold fw_matmul batchedMatmul
   rw [h_553_0 z z_, h_572_0 z z_]
   rfl
 #a h_573_0
 attribute [local irreducible] v_573_0
 attribute [local irreducible] s_574
 theorem r_574_0 (z : Store) : (s_574 z) 831 = (v_571_0 z) := pR (k_573 z) (pR (k_572 z) (w_571_0 z))
 #a r_574_0
 theorem r_574_1 (z : Store) : (s_574 z) 1134 = (v_573_0 z) := w_573_0 z
 #a r_574_1
 def v_574_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_571_0 z), (v_573_0 z)]
 theorem g_574 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_548) (s_574 z) pmNode_548 1 3 834 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_548, r_574_0 z, r_574_1 z, h_571_0 z z_, h_573_0 z z_]
 #a g_574
 def s_575 (z : Store) : Store := pL [2, 3] (s_574 z) pmNode_548 1 3
 theorem t_574 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_548) (pmPeers pmNode_548) (s_574 z) pmNode_548 none = some (s_575 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_548) (s_574 z) pmNode_548).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 834 (by decide) (g_574 z z_)]
   rfl
 #a t_574
 theorem k_574 (z : Store) (tid : Tid) (h : tid ∉ [834]) : (s_575 z) tid = (s_574 z) tid := by
   unfold s_575
   dsimp only [pL, pmNode_548, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_574
 theorem w_574_0 (z : Store) : (s_575 z) 834 = v_574_0 z := by
   unfold s_575
   dsimp only [pL, pmNode_548, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_574_0, r_574_0 z, r_574_1 z] <;> rfl
 #a w_574_0
 theorem h_574_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_574_0 z).shape = [1, 4, 16, 8] := by
   unfold v_574_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_571_0 z z_]
 #a h_574_0
 attribute [local irreducible] v_574_0
 attribute [local irreducible] s_575
 theorem r_575_0 (z : Store) : (s_575 z) 834 = (v_574_0 z) := w_574_0 z
 #a r_575_0
 def v_575_0 (z : Store) : Tensor := fw_div ((4 : Nat) : Scalar) (v_574_0 z)
 def s_576 (z : Store) : Store := storeSet (s_575 z) [(835, fw_div ((4 : Nat) : Scalar) ((s_575 z) 834))]
 theorem t_575 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_549) (pmPeers pmNode_549) (s_575 z) pmNode_549 none = some (s_576 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_575
 theorem k_575 (z : Store) (tid : Tid) (h : tid ∉ [835]) : (s_576 z) tid = (s_575 z) tid := by
   unfold s_576
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_575
 theorem w_575_0 (z : Store) : (s_576 z) 835 = v_575_0 z := by
   unfold s_576
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_575_0, r_575_0 z] <;> rfl
 #a w_575_0
 theorem h_575_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_575_0 z).shape = [1, 4, 16, 8] := by
   unfold v_575_0
   exact h_574_0 z z_
 #a h_575_0
 attribute [local irreducible] v_575_0
 attribute [local irreducible] s_576
 theorem r_576_0 (z : Store) : (s_576 z) 831 = (v_571_0 z) := pR (k_575 z) (pR (k_574 z) (r_574_0 z))
 #a r_576_0
 theorem r_576_1 (z : Store) : (s_576 z) 1134 = (v_573_0 z) := pR (k_575 z) (pR (k_574 z) (r_574_1 z))
 #a r_576_1
 def v_576_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_571_0 z), (v_573_0 z)]
 theorem g_576 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_784) (s_576 z) pmNode_784 1 3 1137 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_784, r_576_0 z, r_576_1 z, h_571_0 z z_, h_573_0 z z_]
 #a g_576
 def s_577 (z : Store) : Store := pL [2, 3] (s_576 z) pmNode_784 1 3
 theorem t_576 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_784) (pmPeers pmNode_784) (s_576 z) pmNode_784 none = some (s_577 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_784) (s_576 z) pmNode_784).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 1137 (by decide) (g_576 z z_)]
   rfl
 #a t_576
 theorem k_576 (z : Store) (tid : Tid) (h : tid ∉ [1137]) : (s_577 z) tid = (s_576 z) tid := by
   unfold s_577
   dsimp only [pL, pmNode_784, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_576
 theorem w_576_0 (z : Store) : (s_577 z) 1137 = v_576_0 z := by
   unfold s_577
   dsimp only [pL, pmNode_784, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_576_0, r_576_0 z, r_576_1 z] <;> rfl
 #a w_576_0
 theorem h_576_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_576_0 z).shape = [1, 4, 16, 8] := by
   unfold v_576_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_571_0 z z_]
 #a h_576_0
 attribute [local irreducible] v_576_0
 attribute [local irreducible] s_577
 theorem r_577_0 (z : Store) : (s_577 z) 1137 = (v_576_0 z) := w_576_0 z
 #a r_577_0
 def v_577_0 (z : Store) : Tensor := fw_div ((4 : Nat) : Scalar) (v_576_0 z)
 def s_578 (z : Store) : Store := storeSet (s_577 z) [(1138, fw_div ((4 : Nat) : Scalar) ((s_577 z) 1137))]
 theorem t_577 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_785) (pmPeers pmNode_785) (s_577 z) pmNode_785 none = some (s_578 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_577
 theorem k_577 (z : Store) (tid : Tid) (h : tid ∉ [1138]) : (s_578 z) tid = (s_577 z) tid := by
   unfold s_578
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_577
 theorem w_577_0 (z : Store) : (s_578 z) 1138 = v_577_0 z := by
   unfold s_578
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_577_0, r_577_0 z] <;> rfl
 #a w_577_0
 theorem h_577_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_577_0 z).shape = [1, 4, 16, 8] := by
   unfold v_577_0
   exact h_576_0 z z_
 #a h_577_0
 attribute [local irreducible] v_577_0
 attribute [local irreducible] s_578
 theorem r_578_0 (z : Store) : (s_578 z) 835 = (v_575_0 z) := pR (k_577 z) (pR (k_576 z) (w_575_0 z))
 #a r_578_0
 theorem r_578_1 (z : Store) : (s_578 z) 1138 = (v_577_0 z) := w_577_0 z
 #a r_578_1
 def v_578_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 2 [(v_575_0 z), (v_577_0 z)]
 theorem g_578 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_550) (s_578 z) pmNode_550 3 2 838 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_550, r_578_0 z, r_578_1 z, h_575_0 z z_, h_577_0 z z_]
 #a g_578
 def s_579 (z : Store) : Store := pL [2, 3] (s_578 z) pmNode_550 3 2
 theorem t_578 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_550) (pmPeers pmNode_550) (s_578 z) pmNode_550 none = some (s_579 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_550) (s_578 z) pmNode_550).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 2 838 (by decide) (g_578 z z_)]
   rfl
 #a t_578
 theorem k_578 (z : Store) (tid : Tid) (h : tid ∉ [838]) : (s_579 z) tid = (s_578 z) tid := by
   unfold s_579
   dsimp only [pL, pmNode_550, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_578
 theorem w_578_0 (z : Store) : (s_579 z) 838 = v_578_0 z := by
   unfold s_579
   dsimp only [pL, pmNode_550, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_578_0, r_578_0 z, r_578_1 z] <;> rfl
 #a w_578_0
 theorem h_578_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_578_0 z).shape = [1, 4, 8, 16] := by
   unfold v_578_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_575_0 z z_]
 #a h_578_0
 attribute [local irreducible] v_578_0
 attribute [local irreducible] s_579
 record_prefix_opacity v_570_0 s_571 v_571_0 s_572 v_572_0 s_573 v_573_0 s_574 v_574_0 s_575 v_575_0 s_576 v_576_0 s_577 v_577_0 s_578 v_578_0 s_579

 end
 end TrainVerify.Denote.RuntimeWorld
