import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0039
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_310_0 (z : Store) : (s_310 z) 194 = (v_307_0 z) := pR (k_309 z) (pR (k_308 z) (w_307_0 z))
 #a r_310_0
 theorem r_310_1 (z : Store) : (s_310 z) 497 = (v_309_0 z) := w_309_0 z
 #a r_310_1
 def v_310_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_307_0 z), (v_309_0 z)]
 theorem g_310 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_155) (s_310 z) pmNode_155 2 1 296 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_155, r_310_0 z, r_310_1 z, h_307_0 z z_, h_309_0 z z_]
 #a g_310
 def s_311 (z : Store) : Store := pL [0, 1] (s_310 z) pmNode_155 2 1
 theorem t_310 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_155) (pmPeers pmNode_155) (s_310 z) pmNode_155 none = some (s_311 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_155) (s_310 z) pmNode_155).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 296 (by decide) (g_310 z z_)]
   rfl
 #a t_310
 theorem k_310 (z : Store) (tid : Tid) (h : tid ∉ [296]) : (s_311 z) tid = (s_310 z) tid := by
   unfold s_311
   dsimp only [pL, pmNode_155, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_310
 theorem w_310_0 (z : Store) : (s_311 z) 296 = v_310_0 z := by
   unfold s_311
   dsimp only [pL, pmNode_155, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_310_0, r_310_0 z, r_310_1 z] <;> rfl
 #a w_310_0
 theorem h_310_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_310_0 z).shape = [1, 8, 64] := by
   unfold v_310_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_307_0 z z_]
 #a h_310_0
 attribute [local irreducible] v_310_0
 attribute [local irreducible] s_311
 theorem r_311_0 (z : Store) : (s_311 z) 190 = (v_302_0 z) := pR (k_310 z) (pR (k_309 z) (pR (k_308 z) (pR (n_304_308 z) (pR (k_303 z) (w_302_0 z)))))
 #a r_311_0
 theorem r_311_1 (z : Store) : (s_311 z) 88 = (v_110_0 z) := pR (k_310 z) (pR (k_309 z) (pR (k_308 z) (pR (n_304_308 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (k_111 z) (r_111_0 z)))))))))
 #a r_311_1
 theorem r_311_2 (z : Store) : (s_311 z) 47 = (z 47) := pR (k_310 z) (pR (k_309 z) (pR (k_308 z) (pR (n_304_308 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (k_111 z) (r_111_1 z)))))))))
 #a r_311_2
 def v_311_0 (z : Store) : Tensor := (bw_linear (v_302_0 z) (v_110_0 z) (z 47)).1
 def v_311_1 (z : Store) : Tensor := (bw_linear (v_302_0 z) (v_110_0 z) (z 47)).2
 def s_312 (z : Store) : Store := storeSet (s_311 z) [(191, (bw_linear ((s_311 z) 190) ((s_311 z) 88) ((s_311 z) 47)).1), (48, (bw_linear ((s_311 z) 190) ((s_311 z) 88) ((s_311 z) 47)).2)]
 theorem t_311 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_156) (pmPeers pmNode_156) (s_311 z) pmNode_156 none = some (s_312 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_311
 theorem k_311 (z : Store) (tid : Tid) (h : tid ∉ [191, 48]) : (s_312 z) tid = (s_311 z) tid := by
   unfold s_312
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_311
 theorem w_311_0 (z : Store) : (s_312 z) 191 = v_311_0 z := by
   unfold s_312
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_311_0, r_311_0 z, r_311_1 z, r_311_2 z] <;> rfl
 #a w_311_0
 theorem h_311_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_311_0 z).shape = [1, 16, 64] := by
   unfold v_311_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_302_0 z) (v_110_0 z) (z 47) (h_302_0 z z_) (h_110_0 z z_) (i_28 z z_)
 #a h_311_0
 attribute [local irreducible] v_311_0
 theorem w_311_1 (z : Store) : (s_312 z) 48 = v_311_1 z := by
   unfold s_312
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_311_1, r_311_0 z, r_311_1 z, r_311_2 z] <;> rfl
 #a w_311_1
 theorem h_311_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_311_1 z).shape = [32, 64] := by
   unfold v_311_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_302_0 z) (v_110_0 z) (z 47) (h_302_0 z z_) (h_110_0 z z_) (i_28 z z_)
 #a h_311_1
 attribute [local irreducible] v_311_1
 attribute [local irreducible] s_312
 theorem r_312_0 (z : Store) : (s_312 z) 194 = (v_307_0 z) := pR (k_311 z) (pR (k_310 z) (r_310_0 z))
 #a r_312_0
 theorem r_312_1 (z : Store) : (s_312 z) 497 = (v_309_0 z) := pR (k_311 z) (pR (k_310 z) (r_310_1 z))
 #a r_312_1
 def v_312_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_307_0 z), (v_309_0 z)]
 theorem g_312 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_391) (s_312 z) pmNode_391 2 1 599 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_391, r_312_0 z, r_312_1 z, h_307_0 z z_, h_309_0 z z_]
 #a g_312
 def s_313 (z : Store) : Store := pL [0, 1] (s_312 z) pmNode_391 2 1
 theorem t_312 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_391) (pmPeers pmNode_391) (s_312 z) pmNode_391 none = some (s_313 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_391) (s_312 z) pmNode_391).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 599 (by decide) (g_312 z z_)]
   rfl
 #a t_312
 theorem k_312 (z : Store) (tid : Tid) (h : tid ∉ [599]) : (s_313 z) tid = (s_312 z) tid := by
   unfold s_313
   dsimp only [pL, pmNode_391, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_312
 theorem w_312_0 (z : Store) : (s_313 z) 599 = v_312_0 z := by
   unfold s_313
   dsimp only [pL, pmNode_391, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_312_0, r_312_0 z, r_312_1 z] <;> rfl
 #a w_312_0
 theorem h_312_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_312_0 z).shape = [1, 8, 64] := by
   unfold v_312_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_307_0 z z_]
 #a h_312_0
 attribute [local irreducible] v_312_0
 attribute [local irreducible] s_313
 theorem n_308_312 (z : Store) (tid : Tid) (h : tid ∉ ([601, 497, 354, 296, 191, 48] : List Tid)) : (s_312 z) tid = (s_308 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_308 z) (k_309 z)) (pF _ _ _ _ _ (k_310 z) (k_311 z)) tid h
 #a n_308_312
 theorem n_304_312 (z : Store) (tid : Tid) (h : tid ∉ ([494, 500, 357, 298, 194, 51, 601, 497, 354, 296, 191, 48] : List Tid)) : (s_312 z) tid = (s_304 z) tid := by
   exact pF _ _ _ _ _ (n_304_308 z) (n_308_312 z) tid h
 #a n_304_312
 theorem r_313_0 (z : Store) : (s_313 z) 494 = (v_304_0 z) := pR (k_312 z) (pR (n_308_312 z) (pR (k_307 z) (pR (k_306 z) (pR (k_305 z) (w_304_0 z)))))
 #a r_313_0
 theorem r_313_1 (z : Store) : (s_313 z) 391 = (v_116_0 z) := pR (k_312 z) (pR (n_304_312 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_120_128 z) (pR (k_119 z) (pR (k_118 z) (pR (k_117 z) (r_117_0 z)))))))))
 #a r_313_1
 theorem r_313_2 (z : Store) : (s_313 z) 350 = (z 350) := pR (k_312 z) (pR (n_304_312 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_120_128 z) (pR (k_119 z) (pR (k_118 z) (pR (k_117 z) (r_117_1 z)))))))))
 #a r_313_2
 def v_313_0 (z : Store) : Tensor := (bw_linear (v_304_0 z) (v_116_0 z) (z 350)).1
 def v_313_1 (z : Store) : Tensor := (bw_linear (v_304_0 z) (v_116_0 z) (z 350)).2
 def s_314 (z : Store) : Store := storeSet (s_313 z) [(493, (bw_linear ((s_313 z) 494) ((s_313 z) 391) ((s_313 z) 350)).1), (351, (bw_linear ((s_313 z) 494) ((s_313 z) 391) ((s_313 z) 350)).2)]
 theorem t_313 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_392) (pmPeers pmNode_392) (s_313 z) pmNode_392 none = some (s_314 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_313
 theorem k_313 (z : Store) (tid : Tid) (h : tid ∉ [493, 351]) : (s_314 z) tid = (s_313 z) tid := by
   unfold s_314
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_313
 theorem w_313_0 (z : Store) : (s_314 z) 493 = v_313_0 z := by
   unfold s_314
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_313_0, r_313_0 z, r_313_1 z, r_313_2 z] <;> rfl
 #a w_313_0
 theorem h_313_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_313_0 z).shape = [1, 16, 64] := by
   unfold v_313_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_304_0 z) (v_116_0 z) (z 350) (h_304_0 z z_) (h_116_0 z z_) (i_31 z z_)
 #a h_313_0
 attribute [local irreducible] v_313_0
 theorem w_313_1 (z : Store) : (s_314 z) 351 = v_313_1 z := by
   unfold s_314
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_313_1, r_313_0 z, r_313_1 z, r_313_2 z] <;> rfl
 #a w_313_1
 theorem h_313_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_313_1 z).shape = [32, 64] := by
   unfold v_313_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_304_0 z) (v_116_0 z) (z 350) (h_304_0 z z_) (h_116_0 z z_) (i_31 z z_)
 #a h_313_1
 attribute [local irreducible] v_313_1
 attribute [local irreducible] s_314
 theorem r_314_0 (z : Store) : (s_314 z) 191 = (v_311_0 z) := pR (k_313 z) (pR (k_312 z) (w_311_0 z))
 #a r_314_0
 theorem r_314_1 (z : Store) : (s_314 z) 493 = (v_313_0 z) := w_313_0 z
 #a r_314_1
 def v_314_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_311_0 z), (v_313_0 z)]
 def s_315 (z : Store) : Store := storeSet (s_314 z) [(294, reduceScatterPrimDimN 1 2 0 [((s_314 z) 191), ((s_314 z) 493)])]
 theorem t_314 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_157) (pmPeers pmNode_157) (s_314 z) pmNode_157 none = some (s_315 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_314 z) pmNode_157 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_314
 theorem k_314 (z : Store) (tid : Tid) (h : tid ∉ [294]) : (s_315 z) tid = (s_314 z) tid := by
   unfold s_315
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_314
 theorem w_314_0 (z : Store) : (s_315 z) 294 = v_314_0 z := by
   unfold s_315
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_314_0, r_314_0 z, r_314_1 z] <;> rfl
 #a w_314_0
 theorem h_314_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_314_0 z).shape = [1, 8, 64] := by
   unfold v_314_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_311_0 z) rfl]
     exact h_311_0 z z_
   · decide
 #a h_314_0
 attribute [local irreducible] v_314_0
 attribute [local irreducible] s_315
 theorem r_315_0 (z : Store) : (s_315 z) 294 = (v_314_0 z) := w_314_0 z
 #a r_315_0
 theorem r_315_1 (z : Store) : (s_315 z) 296 = (v_310_0 z) := pR (k_314 z) (pR (k_313 z) (pR (k_312 z) (pR (k_311 z) (w_310_0 z))))
 #a r_315_1
 theorem r_315_2 (z : Store) : (s_315 z) 298 = (v_306_0 z) := pR (k_314 z) (pR (k_313 z) (pR (k_312 z) (pR (n_308_312 z) (pR (k_307 z) (w_306_0 z)))))
 #a r_315_2
 def v_315_0 (z : Store) : Tensor := tensorSum [(v_314_0 z), (v_310_0 z), (v_306_0 z)]
 def s_316 (z : Store) : Store := storeSet (s_315 z) [(188, tensorSum [((s_315 z) 294), ((s_315 z) 296), ((s_315 z) 298)])]
 theorem t_315 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_158) (pmPeers pmNode_158) (s_315 z) pmNode_158 none = some (s_316 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_315
 theorem k_315 (z : Store) (tid : Tid) (h : tid ∉ [188]) : (s_316 z) tid = (s_315 z) tid := by
   unfold s_316
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_315
 theorem w_315_0 (z : Store) : (s_316 z) 188 = v_315_0 z := by
   unfold s_316
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_315_0, r_315_0 z, r_315_1 z, r_315_2 z] <;> rfl
 #a w_315_0
 theorem h_315_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_315_0 z).shape = [1, 8, 64] := by
   unfold v_315_0
   rw [tensorSum_shape]
   exact h_314_0 z z_
 #a h_315_0
 attribute [local irreducible] v_315_0
 attribute [local irreducible] s_316
 theorem n_312_316 (z : Store) (tid : Tid) (h : tid ∉ ([599, 493, 351, 294, 188] : List Tid)) : (s_316 z) tid = (s_312 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_312 z) (k_313 z)) (pF _ _ _ _ _ (k_314 z) (k_315 z)) tid h
 #a n_312_316
 theorem r_316_0 (z : Store) : (s_316 z) 188 = (v_315_0 z) := w_315_0 z
 #a r_316_0
 theorem r_316_1 (z : Store) : (s_316 z) 185 = (v_104_0 z) := pR (n_312_316 z) (pR (n_304_312 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_108_112 z) (pR (k_107 z) (pR (k_106 z) (pR (k_105 z) (r_105_0 z))))))))))
 #a r_316_1
 theorem r_316_2 (z : Store) : (s_316 z) 9 = (z 9) := pR (n_312_316 z) (pR (n_304_312 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_108_112 z) (pR (k_107 z) (pR (k_106 z) (pR (k_105 z) (r_105_1 z))))))))))
 #a r_316_2
 theorem r_316_3 (z : Store) : (s_316 z) 10 = (z 10) := pR (n_312_316 z) (pR (n_304_312 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_108_112 z) (pR (k_107 z) (pR (k_106 z) (pR (k_105 z) (r_105_2 z))))))))))
 #a r_316_3
 def v_316_0 (z : Store) : Tensor := (bw_layernorm (v_315_0 z) (v_104_0 z) (z 9) (z 10)).1
 def v_316_1 (z : Store) : Tensor := (bw_layernorm (v_315_0 z) (v_104_0 z) (z 9) (z 10)).2.1
 def v_316_2 (z : Store) : Tensor := (bw_layernorm (v_315_0 z) (v_104_0 z) (z 9) (z 10)).2.2
 def s_317 (z : Store) : Store := storeSet (s_316 z) [(187, (bw_layernorm ((s_316 z) 188) ((s_316 z) 185) ((s_316 z) 9) ((s_316 z) 10)).1), (43, (bw_layernorm ((s_316 z) 188) ((s_316 z) 185) ((s_316 z) 9) ((s_316 z) 10)).2.1), (45, (bw_layernorm ((s_316 z) 188) ((s_316 z) 185) ((s_316 z) 9) ((s_316 z) 10)).2.2)]
 theorem t_316 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_159) (pmPeers pmNode_159) (s_316 z) pmNode_159 none = some (s_317 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_316
 theorem k_316 (z : Store) (tid : Tid) (h : tid ∉ [187, 43, 45]) : (s_317 z) tid = (s_316 z) tid := by
   unfold s_317
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_316
 theorem w_316_0 (z : Store) : (s_317 z) 187 = v_316_0 z := by
   unfold s_317
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_316_0, r_316_0 z, r_316_1 z, r_316_2 z, r_316_3 z] <;> rfl
 #a w_316_0
 theorem h_316_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_316_0 z).shape = [1, 8, 64] := by
   unfold v_316_0
   rw [bw_layernorm_dx_shape (v_315_0 z) (v_104_0 z) (z 9) (z 10) 64 [8, 1] (by rw [h_104_0 z z_]; rfl)]
   exact h_104_0 z z_
 #a h_316_0
 attribute [local irreducible] v_316_0
 theorem w_316_1 (z : Store) : (s_317 z) 43 = v_316_1 z := by
   unfold s_317
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_316_1, r_316_0 z, r_316_1 z, r_316_2 z, r_316_3 z] <;> rfl
 #a w_316_1
 theorem h_316_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_316_1 z).shape = [64] := by
   unfold v_316_1
   rw [bw_layernorm_dw_shape (v_315_0 z) (v_104_0 z) (z 9) (z 10) 64 [8, 1] (by rw [h_104_0 z z_]; rfl)]
   exact i_24 z z_
 #a h_316_1
 attribute [local irreducible] v_316_1
 theorem w_316_2 (z : Store) : (s_317 z) 45 = v_316_2 z := by
   unfold s_317
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_316_2, r_316_0 z, r_316_1 z, r_316_2 z, r_316_3 z] <;> rfl
 #a w_316_2
 theorem h_316_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_316_2 z).shape = [64] := by
   unfold v_316_2
   rw [bw_layernorm_db_shape (v_315_0 z) (v_104_0 z) (z 9) (z 10) 64 [8, 1] (by rw [h_104_0 z z_]; rfl)]
   exact i_25 z z_
 #a h_316_2
 attribute [local irreducible] v_316_2
 attribute [local irreducible] s_317
 record_prefix_opacity v_310_0 s_311 v_311_0 v_311_1 s_312 v_312_0 s_313 v_313_0 v_313_1 s_314 v_314_0 s_315 v_315_0 s_316 v_316_0 v_316_1 v_316_2 s_317

 end
 end TrainVerify.Denote.RuntimeWorld
