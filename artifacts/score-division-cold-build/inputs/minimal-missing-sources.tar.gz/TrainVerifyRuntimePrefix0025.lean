import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0024
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_191_0 (z : Store) : (s_191 z) 565 = (v_190_0 z) := w_190_0 z
 #a r_191_0
 theorem r_191_1 (z : Store) : (s_191 z) 366 = (z 366) := pR (k_190 z) (pR (k_189 z) (pR (k_188 z) (pR (n_184_188 z) (pR (n_176_184 z) (pR (n_160_176 z) (pR (n_128_160 z) (pR (n_0_128 z) (e_41 z))))))))
 #a r_191_1
 def v_191_0 (z : Store) : Tensor := fw_linear (v_190_0 z) (z 366)
 def s_192 (z : Store) : Store := storeSet (s_191 z) [(566, fw_linear ((s_191 z) 565) ((s_191 z) 366))]
 theorem t_191 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_331) (pmPeers pmNode_331) (s_191 z) pmNode_331 none = some (s_192 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_191
 theorem k_191 (z : Store) (tid : Tid) (h : tid ∉ [566]) : (s_192 z) tid = (s_191 z) tid := by
   unfold s_192
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_191
 theorem w_191_0 (z : Store) : (s_192 z) 566 = v_191_0 z := by
   unfold s_192
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_191_0, r_191_0 z, r_191_1 z] <;> rfl
 #a w_191_0
 theorem h_191_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_191_0 z).shape = [1, 16, 256] := by
   unfold v_191_0
   exact fw_linear_3d_shape 1 16 32 256 (v_190_0 z) (z 366) (h_190_0 z z_) (i_41 z z_)
 #a h_191_0
 attribute [local irreducible] v_191_0
 attribute [local irreducible] s_192
 theorem r_192_0 (z : Store) : (s_192 z) 263 = (v_189_0 z) := pR (k_191 z) (pR (k_190 z) (w_189_0 z))
 #a r_192_0
 theorem r_192_1 (z : Store) : (s_192 z) 566 = (v_191_0 z) := w_191_0 z
 #a r_192_1
 def v_192_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_189_0 z), (v_191_0 z)]
 def s_193 (z : Store) : Store := storeSet (s_192 z) [(265, reduceScatterPrimDimN 1 2 0 [((s_192 z) 263), ((s_192 z) 566)])]
 theorem t_192 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_96) (pmPeers pmNode_96) (s_192 z) pmNode_96 none = some (s_193 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_192 z) pmNode_96 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_192
 theorem k_192 (z : Store) (tid : Tid) (h : tid ∉ [265]) : (s_193 z) tid = (s_192 z) tid := by
   unfold s_193
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_192
 theorem w_192_0 (z : Store) : (s_193 z) 265 = v_192_0 z := by
   unfold s_193
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_192_0, r_192_0 z, r_192_1 z] <;> rfl
 #a w_192_0
 theorem h_192_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_192_0 z).shape = [1, 8, 256] := by
   unfold v_192_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 256]
   · rw [allReducePrim_shape _ _ _ (v_189_0 z) rfl]
     exact h_189_0 z z_
   · decide
 #a h_192_0
 attribute [local irreducible] v_192_0
 attribute [local irreducible] s_193
 theorem r_193_0 (z : Store) : (s_193 z) 265 = (v_192_0 z) := w_192_0 z
 #a r_193_0
 def v_193_0 (z : Store) : Tensor := fw_gelu (v_192_0 z)
 def s_194 (z : Store) : Store := storeSet (s_193 z) [(266, fw_gelu ((s_193 z) 265))]
 theorem t_193 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_97) (pmPeers pmNode_97) (s_193 z) pmNode_97 none = some (s_194 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_193
 theorem k_193 (z : Store) (tid : Tid) (h : tid ∉ [266]) : (s_194 z) tid = (s_193 z) tid := by
   unfold s_194
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_193
 theorem w_193_0 (z : Store) : (s_194 z) 266 = v_193_0 z := by
   unfold s_194
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_193_0, r_193_0 z] <;> rfl
 #a w_193_0
 theorem h_193_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_193_0 z).shape = [1, 8, 256] := by
   unfold v_193_0
   exact h_192_0 z z_
 #a h_193_0
 attribute [local irreducible] v_193_0
 attribute [local irreducible] s_194
 theorem n_188_192 (z : Store) (tid : Tid) (h : tid ∉ ([262, 263, 565, 566] : List Tid)) : (s_192 z) tid = (s_188 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_188 z) (k_189 z)) (pF _ _ _ _ _ (k_190 z) (k_191 z)) tid h
 #a n_188_192
 theorem n_184_192 (z : Store) (tid : Tid) (h : tid ∉ ([258, 259, 561, 562, 262, 263, 565, 566] : List Tid)) : (s_192 z) tid = (s_184 z) tid := by
   exact pF _ _ _ _ _ (n_184_188 z) (n_188_192 z) tid h
 #a n_184_192
 theorem n_176_192 (z : Store) (tid : Tid) (h : tid ∉ ([551, 554, 253, 254, 299, 301, 556, 557, 602, 604, 258, 259, 561, 562, 262, 263, 565, 566] : List Tid)) : (s_192 z) tid = (s_176 z) tid := by
   exact pF _ _ _ _ _ (n_176_184 z) (n_184_192 z) tid h
 #a n_176_192
 theorem n_160_192 (z : Store) (tid : Tid) (h : tid ∉ ([535, 536, 382, 539, 239, 240, 542, 543, 243, 244, 546, 547, 247, 248, 251, 550, 551, 554, 253, 254, 299, 301, 556, 557, 602, 604, 258, 259, 561, 562, 262, 263, 565, 566] : List Tid)) : (s_192 z) tid = (s_160 z) tid := by
   exact pF _ _ _ _ _ (n_160_176 z) (n_176_192 z) tid h
 #a n_160_192
 theorem n_128_192 (z : Store) (tid : Tid) (h : tid ∉ ([206, 207, 505, 506, 509, 510, 210, 211, 214, 215, 513, 514, 517, 518, 218, 219, 222, 521, 522, 525, 224, 225, 527, 528, 228, 229, 531, 532, 232, 233, 79, 236, 535, 536, 382, 539, 239, 240, 542, 543, 243, 244, 546, 547, 247, 248, 251, 550, 551, 554, 253, 254, 299, 301, 556, 557, 602, 604, 258, 259, 561, 562, 262, 263, 565, 566] : List Tid)) : (s_192 z) tid = (s_128 z) tid := by
   exact pF _ _ _ _ _ (n_128_160 z) (n_160_192 z) tid h
 #a n_128_192
 theorem r_194_0 (z : Store) : (s_194 z) 266 = (v_193_0 z) := w_193_0 z
 #a r_194_0
 theorem r_194_1 (z : Store) : (s_194 z) 13 = (z 13) := pR (k_193 z) (pR (k_192 z) (pR (n_128_192 z) (pR (n_0_128 z) (e_42 z))))
 #a r_194_1
 def v_194_0 (z : Store) : Tensor := fw_linear (v_193_0 z) (z 13)
 def s_195 (z : Store) : Store := storeSet (s_194 z) [(269, fw_linear ((s_194 z) 266) ((s_194 z) 13))]
 theorem t_194 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_98) (pmPeers pmNode_98) (s_194 z) pmNode_98 none = some (s_195 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_194
 theorem k_194 (z : Store) (tid : Tid) (h : tid ∉ [269]) : (s_195 z) tid = (s_194 z) tid := by
   unfold s_195
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_194
 theorem w_194_0 (z : Store) : (s_195 z) 269 = v_194_0 z := by
   unfold s_195
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_194_0, r_194_0 z, r_194_1 z] <;> rfl
 #a w_194_0
 theorem h_194_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_194_0 z).shape = [1, 8, 64] := by
   unfold v_194_0
   exact fw_linear_3d_shape 1 8 256 64 (v_193_0 z) (z 13) (h_193_0 z z_) (i_42 z z_)
 #a h_194_0
 attribute [local irreducible] v_194_0
 attribute [local irreducible] s_195
 theorem r_195_0 (z : Store) : (s_195 z) 301 = (v_180_1 z) := pR (k_194 z) (pR (k_193 z) (pR (k_192 z) (pR (n_184_192 z) (pR (k_183 z) (pR (k_182 z) (pR (k_181 z) (w_180_1 z)))))))
 #a r_195_0
 theorem r_195_1 (z : Store) : (s_195 z) 604 = (v_183_1 z) := pR (k_194 z) (pR (k_193 z) (pR (k_192 z) (pR (n_184_192 z) (w_183_1 z))))
 #a r_195_1
 def v_195_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_180_1 z), (v_183_1 z)]
 theorem g_195 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_99) (s_195 z) pmNode_99 2 1 271 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_99, r_195_0 z, r_195_1 z, h_180_1 z z_, h_183_1 z z_]
 #a g_195
 def s_196 (z : Store) : Store := pL [0, 1] (s_195 z) pmNode_99 2 1
 theorem t_195 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_99) (pmPeers pmNode_99) (s_195 z) pmNode_99 none = some (s_196 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_99) (s_195 z) pmNode_99).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 271 (by decide) (g_195 z z_)]
   rfl
 #a t_195
 theorem k_195 (z : Store) (tid : Tid) (h : tid ∉ [271]) : (s_196 z) tid = (s_195 z) tid := by
   unfold s_196
   dsimp only [pL, pmNode_99, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_195
 theorem w_195_0 (z : Store) : (s_196 z) 271 = v_195_0 z := by
   unfold s_196
   dsimp only [pL, pmNode_99, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_195_0, r_195_0 z, r_195_1 z] <;> rfl
 #a w_195_0
 theorem h_195_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_195_0 z).shape = [1, 8, 64] := by
   unfold v_195_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_180_1 z z_]
 #a h_195_0
 attribute [local irreducible] v_195_0
 attribute [local irreducible] s_196
 theorem r_196_0 (z : Store) : (s_196 z) 271 = (v_195_0 z) := w_195_0 z
 #a r_196_0
 theorem r_196_1 (z : Store) : (s_196 z) 269 = (v_194_0 z) := pR (k_195 z) (w_194_0 z)
 #a r_196_1
 def v_196_0 (z : Store) : Tensor := elemwiseAdd (v_195_0 z) (v_194_0 z)
 def s_197 (z : Store) : Store := storeSet (s_196 z) [(272, elemwiseAdd ((s_196 z) 271) ((s_196 z) 269))]
 theorem t_196 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_100) (pmPeers pmNode_100) (s_196 z) pmNode_100 none = some (s_197 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_196
 theorem k_196 (z : Store) (tid : Tid) (h : tid ∉ [272]) : (s_197 z) tid = (s_196 z) tid := by
   unfold s_197
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_196
 theorem w_196_0 (z : Store) : (s_197 z) 272 = v_196_0 z := by
   unfold s_197
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_196_0, r_196_0 z, r_196_1 z] <;> rfl
 #a w_196_0
 theorem h_196_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_196_0 z).shape = [1, 8, 64] := by
   unfold v_196_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_195_0 z z_, h_194_0 z z_]
 #a h_196_0
 attribute [local irreducible] v_196_0
 attribute [local irreducible] s_197
 theorem n_192_196 (z : Store) (tid : Tid) (h : tid ∉ ([265, 266, 269, 271] : List Tid)) : (s_196 z) tid = (s_192 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_192 z) (k_193 z)) (pF _ _ _ _ _ (k_194 z) (k_195 z)) tid h
 #a n_192_196
 theorem r_197_0 (z : Store) : (s_197 z) 272 = (v_196_0 z) := w_196_0 z
 #a r_197_0
 theorem r_197_1 (z : Store) : (s_197 z) 14 = (z 14) := pR (k_196 z) (pR (n_192_196 z) (pR (n_128_192 z) (pR (n_0_128 z) (e_43 z))))
 #a r_197_1
 theorem r_197_2 (z : Store) : (s_197 z) 15 = (z 15) := pR (k_196 z) (pR (n_192_196 z) (pR (n_128_192 z) (pR (n_0_128 z) (e_44 z))))
 #a r_197_2
 def v_197_0 (z : Store) : Tensor := fw_layernorm (v_196_0 z) (z 14) (z 15)
 def s_198 (z : Store) : Store := storeSet (s_197 z) [(275, fw_layernorm ((s_197 z) 272) ((s_197 z) 14) ((s_197 z) 15))]
 theorem t_197 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_101) (pmPeers pmNode_101) (s_197 z) pmNode_101 none = some (s_198 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_197
 theorem k_197 (z : Store) (tid : Tid) (h : tid ∉ [275]) : (s_198 z) tid = (s_197 z) tid := by
   unfold s_198
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_197
 theorem w_197_0 (z : Store) : (s_198 z) 275 = v_197_0 z := by
   unfold s_198
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_197_0, r_197_0 z, r_197_1 z, r_197_2 z] <;> rfl
 #a w_197_0
 theorem h_197_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_197_0 z).shape = [1, 8, 64] := by
   unfold v_197_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_196_0 z z_
 #a h_197_0
 attribute [local irreducible] v_197_0
 attribute [local irreducible] s_198
 theorem r_198_0 (z : Store) : (s_198 z) 263 = (v_189_0 z) := pR (k_197 z) (pR (k_196 z) (pR (n_192_196 z) (r_192_0 z)))
 #a r_198_0
 theorem r_198_1 (z : Store) : (s_198 z) 566 = (v_191_0 z) := pR (k_197 z) (pR (k_196 z) (pR (n_192_196 z) (r_192_1 z)))
 #a r_198_1
 def v_198_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_189_0 z), (v_191_0 z)]
 def s_199 (z : Store) : Store := storeSet (s_198 z) [(568, reduceScatterPrimDimN 1 2 1 [((s_198 z) 263), ((s_198 z) 566)])]
 theorem t_198 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_332) (pmPeers pmNode_332) (s_198 z) pmNode_332 none = some (s_199 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_198 z) pmNode_332 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_198
 theorem k_198 (z : Store) (tid : Tid) (h : tid ∉ [568]) : (s_199 z) tid = (s_198 z) tid := by
   unfold s_199
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_198
 theorem w_198_0 (z : Store) : (s_199 z) 568 = v_198_0 z := by
   unfold s_199
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_198_0, r_198_0 z, r_198_1 z] <;> rfl
 #a w_198_0
 theorem h_198_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_198_0 z).shape = [1, 8, 256] := by
   unfold v_198_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 256]
   · rw [allReducePrim_shape _ _ _ (v_189_0 z) rfl]
     exact h_189_0 z z_
   · decide
 #a h_198_0
 attribute [local irreducible] v_198_0
 attribute [local irreducible] s_199
 theorem r_199_0 (z : Store) : (s_199 z) 568 = (v_198_0 z) := w_198_0 z
 #a r_199_0
 def v_199_0 (z : Store) : Tensor := fw_gelu (v_198_0 z)
 def s_200 (z : Store) : Store := storeSet (s_199 z) [(569, fw_gelu ((s_199 z) 568))]
 theorem t_199 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_333) (pmPeers pmNode_333) (s_199 z) pmNode_333 none = some (s_200 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_199
 theorem k_199 (z : Store) (tid : Tid) (h : tid ∉ [569]) : (s_200 z) tid = (s_199 z) tid := by
   unfold s_200
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_199
 theorem w_199_0 (z : Store) : (s_200 z) 569 = v_199_0 z := by
   unfold s_200
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_199_0, r_199_0 z] <;> rfl
 #a w_199_0
 theorem h_199_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_199_0 z).shape = [1, 8, 256] := by
   unfold v_199_0
   exact h_198_0 z z_
 #a h_199_0
 attribute [local irreducible] v_199_0
 attribute [local irreducible] s_200
 theorem n_196_200 (z : Store) (tid : Tid) (h : tid ∉ ([272, 275, 568, 569] : List Tid)) : (s_200 z) tid = (s_196 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_196 z) (k_197 z)) (pF _ _ _ _ _ (k_198 z) (k_199 z)) tid h
 #a n_196_200
 theorem n_192_200 (z : Store) (tid : Tid) (h : tid ∉ ([265, 266, 269, 271, 272, 275, 568, 569] : List Tid)) : (s_200 z) tid = (s_192 z) tid := by
   exact pF _ _ _ _ _ (n_192_196 z) (n_196_200 z) tid h
 #a n_192_200
 record_prefix_opacity v_191_0 s_192 v_192_0 s_193 v_193_0 s_194 v_194_0 s_195 v_195_0 s_196 v_196_0 s_197 v_197_0 s_198 v_198_0 s_199 v_199_0 s_200

 end
 end TrainVerify.Denote.RuntimeWorld
