import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0068
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_542_0 (z : Store) : (s_542 z) 901 = (v_528_1 z) := pR (k_541 z) (pR (k_540 z) (pR (n_536_540 z) (pR (k_535 z) (pR (k_534 z) (r_534_0 z)))))
 #a r_542_0
 theorem r_542_1 (z : Store) : (s_542 z) 1204 = (v_531_1 z) := pR (k_541 z) (pR (k_540 z) (pR (n_536_540 z) (pR (k_535 z) (pR (k_534 z) (r_534_1 z)))))
 #a r_542_1
 def v_542_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_528_1 z), (v_531_1 z)]
 theorem g_542 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_765) (s_542 z) pmNode_765 1 2 1101 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_765, r_542_0 z, r_542_1 z, h_528_1 z z_, h_531_1 z z_]
 #a g_542
 def s_543 (z : Store) : Store := pL [2, 3] (s_542 z) pmNode_765 1 2
 theorem t_542 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_765) (pmPeers pmNode_765) (s_542 z) pmNode_765 none = some (s_543 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_765) (s_542 z) pmNode_765).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1101 (by decide) (g_542 z z_)]
   rfl
 #a t_542
 theorem k_542 (z : Store) (tid : Tid) (h : tid ∉ [1101]) : (s_543 z) tid = (s_542 z) tid := by
   unfold s_543
   dsimp only [pL, pmNode_765, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_542
 theorem w_542_0 (z : Store) : (s_543 z) 1101 = v_542_0 z := by
   unfold s_543
   dsimp only [pL, pmNode_765, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_542_0, r_542_0 z, r_542_1 z] <;> rfl
 #a w_542_0
 theorem h_542_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_542_0 z).shape = [1, 16, 32] := by
   unfold v_542_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_528_1 z z_]
 #a h_542_0
 attribute [local irreducible] v_542_0
 attribute [local irreducible] s_543
 theorem r_543_0 (z : Store) : (s_543 z) 1101 = (v_542_0 z) := w_542_0 z
 #a r_543_0
 theorem r_543_1 (z : Store) : (s_543 z) 959 = (z 959) := pR (k_542 z) (pR (k_541 z) (pR (k_540 z) (pR (n_536_540 z) (pR (n_528_536 z) (pR (n_512_528 z) (pR (n_0_512 z) (e_82 z)))))))
 #a r_543_1
 def v_543_0 (z : Store) : Tensor := fw_linear (v_542_0 z) (z 959)
 def s_544 (z : Store) : Store := storeSet (s_543 z) [(1102, fw_linear ((s_543 z) 1101) ((s_543 z) 959))]
 theorem t_543 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_766) (pmPeers pmNode_766) (s_543 z) pmNode_766 none = some (s_544 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_543
 theorem k_543 (z : Store) (tid : Tid) (h : tid ∉ [1102]) : (s_544 z) tid = (s_543 z) tid := by
   unfold s_544
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_543
 theorem w_543_0 (z : Store) : (s_544 z) 1102 = v_543_0 z := by
   unfold s_544
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_543_0, r_543_0 z, r_543_1 z] <;> rfl
 #a w_543_0
 theorem h_543_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_543_0 z).shape = [1, 16, 64] := by
   unfold v_543_0
   exact fw_linear_3d_shape 1 16 32 64 (v_542_0 z) (z 959) (h_542_0 z z_) (i_82 z z_)
 #a h_543_0
 attribute [local irreducible] v_543_0
 attribute [local irreducible] s_544
 theorem n_540_544 (z : Store) (tid : Tid) (h : tid ∉ ([804, 805, 1101, 1102] : List Tid)) : (s_544 z) tid = (s_540 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_540 z) (k_541 z)) (pF _ _ _ _ _ (k_542 z) (k_543 z)) tid h
 #a n_540_544
 theorem n_536_544 (z : Store) (tid : Tid) (h : tid ∉ ([801, 802, 997, 1098, 804, 805, 1101, 1102] : List Tid)) : (s_544 z) tid = (s_536 z) tid := by
   exact pF _ _ _ _ _ (n_536_540 z) (n_540_544 z) tid h
 #a n_536_544
 theorem r_544_0 (z : Store) : (s_544 z) 903 = (v_528_2 z) := pR (n_536_544 z) (r_536_0 z)
 #a r_544_0
 theorem r_544_1 (z : Store) : (s_544 z) 1206 = (v_531_2 z) := pR (n_536_544 z) (r_536_1 z)
 #a r_544_1
 def v_544_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_528_2 z), (v_531_2 z)]
 theorem g_544 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_767) (s_544 z) pmNode_767 1 2 1104 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_767, r_544_0 z, r_544_1 z, h_528_2 z z_, h_531_2 z z_]
 #a g_544
 def s_545 (z : Store) : Store := pL [2, 3] (s_544 z) pmNode_767 1 2
 theorem t_544 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_767) (pmPeers pmNode_767) (s_544 z) pmNode_767 none = some (s_545 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_767) (s_544 z) pmNode_767).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1104 (by decide) (g_544 z z_)]
   rfl
 #a t_544
 theorem k_544 (z : Store) (tid : Tid) (h : tid ∉ [1104]) : (s_545 z) tid = (s_544 z) tid := by
   unfold s_545
   dsimp only [pL, pmNode_767, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_544
 theorem w_544_0 (z : Store) : (s_545 z) 1104 = v_544_0 z := by
   unfold s_545
   dsimp only [pL, pmNode_767, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_544_0, r_544_0 z, r_544_1 z] <;> rfl
 #a w_544_0
 theorem h_544_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_544_0 z).shape = [1, 16, 32] := by
   unfold v_544_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_528_2 z z_]
 #a h_544_0
 attribute [local irreducible] v_544_0
 attribute [local irreducible] s_545
 theorem n_528_544 (z : Store) (tid : Tid) (h : tid ∉ ([899, 901, 903, 1094, 1095, 1202, 1204, 1206, 694, 795, 798, 799, 801, 802, 997, 1098, 804, 805, 1101, 1102] : List Tid)) : (s_544 z) tid = (s_528 z) tid := by
   exact pF _ _ _ _ _ (n_528_536 z) (n_536_544 z) tid h
 #a n_528_544
 theorem n_512_544 (z : Store) (tid : Tid) (h : tid ∉ ([779, 781, 783, 1078, 1079, 1082, 1084, 1086, 786, 787, 897, 858, 1089, 1090, 1200, 1161, 791, 792, 899, 901, 903, 1094, 1095, 1202, 1204, 1206, 694, 795, 798, 799, 801, 802, 997, 1098, 804, 805, 1101, 1102] : List Tid)) : (s_544 z) tid = (s_512 z) tid := by
   exact pF _ _ _ _ _ (n_512_528 z) (n_528_544 z) tid h
 #a n_512_544
 theorem r_545_0 (z : Store) : (s_545 z) 1104 = (v_544_0 z) := w_544_0 z
 #a r_545_0
 theorem r_545_1 (z : Store) : (s_545 z) 962 = (z 962) := pR (k_544 z) (pR (n_512_544 z) (pR (n_0_512 z) (e_83 z)))
 #a r_545_1
 def v_545_0 (z : Store) : Tensor := fw_linear (v_544_0 z) (z 962)
 def s_546 (z : Store) : Store := storeSet (s_545 z) [(1105, fw_linear ((s_545 z) 1104) ((s_545 z) 962))]
 theorem t_545 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_768) (pmPeers pmNode_768) (s_545 z) pmNode_768 none = some (s_546 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_545
 theorem k_545 (z : Store) (tid : Tid) (h : tid ∉ [1105]) : (s_546 z) tid = (s_545 z) tid := by
   unfold s_546
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_545
 theorem w_545_0 (z : Store) : (s_546 z) 1105 = v_545_0 z := by
   unfold s_546
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_545_0, r_545_0 z, r_545_1 z] <;> rfl
 #a w_545_0
 theorem h_545_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_545_0 z).shape = [1, 16, 64] := by
   unfold v_545_0
   exact fw_linear_3d_shape 1 16 32 64 (v_544_0 z) (z 962) (h_544_0 z z_) (i_83 z z_)
 #a h_545_0
 attribute [local irreducible] v_545_0
 attribute [local irreducible] s_546
 theorem r_546_0 (z : Store) : (s_546 z) 795 = (v_533_0 z) := pR (k_545 z) (pR (k_544 z) (pR (n_540_544 z) (r_540_0 z)))
 #a r_546_0
 theorem r_546_1 (z : Store) : (s_546 z) 1098 = (v_539_0 z) := pR (k_545 z) (pR (k_544 z) (pR (n_540_544 z) (r_540_1 z)))
 #a r_546_1
 def v_546_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_533_0 z), (v_539_0 z)]
 theorem g_546 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_769) (s_546 z) pmNode_769 2 1 1107 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_769, r_546_0 z, r_546_1 z, h_533_0 z z_, h_539_0 z z_]
 #a g_546
 def s_547 (z : Store) : Store := pL [2, 3] (s_546 z) pmNode_769 2 1
 theorem t_546 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_769) (pmPeers pmNode_769) (s_546 z) pmNode_769 none = some (s_547 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_769) (s_546 z) pmNode_769).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1107 (by decide) (g_546 z z_)]
   rfl
 #a t_546
 theorem k_546 (z : Store) (tid : Tid) (h : tid ∉ [1107]) : (s_547 z) tid = (s_546 z) tid := by
   unfold s_547
   dsimp only [pL, pmNode_769, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_546
 theorem w_546_0 (z : Store) : (s_547 z) 1107 = v_546_0 z := by
   unfold s_547
   dsimp only [pL, pmNode_769, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_546_0, r_546_0 z, r_546_1 z] <;> rfl
 #a w_546_0
 theorem h_546_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_546_0 z).shape = [1, 8, 64] := by
   unfold v_546_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_533_0 z z_]
 #a h_546_0
 attribute [local irreducible] v_546_0
 attribute [local irreducible] s_547
 theorem r_547_0 (z : Store) : (s_547 z) 1107 = (v_546_0 z) := w_546_0 z
 #a r_547_0
 def v_547_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_546_0 z)
 def s_548 (z : Store) : Store := storeSet (s_547 z) [(1108, fw_view [1, 8, 4, 16] ((s_547 z) 1107))]
 theorem t_547 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_770) (pmPeers pmNode_770) (s_547 z) pmNode_770 none = some (s_548 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_547
 theorem k_547 (z : Store) (tid : Tid) (h : tid ∉ [1108]) : (s_548 z) tid = (s_547 z) tid := by
   unfold s_548
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_547
 theorem w_547_0 (z : Store) : (s_548 z) 1108 = v_547_0 z := by
   unfold s_548
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_547_0, r_547_0 z] <;> rfl
 #a w_547_0
 theorem h_547_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_547_0 z).shape = [1, 8, 4, 16] := by
   unfold v_547_0
   rfl
 #a h_547_0
 attribute [local irreducible] v_547_0
 attribute [local irreducible] s_548
 theorem n_544_548 (z : Store) (tid : Tid) (h : tid ∉ ([1104, 1105, 1107, 1108] : List Tid)) : (s_548 z) tid = (s_544 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_544 z) (k_545 z)) (pF _ _ _ _ _ (k_546 z) (k_547 z)) tid h
 #a n_544_548
 theorem r_548_0 (z : Store) : (s_548 z) 805 = (v_541_0 z) := pR (n_544_548 z) (pR (k_543 z) (pR (k_542 z) (w_541_0 z)))
 #a r_548_0
 theorem r_548_1 (z : Store) : (s_548 z) 1108 = (v_547_0 z) := w_547_0 z
 #a r_548_1
 def v_548_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_541_0 z), (v_547_0 z)]
 theorem g_548 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_535) (s_548 z) pmNode_535 1 2 808 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_535, r_548_0 z, r_548_1 z, h_541_0 z z_, h_547_0 z z_]
 #a g_548
 def s_549 (z : Store) : Store := pL [2, 3] (s_548 z) pmNode_535 1 2
 theorem t_548 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_535) (pmPeers pmNode_535) (s_548 z) pmNode_535 none = some (s_549 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_535) (s_548 z) pmNode_535).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 808 (by decide) (g_548 z z_)]
   rfl
 #a t_548
 theorem k_548 (z : Store) (tid : Tid) (h : tid ∉ [808]) : (s_549 z) tid = (s_548 z) tid := by
   unfold s_549
   dsimp only [pL, pmNode_535, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_548
 theorem w_548_0 (z : Store) : (s_549 z) 808 = v_548_0 z := by
   unfold s_549
   dsimp only [pL, pmNode_535, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_548_0, r_548_0 z, r_548_1 z] <;> rfl
 #a w_548_0
 theorem h_548_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_548_0 z).shape = [1, 16, 2, 16] := by
   unfold v_548_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_541_0 z z_]
 #a h_548_0
 attribute [local irreducible] v_548_0
 attribute [local irreducible] s_549
 theorem r_549_0 (z : Store) : (s_549 z) 808 = (v_548_0 z) := w_548_0 z
 #a r_549_0
 def v_549_0 (z : Store) : Tensor := transposeAxes 1 2 (v_548_0 z)
 def s_550 (z : Store) : Store := storeSet (s_549 z) [(809, transposeAxes 1 2 ((s_549 z) 808))]
 theorem t_549 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_536) (pmPeers pmNode_536) (s_549 z) pmNode_536 none = some (s_550 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_549
 theorem k_549 (z : Store) (tid : Tid) (h : tid ∉ [809]) : (s_550 z) tid = (s_549 z) tid := by
   unfold s_550
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_549
 theorem w_549_0 (z : Store) : (s_550 z) 809 = v_549_0 z := by
   unfold s_550
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_549_0, r_549_0 z] <;> rfl
 #a w_549_0
 theorem h_549_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_549_0 z).shape = [1, 2, 16, 16] := by
   unfold v_549_0
   change listSwapAt _ _ _ = _
   rw [h_548_0 z z_]
   rfl
 #a h_549_0
 attribute [local irreducible] v_549_0
 attribute [local irreducible] s_550
 theorem r_550_0 (z : Store) : (s_550 z) 799 = (v_535_0 z) := pR (k_549 z) (pR (k_548 z) (pR (n_544_548 z) (pR (n_536_544 z) (w_535_0 z))))
 #a r_550_0
 theorem r_550_1 (z : Store) : (s_550 z) 1102 = (v_543_0 z) := pR (k_549 z) (pR (k_548 z) (pR (n_544_548 z) (w_543_0 z)))
 #a r_550_1
 def v_550_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_535_0 z), (v_543_0 z)]
 def s_551 (z : Store) : Store := storeSet (s_550 z) [(812, reduceScatterPrimDimN 1 2 0 [((s_550 z) 799), ((s_550 z) 1102)])]
 theorem t_550 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_537) (pmPeers pmNode_537) (s_550 z) pmNode_537 none = some (s_551 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_550 z) pmNode_537 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_550
 theorem k_550 (z : Store) (tid : Tid) (h : tid ∉ [812]) : (s_551 z) tid = (s_550 z) tid := by
   unfold s_551
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_550
 theorem w_550_0 (z : Store) : (s_551 z) 812 = v_550_0 z := by
   unfold s_551
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_550_0, r_550_0 z, r_550_1 z] <;> rfl
 #a w_550_0
 theorem h_550_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_550_0 z).shape = [1, 8, 64] := by
   unfold v_550_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_535_0 z) rfl]
     exact h_535_0 z z_
   · decide
 #a h_550_0
 attribute [local irreducible] v_550_0
 attribute [local irreducible] s_551
 record_prefix_opacity v_542_0 s_543 v_543_0 s_544 v_544_0 s_545 v_545_0 s_546 v_546_0 s_547 v_547_0 s_548 v_548_0 s_549 v_549_0 s_550 v_550_0 s_551

 end
 end TrainVerify.Denote.RuntimeWorld
