import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0042
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_331_0 (z : Store) : (s_331 z) 183 = (v_322_1 z) := pR (k_330 z) (pR (k_329 z) (pR (k_328 z) (pR (k_327 z) (pR (k_326 z) (r_326_0 z)))))
 #a r_331_0
 theorem r_331_1 (z : Store) : (s_331 z) 486 = (v_325_1 z) := pR (k_330 z) (pR (k_329 z) (pR (k_328 z) (pR (k_327 z) (pR (k_326 z) (r_326_1 z)))))
 #a r_331_1
 def v_331_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_322_1 z), (v_325_1 z)]
 theorem g_331 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_399) (s_331 z) pmNode_399 2 1 481 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_399, r_331_0 z, r_331_1 z, h_322_1 z z_, h_325_1 z z_]
 #a g_331
 def s_332 (z : Store) : Store := pL [0, 1] (s_331 z) pmNode_399 2 1
 theorem t_331 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_399) (pmPeers pmNode_399) (s_331 z) pmNode_399 none = some (s_332 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_399) (s_331 z) pmNode_399).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 481 (by decide) (g_331 z z_)]
   rfl
 #a t_331
 theorem k_331 (z : Store) (tid : Tid) (h : tid ∉ [481]) : (s_332 z) tid = (s_331 z) tid := by
   unfold s_332
   dsimp only [pL, pmNode_399, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_331
 theorem w_331_0 (z : Store) : (s_332 z) 481 = v_331_0 z := by
   unfold s_332
   dsimp only [pL, pmNode_399, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_331_0, r_331_0 z, r_331_1 z] <;> rfl
 #a w_331_0
 theorem h_331_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_331_0 z).shape = [1, 8, 64] := by
   unfold v_331_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_322_1 z z_]
 #a h_331_0
 attribute [local irreducible] v_331_0
 attribute [local irreducible] s_332
 theorem n_328_332 (z : Store) (tid : Tid) (h : tid ∉ ([174, 172, 39, 171, 35, 37, 481] : List Tid)) : (s_332 z) tid = (s_328 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_328 z) (k_329 z)) (pF _ _ _ _ _ (k_330 z) (k_331 z)) tid h
 #a n_328_332
 theorem r_332_0 (z : Store) : (s_332 z) 481 = (v_331_0 z) := w_331_0 z
 #a r_332_0
 theorem r_332_1 (z : Store) : (s_332 z) 478 = (v_96_0 z) := pR (n_328_332 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_104_112 z) (pR (n_100_104 z) (pR (k_99 z) (pR (k_98 z) (pR (k_97 z) (r_97_0 z))))))))))
 #a r_332_1
 theorem r_332_2 (z : Store) : (s_332 z) 311 = (z 311) := pR (n_328_332 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_104_112 z) (pR (n_100_104 z) (pR (k_99 z) (pR (k_98 z) (pR (k_97 z) (r_97_1 z))))))))))
 #a r_332_2
 def v_332_0 (z : Store) : Tensor := (bw_linear (v_331_0 z) (v_96_0 z) (z 311)).1
 def v_332_1 (z : Store) : Tensor := (bw_linear (v_331_0 z) (v_96_0 z) (z 311)).2
 def s_333 (z : Store) : Store := storeSet (s_332 z) [(479, (bw_linear ((s_332 z) 481) ((s_332 z) 478) ((s_332 z) 311)).1), (344, (bw_linear ((s_332 z) 481) ((s_332 z) 478) ((s_332 z) 311)).2)]
 theorem t_332 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_400) (pmPeers pmNode_400) (s_332 z) pmNode_400 none = some (s_333 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_332
 theorem k_332 (z : Store) (tid : Tid) (h : tid ∉ [479, 344]) : (s_333 z) tid = (s_332 z) tid := by
   unfold s_333
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_332
 theorem w_332_0 (z : Store) : (s_333 z) 479 = v_332_0 z := by
   unfold s_333
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_332_0, r_332_0 z, r_332_1 z, r_332_2 z] <;> rfl
 #a w_332_0
 theorem h_332_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_332_0 z).shape = [1, 8, 256] := by
   unfold v_332_0
   exact bw_linear_3d_fst_shape 1 8 64 256 (v_331_0 z) (v_96_0 z) (z 311) (h_331_0 z z_) (h_96_0 z z_) (i_23 z z_)
 #a h_332_0
 attribute [local irreducible] v_332_0
 theorem w_332_1 (z : Store) : (s_333 z) 344 = v_332_1 z := by
   unfold s_333
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_332_1, r_332_0 z, r_332_1 z, r_332_2 z] <;> rfl
 #a w_332_1
 theorem h_332_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_332_1 z).shape = [64, 256] := by
   unfold v_332_1
   exact bw_linear_3d_snd_shape 1 8 64 256 (v_331_0 z) (v_96_0 z) (z 311) (h_331_0 z z_) (h_96_0 z z_) (i_23 z z_)
 #a h_332_1
 attribute [local irreducible] v_332_1
 attribute [local irreducible] s_333
 theorem r_333_0 (z : Store) : (s_333 z) 479 = (v_332_0 z) := w_332_0 z
 #a r_333_0
 theorem r_333_1 (z : Store) : (s_333 z) 476 = (v_95_0 z) := pR (k_332 z) (pR (n_328_332 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (r_96_0 z))))))
 #a r_333_1
 def v_333_0 (z : Store) : Tensor := bw_gelu (v_332_0 z) (v_95_0 z)
 def s_334 (z : Store) : Store := storeSet (s_333 z) [(477, bw_gelu ((s_333 z) 479) ((s_333 z) 476))]
 theorem t_333 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_401) (pmPeers pmNode_401) (s_333 z) pmNode_401 none = some (s_334 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_333
 theorem k_333 (z : Store) (tid : Tid) (h : tid ∉ [477]) : (s_334 z) tid = (s_333 z) tid := by
   unfold s_334
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_333
 theorem w_333_0 (z : Store) : (s_334 z) 477 = v_333_0 z := by
   unfold s_334
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_333_0, r_333_0 z, r_333_1 z] <;> rfl
 #a w_333_0
 theorem h_333_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_333_0 z).shape = [1, 8, 256] := by
   unfold v_333_0
   exact h_95_0 z z_
 #a h_333_0
 attribute [local irreducible] v_333_0
 attribute [local irreducible] s_334
 theorem r_334_0 (z : Store) : (s_334 z) 477 = (v_333_0 z) := w_333_0 z
 #a r_334_0
 theorem r_334_1 (z : Store) : (s_334 z) 473 = (v_94_0 z) := pR (k_333 z) (pR (k_332 z) (pR (n_328_332 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (k_95 z) (r_95_0 z))))))))
 #a r_334_1
 theorem r_334_2 (z : Store) : (s_334 z) 310 = (z 310) := pR (k_333 z) (pR (k_332 z) (pR (n_328_332 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (k_95 z) (r_95_1 z))))))))
 #a r_334_2
 def v_334_0 (z : Store) : Tensor := (bw_linear (v_333_0 z) (v_94_0 z) (z 310)).1
 def v_334_1 (z : Store) : Tensor := (bw_linear (v_333_0 z) (v_94_0 z) (z 310)).2
 def s_335 (z : Store) : Store := storeSet (s_334 z) [(475, (bw_linear ((s_334 z) 477) ((s_334 z) 473) ((s_334 z) 310)).1), (342, (bw_linear ((s_334 z) 477) ((s_334 z) 473) ((s_334 z) 310)).2)]
 theorem t_334 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_402) (pmPeers pmNode_402) (s_334 z) pmNode_402 none = some (s_335 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_334
 theorem k_334 (z : Store) (tid : Tid) (h : tid ∉ [475, 342]) : (s_335 z) tid = (s_334 z) tid := by
   unfold s_335
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_334
 theorem w_334_0 (z : Store) : (s_335 z) 475 = v_334_0 z := by
   unfold s_335
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_334_0, r_334_0 z, r_334_1 z, r_334_2 z] <;> rfl
 #a w_334_0
 theorem h_334_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_334_0 z).shape = [1, 8, 64] := by
   unfold v_334_0
   exact bw_linear_3d_fst_shape 1 8 256 64 (v_333_0 z) (v_94_0 z) (z 310) (h_333_0 z z_) (h_94_0 z z_) (i_22 z z_)
 #a h_334_0
 attribute [local irreducible] v_334_0
 theorem w_334_1 (z : Store) : (s_335 z) 342 = v_334_1 z := by
   unfold s_335
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_334_1, r_334_0 z, r_334_1 z, r_334_2 z] <;> rfl
 #a w_334_1
 theorem h_334_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_334_1 z).shape = [256, 64] := by
   unfold v_334_1
   exact bw_linear_3d_snd_shape 1 8 256 64 (v_333_0 z) (v_94_0 z) (z 310) (h_333_0 z z_) (h_94_0 z z_) (i_22 z z_)
 #a h_334_1
 attribute [local irreducible] v_334_1
 attribute [local irreducible] s_335
 theorem r_335_0 (z : Store) : (s_335 z) 475 = (v_334_0 z) := w_334_0 z
 #a r_335_0
 theorem r_335_1 (z : Store) : (s_335 z) 472 = (v_93_0 z) := pR (k_334 z) (pR (k_333 z) (pR (k_332 z) (pR (n_328_332 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (k_95 z) (pR (k_94 z) (r_94_0 z))))))))))
 #a r_335_1
 theorem r_335_2 (z : Store) : (s_335 z) 308 = (z 308) := pR (k_334 z) (pR (k_333 z) (pR (k_332 z) (pR (n_328_332 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (k_95 z) (pR (k_94 z) (r_94_1 z))))))))))
 #a r_335_2
 theorem r_335_3 (z : Store) : (s_335 z) 309 = (z 309) := pR (k_334 z) (pR (k_333 z) (pR (k_332 z) (pR (n_328_332 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (k_95 z) (pR (k_94 z) (r_94_2 z))))))))))
 #a r_335_3
 def v_335_0 (z : Store) : Tensor := (bw_layernorm (v_334_0 z) (v_93_0 z) (z 308) (z 309)).1
 def v_335_1 (z : Store) : Tensor := (bw_layernorm (v_334_0 z) (v_93_0 z) (z 308) (z 309)).2.1
 def v_335_2 (z : Store) : Tensor := (bw_layernorm (v_334_0 z) (v_93_0 z) (z 308) (z 309)).2.2
 def s_336 (z : Store) : Store := storeSet (s_335 z) [(474, (bw_layernorm ((s_335 z) 475) ((s_335 z) 472) ((s_335 z) 308) ((s_335 z) 309)).1), (338, (bw_layernorm ((s_335 z) 475) ((s_335 z) 472) ((s_335 z) 308) ((s_335 z) 309)).2.1), (340, (bw_layernorm ((s_335 z) 475) ((s_335 z) 472) ((s_335 z) 308) ((s_335 z) 309)).2.2)]
 theorem t_335 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_403) (pmPeers pmNode_403) (s_335 z) pmNode_403 none = some (s_336 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_335
 theorem k_335 (z : Store) (tid : Tid) (h : tid ∉ [474, 338, 340]) : (s_336 z) tid = (s_335 z) tid := by
   unfold s_336
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_335
 theorem w_335_0 (z : Store) : (s_336 z) 474 = v_335_0 z := by
   unfold s_336
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_335_0, r_335_0 z, r_335_1 z, r_335_2 z, r_335_3 z] <;> rfl
 #a w_335_0
 theorem h_335_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_335_0 z).shape = [1, 8, 64] := by
   unfold v_335_0
   rw [bw_layernorm_dx_shape (v_334_0 z) (v_93_0 z) (z 308) (z 309) 64 [8, 1] (by rw [h_93_0 z z_]; rfl)]
   exact h_93_0 z z_
 #a h_335_0
 attribute [local irreducible] v_335_0
 theorem w_335_1 (z : Store) : (s_336 z) 338 = v_335_1 z := by
   unfold s_336
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_335_1, r_335_0 z, r_335_1 z, r_335_2 z, r_335_3 z] <;> rfl
 #a w_335_1
 theorem h_335_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_335_1 z).shape = [64] := by
   unfold v_335_1
   rw [bw_layernorm_dw_shape (v_334_0 z) (v_93_0 z) (z 308) (z 309) 64 [8, 1] (by rw [h_93_0 z z_]; rfl)]
   exact i_20 z z_
 #a h_335_1
 attribute [local irreducible] v_335_1
 theorem w_335_2 (z : Store) : (s_336 z) 340 = v_335_2 z := by
   unfold s_336
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_335_2, r_335_0 z, r_335_1 z, r_335_2 z, r_335_3 z] <;> rfl
 #a w_335_2
 theorem h_335_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_335_2 z).shape = [64] := by
   unfold v_335_2
   rw [bw_layernorm_db_shape (v_334_0 z) (v_93_0 z) (z 308) (z 309) 64 [8, 1] (by rw [h_93_0 z z_]; rfl)]
   exact i_21 z z_
 #a h_335_2
 attribute [local irreducible] v_335_2
 attribute [local irreducible] s_336
 theorem n_332_336 (z : Store) (tid : Tid) (h : tid ∉ ([479, 344, 477, 475, 342, 474, 338, 340] : List Tid)) : (s_336 z) tid = (s_332 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_332 z) (k_333 z)) (pF _ _ _ _ _ (k_334 z) (k_335 z)) tid h
 #a n_332_336
 theorem r_336_0 (z : Store) : (s_336 z) 171 = (v_330_0 z) := pR (n_332_336 z) (pR (k_331 z) (w_330_0 z))
 #a r_336_0
 theorem r_336_1 (z : Store) : (s_336 z) 474 = (v_335_0 z) := w_335_0 z
 #a r_336_1
 def v_336_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_330_0 z), (v_335_0 z)]
 theorem g_336 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_168) (s_336 z) pmNode_168 1 2 290 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_168, r_336_0 z, r_336_1 z, h_330_0 z z_, h_335_0 z z_]
 #a g_336
 def s_337 (z : Store) : Store := pL [0, 1] (s_336 z) pmNode_168 1 2
 theorem t_336 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_168) (pmPeers pmNode_168) (s_336 z) pmNode_168 none = some (s_337 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_168) (s_336 z) pmNode_168).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 290 (by decide) (g_336 z z_)]
   rfl
 #a t_336
 theorem k_336 (z : Store) (tid : Tid) (h : tid ∉ [290]) : (s_337 z) tid = (s_336 z) tid := by
   unfold s_337
   dsimp only [pL, pmNode_168, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_336
 theorem w_336_0 (z : Store) : (s_337 z) 290 = v_336_0 z := by
   unfold s_337
   dsimp only [pL, pmNode_168, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_336_0, r_336_0 z, r_336_1 z] <;> rfl
 #a w_336_0
 theorem h_336_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_336_0 z).shape = [1, 16, 32] := by
   unfold v_336_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_330_0 z z_]
 #a h_336_0
 attribute [local irreducible] v_336_0
 attribute [local irreducible] s_337
 theorem n_328_336 (z : Store) (tid : Tid) (h : tid ∉ ([174, 172, 39, 171, 35, 37, 481, 479, 344, 477, 475, 342, 474, 338, 340] : List Tid)) : (s_336 z) tid = (s_328 z) tid := by
   exact pF _ _ _ _ _ (n_328_332 z) (n_332_336 z) tid h
 #a n_328_336
 theorem r_337_0 (z : Store) : (s_337 z) 290 = (v_336_0 z) := w_336_0 z
 #a r_337_0
 theorem r_337_1 (z : Store) : (s_337 z) 182 = (v_322_0 z) := pR (k_336 z) (pR (n_328_336 z) (pR (n_324_328 z) (pR (k_323 z) (w_322_0 z))))
 #a r_337_1
 def v_337_0 (z : Store) : Tensor := tensorSum [(v_336_0 z), (v_322_0 z)]
 def s_338 (z : Store) : Store := storeSet (s_337 z) [(168, tensorSum [((s_337 z) 290), ((s_337 z) 182)])]
 theorem t_337 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_169) (pmPeers pmNode_169) (s_337 z) pmNode_169 none = some (s_338 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_337
 theorem k_337 (z : Store) (tid : Tid) (h : tid ∉ [168]) : (s_338 z) tid = (s_337 z) tid := by
   unfold s_338
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_337
 theorem w_337_0 (z : Store) : (s_338 z) 168 = v_337_0 z := by
   unfold s_338
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_337_0, r_337_0 z, r_337_1 z] <;> rfl
 #a w_337_0
 theorem h_337_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_337_0 z).shape = [1, 16, 32] := by
   unfold v_337_0
   rw [tensorSum_shape]
   exact h_336_0 z z_
 #a h_337_0
 attribute [local irreducible] v_337_0
 attribute [local irreducible] s_338
 theorem n_320_336 (z : Store) (tid : Tid) (h : tid ∉ ([292, 184, 182, 183, 595, 487, 485, 486, 178, 176, 41, 174, 172, 39, 171, 35, 37, 481, 479, 344, 477, 475, 342, 474, 338, 340] : List Tid)) : (s_336 z) tid = (s_320 z) tid := by
   exact pF _ _ _ _ _ (n_320_328 z) (n_328_336 z) tid h
 #a n_320_336
 record_prefix_opacity v_331_0 s_332 v_332_0 v_332_1 s_333 v_333_0 s_334 v_334_0 v_334_1 s_335 v_335_0 v_335_1 v_335_2 s_336 v_336_0 s_337 v_337_0 s_338

 end
 end TrainVerify.Denote.RuntimeWorld
