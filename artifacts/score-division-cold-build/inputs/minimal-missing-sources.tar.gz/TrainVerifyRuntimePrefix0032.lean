import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0031
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_245_0 (z : Store) : (s_245 z) 560 = (v_244_0 z) := w_244_0 z
 #a r_245_0
 theorem r_245_1 (z : Store) : (s_245 z) 555 = (v_103_1 z) := pR (k_244 z) (pR (n_240_244 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_184_192 z) (pR (k_183 z) (pR (k_182 z) (r_182_0 z)))))))
 #a r_245_1
 theorem r_245_2 (z : Store) : (s_245 z) 556 = (v_181_0 z) := pR (k_244 z) (pR (n_240_244 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_184_192 z) (pR (k_183 z) (pR (k_182 z) (r_182_1 z)))))))
 #a r_245_2
 def v_245_0 (z : Store) : Tensor := (bw_add2 (v_244_0 z) (v_103_1 z) (v_181_0 z)).1
 def v_245_1 (z : Store) : Tensor := (bw_add2 (v_244_0 z) (v_103_1 z) (v_181_0 z)).2
 def s_246 (z : Store) : Store := storeSet (s_245 z) [(558, (bw_add2 ((s_245 z) 560) ((s_245 z) 555) ((s_245 z) 556)).1), (559, (bw_add2 ((s_245 z) 560) ((s_245 z) 555) ((s_245 z) 556)).2)]
 theorem t_245 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_358) (pmPeers pmNode_358) (s_245 z) pmNode_358 none = some (s_246 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_245
 theorem k_245 (z : Store) (tid : Tid) (h : tid ∉ [558, 559]) : (s_246 z) tid = (s_245 z) tid := by
   unfold s_246
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_245
 theorem w_245_0 (z : Store) : (s_246 z) 558 = v_245_0 z := by
   unfold s_246
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_245_0, r_245_0 z, r_245_1 z, r_245_2 z] <;> rfl
 #a w_245_0
 theorem h_245_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_245_0 z).shape = [1, 16, 32] := by
   unfold v_245_0
   exact h_103_1 z z_
 #a h_245_0
 attribute [local irreducible] v_245_0
 theorem w_245_1 (z : Store) : (s_246 z) 559 = v_245_1 z := by
   unfold s_246
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_245_1, r_245_0 z, r_245_1 z, r_245_2 z] <;> rfl
 #a w_245_1
 theorem h_245_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_245_1 z).shape = [1, 16, 32] := by
   unfold v_245_1
   exact h_181_0 z z_
 #a h_245_1
 attribute [local irreducible] v_245_1
 attribute [local irreducible] s_246
 theorem r_246_0 (z : Store) : (s_246 z) 256 = (v_242_1 z) := pR (k_245 z) (pR (k_244 z) (pR (k_243 z) (w_242_1 z)))
 #a r_246_0
 theorem r_246_1 (z : Store) : (s_246 z) 559 = (v_245_1 z) := w_245_1 z
 #a r_246_1
 def v_246_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 0 [(v_242_1 z), (v_245_1 z)]
 def s_247 (z : Store) : Store := storeSet (s_246 z) [(84, allGatherPrimDimN 2 2 0 [((s_246 z) 256), ((s_246 z) 559)])]
 theorem t_246 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_123) (pmPeers pmNode_123) (s_246 z) pmNode_123 none = some (s_247 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_246 z) pmNode_123 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_246
 theorem k_246 (z : Store) (tid : Tid) (h : tid ∉ [84]) : (s_247 z) tid = (s_246 z) tid := by
   unfold s_247
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_246
 theorem w_246_0 (z : Store) : (s_247 z) 84 = v_246_0 z := by
   unfold s_247
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_246_0, r_246_0 z, r_246_1 z] <;> rfl
 #a w_246_0
 theorem h_246_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_246_0 z).shape = [1, 16, 64] := by
   unfold v_246_0
   exact allGatherPrimDimN_shape 2 2 [(v_242_1 z), (v_245_1 z)] [1, 16, 32] (h_242_1 z z_)
 #a h_246_0
 attribute [local irreducible] v_246_0
 attribute [local irreducible] s_247
 theorem r_247_0 (z : Store) : (s_247 z) 84 = (v_246_0 z) := w_246_0 z
 #a r_247_0
 theorem r_247_1 (z : Store) : (s_247 z) 248 = (v_173_0 z) := pR (k_246 z) (pR (k_245 z) (pR (k_244 z) (pR (n_240_244 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_176_192 z) (pR (k_175 z) (pR (k_174 z) (r_174_0 z)))))))))
 #a r_247_1
 theorem r_247_2 (z : Store) : (s_247 z) 56 = (z 56) := pR (k_246 z) (pR (k_245 z) (pR (k_244 z) (pR (n_240_244 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_176_192 z) (pR (k_175 z) (pR (k_174 z) (r_174_1 z)))))))))
 #a r_247_2
 def v_247_0 (z : Store) : Tensor := (bw_linear (v_246_0 z) (v_173_0 z) (z 56)).1
 def v_247_1 (z : Store) : Tensor := (bw_linear (v_246_0 z) (v_173_0 z) (z 56)).2
 def s_248 (z : Store) : Store := storeSet (s_247 z) [(250, (bw_linear ((s_247 z) 84) ((s_247 z) 248) ((s_247 z) 56)).1), (57, (bw_linear ((s_247 z) 84) ((s_247 z) 248) ((s_247 z) 56)).2)]
 theorem t_247 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_124) (pmPeers pmNode_124) (s_247 z) pmNode_124 none = some (s_248 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_247
 theorem k_247 (z : Store) (tid : Tid) (h : tid ∉ [250, 57]) : (s_248 z) tid = (s_247 z) tid := by
   unfold s_248
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_247
 theorem w_247_0 (z : Store) : (s_248 z) 250 = v_247_0 z := by
   unfold s_248
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_247_0, r_247_0 z, r_247_1 z, r_247_2 z] <;> rfl
 #a w_247_0
 theorem h_247_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_247_0 z).shape = [1, 16, 32] := by
   unfold v_247_0
   exact bw_linear_3d_fst_shape 1 16 64 32 (v_246_0 z) (v_173_0 z) (z 56) (h_246_0 z z_) (h_173_0 z z_) (i_34 z z_)
 #a h_247_0
 attribute [local irreducible] v_247_0
 theorem w_247_1 (z : Store) : (s_248 z) 57 = v_247_1 z := by
   unfold s_248
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_247_1, r_247_0 z, r_247_1 z, r_247_2 z] <;> rfl
 #a w_247_1
 theorem h_247_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_247_1 z).shape = [64, 32] := by
   unfold v_247_1
   exact bw_linear_3d_snd_shape 1 16 64 32 (v_246_0 z) (v_173_0 z) (z 56) (h_246_0 z z_) (h_173_0 z z_) (i_34 z z_)
 #a h_247_1
 attribute [local irreducible] v_247_1
 attribute [local irreducible] s_248
 theorem n_244_248 (z : Store) (tid : Tid) (h : tid ∉ ([560, 558, 559, 84, 250, 57] : List Tid)) : (s_248 z) tid = (s_244 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_244 z) (k_245 z)) (pF _ _ _ _ _ (k_246 z) (k_247 z)) tid h
 #a n_244_248
 theorem n_240_248 (z : Store) (tid : Tid) (h : tid ∉ ([300, 257, 255, 256, 603, 560, 558, 559, 84, 250, 57] : List Tid)) : (s_248 z) tid = (s_240 z) tid := by
   exact pF _ _ _ _ _ (n_240_244 z) (n_244_248 z) tid h
 #a n_240_248
 theorem r_248_0 (z : Store) : (s_248 z) 250 = (v_247_0 z) := w_247_0 z
 #a r_248_0
 theorem r_248_1 (z : Store) : (s_248 z) 247 = (v_172_0 z) := pR (n_240_248 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_176_192 z) (pR (k_175 z) (pR (k_174 z) (pR (k_173 z) (r_173_0 z)))))))
 #a r_248_1
 def v_248_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_247_0 z)
 def s_249 (z : Store) : Store := storeSet (s_248 z) [(249, fw_view [1, 16, 2, 16] ((s_248 z) 250))]
 theorem t_248 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_125) (pmPeers pmNode_125) (s_248 z) pmNode_125 none = some (s_249 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_248
 theorem k_248 (z : Store) (tid : Tid) (h : tid ∉ [249]) : (s_249 z) tid = (s_248 z) tid := by
   unfold s_249
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_248
 theorem w_248_0 (z : Store) : (s_249 z) 249 = v_248_0 z := by
   unfold s_249
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_248_0, r_248_0 z, r_248_1 z] <;> rfl
 #a w_248_0
 theorem h_248_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_248_0 z).shape = [1, 16, 2, 16] := by
   unfold v_248_0
   rfl
 #a h_248_0
 attribute [local irreducible] v_248_0
 attribute [local irreducible] s_249
 theorem r_249_0 (z : Store) : (s_249 z) 256 = (v_242_1 z) := pR (k_248 z) (pR (k_247 z) (pR (k_246 z) (r_246_0 z)))
 #a r_249_0
 theorem r_249_1 (z : Store) : (s_249 z) 559 = (v_245_1 z) := pR (k_248 z) (pR (k_247 z) (pR (k_246 z) (r_246_1 z)))
 #a r_249_1
 def v_249_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 1 [(v_242_1 z), (v_245_1 z)]
 def s_250 (z : Store) : Store := storeSet (s_249 z) [(387, allGatherPrimDimN 2 2 1 [((s_249 z) 256), ((s_249 z) 559)])]
 theorem t_249 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_359) (pmPeers pmNode_359) (s_249 z) pmNode_359 none = some (s_250 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_249 z) pmNode_359 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_249
 theorem k_249 (z : Store) (tid : Tid) (h : tid ∉ [387]) : (s_250 z) tid = (s_249 z) tid := by
   unfold s_250
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_249
 theorem w_249_0 (z : Store) : (s_250 z) 387 = v_249_0 z := by
   unfold s_250
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_249_0, r_249_0 z, r_249_1 z] <;> rfl
 #a w_249_0
 theorem h_249_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_249_0 z).shape = [1, 16, 64] := by
   unfold v_249_0
   exact allGatherPrimDimN_shape 2 2 [(v_242_1 z), (v_245_1 z)] [1, 16, 32] (h_242_1 z z_)
 #a h_249_0
 attribute [local irreducible] v_249_0
 attribute [local irreducible] s_250
 theorem r_250_0 (z : Store) : (s_250 z) 387 = (v_249_0 z) := w_249_0 z
 #a r_250_0
 theorem r_250_1 (z : Store) : (s_250 z) 551 = (v_176_0 z) := pR (k_249 z) (pR (k_248 z) (pR (n_240_248 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_184_192 z) (pR (n_180_184 z) (pR (k_179 z) (pR (k_178 z) (pR (k_177 z) (r_177_0 z))))))))))
 #a r_250_1
 theorem r_250_2 (z : Store) : (s_250 z) 359 = (z 359) := pR (k_249 z) (pR (k_248 z) (pR (n_240_248 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_184_192 z) (pR (n_180_184 z) (pR (k_179 z) (pR (k_178 z) (pR (k_177 z) (r_177_1 z))))))))))
 #a r_250_2
 def v_250_0 (z : Store) : Tensor := (bw_linear (v_249_0 z) (v_176_0 z) (z 359)).1
 def v_250_1 (z : Store) : Tensor := (bw_linear (v_249_0 z) (v_176_0 z) (z 359)).2
 def s_251 (z : Store) : Store := storeSet (s_250 z) [(553, (bw_linear ((s_250 z) 387) ((s_250 z) 551) ((s_250 z) 359)).1), (360, (bw_linear ((s_250 z) 387) ((s_250 z) 551) ((s_250 z) 359)).2)]
 theorem t_250 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_360) (pmPeers pmNode_360) (s_250 z) pmNode_360 none = some (s_251 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_250
 theorem k_250 (z : Store) (tid : Tid) (h : tid ∉ [553, 360]) : (s_251 z) tid = (s_250 z) tid := by
   unfold s_251
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_250
 theorem w_250_0 (z : Store) : (s_251 z) 553 = v_250_0 z := by
   unfold s_251
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_250_0, r_250_0 z, r_250_1 z, r_250_2 z] <;> rfl
 #a w_250_0
 theorem h_250_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_250_0 z).shape = [1, 16, 32] := by
   unfold v_250_0
   exact bw_linear_3d_fst_shape 1 16 64 32 (v_249_0 z) (v_176_0 z) (z 359) (h_249_0 z z_) (h_176_0 z z_) (i_35 z z_)
 #a h_250_0
 attribute [local irreducible] v_250_0
 theorem w_250_1 (z : Store) : (s_251 z) 360 = v_250_1 z := by
   unfold s_251
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_250_1, r_250_0 z, r_250_1 z, r_250_2 z] <;> rfl
 #a w_250_1
 theorem h_250_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_250_1 z).shape = [64, 32] := by
   unfold v_250_1
   exact bw_linear_3d_snd_shape 1 16 64 32 (v_249_0 z) (v_176_0 z) (z 359) (h_249_0 z z_) (h_176_0 z z_) (i_35 z z_)
 #a h_250_1
 attribute [local irreducible] v_250_1
 attribute [local irreducible] s_251
 theorem r_251_0 (z : Store) : (s_251 z) 553 = (v_250_0 z) := w_250_0 z
 #a r_251_0
 theorem r_251_1 (z : Store) : (s_251 z) 550 = (v_175_0 z) := pR (k_250 z) (pR (k_249 z) (pR (k_248 z) (pR (n_240_248 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_176_192 z) (r_176_0 z)))))))
 #a r_251_1
 def v_251_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_250_0 z)
 def s_252 (z : Store) : Store := storeSet (s_251 z) [(552, fw_view [1, 16, 2, 16] ((s_251 z) 553))]
 theorem t_251 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_361) (pmPeers pmNode_361) (s_251 z) pmNode_361 none = some (s_252 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_251
 theorem k_251 (z : Store) (tid : Tid) (h : tid ∉ [552]) : (s_252 z) tid = (s_251 z) tid := by
   unfold s_252
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_251
 theorem w_251_0 (z : Store) : (s_252 z) 552 = v_251_0 z := by
   unfold s_252
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_251_0, r_251_0 z, r_251_1 z] <;> rfl
 #a w_251_0
 theorem h_251_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_251_0 z).shape = [1, 16, 2, 16] := by
   unfold v_251_0
   rfl
 #a h_251_0
 attribute [local irreducible] v_251_0
 attribute [local irreducible] s_252
 theorem r_252_0 (z : Store) : (s_252 z) 249 = (v_248_0 z) := pR (k_251 z) (pR (k_250 z) (pR (k_249 z) (w_248_0 z)))
 #a r_252_0
 theorem r_252_1 (z : Store) : (s_252 z) 552 = (v_251_0 z) := w_251_0 z
 #a r_252_1
 def v_252_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_248_0 z), (v_251_0 z)]
 theorem g_252 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_126) (s_252 z) pmNode_126 2 1 246 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_126, r_252_0 z, r_252_1 z, h_248_0 z z_, h_251_0 z z_]
 #a g_252
 def s_253 (z : Store) : Store := pL [0, 1] (s_252 z) pmNode_126 2 1
 theorem t_252 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_126) (pmPeers pmNode_126) (s_252 z) pmNode_126 none = some (s_253 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_126) (s_252 z) pmNode_126).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 246 (by decide) (g_252 z z_)]
   rfl
 #a t_252
 theorem k_252 (z : Store) (tid : Tid) (h : tid ∉ [246]) : (s_253 z) tid = (s_252 z) tid := by
   unfold s_253
   dsimp only [pL, pmNode_126, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_252
 theorem w_252_0 (z : Store) : (s_253 z) 246 = v_252_0 z := by
   unfold s_253
   dsimp only [pL, pmNode_126, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_252_0, r_252_0 z, r_252_1 z] <;> rfl
 #a w_252_0
 theorem h_252_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_252_0 z).shape = [1, 8, 4, 16] := by
   unfold v_252_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_248_0 z z_]
 #a h_252_0
 attribute [local irreducible] v_252_0
 attribute [local irreducible] s_253
 theorem n_248_252 (z : Store) (tid : Tid) (h : tid ∉ ([249, 387, 553, 360, 552] : List Tid)) : (s_252 z) tid = (s_248 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_248 z) (k_249 z)) (pF _ _ _ _ _ (k_250 z) (k_251 z)) tid h
 #a n_248_252
 record_prefix_opacity v_245_0 v_245_1 s_246 v_246_0 s_247 v_247_0 v_247_1 s_248 v_248_0 s_249 v_249_0 s_250 v_250_0 v_250_1 s_251 v_251_0 s_252 v_252_0 s_253

 end
 end TrainVerify.Denote.RuntimeWorld
