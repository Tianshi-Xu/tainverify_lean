import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0089
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_712_0 (z : Store) : (s_712 z) 818 = (v_709_0 z) := pR (k_711 z) (pR (k_710 z) (w_709_0 z))
 #a r_712_0
 theorem r_712_1 (z : Store) : (s_712 z) 1121 = (v_711_0 z) := w_711_0 z
 #a r_712_1
 def v_712_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_709_0 z), (v_711_0 z)]
 theorem g_712 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_617) (s_712 z) pmNode_617 3 1 815 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_617, r_712_0 z, r_712_1 z, h_709_0 z z_, h_711_0 z z_]
 #a g_712
 def s_713 (z : Store) : Store := pL [2, 3] (s_712 z) pmNode_617 3 1
 theorem t_712 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_617) (pmPeers pmNode_617) (s_712 z) pmNode_617 none = some (s_713 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_617) (s_712 z) pmNode_617).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 815 (by decide) (g_712 z z_)]
   rfl
 #a t_712
 theorem k_712 (z : Store) (tid : Tid) (h : tid ∉ [815]) : (s_713 z) tid = (s_712 z) tid := by
   unfold s_713
   dsimp only [pL, pmNode_617, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_712
 theorem w_712_0 (z : Store) : (s_713 z) 815 = v_712_0 z := by
   unfold s_713
   dsimp only [pL, pmNode_617, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_712_0, r_712_0 z, r_712_1 z] <;> rfl
 #a w_712_0
 theorem h_712_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_712_0 z).shape = [1, 8, 4, 16] := by
   unfold v_712_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_709_0 z z_]
 #a h_712_0
 attribute [local irreducible] v_712_0
 attribute [local irreducible] s_713
 theorem n_708_712 (z : Store) (tid : Tid) (h : tid ∉ ([689, 818, 992, 1121] : List Tid)) : (s_712 z) tid = (s_708 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_708 z) (k_709 z)) (pF _ _ _ _ _ (k_710 z) (k_711 z)) tid h
 #a n_708_712
 theorem n_704_712 (z : Store) (tid : Tid) (h : tid ∉ ([823, 822, 1126, 1125, 689, 818, 992, 1121] : List Tid)) : (s_712 z) tid = (s_704 z) tid := by
   exact pF _ _ _ _ _ (n_704_708 z) (n_708_712 z) tid h
 #a n_704_712
 theorem r_713_0 (z : Store) : (s_713 z) 815 = (v_712_0 z) := w_712_0 z
 #a r_713_0
 theorem r_713_1 (z : Store) : (s_713 z) 812 = (v_550_0 z) := pR (k_712 z) (pR (n_704_712 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_560_576 z) (pR (n_552_560 z) (pR (k_551 z) (r_551_0 z)))))))
 #a r_713_1
 def v_713_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_712_0 z)
 def s_714 (z : Store) : Store := storeSet (s_713 z) [(814, fw_view [1, 8, 64] ((s_713 z) 815))]
 theorem t_713 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_618) (pmPeers pmNode_618) (s_713 z) pmNode_618 none = some (s_714 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_713
 theorem k_713 (z : Store) (tid : Tid) (h : tid ∉ [814]) : (s_714 z) tid = (s_713 z) tid := by
   unfold s_714
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_713
 theorem w_713_0 (z : Store) : (s_714 z) 814 = v_713_0 z := by
   unfold s_714
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_713_0, r_713_0 z, r_713_1 z] <;> rfl
 #a w_713_0
 theorem h_713_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_713_0 z).shape = [1, 8, 64] := by
   unfold v_713_0
   rfl
 #a h_713_0
 attribute [local irreducible] v_713_0
 attribute [local irreducible] s_714
 theorem r_714_0 (z : Store) : (s_714 z) 818 = (v_709_0 z) := pR (k_713 z) (pR (k_712 z) (r_712_0 z))
 #a r_714_0
 theorem r_714_1 (z : Store) : (s_714 z) 1121 = (v_711_0 z) := pR (k_713 z) (pR (k_712 z) (r_712_1 z))
 #a r_714_1
 def v_714_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_709_0 z), (v_711_0 z)]
 theorem g_714 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_853) (s_714 z) pmNode_853 3 1 1118 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_853, r_714_0 z, r_714_1 z, h_709_0 z z_, h_711_0 z z_]
 #a g_714
 def s_715 (z : Store) : Store := pL [2, 3] (s_714 z) pmNode_853 3 1
 theorem t_714 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_853) (pmPeers pmNode_853) (s_714 z) pmNode_853 none = some (s_715 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_853) (s_714 z) pmNode_853).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 1118 (by decide) (g_714 z z_)]
   rfl
 #a t_714
 theorem k_714 (z : Store) (tid : Tid) (h : tid ∉ [1118]) : (s_715 z) tid = (s_714 z) tid := by
   unfold s_715
   dsimp only [pL, pmNode_853, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_714
 theorem w_714_0 (z : Store) : (s_715 z) 1118 = v_714_0 z := by
   unfold s_715
   dsimp only [pL, pmNode_853, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_714_0, r_714_0 z, r_714_1 z] <;> rfl
 #a w_714_0
 theorem h_714_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_714_0 z).shape = [1, 8, 4, 16] := by
   unfold v_714_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_709_0 z z_]
 #a h_714_0
 attribute [local irreducible] v_714_0
 attribute [local irreducible] s_715
 theorem r_715_0 (z : Store) : (s_715 z) 1118 = (v_714_0 z) := w_714_0 z
 #a r_715_0
 theorem r_715_1 (z : Store) : (s_715 z) 1115 = (v_554_0 z) := pR (k_714 z) (pR (k_713 z) (pR (k_712 z) (pR (n_704_712 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_560_576 z) (pR (n_556_560 z) (pR (k_555 z) (r_555_0 z)))))))))
 #a r_715_1
 def v_715_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_714_0 z)
 def s_716 (z : Store) : Store := storeSet (s_715 z) [(1117, fw_view [1, 8, 64] ((s_715 z) 1118))]
 theorem t_715 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_854) (pmPeers pmNode_854) (s_715 z) pmNode_854 none = some (s_716 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_715
 theorem k_715 (z : Store) (tid : Tid) (h : tid ∉ [1117]) : (s_716 z) tid = (s_715 z) tid := by
   unfold s_716
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_715
 theorem w_715_0 (z : Store) : (s_716 z) 1117 = v_715_0 z := by
   unfold s_716
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_715_0, r_715_0 z, r_715_1 z] <;> rfl
 #a w_715_0
 theorem h_715_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_715_0 z).shape = [1, 8, 64] := by
   unfold v_715_0
   rfl
 #a h_715_0
 attribute [local irreducible] v_715_0
 attribute [local irreducible] s_716
 theorem r_716_0 (z : Store) : (s_716 z) 814 = (v_713_0 z) := pR (k_715 z) (pR (k_714 z) (w_713_0 z))
 #a r_716_0
 theorem r_716_1 (z : Store) : (s_716 z) 1117 = (v_715_0 z) := w_715_0 z
 #a r_716_1
 def v_716_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_713_0 z), (v_715_0 z)]
 def s_717 (z : Store) : Store := storeSet (s_716 z) [(688, allGatherPrimDimN 1 2 0 [((s_716 z) 814), ((s_716 z) 1117)])]
 theorem t_716 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_619) (pmPeers pmNode_619) (s_716 z) pmNode_619 none = some (s_717 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_716 z) pmNode_619 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_716
 theorem k_716 (z : Store) (tid : Tid) (h : tid ∉ [688]) : (s_717 z) tid = (s_716 z) tid := by
   unfold s_717
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_716
 theorem w_716_0 (z : Store) : (s_717 z) 688 = v_716_0 z := by
   unfold s_717
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_716_0, r_716_0 z, r_716_1 z] <;> rfl
 #a w_716_0
 theorem h_716_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_716_0 z).shape = [1, 16, 64] := by
   unfold v_716_0
   exact allGatherPrimDimN_shape 1 2 [(v_713_0 z), (v_715_0 z)] [1, 8, 64] (h_713_0 z z_)
 #a h_716_0
 attribute [local irreducible] v_716_0
 attribute [local irreducible] s_717
 theorem n_712_716 (z : Store) (tid : Tid) (h : tid ∉ ([815, 814, 1118, 1117] : List Tid)) : (s_716 z) tid = (s_712 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_712 z) (k_713 z)) (pF _ _ _ _ _ (k_714 z) (k_715 z)) tid h
 #a n_712_716
 theorem r_717_0 (z : Store) : (s_717 z) 811 = (v_695_0 z) := pR (k_716 z) (pR (n_712_716 z) (pR (n_704_712 z) (pR (n_696_704 z) (w_695_0 z))))
 #a r_717_0
 theorem r_717_1 (z : Store) : (s_717 z) 808 = (v_548_0 z) := pR (k_716 z) (pR (n_712_716 z) (pR (n_704_712 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_560_576 z) (pR (n_552_560 z) (pR (k_551 z) (pR (k_550 z) (pR (k_549 z) (r_549_0 z))))))))))
 #a r_717_1
 def v_717_0 (z : Store) : Tensor := transposeAxes 1 2 (v_695_0 z)
 def s_718 (z : Store) : Store := storeSet (s_717 z) [(810, transposeAxes 1 2 ((s_717 z) 811))]
 theorem t_717 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_620) (pmPeers pmNode_620) (s_717 z) pmNode_620 none = some (s_718 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_717
 theorem k_717 (z : Store) (tid : Tid) (h : tid ∉ [810]) : (s_718 z) tid = (s_717 z) tid := by
   unfold s_718
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_717
 theorem w_717_0 (z : Store) : (s_718 z) 810 = v_717_0 z := by
   unfold s_718
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_717_0, r_717_0 z, r_717_1 z] <;> rfl
 #a w_717_0
 theorem h_717_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_717_0 z).shape = [1, 16, 2, 16] := by
   unfold v_717_0
   change listSwapAt _ _ _ = _
   rw [h_695_0 z z_]
   rfl
 #a h_717_0
 attribute [local irreducible] v_717_0
 attribute [local irreducible] s_718
 theorem r_718_0 (z : Store) : (s_718 z) 814 = (v_713_0 z) := pR (k_717 z) (pR (k_716 z) (r_716_0 z))
 #a r_718_0
 theorem r_718_1 (z : Store) : (s_718 z) 1117 = (v_715_0 z) := pR (k_717 z) (pR (k_716 z) (r_716_1 z))
 #a r_718_1
 def v_718_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_713_0 z), (v_715_0 z)]
 def s_719 (z : Store) : Store := storeSet (s_718 z) [(991, allGatherPrimDimN 1 2 1 [((s_718 z) 814), ((s_718 z) 1117)])]
 theorem t_718 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_855) (pmPeers pmNode_855) (s_718 z) pmNode_855 none = some (s_719 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_718 z) pmNode_855 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_718
 theorem k_718 (z : Store) (tid : Tid) (h : tid ∉ [991]) : (s_719 z) tid = (s_718 z) tid := by
   unfold s_719
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_718
 theorem w_718_0 (z : Store) : (s_719 z) 991 = v_718_0 z := by
   unfold s_719
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_718_0, r_718_0 z, r_718_1 z] <;> rfl
 #a w_718_0
 theorem h_718_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_718_0 z).shape = [1, 16, 64] := by
   unfold v_718_0
   exact allGatherPrimDimN_shape 1 2 [(v_713_0 z), (v_715_0 z)] [1, 8, 64] (h_713_0 z z_)
 #a h_718_0
 attribute [local irreducible] v_718_0
 attribute [local irreducible] s_719
 theorem r_719_0 (z : Store) : (s_719 z) 1114 = (v_697_0 z) := pR (k_718 z) (pR (k_717 z) (pR (k_716 z) (pR (n_712_716 z) (pR (n_704_712 z) (pR (n_700_704 z) (pR (k_699 z) (pR (k_698 z) (w_697_0 z))))))))
 #a r_719_0
 theorem r_719_1 (z : Store) : (s_719 z) 1111 = (v_552_0 z) := pR (k_718 z) (pR (k_717 z) (pR (k_716 z) (pR (n_712_716 z) (pR (n_704_712 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_560_576 z) (pR (n_556_560 z) (pR (k_555 z) (pR (k_554 z) (pR (k_553 z) (r_553_0 z))))))))))))
 #a r_719_1
 def v_719_0 (z : Store) : Tensor := transposeAxes 1 2 (v_697_0 z)
 def s_720 (z : Store) : Store := storeSet (s_719 z) [(1113, transposeAxes 1 2 ((s_719 z) 1114))]
 theorem t_719 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_856) (pmPeers pmNode_856) (s_719 z) pmNode_856 none = some (s_720 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_719
 theorem k_719 (z : Store) (tid : Tid) (h : tid ∉ [1113]) : (s_720 z) tid = (s_719 z) tid := by
   unfold s_720
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_719
 theorem w_719_0 (z : Store) : (s_720 z) 1113 = v_719_0 z := by
   unfold s_720
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_719_0, r_719_0 z, r_719_1 z] <;> rfl
 #a w_719_0
 theorem h_719_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_719_0 z).shape = [1, 16, 2, 16] := by
   unfold v_719_0
   change listSwapAt _ _ _ = _
   rw [h_697_0 z z_]
   rfl
 #a h_719_0
 attribute [local irreducible] v_719_0
 attribute [local irreducible] s_720
 theorem r_720_0 (z : Store) : (s_720 z) 810 = (v_717_0 z) := pR (k_719 z) (pR (k_718 z) (w_717_0 z))
 #a r_720_0
 theorem r_720_1 (z : Store) : (s_720 z) 1113 = (v_719_0 z) := w_719_0 z
 #a r_720_1
 def v_720_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_717_0 z), (v_719_0 z)]
 theorem g_720 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_621) (s_720 z) pmNode_621 2 1 807 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_621, r_720_0 z, r_720_1 z, h_717_0 z z_, h_719_0 z z_]
 #a g_720
 def s_721 (z : Store) : Store := pL [2, 3] (s_720 z) pmNode_621 2 1
 theorem t_720 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_621) (pmPeers pmNode_621) (s_720 z) pmNode_621 none = some (s_721 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_621) (s_720 z) pmNode_621).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 807 (by decide) (g_720 z z_)]
   rfl
 #a t_720
 theorem k_720 (z : Store) (tid : Tid) (h : tid ∉ [807]) : (s_721 z) tid = (s_720 z) tid := by
   unfold s_721
   dsimp only [pL, pmNode_621, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_720
 theorem w_720_0 (z : Store) : (s_721 z) 807 = v_720_0 z := by
   unfold s_721
   dsimp only [pL, pmNode_621, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_720_0, r_720_0 z, r_720_1 z] <;> rfl
 #a w_720_0
 theorem h_720_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_720_0 z).shape = [1, 8, 4, 16] := by
   unfold v_720_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_717_0 z z_]
 #a h_720_0
 attribute [local irreducible] v_720_0
 attribute [local irreducible] s_721
 theorem n_716_720 (z : Store) (tid : Tid) (h : tid ∉ ([688, 810, 991, 1113] : List Tid)) : (s_720 z) tid = (s_716 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_716 z) (k_717 z)) (pF _ _ _ _ _ (k_718 z) (k_719 z)) tid h
 #a n_716_720
 theorem n_712_720 (z : Store) (tid : Tid) (h : tid ∉ ([815, 814, 1118, 1117, 688, 810, 991, 1113] : List Tid)) : (s_720 z) tid = (s_712 z) tid := by
   exact pF _ _ _ _ _ (n_712_716 z) (n_716_720 z) tid h
 #a n_712_720
 record_prefix_opacity v_712_0 s_713 v_713_0 s_714 v_714_0 s_715 v_715_0 s_716 v_716_0 s_717 v_717_0 s_718 v_718_0 s_719 v_719_0 s_720 v_720_0 s_721

 end
 end TrainVerify.Denote.RuntimeWorld
