import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0030
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_238_0 (z : Store) : (s_238 z) 264 = (v_233_0 z) := pR (k_237 z) (pR (k_236 z) (r_236_0 z))
 #a r_238_0
 theorem r_238_1 (z : Store) : (s_238 z) 567 = (v_235_0 z) := pR (k_237 z) (pR (k_236 z) (r_236_1 z))
 #a r_238_1
 def v_238_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_233_0 z), (v_235_0 z)]
 theorem g_238 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_354) (s_238 z) pmNode_354 2 1 564 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_354, r_238_0 z, r_238_1 z, h_233_0 z z_, h_235_0 z z_]
 #a g_238
 def s_239 (z : Store) : Store := pL [0, 1] (s_238 z) pmNode_354 2 1
 theorem t_238 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_354) (pmPeers pmNode_354) (s_238 z) pmNode_354 none = some (s_239 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_354) (s_238 z) pmNode_354).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 564 (by decide) (g_238 z z_)]
   rfl
 #a t_238
 theorem k_238 (z : Store) (tid : Tid) (h : tid ∉ [564]) : (s_239 z) tid = (s_238 z) tid := by
   unfold s_239
   dsimp only [pL, pmNode_354, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_238
 theorem w_238_0 (z : Store) : (s_239 z) 564 = v_238_0 z := by
   unfold s_239
   dsimp only [pL, pmNode_354, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_238_0, r_238_0 z, r_238_1 z] <;> rfl
 #a w_238_0
 theorem h_238_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_238_0 z).shape = [1, 8, 64] := by
   unfold v_238_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_233_0 z z_]
 #a h_238_0
 attribute [local irreducible] v_238_0
 attribute [local irreducible] s_239
 theorem r_239_0 (z : Store) : (s_239 z) 564 = (v_238_0 z) := w_238_0 z
 #a r_239_0
 theorem r_239_1 (z : Store) : (s_239 z) 561 = (v_186_0 z) := pR (k_238 z) (pR (k_237 z) (pR (k_236 z) (pR (n_232_236 z) (pR (n_224_232 z) (pR (n_192_224 z) (pR (n_188_192 z) (pR (k_187 z) (r_187_0 z))))))))
 #a r_239_1
 theorem r_239_2 (z : Store) : (s_239 z) 314 = (z 314) := pR (k_238 z) (pR (k_237 z) (pR (k_236 z) (pR (n_232_236 z) (pR (n_224_232 z) (pR (n_192_224 z) (pR (n_188_192 z) (pR (k_187 z) (r_187_1 z))))))))
 #a r_239_2
 theorem r_239_3 (z : Store) : (s_239 z) 315 = (z 315) := pR (k_238 z) (pR (k_237 z) (pR (k_236 z) (pR (n_232_236 z) (pR (n_224_232 z) (pR (n_192_224 z) (pR (n_188_192 z) (pR (k_187 z) (r_187_2 z))))))))
 #a r_239_3
 def v_239_0 (z : Store) : Tensor := (bw_layernorm (v_238_0 z) (v_186_0 z) (z 314) (z 315)).1
 def v_239_1 (z : Store) : Tensor := (bw_layernorm (v_238_0 z) (v_186_0 z) (z 314) (z 315)).2.1
 def v_239_2 (z : Store) : Tensor := (bw_layernorm (v_238_0 z) (v_186_0 z) (z 314) (z 315)).2.2
 def s_240 (z : Store) : Store := storeSet (s_239 z) [(563, (bw_layernorm ((s_239 z) 564) ((s_239 z) 561) ((s_239 z) 314) ((s_239 z) 315)).1), (362, (bw_layernorm ((s_239 z) 564) ((s_239 z) 561) ((s_239 z) 314) ((s_239 z) 315)).2.1), (364, (bw_layernorm ((s_239 z) 564) ((s_239 z) 561) ((s_239 z) 314) ((s_239 z) 315)).2.2)]
 theorem t_239 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_355) (pmPeers pmNode_355) (s_239 z) pmNode_355 none = some (s_240 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_239
 theorem k_239 (z : Store) (tid : Tid) (h : tid ∉ [563, 362, 364]) : (s_240 z) tid = (s_239 z) tid := by
   unfold s_240
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_239
 theorem w_239_0 (z : Store) : (s_240 z) 563 = v_239_0 z := by
   unfold s_240
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_239_0, r_239_0 z, r_239_1 z, r_239_2 z, r_239_3 z] <;> rfl
 #a w_239_0
 theorem h_239_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_239_0 z).shape = [1, 8, 64] := by
   unfold v_239_0
   rw [bw_layernorm_dx_shape (v_238_0 z) (v_186_0 z) (z 314) (z 315) 64 [8, 1] (by rw [h_186_0 z z_]; rfl)]
   exact h_186_0 z z_
 #a h_239_0
 attribute [local irreducible] v_239_0
 theorem w_239_1 (z : Store) : (s_240 z) 362 = v_239_1 z := by
   unfold s_240
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_239_1, r_239_0 z, r_239_1 z, r_239_2 z, r_239_3 z] <;> rfl
 #a w_239_1
 theorem h_239_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_239_1 z).shape = [64] := by
   unfold v_239_1
   rw [bw_layernorm_dw_shape (v_238_0 z) (v_186_0 z) (z 314) (z 315) 64 [8, 1] (by rw [h_186_0 z z_]; rfl)]
   exact i_38 z z_
 #a h_239_1
 attribute [local irreducible] v_239_1
 theorem w_239_2 (z : Store) : (s_240 z) 364 = v_239_2 z := by
   unfold s_240
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_239_2, r_239_0 z, r_239_1 z, r_239_2 z, r_239_3 z] <;> rfl
 #a w_239_2
 theorem h_239_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_239_2 z).shape = [64] := by
   unfold v_239_2
   rw [bw_layernorm_db_shape (v_238_0 z) (v_186_0 z) (z 314) (z 315) 64 [8, 1] (by rw [h_186_0 z z_]; rfl)]
   exact i_39 z z_
 #a h_239_2
 attribute [local irreducible] v_239_2
 attribute [local irreducible] s_240
 theorem r_240_0 (z : Store) : (s_240 z) 260 = (v_237_0 z) := pR (k_239 z) (pR (k_238 z) (w_237_0 z))
 #a r_240_0
 theorem r_240_1 (z : Store) : (s_240 z) 563 = (v_239_0 z) := w_239_0 z
 #a r_240_1
 def v_240_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_237_0 z), (v_239_0 z)]
 theorem g_240 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_120) (s_240 z) pmNode_120 1 2 300 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_120, r_240_0 z, r_240_1 z, h_237_0 z z_, h_239_0 z z_]
 #a g_240
 def s_241 (z : Store) : Store := pL [0, 1] (s_240 z) pmNode_120 1 2
 theorem t_240 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_120) (pmPeers pmNode_120) (s_240 z) pmNode_120 none = some (s_241 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_120) (s_240 z) pmNode_120).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 300 (by decide) (g_240 z z_)]
   rfl
 #a t_240
 theorem k_240 (z : Store) (tid : Tid) (h : tid ∉ [300]) : (s_241 z) tid = (s_240 z) tid := by
   unfold s_241
   dsimp only [pL, pmNode_120, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_240
 theorem w_240_0 (z : Store) : (s_241 z) 300 = v_240_0 z := by
   unfold s_241
   dsimp only [pL, pmNode_120, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_240_0, r_240_0 z, r_240_1 z] <;> rfl
 #a w_240_0
 theorem h_240_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_240_0 z).shape = [1, 16, 32] := by
   unfold v_240_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_237_0 z z_]
 #a h_240_0
 attribute [local irreducible] v_240_0
 attribute [local irreducible] s_241
 theorem n_236_240 (z : Store) (tid : Tid) (h : tid ∉ ([261, 260, 59, 61, 564, 563, 362, 364] : List Tid)) : (s_240 z) tid = (s_236 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_236 z) (k_237 z)) (pF _ _ _ _ _ (k_238 z) (k_239 z)) tid h
 #a n_236_240
 theorem n_232_240 (z : Store) (tid : Tid) (h : tid ∉ ([85, 264, 64, 388, 567, 367, 261, 260, 59, 61, 564, 563, 362, 364] : List Tid)) : (s_240 z) tid = (s_232 z) tid := by
   exact pF _ _ _ _ _ (n_232_236 z) (n_236_240 z) tid h
 #a n_232_240
 theorem r_241_0 (z : Store) : (s_241 z) 300 = (v_240_0 z) := w_240_0 z
 #a r_241_0
 theorem r_241_1 (z : Store) : (s_241 z) 302 = (v_226_0 z) := pR (k_240 z) (pR (n_232_240 z) (pR (n_228_232 z) (pR (k_227 z) (w_226_0 z))))
 #a r_241_1
 def v_241_0 (z : Store) : Tensor := tensorSum [(v_240_0 z), (v_226_0 z)]
 def s_242 (z : Store) : Store := storeSet (s_241 z) [(257, tensorSum [((s_241 z) 300), ((s_241 z) 302)])]
 theorem t_241 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_121) (pmPeers pmNode_121) (s_241 z) pmNode_121 none = some (s_242 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_241
 theorem k_241 (z : Store) (tid : Tid) (h : tid ∉ [257]) : (s_242 z) tid = (s_241 z) tid := by
   unfold s_242
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_241
 theorem w_241_0 (z : Store) : (s_242 z) 257 = v_241_0 z := by
   unfold s_242
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_241_0, r_241_0 z, r_241_1 z] <;> rfl
 #a w_241_0
 theorem h_241_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_241_0 z).shape = [1, 16, 32] := by
   unfold v_241_0
   rw [tensorSum_shape]
   exact h_240_0 z z_
 #a h_241_0
 attribute [local irreducible] v_241_0
 attribute [local irreducible] s_242
 theorem n_224_240 (z : Store) (tid : Tid) (h : tid ∉ ([577, 371, 373, 576, 573, 302, 268, 66, 267, 605, 571, 369, 570, 85, 264, 64, 388, 567, 367, 261, 260, 59, 61, 564, 563, 362, 364] : List Tid)) : (s_240 z) tid = (s_224 z) tid := by
   exact pF _ _ _ _ _ (n_224_232 z) (n_232_240 z) tid h
 #a n_224_240
 theorem r_242_0 (z : Store) : (s_242 z) 257 = (v_241_0 z) := w_241_0 z
 #a r_242_0
 theorem r_242_1 (z : Store) : (s_242 z) 252 = (v_100_1 z) := pR (k_241 z) (pR (k_240 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_184_192 z) (pR (n_180_184 z) (pR (k_179 z) (r_179_0 z)))))))
 #a r_242_1
 theorem r_242_2 (z : Store) : (s_242 z) 253 = (v_178_0 z) := pR (k_241 z) (pR (k_240 z) (pR (n_224_240 z) (pR (n_192_224 z) (pR (n_184_192 z) (pR (n_180_184 z) (pR (k_179 z) (r_179_1 z)))))))
 #a r_242_2
 def v_242_0 (z : Store) : Tensor := (bw_add2 (v_241_0 z) (v_100_1 z) (v_178_0 z)).1
 def v_242_1 (z : Store) : Tensor := (bw_add2 (v_241_0 z) (v_100_1 z) (v_178_0 z)).2
 def s_243 (z : Store) : Store := storeSet (s_242 z) [(255, (bw_add2 ((s_242 z) 257) ((s_242 z) 252) ((s_242 z) 253)).1), (256, (bw_add2 ((s_242 z) 257) ((s_242 z) 252) ((s_242 z) 253)).2)]
 theorem t_242 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_122) (pmPeers pmNode_122) (s_242 z) pmNode_122 none = some (s_243 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_242
 theorem k_242 (z : Store) (tid : Tid) (h : tid ∉ [255, 256]) : (s_243 z) tid = (s_242 z) tid := by
   unfold s_243
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_242
 theorem w_242_0 (z : Store) : (s_243 z) 255 = v_242_0 z := by
   unfold s_243
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_242_0, r_242_0 z, r_242_1 z, r_242_2 z] <;> rfl
 #a w_242_0
 theorem h_242_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_242_0 z).shape = [1, 16, 32] := by
   unfold v_242_0
   exact h_100_1 z z_
 #a h_242_0
 attribute [local irreducible] v_242_0
 theorem w_242_1 (z : Store) : (s_243 z) 256 = v_242_1 z := by
   unfold s_243
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_242_1, r_242_0 z, r_242_1 z, r_242_2 z] <;> rfl
 #a w_242_1
 theorem h_242_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_242_1 z).shape = [1, 16, 32] := by
   unfold v_242_1
   exact h_178_0 z z_
 #a h_242_1
 attribute [local irreducible] v_242_1
 attribute [local irreducible] s_243
 theorem r_243_0 (z : Store) : (s_243 z) 260 = (v_237_0 z) := pR (k_242 z) (pR (k_241 z) (pR (k_240 z) (r_240_0 z)))
 #a r_243_0
 theorem r_243_1 (z : Store) : (s_243 z) 563 = (v_239_0 z) := pR (k_242 z) (pR (k_241 z) (pR (k_240 z) (r_240_1 z)))
 #a r_243_1
 def v_243_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_237_0 z), (v_239_0 z)]
 theorem g_243 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_356) (s_243 z) pmNode_356 1 2 603 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_356, r_243_0 z, r_243_1 z, h_237_0 z z_, h_239_0 z z_]
 #a g_243
 def s_244 (z : Store) : Store := pL [0, 1] (s_243 z) pmNode_356 1 2
 theorem t_243 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_356) (pmPeers pmNode_356) (s_243 z) pmNode_356 none = some (s_244 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_356) (s_243 z) pmNode_356).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 603 (by decide) (g_243 z z_)]
   rfl
 #a t_243
 theorem k_243 (z : Store) (tid : Tid) (h : tid ∉ [603]) : (s_244 z) tid = (s_243 z) tid := by
   unfold s_244
   dsimp only [pL, pmNode_356, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_243
 theorem w_243_0 (z : Store) : (s_244 z) 603 = v_243_0 z := by
   unfold s_244
   dsimp only [pL, pmNode_356, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_243_0, r_243_0 z, r_243_1 z] <;> rfl
 #a w_243_0
 theorem h_243_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_243_0 z).shape = [1, 16, 32] := by
   unfold v_243_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_237_0 z z_]
 #a h_243_0
 attribute [local irreducible] v_243_0
 attribute [local irreducible] s_244
 theorem n_240_244 (z : Store) (tid : Tid) (h : tid ∉ ([300, 257, 255, 256, 603] : List Tid)) : (s_244 z) tid = (s_240 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_240 z) (k_241 z)) (pF _ _ _ _ _ (k_242 z) (k_243 z)) tid h
 #a n_240_244
 theorem r_244_0 (z : Store) : (s_244 z) 603 = (v_243_0 z) := w_243_0 z
 #a r_244_0
 theorem r_244_1 (z : Store) : (s_244 z) 605 = (v_229_0 z) := pR (n_240_244 z) (pR (n_232_240 z) (pR (k_231 z) (pR (k_230 z) (w_229_0 z))))
 #a r_244_1
 def v_244_0 (z : Store) : Tensor := tensorSum [(v_243_0 z), (v_229_0 z)]
 def s_245 (z : Store) : Store := storeSet (s_244 z) [(560, tensorSum [((s_244 z) 603), ((s_244 z) 605)])]
 theorem t_244 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_357) (pmPeers pmNode_357) (s_244 z) pmNode_357 none = some (s_245 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_244
 theorem k_244 (z : Store) (tid : Tid) (h : tid ∉ [560]) : (s_245 z) tid = (s_244 z) tid := by
   unfold s_245
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_244
 theorem w_244_0 (z : Store) : (s_245 z) 560 = v_244_0 z := by
   unfold s_245
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_244_0, r_244_0 z, r_244_1 z] <;> rfl
 #a w_244_0
 theorem h_244_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_244_0 z).shape = [1, 16, 32] := by
   unfold v_244_0
   rw [tensorSum_shape]
   exact h_243_0 z z_
 #a h_244_0
 attribute [local irreducible] v_244_0
 attribute [local irreducible] s_245
 record_prefix_opacity v_238_0 s_239 v_239_0 v_239_1 v_239_2 s_240 v_240_0 s_241 v_241_0 s_242 v_242_0 v_242_1 s_243 v_243_0 s_244 v_244_0 s_245

 end
 end TrainVerify.Denote.RuntimeWorld
