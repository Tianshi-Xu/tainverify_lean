import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0078
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_631_0 (z : Store) : (s_631 z) 886 = (v_630_0 z) := w_630_0 z
 #a r_631_0
 def v_631_0 (z : Store) : Tensor := fw_sum (v_630_0 z)
 def s_632 (z : Store) : Store := storeSet (s_631 z) [(887, fw_sum ((s_631 z) 886))]
 theorem t_631 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_577) (pmPeers pmNode_577) (s_631 z) pmNode_577 none = some (s_632 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_631
 theorem k_631 (z : Store) (tid : Tid) (h : tid ∉ [887]) : (s_632 z) tid = (s_631 z) tid := by
   unfold s_632
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_631
 theorem w_631_0 (z : Store) : (s_632 z) 887 = v_631_0 z := by
   unfold s_632
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_631_0, r_631_0 z] <;> rfl
 #a w_631_0
 theorem h_631_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_631_0 z).shape = [1] := by
   unfold v_631_0
   rfl
 #a h_631_0
 attribute [local irreducible] v_631_0
 attribute [local irreducible] s_632
 theorem r_632_0 (z : Store) : (s_632 z) 883 = (v_627_0 z) := pR (k_631 z) (pR (k_630 z) (r_630_0 z))
 #a r_632_0
 theorem r_632_1 (z : Store) : (s_632 z) 1186 = (v_629_0 z) := pR (k_631 z) (pR (k_630 z) (r_630_1 z))
 #a r_632_1
 def v_632_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_627_0 z), (v_629_0 z)]
 theorem g_632 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_812) (s_632 z) pmNode_812 2 1 1189 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 128], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_812, r_632_0 z, r_632_1 z, h_627_0 z z_, h_629_0 z z_]
 #a g_632
 def s_633 (z : Store) : Store := pL [2, 3] (s_632 z) pmNode_812 2 1
 theorem t_632 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_812) (pmPeers pmNode_812) (s_632 z) pmNode_812 none = some (s_633 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_812) (s_632 z) pmNode_812).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1189 (by decide) (g_632 z z_)]
   rfl
 #a t_632
 theorem k_632 (z : Store) (tid : Tid) (h : tid ∉ [1189]) : (s_633 z) tid = (s_632 z) tid := by
   unfold s_633
   dsimp only [pL, pmNode_812, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_632
 theorem w_632_0 (z : Store) : (s_633 z) 1189 = v_632_0 z := by
   unfold s_633
   dsimp only [pL, pmNode_812, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_632_0, r_632_0 z, r_632_1 z] <;> rfl
 #a w_632_0
 theorem h_632_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_632_0 z).shape = [1, 8, 256] := by
   unfold v_632_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_627_0 z z_]
 #a h_632_0
 attribute [local irreducible] v_632_0
 attribute [local irreducible] s_633
 theorem r_633_0 (z : Store) : (s_633 z) 1189 = (v_632_0 z) := w_632_0 z
 #a r_633_0
 def v_633_0 (z : Store) : Tensor := fw_sum (v_632_0 z)
 def s_634 (z : Store) : Store := storeSet (s_633 z) [(1190, fw_sum ((s_633 z) 1189))]
 theorem t_633 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_813) (pmPeers pmNode_813) (s_633 z) pmNode_813 none = some (s_634 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_633
 theorem k_633 (z : Store) (tid : Tid) (h : tid ∉ [1190]) : (s_634 z) tid = (s_633 z) tid := by
   unfold s_634
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_633
 theorem w_633_0 (z : Store) : (s_634 z) 1190 = v_633_0 z := by
   unfold s_634
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_633_0, r_633_0 z] <;> rfl
 #a w_633_0
 theorem h_633_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_633_0 z).shape = [1] := by
   unfold v_633_0
   rfl
 #a h_633_0
 attribute [local irreducible] v_633_0
 attribute [local irreducible] s_634
 theorem r_634_0 (z : Store) : (s_634 z) 887 = (v_631_0 z) := pR (k_633 z) (pR (k_632 z) (w_631_0 z))
 #a r_634_0
 theorem r_634_1 (z : Store) : (s_634 z) 1190 = (v_633_0 z) := w_633_0 z
 #a r_634_1
 def v_634_0 (z : Store) : Tensor := allReducePrim 2 0 [(v_631_0 z), (v_633_0 z)]
 def s_635 (z : Store) : Store := storeSet (s_634 z) [(683, allReducePrim 2 0 [((s_634 z) 887), ((s_634 z) 1190)])]
 theorem t_634 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_578) (pmPeers pmNode_578) (s_634 z) pmNode_578 none = some (s_635 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_634 z) pmNode_578 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_634
 theorem k_634 (z : Store) (tid : Tid) (h : tid ∉ [683]) : (s_635 z) tid = (s_634 z) tid := by
   unfold s_635
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_634
 theorem w_634_0 (z : Store) : (s_635 z) 683 = v_634_0 z := by
   unfold s_635
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_634_0, r_634_0 z, r_634_1 z] <;> rfl
 #a w_634_0
 theorem h_634_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_634_0 z).shape = [1] := by
   unfold v_634_0
   rw [allReducePrim_shape _ _ _ (v_631_0 z) rfl]
   exact h_631_0 z z_
 #a h_634_0
 attribute [local irreducible] v_634_0
 attribute [local irreducible] s_635
 theorem n_628_632 (z : Store) (tid : Tid) (h : tid ∉ ([989, 1186, 886, 887] : List Tid)) : (s_632 z) tid = (s_628 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_628 z) (k_629 z)) (pF _ _ _ _ _ (k_630 z) (k_631 z)) tid h
 #a n_628_632
 theorem n_624_632 (z : Store) (tid : Tid) (h : tid ∉ ([1181, 1184, 686, 883, 989, 1186, 886, 887] : List Tid)) : (s_632 z) tid = (s_624 z) tid := by
   exact pF _ _ _ _ _ (n_624_628 z) (n_628_632 z) tid h
 #a n_624_632
 theorem r_635_0 (z : Store) : (s_635 z) 687 = unitSeed := pR (k_634 z) (pR (k_633 z) (pR (k_632 z) (pR (n_624_632 z) (pR (n_608_624 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (pmInitialWithSeeds_seed_2 z))))))))
 #a r_635_0
 theorem r_635_1 (z : Store) : (s_635 z) 886 = (v_630_0 z) := pR (k_634 z) (pR (k_633 z) (pR (k_632 z) (pR (k_631 z) (r_631_0 z))))
 #a r_635_1
 def v_635_0 (z : Store) : Tensor := bw_sum unitSeed (v_630_0 z)
 def s_636 (z : Store) : Store := storeSet (s_635 z) [(888, bw_sum ((s_635 z) 687) ((s_635 z) 886))]
 theorem t_635 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_579) (pmPeers pmNode_579) (s_635 z) pmNode_579 none = some (s_636 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_635
 theorem k_635 (z : Store) (tid : Tid) (h : tid ∉ [888]) : (s_636 z) tid = (s_635 z) tid := by
   unfold s_636
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_635
 theorem w_635_0 (z : Store) : (s_636 z) 888 = v_635_0 z := by
   unfold s_636
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_635_0, r_635_0 z, r_635_1 z] <;> rfl
 #a w_635_0
 theorem h_635_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_635_0 z).shape = [1, 8, 256] := by
   unfold v_635_0
   exact h_630_0 z z_
 #a h_635_0
 attribute [local irreducible] v_635_0
 attribute [local irreducible] s_636
 theorem r_636_0 (z : Store) : (s_636 z) 887 = (v_631_0 z) := pR (k_635 z) (pR (k_634 z) (r_634_0 z))
 #a r_636_0
 theorem r_636_1 (z : Store) : (s_636 z) 1190 = (v_633_0 z) := pR (k_635 z) (pR (k_634 z) (r_634_1 z))
 #a r_636_1
 def v_636_0 (z : Store) : Tensor := allReducePrim 2 1 [(v_631_0 z), (v_633_0 z)]
 def s_637 (z : Store) : Store := storeSet (s_636 z) [(986, allReducePrim 2 1 [((s_636 z) 887), ((s_636 z) 1190)])]
 theorem t_636 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_814) (pmPeers pmNode_814) (s_636 z) pmNode_814 none = some (s_637 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_636 z) pmNode_814 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_636
 theorem k_636 (z : Store) (tid : Tid) (h : tid ∉ [986]) : (s_637 z) tid = (s_636 z) tid := by
   unfold s_637
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_636
 theorem w_636_0 (z : Store) : (s_637 z) 986 = v_636_0 z := by
   unfold s_637
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_636_0, r_636_0 z, r_636_1 z] <;> rfl
 #a w_636_0
 theorem h_636_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_636_0 z).shape = [1] := by
   unfold v_636_0
   rw [allReducePrim_shape _ _ _ (v_631_0 z) rfl]
   exact h_631_0 z z_
 #a h_636_0
 attribute [local irreducible] v_636_0
 attribute [local irreducible] s_637
 theorem n_632_636 (z : Store) (tid : Tid) (h : tid ∉ ([1189, 1190, 683, 888] : List Tid)) : (s_636 z) tid = (s_632 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_632 z) (k_633 z)) (pF _ _ _ _ _ (k_634 z) (k_635 z)) tid h
 #a n_632_636
 theorem r_637_0 (z : Store) : (s_637 z) 990 = unitSeed := pR (k_636 z) (pR (n_632_636 z) (pR (n_624_632 z) (pR (n_608_624 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (pmInitialWithSeeds_seed_3 z)))))))
 #a r_637_0
 theorem r_637_1 (z : Store) : (s_637 z) 1189 = (v_632_0 z) := pR (k_636 z) (pR (k_635 z) (pR (k_634 z) (pR (k_633 z) (r_633_0 z))))
 #a r_637_1
 def v_637_0 (z : Store) : Tensor := bw_sum unitSeed (v_632_0 z)
 def s_638 (z : Store) : Store := storeSet (s_637 z) [(1191, bw_sum ((s_637 z) 990) ((s_637 z) 1189))]
 theorem t_637 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_815) (pmPeers pmNode_815) (s_637 z) pmNode_815 none = some (s_638 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_637
 theorem k_637 (z : Store) (tid : Tid) (h : tid ∉ [1191]) : (s_638 z) tid = (s_637 z) tid := by
   unfold s_638
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_637
 theorem w_637_0 (z : Store) : (s_638 z) 1191 = v_637_0 z := by
   unfold s_638
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_637_0, r_637_0 z, r_637_1 z] <;> rfl
 #a w_637_0
 theorem h_637_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_637_0 z).shape = [1, 8, 256] := by
   unfold v_637_0
   exact h_632_0 z z_
 #a h_637_0
 attribute [local irreducible] v_637_0
 attribute [local irreducible] s_638
 theorem r_638_0 (z : Store) : (s_638 z) 888 = (v_635_0 z) := pR (k_637 z) (pR (k_636 z) (w_635_0 z))
 #a r_638_0
 theorem r_638_1 (z : Store) : (s_638 z) 1191 = (v_637_0 z) := w_637_0 z
 #a r_638_1
 def v_638_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_635_0 z), (v_637_0 z)]
 theorem g_638 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_580) (s_638 z) pmNode_580 1 2 884 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 256], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_580, r_638_0 z, r_638_1 z, h_635_0 z z_, h_637_0 z z_]
 #a g_638
 def s_639 (z : Store) : Store := pL [2, 3] (s_638 z) pmNode_580 1 2
 theorem t_638 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_580) (pmPeers pmNode_580) (s_638 z) pmNode_580 none = some (s_639 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_580) (s_638 z) pmNode_580).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 884 (by decide) (g_638 z z_)]
   rfl
 #a t_638
 theorem k_638 (z : Store) (tid : Tid) (h : tid ∉ [884]) : (s_639 z) tid = (s_638 z) tid := by
   unfold s_639
   dsimp only [pL, pmNode_580, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_638
 theorem w_638_0 (z : Store) : (s_639 z) 884 = v_638_0 z := by
   unfold s_639
   dsimp only [pL, pmNode_580, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_638_0, r_638_0 z, r_638_1 z] <;> rfl
 #a w_638_0
 theorem h_638_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_638_0 z).shape = [1, 16, 128] := by
   unfold v_638_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_635_0 z z_]
 #a h_638_0
 attribute [local irreducible] v_638_0
 attribute [local irreducible] s_639
 theorem r_639_0 (z : Store) : (s_639 z) 884 = (v_638_0 z) := w_638_0 z
 #a r_639_0
 theorem r_639_1 (z : Store) : (s_639 z) 686 = (v_626_0 z) := pR (k_638 z) (pR (k_637 z) (pR (k_636 z) (pR (n_632_636 z) (pR (n_628_632 z) (pR (k_627 z) (r_627_0 z))))))
 #a r_639_1
 theorem r_639_2 (z : Store) : (s_639 z) 678 = (z 678) := pR (k_638 z) (pR (k_637 z) (pR (k_636 z) (pR (n_632_636 z) (pR (n_628_632 z) (pR (k_627 z) (r_627_1 z))))))
 #a r_639_2
 def v_639_0 (z : Store) : Tensor := (bw_linear (v_638_0 z) (v_626_0 z) (z 678)).1
 def v_639_1 (z : Store) : Tensor := (bw_linear (v_638_0 z) (v_626_0 z) (z 678)).2
 def s_640 (z : Store) : Store := storeSet (s_639 z) [(885, (bw_linear ((s_639 z) 884) ((s_639 z) 686) ((s_639 z) 678)).1), (679, (bw_linear ((s_639 z) 884) ((s_639 z) 686) ((s_639 z) 678)).2)]
 theorem t_639 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_581) (pmPeers pmNode_581) (s_639 z) pmNode_581 none = some (s_640 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_639
 theorem k_639 (z : Store) (tid : Tid) (h : tid ∉ [885, 679]) : (s_640 z) tid = (s_639 z) tid := by
   unfold s_640
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_639
 theorem w_639_0 (z : Store) : (s_640 z) 885 = v_639_0 z := by
   unfold s_640
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_639_0, r_639_0 z, r_639_1 z, r_639_2 z] <;> rfl
 #a w_639_0
 theorem h_639_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_639_0 z).shape = [1, 16, 64] := by
   unfold v_639_0
   exact bw_linear_3d_fst_shape 1 16 128 64 (v_638_0 z) (v_626_0 z) (z 678) (h_638_0 z z_) (h_626_0 z z_) (i_98 z z_)
 #a h_639_0
 attribute [local irreducible] v_639_0
 theorem w_639_1 (z : Store) : (s_640 z) 679 = v_639_1 z := by
   unfold s_640
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_639_1, r_639_0 z, r_639_1 z, r_639_2 z] <;> rfl
 #a w_639_1
 theorem h_639_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_639_1 z).shape = [128, 64] := by
   unfold v_639_1
   exact bw_linear_3d_snd_shape 1 16 128 64 (v_638_0 z) (v_626_0 z) (z 678) (h_638_0 z z_) (h_626_0 z z_) (i_98 z z_)
 #a h_639_1
 attribute [local irreducible] v_639_1
 attribute [local irreducible] s_640
 record_prefix_opacity v_631_0 s_632 v_632_0 s_633 v_633_0 s_634 v_634_0 s_635 v_635_0 s_636 v_636_0 s_637 v_637_0 s_638 v_638_0 s_639 v_639_0 v_639_1 s_640

 end
 end TrainVerify.Denote.RuntimeWorld
