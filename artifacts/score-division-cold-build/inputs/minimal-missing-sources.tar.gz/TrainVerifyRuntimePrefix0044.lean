import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0043
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_338_0 (z : Store) : (s_338 z) 168 = (v_337_0 z) := w_337_0 z
 #a r_338_0
 theorem r_338_1 (z : Store) : (s_338 z) 163 = (v_10_1 z) := pR (k_337 z) (pR (k_336 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_88_96 z) (pR (n_84_88 z) (pR (k_83 z) (r_83_0 z)))))))))
 #a r_338_1
 theorem r_338_2 (z : Store) : (s_338 z) 164 = (v_82_0 z) := pR (k_337 z) (pR (k_336 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_88_96 z) (pR (n_84_88 z) (pR (k_83 z) (r_83_1 z)))))))))
 #a r_338_2
 def v_338_0 (z : Store) : Tensor := (bw_add2 (v_337_0 z) (v_10_1 z) (v_82_0 z)).1
 def v_338_1 (z : Store) : Tensor := (bw_add2 (v_337_0 z) (v_10_1 z) (v_82_0 z)).2
 def s_339 (z : Store) : Store := storeSet (s_338 z) [(166, (bw_add2 ((s_338 z) 168) ((s_338 z) 163) ((s_338 z) 164)).1), (167, (bw_add2 ((s_338 z) 168) ((s_338 z) 163) ((s_338 z) 164)).2)]
 theorem t_338 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_170) (pmPeers pmNode_170) (s_338 z) pmNode_170 none = some (s_339 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_338
 theorem k_338 (z : Store) (tid : Tid) (h : tid ∉ [166, 167]) : (s_339 z) tid = (s_338 z) tid := by
   unfold s_339
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_338
 theorem w_338_0 (z : Store) : (s_339 z) 166 = v_338_0 z := by
   unfold s_339
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_338_0, r_338_0 z, r_338_1 z, r_338_2 z] <;> rfl
 #a w_338_0
 theorem h_338_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_338_0 z).shape = [1, 16, 32] := by
   unfold v_338_0
   exact h_10_1 z z_
 #a h_338_0
 attribute [local irreducible] v_338_0
 theorem w_338_1 (z : Store) : (s_339 z) 167 = v_338_1 z := by
   unfold s_339
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_338_1, r_338_0 z, r_338_1 z, r_338_2 z] <;> rfl
 #a w_338_1
 theorem h_338_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_338_1 z).shape = [1, 16, 32] := by
   unfold v_338_1
   exact h_82_0 z z_
 #a h_338_1
 attribute [local irreducible] v_338_1
 attribute [local irreducible] s_339
 theorem r_339_0 (z : Store) : (s_339 z) 171 = (v_330_0 z) := pR (k_338 z) (pR (k_337 z) (pR (k_336 z) (r_336_0 z)))
 #a r_339_0
 theorem r_339_1 (z : Store) : (s_339 z) 474 = (v_335_0 z) := pR (k_338 z) (pR (k_337 z) (pR (k_336 z) (r_336_1 z)))
 #a r_339_1
 def v_339_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_330_0 z), (v_335_0 z)]
 theorem g_339 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_404) (s_339 z) pmNode_404 1 2 593 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_404, r_339_0 z, r_339_1 z, h_330_0 z z_, h_335_0 z z_]
 #a g_339
 def s_340 (z : Store) : Store := pL [0, 1] (s_339 z) pmNode_404 1 2
 theorem t_339 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_404) (pmPeers pmNode_404) (s_339 z) pmNode_404 none = some (s_340 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_404) (s_339 z) pmNode_404).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 593 (by decide) (g_339 z z_)]
   rfl
 #a t_339
 theorem k_339 (z : Store) (tid : Tid) (h : tid ∉ [593]) : (s_340 z) tid = (s_339 z) tid := by
   unfold s_340
   dsimp only [pL, pmNode_404, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_339
 theorem w_339_0 (z : Store) : (s_340 z) 593 = v_339_0 z := by
   unfold s_340
   dsimp only [pL, pmNode_404, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_339_0, r_339_0 z, r_339_1 z] <;> rfl
 #a w_339_0
 theorem h_339_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_339_0 z).shape = [1, 16, 32] := by
   unfold v_339_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_330_0 z z_]
 #a h_339_0
 attribute [local irreducible] v_339_0
 attribute [local irreducible] s_340
 theorem n_336_340 (z : Store) (tid : Tid) (h : tid ∉ ([290, 168, 166, 167, 593] : List Tid)) : (s_340 z) tid = (s_336 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_336 z) (k_337 z)) (pF _ _ _ _ _ (k_338 z) (k_339 z)) tid h
 #a n_336_340
 theorem r_340_0 (z : Store) : (s_340 z) 593 = (v_339_0 z) := w_339_0 z
 #a r_340_0
 theorem r_340_1 (z : Store) : (s_340 z) 485 = (v_325_0 z) := pR (n_336_340 z) (pR (n_328_336 z) (pR (k_327 z) (pR (k_326 z) (w_325_0 z))))
 #a r_340_1
 def v_340_0 (z : Store) : Tensor := tensorSum [(v_339_0 z), (v_325_0 z)]
 def s_341 (z : Store) : Store := storeSet (s_340 z) [(471, tensorSum [((s_340 z) 593), ((s_340 z) 485)])]
 theorem t_340 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_405) (pmPeers pmNode_405) (s_340 z) pmNode_405 none = some (s_341 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_340
 theorem k_340 (z : Store) (tid : Tid) (h : tid ∉ [471]) : (s_341 z) tid = (s_340 z) tid := by
   unfold s_341
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_340
 theorem w_340_0 (z : Store) : (s_341 z) 471 = v_340_0 z := by
   unfold s_341
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_340_0, r_340_0 z, r_340_1 z] <;> rfl
 #a w_340_0
 theorem h_340_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_340_0 z).shape = [1, 16, 32] := by
   unfold v_340_0
   rw [tensorSum_shape]
   exact h_339_0 z z_
 #a h_340_0
 attribute [local irreducible] v_340_0
 attribute [local irreducible] s_341
 theorem r_341_0 (z : Store) : (s_341 z) 471 = (v_340_0 z) := w_340_0 z
 #a r_341_0
 theorem r_341_1 (z : Store) : (s_341 z) 466 = (v_13_1 z) := pR (k_340 z) (pR (n_336_340 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_88_96 z) (pR (k_87 z) (pR (k_86 z) (r_86_0 z)))))))))
 #a r_341_1
 theorem r_341_2 (z : Store) : (s_341 z) 467 = (v_85_0 z) := pR (k_340 z) (pR (n_336_340 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_88_96 z) (pR (k_87 z) (pR (k_86 z) (r_86_1 z)))))))))
 #a r_341_2
 def v_341_0 (z : Store) : Tensor := (bw_add2 (v_340_0 z) (v_13_1 z) (v_85_0 z)).1
 def v_341_1 (z : Store) : Tensor := (bw_add2 (v_340_0 z) (v_13_1 z) (v_85_0 z)).2
 def s_342 (z : Store) : Store := storeSet (s_341 z) [(469, (bw_add2 ((s_341 z) 471) ((s_341 z) 466) ((s_341 z) 467)).1), (470, (bw_add2 ((s_341 z) 471) ((s_341 z) 466) ((s_341 z) 467)).2)]
 theorem t_341 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_406) (pmPeers pmNode_406) (s_341 z) pmNode_406 none = some (s_342 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_341
 theorem k_341 (z : Store) (tid : Tid) (h : tid ∉ [469, 470]) : (s_342 z) tid = (s_341 z) tid := by
   unfold s_342
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_341
 theorem w_341_0 (z : Store) : (s_342 z) 469 = v_341_0 z := by
   unfold s_342
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_341_0, r_341_0 z, r_341_1 z, r_341_2 z] <;> rfl
 #a w_341_0
 theorem h_341_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_341_0 z).shape = [1, 16, 32] := by
   unfold v_341_0
   exact h_13_1 z z_
 #a h_341_0
 attribute [local irreducible] v_341_0
 theorem w_341_1 (z : Store) : (s_342 z) 470 = v_341_1 z := by
   unfold s_342
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_341_1, r_341_0 z, r_341_1 z, r_341_2 z] <;> rfl
 #a w_341_1
 theorem h_341_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_341_1 z).shape = [1, 16, 32] := by
   unfold v_341_1
   exact h_85_0 z z_
 #a h_341_1
 attribute [local irreducible] v_341_1
 attribute [local irreducible] s_342
 theorem r_342_0 (z : Store) : (s_342 z) 167 = (v_338_1 z) := pR (k_341 z) (pR (k_340 z) (pR (k_339 z) (w_338_1 z)))
 #a r_342_0
 theorem r_342_1 (z : Store) : (s_342 z) 470 = (v_341_1 z) := w_341_1 z
 #a r_342_1
 def v_342_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_338_1 z), (v_341_1 z)]
 theorem g_342 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_171) (s_342 z) pmNode_171 2 1 162 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_171, r_342_0 z, r_342_1 z, h_338_1 z z_, h_341_1 z z_]
 #a g_342
 def s_343 (z : Store) : Store := pL [0, 1] (s_342 z) pmNode_171 2 1
 theorem t_342 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_171) (pmPeers pmNode_171) (s_342 z) pmNode_171 none = some (s_343 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_171) (s_342 z) pmNode_171).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 162 (by decide) (g_342 z z_)]
   rfl
 #a t_342
 theorem k_342 (z : Store) (tid : Tid) (h : tid ∉ [162]) : (s_343 z) tid = (s_342 z) tid := by
   unfold s_343
   dsimp only [pL, pmNode_171, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_342
 theorem w_342_0 (z : Store) : (s_343 z) 162 = v_342_0 z := by
   unfold s_343
   dsimp only [pL, pmNode_171, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_342_0, r_342_0 z, r_342_1 z] <;> rfl
 #a w_342_0
 theorem h_342_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_342_0 z).shape = [1, 8, 64] := by
   unfold v_342_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_338_1 z z_]
 #a h_342_0
 attribute [local irreducible] v_342_0
 attribute [local irreducible] s_343
 theorem r_343_0 (z : Store) : (s_343 z) 162 = (v_342_0 z) := w_342_0 z
 #a r_343_0
 theorem r_343_1 (z : Store) : (s_343 z) 159 = (v_78_0 z) := pR (k_342 z) (pR (k_341 z) (pR (k_340 z) (pR (n_336_340 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (k_79 z) (r_79_0 z))))))))))
 #a r_343_1
 theorem r_343_2 (z : Store) : (s_343 z) 4 = (z 4) := pR (k_342 z) (pR (k_341 z) (pR (k_340 z) (pR (n_336_340 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (k_79 z) (r_79_1 z))))))))))
 #a r_343_2
 def v_343_0 (z : Store) : Tensor := (bw_linear (v_342_0 z) (v_78_0 z) (z 4)).1
 def v_343_1 (z : Store) : Tensor := (bw_linear (v_342_0 z) (v_78_0 z) (z 4)).2
 def s_344 (z : Store) : Store := storeSet (s_343 z) [(161, (bw_linear ((s_343 z) 162) ((s_343 z) 159) ((s_343 z) 4)).1), (33, (bw_linear ((s_343 z) 162) ((s_343 z) 159) ((s_343 z) 4)).2)]
 theorem t_343 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_172) (pmPeers pmNode_172) (s_343 z) pmNode_172 none = some (s_344 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_343
 theorem k_343 (z : Store) (tid : Tid) (h : tid ∉ [161, 33]) : (s_344 z) tid = (s_343 z) tid := by
   unfold s_344
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_343
 theorem w_343_0 (z : Store) : (s_344 z) 161 = v_343_0 z := by
   unfold s_344
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_343_0, r_343_0 z, r_343_1 z, r_343_2 z] <;> rfl
 #a w_343_0
 theorem h_343_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_343_0 z).shape = [1, 8, 64] := by
   unfold v_343_0
   exact bw_linear_3d_fst_shape 1 8 64 64 (v_342_0 z) (v_78_0 z) (z 4) (h_342_0 z z_) (h_78_0 z z_) (i_14 z z_)
 #a h_343_0
 attribute [local irreducible] v_343_0
 theorem w_343_1 (z : Store) : (s_344 z) 33 = v_343_1 z := by
   unfold s_344
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_343_1, r_343_0 z, r_343_1 z, r_343_2 z] <;> rfl
 #a w_343_1
 theorem h_343_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_343_1 z).shape = [64, 64] := by
   unfold v_343_1
   exact bw_linear_3d_snd_shape 1 8 64 64 (v_342_0 z) (v_78_0 z) (z 4) (h_342_0 z z_) (h_78_0 z z_) (i_14 z z_)
 #a h_343_1
 attribute [local irreducible] v_343_1
 attribute [local irreducible] s_344
 theorem r_344_0 (z : Store) : (s_344 z) 167 = (v_338_1 z) := pR (k_343 z) (pR (k_342 z) (r_342_0 z))
 #a r_344_0
 theorem r_344_1 (z : Store) : (s_344 z) 470 = (v_341_1 z) := pR (k_343 z) (pR (k_342 z) (r_342_1 z))
 #a r_344_1
 def v_344_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_338_1 z), (v_341_1 z)]
 theorem g_344 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_407) (s_344 z) pmNode_407 2 1 465 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_407, r_344_0 z, r_344_1 z, h_338_1 z z_, h_341_1 z z_]
 #a g_344
 def s_345 (z : Store) : Store := pL [0, 1] (s_344 z) pmNode_407 2 1
 theorem t_344 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_407) (pmPeers pmNode_407) (s_344 z) pmNode_407 none = some (s_345 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_407) (s_344 z) pmNode_407).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 465 (by decide) (g_344 z z_)]
   rfl
 #a t_344
 theorem k_344 (z : Store) (tid : Tid) (h : tid ∉ [465]) : (s_345 z) tid = (s_344 z) tid := by
   unfold s_345
   dsimp only [pL, pmNode_407, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_344
 theorem w_344_0 (z : Store) : (s_345 z) 465 = v_344_0 z := by
   unfold s_345
   dsimp only [pL, pmNode_407, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_344_0, r_344_0 z, r_344_1 z] <;> rfl
 #a w_344_0
 theorem h_344_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_344_0 z).shape = [1, 8, 64] := by
   unfold v_344_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_338_1 z z_]
 #a h_344_0
 attribute [local irreducible] v_344_0
 attribute [local irreducible] s_345
 theorem n_340_344 (z : Store) (tid : Tid) (h : tid ∉ ([471, 469, 470, 162, 161, 33] : List Tid)) : (s_344 z) tid = (s_340 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_340 z) (k_341 z)) (pF _ _ _ _ _ (k_342 z) (k_343 z)) tid h
 #a n_340_344
 theorem n_336_344 (z : Store) (tid : Tid) (h : tid ∉ ([290, 168, 166, 167, 593, 471, 469, 470, 162, 161, 33] : List Tid)) : (s_344 z) tid = (s_336 z) tid := by
   exact pF _ _ _ _ _ (n_336_340 z) (n_340_344 z) tid h
 #a n_336_344
 record_prefix_opacity v_338_0 v_338_1 s_339 v_339_0 s_340 v_340_0 s_341 v_341_0 v_341_1 s_342 v_342_0 s_343 v_343_0 v_343_1 s_344 v_344_0 s_345

 end
 end TrainVerify.Denote.RuntimeWorld
