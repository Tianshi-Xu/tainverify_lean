import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0072
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_579_0 (z : Store) : (s_579 z) 838 = (v_578_0 z) := w_578_0 z
 #a r_579_0
 def v_579_0 (z : Store) : Tensor := fw_softmax (v_578_0 z)
 def s_580 (z : Store) : Store := storeSet (s_579 z) [(839, fw_softmax ((s_579 z) 838))]
 theorem t_579 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_551) (pmPeers pmNode_551) (s_579 z) pmNode_551 none = some (s_580 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_579
 theorem k_579 (z : Store) (tid : Tid) (h : tid ∉ [839]) : (s_580 z) tid = (s_579 z) tid := by
   unfold s_580
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_579
 theorem w_579_0 (z : Store) : (s_580 z) 839 = v_579_0 z := by
   unfold s_580
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_579_0, r_579_0 z] <;> rfl
 #a w_579_0
 theorem h_579_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_579_0 z).shape = [1, 4, 8, 16] := by
   unfold v_579_0
   unfold fw_softmax softmax
   split <;> exact h_578_0 z z_
 #a h_579_0
 attribute [local irreducible] v_579_0
 attribute [local irreducible] s_580
 theorem n_576_580 (z : Store) (tid : Tid) (h : tid ∉ ([1137, 1138, 838, 839] : List Tid)) : (s_580 z) tid = (s_576 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_576 z) (k_577 z)) (pF _ _ _ _ _ (k_578 z) (k_579 z)) tid h
 #a n_576_580
 theorem n_572_576 (z : Store) (tid : Tid) (h : tid ∉ ([1133, 1134, 834, 835] : List Tid)) : (s_576 z) tid = (s_572 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_572 z) (k_573 z)) (pF _ _ _ _ _ (k_574 z) (k_575 z)) tid h
 #a n_572_576
 theorem n_568_576 (z : Store) (tid : Tid) (h : tid ∉ ([1128, 1131, 830, 831, 1133, 1134, 834, 835] : List Tid)) : (s_576 z) tid = (s_568 z) tid := by
   exact pF _ _ _ _ _ (n_568_572 z) (n_572_576 z) tid h
 #a n_568_576
 theorem r_580_0 (z : Store) : (s_580 z) 825 = (v_565_0 z) := pR (n_576_580 z) (pR (n_568_576 z) (pR (k_567 z) (pR (k_566 z) (w_565_0 z))))
 #a r_580_0
 theorem r_580_1 (z : Store) : (s_580 z) 1128 = (v_568_0 z) := pR (n_576_580 z) (pR (n_572_576 z) (pR (k_571 z) (pR (k_570 z) (pR (k_569 z) (w_568_0 z)))))
 #a r_580_1
 def v_580_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 0 [(v_565_0 z), (v_568_0 z)]
 def s_581 (z : Store) : Store := storeSet (s_580 z) [(685, allGatherPrimDimN 2 2 0 [((s_580 z) 825), ((s_580 z) 1128)])]
 theorem t_580 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_552) (pmPeers pmNode_552) (s_580 z) pmNode_552 none = some (s_581 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_580 z) pmNode_552 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_580
 theorem k_580 (z : Store) (tid : Tid) (h : tid ∉ [685]) : (s_581 z) tid = (s_580 z) tid := by
   unfold s_581
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_580
 theorem w_580_0 (z : Store) : (s_581 z) 685 = v_580_0 z := by
   unfold s_581
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_580_0, r_580_0 z, r_580_1 z] <;> rfl
 #a w_580_0
 theorem h_580_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_580_0 z).shape = [1, 4, 16, 16] := by
   unfold v_580_0
   exact allGatherPrimDimN_shape 2 2 [(v_565_0 z), (v_568_0 z)] [1, 4, 8, 16] (h_565_0 z z_)
 #a h_580_0
 attribute [local irreducible] v_580_0
 attribute [local irreducible] s_581
 theorem r_581_0 (z : Store) : (s_581 z) 839 = (v_579_0 z) := pR (k_580 z) (w_579_0 z)
 #a r_581_0
 theorem r_581_1 (z : Store) : (s_581 z) 685 = (v_580_0 z) := w_580_0 z
 #a r_581_1
 def v_581_0 (z : Store) : Tensor := fw_matmul (v_579_0 z) (v_580_0 z)
 def s_582 (z : Store) : Store := storeSet (s_581 z) [(842, fw_matmul ((s_581 z) 839) ((s_581 z) 685))]
 theorem t_581 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_553) (pmPeers pmNode_553) (s_581 z) pmNode_553 none = some (s_582 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_581
 theorem k_581 (z : Store) (tid : Tid) (h : tid ∉ [842]) : (s_582 z) tid = (s_581 z) tid := by
   unfold s_582
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_581
 theorem w_581_0 (z : Store) : (s_582 z) 842 = v_581_0 z := by
   unfold s_582
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_581_0, r_581_0 z, r_581_1 z] <;> rfl
 #a w_581_0
 theorem h_581_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_581_0 z).shape = [1, 4, 8, 16] := by
   unfold v_581_0
   unfold fw_matmul batchedMatmul
   rw [h_579_0 z z_, h_580_0 z z_]
   rfl
 #a h_581_0
 attribute [local irreducible] v_581_0
 attribute [local irreducible] s_582
 theorem r_582_0 (z : Store) : (s_582 z) 835 = (v_575_0 z) := pR (k_581 z) (pR (k_580 z) (pR (k_579 z) (pR (k_578 z) (r_578_0 z))))
 #a r_582_0
 theorem r_582_1 (z : Store) : (s_582 z) 1138 = (v_577_0 z) := pR (k_581 z) (pR (k_580 z) (pR (k_579 z) (pR (k_578 z) (r_578_1 z))))
 #a r_582_1
 def v_582_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 2 [(v_575_0 z), (v_577_0 z)]
 theorem g_582 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_786) (s_582 z) pmNode_786 3 2 1141 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_786, r_582_0 z, r_582_1 z, h_575_0 z z_, h_577_0 z z_]
 #a g_582
 def s_583 (z : Store) : Store := pL [2, 3] (s_582 z) pmNode_786 3 2
 theorem t_582 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_786) (pmPeers pmNode_786) (s_582 z) pmNode_786 none = some (s_583 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_786) (s_582 z) pmNode_786).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 2 1141 (by decide) (g_582 z z_)]
   rfl
 #a t_582
 theorem k_582 (z : Store) (tid : Tid) (h : tid ∉ [1141]) : (s_583 z) tid = (s_582 z) tid := by
   unfold s_583
   dsimp only [pL, pmNode_786, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_582
 theorem w_582_0 (z : Store) : (s_583 z) 1141 = v_582_0 z := by
   unfold s_583
   dsimp only [pL, pmNode_786, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_582_0, r_582_0 z, r_582_1 z] <;> rfl
 #a w_582_0
 theorem h_582_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_582_0 z).shape = [1, 4, 8, 16] := by
   unfold v_582_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_575_0 z z_]
 #a h_582_0
 attribute [local irreducible] v_582_0
 attribute [local irreducible] s_583
 theorem r_583_0 (z : Store) : (s_583 z) 1141 = (v_582_0 z) := w_582_0 z
 #a r_583_0
 def v_583_0 (z : Store) : Tensor := fw_softmax (v_582_0 z)
 def s_584 (z : Store) : Store := storeSet (s_583 z) [(1142, fw_softmax ((s_583 z) 1141))]
 theorem t_583 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_787) (pmPeers pmNode_787) (s_583 z) pmNode_787 none = some (s_584 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_583
 theorem k_583 (z : Store) (tid : Tid) (h : tid ∉ [1142]) : (s_584 z) tid = (s_583 z) tid := by
   unfold s_584
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_583
 theorem w_583_0 (z : Store) : (s_584 z) 1142 = v_583_0 z := by
   unfold s_584
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_583_0, r_583_0 z] <;> rfl
 #a w_583_0
 theorem h_583_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_583_0 z).shape = [1, 4, 8, 16] := by
   unfold v_583_0
   unfold fw_softmax softmax
   split <;> exact h_582_0 z z_
 #a h_583_0
 attribute [local irreducible] v_583_0
 attribute [local irreducible] s_584
 theorem n_580_584 (z : Store) (tid : Tid) (h : tid ∉ ([685, 842, 1141, 1142] : List Tid)) : (s_584 z) tid = (s_580 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_580 z) (k_581 z)) (pF _ _ _ _ _ (k_582 z) (k_583 z)) tid h
 #a n_580_584
 theorem r_584_0 (z : Store) : (s_584 z) 825 = (v_565_0 z) := pR (n_580_584 z) (r_580_0 z)
 #a r_584_0
 theorem r_584_1 (z : Store) : (s_584 z) 1128 = (v_568_0 z) := pR (n_580_584 z) (r_580_1 z)
 #a r_584_1
 def v_584_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 1 [(v_565_0 z), (v_568_0 z)]
 def s_585 (z : Store) : Store := storeSet (s_584 z) [(988, allGatherPrimDimN 2 2 1 [((s_584 z) 825), ((s_584 z) 1128)])]
 theorem t_584 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_788) (pmPeers pmNode_788) (s_584 z) pmNode_788 none = some (s_585 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_584 z) pmNode_788 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_584
 theorem k_584 (z : Store) (tid : Tid) (h : tid ∉ [988]) : (s_585 z) tid = (s_584 z) tid := by
   unfold s_585
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_584
 theorem w_584_0 (z : Store) : (s_585 z) 988 = v_584_0 z := by
   unfold s_585
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_584_0, r_584_0 z, r_584_1 z] <;> rfl
 #a w_584_0
 theorem h_584_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_584_0 z).shape = [1, 4, 16, 16] := by
   unfold v_584_0
   exact allGatherPrimDimN_shape 2 2 [(v_565_0 z), (v_568_0 z)] [1, 4, 8, 16] (h_565_0 z z_)
 #a h_584_0
 attribute [local irreducible] v_584_0
 attribute [local irreducible] s_585
 theorem r_585_0 (z : Store) : (s_585 z) 1142 = (v_583_0 z) := pR (k_584 z) (w_583_0 z)
 #a r_585_0
 theorem r_585_1 (z : Store) : (s_585 z) 988 = (v_584_0 z) := w_584_0 z
 #a r_585_1
 def v_585_0 (z : Store) : Tensor := fw_matmul (v_583_0 z) (v_584_0 z)
 def s_586 (z : Store) : Store := storeSet (s_585 z) [(1145, fw_matmul ((s_585 z) 1142) ((s_585 z) 988))]
 theorem t_585 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_789) (pmPeers pmNode_789) (s_585 z) pmNode_789 none = some (s_586 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_585
 theorem k_585 (z : Store) (tid : Tid) (h : tid ∉ [1145]) : (s_586 z) tid = (s_585 z) tid := by
   unfold s_586
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_585
 theorem w_585_0 (z : Store) : (s_586 z) 1145 = v_585_0 z := by
   unfold s_586
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_585_0, r_585_0 z, r_585_1 z] <;> rfl
 #a w_585_0
 theorem h_585_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_585_0 z).shape = [1, 4, 8, 16] := by
   unfold v_585_0
   unfold fw_matmul batchedMatmul
   rw [h_583_0 z z_, h_584_0 z z_]
   rfl
 #a h_585_0
 attribute [local irreducible] v_585_0
 attribute [local irreducible] s_586
 theorem r_586_0 (z : Store) : (s_586 z) 842 = (v_581_0 z) := pR (k_585 z) (pR (k_584 z) (pR (k_583 z) (pR (k_582 z) (w_581_0 z))))
 #a r_586_0
 theorem r_586_1 (z : Store) : (s_586 z) 1145 = (v_585_0 z) := w_585_0 z
 #a r_586_1
 def v_586_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_581_0 z), (v_585_0 z)]
 theorem g_586 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_554) (s_586 z) pmNode_554 2 1 845 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_554, r_586_0 z, r_586_1 z, h_581_0 z z_, h_585_0 z z_]
 #a g_586
 def s_587 (z : Store) : Store := pL [2, 3] (s_586 z) pmNode_554 2 1
 theorem t_586 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_554) (pmPeers pmNode_554) (s_586 z) pmNode_554 none = some (s_587 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_554) (s_586 z) pmNode_554).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 845 (by decide) (g_586 z z_)]
   rfl
 #a t_586
 theorem k_586 (z : Store) (tid : Tid) (h : tid ∉ [845]) : (s_587 z) tid = (s_586 z) tid := by
   unfold s_587
   dsimp only [pL, pmNode_554, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_586
 theorem w_586_0 (z : Store) : (s_587 z) 845 = v_586_0 z := by
   unfold s_587
   dsimp only [pL, pmNode_554, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_586_0, r_586_0 z, r_586_1 z] <;> rfl
 #a w_586_0
 theorem h_586_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_586_0 z).shape = [1, 2, 16, 16] := by
   unfold v_586_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_581_0 z z_]
 #a h_586_0
 attribute [local irreducible] v_586_0
 attribute [local irreducible] s_587
 theorem r_587_0 (z : Store) : (s_587 z) 845 = (v_586_0 z) := w_586_0 z
 #a r_587_0
 def v_587_0 (z : Store) : Tensor := transposeAxes 1 2 (v_586_0 z)
 def s_588 (z : Store) : Store := storeSet (s_587 z) [(846, transposeAxes 1 2 ((s_587 z) 845))]
 theorem t_587 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_555) (pmPeers pmNode_555) (s_587 z) pmNode_555 none = some (s_588 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_587
 theorem k_587 (z : Store) (tid : Tid) (h : tid ∉ [846]) : (s_588 z) tid = (s_587 z) tid := by
   unfold s_588
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_587
 theorem w_587_0 (z : Store) : (s_588 z) 846 = v_587_0 z := by
   unfold s_588
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_587_0, r_587_0 z] <;> rfl
 #a w_587_0
 theorem h_587_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_587_0 z).shape = [1, 16, 2, 16] := by
   unfold v_587_0
   change listSwapAt _ _ _ = _
   rw [h_586_0 z z_]
   rfl
 #a h_587_0
 attribute [local irreducible] v_587_0
 attribute [local irreducible] s_588
 record_prefix_opacity v_579_0 s_580 v_580_0 s_581 v_581_0 s_582 v_582_0 s_583 v_583_0 s_584 v_584_0 s_585 v_585_0 s_586 v_586_0 s_587 v_587_0 s_588

 end
 end TrainVerify.Denote.RuntimeWorld
