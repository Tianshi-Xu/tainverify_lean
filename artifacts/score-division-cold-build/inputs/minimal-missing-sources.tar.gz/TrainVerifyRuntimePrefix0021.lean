import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0020
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_157_0 (z : Store) : (s_157 z) 232 = (v_156_0 z) := w_156_0 z
 #a r_157_0
 def v_157_0 (z : Store) : Tensor := fw_softmax (v_156_0 z)
 def s_158 (z : Store) : Store := storeSet (s_157 z) [(233, fw_softmax ((s_157 z) 232))]
 theorem t_157 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_79) (pmPeers pmNode_79) (s_157 z) pmNode_79 none = some (s_158 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_157
 theorem k_157 (z : Store) (tid : Tid) (h : tid ∉ [233]) : (s_158 z) tid = (s_157 z) tid := by
   unfold s_158
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_157
 theorem w_157_0 (z : Store) : (s_158 z) 233 = v_157_0 z := by
   unfold s_158
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_157_0, r_157_0 z] <;> rfl
 #a w_157_0
 theorem h_157_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_157_0 z).shape = [1, 4, 8, 16] := by
   unfold v_157_0
   unfold fw_softmax softmax
   split <;> exact h_156_0 z z_
 #a h_157_0
 attribute [local irreducible] v_157_0
 attribute [local irreducible] s_158
 theorem n_152_156 (z : Store) (tid : Tid) (h : tid ∉ ([228, 229, 531, 532] : List Tid)) : (s_156 z) tid = (s_152 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_152 z) (k_153 z)) (pF _ _ _ _ _ (k_154 z) (k_155 z)) tid h
 #a n_152_156
 theorem n_148_152 (z : Store) (tid : Tid) (h : tid ∉ ([224, 225, 527, 528] : List Tid)) : (s_152 z) tid = (s_148 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_148 z) (k_149 z)) (pF _ _ _ _ _ (k_150 z) (k_151 z)) tid h
 #a n_148_152
 theorem n_144_152 (z : Store) (tid : Tid) (h : tid ∉ ([222, 521, 522, 525, 224, 225, 527, 528] : List Tid)) : (s_152 z) tid = (s_144 z) tid := by
   exact pF _ _ _ _ _ (n_144_148 z) (n_148_152 z) tid h
 #a n_144_152
 theorem r_158_0 (z : Store) : (s_158 z) 219 = (v_143_0 z) := pR (k_157 z) (pR (k_156 z) (pR (n_152_156 z) (pR (n_144_152 z) (w_143_0 z))))
 #a r_158_0
 theorem r_158_1 (z : Store) : (s_158 z) 522 = (v_146_0 z) := pR (k_157 z) (pR (k_156 z) (pR (n_152_156 z) (pR (n_148_152 z) (pR (k_147 z) (w_146_0 z)))))
 #a r_158_1
 def v_158_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 0 [(v_143_0 z), (v_146_0 z)]
 def s_159 (z : Store) : Store := storeSet (s_158 z) [(79, allGatherPrimDimN 2 2 0 [((s_158 z) 219), ((s_158 z) 522)])]
 theorem t_158 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_80) (pmPeers pmNode_80) (s_158 z) pmNode_80 none = some (s_159 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_158 z) pmNode_80 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_158
 theorem k_158 (z : Store) (tid : Tid) (h : tid ∉ [79]) : (s_159 z) tid = (s_158 z) tid := by
   unfold s_159
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_158
 theorem w_158_0 (z : Store) : (s_159 z) 79 = v_158_0 z := by
   unfold s_159
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_158_0, r_158_0 z, r_158_1 z] <;> rfl
 #a w_158_0
 theorem h_158_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_158_0 z).shape = [1, 4, 16, 16] := by
   unfold v_158_0
   exact allGatherPrimDimN_shape 2 2 [(v_143_0 z), (v_146_0 z)] [1, 4, 8, 16] (h_143_0 z z_)
 #a h_158_0
 attribute [local irreducible] v_158_0
 attribute [local irreducible] s_159
 theorem r_159_0 (z : Store) : (s_159 z) 233 = (v_157_0 z) := pR (k_158 z) (w_157_0 z)
 #a r_159_0
 theorem r_159_1 (z : Store) : (s_159 z) 79 = (v_158_0 z) := w_158_0 z
 #a r_159_1
 def v_159_0 (z : Store) : Tensor := fw_matmul (v_157_0 z) (v_158_0 z)
 def s_160 (z : Store) : Store := storeSet (s_159 z) [(236, fw_matmul ((s_159 z) 233) ((s_159 z) 79))]
 theorem t_159 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_81) (pmPeers pmNode_81) (s_159 z) pmNode_81 none = some (s_160 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_159
 theorem k_159 (z : Store) (tid : Tid) (h : tid ∉ [236]) : (s_160 z) tid = (s_159 z) tid := by
   unfold s_160
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_159
 theorem w_159_0 (z : Store) : (s_160 z) 236 = v_159_0 z := by
   unfold s_160
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_159_0, r_159_0 z, r_159_1 z] <;> rfl
 #a w_159_0
 theorem h_159_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_159_0 z).shape = [1, 4, 8, 16] := by
   unfold v_159_0
   unfold fw_matmul batchedMatmul
   rw [h_157_0 z z_, h_158_0 z z_]
   rfl
 #a h_159_0
 attribute [local irreducible] v_159_0
 attribute [local irreducible] s_160
 theorem n_156_160 (z : Store) (tid : Tid) (h : tid ∉ ([232, 233, 79, 236] : List Tid)) : (s_160 z) tid = (s_156 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_156 z) (k_157 z)) (pF _ _ _ _ _ (k_158 z) (k_159 z)) tid h
 #a n_156_160
 theorem r_160_0 (z : Store) : (s_160 z) 229 = (v_153_0 z) := pR (n_156_160 z) (r_156_0 z)
 #a r_160_0
 theorem r_160_1 (z : Store) : (s_160 z) 532 = (v_155_0 z) := pR (n_156_160 z) (r_156_1 z)
 #a r_160_1
 def v_160_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 2 [(v_153_0 z), (v_155_0 z)]
 theorem g_160 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_314) (s_160 z) pmNode_314 3 2 535 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_314, r_160_0 z, r_160_1 z, h_153_0 z z_, h_155_0 z z_]
 #a g_160
 def s_161 (z : Store) : Store := pL [0, 1] (s_160 z) pmNode_314 3 2
 theorem t_160 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_314) (pmPeers pmNode_314) (s_160 z) pmNode_314 none = some (s_161 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_314) (s_160 z) pmNode_314).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 2 535 (by decide) (g_160 z z_)]
   rfl
 #a t_160
 theorem k_160 (z : Store) (tid : Tid) (h : tid ∉ [535]) : (s_161 z) tid = (s_160 z) tid := by
   unfold s_161
   dsimp only [pL, pmNode_314, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_160
 theorem w_160_0 (z : Store) : (s_161 z) 535 = v_160_0 z := by
   unfold s_161
   dsimp only [pL, pmNode_314, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_160_0, r_160_0 z, r_160_1 z] <;> rfl
 #a w_160_0
 theorem h_160_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_160_0 z).shape = [1, 4, 8, 16] := by
   unfold v_160_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_153_0 z z_]
 #a h_160_0
 attribute [local irreducible] v_160_0
 attribute [local irreducible] s_161
 theorem r_161_0 (z : Store) : (s_161 z) 535 = (v_160_0 z) := w_160_0 z
 #a r_161_0
 def v_161_0 (z : Store) : Tensor := fw_softmax (v_160_0 z)
 def s_162 (z : Store) : Store := storeSet (s_161 z) [(536, fw_softmax ((s_161 z) 535))]
 theorem t_161 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_315) (pmPeers pmNode_315) (s_161 z) pmNode_315 none = some (s_162 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_161
 theorem k_161 (z : Store) (tid : Tid) (h : tid ∉ [536]) : (s_162 z) tid = (s_161 z) tid := by
   unfold s_162
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_161
 theorem w_161_0 (z : Store) : (s_162 z) 536 = v_161_0 z := by
   unfold s_162
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_161_0, r_161_0 z] <;> rfl
 #a w_161_0
 theorem h_161_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_161_0 z).shape = [1, 4, 8, 16] := by
   unfold v_161_0
   unfold fw_softmax softmax
   split <;> exact h_160_0 z z_
 #a h_161_0
 attribute [local irreducible] v_161_0
 attribute [local irreducible] s_162
 theorem r_162_0 (z : Store) : (s_162 z) 219 = (v_143_0 z) := pR (k_161 z) (pR (k_160 z) (pR (k_159 z) (pR (k_158 z) (r_158_0 z))))
 #a r_162_0
 theorem r_162_1 (z : Store) : (s_162 z) 522 = (v_146_0 z) := pR (k_161 z) (pR (k_160 z) (pR (k_159 z) (pR (k_158 z) (r_158_1 z))))
 #a r_162_1
 def v_162_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 1 [(v_143_0 z), (v_146_0 z)]
 def s_163 (z : Store) : Store := storeSet (s_162 z) [(382, allGatherPrimDimN 2 2 1 [((s_162 z) 219), ((s_162 z) 522)])]
 theorem t_162 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_316) (pmPeers pmNode_316) (s_162 z) pmNode_316 none = some (s_163 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_162 z) pmNode_316 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_162
 theorem k_162 (z : Store) (tid : Tid) (h : tid ∉ [382]) : (s_163 z) tid = (s_162 z) tid := by
   unfold s_163
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_162
 theorem w_162_0 (z : Store) : (s_163 z) 382 = v_162_0 z := by
   unfold s_163
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_162_0, r_162_0 z, r_162_1 z] <;> rfl
 #a w_162_0
 theorem h_162_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_162_0 z).shape = [1, 4, 16, 16] := by
   unfold v_162_0
   exact allGatherPrimDimN_shape 2 2 [(v_143_0 z), (v_146_0 z)] [1, 4, 8, 16] (h_143_0 z z_)
 #a h_162_0
 attribute [local irreducible] v_162_0
 attribute [local irreducible] s_163
 theorem r_163_0 (z : Store) : (s_163 z) 536 = (v_161_0 z) := pR (k_162 z) (w_161_0 z)
 #a r_163_0
 theorem r_163_1 (z : Store) : (s_163 z) 382 = (v_162_0 z) := w_162_0 z
 #a r_163_1
 def v_163_0 (z : Store) : Tensor := fw_matmul (v_161_0 z) (v_162_0 z)
 def s_164 (z : Store) : Store := storeSet (s_163 z) [(539, fw_matmul ((s_163 z) 536) ((s_163 z) 382))]
 theorem t_163 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_317) (pmPeers pmNode_317) (s_163 z) pmNode_317 none = some (s_164 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_163
 theorem k_163 (z : Store) (tid : Tid) (h : tid ∉ [539]) : (s_164 z) tid = (s_163 z) tid := by
   unfold s_164
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_163
 theorem w_163_0 (z : Store) : (s_164 z) 539 = v_163_0 z := by
   unfold s_164
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_163_0, r_163_0 z, r_163_1 z] <;> rfl
 #a w_163_0
 theorem h_163_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_163_0 z).shape = [1, 4, 8, 16] := by
   unfold v_163_0
   unfold fw_matmul batchedMatmul
   rw [h_161_0 z z_, h_162_0 z z_]
   rfl
 #a h_163_0
 attribute [local irreducible] v_163_0
 attribute [local irreducible] s_164
 theorem n_160_164 (z : Store) (tid : Tid) (h : tid ∉ ([535, 536, 382, 539] : List Tid)) : (s_164 z) tid = (s_160 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_160 z) (k_161 z)) (pF _ _ _ _ _ (k_162 z) (k_163 z)) tid h
 #a n_160_164
 theorem r_164_0 (z : Store) : (s_164 z) 236 = (v_159_0 z) := pR (n_160_164 z) (w_159_0 z)
 #a r_164_0
 theorem r_164_1 (z : Store) : (s_164 z) 539 = (v_163_0 z) := w_163_0 z
 #a r_164_1
 def v_164_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_159_0 z), (v_163_0 z)]
 theorem g_164 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_82) (s_164 z) pmNode_82 2 1 239 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_82, r_164_0 z, r_164_1 z, h_159_0 z z_, h_163_0 z z_]
 #a g_164
 def s_165 (z : Store) : Store := pL [0, 1] (s_164 z) pmNode_82 2 1
 theorem t_164 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_82) (pmPeers pmNode_82) (s_164 z) pmNode_82 none = some (s_165 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_82) (s_164 z) pmNode_82).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 239 (by decide) (g_164 z z_)]
   rfl
 #a t_164
 theorem k_164 (z : Store) (tid : Tid) (h : tid ∉ [239]) : (s_165 z) tid = (s_164 z) tid := by
   unfold s_165
   dsimp only [pL, pmNode_82, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_164
 theorem w_164_0 (z : Store) : (s_165 z) 239 = v_164_0 z := by
   unfold s_165
   dsimp only [pL, pmNode_82, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_164_0, r_164_0 z, r_164_1 z] <;> rfl
 #a w_164_0
 theorem h_164_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_164_0 z).shape = [1, 2, 16, 16] := by
   unfold v_164_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_159_0 z z_]
 #a h_164_0
 attribute [local irreducible] v_164_0
 attribute [local irreducible] s_165
 theorem r_165_0 (z : Store) : (s_165 z) 239 = (v_164_0 z) := w_164_0 z
 #a r_165_0
 def v_165_0 (z : Store) : Tensor := transposeAxes 1 2 (v_164_0 z)
 def s_166 (z : Store) : Store := storeSet (s_165 z) [(240, transposeAxes 1 2 ((s_165 z) 239))]
 theorem t_165 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_83) (pmPeers pmNode_83) (s_165 z) pmNode_83 none = some (s_166 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_165
 theorem k_165 (z : Store) (tid : Tid) (h : tid ∉ [240]) : (s_166 z) tid = (s_165 z) tid := by
   unfold s_166
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_165
 theorem w_165_0 (z : Store) : (s_166 z) 240 = v_165_0 z := by
   unfold s_166
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_165_0, r_165_0 z] <;> rfl
 #a w_165_0
 theorem h_165_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_165_0 z).shape = [1, 16, 2, 16] := by
   unfold v_165_0
   change listSwapAt _ _ _ = _
   rw [h_164_0 z z_]
   rfl
 #a h_165_0
 attribute [local irreducible] v_165_0
 attribute [local irreducible] s_166
 record_prefix_opacity v_157_0 s_158 v_158_0 s_159 v_159_0 s_160 v_160_0 s_161 v_161_0 s_162 v_162_0 s_163 v_163_0 s_164 v_164_0 s_165 v_165_0 s_166

 end
 end TrainVerify.Denote.RuntimeWorld
