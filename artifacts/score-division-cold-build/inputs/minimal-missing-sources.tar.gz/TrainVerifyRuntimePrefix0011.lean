import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0010
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_71_0 (z : Store) : (s_71 z) 449 = (v_70_0 z) := w_70_0 z
 #a r_71_0
 theorem r_71_1 (z : Store) : (s_71 z) 381 = (v_69_0 z) := pR (k_70 z) (w_69_0 z)
 #a r_71_1
 def v_71_0 (z : Store) : Tensor := fw_matmul (v_70_0 z) (v_69_0 z)
 def s_72 (z : Store) : Store := storeSet (s_71 z) [(450, fw_matmul ((s_71 z) 449) ((s_71 z) 381))]
 theorem t_71 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_270) (pmPeers pmNode_270) (s_71 z) pmNode_270 none = some (s_72 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_71
 theorem k_71 (z : Store) (tid : Tid) (h : tid ∉ [450]) : (s_72 z) tid = (s_71 z) tid := by
   unfold s_72
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_71
 theorem w_71_0 (z : Store) : (s_72 z) 450 = v_71_0 z := by
   unfold s_72
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_71_0, r_71_0 z, r_71_1 z] <;> rfl
 #a w_71_0
 theorem h_71_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_71_0 z).shape = [1, 4, 8, 16] := by
   unfold v_71_0
   unfold fw_matmul batchedMatmul
   rw [h_70_0 z z_, h_69_0 z z_]
   rfl
 #a h_71_0
 attribute [local irreducible] v_71_0
 attribute [local irreducible] s_72
 theorem r_72_0 (z : Store) : (s_72 z) 450 = (v_71_0 z) := w_71_0 z
 #a r_72_0
 def v_72_0 (z : Store) : Tensor := transposeAxes 1 2 (v_71_0 z)
 def s_73 (z : Store) : Store := storeSet (s_72 z) [(454, transposeAxes 1 2 ((s_72 z) 450))]
 theorem t_72 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_271) (pmPeers pmNode_271) (s_72 z) pmNode_271 none = some (s_73 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_72
 theorem k_72 (z : Store) (tid : Tid) (h : tid ∉ [454]) : (s_73 z) tid = (s_72 z) tid := by
   unfold s_73
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_72
 theorem w_72_0 (z : Store) : (s_73 z) 454 = v_72_0 z := by
   unfold s_73
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_72_0, r_72_0 z] <;> rfl
 #a w_72_0
 theorem h_72_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_72_0 z).shape = [1, 8, 4, 16] := by
   unfold v_72_0
   change listSwapAt _ _ _ = _
   rw [h_71_0 z z_]
   rfl
 #a h_72_0
 attribute [local irreducible] v_72_0
 attribute [local irreducible] s_73
 theorem r_73_0 (z : Store) : (s_73 z) 454 = (v_72_0 z) := w_72_0 z
 #a r_73_0
 def v_73_0 (z : Store) : Tensor := (v_72_0 z)
 def s_74 (z : Store) : Store := storeSet (s_73 z) [(456, ((s_73 z) 454))]
 theorem t_73 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_272) (pmPeers pmNode_272) (s_73 z) pmNode_272 none = some (s_74 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_73
 theorem k_73 (z : Store) (tid : Tid) (h : tid ∉ [456]) : (s_74 z) tid = (s_73 z) tid := by
   unfold s_74
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_73
 theorem w_73_0 (z : Store) : (s_74 z) 456 = v_73_0 z := by
   unfold s_74
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_73_0, r_73_0 z] <;> rfl
 #a w_73_0
 theorem h_73_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_73_0 z).shape = [1, 8, 4, 16] := by
   unfold v_73_0
   exact h_72_0 z z_
 #a h_73_0
 attribute [local irreducible] v_73_0
 attribute [local irreducible] s_74
 theorem r_74_0 (z : Store) : (s_74 z) 153 = (v_68_0 z) := pR (k_73 z) (pR (k_72 z) (pR (k_71 z) (pR (k_70 z) (pR (k_69 z) (w_68_0 z)))))
 #a r_74_0
 theorem r_74_1 (z : Store) : (s_74 z) 456 = (v_73_0 z) := w_73_0 z
 #a r_74_1
 def v_74_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_68_0 z), (v_73_0 z)]
 theorem g_74 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_37) (s_74 z) pmNode_37 1 2 155 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_37, r_74_0 z, r_74_1 z, h_68_0 z z_, h_73_0 z z_]
 #a g_74
 def s_75 (z : Store) : Store := pL [0, 1] (s_74 z) pmNode_37 1 2
 theorem t_74 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_37) (pmPeers pmNode_37) (s_74 z) pmNode_37 none = some (s_75 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_37) (s_74 z) pmNode_37).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 155 (by decide) (g_74 z z_)]
   rfl
 #a t_74
 theorem k_74 (z : Store) (tid : Tid) (h : tid ∉ [155]) : (s_75 z) tid = (s_74 z) tid := by
   unfold s_75
   dsimp only [pL, pmNode_37, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_74
 theorem w_74_0 (z : Store) : (s_75 z) 155 = v_74_0 z := by
   unfold s_75
   dsimp only [pL, pmNode_37, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_74_0, r_74_0 z, r_74_1 z] <;> rfl
 #a w_74_0
 theorem h_74_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_74_0 z).shape = [1, 16, 2, 16] := by
   unfold v_74_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_68_0 z z_]
 #a h_74_0
 attribute [local irreducible] v_74_0
 attribute [local irreducible] s_75
 theorem r_75_0 (z : Store) : (s_75 z) 155 = (v_74_0 z) := w_74_0 z
 #a r_75_0
 def v_75_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_74_0 z)
 def s_76 (z : Store) : Store := storeSet (s_75 z) [(156, fw_view [1, 16, 32] ((s_75 z) 155))]
 theorem t_75 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_38) (pmPeers pmNode_38) (s_75 z) pmNode_38 none = some (s_76 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_75
 theorem k_75 (z : Store) (tid : Tid) (h : tid ∉ [156]) : (s_76 z) tid = (s_75 z) tid := by
   unfold s_76
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_75
 theorem w_75_0 (z : Store) : (s_76 z) 156 = v_75_0 z := by
   unfold s_76
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_75_0, r_75_0 z] <;> rfl
 #a w_75_0
 theorem h_75_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_75_0 z).shape = [1, 16, 32] := by
   unfold v_75_0
   rfl
 #a h_75_0
 attribute [local irreducible] v_75_0
 attribute [local irreducible] s_76
 theorem r_76_0 (z : Store) : (s_76 z) 153 = (v_68_0 z) := pR (k_75 z) (pR (k_74 z) (r_74_0 z))
 #a r_76_0
 theorem r_76_1 (z : Store) : (s_76 z) 456 = (v_73_0 z) := pR (k_75 z) (pR (k_74 z) (r_74_1 z))
 #a r_76_1
 def v_76_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_68_0 z), (v_73_0 z)]
 theorem g_76 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_273) (s_76 z) pmNode_273 1 2 458 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_273, r_76_0 z, r_76_1 z, h_68_0 z z_, h_73_0 z z_]
 #a g_76
 def s_77 (z : Store) : Store := pL [0, 1] (s_76 z) pmNode_273 1 2
 theorem t_76 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_273) (pmPeers pmNode_273) (s_76 z) pmNode_273 none = some (s_77 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_273) (s_76 z) pmNode_273).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 458 (by decide) (g_76 z z_)]
   rfl
 #a t_76
 theorem k_76 (z : Store) (tid : Tid) (h : tid ∉ [458]) : (s_77 z) tid = (s_76 z) tid := by
   unfold s_77
   dsimp only [pL, pmNode_273, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_76
 theorem w_76_0 (z : Store) : (s_77 z) 458 = v_76_0 z := by
   unfold s_77
   dsimp only [pL, pmNode_273, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_76_0, r_76_0 z, r_76_1 z] <;> rfl
 #a w_76_0
 theorem h_76_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_76_0 z).shape = [1, 16, 2, 16] := by
   unfold v_76_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_68_0 z z_]
 #a h_76_0
 attribute [local irreducible] v_76_0
 attribute [local irreducible] s_77
 theorem r_77_0 (z : Store) : (s_77 z) 458 = (v_76_0 z) := w_76_0 z
 #a r_77_0
 def v_77_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_76_0 z)
 def s_78 (z : Store) : Store := storeSet (s_77 z) [(459, fw_view [1, 16, 32] ((s_77 z) 458))]
 theorem t_77 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_274) (pmPeers pmNode_274) (s_77 z) pmNode_274 none = some (s_78 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_77
 theorem k_77 (z : Store) (tid : Tid) (h : tid ∉ [459]) : (s_78 z) tid = (s_77 z) tid := by
   unfold s_78
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_77
 theorem w_77_0 (z : Store) : (s_78 z) 459 = v_77_0 z := by
   unfold s_78
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_77_0, r_77_0 z] <;> rfl
 #a w_77_0
 theorem h_77_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_77_0 z).shape = [1, 16, 32] := by
   unfold v_77_0
   rfl
 #a h_77_0
 attribute [local irreducible] v_77_0
 attribute [local irreducible] s_78
 theorem r_78_0 (z : Store) : (s_78 z) 156 = (v_75_0 z) := pR (k_77 z) (pR (k_76 z) (w_75_0 z))
 #a r_78_0
 theorem r_78_1 (z : Store) : (s_78 z) 459 = (v_77_0 z) := w_77_0 z
 #a r_78_1
 def v_78_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_75_0 z), (v_77_0 z)]
 theorem g_78 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_39) (s_78 z) pmNode_39 2 1 159 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_39, r_78_0 z, r_78_1 z, h_75_0 z z_, h_77_0 z z_]
 #a g_78
 def s_79 (z : Store) : Store := pL [0, 1] (s_78 z) pmNode_39 2 1
 theorem t_78 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_39) (pmPeers pmNode_39) (s_78 z) pmNode_39 none = some (s_79 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_39) (s_78 z) pmNode_39).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 159 (by decide) (g_78 z z_)]
   rfl
 #a t_78
 theorem k_78 (z : Store) (tid : Tid) (h : tid ∉ [159]) : (s_79 z) tid = (s_78 z) tid := by
   unfold s_79
   dsimp only [pL, pmNode_39, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_78
 theorem w_78_0 (z : Store) : (s_79 z) 159 = v_78_0 z := by
   unfold s_79
   dsimp only [pL, pmNode_39, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_78_0, r_78_0 z, r_78_1 z] <;> rfl
 #a w_78_0
 theorem h_78_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_78_0 z).shape = [1, 8, 64] := by
   unfold v_78_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_75_0 z z_]
 #a h_78_0
 attribute [local irreducible] v_78_0
 attribute [local irreducible] s_79
 theorem n_72_76 (z : Store) (tid : Tid) (h : tid ∉ ([454, 456, 155, 156] : List Tid)) : (s_76 z) tid = (s_72 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_72 z) (k_73 z)) (pF _ _ _ _ _ (k_74 z) (k_75 z)) tid h
 #a n_72_76
 theorem n_68_72 (z : Store) (tid : Tid) (h : tid ∉ ([153, 381, 449, 450] : List Tid)) : (s_72 z) tid = (s_68 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_68 z) (k_69 z)) (pF _ _ _ _ _ (k_70 z) (k_71 z)) tid h
 #a n_68_72
 theorem n_64_72 (z : Store) (tid : Tid) (h : tid ∉ ([446, 146, 147, 151, 153, 381, 449, 450] : List Tid)) : (s_72 z) tid = (s_64 z) tid := by
   exact pF _ _ _ _ _ (n_64_68 z) (n_68_72 z) tid h
 #a n_64_72
 theorem n_16_32 (z : Store) (tid : Tid) (h : tid ∉ ([102, 285, 287, 103, 401, 402, 405, 588, 590, 86, 106, 87, 109, 112, 406, 389, 409, 390, 412, 415] : List Tid)) : (s_32 z) tid = (s_16 z) tid := by
   exact pF _ _ _ _ _ (n_16_24 z) (n_24_32 z) tid h
 #a n_16_32
 theorem n_0_32 (z : Store) (tid : Tid) (h : tid ∉ ([75, 76, 89, 91, 92, 378, 379, 392, 394, 395, 94, 95, 283, 163, 397, 398, 586, 466, 98, 99, 102, 285, 287, 103, 401, 402, 405, 588, 590, 86, 106, 87, 109, 112, 406, 389, 409, 390, 412, 415] : List Tid)) : (s_32 z) tid = (s_0 z) tid := by
   exact pF _ _ _ _ _ (n_0_16 z) (n_16_32 z) tid h
 #a n_0_32
 theorem n_40_48 (z : Store) (tid : Tid) (h : tid ∉ ([124, 125, 128, 130, 132, 423, 424, 427] : List Tid)) : (s_48 z) tid = (s_40 z) tid := by
   exact pF _ _ _ _ _ (n_40_44 z) (n_44_48 z) tid h
 #a n_40_48
 theorem n_32_48 (z : Store) (tid : Tid) (h : tid ∉ ([114, 115, 118, 417, 418, 421, 120, 121, 124, 125, 128, 130, 132, 423, 424, 427] : List Tid)) : (s_48 z) tid = (s_32 z) tid := by
   exact pF _ _ _ _ _ (n_32_40 z) (n_40_48 z) tid h
 #a n_32_48
 theorem n_60_64 (z : Store) (tid : Tid) (h : tid ∉ ([142, 143, 78, 445] : List Tid)) : (s_64 z) tid = (s_60 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_60 z) (k_61 z)) (pF _ _ _ _ _ (k_62 z) (k_63 z)) tid h
 #a n_60_64
 theorem n_56_64 (z : Store) (tid : Tid) (h : tid ∉ ([138, 139, 441, 442, 142, 143, 78, 445] : List Tid)) : (s_64 z) tid = (s_56 z) tid := by
   exact pF _ _ _ _ _ (n_56_60 z) (n_60_64 z) tid h
 #a n_56_64
 theorem n_48_64 (z : Store) (tid : Tid) (h : tid ∉ ([428, 431, 433, 133, 134, 435, 436, 437, 138, 139, 441, 442, 142, 143, 78, 445] : List Tid)) : (s_64 z) tid = (s_48 z) tid := by
   exact pF _ _ _ _ _ (n_48_56 z) (n_56_64 z) tid h
 #a n_48_64
 theorem n_32_64 (z : Store) (tid : Tid) (h : tid ∉ ([114, 115, 118, 417, 418, 421, 120, 121, 124, 125, 128, 130, 132, 423, 424, 427, 428, 431, 433, 133, 134, 435, 436, 437, 138, 139, 441, 442, 142, 143, 78, 445] : List Tid)) : (s_64 z) tid = (s_32 z) tid := by
   exact pF _ _ _ _ _ (n_32_48 z) (n_48_64 z) tid h
 #a n_32_64
 theorem n_0_64 (z : Store) (tid : Tid) (h : tid ∉ ([75, 76, 89, 91, 92, 378, 379, 392, 394, 395, 94, 95, 283, 163, 397, 398, 586, 466, 98, 99, 102, 285, 287, 103, 401, 402, 405, 588, 590, 86, 106, 87, 109, 112, 406, 389, 409, 390, 412, 415, 114, 115, 118, 417, 418, 421, 120, 121, 124, 125, 128, 130, 132, 423, 424, 427, 428, 431, 433, 133, 134, 435, 436, 437, 138, 139, 441, 442, 142, 143, 78, 445] : List Tid)) : (s_64 z) tid = (s_0 z) tid := by
   exact pF _ _ _ _ _ (n_0_32 z) (n_32_64 z) tid h
 #a n_0_64
 record_prefix_opacity v_71_0 s_72 v_72_0 s_73 v_73_0 s_74 v_74_0 s_75 v_75_0 s_76 v_76_0 s_77 v_77_0 s_78 v_78_0 s_79

 end
 end TrainVerify.Denote.RuntimeWorld
