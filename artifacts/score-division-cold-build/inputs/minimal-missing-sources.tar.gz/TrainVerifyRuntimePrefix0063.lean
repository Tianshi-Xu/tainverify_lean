import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0062
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_493_0 (z : Store) : (s_493 z) 1055 = (v_492_0 z) := w_492_0 z
 #a r_493_0
 theorem r_493_1 (z : Store) : (s_493 z) 987 = (v_491_0 z) := pR (k_492 z) (w_491_0 z)
 #a r_493_1
 def v_493_0 (z : Store) : Tensor := fw_matmul (v_492_0 z) (v_491_0 z)
 def s_494 (z : Store) : Store := storeSet (s_493 z) [(1056, fw_matmul ((s_493 z) 1055) ((s_493 z) 987))]
 theorem t_493 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_742) (pmPeers pmNode_742) (s_493 z) pmNode_742 none = some (s_494 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_493
 theorem k_493 (z : Store) (tid : Tid) (h : tid ∉ [1056]) : (s_494 z) tid = (s_493 z) tid := by
   unfold s_494
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_493
 theorem w_493_0 (z : Store) : (s_494 z) 1056 = v_493_0 z := by
   unfold s_494
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_493_0, r_493_0 z, r_493_1 z] <;> rfl
 #a w_493_0
 theorem h_493_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_493_0 z).shape = [1, 4, 8, 16] := by
   unfold v_493_0
   unfold fw_matmul batchedMatmul
   rw [h_492_0 z z_, h_491_0 z z_]
   rfl
 #a h_493_0
 attribute [local irreducible] v_493_0
 attribute [local irreducible] s_494
 theorem r_494_0 (z : Store) : (s_494 z) 1056 = (v_493_0 z) := w_493_0 z
 #a r_494_0
 def v_494_0 (z : Store) : Tensor := transposeAxes 1 2 (v_493_0 z)
 def s_495 (z : Store) : Store := storeSet (s_494 z) [(1060, transposeAxes 1 2 ((s_494 z) 1056))]
 theorem t_494 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_743) (pmPeers pmNode_743) (s_494 z) pmNode_743 none = some (s_495 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_494
 theorem k_494 (z : Store) (tid : Tid) (h : tid ∉ [1060]) : (s_495 z) tid = (s_494 z) tid := by
   unfold s_495
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_494
 theorem w_494_0 (z : Store) : (s_495 z) 1060 = v_494_0 z := by
   unfold s_495
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_494_0, r_494_0 z] <;> rfl
 #a w_494_0
 theorem h_494_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_494_0 z).shape = [1, 8, 4, 16] := by
   unfold v_494_0
   change listSwapAt _ _ _ = _
   rw [h_493_0 z z_]
   rfl
 #a h_494_0
 attribute [local irreducible] v_494_0
 attribute [local irreducible] s_495
 theorem r_495_0 (z : Store) : (s_495 z) 1060 = (v_494_0 z) := w_494_0 z
 #a r_495_0
 def v_495_0 (z : Store) : Tensor := (v_494_0 z)
 def s_496 (z : Store) : Store := storeSet (s_495 z) [(1062, ((s_495 z) 1060))]
 theorem t_495 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_744) (pmPeers pmNode_744) (s_495 z) pmNode_744 none = some (s_496 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_495
 theorem k_495 (z : Store) (tid : Tid) (h : tid ∉ [1062]) : (s_496 z) tid = (s_495 z) tid := by
   unfold s_496
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_495
 theorem w_495_0 (z : Store) : (s_496 z) 1062 = v_495_0 z := by
   unfold s_496
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_495_0, r_495_0 z] <;> rfl
 #a w_495_0
 theorem h_495_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_495_0 z).shape = [1, 8, 4, 16] := by
   unfold v_495_0
   exact h_494_0 z z_
 #a h_495_0
 attribute [local irreducible] v_495_0
 attribute [local irreducible] s_496
 theorem n_492_496 (z : Store) (tid : Tid) (h : tid ∉ ([1055, 1056, 1060, 1062] : List Tid)) : (s_496 z) tid = (s_492 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_492 z) (k_493 z)) (pF _ _ _ _ _ (k_494 z) (k_495 z)) tid h
 #a n_492_496
 theorem r_496_0 (z : Store) : (s_496 z) 759 = (v_490_0 z) := pR (n_492_496 z) (pR (k_491 z) (w_490_0 z))
 #a r_496_0
 theorem r_496_1 (z : Store) : (s_496 z) 1062 = (v_495_0 z) := w_495_0 z
 #a r_496_1
 def v_496_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_490_0 z), (v_495_0 z)]
 theorem g_496 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_509) (s_496 z) pmNode_509 1 2 761 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_509, r_496_0 z, r_496_1 z, h_490_0 z z_, h_495_0 z z_]
 #a g_496
 def s_497 (z : Store) : Store := pL [2, 3] (s_496 z) pmNode_509 1 2
 theorem t_496 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_509) (pmPeers pmNode_509) (s_496 z) pmNode_509 none = some (s_497 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_509) (s_496 z) pmNode_509).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 761 (by decide) (g_496 z z_)]
   rfl
 #a t_496
 theorem k_496 (z : Store) (tid : Tid) (h : tid ∉ [761]) : (s_497 z) tid = (s_496 z) tid := by
   unfold s_497
   dsimp only [pL, pmNode_509, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_496
 theorem w_496_0 (z : Store) : (s_497 z) 761 = v_496_0 z := by
   unfold s_497
   dsimp only [pL, pmNode_509, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_496_0, r_496_0 z, r_496_1 z] <;> rfl
 #a w_496_0
 theorem h_496_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_496_0 z).shape = [1, 16, 2, 16] := by
   unfold v_496_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_490_0 z z_]
 #a h_496_0
 attribute [local irreducible] v_496_0
 attribute [local irreducible] s_497
 theorem r_497_0 (z : Store) : (s_497 z) 761 = (v_496_0 z) := w_496_0 z
 #a r_497_0
 def v_497_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_496_0 z)
 def s_498 (z : Store) : Store := storeSet (s_497 z) [(762, fw_view [1, 16, 32] ((s_497 z) 761))]
 theorem t_497 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_510) (pmPeers pmNode_510) (s_497 z) pmNode_510 none = some (s_498 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_497
 theorem k_497 (z : Store) (tid : Tid) (h : tid ∉ [762]) : (s_498 z) tid = (s_497 z) tid := by
   unfold s_498
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_497
 theorem w_497_0 (z : Store) : (s_498 z) 762 = v_497_0 z := by
   unfold s_498
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_497_0, r_497_0 z] <;> rfl
 #a w_497_0
 theorem h_497_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_497_0 z).shape = [1, 16, 32] := by
   unfold v_497_0
   rfl
 #a h_497_0
 attribute [local irreducible] v_497_0
 attribute [local irreducible] s_498
 theorem r_498_0 (z : Store) : (s_498 z) 759 = (v_490_0 z) := pR (k_497 z) (pR (k_496 z) (r_496_0 z))
 #a r_498_0
 theorem r_498_1 (z : Store) : (s_498 z) 1062 = (v_495_0 z) := pR (k_497 z) (pR (k_496 z) (r_496_1 z))
 #a r_498_1
 def v_498_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_490_0 z), (v_495_0 z)]
 theorem g_498 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_745) (s_498 z) pmNode_745 1 2 1064 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_745, r_498_0 z, r_498_1 z, h_490_0 z z_, h_495_0 z z_]
 #a g_498
 def s_499 (z : Store) : Store := pL [2, 3] (s_498 z) pmNode_745 1 2
 theorem t_498 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_745) (pmPeers pmNode_745) (s_498 z) pmNode_745 none = some (s_499 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_745) (s_498 z) pmNode_745).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1064 (by decide) (g_498 z z_)]
   rfl
 #a t_498
 theorem k_498 (z : Store) (tid : Tid) (h : tid ∉ [1064]) : (s_499 z) tid = (s_498 z) tid := by
   unfold s_499
   dsimp only [pL, pmNode_745, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_498
 theorem w_498_0 (z : Store) : (s_499 z) 1064 = v_498_0 z := by
   unfold s_499
   dsimp only [pL, pmNode_745, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_498_0, r_498_0 z, r_498_1 z] <;> rfl
 #a w_498_0
 theorem h_498_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_498_0 z).shape = [1, 16, 2, 16] := by
   unfold v_498_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_490_0 z z_]
 #a h_498_0
 attribute [local irreducible] v_498_0
 attribute [local irreducible] s_499
 theorem r_499_0 (z : Store) : (s_499 z) 1064 = (v_498_0 z) := w_498_0 z
 #a r_499_0
 def v_499_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_498_0 z)
 def s_500 (z : Store) : Store := storeSet (s_499 z) [(1065, fw_view [1, 16, 32] ((s_499 z) 1064))]
 theorem t_499 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_746) (pmPeers pmNode_746) (s_499 z) pmNode_746 none = some (s_500 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_499
 theorem k_499 (z : Store) (tid : Tid) (h : tid ∉ [1065]) : (s_500 z) tid = (s_499 z) tid := by
   unfold s_500
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_499
 theorem w_499_0 (z : Store) : (s_500 z) 1065 = v_499_0 z := by
   unfold s_500
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_499_0, r_499_0 z] <;> rfl
 #a w_499_0
 theorem h_499_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_499_0 z).shape = [1, 16, 32] := by
   unfold v_499_0
   rfl
 #a h_499_0
 attribute [local irreducible] v_499_0
 attribute [local irreducible] s_500
 theorem r_500_0 (z : Store) : (s_500 z) 762 = (v_497_0 z) := pR (k_499 z) (pR (k_498 z) (w_497_0 z))
 #a r_500_0
 theorem r_500_1 (z : Store) : (s_500 z) 1065 = (v_499_0 z) := w_499_0 z
 #a r_500_1
 def v_500_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_497_0 z), (v_499_0 z)]
 theorem g_500 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_511) (s_500 z) pmNode_511 2 1 765 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_511, r_500_0 z, r_500_1 z, h_497_0 z z_, h_499_0 z z_]
 #a g_500
 def s_501 (z : Store) : Store := pL [2, 3] (s_500 z) pmNode_511 2 1
 theorem t_500 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_511) (pmPeers pmNode_511) (s_500 z) pmNode_511 none = some (s_501 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_511) (s_500 z) pmNode_511).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 765 (by decide) (g_500 z z_)]
   rfl
 #a t_500
 theorem k_500 (z : Store) (tid : Tid) (h : tid ∉ [765]) : (s_501 z) tid = (s_500 z) tid := by
   unfold s_501
   dsimp only [pL, pmNode_511, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_500
 theorem w_500_0 (z : Store) : (s_501 z) 765 = v_500_0 z := by
   unfold s_501
   dsimp only [pL, pmNode_511, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_500_0, r_500_0 z, r_500_1 z] <;> rfl
 #a w_500_0
 theorem h_500_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_500_0 z).shape = [1, 8, 64] := by
   unfold v_500_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_497_0 z z_]
 #a h_500_0
 attribute [local irreducible] v_500_0
 attribute [local irreducible] s_501
 theorem n_496_500 (z : Store) (tid : Tid) (h : tid ∉ ([761, 762, 1064, 1065] : List Tid)) : (s_500 z) tid = (s_496 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_496 z) (k_497 z)) (pF _ _ _ _ _ (k_498 z) (k_499 z)) tid h
 #a n_496_500
 theorem n_480_488 (z : Store) (tid : Tid) (h : tid ∉ ([1047, 1048, 748, 749, 684, 1051, 1052, 752] : List Tid)) : (s_488 z) tid = (s_480 z) tid := by
   exact pF _ _ _ _ _ (n_480_484 z) (n_484_488 z) tid h
 #a n_480_488
 theorem n_488_496 (z : Store) (tid : Tid) (h : tid ∉ ([753, 757, 759, 987, 1055, 1056, 1060, 1062] : List Tid)) : (s_496 z) tid = (s_488 z) tid := by
   exact pF _ _ _ _ _ (n_488_492 z) (n_492_496 z) tid h
 #a n_488_496
 theorem n_480_496 (z : Store) (tid : Tid) (h : tid ∉ ([1047, 1048, 748, 749, 684, 1051, 1052, 752, 753, 757, 759, 987, 1055, 1056, 1060, 1062] : List Tid)) : (s_496 z) tid = (s_480 z) tid := by
   exact pF _ _ _ _ _ (n_480_488 z) (n_488_496 z) tid h
 #a n_480_496
 theorem n_448_464 (z : Store) (tid : Tid) (h : tid ∉ ([1012, 995, 1015, 996, 1018, 1021, 720, 721, 724, 1023, 1024, 1027, 726, 727, 730, 731] : List Tid)) : (s_464 z) tid = (s_448 z) tid := by
   exact pF _ _ _ _ _ (n_448_456 z) (n_456_464 z) tid h
 #a n_448_464
 theorem n_464_472 (z : Store) (tid : Tid) (h : tid ∉ ([734, 736, 738, 1029, 1030, 1033, 1034, 1037] : List Tid)) : (s_472 z) tid = (s_464 z) tid := by
   exact pF _ _ _ _ _ (n_464_468 z) (n_468_472 z) tid h
 #a n_464_472
 theorem n_464_480 (z : Store) (tid : Tid) (h : tid ∉ ([734, 736, 738, 1029, 1030, 1033, 1034, 1037, 1039, 739, 740, 1041, 1042, 1043, 744, 745] : List Tid)) : (s_480 z) tid = (s_464 z) tid := by
   exact pF _ _ _ _ _ (n_464_472 z) (n_472_480 z) tid h
 #a n_464_480
 theorem n_448_480 (z : Store) (tid : Tid) (h : tid ∉ ([1012, 995, 1015, 996, 1018, 1021, 720, 721, 724, 1023, 1024, 1027, 726, 727, 730, 731, 734, 736, 738, 1029, 1030, 1033, 1034, 1037, 1039, 739, 740, 1041, 1042, 1043, 744, 745] : List Tid)) : (s_480 z) tid = (s_448 z) tid := by
   exact pF _ _ _ _ _ (n_448_464 z) (n_464_480 z) tid h
 #a n_448_480
 theorem r_501_0 (z : Store) : (s_501 z) 765 = (v_500_0 z) := w_500_0 z
 #a r_501_0
 theorem r_501_1 (z : Store) : (s_501 z) 610 = (z 610) := pR (k_500 z) (pR (n_496_500 z) (pR (n_480_496 z) (pR (n_448_480 z) (pR (n_384_448 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_64 z)))))))
 #a r_501_1
 def v_501_0 (z : Store) : Tensor := fw_linear (v_500_0 z) (z 610)
 def s_502 (z : Store) : Store := storeSet (s_501 z) [(766, fw_linear ((s_501 z) 765) ((s_501 z) 610))]
 theorem t_501 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_512) (pmPeers pmNode_512) (s_501 z) pmNode_512 none = some (s_502 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_501
 theorem k_501 (z : Store) (tid : Tid) (h : tid ∉ [766]) : (s_502 z) tid = (s_501 z) tid := by
   unfold s_502
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_501
 theorem w_501_0 (z : Store) : (s_502 z) 766 = v_501_0 z := by
   unfold s_502
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_501_0, r_501_0 z, r_501_1 z] <;> rfl
 #a w_501_0
 theorem h_501_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_501_0 z).shape = [1, 8, 64] := by
   unfold v_501_0
   exact fw_linear_3d_shape 1 8 64 64 (v_500_0 z) (z 610) (h_500_0 z z_) (i_64 z z_)
 #a h_501_0
 attribute [local irreducible] v_501_0
 attribute [local irreducible] s_502
 record_prefix_opacity v_493_0 s_494 v_494_0 s_495 v_495_0 s_496 v_496_0 s_497 v_497_0 s_498 v_498_0 s_499 v_499_0 s_500 v_500_0 s_501 v_501_0 s_502

 end
 end TrainVerify.Denote.RuntimeWorld
