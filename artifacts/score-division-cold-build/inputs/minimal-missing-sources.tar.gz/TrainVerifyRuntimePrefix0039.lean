import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0038
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_303_0 (z : Store) : (s_303 z) 83 = (v_286_0 z) := pR (k_302 z) (pR (k_301 z) (pR (k_300 z) (pR (n_296_300 z) (pR (n_288_296 z) (pR (k_287 z) (w_286_0 z))))))
 #a r_303_0
 theorem r_303_1 (z : Store) : (s_303 z) 195 = (v_114_0 z) := pR (k_302 z) (pR (k_301 z) (pR (k_300 z) (pR (n_296_300 z) (pR (n_288_296 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_120_128 z) (pR (n_116_120 z) (pR (k_115 z) (r_115_0 z))))))))))
 #a r_303_1
 theorem r_303_2 (z : Store) : (s_303 z) 53 = (z 53) := pR (k_302 z) (pR (k_301 z) (pR (k_300 z) (pR (n_296_300 z) (pR (n_288_296 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_120_128 z) (pR (n_116_120 z) (pR (k_115 z) (r_115_1 z))))))))))
 #a r_303_2
 def v_303_0 (z : Store) : Tensor := (bw_linear (v_286_0 z) (v_114_0 z) (z 53)).1
 def v_303_1 (z : Store) : Tensor := (bw_linear (v_286_0 z) (v_114_0 z) (z 53)).2
 def s_304 (z : Store) : Store := storeSet (s_303 z) [(197, (bw_linear ((s_303 z) 83) ((s_303 z) 195) ((s_303 z) 53)).1), (54, (bw_linear ((s_303 z) 83) ((s_303 z) 195) ((s_303 z) 53)).2)]
 theorem t_303 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_152) (pmPeers pmNode_152) (s_303 z) pmNode_152 none = some (s_304 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_303
 theorem k_303 (z : Store) (tid : Tid) (h : tid ∉ [197, 54]) : (s_304 z) tid = (s_303 z) tid := by
   unfold s_304
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_303
 theorem w_303_0 (z : Store) : (s_304 z) 197 = v_303_0 z := by
   unfold s_304
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_303_0, r_303_0 z, r_303_1 z, r_303_2 z] <;> rfl
 #a w_303_0
 theorem h_303_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_303_0 z).shape = [1, 16, 32] := by
   unfold v_303_0
   exact bw_linear_3d_fst_shape 1 16 64 32 (v_286_0 z) (v_114_0 z) (z 53) (h_286_0 z z_) (h_114_0 z z_) (i_30 z z_)
 #a h_303_0
 attribute [local irreducible] v_303_0
 theorem w_303_1 (z : Store) : (s_304 z) 54 = v_303_1 z := by
   unfold s_304
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_303_1, r_303_0 z, r_303_1 z, r_303_2 z] <;> rfl
 #a w_303_1
 theorem h_303_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_303_1 z).shape = [64, 32] := by
   unfold v_303_1
   exact bw_linear_3d_snd_shape 1 16 64 32 (v_286_0 z) (v_114_0 z) (z 53) (h_286_0 z z_) (h_114_0 z z_) (i_30 z z_)
 #a h_303_1
 attribute [local irreducible] v_303_1
 attribute [local irreducible] s_304
 theorem r_304_0 (z : Store) : (s_304 z) 200 = (v_299_0 z) := pR (k_303 z) (pR (k_302 z) (r_302_0 z))
 #a r_304_0
 theorem r_304_1 (z : Store) : (s_304 z) 503 = (v_301_0 z) := pR (k_303 z) (pR (k_302 z) (r_302_1 z))
 #a r_304_1
 def v_304_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_299_0 z), (v_301_0 z)]
 theorem g_304 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_387) (s_304 z) pmNode_387 1 2 494 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_387, r_304_0 z, r_304_1 z, h_299_0 z z_, h_301_0 z z_]
 #a g_304
 def s_305 (z : Store) : Store := pL [0, 1] (s_304 z) pmNode_387 1 2
 theorem t_304 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_387) (pmPeers pmNode_387) (s_304 z) pmNode_387 none = some (s_305 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_387) (s_304 z) pmNode_387).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 494 (by decide) (g_304 z z_)]
   rfl
 #a t_304
 theorem k_304 (z : Store) (tid : Tid) (h : tid ∉ [494]) : (s_305 z) tid = (s_304 z) tid := by
   unfold s_305
   dsimp only [pL, pmNode_387, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_304
 theorem w_304_0 (z : Store) : (s_305 z) 494 = v_304_0 z := by
   unfold s_305
   dsimp only [pL, pmNode_387, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_304_0, r_304_0 z, r_304_1 z] <;> rfl
 #a w_304_0
 theorem h_304_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_304_0 z).shape = [1, 16, 32] := by
   unfold v_304_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_299_0 z z_]
 #a h_304_0
 attribute [local irreducible] v_304_0
 attribute [local irreducible] s_305
 theorem n_300_304 (z : Store) (tid : Tid) (h : tid ∉ ([504, 503, 190, 197, 54] : List Tid)) : (s_304 z) tid = (s_300 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_300 z) (k_301 z)) (pF _ _ _ _ _ (k_302 z) (k_303 z)) tid h
 #a n_300_304
 theorem n_296_304 (z : Store) (tid : Tid) (h : tid ∉ ([385, 507, 201, 200, 504, 503, 190, 197, 54] : List Tid)) : (s_304 z) tid = (s_296 z) tid := by
   exact pF _ _ _ _ _ (n_296_300 z) (n_300_304 z) tid h
 #a n_296_304
 theorem n_288_304 (z : Store) (tid : Tid) (h : tid ∉ ([386, 515, 209, 208, 512, 511, 82, 204, 385, 507, 201, 200, 504, 503, 190, 197, 54] : List Tid)) : (s_304 z) tid = (s_288 z) tid := by
   exact pF _ _ _ _ _ (n_288_296 z) (n_296_304 z) tid h
 #a n_288_304
 theorem r_305_0 (z : Store) : (s_305 z) 386 = (v_288_0 z) := pR (k_304 z) (pR (n_296_304 z) (pR (n_292_296 z) (pR (k_291 z) (pR (k_290 z) (pR (k_289 z) (w_288_0 z))))))
 #a r_305_0
 theorem r_305_1 (z : Store) : (s_305 z) 498 = (v_122_0 z) := pR (k_304 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_124_128 z) (pR (k_123 z) (r_123_0 z))))))
 #a r_305_1
 theorem r_305_2 (z : Store) : (s_305 z) 356 = (z 356) := pR (k_304 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_124_128 z) (pR (k_123 z) (r_123_1 z))))))
 #a r_305_2
 def v_305_0 (z : Store) : Tensor := (bw_linear (v_288_0 z) (v_122_0 z) (z 356)).1
 def v_305_1 (z : Store) : Tensor := (bw_linear (v_288_0 z) (v_122_0 z) (z 356)).2
 def s_306 (z : Store) : Store := storeSet (s_305 z) [(500, (bw_linear ((s_305 z) 386) ((s_305 z) 498) ((s_305 z) 356)).1), (357, (bw_linear ((s_305 z) 386) ((s_305 z) 498) ((s_305 z) 356)).2)]
 theorem t_305 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_388) (pmPeers pmNode_388) (s_305 z) pmNode_388 none = some (s_306 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_305
 theorem k_305 (z : Store) (tid : Tid) (h : tid ∉ [500, 357]) : (s_306 z) tid = (s_305 z) tid := by
   unfold s_306
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_305
 theorem w_305_0 (z : Store) : (s_306 z) 500 = v_305_0 z := by
   unfold s_306
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_305_0, r_305_0 z, r_305_1 z, r_305_2 z] <;> rfl
 #a w_305_0
 theorem h_305_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_305_0 z).shape = [1, 16, 32] := by
   unfold v_305_0
   exact bw_linear_3d_fst_shape 1 16 64 32 (v_288_0 z) (v_122_0 z) (z 356) (h_288_0 z z_) (h_122_0 z z_) (i_33 z z_)
 #a h_305_0
 attribute [local irreducible] v_305_0
 theorem w_305_1 (z : Store) : (s_306 z) 357 = v_305_1 z := by
   unfold s_306
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_305_1, r_305_0 z, r_305_1 z, r_305_2 z] <;> rfl
 #a w_305_1
 theorem h_305_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_305_1 z).shape = [64, 32] := by
   unfold v_305_1
   exact bw_linear_3d_snd_shape 1 16 64 32 (v_288_0 z) (v_122_0 z) (z 356) (h_288_0 z z_) (h_122_0 z z_) (i_33 z z_)
 #a h_305_1
 attribute [local irreducible] v_305_1
 attribute [local irreducible] s_306
 theorem r_306_0 (z : Store) : (s_306 z) 197 = (v_303_0 z) := pR (k_305 z) (pR (k_304 z) (w_303_0 z))
 #a r_306_0
 theorem r_306_1 (z : Store) : (s_306 z) 500 = (v_305_0 z) := w_305_0 z
 #a r_306_1
 def v_306_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_303_0 z), (v_305_0 z)]
 theorem g_306 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_153) (s_306 z) pmNode_153 2 1 298 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_153, r_306_0 z, r_306_1 z, h_303_0 z z_, h_305_0 z z_]
 #a g_306
 def s_307 (z : Store) : Store := pL [0, 1] (s_306 z) pmNode_153 2 1
 theorem t_306 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_153) (pmPeers pmNode_153) (s_306 z) pmNode_153 none = some (s_307 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_153) (s_306 z) pmNode_153).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 298 (by decide) (g_306 z z_)]
   rfl
 #a t_306
 theorem k_306 (z : Store) (tid : Tid) (h : tid ∉ [298]) : (s_307 z) tid = (s_306 z) tid := by
   unfold s_307
   dsimp only [pL, pmNode_153, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_306
 theorem w_306_0 (z : Store) : (s_307 z) 298 = v_306_0 z := by
   unfold s_307
   dsimp only [pL, pmNode_153, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_306_0, r_306_0 z, r_306_1 z] <;> rfl
 #a w_306_0
 theorem h_306_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_306_0 z).shape = [1, 8, 64] := by
   unfold v_306_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_303_0 z z_]
 #a h_306_0
 attribute [local irreducible] v_306_0
 attribute [local irreducible] s_307
 theorem r_307_0 (z : Store) : (s_307 z) 82 = (v_294_0 z) := pR (k_306 z) (pR (k_305 z) (pR (k_304 z) (pR (n_296_304 z) (pR (k_295 z) (w_294_0 z)))))
 #a r_307_0
 theorem r_307_1 (z : Store) : (s_307 z) 192 = (v_112_0 z) := pR (k_306 z) (pR (k_305 z) (pR (k_304 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_120_128 z) (pR (n_116_120 z) (pR (k_115 z) (pR (k_114 z) (pR (k_113 z) (r_113_0 z)))))))))))
 #a r_307_1
 theorem r_307_2 (z : Store) : (s_307 z) 50 = (z 50) := pR (k_306 z) (pR (k_305 z) (pR (k_304 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_120_128 z) (pR (n_116_120 z) (pR (k_115 z) (pR (k_114 z) (pR (k_113 z) (r_113_1 z)))))))))))
 #a r_307_2
 def v_307_0 (z : Store) : Tensor := (bw_linear (v_294_0 z) (v_112_0 z) (z 50)).1
 def v_307_1 (z : Store) : Tensor := (bw_linear (v_294_0 z) (v_112_0 z) (z 50)).2
 def s_308 (z : Store) : Store := storeSet (s_307 z) [(194, (bw_linear ((s_307 z) 82) ((s_307 z) 192) ((s_307 z) 50)).1), (51, (bw_linear ((s_307 z) 82) ((s_307 z) 192) ((s_307 z) 50)).2)]
 theorem t_307 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_154) (pmPeers pmNode_154) (s_307 z) pmNode_154 none = some (s_308 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_307
 theorem k_307 (z : Store) (tid : Tid) (h : tid ∉ [194, 51]) : (s_308 z) tid = (s_307 z) tid := by
   unfold s_308
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_307
 theorem w_307_0 (z : Store) : (s_308 z) 194 = v_307_0 z := by
   unfold s_308
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_307_0, r_307_0 z, r_307_1 z, r_307_2 z] <;> rfl
 #a w_307_0
 theorem h_307_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_307_0 z).shape = [1, 16, 32] := by
   unfold v_307_0
   exact bw_linear_3d_fst_shape 1 16 64 32 (v_294_0 z) (v_112_0 z) (z 50) (h_294_0 z z_) (h_112_0 z z_) (i_29 z z_)
 #a h_307_0
 attribute [local irreducible] v_307_0
 theorem w_307_1 (z : Store) : (s_308 z) 51 = v_307_1 z := by
   unfold s_308
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_307_1, r_307_0 z, r_307_1 z, r_307_2 z] <;> rfl
 #a w_307_1
 theorem h_307_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_307_1 z).shape = [64, 32] := by
   unfold v_307_1
   exact bw_linear_3d_snd_shape 1 16 64 32 (v_294_0 z) (v_112_0 z) (z 50) (h_294_0 z z_) (h_112_0 z z_) (i_29 z z_)
 #a h_307_1
 attribute [local irreducible] v_307_1
 attribute [local irreducible] s_308
 theorem r_308_0 (z : Store) : (s_308 z) 197 = (v_303_0 z) := pR (k_307 z) (pR (k_306 z) (r_306_0 z))
 #a r_308_0
 theorem r_308_1 (z : Store) : (s_308 z) 500 = (v_305_0 z) := pR (k_307 z) (pR (k_306 z) (r_306_1 z))
 #a r_308_1
 def v_308_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_303_0 z), (v_305_0 z)]
 theorem g_308 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_389) (s_308 z) pmNode_389 2 1 601 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_389, r_308_0 z, r_308_1 z, h_303_0 z z_, h_305_0 z z_]
 #a g_308
 def s_309 (z : Store) : Store := pL [0, 1] (s_308 z) pmNode_389 2 1
 theorem t_308 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_389) (pmPeers pmNode_389) (s_308 z) pmNode_389 none = some (s_309 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_389) (s_308 z) pmNode_389).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 601 (by decide) (g_308 z z_)]
   rfl
 #a t_308
 theorem k_308 (z : Store) (tid : Tid) (h : tid ∉ [601]) : (s_309 z) tid = (s_308 z) tid := by
   unfold s_309
   dsimp only [pL, pmNode_389, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_308
 theorem w_308_0 (z : Store) : (s_309 z) 601 = v_308_0 z := by
   unfold s_309
   dsimp only [pL, pmNode_389, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_308_0, r_308_0 z, r_308_1 z] <;> rfl
 #a w_308_0
 theorem h_308_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_308_0 z).shape = [1, 8, 64] := by
   unfold v_308_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_303_0 z z_]
 #a h_308_0
 attribute [local irreducible] v_308_0
 attribute [local irreducible] s_309
 theorem n_304_308 (z : Store) (tid : Tid) (h : tid ∉ ([494, 500, 357, 298, 194, 51] : List Tid)) : (s_308 z) tid = (s_304 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_304 z) (k_305 z)) (pF _ _ _ _ _ (k_306 z) (k_307 z)) tid h
 #a n_304_308
 theorem r_309_0 (z : Store) : (s_309 z) 385 = (v_296_0 z) := pR (k_308 z) (pR (n_304_308 z) (pR (n_300_304 z) (pR (k_299 z) (pR (k_298 z) (pR (k_297 z) (w_296_0 z))))))
 #a r_309_0
 theorem r_309_1 (z : Store) : (s_309 z) 495 = (v_120_0 z) := pR (k_308 z) (pR (n_304_308 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_124_128 z) (pR (k_123 z) (pR (k_122 z) (pR (k_121 z) (r_121_0 z)))))))))
 #a r_309_1
 theorem r_309_2 (z : Store) : (s_309 z) 353 = (z 353) := pR (k_308 z) (pR (n_304_308 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_124_128 z) (pR (k_123 z) (pR (k_122 z) (pR (k_121 z) (r_121_1 z)))))))))
 #a r_309_2
 def v_309_0 (z : Store) : Tensor := (bw_linear (v_296_0 z) (v_120_0 z) (z 353)).1
 def v_309_1 (z : Store) : Tensor := (bw_linear (v_296_0 z) (v_120_0 z) (z 353)).2
 def s_310 (z : Store) : Store := storeSet (s_309 z) [(497, (bw_linear ((s_309 z) 385) ((s_309 z) 495) ((s_309 z) 353)).1), (354, (bw_linear ((s_309 z) 385) ((s_309 z) 495) ((s_309 z) 353)).2)]
 theorem t_309 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_390) (pmPeers pmNode_390) (s_309 z) pmNode_390 none = some (s_310 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_309
 theorem k_309 (z : Store) (tid : Tid) (h : tid ∉ [497, 354]) : (s_310 z) tid = (s_309 z) tid := by
   unfold s_310
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_309
 theorem w_309_0 (z : Store) : (s_310 z) 497 = v_309_0 z := by
   unfold s_310
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_309_0, r_309_0 z, r_309_1 z, r_309_2 z] <;> rfl
 #a w_309_0
 theorem h_309_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_309_0 z).shape = [1, 16, 32] := by
   unfold v_309_0
   exact bw_linear_3d_fst_shape 1 16 64 32 (v_296_0 z) (v_120_0 z) (z 353) (h_296_0 z z_) (h_120_0 z z_) (i_32 z z_)
 #a h_309_0
 attribute [local irreducible] v_309_0
 theorem w_309_1 (z : Store) : (s_310 z) 354 = v_309_1 z := by
   unfold s_310
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_309_1, r_309_0 z, r_309_1 z, r_309_2 z] <;> rfl
 #a w_309_1
 theorem h_309_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_309_1 z).shape = [64, 32] := by
   unfold v_309_1
   exact bw_linear_3d_snd_shape 1 16 64 32 (v_296_0 z) (v_120_0 z) (z 353) (h_296_0 z z_) (h_120_0 z z_) (i_32 z z_)
 #a h_309_1
 attribute [local irreducible] v_309_1
 attribute [local irreducible] s_310
 record_prefix_opacity v_303_0 v_303_1 s_304 v_304_0 s_305 v_305_0 v_305_1 s_306 v_306_0 s_307 v_307_0 v_307_1 s_308 v_308_0 s_309 v_309_0 v_309_1 s_310

 end
 end TrainVerify.Denote.RuntimeWorld
