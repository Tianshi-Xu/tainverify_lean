import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0085
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_680_0 (z : Store) : (s_680 z) 851 = (v_675_0 z) := pR (k_679 z) (pR (k_678 z) (r_678_0 z))
 #a r_680_0
 theorem r_680_1 (z : Store) : (s_680 z) 1154 = (v_677_0 z) := pR (k_679 z) (pR (k_678 z) (r_678_1 z))
 #a r_680_1
 def v_680_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_675_0 z), (v_677_0 z)]
 theorem g_680 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_836) (s_680 z) pmNode_836 1 2 1151 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_836, r_680_0 z, r_680_1 z, h_675_0 z z_, h_677_0 z z_]
 #a g_680
 def s_681 (z : Store) : Store := pL [2, 3] (s_680 z) pmNode_836 1 2
 theorem t_680 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_836) (pmPeers pmNode_836) (s_680 z) pmNode_836 none = some (s_681 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_836) (s_680 z) pmNode_836).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1151 (by decide) (g_680 z z_)]
   rfl
 #a t_680
 theorem k_680 (z : Store) (tid : Tid) (h : tid ∉ [1151]) : (s_681 z) tid = (s_680 z) tid := by
   unfold s_681
   dsimp only [pL, pmNode_836, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_680
 theorem w_680_0 (z : Store) : (s_681 z) 1151 = v_680_0 z := by
   unfold s_681
   dsimp only [pL, pmNode_836, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_680_0, r_680_0 z, r_680_1 z] <;> rfl
 #a w_680_0
 theorem h_680_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_680_0 z).shape = [1, 16, 2, 16] := by
   unfold v_680_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_675_0 z z_]
 #a h_680_0
 attribute [local irreducible] v_680_0
 attribute [local irreducible] s_681
 theorem n_676_680 (z : Store) (tid : Tid) (h : tid ∉ ([1155, 1154, 848, 847] : List Tid)) : (s_680 z) tid = (s_676 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_676 z) (k_677 z)) (pF _ _ _ _ _ (k_678 z) (k_679 z)) tid h
 #a n_676_680
 theorem n_672_680 (z : Store) (tid : Tid) (h : tid ∉ ([1159, 966, 1158, 852, 851, 1155, 1154, 848, 847] : List Tid)) : (s_680 z) tid = (s_672 z) tid := by
   exact pF _ _ _ _ _ (n_672_676 z) (n_676_680 z) tid h
 #a n_672_680
 theorem r_681_0 (z : Store) : (s_681 z) 1151 = (v_680_0 z) := w_680_0 z
 #a r_681_0
 theorem r_681_1 (z : Store) : (s_681 z) 1148 = (v_588_0 z) := pR (k_680 z) (pR (n_672_680 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_592_608 z) (pR (k_591 z) (pR (k_590 z) (pR (k_589 z) (r_589_0 z))))))))
 #a r_681_1
 def v_681_0 (z : Store) : Tensor := transposeAxes 1 2 (v_680_0 z)
 def s_682 (z : Store) : Store := storeSet (s_681 z) [(1150, transposeAxes 1 2 ((s_681 z) 1151))]
 theorem t_681 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_837) (pmPeers pmNode_837) (s_681 z) pmNode_837 none = some (s_682 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_681
 theorem k_681 (z : Store) (tid : Tid) (h : tid ∉ [1150]) : (s_682 z) tid = (s_681 z) tid := by
   unfold s_682
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_681
 theorem w_681_0 (z : Store) : (s_682 z) 1150 = v_681_0 z := by
   unfold s_682
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_681_0, r_681_0 z, r_681_1 z] <;> rfl
 #a w_681_0
 theorem h_681_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_681_0 z).shape = [1, 2, 16, 16] := by
   unfold v_681_0
   change listSwapAt _ _ _ = _
   rw [h_680_0 z z_]
   rfl
 #a h_681_0
 attribute [local irreducible] v_681_0
 attribute [local irreducible] s_682
 theorem r_682_0 (z : Store) : (s_682 z) 847 = (v_679_0 z) := pR (k_681 z) (pR (k_680 z) (w_679_0 z))
 #a r_682_0
 theorem r_682_1 (z : Store) : (s_682 z) 1150 = (v_681_0 z) := w_681_0 z
 #a r_682_1
 def v_682_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_679_0 z), (v_681_0 z)]
 theorem g_682 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_602) (s_682 z) pmNode_602 1 2 843 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_602, r_682_0 z, r_682_1 z, h_679_0 z z_, h_681_0 z z_]
 #a g_682
 def s_683 (z : Store) : Store := pL [2, 3] (s_682 z) pmNode_602 1 2
 theorem t_682 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_602) (pmPeers pmNode_602) (s_682 z) pmNode_602 none = some (s_683 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_602) (s_682 z) pmNode_602).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 843 (by decide) (g_682 z z_)]
   rfl
 #a t_682
 theorem k_682 (z : Store) (tid : Tid) (h : tid ∉ [843]) : (s_683 z) tid = (s_682 z) tid := by
   unfold s_683
   dsimp only [pL, pmNode_602, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_682
 theorem w_682_0 (z : Store) : (s_683 z) 843 = v_682_0 z := by
   unfold s_683
   dsimp only [pL, pmNode_602, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_682_0, r_682_0 z, r_682_1 z] <;> rfl
 #a w_682_0
 theorem h_682_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_682_0 z).shape = [1, 4, 8, 16] := by
   unfold v_682_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_679_0 z z_]
 #a h_682_0
 attribute [local irreducible] v_682_0
 attribute [local irreducible] s_683
 theorem r_683_0 (z : Store) : (s_683 z) 843 = (v_682_0 z) := w_682_0 z
 #a r_683_0
 theorem r_683_1 (z : Store) : (s_683 z) 839 = (v_579_0 z) := pR (k_682 z) (pR (k_681 z) (pR (k_680 z) (pR (n_672_680 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_592_608 z) (pR (n_584_592 z) (pR (k_583 z) (pR (k_582 z) (pR (k_581 z) (r_581_0 z)))))))))))
 #a r_683_1
 theorem r_683_2 (z : Store) : (s_683 z) 685 = (v_580_0 z) := pR (k_682 z) (pR (k_681 z) (pR (k_680 z) (pR (n_672_680 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_592_608 z) (pR (n_584_592 z) (pR (k_583 z) (pR (k_582 z) (pR (k_581 z) (r_581_1 z)))))))))))
 #a r_683_2
 def v_683_0 (z : Store) : Tensor := (batchedMatmulBwd (v_682_0 z) (v_579_0 z) (v_580_0 z)).1
 def v_683_1 (z : Store) : Tensor := (batchedMatmulBwd (v_682_0 z) (v_579_0 z) (v_580_0 z)).2
 def s_684 (z : Store) : Store := storeSet (s_683 z) [(841, (batchedMatmulBwd ((s_683 z) 843) ((s_683 z) 839) ((s_683 z) 685)).1), (844, (batchedMatmulBwd ((s_683 z) 843) ((s_683 z) 839) ((s_683 z) 685)).2)]
 theorem t_683 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_603) (pmPeers pmNode_603) (s_683 z) pmNode_603 none = some (s_684 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_683
 theorem k_683 (z : Store) (tid : Tid) (h : tid ∉ [841, 844]) : (s_684 z) tid = (s_683 z) tid := by
   unfold s_684
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_683
 theorem w_683_0 (z : Store) : (s_684 z) 841 = v_683_0 z := by
   unfold s_684
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_683_0, r_683_0 z, r_683_1 z, r_683_2 z] <;> rfl
 #a w_683_0
 theorem h_683_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_683_0 z).shape = [1, 4, 8, 16] := by
   unfold v_683_0
   change (batchedMatmul (v_682_0 z) (transpose2d (v_580_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_682_0 z z_, h_580_0 z z_]
   rfl
 #a h_683_0
 attribute [local irreducible] v_683_0
 theorem w_683_1 (z : Store) : (s_684 z) 844 = v_683_1 z := by
   unfold s_684
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_683_1, r_683_0 z, r_683_1 z, r_683_2 z] <;> rfl
 #a w_683_1
 theorem h_683_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_683_1 z).shape = [1, 4, 16, 16] := by
   unfold v_683_1
   change (batchedMatmul (transpose2d (v_579_0 z)) (v_682_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_682_0 z z_, h_579_0 z z_]
   rfl
 #a h_683_1
 attribute [local irreducible] v_683_1
 attribute [local irreducible] s_684
 theorem r_684_0 (z : Store) : (s_684 z) 847 = (v_679_0 z) := pR (k_683 z) (pR (k_682 z) (r_682_0 z))
 #a r_684_0
 theorem r_684_1 (z : Store) : (s_684 z) 1150 = (v_681_0 z) := pR (k_683 z) (pR (k_682 z) (r_682_1 z))
 #a r_684_1
 def v_684_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_679_0 z), (v_681_0 z)]
 theorem g_684 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_838) (s_684 z) pmNode_838 1 2 1147 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_838, r_684_0 z, r_684_1 z, h_679_0 z z_, h_681_0 z z_]
 #a g_684
 def s_685 (z : Store) : Store := pL [2, 3] (s_684 z) pmNode_838 1 2
 theorem t_684 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_838) (pmPeers pmNode_838) (s_684 z) pmNode_838 none = some (s_685 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_838) (s_684 z) pmNode_838).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1147 (by decide) (g_684 z z_)]
   rfl
 #a t_684
 theorem k_684 (z : Store) (tid : Tid) (h : tid ∉ [1147]) : (s_685 z) tid = (s_684 z) tid := by
   unfold s_685
   dsimp only [pL, pmNode_838, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_684
 theorem w_684_0 (z : Store) : (s_685 z) 1147 = v_684_0 z := by
   unfold s_685
   dsimp only [pL, pmNode_838, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_684_0, r_684_0 z, r_684_1 z] <;> rfl
 #a w_684_0
 theorem h_684_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_684_0 z).shape = [1, 4, 8, 16] := by
   unfold v_684_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_679_0 z z_]
 #a h_684_0
 attribute [local irreducible] v_684_0
 attribute [local irreducible] s_685
 theorem n_680_684 (z : Store) (tid : Tid) (h : tid ∉ ([1151, 1150, 843, 841, 844] : List Tid)) : (s_684 z) tid = (s_680 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_680 z) (k_681 z)) (pF _ _ _ _ _ (k_682 z) (k_683 z)) tid h
 #a n_680_684
 theorem r_685_0 (z : Store) : (s_685 z) 1147 = (v_684_0 z) := w_684_0 z
 #a r_685_0
 theorem r_685_1 (z : Store) : (s_685 z) 1142 = (v_583_0 z) := pR (k_684 z) (pR (n_680_684 z) (pR (n_672_680 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_592_608 z) (pR (n_588_592 z) (pR (k_587 z) (pR (k_586 z) (pR (k_585 z) (r_585_0 z))))))))))
 #a r_685_1
 theorem r_685_2 (z : Store) : (s_685 z) 988 = (v_584_0 z) := pR (k_684 z) (pR (n_680_684 z) (pR (n_672_680 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_592_608 z) (pR (n_588_592 z) (pR (k_587 z) (pR (k_586 z) (pR (k_585 z) (r_585_1 z))))))))))
 #a r_685_2
 def v_685_0 (z : Store) : Tensor := (batchedMatmulBwd (v_684_0 z) (v_583_0 z) (v_584_0 z)).1
 def v_685_1 (z : Store) : Tensor := (batchedMatmulBwd (v_684_0 z) (v_583_0 z) (v_584_0 z)).2
 def s_686 (z : Store) : Store := storeSet (s_685 z) [(1144, (batchedMatmulBwd ((s_685 z) 1147) ((s_685 z) 1142) ((s_685 z) 988)).1), (1146, (batchedMatmulBwd ((s_685 z) 1147) ((s_685 z) 1142) ((s_685 z) 988)).2)]
 theorem t_685 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_839) (pmPeers pmNode_839) (s_685 z) pmNode_839 none = some (s_686 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_685
 theorem k_685 (z : Store) (tid : Tid) (h : tid ∉ [1144, 1146]) : (s_686 z) tid = (s_685 z) tid := by
   unfold s_686
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_685
 theorem w_685_0 (z : Store) : (s_686 z) 1144 = v_685_0 z := by
   unfold s_686
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_685_0, r_685_0 z, r_685_1 z, r_685_2 z] <;> rfl
 #a w_685_0
 theorem h_685_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_685_0 z).shape = [1, 4, 8, 16] := by
   unfold v_685_0
   change (batchedMatmul (v_684_0 z) (transpose2d (v_584_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_684_0 z z_, h_584_0 z z_]
   rfl
 #a h_685_0
 attribute [local irreducible] v_685_0
 theorem w_685_1 (z : Store) : (s_686 z) 1146 = v_685_1 z := by
   unfold s_686
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_685_1, r_685_0 z, r_685_1 z, r_685_2 z] <;> rfl
 #a w_685_1
 theorem h_685_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_685_1 z).shape = [1, 4, 16, 16] := by
   unfold v_685_1
   change (batchedMatmul (transpose2d (v_583_0 z)) (v_684_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_684_0 z z_, h_583_0 z z_]
   rfl
 #a h_685_1
 attribute [local irreducible] v_685_1
 attribute [local irreducible] s_686
 theorem r_686_0 (z : Store) : (s_686 z) 844 = (v_683_1 z) := pR (k_685 z) (pR (k_684 z) (w_683_1 z))
 #a r_686_0
 theorem r_686_1 (z : Store) : (s_686 z) 1146 = (v_685_1 z) := w_685_1 z
 #a r_686_1
 def v_686_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 0 [(v_683_1 z), (v_685_1 z)]
 def s_687 (z : Store) : Store := storeSet (s_686 z) [(827, reduceScatterPrimDimN 2 2 0 [((s_686 z) 844), ((s_686 z) 1146)])]
 theorem t_686 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_604) (pmPeers pmNode_604) (s_686 z) pmNode_604 none = some (s_687 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_686 z) pmNode_604 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_686
 theorem k_686 (z : Store) (tid : Tid) (h : tid ∉ [827]) : (s_687 z) tid = (s_686 z) tid := by
   unfold s_687
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_686
 theorem w_686_0 (z : Store) : (s_687 z) 827 = v_686_0 z := by
   unfold s_687
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_686_0, r_686_0 z, r_686_1 z] <;> rfl
 #a w_686_0
 theorem h_686_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_686_0 z).shape = [1, 4, 8, 16] := by
   unfold v_686_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 0 _ [1, 4, 16, 16]
   · rw [allReducePrim_shape _ _ _ (v_683_1 z) rfl]
     exact h_683_1 z z_
   · decide
 #a h_686_0
 attribute [local irreducible] v_686_0
 attribute [local irreducible] s_687
 theorem r_687_0 (z : Store) : (s_687 z) 841 = (v_683_0 z) := pR (k_686 z) (pR (k_685 z) (pR (k_684 z) (w_683_0 z)))
 #a r_687_0
 theorem r_687_1 (z : Store) : (s_687 z) 838 = (v_578_0 z) := pR (k_686 z) (pR (k_685 z) (pR (k_684 z) (pR (n_680_684 z) (pR (n_672_680 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_592_608 z) (pR (n_584_592 z) (pR (n_580_584 z) (pR (k_579 z) (r_579_0 z)))))))))))
 #a r_687_1
 def v_687_0 (z : Store) : Tensor := bw_softmax (v_683_0 z) (v_578_0 z)
 def s_688 (z : Store) : Store := storeSet (s_687 z) [(840, bw_softmax ((s_687 z) 841) ((s_687 z) 838))]
 theorem t_687 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_605) (pmPeers pmNode_605) (s_687 z) pmNode_605 none = some (s_688 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_687
 theorem k_687 (z : Store) (tid : Tid) (h : tid ∉ [840]) : (s_688 z) tid = (s_687 z) tid := by
   unfold s_688
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_687
 theorem w_687_0 (z : Store) : (s_688 z) 840 = v_687_0 z := by
   unfold s_688
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_687_0, r_687_0 z, r_687_1 z] <;> rfl
 #a w_687_0
 theorem h_687_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_687_0 z).shape = [1, 4, 8, 16] := by
   unfold v_687_0
   unfold bw_softmax softmaxBwd softmaxBwdFromOutput softmax
   rw [h_578_0 z z_]
   rfl
 #a h_687_0
 attribute [local irreducible] v_687_0
 attribute [local irreducible] s_688
 record_prefix_opacity v_680_0 s_681 v_681_0 s_682 v_682_0 s_683 v_683_0 v_683_1 s_684 v_684_0 s_685 v_685_0 v_685_1 s_686 v_686_0 s_687 v_687_0 s_688

 end
 end TrainVerify.Denote.RuntimeWorld
