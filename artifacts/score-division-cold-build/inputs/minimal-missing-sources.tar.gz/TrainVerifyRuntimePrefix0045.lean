import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0044
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_345_0 (z : Store) : (s_345 z) 465 = (v_344_0 z) := w_344_0 z
 #a r_345_0
 theorem r_345_1 (z : Store) : (s_345 z) 462 = (v_80_0 z) := pR (k_344 z) (pR (n_336_344 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_88_96 z) (pR (n_84_88 z) (pR (k_83 z) (pR (k_82 z) (pR (k_81 z) (r_81_0 z)))))))))))
 #a r_345_1
 theorem r_345_2 (z : Store) : (s_345 z) 307 = (z 307) := pR (k_344 z) (pR (n_336_344 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_88_96 z) (pR (n_84_88 z) (pR (k_83 z) (pR (k_82 z) (pR (k_81 z) (r_81_1 z)))))))))))
 #a r_345_2
 def v_345_0 (z : Store) : Tensor := (bw_linear (v_344_0 z) (v_80_0 z) (z 307)).1
 def v_345_1 (z : Store) : Tensor := (bw_linear (v_344_0 z) (v_80_0 z) (z 307)).2
 def s_346 (z : Store) : Store := storeSet (s_345 z) [(464, (bw_linear ((s_345 z) 465) ((s_345 z) 462) ((s_345 z) 307)).1), (336, (bw_linear ((s_345 z) 465) ((s_345 z) 462) ((s_345 z) 307)).2)]
 theorem t_345 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_408) (pmPeers pmNode_408) (s_345 z) pmNode_408 none = some (s_346 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_345
 theorem k_345 (z : Store) (tid : Tid) (h : tid ∉ [464, 336]) : (s_346 z) tid = (s_345 z) tid := by
   unfold s_346
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_345
 theorem w_345_0 (z : Store) : (s_346 z) 464 = v_345_0 z := by
   unfold s_346
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_345_0, r_345_0 z, r_345_1 z, r_345_2 z] <;> rfl
 #a w_345_0
 theorem h_345_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_345_0 z).shape = [1, 8, 64] := by
   unfold v_345_0
   exact bw_linear_3d_fst_shape 1 8 64 64 (v_344_0 z) (v_80_0 z) (z 307) (h_344_0 z z_) (h_80_0 z z_) (i_15 z z_)
 #a h_345_0
 attribute [local irreducible] v_345_0
 theorem w_345_1 (z : Store) : (s_346 z) 336 = v_345_1 z := by
   unfold s_346
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_345_1, r_345_0 z, r_345_1 z, r_345_2 z] <;> rfl
 #a w_345_1
 theorem h_345_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_345_1 z).shape = [64, 64] := by
   unfold v_345_1
   exact bw_linear_3d_snd_shape 1 8 64 64 (v_344_0 z) (v_80_0 z) (z 307) (h_344_0 z z_) (h_80_0 z z_) (i_15 z z_)
 #a h_345_1
 attribute [local irreducible] v_345_1
 attribute [local irreducible] s_346
 theorem r_346_0 (z : Store) : (s_346 z) 161 = (v_343_0 z) := pR (k_345 z) (pR (k_344 z) (w_343_0 z))
 #a r_346_0
 theorem r_346_1 (z : Store) : (s_346 z) 464 = (v_345_0 z) := w_345_0 z
 #a r_346_1
 def v_346_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_343_0 z), (v_345_0 z)]
 theorem g_346 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_173) (s_346 z) pmNode_173 1 2 158 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_173, r_346_0 z, r_346_1 z, h_343_0 z z_, h_345_0 z z_]
 #a g_346
 def s_347 (z : Store) : Store := pL [0, 1] (s_346 z) pmNode_173 1 2
 theorem t_346 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_173) (pmPeers pmNode_173) (s_346 z) pmNode_173 none = some (s_347 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_173) (s_346 z) pmNode_173).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 158 (by decide) (g_346 z z_)]
   rfl
 #a t_346
 theorem k_346 (z : Store) (tid : Tid) (h : tid ∉ [158]) : (s_347 z) tid = (s_346 z) tid := by
   unfold s_347
   dsimp only [pL, pmNode_173, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_346
 theorem w_346_0 (z : Store) : (s_347 z) 158 = v_346_0 z := by
   unfold s_347
   dsimp only [pL, pmNode_173, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_346_0, r_346_0 z, r_346_1 z] <;> rfl
 #a w_346_0
 theorem h_346_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_346_0 z).shape = [1, 16, 32] := by
   unfold v_346_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_343_0 z z_]
 #a h_346_0
 attribute [local irreducible] v_346_0
 attribute [local irreducible] s_347
 theorem r_347_0 (z : Store) : (s_347 z) 158 = (v_346_0 z) := w_346_0 z
 #a r_347_0
 theorem r_347_1 (z : Store) : (s_347 z) 155 = (v_74_0 z) := pR (k_346 z) (pR (k_345 z) (pR (k_344 z) (pR (n_336_344 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (n_76_80 z) (pR (k_75 z) (r_75_0 z)))))))))))
 #a r_347_1
 def v_347_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_346_0 z)
 def s_348 (z : Store) : Store := storeSet (s_347 z) [(157, fw_view [1, 16, 2, 16] ((s_347 z) 158))]
 theorem t_347 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_174) (pmPeers pmNode_174) (s_347 z) pmNode_174 none = some (s_348 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_347
 theorem k_347 (z : Store) (tid : Tid) (h : tid ∉ [157]) : (s_348 z) tid = (s_347 z) tid := by
   unfold s_348
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_347
 theorem w_347_0 (z : Store) : (s_348 z) 157 = v_347_0 z := by
   unfold s_348
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_347_0, r_347_0 z, r_347_1 z] <;> rfl
 #a w_347_0
 theorem h_347_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_347_0 z).shape = [1, 16, 2, 16] := by
   unfold v_347_0
   rfl
 #a h_347_0
 attribute [local irreducible] v_347_0
 attribute [local irreducible] s_348
 theorem r_348_0 (z : Store) : (s_348 z) 161 = (v_343_0 z) := pR (k_347 z) (pR (k_346 z) (r_346_0 z))
 #a r_348_0
 theorem r_348_1 (z : Store) : (s_348 z) 464 = (v_345_0 z) := pR (k_347 z) (pR (k_346 z) (r_346_1 z))
 #a r_348_1
 def v_348_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_343_0 z), (v_345_0 z)]
 theorem g_348 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_409) (s_348 z) pmNode_409 1 2 461 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_409, r_348_0 z, r_348_1 z, h_343_0 z z_, h_345_0 z z_]
 #a g_348
 def s_349 (z : Store) : Store := pL [0, 1] (s_348 z) pmNode_409 1 2
 theorem t_348 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_409) (pmPeers pmNode_409) (s_348 z) pmNode_409 none = some (s_349 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_409) (s_348 z) pmNode_409).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 461 (by decide) (g_348 z z_)]
   rfl
 #a t_348
 theorem k_348 (z : Store) (tid : Tid) (h : tid ∉ [461]) : (s_349 z) tid = (s_348 z) tid := by
   unfold s_349
   dsimp only [pL, pmNode_409, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_348
 theorem w_348_0 (z : Store) : (s_349 z) 461 = v_348_0 z := by
   unfold s_349
   dsimp only [pL, pmNode_409, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_348_0, r_348_0 z, r_348_1 z] <;> rfl
 #a w_348_0
 theorem h_348_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_348_0 z).shape = [1, 16, 32] := by
   unfold v_348_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_343_0 z z_]
 #a h_348_0
 attribute [local irreducible] v_348_0
 attribute [local irreducible] s_349
 theorem n_344_348 (z : Store) (tid : Tid) (h : tid ∉ ([465, 464, 336, 158, 157] : List Tid)) : (s_348 z) tid = (s_344 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_344 z) (k_345 z)) (pF _ _ _ _ _ (k_346 z) (k_347 z)) tid h
 #a n_344_348
 theorem r_349_0 (z : Store) : (s_349 z) 461 = (v_348_0 z) := w_348_0 z
 #a r_349_0
 theorem r_349_1 (z : Store) : (s_349 z) 458 = (v_76_0 z) := pR (k_348 z) (pR (n_344_348 z) (pR (n_336_344 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (k_79 z) (pR (k_78 z) (pR (k_77 z) (r_77_0 z)))))))))))
 #a r_349_1
 def v_349_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_348_0 z)
 def s_350 (z : Store) : Store := storeSet (s_349 z) [(460, fw_view [1, 16, 2, 16] ((s_349 z) 461))]
 theorem t_349 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_410) (pmPeers pmNode_410) (s_349 z) pmNode_410 none = some (s_350 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_349
 theorem k_349 (z : Store) (tid : Tid) (h : tid ∉ [460]) : (s_350 z) tid = (s_349 z) tid := by
   unfold s_350
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_349
 theorem w_349_0 (z : Store) : (s_350 z) 460 = v_349_0 z := by
   unfold s_350
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_349_0, r_349_0 z, r_349_1 z] <;> rfl
 #a w_349_0
 theorem h_349_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_349_0 z).shape = [1, 16, 2, 16] := by
   unfold v_349_0
   rfl
 #a h_349_0
 attribute [local irreducible] v_349_0
 attribute [local irreducible] s_350
 theorem r_350_0 (z : Store) : (s_350 z) 157 = (v_347_0 z) := pR (k_349 z) (pR (k_348 z) (w_347_0 z))
 #a r_350_0
 theorem r_350_1 (z : Store) : (s_350 z) 460 = (v_349_0 z) := w_349_0 z
 #a r_350_1
 def v_350_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_347_0 z), (v_349_0 z)]
 theorem g_350 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_175) (s_350 z) pmNode_175 2 1 154 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_175, r_350_0 z, r_350_1 z, h_347_0 z z_, h_349_0 z z_]
 #a g_350
 def s_351 (z : Store) : Store := pL [0, 1] (s_350 z) pmNode_175 2 1
 theorem t_350 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_175) (pmPeers pmNode_175) (s_350 z) pmNode_175 none = some (s_351 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_175) (s_350 z) pmNode_175).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 154 (by decide) (g_350 z z_)]
   rfl
 #a t_350
 theorem k_350 (z : Store) (tid : Tid) (h : tid ∉ [154]) : (s_351 z) tid = (s_350 z) tid := by
   unfold s_351
   dsimp only [pL, pmNode_175, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_350
 theorem w_350_0 (z : Store) : (s_351 z) 154 = v_350_0 z := by
   unfold s_351
   dsimp only [pL, pmNode_175, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_350_0, r_350_0 z, r_350_1 z] <;> rfl
 #a w_350_0
 theorem h_350_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_350_0 z).shape = [1, 8, 4, 16] := by
   unfold v_350_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_347_0 z z_]
 #a h_350_0
 attribute [local irreducible] v_350_0
 attribute [local irreducible] s_351
 theorem r_351_0 (z : Store) : (s_351 z) 154 = (v_350_0 z) := w_350_0 z
 #a r_351_0
 theorem r_351_1 (z : Store) : (s_351 z) 151 = (v_67_0 z) := pR (k_350 z) (pR (k_349 z) (pR (k_348 z) (pR (n_344_348 z) (pR (n_336_344 z) (pR (n_320_336 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (n_72_80 z) (pR (n_68_72 z) (r_68_0 z))))))))))))
 #a r_351_1
 def v_351_0 (z : Store) : Tensor := (v_350_0 z)
 def s_352 (z : Store) : Store := storeSet (s_351 z) [(152, ((s_351 z) 154))]
 theorem t_351 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_176) (pmPeers pmNode_176) (s_351 z) pmNode_176 none = some (s_352 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_351
 theorem k_351 (z : Store) (tid : Tid) (h : tid ∉ [152]) : (s_352 z) tid = (s_351 z) tid := by
   unfold s_352
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_351
 theorem w_351_0 (z : Store) : (s_352 z) 152 = v_351_0 z := by
   unfold s_352
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_351_0, r_351_0 z, r_351_1 z] <;> rfl
 #a w_351_0
 theorem h_351_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_351_0 z).shape = [1, 8, 4, 16] := by
   unfold v_351_0
   exact h_350_0 z z_
 #a h_351_0
 attribute [local irreducible] v_351_0
 attribute [local irreducible] s_352
 theorem n_348_352 (z : Store) (tid : Tid) (h : tid ∉ ([461, 460, 154, 152] : List Tid)) : (s_352 z) tid = (s_348 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_348 z) (k_349 z)) (pF _ _ _ _ _ (k_350 z) (k_351 z)) tid h
 #a n_348_352
 theorem n_344_352 (z : Store) (tid : Tid) (h : tid ∉ ([465, 464, 336, 158, 157, 461, 460, 154, 152] : List Tid)) : (s_352 z) tid = (s_344 z) tid := by
   exact pF _ _ _ _ _ (n_344_348 z) (n_348_352 z) tid h
 #a n_344_352
 theorem n_336_352 (z : Store) (tid : Tid) (h : tid ∉ ([290, 168, 166, 167, 593, 471, 469, 470, 162, 161, 33, 465, 464, 336, 158, 157, 461, 460, 154, 152] : List Tid)) : (s_352 z) tid = (s_336 z) tid := by
   exact pF _ _ _ _ _ (n_336_344 z) (n_344_352 z) tid h
 #a n_336_352
 theorem n_320_352 (z : Store) (tid : Tid) (h : tid ∉ ([292, 184, 182, 183, 595, 487, 485, 486, 178, 176, 41, 174, 172, 39, 171, 35, 37, 481, 479, 344, 477, 475, 342, 474, 338, 340, 290, 168, 166, 167, 593, 471, 469, 470, 162, 161, 33, 465, 464, 336, 158, 157, 461, 460, 154, 152] : List Tid)) : (s_352 z) tid = (s_320 z) tid := by
   exact pF _ _ _ _ _ (n_320_336 z) (n_336_352 z) tid h
 #a n_320_352
 theorem r_352_0 (z : Store) : (s_352 z) 152 = (v_351_0 z) := w_351_0 z
 #a r_352_0
 theorem r_352_1 (z : Store) : (s_352 z) 147 = (v_66_0 z) := pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (n_72_80 z) (pR (n_68_72 z) (pR (k_67 z) (r_67_0 z))))))))
 #a r_352_1
 def v_352_0 (z : Store) : Tensor := transposeAxes 1 2 (v_351_0 z)
 def s_353 (z : Store) : Store := storeSet (s_352 z) [(149, transposeAxes 1 2 ((s_352 z) 152))]
 theorem t_352 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_177) (pmPeers pmNode_177) (s_352 z) pmNode_177 none = some (s_353 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_352
 theorem k_352 (z : Store) (tid : Tid) (h : tid ∉ [149]) : (s_353 z) tid = (s_352 z) tid := by
   unfold s_353
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_352
 theorem w_352_0 (z : Store) : (s_353 z) 149 = v_352_0 z := by
   unfold s_353
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_352_0, r_352_0 z, r_352_1 z] <;> rfl
 #a w_352_0
 theorem h_352_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_352_0 z).shape = [1, 4, 8, 16] := by
   unfold v_352_0
   change listSwapAt _ _ _ = _
   rw [h_351_0 z z_]
   rfl
 #a h_352_0
 attribute [local irreducible] v_352_0
 attribute [local irreducible] s_353
 record_prefix_opacity v_345_0 v_345_1 s_346 v_346_0 s_347 v_347_0 s_348 v_348_0 s_349 v_349_0 s_350 v_350_0 s_351 v_351_0 s_352 v_352_0 s_353

 end
 end TrainVerify.Denote.RuntimeWorld
