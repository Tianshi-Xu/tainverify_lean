import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0023
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_183_0 (z : Store) : (s_183 z) 557 = (v_182_0 z) := w_182_0 z
 #a r_183_0
 def v_183_0 (z : Store) : Tensor := (v_182_0 z)
 def v_183_1 (z : Store) : Tensor := (v_182_0 z)
 def s_184 (z : Store) : Store := storeSet (s_183 z) [(602, ((s_183 z) 557)), (604, ((s_183 z) 557))]
 theorem t_183 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_327) (pmPeers pmNode_327) (s_183 z) pmNode_327 none = some (s_184 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_183
 theorem k_183 (z : Store) (tid : Tid) (h : tid ∉ [602, 604]) : (s_184 z) tid = (s_183 z) tid := by
   unfold s_184
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_183
 theorem w_183_0 (z : Store) : (s_184 z) 602 = v_183_0 z := by
   unfold s_184
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_183_0, r_183_0 z] <;> rfl
 #a w_183_0
 theorem h_183_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_183_0 z).shape = [1, 16, 32] := by
   unfold v_183_0
   exact h_182_0 z z_
 #a h_183_0
 attribute [local irreducible] v_183_0
 theorem w_183_1 (z : Store) : (s_184 z) 604 = v_183_1 z := by
   unfold s_184
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_183_1, r_183_0 z] <;> rfl
 #a w_183_1
 theorem h_183_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_183_1 z).shape = [1, 16, 32] := by
   unfold v_183_1
   exact h_182_0 z z_
 #a h_183_1
 attribute [local irreducible] v_183_1
 attribute [local irreducible] s_184
 theorem r_184_0 (z : Store) : (s_184 z) 299 = (v_180_0 z) := pR (k_183 z) (pR (k_182 z) (pR (k_181 z) (w_180_0 z)))
 #a r_184_0
 theorem r_184_1 (z : Store) : (s_184 z) 602 = (v_183_0 z) := w_183_0 z
 #a r_184_1
 def v_184_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_180_0 z), (v_183_0 z)]
 theorem g_184 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_92) (s_184 z) pmNode_92 2 1 258 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_92, r_184_0 z, r_184_1 z, h_180_0 z z_, h_183_0 z z_]
 #a g_184
 def s_185 (z : Store) : Store := pL [0, 1] (s_184 z) pmNode_92 2 1
 theorem t_184 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_92) (pmPeers pmNode_92) (s_184 z) pmNode_92 none = some (s_185 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_92) (s_184 z) pmNode_92).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 258 (by decide) (g_184 z z_)]
   rfl
 #a t_184
 theorem k_184 (z : Store) (tid : Tid) (h : tid ∉ [258]) : (s_185 z) tid = (s_184 z) tid := by
   unfold s_185
   dsimp only [pL, pmNode_92, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_184
 theorem w_184_0 (z : Store) : (s_185 z) 258 = v_184_0 z := by
   unfold s_185
   dsimp only [pL, pmNode_92, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_184_0, r_184_0 z, r_184_1 z] <;> rfl
 #a w_184_0
 theorem h_184_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_184_0 z).shape = [1, 8, 64] := by
   unfold v_184_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_180_0 z z_]
 #a h_184_0
 attribute [local irreducible] v_184_0
 attribute [local irreducible] s_185
 theorem n_180_184 (z : Store) (tid : Tid) (h : tid ∉ ([299, 301, 556, 557, 602, 604] : List Tid)) : (s_184 z) tid = (s_180 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_180 z) (k_181 z)) (pF _ _ _ _ _ (k_182 z) (k_183 z)) tid h
 #a n_180_184
 theorem n_176_184 (z : Store) (tid : Tid) (h : tid ∉ ([551, 554, 253, 254, 299, 301, 556, 557, 602, 604] : List Tid)) : (s_184 z) tid = (s_176 z) tid := by
   exact pF _ _ _ _ _ (n_176_180 z) (n_180_184 z) tid h
 #a n_176_184
 theorem r_185_0 (z : Store) : (s_185 z) 258 = (v_184_0 z) := w_184_0 z
 #a r_185_0
 theorem r_185_1 (z : Store) : (s_185 z) 11 = (z 11) := pR (k_184 z) (pR (n_176_184 z) (pR (n_160_176 z) (pR (n_128_160 z) (pR (n_0_128 z) (e_36 z)))))
 #a r_185_1
 theorem r_185_2 (z : Store) : (s_185 z) 12 = (z 12) := pR (k_184 z) (pR (n_176_184 z) (pR (n_160_176 z) (pR (n_128_160 z) (pR (n_0_128 z) (e_37 z)))))
 #a r_185_2
 def v_185_0 (z : Store) : Tensor := fw_layernorm (v_184_0 z) (z 11) (z 12)
 def s_186 (z : Store) : Store := storeSet (s_185 z) [(259, fw_layernorm ((s_185 z) 258) ((s_185 z) 11) ((s_185 z) 12))]
 theorem t_185 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_93) (pmPeers pmNode_93) (s_185 z) pmNode_93 none = some (s_186 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_185
 theorem k_185 (z : Store) (tid : Tid) (h : tid ∉ [259]) : (s_186 z) tid = (s_185 z) tid := by
   unfold s_186
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_185
 theorem w_185_0 (z : Store) : (s_186 z) 259 = v_185_0 z := by
   unfold s_186
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_185_0, r_185_0 z, r_185_1 z, r_185_2 z] <;> rfl
 #a w_185_0
 theorem h_185_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_185_0 z).shape = [1, 8, 64] := by
   unfold v_185_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_184_0 z z_
 #a h_185_0
 attribute [local irreducible] v_185_0
 attribute [local irreducible] s_186
 theorem r_186_0 (z : Store) : (s_186 z) 299 = (v_180_0 z) := pR (k_185 z) (pR (k_184 z) (r_184_0 z))
 #a r_186_0
 theorem r_186_1 (z : Store) : (s_186 z) 602 = (v_183_0 z) := pR (k_185 z) (pR (k_184 z) (r_184_1 z))
 #a r_186_1
 def v_186_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_180_0 z), (v_183_0 z)]
 theorem g_186 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_328) (s_186 z) pmNode_328 2 1 561 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_328, r_186_0 z, r_186_1 z, h_180_0 z z_, h_183_0 z z_]
 #a g_186
 def s_187 (z : Store) : Store := pL [0, 1] (s_186 z) pmNode_328 2 1
 theorem t_186 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_328) (pmPeers pmNode_328) (s_186 z) pmNode_328 none = some (s_187 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_328) (s_186 z) pmNode_328).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 561 (by decide) (g_186 z z_)]
   rfl
 #a t_186
 theorem k_186 (z : Store) (tid : Tid) (h : tid ∉ [561]) : (s_187 z) tid = (s_186 z) tid := by
   unfold s_187
   dsimp only [pL, pmNode_328, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_186
 theorem w_186_0 (z : Store) : (s_187 z) 561 = v_186_0 z := by
   unfold s_187
   dsimp only [pL, pmNode_328, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_186_0, r_186_0 z, r_186_1 z] <;> rfl
 #a w_186_0
 theorem h_186_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_186_0 z).shape = [1, 8, 64] := by
   unfold v_186_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_180_0 z z_]
 #a h_186_0
 attribute [local irreducible] v_186_0
 attribute [local irreducible] s_187
 theorem r_187_0 (z : Store) : (s_187 z) 561 = (v_186_0 z) := w_186_0 z
 #a r_187_0
 theorem r_187_1 (z : Store) : (s_187 z) 314 = (z 314) := pR (k_186 z) (pR (k_185 z) (pR (k_184 z) (pR (n_176_184 z) (pR (n_160_176 z) (pR (n_128_160 z) (pR (n_0_128 z) (e_38 z)))))))
 #a r_187_1
 theorem r_187_2 (z : Store) : (s_187 z) 315 = (z 315) := pR (k_186 z) (pR (k_185 z) (pR (k_184 z) (pR (n_176_184 z) (pR (n_160_176 z) (pR (n_128_160 z) (pR (n_0_128 z) (e_39 z)))))))
 #a r_187_2
 def v_187_0 (z : Store) : Tensor := fw_layernorm (v_186_0 z) (z 314) (z 315)
 def s_188 (z : Store) : Store := storeSet (s_187 z) [(562, fw_layernorm ((s_187 z) 561) ((s_187 z) 314) ((s_187 z) 315))]
 theorem t_187 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_329) (pmPeers pmNode_329) (s_187 z) pmNode_329 none = some (s_188 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_187
 theorem k_187 (z : Store) (tid : Tid) (h : tid ∉ [562]) : (s_188 z) tid = (s_187 z) tid := by
   unfold s_188
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_187
 theorem w_187_0 (z : Store) : (s_188 z) 562 = v_187_0 z := by
   unfold s_188
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_187_0, r_187_0 z, r_187_1 z, r_187_2 z] <;> rfl
 #a w_187_0
 theorem h_187_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_187_0 z).shape = [1, 8, 64] := by
   unfold v_187_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_186_0 z z_
 #a h_187_0
 attribute [local irreducible] v_187_0
 attribute [local irreducible] s_188
 theorem r_188_0 (z : Store) : (s_188 z) 259 = (v_185_0 z) := pR (k_187 z) (pR (k_186 z) (w_185_0 z))
 #a r_188_0
 theorem r_188_1 (z : Store) : (s_188 z) 562 = (v_187_0 z) := w_187_0 z
 #a r_188_1
 def v_188_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_185_0 z), (v_187_0 z)]
 theorem g_188 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_94) (s_188 z) pmNode_94 1 2 262 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_94, r_188_0 z, r_188_1 z, h_185_0 z z_, h_187_0 z z_]
 #a g_188
 def s_189 (z : Store) : Store := pL [0, 1] (s_188 z) pmNode_94 1 2
 theorem t_188 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_94) (pmPeers pmNode_94) (s_188 z) pmNode_94 none = some (s_189 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_94) (s_188 z) pmNode_94).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 262 (by decide) (g_188 z z_)]
   rfl
 #a t_188
 theorem k_188 (z : Store) (tid : Tid) (h : tid ∉ [262]) : (s_189 z) tid = (s_188 z) tid := by
   unfold s_189
   dsimp only [pL, pmNode_94, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_188
 theorem w_188_0 (z : Store) : (s_189 z) 262 = v_188_0 z := by
   unfold s_189
   dsimp only [pL, pmNode_94, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_188_0, r_188_0 z, r_188_1 z] <;> rfl
 #a w_188_0
 theorem h_188_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_188_0 z).shape = [1, 16, 32] := by
   unfold v_188_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_185_0 z z_]
 #a h_188_0
 attribute [local irreducible] v_188_0
 attribute [local irreducible] s_189
 theorem n_184_188 (z : Store) (tid : Tid) (h : tid ∉ ([258, 259, 561, 562] : List Tid)) : (s_188 z) tid = (s_184 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_184 z) (k_185 z)) (pF _ _ _ _ _ (k_186 z) (k_187 z)) tid h
 #a n_184_188
 theorem r_189_0 (z : Store) : (s_189 z) 262 = (v_188_0 z) := w_188_0 z
 #a r_189_0
 theorem r_189_1 (z : Store) : (s_189 z) 63 = (z 63) := pR (k_188 z) (pR (n_184_188 z) (pR (n_176_184 z) (pR (n_160_176 z) (pR (n_128_160 z) (pR (n_0_128 z) (e_40 z))))))
 #a r_189_1
 def v_189_0 (z : Store) : Tensor := fw_linear (v_188_0 z) (z 63)
 def s_190 (z : Store) : Store := storeSet (s_189 z) [(263, fw_linear ((s_189 z) 262) ((s_189 z) 63))]
 theorem t_189 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_95) (pmPeers pmNode_95) (s_189 z) pmNode_95 none = some (s_190 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_189
 theorem k_189 (z : Store) (tid : Tid) (h : tid ∉ [263]) : (s_190 z) tid = (s_189 z) tid := by
   unfold s_190
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_189
 theorem w_189_0 (z : Store) : (s_190 z) 263 = v_189_0 z := by
   unfold s_190
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_189_0, r_189_0 z, r_189_1 z] <;> rfl
 #a w_189_0
 theorem h_189_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_189_0 z).shape = [1, 16, 256] := by
   unfold v_189_0
   exact fw_linear_3d_shape 1 16 32 256 (v_188_0 z) (z 63) (h_188_0 z z_) (i_40 z z_)
 #a h_189_0
 attribute [local irreducible] v_189_0
 attribute [local irreducible] s_190
 theorem r_190_0 (z : Store) : (s_190 z) 259 = (v_185_0 z) := pR (k_189 z) (pR (k_188 z) (r_188_0 z))
 #a r_190_0
 theorem r_190_1 (z : Store) : (s_190 z) 562 = (v_187_0 z) := pR (k_189 z) (pR (k_188 z) (r_188_1 z))
 #a r_190_1
 def v_190_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_185_0 z), (v_187_0 z)]
 theorem g_190 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_330) (s_190 z) pmNode_330 1 2 565 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_330, r_190_0 z, r_190_1 z, h_185_0 z z_, h_187_0 z z_]
 #a g_190
 def s_191 (z : Store) : Store := pL [0, 1] (s_190 z) pmNode_330 1 2
 theorem t_190 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_330) (pmPeers pmNode_330) (s_190 z) pmNode_330 none = some (s_191 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_330) (s_190 z) pmNode_330).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 565 (by decide) (g_190 z z_)]
   rfl
 #a t_190
 theorem k_190 (z : Store) (tid : Tid) (h : tid ∉ [565]) : (s_191 z) tid = (s_190 z) tid := by
   unfold s_191
   dsimp only [pL, pmNode_330, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_190
 theorem w_190_0 (z : Store) : (s_191 z) 565 = v_190_0 z := by
   unfold s_191
   dsimp only [pL, pmNode_330, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_190_0, r_190_0 z, r_190_1 z] <;> rfl
 #a w_190_0
 theorem h_190_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_190_0 z).shape = [1, 16, 32] := by
   unfold v_190_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_185_0 z z_]
 #a h_190_0
 attribute [local irreducible] v_190_0
 attribute [local irreducible] s_191
 record_prefix_opacity v_183_0 v_183_1 s_184 v_184_0 s_185 v_185_0 s_186 v_186_0 s_187 v_187_0 s_188 v_188_0 s_189 v_189_0 s_190 v_190_0 s_191

 end
 end TrainVerify.Denote.RuntimeWorld
