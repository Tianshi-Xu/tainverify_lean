import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0001
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem i_66 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 611).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_66
 theorem e_66 (z : Store) : (s_0 z) 611 = z 611 := pmInitialWithSeeds_frame z 611 (by decide)
 #a e_66
 theorem i_67 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 612).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_67
 theorem e_67 (z : Store) : (s_0 z) 612 = z 612 := pmInitialWithSeeds_frame z 612 (by decide)
 #a e_67
 theorem i_68 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 613).shape = [256, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_68
 theorem e_68 (z : Store) : (s_0 z) 613 = z 613 := pmInitialWithSeeds_frame z 613 (by decide)
 #a e_68
 theorem i_69 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 614).shape = [64, 256] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_69
 theorem e_69 (z : Store) : (s_0 z) 614 = z 614 := pmInitialWithSeeds_frame z 614 (by decide)
 #a e_69
 theorem i_70 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 914).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_70
 theorem e_70 (z : Store) : (s_0 z) 914 = z 914 := pmInitialWithSeeds_frame z 914 (by decide)
 #a e_70
 theorem i_71 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 915).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_71
 theorem e_71 (z : Store) : (s_0 z) 915 = z 915 := pmInitialWithSeeds_frame z 915 (by decide)
 #a e_71
 theorem i_72 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 916).shape = [256, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_72
 theorem e_72 (z : Store) : (s_0 z) 916 = z 916 := pmInitialWithSeeds_frame z 916 (by decide)
 #a e_72
 theorem i_73 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 917).shape = [64, 256] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_73
 theorem e_73 (z : Store) : (s_0 z) 917 = z 917 := pmInitialWithSeeds_frame z 917 (by decide)
 #a e_73
 theorem i_74 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 615).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_74
 theorem e_74 (z : Store) : (s_0 z) 615 = z 615 := pmInitialWithSeeds_frame z 615 (by decide)
 #a e_74
 theorem i_75 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 616).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_75
 theorem e_75 (z : Store) : (s_0 z) 616 = z 616 := pmInitialWithSeeds_frame z 616 (by decide)
 #a e_75
 theorem i_76 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 918).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_76
 theorem e_76 (z : Store) : (s_0 z) 918 = z 918 := pmInitialWithSeeds_frame z 918 (by decide)
 #a e_76
 theorem i_77 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 919).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_77
 theorem e_77 (z : Store) : (s_0 z) 919 = z 919 := pmInitialWithSeeds_frame z 919 (by decide)
 #a e_77
 theorem i_78 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 653).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_78
 theorem e_78 (z : Store) : (s_0 z) 653 = z 653 := pmInitialWithSeeds_frame z 653 (by decide)
 #a e_78
 theorem i_79 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 656).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_79
 theorem e_79 (z : Store) : (s_0 z) 656 = z 656 := pmInitialWithSeeds_frame z 656 (by decide)
 #a e_79
 theorem i_80 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 659).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_80
 theorem e_80 (z : Store) : (s_0 z) 659 = z 659 := pmInitialWithSeeds_frame z 659 (by decide)
 #a e_80
 theorem i_81 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 956).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_81
 theorem e_81 (z : Store) : (s_0 z) 956 = z 956 := pmInitialWithSeeds_frame z 956 (by decide)
 #a e_81
 theorem i_82 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 959).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_82
 theorem e_82 (z : Store) : (s_0 z) 959 = z 959 := pmInitialWithSeeds_frame z 959 (by decide)
 #a e_82
 theorem i_83 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 962).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_83
 theorem e_83 (z : Store) : (s_0 z) 962 = z 962 := pmInitialWithSeeds_frame z 962 (by decide)
 #a e_83
 theorem i_84 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 662).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_84
 theorem e_84 (z : Store) : (s_0 z) 662 = z 662 := pmInitialWithSeeds_frame z 662 (by decide)
 #a e_84
 theorem i_85 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 965).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_85
 theorem e_85 (z : Store) : (s_0 z) 965 = z 965 := pmInitialWithSeeds_frame z 965 (by decide)
 #a e_85
 theorem i_86 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 617).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_86
 theorem e_86 (z : Store) : (s_0 z) 617 = z 617 := pmInitialWithSeeds_frame z 617 (by decide)
 #a e_86
 theorem i_87 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 618).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_87
 theorem e_87 (z : Store) : (s_0 z) 618 = z 618 := pmInitialWithSeeds_frame z 618 (by decide)
 #a e_87
 theorem i_88 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 920).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_88
 theorem e_88 (z : Store) : (s_0 z) 920 = z 920 := pmInitialWithSeeds_frame z 920 (by decide)
 #a e_88
 theorem i_89 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 921).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_89
 theorem e_89 (z : Store) : (s_0 z) 921 = z 921 := pmInitialWithSeeds_frame z 921 (by decide)
 #a e_89
 theorem i_90 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 669).shape = [256, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_90
 theorem e_90 (z : Store) : (s_0 z) 669 = z 669 := pmInitialWithSeeds_frame z 669 (by decide)
 #a e_90
 theorem i_91 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 972).shape = [256, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_91
 theorem e_91 (z : Store) : (s_0 z) 972 = z 972 := pmInitialWithSeeds_frame z 972 (by decide)
 #a e_91
 theorem i_92 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 619).shape = [64, 256] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_92
 theorem e_92 (z : Store) : (s_0 z) 619 = z 619 := pmInitialWithSeeds_frame z 619 (by decide)
 #a e_92
 theorem i_93 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 620).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_93
 theorem e_93 (z : Store) : (s_0 z) 620 = z 620 := pmInitialWithSeeds_frame z 620 (by decide)
 #a e_93
 theorem i_94 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 621).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_94
 theorem e_94 (z : Store) : (s_0 z) 621 = z 621 := pmInitialWithSeeds_frame z 621 (by decide)
 #a e_94
 theorem i_95 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 922).shape = [64, 256] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_95
 theorem e_95 (z : Store) : (s_0 z) 922 = z 922 := pmInitialWithSeeds_frame z 922 (by decide)
 #a e_95
 theorem i_96 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 923).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_96
 theorem e_96 (z : Store) : (s_0 z) 923 = z 923 := pmInitialWithSeeds_frame z 923 (by decide)
 #a e_96
 theorem i_97 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 924).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_97
 theorem e_97 (z : Store) : (s_0 z) 924 = z 924 := pmInitialWithSeeds_frame z 924 (by decide)
 #a e_97
 theorem i_98 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 678).shape = [128, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_98
 theorem e_98 (z : Store) : (s_0 z) 678 = z 678 := pmInitialWithSeeds_frame z 678 (by decide)
 #a e_98
 theorem i_99 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 981).shape = [128, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2
 #a i_99
 theorem e_99 (z : Store) : (s_0 z) 981 = z 981 := pmInitialWithSeeds_frame z 981 (by decide)
 #a e_99

 def v_0_0 (z : Store) : Tensor := pmNode_0_port0
 def v_0_1 (z : Store) : Tensor := pmNode_0_port1
 def s_1 (z : Store) : Store := storeSet (s_0 z) pmNode_0_feed
 theorem t_0 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_0) (pmPeers pmNode_0) (s_0 z) pmNode_0 (some pmNode_0_feed) = some (s_1 z) := by
   exact pmNode_0_scoped_step (s_0 z)
 #a t_0
 theorem k_0 (z : Store) (tid : Tid) (h : tid ∉ [75, 76]) : (s_1 z) tid = (s_0 z) tid := by
   unfold s_1
   dsimp only [pmNode_0_feed]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_0
 theorem w_0_0 (z : Store) : (s_1 z) 75 = v_0_0 z := by
   unfold s_1
   dsimp only [pmNode_0_feed]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_0_0] <;> rfl
 #a w_0_0
 theorem h_0_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_0_0 z).shape = [1, 16] := by
   unfold v_0_0
   simp [pmNode_0_port0, Tensor.mkShape]
 #a h_0_0
 attribute [local irreducible] v_0_0
 theorem w_0_1 (z : Store) : (s_1 z) 76 = v_0_1 z := by
   unfold s_1
   dsimp only [pmNode_0_feed]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_0_1] <;> rfl
 #a w_0_1
 theorem h_0_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_0_1 z).shape = [1, 16] := by
   unfold v_0_1
   simp [pmNode_0_port1, Tensor.mkShape]
 #a h_0_1
 attribute [local irreducible] v_0_1
 attribute [local irreducible] s_1
 record_prefix_opacity v_0_0 v_0_1 s_1

 end
 end TrainVerify.Denote.RuntimeWorld
