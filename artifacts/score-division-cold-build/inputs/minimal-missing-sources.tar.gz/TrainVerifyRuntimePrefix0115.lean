import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0114
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_894_0 (z : Store) : (s_894 z) 35 = (v_330_1 z) := pR (k_893 z) (pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (pR (k_878 z) (r_878_0 z))))))
 #a r_894_0
 theorem r_894_1 (z : Store) : (s_894 z) 338 = (v_335_1 z) := pR (k_893 z) (pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (pR (k_878 z) (r_878_1 z))))))
 #a r_894_1
 theorem r_894_2 (z : Store) : (s_894 z) 641 = (v_752_1 z) := pR (k_893 z) (pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (pR (k_878 z) (r_878_2 z))))))
 #a r_894_2
 theorem r_894_3 (z : Store) : (s_894 z) 944 = (v_757_1 z) := pR (k_893 z) (pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (pR (k_878 z) (r_878_3 z))))))
 #a r_894_3
 def v_894_0 (z : Store) : Tensor := cross_dp_wred [(v_330_1 z), (v_335_1 z), (v_752_1 z), (v_757_1 z)]
 theorem g_894 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_693) (s_894 z) pmNode_693 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_693, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_894_1 z, r_894_0 z]
     exact (h_335_1 z z_).trans (h_330_1 z z_).symm
   · rw [r_894_2 z, r_894_0 z]
     exact (h_752_1 z z_).trans (h_330_1 z z_).symm
   · rw [r_894_3 z, r_894_0 z]
     exact (h_757_1 z z_).trans (h_330_1 z z_).symm
 #a g_894
 def s_895 (z : Store) : Store := storeSet (s_894 z) [(642, cross_dp_wred [((s_894 z) 35), ((s_894 z) 338), ((s_894 z) 641), ((s_894 z) 944)])]
 theorem t_894 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_693) (pmPeers pmNode_693) (s_894 z) pmNode_693 none = some (s_895 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_693) (s_894 z) pmNode_693 = _
   rw [wredStep, if_pos ⟨by decide, g_894 z z_⟩]
   rfl
 #a t_894
 theorem k_894 (z : Store) (tid : Tid) (h : tid ∉ [642]) : (s_895 z) tid = (s_894 z) tid := by
   unfold s_895
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_894
 theorem w_894_0 (z : Store) : (s_895 z) 642 = v_894_0 z := by
   unfold s_895
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_894_0, r_894_0 z, r_894_1 z, r_894_2 z, r_894_3 z] <;> rfl
 #a w_894_0
 theorem h_894_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_894_0 z).shape = [64] := by
   unfold v_894_0
   rw [tensorSum_shape]
   exact h_330_1 z z_
 #a h_894_0
 attribute [local irreducible] v_894_0
 attribute [local irreducible] s_895
 theorem r_895_0 (z : Store) : (s_895 z) 37 = (v_330_2 z) := pR (k_894 z) (pR (k_893 z) (pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (r_879_0 z))))))
 #a r_895_0
 theorem r_895_1 (z : Store) : (s_895 z) 340 = (v_335_2 z) := pR (k_894 z) (pR (k_893 z) (pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (r_879_1 z))))))
 #a r_895_1
 theorem r_895_2 (z : Store) : (s_895 z) 643 = (v_752_2 z) := pR (k_894 z) (pR (k_893 z) (pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (r_879_2 z))))))
 #a r_895_2
 theorem r_895_3 (z : Store) : (s_895 z) 946 = (v_757_2 z) := pR (k_894 z) (pR (k_893 z) (pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (r_879_3 z))))))
 #a r_895_3
 def v_895_0 (z : Store) : Tensor := cross_dp_wred [(v_330_2 z), (v_335_2 z), (v_752_2 z), (v_757_2 z)]
 theorem g_895 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_694) (s_895 z) pmNode_694 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_694, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_895_1 z, r_895_0 z]
     exact (h_335_2 z z_).trans (h_330_2 z z_).symm
   · rw [r_895_2 z, r_895_0 z]
     exact (h_752_2 z z_).trans (h_330_2 z z_).symm
   · rw [r_895_3 z, r_895_0 z]
     exact (h_757_2 z z_).trans (h_330_2 z z_).symm
 #a g_895
 def s_896 (z : Store) : Store := storeSet (s_895 z) [(644, cross_dp_wred [((s_895 z) 37), ((s_895 z) 340), ((s_895 z) 643), ((s_895 z) 946)])]
 theorem t_895 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_694) (pmPeers pmNode_694) (s_895 z) pmNode_694 none = some (s_896 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_694) (s_895 z) pmNode_694 = _
   rw [wredStep, if_pos ⟨by decide, g_895 z z_⟩]
   rfl
 #a t_895
 theorem k_895 (z : Store) (tid : Tid) (h : tid ∉ [644]) : (s_896 z) tid = (s_895 z) tid := by
   unfold s_896
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_895
 theorem w_895_0 (z : Store) : (s_896 z) 644 = v_895_0 z := by
   unfold s_896
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_895_0, r_895_0 z, r_895_1 z, r_895_2 z, r_895_3 z] <;> rfl
 #a w_895_0
 theorem h_895_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_895_0 z).shape = [64] := by
   unfold v_895_0
   rw [tensorSum_shape]
   exact h_330_2 z z_
 #a h_895_0
 attribute [local irreducible] v_895_0
 attribute [local irreducible] s_896
 theorem n_892_896 (z : Store) (tid : Tid) (h : tid ∉ ([677, 640, 642, 644] : List Tid)) : (s_896 z) tid = (s_892 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_892 z) (k_893 z)) (pF _ _ _ _ _ (k_894 z) (k_895 z)) tid h
 #a n_892_896
 theorem n_888_896 (z : Store) (tid : Tid) (h : tid ∉ ([632, 668, 673, 675, 677, 640, 642, 644] : List Tid)) : (s_896 z) tid = (s_888 z) tid := by
   exact pF _ _ _ _ _ (n_888_892 z) (n_892_896 z) tid h
 #a n_888_896
 theorem n_880_896 (z : Store) (tid : Tid) (h : tid ∉ ([343, 345, 347, 349, 626, 628, 630, 666, 632, 668, 673, 675, 677, 640, 642, 644] : List Tid)) : (s_896 z) tid = (s_880 z) tid := by
   exact pF _ _ _ _ _ (n_880_888 z) (n_888_896 z) tid h
 #a n_880_896
 theorem r_896_0 (z : Store) : (s_896 z) 39 = (v_329_1 z) := pR (n_880_896 z) (r_880_0 z)
 #a r_896_0
 theorem r_896_1 (z : Store) : (s_896 z) 342 = (v_334_1 z) := pR (n_880_896 z) (r_880_1 z)
 #a r_896_1
 theorem r_896_2 (z : Store) : (s_896 z) 645 = (v_751_1 z) := pR (n_880_896 z) (r_880_2 z)
 #a r_896_2
 theorem r_896_3 (z : Store) : (s_896 z) 948 = (v_756_1 z) := pR (n_880_896 z) (r_880_3 z)
 #a r_896_3
 def v_896_0 (z : Store) : Tensor := cross_dp_wred [(v_329_1 z), (v_334_1 z), (v_751_1 z), (v_756_1 z)]
 theorem g_896 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_695) (s_896 z) pmNode_695 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_695, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_896_1 z, r_896_0 z]
     exact (h_334_1 z z_).trans (h_329_1 z z_).symm
   · rw [r_896_2 z, r_896_0 z]
     exact (h_751_1 z z_).trans (h_329_1 z z_).symm
   · rw [r_896_3 z, r_896_0 z]
     exact (h_756_1 z z_).trans (h_329_1 z z_).symm
 #a g_896
 def s_897 (z : Store) : Store := storeSet (s_896 z) [(646, cross_dp_wred [((s_896 z) 39), ((s_896 z) 342), ((s_896 z) 645), ((s_896 z) 948)])]
 theorem t_896 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_695) (pmPeers pmNode_695) (s_896 z) pmNode_695 none = some (s_897 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_695) (s_896 z) pmNode_695 = _
   rw [wredStep, if_pos ⟨by decide, g_896 z z_⟩]
   rfl
 #a t_896
 theorem k_896 (z : Store) (tid : Tid) (h : tid ∉ [646]) : (s_897 z) tid = (s_896 z) tid := by
   unfold s_897
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_896
 theorem w_896_0 (z : Store) : (s_897 z) 646 = v_896_0 z := by
   unfold s_897
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_896_0, r_896_0 z, r_896_1 z, r_896_2 z, r_896_3 z] <;> rfl
 #a w_896_0
 theorem h_896_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_896_0 z).shape = [256, 64] := by
   unfold v_896_0
   rw [tensorSum_shape]
   exact h_329_1 z z_
 #a h_896_0
 attribute [local irreducible] v_896_0
 attribute [local irreducible] s_897
 theorem r_897_0 (z : Store) : (s_897 z) 41 = (v_327_1 z) := pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (pR (k_882 z) (pR (k_881 z) (r_881_0 z))))))
 #a r_897_0
 theorem r_897_1 (z : Store) : (s_897 z) 344 = (v_332_1 z) := pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (pR (k_882 z) (pR (k_881 z) (r_881_1 z))))))
 #a r_897_1
 theorem r_897_2 (z : Store) : (s_897 z) 647 = (v_749_1 z) := pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (pR (k_882 z) (pR (k_881 z) (r_881_2 z))))))
 #a r_897_2
 theorem r_897_3 (z : Store) : (s_897 z) 950 = (v_754_1 z) := pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (pR (k_882 z) (pR (k_881 z) (r_881_3 z))))))
 #a r_897_3
 def v_897_0 (z : Store) : Tensor := cross_dp_wred [(v_327_1 z), (v_332_1 z), (v_749_1 z), (v_754_1 z)]
 theorem g_897 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_696) (s_897 z) pmNode_696 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_696, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_897_1 z, r_897_0 z]
     exact (h_332_1 z z_).trans (h_327_1 z z_).symm
   · rw [r_897_2 z, r_897_0 z]
     exact (h_749_1 z z_).trans (h_327_1 z z_).symm
   · rw [r_897_3 z, r_897_0 z]
     exact (h_754_1 z z_).trans (h_327_1 z z_).symm
 #a g_897
 def s_898 (z : Store) : Store := storeSet (s_897 z) [(648, cross_dp_wred [((s_897 z) 41), ((s_897 z) 344), ((s_897 z) 647), ((s_897 z) 950)])]
 theorem t_897 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_696) (pmPeers pmNode_696) (s_897 z) pmNode_696 none = some (s_898 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_696) (s_897 z) pmNode_696 = _
   rw [wredStep, if_pos ⟨by decide, g_897 z z_⟩]
   rfl
 #a t_897
 theorem k_897 (z : Store) (tid : Tid) (h : tid ∉ [648]) : (s_898 z) tid = (s_897 z) tid := by
   unfold s_898
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_897
 theorem w_897_0 (z : Store) : (s_898 z) 648 = v_897_0 z := by
   unfold s_898
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_897_0, r_897_0 z, r_897_1 z, r_897_2 z, r_897_3 z] <;> rfl
 #a w_897_0
 theorem h_897_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_897_0 z).shape = [64, 256] := by
   unfold v_897_0
   rw [tensorSum_shape]
   exact h_327_1 z z_
 #a h_897_0
 attribute [local irreducible] v_897_0
 attribute [local irreducible] s_898
 theorem r_898_0 (z : Store) : (s_898 z) 43 = (v_316_1 z) := pR (k_897 z) (pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (pR (k_882 z) (r_882_0 z))))))
 #a r_898_0
 theorem r_898_1 (z : Store) : (s_898 z) 346 = (v_319_1 z) := pR (k_897 z) (pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (pR (k_882 z) (r_882_1 z))))))
 #a r_898_1
 theorem r_898_2 (z : Store) : (s_898 z) 649 = (v_738_1 z) := pR (k_897 z) (pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (pR (k_882 z) (r_882_2 z))))))
 #a r_898_2
 theorem r_898_3 (z : Store) : (s_898 z) 952 = (v_741_1 z) := pR (k_897 z) (pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (pR (k_882 z) (r_882_3 z))))))
 #a r_898_3
 def v_898_0 (z : Store) : Tensor := cross_dp_wred [(v_316_1 z), (v_319_1 z), (v_738_1 z), (v_741_1 z)]
 theorem g_898 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_697) (s_898 z) pmNode_697 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_697, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_898_1 z, r_898_0 z]
     exact (h_319_1 z z_).trans (h_316_1 z z_).symm
   · rw [r_898_2 z, r_898_0 z]
     exact (h_738_1 z z_).trans (h_316_1 z z_).symm
   · rw [r_898_3 z, r_898_0 z]
     exact (h_741_1 z z_).trans (h_316_1 z z_).symm
 #a g_898
 def s_899 (z : Store) : Store := storeSet (s_898 z) [(650, cross_dp_wred [((s_898 z) 43), ((s_898 z) 346), ((s_898 z) 649), ((s_898 z) 952)])]
 theorem t_898 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_697) (pmPeers pmNode_697) (s_898 z) pmNode_697 none = some (s_899 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_697) (s_898 z) pmNode_697 = _
   rw [wredStep, if_pos ⟨by decide, g_898 z z_⟩]
   rfl
 #a t_898
 theorem k_898 (z : Store) (tid : Tid) (h : tid ∉ [650]) : (s_899 z) tid = (s_898 z) tid := by
   unfold s_899
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_898
 theorem w_898_0 (z : Store) : (s_899 z) 650 = v_898_0 z := by
   unfold s_899
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_898_0, r_898_0 z, r_898_1 z, r_898_2 z, r_898_3 z] <;> rfl
 #a w_898_0
 theorem h_898_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_898_0 z).shape = [64] := by
   unfold v_898_0
   rw [tensorSum_shape]
   exact h_316_1 z z_
 #a h_898_0
 attribute [local irreducible] v_898_0
 attribute [local irreducible] s_899
 theorem r_899_0 (z : Store) : (s_899 z) 45 = (v_316_2 z) := pR (k_898 z) (pR (k_897 z) (pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (r_883_0 z))))))
 #a r_899_0
 theorem r_899_1 (z : Store) : (s_899 z) 348 = (v_319_2 z) := pR (k_898 z) (pR (k_897 z) (pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (r_883_1 z))))))
 #a r_899_1
 theorem r_899_2 (z : Store) : (s_899 z) 651 = (v_738_2 z) := pR (k_898 z) (pR (k_897 z) (pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (r_883_2 z))))))
 #a r_899_2
 theorem r_899_3 (z : Store) : (s_899 z) 954 = (v_741_2 z) := pR (k_898 z) (pR (k_897 z) (pR (k_896 z) (pR (n_888_896 z) (pR (n_884_888 z) (pR (k_883 z) (r_883_3 z))))))
 #a r_899_3
 def v_899_0 (z : Store) : Tensor := cross_dp_wred [(v_316_2 z), (v_319_2 z), (v_738_2 z), (v_741_2 z)]
 theorem g_899 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_698) (s_899 z) pmNode_698 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_698, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_899_1 z, r_899_0 z]
     exact (h_319_2 z z_).trans (h_316_2 z z_).symm
   · rw [r_899_2 z, r_899_0 z]
     exact (h_738_2 z z_).trans (h_316_2 z z_).symm
   · rw [r_899_3 z, r_899_0 z]
     exact (h_741_2 z z_).trans (h_316_2 z z_).symm
 #a g_899
 def s_900 (z : Store) : Store := storeSet (s_899 z) [(652, cross_dp_wred [((s_899 z) 45), ((s_899 z) 348), ((s_899 z) 651), ((s_899 z) 954)])]
 theorem t_899 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_698) (pmPeers pmNode_698) (s_899 z) pmNode_698 none = some (s_900 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_698) (s_899 z) pmNode_698 = _
   rw [wredStep, if_pos ⟨by decide, g_899 z z_⟩]
   rfl
 #a t_899
 theorem k_899 (z : Store) (tid : Tid) (h : tid ∉ [652]) : (s_900 z) tid = (s_899 z) tid := by
   unfold s_900
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_899
 theorem w_899_0 (z : Store) : (s_900 z) 652 = v_899_0 z := by
   unfold s_900
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_899_0, r_899_0 z, r_899_1 z, r_899_2 z, r_899_3 z] <;> rfl
 #a w_899_0
 theorem h_899_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_899_0 z).shape = [64] := by
   unfold v_899_0
   rw [tensorSum_shape]
   exact h_316_2 z z_
 #a h_899_0
 attribute [local irreducible] v_899_0
 attribute [local irreducible] s_900
 theorem n_896_900 (z : Store) (tid : Tid) (h : tid ∉ ([646, 648, 650, 652] : List Tid)) : (s_900 z) tid = (s_896 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_896 z) (k_897 z)) (pF _ _ _ _ _ (k_898 z) (k_899 z)) tid h
 #a n_896_900
 theorem n_864_896 (z : Store) (tid : Tid) (h : tid ∉ ([74, 49, 52, 55, 323, 325, 327, 363, 329, 365, 370, 372, 374, 337, 339, 341, 343, 345, 347, 349, 626, 628, 630, 666, 632, 668, 673, 675, 677, 640, 642, 644] : List Tid)) : (s_896 z) tid = (s_864 z) tid := by
   exact pF _ _ _ _ _ (n_864_880 z) (n_880_896 z) tid h
 #a n_864_896
 theorem r_900_0 (z : Store) : (s_900 z) 17 = (v_418_0 z) := pR (n_896_900 z) (pR (n_864_896 z) (pR (n_860_864 z) (pR (k_859 z) (r_859_0 z))))
 #a r_900_0
 theorem r_900_1 (z : Store) : (s_900 z) 623 = (v_840_0 z) := pR (n_896_900 z) (pR (n_864_896 z) (pR (n_860_864 z) (pR (k_859 z) (r_859_1 z))))
 #a r_900_1
 def v_900_0 (z : Store) : Tensor := cross_dp_wred [(v_418_0 z), (v_840_0 z)]
 theorem g_900 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_699) (s_900 z) pmNode_699 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_699, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_900_1 z, r_900_0 z]
     exact (h_840_0 z z_).trans (h_418_0 z z_).symm
 #a g_900
 def s_901 (z : Store) : Store := storeSet (s_900 z) [(624, cross_dp_wred [((s_900 z) 17), ((s_900 z) 623)])]
 theorem t_900 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_699) (pmPeers pmNode_699) (s_900 z) pmNode_699 none = some (s_901 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_699) (s_900 z) pmNode_699 = _
   rw [wredStep, if_pos ⟨by decide, g_900 z z_⟩]
   rfl
 #a t_900
 theorem k_900 (z : Store) (tid : Tid) (h : tid ∉ [624]) : (s_901 z) tid = (s_900 z) tid := by
   unfold s_901
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_900
 theorem w_900_0 (z : Store) : (s_901 z) 624 = v_900_0 z := by
   unfold s_901
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_900_0, r_900_0 z, r_900_1 z] <;> rfl
 #a w_900_0
 theorem h_900_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_900_0 z).shape = [256, 32] := by
   unfold v_900_0
   rw [tensorSum_shape]
   exact h_418_0 z z_
 #a h_900_0
 attribute [local irreducible] v_900_0
 attribute [local irreducible] s_901
 record_prefix_opacity v_894_0 s_895 v_895_0 s_896 v_896_0 s_897 v_897_0 s_898 v_898_0 s_899 v_899_0 s_900 v_900_0 s_901

 end
 end TrainVerify.Denote.RuntimeWorld
