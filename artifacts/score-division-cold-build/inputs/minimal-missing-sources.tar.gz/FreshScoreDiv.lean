import FreshScoreExchange
import denote.SourceDivRead
import denote.SourceDivUnit
-- UNCOMPILED: parent owns exact imports, assembly, budget and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierScoreDivRead_sm_1305 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1305 = fw_div (4 : Scalar) (t 1304) := by
  apply SourceDivRead.div_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 46) (smInputRequests.drop 47) smNode_46
    0 4 1304 1305 s t rfl ?_ rfl ?_ h
  · calc
      smInputRequests = smInputRequests.take 46 ++ smInputRequests.drop 46 := (List.take_append_drop 46 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 46, 1304 ∉ row.1.outs
    decide
#print axioms frontierScoreDivRead_sm_1305
theorem frontierScoreDivRead_pm_229 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 229 = fw_div (4 : Scalar) (t 228) := by
  apply SourceDivRead.div_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 153) (pmInputRequests.drop 154) pmNode_77
    0 4 228 229 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 153 ++ pmInputRequests.drop 153 := (List.take_append_drop 153 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 153, 228 ∉ row.1.outs
    decide
#print axioms frontierScoreDivRead_pm_229
theorem frontierScoreDivRead_pm_532 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 532 = fw_div (4 : Scalar) (t 531) := by
  apply SourceDivRead.div_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 155) (pmInputRequests.drop 156) pmNode_313
    1 4 531 532 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 155 ++ pmInputRequests.drop 155 := (List.take_append_drop 155 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 155, 531 ∉ row.1.outs
    decide
#print axioms frontierScoreDivRead_pm_532
theorem frontierScoreDivUnitFacts_1305_0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1305).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 229, q 532], y.shape = [1, 4, 16, 8]) ∧
    chunkPrimDimN 0 2 0 (t 1305) = allGatherPrimDimN 3 2 0 [q 229, q 532] := by
  have predecessor := frontierScoreExchangeUnitFacts_1304_0 s p t q hs hp hvalues
  have outputs : [q 229, q 532] = List.map (fw_div (4 : Scalar)) [q 228, q 531] := by
    change [q 229, q 532] = [fw_div (4 : Scalar) (q 228), fw_div (4 : Scalar) (q 531)]
    exact congrArg₂ List.cons (frontierScoreDivRead_pm_229 p q hp) (congrArg₂ List.cons (frontierScoreDivRead_pm_532 p q hp) (rfl))
  exact TrainVerify.Denote.source_div_unit_output_reconstruct (4 : Scalar) 2 2 1 4 16 8 0
    (t 1304) (t 1305) [q 228, q 531] [q 229, q 532]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2
    (frontierScoreDivRead_sm_1305 s t hs) outputs
#print axioms frontierScoreDivUnitFacts_1305_0
theorem frontierScoreDivRead_pm_835 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 835 = fw_div (4 : Scalar) (t 834) := by
  apply SourceDivRead.div_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 575) (pmInputRequests.drop 576) pmNode_549
    2 4 834 835 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 575 ++ pmInputRequests.drop 575 := (List.take_append_drop 575 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 575, 834 ∉ row.1.outs
    decide
#print axioms frontierScoreDivRead_pm_835
theorem frontierScoreDivRead_pm_1138 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1138 = fw_div (4 : Scalar) (t 1137) := by
  apply SourceDivRead.div_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 577) (pmInputRequests.drop 578) pmNode_785
    3 4 1137 1138 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 577 ++ pmInputRequests.drop 577 := (List.take_append_drop 577 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 577, 1137 ∉ row.1.outs
    decide
#print axioms frontierScoreDivRead_pm_1138
theorem frontierScoreDivUnitFacts_1305_1 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1305).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 835, q 1138], y.shape = [1, 4, 16, 8]) ∧
    chunkPrimDimN 0 2 1 (t 1305) = allGatherPrimDimN 3 2 0 [q 835, q 1138] := by
  have predecessor := frontierScoreExchangeUnitFacts_1304_1 s p t q hs hp hvalues
  have outputs : [q 835, q 1138] = List.map (fw_div (4 : Scalar)) [q 834, q 1137] := by
    change [q 835, q 1138] = [fw_div (4 : Scalar) (q 834), fw_div (4 : Scalar) (q 1137)]
    exact congrArg₂ List.cons (frontierScoreDivRead_pm_835 p q hp) (congrArg₂ List.cons (frontierScoreDivRead_pm_1138 p q hp) (rfl))
  exact TrainVerify.Denote.source_div_unit_output_reconstruct (4 : Scalar) 2 2 1 4 16 8 1
    (t 1304) (t 1305) [q 834, q 1137] [q 835, q 1138]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl predecessor.2.1 predecessor.2.2
    (frontierScoreDivRead_sm_1305 s t hs) outputs
#print axioms frontierScoreDivUnitFacts_1305_1
end
end TrainVerify.Denote.RuntimeWorld
