import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0113
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_887_0 (z : Store) : (s_887 z) 59 = (v_237_1 z) := pR (k_886 z) (pR (k_885 z) (pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (r_871_0 z))))))
 #a r_887_0
 theorem r_887_1 (z : Store) : (s_887 z) 362 = (v_239_1 z) := pR (k_886 z) (pR (k_885 z) (pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (r_871_1 z))))))
 #a r_887_1
 theorem r_887_2 (z : Store) : (s_887 z) 665 = (v_659_1 z) := pR (k_886 z) (pR (k_885 z) (pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (r_871_2 z))))))
 #a r_887_2
 theorem r_887_3 (z : Store) : (s_887 z) 968 = (v_661_1 z) := pR (k_886 z) (pR (k_885 z) (pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (r_871_3 z))))))
 #a r_887_3
 def v_887_0 (z : Store) : Tensor := cross_dp_wred [(v_237_1 z), (v_239_1 z), (v_659_1 z), (v_661_1 z)]
 theorem g_887 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_686) (s_887 z) pmNode_686 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_686, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_887_1 z, r_887_0 z]
     exact (h_239_1 z z_).trans (h_237_1 z z_).symm
   · rw [r_887_2 z, r_887_0 z]
     exact (h_659_1 z z_).trans (h_237_1 z z_).symm
   · rw [r_887_3 z, r_887_0 z]
     exact (h_661_1 z z_).trans (h_237_1 z z_).symm
 #a g_887
 def s_888 (z : Store) : Store := storeSet (s_887 z) [(666, cross_dp_wred [((s_887 z) 59), ((s_887 z) 362), ((s_887 z) 665), ((s_887 z) 968)])]
 theorem t_887 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_686) (pmPeers pmNode_686) (s_887 z) pmNode_686 none = some (s_888 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_686) (s_887 z) pmNode_686 = _
   rw [wredStep, if_pos ⟨by decide, g_887 z z_⟩]
   rfl
 #a t_887
 theorem k_887 (z : Store) (tid : Tid) (h : tid ∉ [666]) : (s_888 z) tid = (s_887 z) tid := by
   unfold s_888
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_887
 theorem w_887_0 (z : Store) : (s_888 z) 666 = v_887_0 z := by
   unfold s_888
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_887_0, r_887_0 z, r_887_1 z, r_887_2 z, r_887_3 z] <;> rfl
 #a w_887_0
 theorem h_887_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_887_0 z).shape = [64] := by
   unfold v_887_0
   rw [tensorSum_shape]
   exact h_237_1 z z_
 #a h_887_0
 attribute [local irreducible] v_887_0
 attribute [local irreducible] s_888
 theorem n_884_888 (z : Store) (tid : Tid) (h : tid ∉ ([626, 628, 630, 666] : List Tid)) : (s_888 z) tid = (s_884 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_884 z) (k_885 z)) (pF _ _ _ _ _ (k_886 z) (k_887 z)) tid h
 #a n_884_888
 theorem n_880_888 (z : Store) (tid : Tid) (h : tid ∉ ([343, 345, 347, 349, 626, 628, 630, 666] : List Tid)) : (s_888 z) tid = (s_880 z) tid := by
   exact pF _ _ _ _ _ (n_880_884 z) (n_884_888 z) tid h
 #a n_880_888
 theorem r_888_0 (z : Store) : (s_888 z) 25 = (v_403_1 z) := pR (n_880_888 z) (pR (n_872_880 z) (r_872_0 z))
 #a r_888_0
 theorem r_888_1 (z : Store) : (s_888 z) 328 = (v_407_1 z) := pR (n_880_888 z) (pR (n_872_880 z) (r_872_1 z))
 #a r_888_1
 theorem r_888_2 (z : Store) : (s_888 z) 631 = (v_825_1 z) := pR (n_880_888 z) (pR (n_872_880 z) (r_872_2 z))
 #a r_888_2
 theorem r_888_3 (z : Store) : (s_888 z) 934 = (v_829_1 z) := pR (n_880_888 z) (pR (n_872_880 z) (r_872_3 z))
 #a r_888_3
 def v_888_0 (z : Store) : Tensor := cross_dp_wred [(v_403_1 z), (v_407_1 z), (v_825_1 z), (v_829_1 z)]
 theorem g_888 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_687) (s_888 z) pmNode_687 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_687, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_888_1 z, r_888_0 z]
     exact (h_407_1 z z_).trans (h_403_1 z z_).symm
   · rw [r_888_2 z, r_888_0 z]
     exact (h_825_1 z z_).trans (h_403_1 z z_).symm
   · rw [r_888_3 z, r_888_0 z]
     exact (h_829_1 z z_).trans (h_403_1 z z_).symm
 #a g_888
 def s_889 (z : Store) : Store := storeSet (s_888 z) [(632, cross_dp_wred [((s_888 z) 25), ((s_888 z) 328), ((s_888 z) 631), ((s_888 z) 934)])]
 theorem t_888 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_687) (pmPeers pmNode_687) (s_888 z) pmNode_687 none = some (s_889 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_687) (s_888 z) pmNode_687 = _
   rw [wredStep, if_pos ⟨by decide, g_888 z z_⟩]
   rfl
 #a t_888
 theorem k_888 (z : Store) (tid : Tid) (h : tid ∉ [632]) : (s_889 z) tid = (s_888 z) tid := by
   unfold s_889
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_888
 theorem w_888_0 (z : Store) : (s_889 z) 632 = v_888_0 z := by
   unfold s_889
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_888_0, r_888_0 z, r_888_1 z, r_888_2 z, r_888_3 z] <;> rfl
 #a w_888_0
 theorem h_888_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_888_0 z).shape = [64, 64] := by
   unfold v_888_0
   rw [tensorSum_shape]
   exact h_403_1 z z_
 #a h_888_0
 attribute [local irreducible] v_888_0
 attribute [local irreducible] s_889
 theorem r_889_0 (z : Store) : (s_889 z) 61 = (v_237_2 z) := pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (pR (k_874 z) (pR (k_873 z) (r_873_0 z))))))
 #a r_889_0
 theorem r_889_1 (z : Store) : (s_889 z) 364 = (v_239_2 z) := pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (pR (k_874 z) (pR (k_873 z) (r_873_1 z))))))
 #a r_889_1
 theorem r_889_2 (z : Store) : (s_889 z) 667 = (v_659_2 z) := pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (pR (k_874 z) (pR (k_873 z) (r_873_2 z))))))
 #a r_889_2
 theorem r_889_3 (z : Store) : (s_889 z) 970 = (v_661_2 z) := pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (pR (k_874 z) (pR (k_873 z) (r_873_3 z))))))
 #a r_889_3
 def v_889_0 (z : Store) : Tensor := cross_dp_wred [(v_237_2 z), (v_239_2 z), (v_659_2 z), (v_661_2 z)]
 theorem g_889 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_688) (s_889 z) pmNode_688 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_688, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_889_1 z, r_889_0 z]
     exact (h_239_2 z z_).trans (h_237_2 z z_).symm
   · rw [r_889_2 z, r_889_0 z]
     exact (h_659_2 z z_).trans (h_237_2 z z_).symm
   · rw [r_889_3 z, r_889_0 z]
     exact (h_661_2 z z_).trans (h_237_2 z z_).symm
 #a g_889
 def s_890 (z : Store) : Store := storeSet (s_889 z) [(668, cross_dp_wred [((s_889 z) 61), ((s_889 z) 364), ((s_889 z) 667), ((s_889 z) 970)])]
 theorem t_889 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_688) (pmPeers pmNode_688) (s_889 z) pmNode_688 none = some (s_890 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_688) (s_889 z) pmNode_688 = _
   rw [wredStep, if_pos ⟨by decide, g_889 z z_⟩]
   rfl
 #a t_889
 theorem k_889 (z : Store) (tid : Tid) (h : tid ∉ [668]) : (s_890 z) tid = (s_889 z) tid := by
   unfold s_890
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_889
 theorem w_889_0 (z : Store) : (s_890 z) 668 = v_889_0 z := by
   unfold s_890
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_889_0, r_889_0 z, r_889_1 z, r_889_2 z, r_889_3 z] <;> rfl
 #a w_889_0
 theorem h_889_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_889_0 z).shape = [64] := by
   unfold v_889_0
   rw [tensorSum_shape]
   exact h_237_2 z z_
 #a h_889_0
 attribute [local irreducible] v_889_0
 attribute [local irreducible] s_890
 theorem r_890_0 (z : Store) : (s_890 z) 66 = (v_227_1 z) := pR (k_889 z) (pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (pR (k_874 z) (r_874_0 z))))))
 #a r_890_0
 theorem r_890_1 (z : Store) : (s_890 z) 369 = (v_230_1 z) := pR (k_889 z) (pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (pR (k_874 z) (r_874_1 z))))))
 #a r_890_1
 theorem r_890_2 (z : Store) : (s_890 z) 672 = (v_649_1 z) := pR (k_889 z) (pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (pR (k_874 z) (r_874_2 z))))))
 #a r_890_2
 theorem r_890_3 (z : Store) : (s_890 z) 975 = (v_652_1 z) := pR (k_889 z) (pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (pR (k_874 z) (r_874_3 z))))))
 #a r_890_3
 def v_890_0 (z : Store) : Tensor := cross_dp_wred [(v_227_1 z), (v_230_1 z), (v_649_1 z), (v_652_1 z)]
 theorem g_890 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_689) (s_890 z) pmNode_689 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_689, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_890_1 z, r_890_0 z]
     exact (h_230_1 z z_).trans (h_227_1 z z_).symm
   · rw [r_890_2 z, r_890_0 z]
     exact (h_649_1 z z_).trans (h_227_1 z z_).symm
   · rw [r_890_3 z, r_890_0 z]
     exact (h_652_1 z z_).trans (h_227_1 z z_).symm
 #a g_890
 def s_891 (z : Store) : Store := storeSet (s_890 z) [(673, cross_dp_wred [((s_890 z) 66), ((s_890 z) 369), ((s_890 z) 672), ((s_890 z) 975)])]
 theorem t_890 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_689) (pmPeers pmNode_689) (s_890 z) pmNode_689 none = some (s_891 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_689) (s_890 z) pmNode_689 = _
   rw [wredStep, if_pos ⟨by decide, g_890 z z_⟩]
   rfl
 #a t_890
 theorem k_890 (z : Store) (tid : Tid) (h : tid ∉ [673]) : (s_891 z) tid = (s_890 z) tid := by
   unfold s_891
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_890
 theorem w_890_0 (z : Store) : (s_891 z) 673 = v_890_0 z := by
   unfold s_891
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_890_0, r_890_0 z, r_890_1 z, r_890_2 z, r_890_3 z] <;> rfl
 #a w_890_0
 theorem h_890_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_890_0 z).shape = [64, 256] := by
   unfold v_890_0
   rw [tensorSum_shape]
   exact h_227_1 z z_
 #a h_890_0
 attribute [local irreducible] v_890_0
 attribute [local irreducible] s_891
 theorem r_891_0 (z : Store) : (s_891 z) 68 = (v_221_1 z) := pR (k_890 z) (pR (k_889 z) (pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (r_875_0 z))))))
 #a r_891_0
 theorem r_891_1 (z : Store) : (s_891 z) 371 = (v_224_1 z) := pR (k_890 z) (pR (k_889 z) (pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (r_875_1 z))))))
 #a r_891_1
 theorem r_891_2 (z : Store) : (s_891 z) 674 = (v_643_1 z) := pR (k_890 z) (pR (k_889 z) (pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (r_875_2 z))))))
 #a r_891_2
 theorem r_891_3 (z : Store) : (s_891 z) 977 = (v_646_1 z) := pR (k_890 z) (pR (k_889 z) (pR (k_888 z) (pR (n_880_888 z) (pR (n_876_880 z) (pR (k_875 z) (r_875_3 z))))))
 #a r_891_3
 def v_891_0 (z : Store) : Tensor := cross_dp_wred [(v_221_1 z), (v_224_1 z), (v_643_1 z), (v_646_1 z)]
 theorem g_891 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_690) (s_891 z) pmNode_690 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_690, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_891_1 z, r_891_0 z]
     exact (h_224_1 z z_).trans (h_221_1 z z_).symm
   · rw [r_891_2 z, r_891_0 z]
     exact (h_643_1 z z_).trans (h_221_1 z z_).symm
   · rw [r_891_3 z, r_891_0 z]
     exact (h_646_1 z z_).trans (h_221_1 z z_).symm
 #a g_891
 def s_892 (z : Store) : Store := storeSet (s_891 z) [(675, cross_dp_wred [((s_891 z) 68), ((s_891 z) 371), ((s_891 z) 674), ((s_891 z) 977)])]
 theorem t_891 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_690) (pmPeers pmNode_690) (s_891 z) pmNode_690 none = some (s_892 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_690) (s_891 z) pmNode_690 = _
   rw [wredStep, if_pos ⟨by decide, g_891 z z_⟩]
   rfl
 #a t_891
 theorem k_891 (z : Store) (tid : Tid) (h : tid ∉ [675]) : (s_892 z) tid = (s_891 z) tid := by
   unfold s_892
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_891
 theorem w_891_0 (z : Store) : (s_892 z) 675 = v_891_0 z := by
   unfold s_892
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_891_0, r_891_0 z, r_891_1 z, r_891_2 z, r_891_3 z] <;> rfl
 #a w_891_0
 theorem h_891_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_891_0 z).shape = [64] := by
   unfold v_891_0
   rw [tensorSum_shape]
   exact h_221_1 z z_
 #a h_891_0
 attribute [local irreducible] v_891_0
 attribute [local irreducible] s_892
 theorem n_888_892 (z : Store) (tid : Tid) (h : tid ∉ ([632, 668, 673, 675] : List Tid)) : (s_892 z) tid = (s_888 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_888 z) (k_889 z)) (pF _ _ _ _ _ (k_890 z) (k_891 z)) tid h
 #a n_888_892
 theorem r_892_0 (z : Store) : (s_892 z) 70 = (v_221_2 z) := pR (n_888_892 z) (pR (n_880_888 z) (pR (n_876_880 z) (r_876_0 z)))
 #a r_892_0
 theorem r_892_1 (z : Store) : (s_892 z) 373 = (v_224_2 z) := pR (n_888_892 z) (pR (n_880_888 z) (pR (n_876_880 z) (r_876_1 z)))
 #a r_892_1
 theorem r_892_2 (z : Store) : (s_892 z) 676 = (v_643_2 z) := pR (n_888_892 z) (pR (n_880_888 z) (pR (n_876_880 z) (r_876_2 z)))
 #a r_892_2
 theorem r_892_3 (z : Store) : (s_892 z) 979 = (v_646_2 z) := pR (n_888_892 z) (pR (n_880_888 z) (pR (n_876_880 z) (r_876_3 z)))
 #a r_892_3
 def v_892_0 (z : Store) : Tensor := cross_dp_wred [(v_221_2 z), (v_224_2 z), (v_643_2 z), (v_646_2 z)]
 theorem g_892 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_691) (s_892 z) pmNode_691 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_691, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_892_1 z, r_892_0 z]
     exact (h_224_2 z z_).trans (h_221_2 z z_).symm
   · rw [r_892_2 z, r_892_0 z]
     exact (h_643_2 z z_).trans (h_221_2 z z_).symm
   · rw [r_892_3 z, r_892_0 z]
     exact (h_646_2 z z_).trans (h_221_2 z z_).symm
 #a g_892
 def s_893 (z : Store) : Store := storeSet (s_892 z) [(677, cross_dp_wred [((s_892 z) 70), ((s_892 z) 373), ((s_892 z) 676), ((s_892 z) 979)])]
 theorem t_892 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_691) (pmPeers pmNode_691) (s_892 z) pmNode_691 none = some (s_893 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_691) (s_892 z) pmNode_691 = _
   rw [wredStep, if_pos ⟨by decide, g_892 z z_⟩]
   rfl
 #a t_892
 theorem k_892 (z : Store) (tid : Tid) (h : tid ∉ [677]) : (s_893 z) tid = (s_892 z) tid := by
   unfold s_893
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_892
 theorem w_892_0 (z : Store) : (s_893 z) 677 = v_892_0 z := by
   unfold s_893
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_892_0, r_892_0 z, r_892_1 z, r_892_2 z, r_892_3 z] <;> rfl
 #a w_892_0
 theorem h_892_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_892_0 z).shape = [64] := by
   unfold v_892_0
   rw [tensorSum_shape]
   exact h_221_2 z z_
 #a h_892_0
 attribute [local irreducible] v_892_0
 attribute [local irreducible] s_893
 theorem r_893_0 (z : Store) : (s_893 z) 33 = (v_343_1 z) := pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (pR (k_878 z) (pR (k_877 z) (r_877_0 z))))))
 #a r_893_0
 theorem r_893_1 (z : Store) : (s_893 z) 336 = (v_345_1 z) := pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (pR (k_878 z) (pR (k_877 z) (r_877_1 z))))))
 #a r_893_1
 theorem r_893_2 (z : Store) : (s_893 z) 639 = (v_765_1 z) := pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (pR (k_878 z) (pR (k_877 z) (r_877_2 z))))))
 #a r_893_2
 theorem r_893_3 (z : Store) : (s_893 z) 942 = (v_767_1 z) := pR (k_892 z) (pR (n_888_892 z) (pR (n_880_888 z) (pR (k_879 z) (pR (k_878 z) (pR (k_877 z) (r_877_3 z))))))
 #a r_893_3
 def v_893_0 (z : Store) : Tensor := cross_dp_wred [(v_343_1 z), (v_345_1 z), (v_765_1 z), (v_767_1 z)]
 theorem g_893 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_692) (s_893 z) pmNode_692 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_692, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_893_1 z, r_893_0 z]
     exact (h_345_1 z z_).trans (h_343_1 z z_).symm
   · rw [r_893_2 z, r_893_0 z]
     exact (h_765_1 z z_).trans (h_343_1 z z_).symm
   · rw [r_893_3 z, r_893_0 z]
     exact (h_767_1 z z_).trans (h_343_1 z z_).symm
 #a g_893
 def s_894 (z : Store) : Store := storeSet (s_893 z) [(640, cross_dp_wred [((s_893 z) 33), ((s_893 z) 336), ((s_893 z) 639), ((s_893 z) 942)])]
 theorem t_893 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_692) (pmPeers pmNode_692) (s_893 z) pmNode_692 none = some (s_894 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_692) (s_893 z) pmNode_692 = _
   rw [wredStep, if_pos ⟨by decide, g_893 z z_⟩]
   rfl
 #a t_893
 theorem k_893 (z : Store) (tid : Tid) (h : tid ∉ [640]) : (s_894 z) tid = (s_893 z) tid := by
   unfold s_894
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_893
 theorem w_893_0 (z : Store) : (s_894 z) 640 = v_893_0 z := by
   unfold s_894
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_893_0, r_893_0 z, r_893_1 z, r_893_2 z, r_893_3 z] <;> rfl
 #a w_893_0
 theorem h_893_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_893_0 z).shape = [64, 64] := by
   unfold v_893_0
   rw [tensorSum_shape]
   exact h_343_1 z z_
 #a h_893_0
 attribute [local irreducible] v_893_0
 attribute [local irreducible] s_894
 record_prefix_opacity v_887_0 s_888 v_888_0 s_889 v_889_0 s_890 v_890_0 s_891 v_891_0 s_892 v_892_0 s_893 v_893_0 s_894

 end
 end TrainVerify.Denote.RuntimeWorld
