import FreshProjectionExchange
import denote.SourceLinearInputUnit
import denote.SourceReduceScatterRead
import denote.KRankAllToAll
-- UNCOMPILED: parent owns imports, canonical frame, aggregate costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierInputLinearRead_sm_1295 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1295 = fw_linear (t 1395) (t 1227) := by
  apply SourceLinearRead.linear_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 36) (smInputRequests.drop 37) smNode_36
    0 1395 1227 1295 s t rfl ?_ rfl ?_ ?_ h
  · calc
      smInputRequests = smInputRequests.take 36 ++ smInputRequests.drop 36 := (List.take_append_drop 36 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 36, 1395 ∉ row.1.outs
    decide
  · change ∀ row ∈ smInputRequests.drop 36, 1227 ∉ row.1.outs
    decide
#print axioms frontierInputLinearRead_sm_1295
theorem frontierInputLinearRead_pm_193 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 193 = fw_linear (t 192) (t 50) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 113) (pmInputRequests.drop 114) pmNode_58
    0 192 50 193 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 113 ++ pmInputRequests.drop 113 := (List.take_append_drop 113 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 113, 192 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 113, 50 ∉ row.1.outs
    decide
#print axioms frontierInputLinearRead_pm_193
theorem frontierInputLinearRead_pm_496 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 496 = fw_linear (t 495) (t 353) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 121) (pmInputRequests.drop 122) pmNode_294
    1 495 353 496 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 121 ++ pmInputRequests.drop 121 := (List.take_append_drop 121 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 121, 495 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 121, 353 ∉ row.1.outs
    decide
#print axioms frontierInputLinearRead_pm_496
theorem frontierInputReduceScatterRead_pm_206 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 206 = chunkPrimDimN 1 2 0 (tensorSum [t 193, t 496]) := by
  apply SourceReduceScatterRead.reduceScatter_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 128) (pmInputRequests.drop 129) pmNode_65
    0 [0, 1] [193, 496] 206 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 128 ++ pmInputRequests.drop 128 := (List.take_append_drop 128 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([193, 496] : List Tid), ∀ row ∈ pmInputRequests.drop 128, tid ∉ row.1.outs
    decide
#print axioms frontierInputReduceScatterRead_pm_206
theorem frontierInputReduceScatterRead_pm_509 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 509 = chunkPrimDimN 1 2 1 (tensorSum [t 193, t 496]) := by
  apply SourceReduceScatterRead.reduceScatter_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 132) (pmInputRequests.drop 133) pmNode_301
    1 [0, 1] [193, 496] 509 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 132 ++ pmInputRequests.drop 132 := (List.take_append_drop 132 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([193, 496] : List Tid), ∀ row ∈ pmInputRequests.drop 132, tid ∉ row.1.outs
    decide
#print axioms frontierInputReduceScatterRead_pm_509
theorem frontierInputLinearUnitFacts_1295_0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1295).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 206, q 509], y.shape = [1, 8, 64]) ∧
    chunkPrimDimN 0 2 0 (t 1295) = allGatherPrimDimN 1 2 0 [q 206, q 509] := by
  have predecessor := frontierProjectionExchangeUnitFacts_1395_0_192_495 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : RelationCompiler.ShardedRel (t 1227) [q 50, q 353] 1 [64, 64] [64, 32] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 := frontierInputLinearRead_pm_193 p q hp
  have local1 := frontierInputLinearRead_pm_496 p q hp
  have localReads : List.Forall₂ (fun xy y => y = fw_linear xy.1 xy.2) ([q 192, q 495].zip [q 50, q 353]) [q 193, q 496] :=
    List.Forall₂.cons local0 (List.Forall₂.cons local1 (List.Forall₂.nil))
  have reduced := TrainVerify.Denote.source_linear_input_unit_output_reduce 2 2 1 16 32 64 0
    (t 1395) (t 1227) (t 1295) [q 192, q 495] [q 50, q 353] [q 193, q 496]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl rfl predecessor.2.1 weightRel.shard_shapes predecessor.2.2 weightRel.full_value
    (frontierInputLinearRead_sm_1295 s t hs) localReads
  have sumShape : (tensorSum [q 193, q 496]).shape = [1, 16, 64] := by
    rw [← reduced.2.2]
    rw [chunkPrimDimN_shape 0 2 0 (t 1295) _ reduced.1 (by decide)]
    rfl
  have scatter0 := frontierInputReduceScatterRead_pm_206 p q hp
  have scatter1 := frontierInputReduceScatterRead_pm_509 p q hp
  have outputs : [q 206, q 509] = List.ofFn (fun dst : Fin 2 => chunkPrimDimN 1 2 dst.val (tensorSum [q 193, q 496])) := by
    change [q 206, q 509] = [chunkPrimDimN 1 2 0 (tensorSum [q 193, q 496]), chunkPrimDimN 1 2 1 (tensorSum [q 193, q 496])]
    exact congrArg₂ List.cons (scatter0) (congrArg₂ List.cons (scatter1) (rfl))
  refine ⟨reduced.1, ?_, ?_⟩
  · intro y hy
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
    rcases hy with rfl | rfl
    · rw [scatter0, chunkPrimDimN_shape 1 2 0 (tensorSum [q 193, q 496]) _ sumShape (by decide)]
      rfl
    · rw [scatter1, chunkPrimDimN_shape 1 2 1 (tensorSum [q 193, q 496]) _ sumShape (by decide)]
      rfl
  · rw [reduced.2.2, outputs]
    symm
    exact allGatherPrimDimN_chunks_ofFn 1 2 (tensorSum [q 193, q 496])
      (by decide) (by rw [sumShape]; decide) (by rw [sumShape]; decide)
#print axioms frontierInputLinearUnitFacts_1295_0
theorem frontierInputLinearRead_sm_1296 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1296 = fw_linear (t 1396) (t 1228) := by
  apply SourceLinearRead.linear_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 37) (smInputRequests.drop 38) smNode_37
    0 1396 1228 1296 s t rfl ?_ rfl ?_ ?_ h
  · calc
      smInputRequests = smInputRequests.take 37 ++ smInputRequests.drop 37 := (List.take_append_drop 37 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 37, 1396 ∉ row.1.outs
    decide
  · change ∀ row ∈ smInputRequests.drop 37, 1228 ∉ row.1.outs
    decide
#print axioms frontierInputLinearRead_sm_1296
theorem frontierInputLinearRead_pm_196 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 196 = fw_linear (t 195) (t 53) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 115) (pmInputRequests.drop 116) pmNode_60
    0 195 53 196 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 115 ++ pmInputRequests.drop 115 := (List.take_append_drop 115 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 115, 195 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 115, 53 ∉ row.1.outs
    decide
#print axioms frontierInputLinearRead_pm_196
theorem frontierInputLinearRead_pm_499 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 499 = fw_linear (t 498) (t 356) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 123) (pmInputRequests.drop 124) pmNode_296
    1 498 356 499 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 123 ++ pmInputRequests.drop 123 := (List.take_append_drop 123 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 123, 498 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 123, 356 ∉ row.1.outs
    decide
#print axioms frontierInputLinearRead_pm_499
theorem frontierInputReduceScatterRead_pm_214 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 214 = chunkPrimDimN 2 2 0 (tensorSum [t 196, t 499]) := by
  apply SourceReduceScatterRead.reduceScatter_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 136) (pmInputRequests.drop 137) pmNode_69
    0 [0, 1] [196, 499] 214 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 136 ++ pmInputRequests.drop 136 := (List.take_append_drop 136 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([196, 499] : List Tid), ∀ row ∈ pmInputRequests.drop 136, tid ∉ row.1.outs
    decide
#print axioms frontierInputReduceScatterRead_pm_214
theorem frontierInputReduceScatterRead_pm_517 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 517 = chunkPrimDimN 2 2 1 (tensorSum [t 196, t 499]) := by
  apply SourceReduceScatterRead.reduceScatter_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 140) (pmInputRequests.drop 141) pmNode_305
    1 [0, 1] [196, 499] 517 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 140 ++ pmInputRequests.drop 140 := (List.take_append_drop 140 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([196, 499] : List Tid), ∀ row ∈ pmInputRequests.drop 140, tid ∉ row.1.outs
    decide
#print axioms frontierInputReduceScatterRead_pm_517
theorem frontierInputLinearUnitFacts_1296_0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1296).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 214, q 517], y.shape = [1, 16, 32]) ∧
    chunkPrimDimN 0 2 0 (t 1296) = allGatherPrimDimN 2 2 0 [q 214, q 517] := by
  have predecessor := frontierProjectionExchangeUnitFacts_1396_0_195_498 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : RelationCompiler.ShardedRel (t 1228) [q 53, q 356] 1 [64, 64] [64, 32] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 := frontierInputLinearRead_pm_196 p q hp
  have local1 := frontierInputLinearRead_pm_499 p q hp
  have localReads : List.Forall₂ (fun xy y => y = fw_linear xy.1 xy.2) ([q 195, q 498].zip [q 53, q 356]) [q 196, q 499] :=
    List.Forall₂.cons local0 (List.Forall₂.cons local1 (List.Forall₂.nil))
  have reduced := TrainVerify.Denote.source_linear_input_unit_output_reduce 2 2 1 16 32 64 0
    (t 1396) (t 1228) (t 1296) [q 195, q 498] [q 53, q 356] [q 196, q 499]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl rfl predecessor.2.1 weightRel.shard_shapes predecessor.2.2 weightRel.full_value
    (frontierInputLinearRead_sm_1296 s t hs) localReads
  have sumShape : (tensorSum [q 196, q 499]).shape = [1, 16, 64] := by
    rw [← reduced.2.2]
    rw [chunkPrimDimN_shape 0 2 0 (t 1296) _ reduced.1 (by decide)]
    rfl
  have scatter0 := frontierInputReduceScatterRead_pm_214 p q hp
  have scatter1 := frontierInputReduceScatterRead_pm_517 p q hp
  have outputs : [q 214, q 517] = List.ofFn (fun dst : Fin 2 => chunkPrimDimN 2 2 dst.val (tensorSum [q 196, q 499])) := by
    change [q 214, q 517] = [chunkPrimDimN 2 2 0 (tensorSum [q 196, q 499]), chunkPrimDimN 2 2 1 (tensorSum [q 196, q 499])]
    exact congrArg₂ List.cons (scatter0) (congrArg₂ List.cons (scatter1) (rfl))
  refine ⟨reduced.1, ?_, ?_⟩
  · intro y hy
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
    rcases hy with rfl | rfl
    · rw [scatter0, chunkPrimDimN_shape 2 2 0 (tensorSum [q 196, q 499]) _ sumShape (by decide)]
      rfl
    · rw [scatter1, chunkPrimDimN_shape 2 2 1 (tensorSum [q 196, q 499]) _ sumShape (by decide)]
      rfl
  · rw [reduced.2.2, outputs]
    symm
    exact allGatherPrimDimN_chunks_ofFn 2 2 (tensorSum [q 196, q 499])
      (by decide) (by rw [sumShape]; decide) (by rw [sumShape]; decide)
#print axioms frontierInputLinearUnitFacts_1296_0
theorem frontierInputLinearRead_pm_799 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 799 = fw_linear (t 798) (t 656) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 535) (pmInputRequests.drop 536) pmNode_530
    2 798 656 799 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 535 ++ pmInputRequests.drop 535 := (List.take_append_drop 535 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 535, 798 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 535, 656 ∉ row.1.outs
    decide
#print axioms frontierInputLinearRead_pm_799
theorem frontierInputLinearRead_pm_1102 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1102 = fw_linear (t 1101) (t 959) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 543) (pmInputRequests.drop 544) pmNode_766
    3 1101 959 1102 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 543 ++ pmInputRequests.drop 543 := (List.take_append_drop 543 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 543, 1101 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 543, 959 ∉ row.1.outs
    decide
#print axioms frontierInputLinearRead_pm_1102
theorem frontierInputReduceScatterRead_pm_812 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 812 = chunkPrimDimN 1 2 0 (tensorSum [t 799, t 1102]) := by
  apply SourceReduceScatterRead.reduceScatter_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 550) (pmInputRequests.drop 551) pmNode_537
    2 [2, 3] [799, 1102] 812 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 550 ++ pmInputRequests.drop 550 := (List.take_append_drop 550 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([799, 1102] : List Tid), ∀ row ∈ pmInputRequests.drop 550, tid ∉ row.1.outs
    decide
#print axioms frontierInputReduceScatterRead_pm_812
theorem frontierInputReduceScatterRead_pm_1115 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1115 = chunkPrimDimN 1 2 1 (tensorSum [t 799, t 1102]) := by
  apply SourceReduceScatterRead.reduceScatter_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 554) (pmInputRequests.drop 555) pmNode_773
    3 [2, 3] [799, 1102] 1115 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 554 ++ pmInputRequests.drop 554 := (List.take_append_drop 554 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([799, 1102] : List Tid), ∀ row ∈ pmInputRequests.drop 554, tid ∉ row.1.outs
    decide
#print axioms frontierInputReduceScatterRead_pm_1115
theorem frontierInputLinearUnitFacts_1295_1 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1295).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 812, q 1115], y.shape = [1, 8, 64]) ∧
    chunkPrimDimN 0 2 1 (t 1295) = allGatherPrimDimN 1 2 0 [q 812, q 1115] := by
  have predecessor := frontierProjectionExchangeUnitFacts_1395_1_798_1101 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : RelationCompiler.ShardedRel (t 1227) [q 656, q 959] 1 [64, 64] [64, 32] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 := frontierInputLinearRead_pm_799 p q hp
  have local1 := frontierInputLinearRead_pm_1102 p q hp
  have localReads : List.Forall₂ (fun xy y => y = fw_linear xy.1 xy.2) ([q 798, q 1101].zip [q 656, q 959]) [q 799, q 1102] :=
    List.Forall₂.cons local0 (List.Forall₂.cons local1 (List.Forall₂.nil))
  have reduced := TrainVerify.Denote.source_linear_input_unit_output_reduce 2 2 1 16 32 64 1
    (t 1395) (t 1227) (t 1295) [q 798, q 1101] [q 656, q 959] [q 799, q 1102]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl rfl predecessor.2.1 weightRel.shard_shapes predecessor.2.2 weightRel.full_value
    (frontierInputLinearRead_sm_1295 s t hs) localReads
  have sumShape : (tensorSum [q 799, q 1102]).shape = [1, 16, 64] := by
    rw [← reduced.2.2]
    rw [chunkPrimDimN_shape 0 2 1 (t 1295) _ reduced.1 (by decide)]
    rfl
  have scatter0 := frontierInputReduceScatterRead_pm_812 p q hp
  have scatter1 := frontierInputReduceScatterRead_pm_1115 p q hp
  have outputs : [q 812, q 1115] = List.ofFn (fun dst : Fin 2 => chunkPrimDimN 1 2 dst.val (tensorSum [q 799, q 1102])) := by
    change [q 812, q 1115] = [chunkPrimDimN 1 2 0 (tensorSum [q 799, q 1102]), chunkPrimDimN 1 2 1 (tensorSum [q 799, q 1102])]
    exact congrArg₂ List.cons (scatter0) (congrArg₂ List.cons (scatter1) (rfl))
  refine ⟨reduced.1, ?_, ?_⟩
  · intro y hy
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
    rcases hy with rfl | rfl
    · rw [scatter0, chunkPrimDimN_shape 1 2 0 (tensorSum [q 799, q 1102]) _ sumShape (by decide)]
      rfl
    · rw [scatter1, chunkPrimDimN_shape 1 2 1 (tensorSum [q 799, q 1102]) _ sumShape (by decide)]
      rfl
  · rw [reduced.2.2, outputs]
    symm
    exact allGatherPrimDimN_chunks_ofFn 1 2 (tensorSum [q 799, q 1102])
      (by decide) (by rw [sumShape]; decide) (by rw [sumShape]; decide)
#print axioms frontierInputLinearUnitFacts_1295_1
theorem frontierInputLinearRead_pm_802 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 802 = fw_linear (t 801) (t 659) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 537) (pmInputRequests.drop 538) pmNode_532
    2 801 659 802 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 537 ++ pmInputRequests.drop 537 := (List.take_append_drop 537 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 537, 801 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 537, 659 ∉ row.1.outs
    decide
#print axioms frontierInputLinearRead_pm_802
theorem frontierInputLinearRead_pm_1105 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1105 = fw_linear (t 1104) (t 962) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 545) (pmInputRequests.drop 546) pmNode_768
    3 1104 962 1105 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 545 ++ pmInputRequests.drop 545 := (List.take_append_drop 545 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 545, 1104 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 545, 962 ∉ row.1.outs
    decide
#print axioms frontierInputLinearRead_pm_1105
theorem frontierInputReduceScatterRead_pm_820 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 820 = chunkPrimDimN 2 2 0 (tensorSum [t 802, t 1105]) := by
  apply SourceReduceScatterRead.reduceScatter_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 558) (pmInputRequests.drop 559) pmNode_541
    2 [2, 3] [802, 1105] 820 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 558 ++ pmInputRequests.drop 558 := (List.take_append_drop 558 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([802, 1105] : List Tid), ∀ row ∈ pmInputRequests.drop 558, tid ∉ row.1.outs
    decide
#print axioms frontierInputReduceScatterRead_pm_820
theorem frontierInputReduceScatterRead_pm_1123 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1123 = chunkPrimDimN 2 2 1 (tensorSum [t 802, t 1105]) := by
  apply SourceReduceScatterRead.reduceScatter_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 562) (pmInputRequests.drop 563) pmNode_777
    3 [2, 3] [802, 1105] 1123 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 562 ++ pmInputRequests.drop 562 := (List.take_append_drop 562 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([802, 1105] : List Tid), ∀ row ∈ pmInputRequests.drop 562, tid ∉ row.1.outs
    decide
#print axioms frontierInputReduceScatterRead_pm_1123
theorem frontierInputLinearUnitFacts_1296_1 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1296).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 820, q 1123], y.shape = [1, 16, 32]) ∧
    chunkPrimDimN 0 2 1 (t 1296) = allGatherPrimDimN 2 2 0 [q 820, q 1123] := by
  have predecessor := frontierProjectionExchangeUnitFacts_1396_1_801_1104 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : RelationCompiler.ShardedRel (t 1228) [q 659, q 962] 1 [64, 64] [64, 32] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have local0 := frontierInputLinearRead_pm_802 p q hp
  have local1 := frontierInputLinearRead_pm_1105 p q hp
  have localReads : List.Forall₂ (fun xy y => y = fw_linear xy.1 xy.2) ([q 801, q 1104].zip [q 659, q 962]) [q 802, q 1105] :=
    List.Forall₂.cons local0 (List.Forall₂.cons local1 (List.Forall₂.nil))
  have reduced := TrainVerify.Denote.source_linear_input_unit_output_reduce 2 2 1 16 32 64 1
    (t 1396) (t 1228) (t 1296) [q 801, q 1104] [q 659, q 962] [q 802, q 1105]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl rfl predecessor.2.1 weightRel.shard_shapes predecessor.2.2 weightRel.full_value
    (frontierInputLinearRead_sm_1296 s t hs) localReads
  have sumShape : (tensorSum [q 802, q 1105]).shape = [1, 16, 64] := by
    rw [← reduced.2.2]
    rw [chunkPrimDimN_shape 0 2 1 (t 1296) _ reduced.1 (by decide)]
    rfl
  have scatter0 := frontierInputReduceScatterRead_pm_820 p q hp
  have scatter1 := frontierInputReduceScatterRead_pm_1123 p q hp
  have outputs : [q 820, q 1123] = List.ofFn (fun dst : Fin 2 => chunkPrimDimN 2 2 dst.val (tensorSum [q 802, q 1105])) := by
    change [q 820, q 1123] = [chunkPrimDimN 2 2 0 (tensorSum [q 802, q 1105]), chunkPrimDimN 2 2 1 (tensorSum [q 802, q 1105])]
    exact congrArg₂ List.cons (scatter0) (congrArg₂ List.cons (scatter1) (rfl))
  refine ⟨reduced.1, ?_, ?_⟩
  · intro y hy
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
    rcases hy with rfl | rfl
    · rw [scatter0, chunkPrimDimN_shape 2 2 0 (tensorSum [q 802, q 1105]) _ sumShape (by decide)]
      rfl
    · rw [scatter1, chunkPrimDimN_shape 2 2 1 (tensorSum [q 802, q 1105]) _ sumShape (by decide)]
      rfl
  · rw [reduced.2.2, outputs]
    symm
    exact allGatherPrimDimN_chunks_ofFn 2 2 (tensorSum [q 802, q 1105])
      (by decide) (by rw [sumShape]; decide) (by rw [sumShape]; decide)
#print axioms frontierInputLinearUnitFacts_1296_1
end
end TrainVerify.Denote.RuntimeWorld
