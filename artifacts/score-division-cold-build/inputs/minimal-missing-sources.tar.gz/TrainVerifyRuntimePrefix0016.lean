import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0015
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_111_0 (z : Store) : (s_111 z) 88 = (v_110_0 z) := w_110_0 z
 #a r_111_0
 theorem r_111_1 (z : Store) : (s_111 z) 47 = (z 47) := pR (k_110 z) (pR (k_109 z) (pR (k_108 z) (pR (n_104_108 z) (pR (n_96_104 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_28 z)))))))
 #a r_111_1
 def v_111_0 (z : Store) : Tensor := fw_linear (v_110_0 z) (z 47)
 def s_112 (z : Store) : Store := storeSet (s_111 z) [(189, fw_linear ((s_111 z) 88) ((s_111 z) 47))]
 theorem t_111 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_56) (pmPeers pmNode_56) (s_111 z) pmNode_56 none = some (s_112 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_111
 theorem k_111 (z : Store) (tid : Tid) (h : tid ∉ [189]) : (s_112 z) tid = (s_111 z) tid := by
   unfold s_112
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_111
 theorem w_111_0 (z : Store) : (s_112 z) 189 = v_111_0 z := by
   unfold s_112
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_111_0, r_111_0 z, r_111_1 z] <;> rfl
 #a w_111_0
 theorem h_111_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_111_0 z).shape = [1, 16, 32] := by
   unfold v_111_0
   exact fw_linear_3d_shape 1 16 64 32 (v_110_0 z) (z 47) (h_110_0 z z_) (i_28 z z_)
 #a h_111_0
 attribute [local irreducible] v_111_0
 attribute [local irreducible] s_112
 theorem n_108_112 (z : Store) (tid : Tid) (h : tid ∉ ([489, 596, 598, 600, 88, 189] : List Tid)) : (s_112 z) tid = (s_108 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_108 z) (k_109 z)) (pF _ _ _ _ _ (k_110 z) (k_111 z)) tid h
 #a n_108_112
 theorem r_112_0 (z : Store) : (s_112 z) 295 = (v_106_1 z) := pR (n_108_112 z) (pR (k_107 z) (w_106_1 z))
 #a r_112_0
 theorem r_112_1 (z : Store) : (s_112 z) 598 = (v_109_1 z) := pR (k_111 z) (pR (k_110 z) (w_109_1 z))
 #a r_112_1
 def v_112_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_106_1 z), (v_109_1 z)]
 theorem g_112 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_57) (s_112 z) pmNode_57 1 2 192 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_57, r_112_0 z, r_112_1 z, h_106_1 z z_, h_109_1 z z_]
 #a g_112
 def s_113 (z : Store) : Store := pL [0, 1] (s_112 z) pmNode_57 1 2
 theorem t_112 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_57) (pmPeers pmNode_57) (s_112 z) pmNode_57 none = some (s_113 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_57) (s_112 z) pmNode_57).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 192 (by decide) (g_112 z z_)]
   rfl
 #a t_112
 theorem k_112 (z : Store) (tid : Tid) (h : tid ∉ [192]) : (s_113 z) tid = (s_112 z) tid := by
   unfold s_113
   dsimp only [pL, pmNode_57, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_112
 theorem w_112_0 (z : Store) : (s_113 z) 192 = v_112_0 z := by
   unfold s_113
   dsimp only [pL, pmNode_57, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_112_0, r_112_0 z, r_112_1 z] <;> rfl
 #a w_112_0
 theorem h_112_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_112_0 z).shape = [1, 16, 32] := by
   unfold v_112_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_106_1 z z_]
 #a h_112_0
 attribute [local irreducible] v_112_0
 attribute [local irreducible] s_113
 theorem n_104_112 (z : Store) (tid : Tid) (h : tid ∉ ([185, 186, 293, 295, 297, 488, 489, 596, 598, 600, 88, 189] : List Tid)) : (s_112 z) tid = (s_104 z) tid := by
   exact pF _ _ _ _ _ (n_104_108 z) (n_108_112 z) tid h
 #a n_104_112
 theorem n_96_112 (z : Store) (tid : Tid) (h : tid ∉ ([478, 480, 180, 181, 291, 252, 483, 484, 594, 555, 185, 186, 293, 295, 297, 488, 489, 596, 598, 600, 88, 189] : List Tid)) : (s_112 z) tid = (s_96 z) tid := by
   exact pF _ _ _ _ _ (n_96_104 z) (n_104_112 z) tid h
 #a n_96_112
 theorem r_113_0 (z : Store) : (s_113 z) 192 = (v_112_0 z) := w_112_0 z
 #a r_113_0
 theorem r_113_1 (z : Store) : (s_113 z) 50 = (z 50) := pR (k_112 z) (pR (n_96_112 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_29 z))))
 #a r_113_1
 def v_113_0 (z : Store) : Tensor := fw_linear (v_112_0 z) (z 50)
 def s_114 (z : Store) : Store := storeSet (s_113 z) [(193, fw_linear ((s_113 z) 192) ((s_113 z) 50))]
 theorem t_113 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_58) (pmPeers pmNode_58) (s_113 z) pmNode_58 none = some (s_114 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_113
 theorem k_113 (z : Store) (tid : Tid) (h : tid ∉ [193]) : (s_114 z) tid = (s_113 z) tid := by
   unfold s_114
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_113
 theorem w_113_0 (z : Store) : (s_114 z) 193 = v_113_0 z := by
   unfold s_114
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_113_0, r_113_0 z, r_113_1 z] <;> rfl
 #a w_113_0
 theorem h_113_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_113_0 z).shape = [1, 16, 64] := by
   unfold v_113_0
   exact fw_linear_3d_shape 1 16 32 64 (v_112_0 z) (z 50) (h_112_0 z z_) (i_29 z z_)
 #a h_113_0
 attribute [local irreducible] v_113_0
 attribute [local irreducible] s_114
 theorem r_114_0 (z : Store) : (s_114 z) 297 = (v_106_2 z) := pR (k_113 z) (pR (k_112 z) (pR (n_108_112 z) (pR (k_107 z) (w_106_2 z))))
 #a r_114_0
 theorem r_114_1 (z : Store) : (s_114 z) 600 = (v_109_2 z) := pR (k_113 z) (pR (k_112 z) (pR (k_111 z) (pR (k_110 z) (w_109_2 z))))
 #a r_114_1
 def v_114_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_106_2 z), (v_109_2 z)]
 theorem g_114 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_59) (s_114 z) pmNode_59 1 2 195 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_59, r_114_0 z, r_114_1 z, h_106_2 z z_, h_109_2 z z_]
 #a g_114
 def s_115 (z : Store) : Store := pL [0, 1] (s_114 z) pmNode_59 1 2
 theorem t_114 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_59) (pmPeers pmNode_59) (s_114 z) pmNode_59 none = some (s_115 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_59) (s_114 z) pmNode_59).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 195 (by decide) (g_114 z z_)]
   rfl
 #a t_114
 theorem k_114 (z : Store) (tid : Tid) (h : tid ∉ [195]) : (s_115 z) tid = (s_114 z) tid := by
   unfold s_115
   dsimp only [pL, pmNode_59, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_114
 theorem w_114_0 (z : Store) : (s_115 z) 195 = v_114_0 z := by
   unfold s_115
   dsimp only [pL, pmNode_59, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_114_0, r_114_0 z, r_114_1 z] <;> rfl
 #a w_114_0
 theorem h_114_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_114_0 z).shape = [1, 16, 32] := by
   unfold v_114_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_106_2 z z_]
 #a h_114_0
 attribute [local irreducible] v_114_0
 attribute [local irreducible] s_115
 theorem r_115_0 (z : Store) : (s_115 z) 195 = (v_114_0 z) := w_114_0 z
 #a r_115_0
 theorem r_115_1 (z : Store) : (s_115 z) 53 = (z 53) := pR (k_114 z) (pR (k_113 z) (pR (k_112 z) (pR (n_96_112 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_30 z))))))
 #a r_115_1
 def v_115_0 (z : Store) : Tensor := fw_linear (v_114_0 z) (z 53)
 def s_116 (z : Store) : Store := storeSet (s_115 z) [(196, fw_linear ((s_115 z) 195) ((s_115 z) 53))]
 theorem t_115 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_60) (pmPeers pmNode_60) (s_115 z) pmNode_60 none = some (s_116 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_115
 theorem k_115 (z : Store) (tid : Tid) (h : tid ∉ [196]) : (s_116 z) tid = (s_115 z) tid := by
   unfold s_116
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_115
 theorem w_115_0 (z : Store) : (s_116 z) 196 = v_115_0 z := by
   unfold s_116
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_115_0, r_115_0 z, r_115_1 z] <;> rfl
 #a w_115_0
 theorem h_115_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_115_0 z).shape = [1, 16, 64] := by
   unfold v_115_0
   exact fw_linear_3d_shape 1 16 32 64 (v_114_0 z) (z 53) (h_114_0 z z_) (i_30 z z_)
 #a h_115_0
 attribute [local irreducible] v_115_0
 attribute [local irreducible] s_116
 theorem n_112_116 (z : Store) (tid : Tid) (h : tid ∉ ([192, 193, 195, 196] : List Tid)) : (s_116 z) tid = (s_112 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_112 z) (k_113 z)) (pF _ _ _ _ _ (k_114 z) (k_115 z)) tid h
 #a n_112_116
 theorem r_116_0 (z : Store) : (s_116 z) 293 = (v_106_0 z) := pR (n_112_116 z) (pR (k_111 z) (pR (k_110 z) (r_110_0 z)))
 #a r_116_0
 theorem r_116_1 (z : Store) : (s_116 z) 596 = (v_109_0 z) := pR (n_112_116 z) (pR (k_111 z) (pR (k_110 z) (r_110_1 z)))
 #a r_116_1
 def v_116_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_106_0 z), (v_109_0 z)]
 def s_117 (z : Store) : Store := storeSet (s_116 z) [(391, allGatherPrimDimN 1 2 1 [((s_116 z) 293), ((s_116 z) 596)])]
 theorem t_116 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_291) (pmPeers pmNode_291) (s_116 z) pmNode_291 none = some (s_117 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_116 z) pmNode_291 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_116
 theorem k_116 (z : Store) (tid : Tid) (h : tid ∉ [391]) : (s_117 z) tid = (s_116 z) tid := by
   unfold s_117
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_116
 theorem w_116_0 (z : Store) : (s_117 z) 391 = v_116_0 z := by
   unfold s_117
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_116_0, r_116_0 z, r_116_1 z] <;> rfl
 #a w_116_0
 theorem h_116_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_116_0 z).shape = [1, 16, 64] := by
   unfold v_116_0
   exact allGatherPrimDimN_shape 1 2 [(v_106_0 z), (v_109_0 z)] [1, 8, 64] (h_106_0 z z_)
 #a h_116_0
 attribute [local irreducible] v_116_0
 attribute [local irreducible] s_117
 theorem r_117_0 (z : Store) : (s_117 z) 391 = (v_116_0 z) := w_116_0 z
 #a r_117_0
 theorem r_117_1 (z : Store) : (s_117 z) 350 = (z 350) := pR (k_116 z) (pR (n_112_116 z) (pR (n_96_112 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_31 z)))))
 #a r_117_1
 def v_117_0 (z : Store) : Tensor := fw_linear (v_116_0 z) (z 350)
 def s_118 (z : Store) : Store := storeSet (s_117 z) [(492, fw_linear ((s_117 z) 391) ((s_117 z) 350))]
 theorem t_117 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_292) (pmPeers pmNode_292) (s_117 z) pmNode_292 none = some (s_118 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_117
 theorem k_117 (z : Store) (tid : Tid) (h : tid ∉ [492]) : (s_118 z) tid = (s_117 z) tid := by
   unfold s_118
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_117
 theorem w_117_0 (z : Store) : (s_118 z) 492 = v_117_0 z := by
   unfold s_118
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_117_0, r_117_0 z, r_117_1 z] <;> rfl
 #a w_117_0
 theorem h_117_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_117_0 z).shape = [1, 16, 32] := by
   unfold v_117_0
   exact fw_linear_3d_shape 1 16 64 32 (v_116_0 z) (z 350) (h_116_0 z z_) (i_31 z z_)
 #a h_117_0
 attribute [local irreducible] v_117_0
 attribute [local irreducible] s_118
 theorem r_118_0 (z : Store) : (s_118 z) 189 = (v_111_0 z) := pR (k_117 z) (pR (k_116 z) (pR (n_112_116 z) (w_111_0 z)))
 #a r_118_0
 theorem r_118_1 (z : Store) : (s_118 z) 492 = (v_117_0 z) := w_117_0 z
 #a r_118_1
 def v_118_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_111_0 z), (v_117_0 z)]
 theorem g_118 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_61) (s_118 z) pmNode_61 2 1 198 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_61, r_118_0 z, r_118_1 z, h_111_0 z z_, h_117_0 z z_]
 #a g_118
 def s_119 (z : Store) : Store := pL [0, 1] (s_118 z) pmNode_61 2 1
 theorem t_118 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_61) (pmPeers pmNode_61) (s_118 z) pmNode_61 none = some (s_119 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_61) (s_118 z) pmNode_61).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 198 (by decide) (g_118 z z_)]
   rfl
 #a t_118
 theorem k_118 (z : Store) (tid : Tid) (h : tid ∉ [198]) : (s_119 z) tid = (s_118 z) tid := by
   unfold s_119
   dsimp only [pL, pmNode_61, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_118
 theorem w_118_0 (z : Store) : (s_119 z) 198 = v_118_0 z := by
   unfold s_119
   dsimp only [pL, pmNode_61, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_118_0, r_118_0 z, r_118_1 z] <;> rfl
 #a w_118_0
 theorem h_118_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_118_0 z).shape = [1, 8, 64] := by
   unfold v_118_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_111_0 z z_]
 #a h_118_0
 attribute [local irreducible] v_118_0
 attribute [local irreducible] s_119
 theorem r_119_0 (z : Store) : (s_119 z) 198 = (v_118_0 z) := w_118_0 z
 #a r_119_0
 def v_119_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_118_0 z)
 def s_120 (z : Store) : Store := storeSet (s_119 z) [(199, fw_view [1, 8, 4, 16] ((s_119 z) 198))]
 theorem t_119 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_62) (pmPeers pmNode_62) (s_119 z) pmNode_62 none = some (s_120 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_119
 theorem k_119 (z : Store) (tid : Tid) (h : tid ∉ [199]) : (s_120 z) tid = (s_119 z) tid := by
   unfold s_120
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_119
 theorem w_119_0 (z : Store) : (s_120 z) 199 = v_119_0 z := by
   unfold s_120
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_119_0, r_119_0 z] <;> rfl
 #a w_119_0
 theorem h_119_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_119_0 z).shape = [1, 8, 4, 16] := by
   unfold v_119_0
   rfl
 #a h_119_0
 attribute [local irreducible] v_119_0
 attribute [local irreducible] s_120
 theorem n_116_120 (z : Store) (tid : Tid) (h : tid ∉ ([391, 492, 198, 199] : List Tid)) : (s_120 z) tid = (s_116 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_116 z) (k_117 z)) (pF _ _ _ _ _ (k_118 z) (k_119 z)) tid h
 #a n_116_120
 theorem n_112_120 (z : Store) (tid : Tid) (h : tid ∉ ([192, 193, 195, 196, 391, 492, 198, 199] : List Tid)) : (s_120 z) tid = (s_112 z) tid := by
   exact pF _ _ _ _ _ (n_112_116 z) (n_116_120 z) tid h
 #a n_112_120
 record_prefix_opacity v_111_0 s_112 v_112_0 s_113 v_113_0 s_114 v_114_0 s_115 v_115_0 s_116 v_116_0 s_117 v_117_0 s_118 v_118_0 s_119 v_119_0 s_120

 end
 end TrainVerify.Denote.RuntimeWorld
