import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0009
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_62_0 (z : Store) : (s_62 z) 128 = (v_42_0 z) := pR (k_61 z) (pR (k_60 z) (pR (n_56_60 z) (pR (n_48_56 z) (pR (n_44_48 z) (pR (k_43 z) (w_42_0 z))))))
 #a r_62_0
 theorem r_62_1 (z : Store) : (s_62 z) 431 = (v_49_0 z) := pR (k_61 z) (pR (k_60 z) (pR (n_56_60 z) (pR (n_52_56 z) (pR (k_51 z) (pR (k_50 z) (w_49_0 z))))))
 #a r_62_1
 def v_62_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 0 [(v_42_0 z), (v_49_0 z)]
 def s_63 (z : Store) : Store := storeSet (s_62 z) [(78, allGatherPrimDimN 2 2 0 [((s_62 z) 128), ((s_62 z) 431)])]
 theorem t_62 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_32) (pmPeers pmNode_32) (s_62 z) pmNode_32 none = some (s_63 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_62 z) pmNode_32 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_62
 theorem k_62 (z : Store) (tid : Tid) (h : tid ∉ [78]) : (s_63 z) tid = (s_62 z) tid := by
   unfold s_63
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_62
 theorem w_62_0 (z : Store) : (s_63 z) 78 = v_62_0 z := by
   unfold s_63
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_62_0, r_62_0 z, r_62_1 z] <;> rfl
 #a w_62_0
 theorem h_62_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_62_0 z).shape = [1, 4, 16, 16] := by
   unfold v_62_0
   exact allGatherPrimDimN_shape 2 2 [(v_42_0 z), (v_49_0 z)] [1, 4, 8, 16] (h_42_0 z z_)
 #a h_62_0
 attribute [local irreducible] v_62_0
 attribute [local irreducible] s_63
 theorem r_63_0 (z : Store) : (s_63 z) 139 = (v_57_0 z) := pR (k_62 z) (pR (k_61 z) (pR (k_60 z) (r_60_0 z)))
 #a r_63_0
 theorem r_63_1 (z : Store) : (s_63 z) 442 = (v_59_0 z) := pR (k_62 z) (pR (k_61 z) (pR (k_60 z) (r_60_1 z)))
 #a r_63_1
 def v_63_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_57_0 z), (v_59_0 z)]
 theorem g_63 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_266) (s_63 z) pmNode_266 3 1 445 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_266, r_63_0 z, r_63_1 z, h_57_0 z z_, h_59_0 z z_]
 #a g_63
 def s_64 (z : Store) : Store := pL [0, 1] (s_63 z) pmNode_266 3 1
 theorem t_63 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_266) (pmPeers pmNode_266) (s_63 z) pmNode_266 none = some (s_64 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_266) (s_63 z) pmNode_266).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 445 (by decide) (g_63 z z_)]
   rfl
 #a t_63
 theorem k_63 (z : Store) (tid : Tid) (h : tid ∉ [445]) : (s_64 z) tid = (s_63 z) tid := by
   unfold s_64
   dsimp only [pL, pmNode_266, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_63
 theorem w_63_0 (z : Store) : (s_64 z) 445 = v_63_0 z := by
   unfold s_64
   dsimp only [pL, pmNode_266, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_63_0, r_63_0 z, r_63_1 z] <;> rfl
 #a w_63_0
 theorem h_63_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_63_0 z).shape = [1, 2, 16, 16] := by
   unfold v_63_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_57_0 z z_]
 #a h_63_0
 attribute [local irreducible] v_63_0
 attribute [local irreducible] s_64
 theorem r_64_0 (z : Store) : (s_64 z) 445 = (v_63_0 z) := w_63_0 z
 #a r_64_0
 def v_64_0 (z : Store) : Tensor := fw_softmax (v_63_0 z)
 def s_65 (z : Store) : Store := storeSet (s_64 z) [(446, fw_softmax ((s_64 z) 445))]
 theorem t_64 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_267) (pmPeers pmNode_267) (s_64 z) pmNode_267 none = some (s_65 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_64
 theorem k_64 (z : Store) (tid : Tid) (h : tid ∉ [446]) : (s_65 z) tid = (s_64 z) tid := by
   unfold s_65
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_64
 theorem w_64_0 (z : Store) : (s_65 z) 446 = v_64_0 z := by
   unfold s_65
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_64_0, r_64_0 z] <;> rfl
 #a w_64_0
 theorem h_64_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_64_0 z).shape = [1, 2, 16, 16] := by
   unfold v_64_0
   unfold fw_softmax softmax
   split <;> exact h_63_0 z z_
 #a h_64_0
 attribute [local irreducible] v_64_0
 attribute [local irreducible] s_65
 theorem r_65_0 (z : Store) : (s_65 z) 143 = (v_61_0 z) := pR (k_64 z) (pR (k_63 z) (pR (k_62 z) (w_61_0 z)))
 #a r_65_0
 theorem r_65_1 (z : Store) : (s_65 z) 446 = (v_64_0 z) := w_64_0 z
 #a r_65_1
 def v_65_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_61_0 z), (v_64_0 z)]
 theorem g_65 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_33) (s_65 z) pmNode_33 1 2 146 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_33, r_65_0 z, r_65_1 z, h_61_0 z z_, h_64_0 z z_]
 #a g_65
 def s_66 (z : Store) : Store := pL [0, 1] (s_65 z) pmNode_33 1 2
 theorem t_65 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_33) (pmPeers pmNode_33) (s_65 z) pmNode_33 none = some (s_66 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_33) (s_65 z) pmNode_33).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 146 (by decide) (g_65 z z_)]
   rfl
 #a t_65
 theorem k_65 (z : Store) (tid : Tid) (h : tid ∉ [146]) : (s_66 z) tid = (s_65 z) tid := by
   unfold s_66
   dsimp only [pL, pmNode_33, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_65
 theorem w_65_0 (z : Store) : (s_66 z) 146 = v_65_0 z := by
   unfold s_66
   dsimp only [pL, pmNode_33, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_65_0, r_65_0 z, r_65_1 z] <;> rfl
 #a w_65_0
 theorem h_65_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_65_0 z).shape = [1, 4, 8, 16] := by
   unfold v_65_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_61_0 z z_]
 #a h_65_0
 attribute [local irreducible] v_65_0
 attribute [local irreducible] s_66
 theorem r_66_0 (z : Store) : (s_66 z) 146 = (v_65_0 z) := w_65_0 z
 #a r_66_0
 theorem r_66_1 (z : Store) : (s_66 z) 78 = (v_62_0 z) := pR (k_65 z) (pR (k_64 z) (pR (k_63 z) (w_62_0 z)))
 #a r_66_1
 def v_66_0 (z : Store) : Tensor := fw_matmul (v_65_0 z) (v_62_0 z)
 def s_67 (z : Store) : Store := storeSet (s_66 z) [(147, fw_matmul ((s_66 z) 146) ((s_66 z) 78))]
 theorem t_66 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_34) (pmPeers pmNode_34) (s_66 z) pmNode_34 none = some (s_67 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_66
 theorem k_66 (z : Store) (tid : Tid) (h : tid ∉ [147]) : (s_67 z) tid = (s_66 z) tid := by
   unfold s_67
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_66
 theorem w_66_0 (z : Store) : (s_67 z) 147 = v_66_0 z := by
   unfold s_67
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_66_0, r_66_0 z, r_66_1 z] <;> rfl
 #a w_66_0
 theorem h_66_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_66_0 z).shape = [1, 4, 8, 16] := by
   unfold v_66_0
   unfold fw_matmul batchedMatmul
   rw [h_65_0 z z_, h_62_0 z z_]
   rfl
 #a h_66_0
 attribute [local irreducible] v_66_0
 attribute [local irreducible] s_67
 theorem r_67_0 (z : Store) : (s_67 z) 147 = (v_66_0 z) := w_66_0 z
 #a r_67_0
 def v_67_0 (z : Store) : Tensor := transposeAxes 1 2 (v_66_0 z)
 def s_68 (z : Store) : Store := storeSet (s_67 z) [(151, transposeAxes 1 2 ((s_67 z) 147))]
 theorem t_67 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_35) (pmPeers pmNode_35) (s_67 z) pmNode_35 none = some (s_68 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_67
 theorem k_67 (z : Store) (tid : Tid) (h : tid ∉ [151]) : (s_68 z) tid = (s_67 z) tid := by
   unfold s_68
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_67
 theorem w_67_0 (z : Store) : (s_68 z) 151 = v_67_0 z := by
   unfold s_68
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_67_0, r_67_0 z] <;> rfl
 #a w_67_0
 theorem h_67_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_67_0 z).shape = [1, 8, 4, 16] := by
   unfold v_67_0
   change listSwapAt _ _ _ = _
   rw [h_66_0 z z_]
   rfl
 #a h_67_0
 attribute [local irreducible] v_67_0
 attribute [local irreducible] s_68
 theorem r_68_0 (z : Store) : (s_68 z) 151 = (v_67_0 z) := w_67_0 z
 #a r_68_0
 def v_68_0 (z : Store) : Tensor := (v_67_0 z)
 def s_69 (z : Store) : Store := storeSet (s_68 z) [(153, ((s_68 z) 151))]
 theorem t_68 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_36) (pmPeers pmNode_36) (s_68 z) pmNode_36 none = some (s_69 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_68
 theorem k_68 (z : Store) (tid : Tid) (h : tid ∉ [153]) : (s_69 z) tid = (s_68 z) tid := by
   unfold s_69
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_68
 theorem w_68_0 (z : Store) : (s_69 z) 153 = v_68_0 z := by
   unfold s_69
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_68_0, r_68_0 z] <;> rfl
 #a w_68_0
 theorem h_68_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_68_0 z).shape = [1, 8, 4, 16] := by
   unfold v_68_0
   exact h_67_0 z z_
 #a h_68_0
 attribute [local irreducible] v_68_0
 attribute [local irreducible] s_69
 theorem n_64_68 (z : Store) (tid : Tid) (h : tid ∉ ([446, 146, 147, 151] : List Tid)) : (s_68 z) tid = (s_64 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_64 z) (k_65 z)) (pF _ _ _ _ _ (k_66 z) (k_67 z)) tid h
 #a n_64_68
 theorem r_69_0 (z : Store) : (s_69 z) 128 = (v_42_0 z) := pR (k_68 z) (pR (n_64_68 z) (pR (k_63 z) (pR (k_62 z) (r_62_0 z))))
 #a r_69_0
 theorem r_69_1 (z : Store) : (s_69 z) 431 = (v_49_0 z) := pR (k_68 z) (pR (n_64_68 z) (pR (k_63 z) (pR (k_62 z) (r_62_1 z))))
 #a r_69_1
 def v_69_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 1 [(v_42_0 z), (v_49_0 z)]
 def s_70 (z : Store) : Store := storeSet (s_69 z) [(381, allGatherPrimDimN 2 2 1 [((s_69 z) 128), ((s_69 z) 431)])]
 theorem t_69 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_268) (pmPeers pmNode_268) (s_69 z) pmNode_268 none = some (s_70 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_69 z) pmNode_268 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_69
 theorem k_69 (z : Store) (tid : Tid) (h : tid ∉ [381]) : (s_70 z) tid = (s_69 z) tid := by
   unfold s_70
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_69
 theorem w_69_0 (z : Store) : (s_70 z) 381 = v_69_0 z := by
   unfold s_70
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_69_0, r_69_0 z, r_69_1 z] <;> rfl
 #a w_69_0
 theorem h_69_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_69_0 z).shape = [1, 4, 16, 16] := by
   unfold v_69_0
   exact allGatherPrimDimN_shape 2 2 [(v_42_0 z), (v_49_0 z)] [1, 4, 8, 16] (h_42_0 z z_)
 #a h_69_0
 attribute [local irreducible] v_69_0
 attribute [local irreducible] s_70
 theorem r_70_0 (z : Store) : (s_70 z) 143 = (v_61_0 z) := pR (k_69 z) (pR (k_68 z) (pR (k_67 z) (pR (k_66 z) (pR (k_65 z) (r_65_0 z)))))
 #a r_70_0
 theorem r_70_1 (z : Store) : (s_70 z) 446 = (v_64_0 z) := pR (k_69 z) (pR (k_68 z) (pR (k_67 z) (pR (k_66 z) (pR (k_65 z) (r_65_1 z)))))
 #a r_70_1
 def v_70_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_61_0 z), (v_64_0 z)]
 theorem g_70 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_269) (s_70 z) pmNode_269 1 2 449 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_269, r_70_0 z, r_70_1 z, h_61_0 z z_, h_64_0 z z_]
 #a g_70
 def s_71 (z : Store) : Store := pL [0, 1] (s_70 z) pmNode_269 1 2
 theorem t_70 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_269) (pmPeers pmNode_269) (s_70 z) pmNode_269 none = some (s_71 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_269) (s_70 z) pmNode_269).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 449 (by decide) (g_70 z z_)]
   rfl
 #a t_70
 theorem k_70 (z : Store) (tid : Tid) (h : tid ∉ [449]) : (s_71 z) tid = (s_70 z) tid := by
   unfold s_71
   dsimp only [pL, pmNode_269, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_70
 theorem w_70_0 (z : Store) : (s_71 z) 449 = v_70_0 z := by
   unfold s_71
   dsimp only [pL, pmNode_269, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_70_0, r_70_0 z, r_70_1 z] <;> rfl
 #a w_70_0
 theorem h_70_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_70_0 z).shape = [1, 4, 8, 16] := by
   unfold v_70_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_61_0 z z_]
 #a h_70_0
 attribute [local irreducible] v_70_0
 attribute [local irreducible] s_71
 record_prefix_opacity v_62_0 s_63 v_63_0 s_64 v_64_0 s_65 v_65_0 s_66 v_66_0 s_67 v_67_0 s_68 v_68_0 s_69 v_69_0 s_70 v_70_0 s_71

 end
 end TrainVerify.Denote.RuntimeWorld
