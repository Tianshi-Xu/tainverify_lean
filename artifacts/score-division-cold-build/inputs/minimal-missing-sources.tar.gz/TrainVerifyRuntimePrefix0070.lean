import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0069
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_551_0 (z : Store) : (s_551 z) 812 = (v_550_0 z) := w_550_0 z
 #a r_551_0
 def v_551_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_550_0 z)
 def s_552 (z : Store) : Store := storeSet (s_551 z) [(813, fw_view [1, 8, 4, 16] ((s_551 z) 812))]
 theorem t_551 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_538) (pmPeers pmNode_538) (s_551 z) pmNode_538 none = some (s_552 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_551
 theorem k_551 (z : Store) (tid : Tid) (h : tid ∉ [813]) : (s_552 z) tid = (s_551 z) tid := by
   unfold s_552
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_551
 theorem w_551_0 (z : Store) : (s_552 z) 813 = v_551_0 z := by
   unfold s_552
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_551_0, r_551_0 z] <;> rfl
 #a w_551_0
 theorem h_551_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_551_0 z).shape = [1, 8, 4, 16] := by
   unfold v_551_0
   rfl
 #a h_551_0
 attribute [local irreducible] v_551_0
 attribute [local irreducible] s_552
 theorem n_548_552 (z : Store) (tid : Tid) (h : tid ∉ ([808, 809, 812, 813] : List Tid)) : (s_552 z) tid = (s_548 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_548 z) (k_549 z)) (pF _ _ _ _ _ (k_550 z) (k_551 z)) tid h
 #a n_548_552
 theorem r_552_0 (z : Store) : (s_552 z) 805 = (v_541_0 z) := pR (n_548_552 z) (r_548_0 z)
 #a r_552_0
 theorem r_552_1 (z : Store) : (s_552 z) 1108 = (v_547_0 z) := pR (n_548_552 z) (r_548_1 z)
 #a r_552_1
 def v_552_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_541_0 z), (v_547_0 z)]
 theorem g_552 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_771) (s_552 z) pmNode_771 1 2 1111 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_771, r_552_0 z, r_552_1 z, h_541_0 z z_, h_547_0 z z_]
 #a g_552
 def s_553 (z : Store) : Store := pL [2, 3] (s_552 z) pmNode_771 1 2
 theorem t_552 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_771) (pmPeers pmNode_771) (s_552 z) pmNode_771 none = some (s_553 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_771) (s_552 z) pmNode_771).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1111 (by decide) (g_552 z z_)]
   rfl
 #a t_552
 theorem k_552 (z : Store) (tid : Tid) (h : tid ∉ [1111]) : (s_553 z) tid = (s_552 z) tid := by
   unfold s_553
   dsimp only [pL, pmNode_771, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_552
 theorem w_552_0 (z : Store) : (s_553 z) 1111 = v_552_0 z := by
   unfold s_553
   dsimp only [pL, pmNode_771, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_552_0, r_552_0 z, r_552_1 z] <;> rfl
 #a w_552_0
 theorem h_552_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_552_0 z).shape = [1, 16, 2, 16] := by
   unfold v_552_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_541_0 z z_]
 #a h_552_0
 attribute [local irreducible] v_552_0
 attribute [local irreducible] s_553
 theorem r_553_0 (z : Store) : (s_553 z) 1111 = (v_552_0 z) := w_552_0 z
 #a r_553_0
 def v_553_0 (z : Store) : Tensor := transposeAxes 1 2 (v_552_0 z)
 def s_554 (z : Store) : Store := storeSet (s_553 z) [(1112, transposeAxes 1 2 ((s_553 z) 1111))]
 theorem t_553 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_772) (pmPeers pmNode_772) (s_553 z) pmNode_772 none = some (s_554 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_553
 theorem k_553 (z : Store) (tid : Tid) (h : tid ∉ [1112]) : (s_554 z) tid = (s_553 z) tid := by
   unfold s_554
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_553
 theorem w_553_0 (z : Store) : (s_554 z) 1112 = v_553_0 z := by
   unfold s_554
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_553_0, r_553_0 z] <;> rfl
 #a w_553_0
 theorem h_553_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_553_0 z).shape = [1, 2, 16, 16] := by
   unfold v_553_0
   change listSwapAt _ _ _ = _
   rw [h_552_0 z z_]
   rfl
 #a h_553_0
 attribute [local irreducible] v_553_0
 attribute [local irreducible] s_554
 theorem r_554_0 (z : Store) : (s_554 z) 799 = (v_535_0 z) := pR (k_553 z) (pR (k_552 z) (pR (k_551 z) (pR (k_550 z) (r_550_0 z))))
 #a r_554_0
 theorem r_554_1 (z : Store) : (s_554 z) 1102 = (v_543_0 z) := pR (k_553 z) (pR (k_552 z) (pR (k_551 z) (pR (k_550 z) (r_550_1 z))))
 #a r_554_1
 def v_554_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_535_0 z), (v_543_0 z)]
 def s_555 (z : Store) : Store := storeSet (s_554 z) [(1115, reduceScatterPrimDimN 1 2 1 [((s_554 z) 799), ((s_554 z) 1102)])]
 theorem t_554 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_773) (pmPeers pmNode_773) (s_554 z) pmNode_773 none = some (s_555 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_554 z) pmNode_773 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_554
 theorem k_554 (z : Store) (tid : Tid) (h : tid ∉ [1115]) : (s_555 z) tid = (s_554 z) tid := by
   unfold s_555
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_554
 theorem w_554_0 (z : Store) : (s_555 z) 1115 = v_554_0 z := by
   unfold s_555
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_554_0, r_554_0 z, r_554_1 z] <;> rfl
 #a w_554_0
 theorem h_554_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_554_0 z).shape = [1, 8, 64] := by
   unfold v_554_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_535_0 z) rfl]
     exact h_535_0 z z_
   · decide
 #a h_554_0
 attribute [local irreducible] v_554_0
 attribute [local irreducible] s_555
 theorem r_555_0 (z : Store) : (s_555 z) 1115 = (v_554_0 z) := w_554_0 z
 #a r_555_0
 def v_555_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_554_0 z)
 def s_556 (z : Store) : Store := storeSet (s_555 z) [(1116, fw_view [1, 8, 4, 16] ((s_555 z) 1115))]
 theorem t_555 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_774) (pmPeers pmNode_774) (s_555 z) pmNode_774 none = some (s_556 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_555
 theorem k_555 (z : Store) (tid : Tid) (h : tid ∉ [1116]) : (s_556 z) tid = (s_555 z) tid := by
   unfold s_556
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_555
 theorem w_555_0 (z : Store) : (s_556 z) 1116 = v_555_0 z := by
   unfold s_556
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_555_0, r_555_0 z] <;> rfl
 #a w_555_0
 theorem h_555_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_555_0 z).shape = [1, 8, 4, 16] := by
   unfold v_555_0
   rfl
 #a h_555_0
 attribute [local irreducible] v_555_0
 attribute [local irreducible] s_556
 theorem n_552_556 (z : Store) (tid : Tid) (h : tid ∉ ([1111, 1112, 1115, 1116] : List Tid)) : (s_556 z) tid = (s_552 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_552 z) (k_553 z)) (pF _ _ _ _ _ (k_554 z) (k_555 z)) tid h
 #a n_552_556
 theorem r_556_0 (z : Store) : (s_556 z) 813 = (v_551_0 z) := pR (n_552_556 z) (w_551_0 z)
 #a r_556_0
 theorem r_556_1 (z : Store) : (s_556 z) 1116 = (v_555_0 z) := w_555_0 z
 #a r_556_1
 def v_556_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_551_0 z), (v_555_0 z)]
 theorem g_556 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_539) (s_556 z) pmNode_539 1 3 816 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_539, r_556_0 z, r_556_1 z, h_551_0 z z_, h_555_0 z z_]
 #a g_556
 def s_557 (z : Store) : Store := pL [2, 3] (s_556 z) pmNode_539 1 3
 theorem t_556 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_539) (pmPeers pmNode_539) (s_556 z) pmNode_539 none = some (s_557 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_539) (s_556 z) pmNode_539).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 816 (by decide) (g_556 z z_)]
   rfl
 #a t_556
 theorem k_556 (z : Store) (tid : Tid) (h : tid ∉ [816]) : (s_557 z) tid = (s_556 z) tid := by
   unfold s_557
   dsimp only [pL, pmNode_539, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_556
 theorem w_556_0 (z : Store) : (s_557 z) 816 = v_556_0 z := by
   unfold s_557
   dsimp only [pL, pmNode_539, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_556_0, r_556_0 z, r_556_1 z] <;> rfl
 #a w_556_0
 theorem h_556_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_556_0 z).shape = [1, 16, 4, 8] := by
   unfold v_556_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_551_0 z z_]
 #a h_556_0
 attribute [local irreducible] v_556_0
 attribute [local irreducible] s_557
 theorem r_557_0 (z : Store) : (s_557 z) 816 = (v_556_0 z) := w_556_0 z
 #a r_557_0
 def v_557_0 (z : Store) : Tensor := transposeAxes 1 2 (v_556_0 z)
 def s_558 (z : Store) : Store := storeSet (s_557 z) [(817, transposeAxes 1 2 ((s_557 z) 816))]
 theorem t_557 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_540) (pmPeers pmNode_540) (s_557 z) pmNode_540 none = some (s_558 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_557
 theorem k_557 (z : Store) (tid : Tid) (h : tid ∉ [817]) : (s_558 z) tid = (s_557 z) tid := by
   unfold s_558
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_557
 theorem w_557_0 (z : Store) : (s_558 z) 817 = v_557_0 z := by
   unfold s_558
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_557_0, r_557_0 z] <;> rfl
 #a w_557_0
 theorem h_557_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_557_0 z).shape = [1, 4, 16, 8] := by
   unfold v_557_0
   change listSwapAt _ _ _ = _
   rw [h_556_0 z z_]
   rfl
 #a h_557_0
 attribute [local irreducible] v_557_0
 attribute [local irreducible] s_558
 theorem n_544_552 (z : Store) (tid : Tid) (h : tid ∉ ([1104, 1105, 1107, 1108, 808, 809, 812, 813] : List Tid)) : (s_552 z) tid = (s_544 z) tid := by
   exact pF _ _ _ _ _ (n_544_548 z) (n_548_552 z) tid h
 #a n_544_552
 theorem r_558_0 (z : Store) : (s_558 z) 802 = (v_537_0 z) := pR (k_557 z) (pR (k_556 z) (pR (n_552_556 z) (pR (n_544_552 z) (pR (n_540_544 z) (pR (k_539 z) (pR (k_538 z) (w_537_0 z)))))))
 #a r_558_0
 theorem r_558_1 (z : Store) : (s_558 z) 1105 = (v_545_0 z) := pR (k_557 z) (pR (k_556 z) (pR (n_552_556 z) (pR (n_548_552 z) (pR (k_547 z) (pR (k_546 z) (w_545_0 z))))))
 #a r_558_1
 def v_558_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 0 [(v_537_0 z), (v_545_0 z)]
 def s_559 (z : Store) : Store := storeSet (s_558 z) [(820, reduceScatterPrimDimN 2 2 0 [((s_558 z) 802), ((s_558 z) 1105)])]
 theorem t_558 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_541) (pmPeers pmNode_541) (s_558 z) pmNode_541 none = some (s_559 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_558 z) pmNode_541 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_558
 theorem k_558 (z : Store) (tid : Tid) (h : tid ∉ [820]) : (s_559 z) tid = (s_558 z) tid := by
   unfold s_559
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_558
 theorem w_558_0 (z : Store) : (s_559 z) 820 = v_558_0 z := by
   unfold s_559
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_558_0, r_558_0 z, r_558_1 z] <;> rfl
 #a w_558_0
 theorem h_558_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_558_0 z).shape = [1, 16, 32] := by
   unfold v_558_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_537_0 z) rfl]
     exact h_537_0 z z_
   · decide
 #a h_558_0
 attribute [local irreducible] v_558_0
 attribute [local irreducible] s_559
 theorem r_559_0 (z : Store) : (s_559 z) 820 = (v_558_0 z) := w_558_0 z
 #a r_559_0
 def v_559_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_558_0 z)
 def s_560 (z : Store) : Store := storeSet (s_559 z) [(821, fw_view [1, 16, 2, 16] ((s_559 z) 820))]
 theorem t_559 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_542) (pmPeers pmNode_542) (s_559 z) pmNode_542 none = some (s_560 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_559
 theorem k_559 (z : Store) (tid : Tid) (h : tid ∉ [821]) : (s_560 z) tid = (s_559 z) tid := by
   unfold s_560
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_559
 theorem w_559_0 (z : Store) : (s_560 z) 821 = v_559_0 z := by
   unfold s_560
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_559_0, r_559_0 z] <;> rfl
 #a w_559_0
 theorem h_559_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_559_0 z).shape = [1, 16, 2, 16] := by
   unfold v_559_0
   rfl
 #a h_559_0
 attribute [local irreducible] v_559_0
 attribute [local irreducible] s_560
 theorem n_556_560 (z : Store) (tid : Tid) (h : tid ∉ ([816, 817, 820, 821] : List Tid)) : (s_560 z) tid = (s_556 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_556 z) (k_557 z)) (pF _ _ _ _ _ (k_558 z) (k_559 z)) tid h
 #a n_556_560
 record_prefix_opacity v_551_0 s_552 v_552_0 s_553 v_553_0 s_554 v_554_0 s_555 v_555_0 s_556 v_556_0 s_557 v_557_0 s_558 v_558_0 s_559 v_559_0 s_560

 end
 end TrainVerify.Denote.RuntimeWorld
