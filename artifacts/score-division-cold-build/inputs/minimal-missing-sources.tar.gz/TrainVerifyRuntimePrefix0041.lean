import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0040
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_317_0 (z : Store) : (s_317 z) 191 = (v_311_0 z) := pR (k_316 z) (pR (k_315 z) (pR (k_314 z) (r_314_0 z)))
 #a r_317_0
 theorem r_317_1 (z : Store) : (s_317 z) 493 = (v_313_0 z) := pR (k_316 z) (pR (k_315 z) (pR (k_314 z) (r_314_1 z)))
 #a r_317_1
 def v_317_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_311_0 z), (v_313_0 z)]
 def s_318 (z : Store) : Store := storeSet (s_317 z) [(597, reduceScatterPrimDimN 1 2 1 [((s_317 z) 191), ((s_317 z) 493)])]
 theorem t_317 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_393) (pmPeers pmNode_393) (s_317 z) pmNode_393 none = some (s_318 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_317 z) pmNode_393 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_317
 theorem k_317 (z : Store) (tid : Tid) (h : tid ∉ [597]) : (s_318 z) tid = (s_317 z) tid := by
   unfold s_318
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_317
 theorem w_317_0 (z : Store) : (s_318 z) 597 = v_317_0 z := by
   unfold s_318
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_317_0, r_317_0 z, r_317_1 z] <;> rfl
 #a w_317_0
 theorem h_317_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_317_0 z).shape = [1, 8, 64] := by
   unfold v_317_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_311_0 z) rfl]
     exact h_311_0 z z_
   · decide
 #a h_317_0
 attribute [local irreducible] v_317_0
 attribute [local irreducible] s_318
 theorem r_318_0 (z : Store) : (s_318 z) 597 = (v_317_0 z) := w_317_0 z
 #a r_318_0
 theorem r_318_1 (z : Store) : (s_318 z) 599 = (v_312_0 z) := pR (k_317 z) (pR (k_316 z) (pR (k_315 z) (pR (k_314 z) (pR (k_313 z) (w_312_0 z)))))
 #a r_318_1
 theorem r_318_2 (z : Store) : (s_318 z) 601 = (v_308_0 z) := pR (k_317 z) (pR (k_316 z) (pR (n_312_316 z) (pR (k_311 z) (pR (k_310 z) (pR (k_309 z) (w_308_0 z))))))
 #a r_318_2
 def v_318_0 (z : Store) : Tensor := tensorSum [(v_317_0 z), (v_312_0 z), (v_308_0 z)]
 def s_319 (z : Store) : Store := storeSet (s_318 z) [(491, tensorSum [((s_318 z) 597), ((s_318 z) 599), ((s_318 z) 601)])]
 theorem t_318 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_394) (pmPeers pmNode_394) (s_318 z) pmNode_394 none = some (s_319 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_318
 theorem k_318 (z : Store) (tid : Tid) (h : tid ∉ [491]) : (s_319 z) tid = (s_318 z) tid := by
   unfold s_319
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_318
 theorem w_318_0 (z : Store) : (s_319 z) 491 = v_318_0 z := by
   unfold s_319
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_318_0, r_318_0 z, r_318_1 z, r_318_2 z] <;> rfl
 #a w_318_0
 theorem h_318_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_318_0 z).shape = [1, 8, 64] := by
   unfold v_318_0
   rw [tensorSum_shape]
   exact h_317_0 z z_
 #a h_318_0
 attribute [local irreducible] v_318_0
 attribute [local irreducible] s_319
 theorem r_319_0 (z : Store) : (s_319 z) 491 = (v_318_0 z) := w_318_0 z
 #a r_319_0
 theorem r_319_1 (z : Store) : (s_319 z) 488 = (v_107_0 z) := pR (k_318 z) (pR (k_317 z) (pR (k_316 z) (pR (n_312_316 z) (pR (n_304_312 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_108_112 z) (r_108_0 z))))))))))
 #a r_319_1
 theorem r_319_2 (z : Store) : (s_319 z) 312 = (z 312) := pR (k_318 z) (pR (k_317 z) (pR (k_316 z) (pR (n_312_316 z) (pR (n_304_312 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_108_112 z) (r_108_1 z))))))))))
 #a r_319_2
 theorem r_319_3 (z : Store) : (s_319 z) 313 = (z 313) := pR (k_318 z) (pR (k_317 z) (pR (k_316 z) (pR (n_312_316 z) (pR (n_304_312 z) (pR (n_288_304 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_108_112 z) (r_108_2 z))))))))))
 #a r_319_3
 def v_319_0 (z : Store) : Tensor := (bw_layernorm (v_318_0 z) (v_107_0 z) (z 312) (z 313)).1
 def v_319_1 (z : Store) : Tensor := (bw_layernorm (v_318_0 z) (v_107_0 z) (z 312) (z 313)).2.1
 def v_319_2 (z : Store) : Tensor := (bw_layernorm (v_318_0 z) (v_107_0 z) (z 312) (z 313)).2.2
 def s_320 (z : Store) : Store := storeSet (s_319 z) [(490, (bw_layernorm ((s_319 z) 491) ((s_319 z) 488) ((s_319 z) 312) ((s_319 z) 313)).1), (346, (bw_layernorm ((s_319 z) 491) ((s_319 z) 488) ((s_319 z) 312) ((s_319 z) 313)).2.1), (348, (bw_layernorm ((s_319 z) 491) ((s_319 z) 488) ((s_319 z) 312) ((s_319 z) 313)).2.2)]
 theorem t_319 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_395) (pmPeers pmNode_395) (s_319 z) pmNode_395 none = some (s_320 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_319
 theorem k_319 (z : Store) (tid : Tid) (h : tid ∉ [490, 346, 348]) : (s_320 z) tid = (s_319 z) tid := by
   unfold s_320
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_319
 theorem w_319_0 (z : Store) : (s_320 z) 490 = v_319_0 z := by
   unfold s_320
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_319_0, r_319_0 z, r_319_1 z, r_319_2 z, r_319_3 z] <;> rfl
 #a w_319_0
 theorem h_319_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_319_0 z).shape = [1, 8, 64] := by
   unfold v_319_0
   rw [bw_layernorm_dx_shape (v_318_0 z) (v_107_0 z) (z 312) (z 313) 64 [8, 1] (by rw [h_107_0 z z_]; rfl)]
   exact h_107_0 z z_
 #a h_319_0
 attribute [local irreducible] v_319_0
 theorem w_319_1 (z : Store) : (s_320 z) 346 = v_319_1 z := by
   unfold s_320
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_319_1, r_319_0 z, r_319_1 z, r_319_2 z, r_319_3 z] <;> rfl
 #a w_319_1
 theorem h_319_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_319_1 z).shape = [64] := by
   unfold v_319_1
   rw [bw_layernorm_dw_shape (v_318_0 z) (v_107_0 z) (z 312) (z 313) 64 [8, 1] (by rw [h_107_0 z z_]; rfl)]
   exact i_26 z z_
 #a h_319_1
 attribute [local irreducible] v_319_1
 theorem w_319_2 (z : Store) : (s_320 z) 348 = v_319_2 z := by
   unfold s_320
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_319_2, r_319_0 z, r_319_1 z, r_319_2 z, r_319_3 z] <;> rfl
 #a w_319_2
 theorem h_319_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_319_2 z).shape = [64] := by
   unfold v_319_2
   rw [bw_layernorm_db_shape (v_318_0 z) (v_107_0 z) (z 312) (z 313) 64 [8, 1] (by rw [h_107_0 z z_]; rfl)]
   exact i_27 z z_
 #a h_319_2
 attribute [local irreducible] v_319_2
 attribute [local irreducible] s_320
 theorem r_320_0 (z : Store) : (s_320 z) 187 = (v_316_0 z) := pR (k_319 z) (pR (k_318 z) (pR (k_317 z) (w_316_0 z)))
 #a r_320_0
 theorem r_320_1 (z : Store) : (s_320 z) 490 = (v_319_0 z) := w_319_0 z
 #a r_320_1
 def v_320_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_316_0 z), (v_319_0 z)]
 theorem g_320 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_160) (s_320 z) pmNode_160 1 2 292 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_160, r_320_0 z, r_320_1 z, h_316_0 z z_, h_319_0 z z_]
 #a g_320
 def s_321 (z : Store) : Store := pL [0, 1] (s_320 z) pmNode_160 1 2
 theorem t_320 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_160) (pmPeers pmNode_160) (s_320 z) pmNode_160 none = some (s_321 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_160) (s_320 z) pmNode_160).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 292 (by decide) (g_320 z z_)]
   rfl
 #a t_320
 theorem k_320 (z : Store) (tid : Tid) (h : tid ∉ [292]) : (s_321 z) tid = (s_320 z) tid := by
   unfold s_321
   dsimp only [pL, pmNode_160, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_320
 theorem w_320_0 (z : Store) : (s_321 z) 292 = v_320_0 z := by
   unfold s_321
   dsimp only [pL, pmNode_160, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_320_0, r_320_0 z, r_320_1 z] <;> rfl
 #a w_320_0
 theorem h_320_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_320_0 z).shape = [1, 16, 32] := by
   unfold v_320_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_316_0 z z_]
 #a h_320_0
 attribute [local irreducible] v_320_0
 attribute [local irreducible] s_321
 theorem n_316_320 (z : Store) (tid : Tid) (h : tid ∉ ([187, 43, 45, 597, 491, 490, 346, 348] : List Tid)) : (s_320 z) tid = (s_316 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_316 z) (k_317 z)) (pF _ _ _ _ _ (k_318 z) (k_319 z)) tid h
 #a n_316_320
 theorem n_312_320 (z : Store) (tid : Tid) (h : tid ∉ ([599, 493, 351, 294, 188, 187, 43, 45, 597, 491, 490, 346, 348] : List Tid)) : (s_320 z) tid = (s_312 z) tid := by
   exact pF _ _ _ _ _ (n_312_316 z) (n_316_320 z) tid h
 #a n_312_320
 theorem n_304_320 (z : Store) (tid : Tid) (h : tid ∉ ([494, 500, 357, 298, 194, 51, 601, 497, 354, 296, 191, 48, 599, 493, 351, 294, 188, 187, 43, 45, 597, 491, 490, 346, 348] : List Tid)) : (s_320 z) tid = (s_304 z) tid := by
   exact pF _ _ _ _ _ (n_304_312 z) (n_312_320 z) tid h
 #a n_304_320
 theorem n_288_320 (z : Store) (tid : Tid) (h : tid ∉ ([386, 515, 209, 208, 512, 511, 82, 204, 385, 507, 201, 200, 504, 503, 190, 197, 54, 494, 500, 357, 298, 194, 51, 601, 497, 354, 296, 191, 48, 599, 493, 351, 294, 188, 187, 43, 45, 597, 491, 490, 346, 348] : List Tid)) : (s_320 z) tid = (s_288 z) tid := by
   exact pF _ _ _ _ _ (n_288_304 z) (n_304_320 z) tid h
 #a n_288_320
 theorem n_256_320 (z : Store) (tid : Tid) (h : tid ∉ ([242, 241, 545, 544, 237, 235, 238, 541, 538, 540, 221, 234, 524, 537, 231, 230, 534, 533, 227, 205, 226, 530, 508, 529, 223, 213, 220, 526, 516, 523, 217, 216, 520, 519, 83, 212, 386, 515, 209, 208, 512, 511, 82, 204, 385, 507, 201, 200, 504, 503, 190, 197, 54, 494, 500, 357, 298, 194, 51, 601, 497, 354, 296, 191, 48, 599, 493, 351, 294, 188, 187, 43, 45, 597, 491, 490, 346, 348] : List Tid)) : (s_320 z) tid = (s_256 z) tid := by
   exact pF _ _ _ _ _ (n_256_288 z) (n_288_320 z) tid h
 #a n_256_320
 theorem r_321_0 (z : Store) : (s_321 z) 292 = (v_320_0 z) := w_320_0 z
 #a r_321_0
 theorem r_321_1 (z : Store) : (s_321 z) 255 = (v_242_0 z) := pR (k_320 z) (pR (n_256_320 z) (pR (n_248_256 z) (pR (n_244_248 z) (pR (k_243 z) (w_242_0 z)))))
 #a r_321_1
 def v_321_0 (z : Store) : Tensor := tensorSum [(v_320_0 z), (v_242_0 z)]
 def s_322 (z : Store) : Store := storeSet (s_321 z) [(184, tensorSum [((s_321 z) 292), ((s_321 z) 255)])]
 theorem t_321 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_161) (pmPeers pmNode_161) (s_321 z) pmNode_161 none = some (s_322 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_321
 theorem k_321 (z : Store) (tid : Tid) (h : tid ∉ [184]) : (s_322 z) tid = (s_321 z) tid := by
   unfold s_322
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_321
 theorem w_321_0 (z : Store) : (s_322 z) 184 = v_321_0 z := by
   unfold s_322
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_321_0, r_321_0 z, r_321_1 z] <;> rfl
 #a w_321_0
 theorem h_321_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_321_0 z).shape = [1, 16, 32] := by
   unfold v_321_0
   rw [tensorSum_shape]
   exact h_320_0 z z_
 #a h_321_0
 attribute [local irreducible] v_321_0
 attribute [local irreducible] s_322
 theorem r_322_0 (z : Store) : (s_322 z) 184 = (v_321_0 z) := w_321_0 z
 #a r_322_0
 theorem r_322_1 (z : Store) : (s_322 z) 179 = (v_84_1 z) := pR (k_321 z) (pR (k_320 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_104_112 z) (pR (n_100_104 z) (pR (k_99 z) (r_99_0 z))))))))
 #a r_322_1
 theorem r_322_2 (z : Store) : (s_322 z) 180 = (v_98_0 z) := pR (k_321 z) (pR (k_320 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_104_112 z) (pR (n_100_104 z) (pR (k_99 z) (r_99_1 z))))))))
 #a r_322_2
 def v_322_0 (z : Store) : Tensor := (bw_add2 (v_321_0 z) (v_84_1 z) (v_98_0 z)).1
 def v_322_1 (z : Store) : Tensor := (bw_add2 (v_321_0 z) (v_84_1 z) (v_98_0 z)).2
 def s_323 (z : Store) : Store := storeSet (s_322 z) [(182, (bw_add2 ((s_322 z) 184) ((s_322 z) 179) ((s_322 z) 180)).1), (183, (bw_add2 ((s_322 z) 184) ((s_322 z) 179) ((s_322 z) 180)).2)]
 theorem t_322 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_162) (pmPeers pmNode_162) (s_322 z) pmNode_162 none = some (s_323 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_322
 theorem k_322 (z : Store) (tid : Tid) (h : tid ∉ [182, 183]) : (s_323 z) tid = (s_322 z) tid := by
   unfold s_323
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_322
 theorem w_322_0 (z : Store) : (s_323 z) 182 = v_322_0 z := by
   unfold s_323
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_322_0, r_322_0 z, r_322_1 z, r_322_2 z] <;> rfl
 #a w_322_0
 theorem h_322_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_322_0 z).shape = [1, 16, 32] := by
   unfold v_322_0
   exact h_84_1 z z_
 #a h_322_0
 attribute [local irreducible] v_322_0
 theorem w_322_1 (z : Store) : (s_323 z) 183 = v_322_1 z := by
   unfold s_323
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_322_1, r_322_0 z, r_322_1 z, r_322_2 z] <;> rfl
 #a w_322_1
 theorem h_322_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_322_1 z).shape = [1, 16, 32] := by
   unfold v_322_1
   exact h_98_0 z z_
 #a h_322_1
 attribute [local irreducible] v_322_1
 attribute [local irreducible] s_323
 theorem r_323_0 (z : Store) : (s_323 z) 187 = (v_316_0 z) := pR (k_322 z) (pR (k_321 z) (pR (k_320 z) (r_320_0 z)))
 #a r_323_0
 theorem r_323_1 (z : Store) : (s_323 z) 490 = (v_319_0 z) := pR (k_322 z) (pR (k_321 z) (pR (k_320 z) (r_320_1 z)))
 #a r_323_1
 def v_323_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_316_0 z), (v_319_0 z)]
 theorem g_323 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_396) (s_323 z) pmNode_396 1 2 595 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_396, r_323_0 z, r_323_1 z, h_316_0 z z_, h_319_0 z z_]
 #a g_323
 def s_324 (z : Store) : Store := pL [0, 1] (s_323 z) pmNode_396 1 2
 theorem t_323 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_396) (pmPeers pmNode_396) (s_323 z) pmNode_396 none = some (s_324 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_396) (s_323 z) pmNode_396).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 595 (by decide) (g_323 z z_)]
   rfl
 #a t_323
 theorem k_323 (z : Store) (tid : Tid) (h : tid ∉ [595]) : (s_324 z) tid = (s_323 z) tid := by
   unfold s_324
   dsimp only [pL, pmNode_396, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_323
 theorem w_323_0 (z : Store) : (s_324 z) 595 = v_323_0 z := by
   unfold s_324
   dsimp only [pL, pmNode_396, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_323_0, r_323_0 z, r_323_1 z] <;> rfl
 #a w_323_0
 theorem h_323_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_323_0 z).shape = [1, 16, 32] := by
   unfold v_323_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_316_0 z z_]
 #a h_323_0
 attribute [local irreducible] v_323_0
 attribute [local irreducible] s_324
 theorem n_320_324 (z : Store) (tid : Tid) (h : tid ∉ ([292, 184, 182, 183, 595] : List Tid)) : (s_324 z) tid = (s_320 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_320 z) (k_321 z)) (pF _ _ _ _ _ (k_322 z) (k_323 z)) tid h
 #a n_320_324
 record_prefix_opacity v_317_0 s_318 v_318_0 s_319 v_319_0 v_319_1 v_319_2 s_320 v_320_0 s_321 v_321_0 s_322 v_322_0 v_322_1 s_323 v_323_0 s_324

 end
 end TrainVerify.Denote.RuntimeWorld
