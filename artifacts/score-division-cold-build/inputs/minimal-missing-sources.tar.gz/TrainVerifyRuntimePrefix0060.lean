import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0059
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_466_0 (z : Store) : (s_466 z) 721 = (v_455_0 z) := pR (k_465 z) (pR (k_464 z) (pR (n_456_464 z) (w_455_0 z)))
 #a r_466_0
 theorem r_466_1 (z : Store) : (s_466 z) 1024 = (v_458_0 z) := pR (k_465 z) (pR (k_464 z) (pR (n_460_464 z) (pR (k_459 z) (w_458_0 z))))
 #a r_466_1
 def v_466_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_455_0 z), (v_458_0 z)]
 theorem g_466 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_497) (s_466 z) pmNode_497 3 1 738 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_497, r_466_0 z, r_466_1 z, h_455_0 z z_, h_458_0 z z_]
 #a g_466
 def s_467 (z : Store) : Store := pL [2, 3] (s_466 z) pmNode_497 3 1
 theorem t_466 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_497) (pmPeers pmNode_497) (s_466 z) pmNode_497 none = some (s_467 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_497) (s_466 z) pmNode_497).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 738 (by decide) (g_466 z z_)]
   rfl
 #a t_466
 theorem k_466 (z : Store) (tid : Tid) (h : tid ∉ [738]) : (s_467 z) tid = (s_466 z) tid := by
   unfold s_467
   dsimp only [pL, pmNode_497, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_466
 theorem w_466_0 (z : Store) : (s_467 z) 738 = v_466_0 z := by
   unfold s_467
   dsimp only [pL, pmNode_497, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_466_0, r_466_0 z, r_466_1 z] <;> rfl
 #a w_466_0
 theorem h_466_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_466_0 z).shape = [1, 2, 16, 16] := by
   unfold v_466_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_455_0 z z_]
 #a h_466_0
 attribute [local irreducible] v_466_0
 attribute [local irreducible] s_467
 theorem r_467_0 (z : Store) : (s_467 z) 724 = (v_456_0 z) := pR (k_466 z) (pR (k_465 z) (pR (k_464 z) (pR (n_460_464 z) (r_460_0 z))))
 #a r_467_0
 theorem r_467_1 (z : Store) : (s_467 z) 1027 = (v_459_0 z) := pR (k_466 z) (pR (k_465 z) (pR (k_464 z) (pR (n_460_464 z) (r_460_1 z))))
 #a r_467_1
 def v_467_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 3 [(v_456_0 z), (v_459_0 z)]
 theorem g_467 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_727) (s_467 z) pmNode_727 2 3 1029 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_727, r_467_0 z, r_467_1 z, h_456_0 z z_, h_459_0 z z_]
 #a g_467
 def s_468 (z : Store) : Store := pL [2, 3] (s_467 z) pmNode_727 2 3
 theorem t_467 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_727) (pmPeers pmNode_727) (s_467 z) pmNode_727 none = some (s_468 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_727) (s_467 z) pmNode_727).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 3 1029 (by decide) (g_467 z z_)]
   rfl
 #a t_467
 theorem k_467 (z : Store) (tid : Tid) (h : tid ∉ [1029]) : (s_468 z) tid = (s_467 z) tid := by
   unfold s_468
   dsimp only [pL, pmNode_727, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_467
 theorem w_467_0 (z : Store) : (s_468 z) 1029 = v_467_0 z := by
   unfold s_468
   dsimp only [pL, pmNode_727, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_467_0, r_467_0 z, r_467_1 z] <;> rfl
 #a w_467_0
 theorem h_467_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_467_0 z).shape = [1, 16, 4, 8] := by
   unfold v_467_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_456_0 z z_]
 #a h_467_0
 attribute [local irreducible] v_467_0
 attribute [local irreducible] s_468
 theorem r_468_0 (z : Store) : (s_468 z) 1029 = (v_467_0 z) := w_467_0 z
 #a r_468_0
 def v_468_0 (z : Store) : Tensor := transposeAxes 1 2 (v_467_0 z)
 def s_469 (z : Store) : Store := storeSet (s_468 z) [(1030, transposeAxes 1 2 ((s_468 z) 1029))]
 theorem t_468 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_728) (pmPeers pmNode_728) (s_468 z) pmNode_728 none = some (s_469 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_468
 theorem k_468 (z : Store) (tid : Tid) (h : tid ∉ [1030]) : (s_469 z) tid = (s_468 z) tid := by
   unfold s_469
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_468
 theorem w_468_0 (z : Store) : (s_469 z) 1030 = v_468_0 z := by
   unfold s_469
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_468_0, r_468_0 z] <;> rfl
 #a w_468_0
 theorem h_468_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_468_0 z).shape = [1, 4, 16, 8] := by
   unfold v_468_0
   change listSwapAt _ _ _ = _
   rw [h_467_0 z z_]
   rfl
 #a h_468_0
 attribute [local irreducible] v_468_0
 attribute [local irreducible] s_469
 theorem n_464_468 (z : Store) (tid : Tid) (h : tid ∉ ([734, 736, 738, 1029] : List Tid)) : (s_468 z) tid = (s_464 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_464 z) (k_465 z)) (pF _ _ _ _ _ (k_466 z) (k_467 z)) tid h
 #a n_464_468
 theorem r_469_0 (z : Store) : (s_469 z) 715 = (v_446_0 z) := pR (k_468 z) (pR (n_464_468 z) (pR (k_463 z) (pR (k_462 z) (r_462_0 z))))
 #a r_469_0
 theorem r_469_1 (z : Store) : (s_469 z) 1018 = (v_452_0 z) := pR (k_468 z) (pR (n_464_468 z) (pR (k_463 z) (pR (k_462 z) (r_462_1 z))))
 #a r_469_1
 def v_469_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_446_0 z), (v_452_0 z)]
 theorem g_469 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_729) (s_469 z) pmNode_729 2 1 1033 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_729, r_469_0 z, r_469_1 z, h_446_0 z z_, h_452_0 z z_]
 #a g_469
 def s_470 (z : Store) : Store := pL [2, 3] (s_469 z) pmNode_729 2 1
 theorem t_469 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_729) (pmPeers pmNode_729) (s_469 z) pmNode_729 none = some (s_470 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_729) (s_469 z) pmNode_729).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1033 (by decide) (g_469 z z_)]
   rfl
 #a t_469
 theorem k_469 (z : Store) (tid : Tid) (h : tid ∉ [1033]) : (s_470 z) tid = (s_469 z) tid := by
   unfold s_470
   dsimp only [pL, pmNode_729, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_469
 theorem w_469_0 (z : Store) : (s_470 z) 1033 = v_469_0 z := by
   unfold s_470
   dsimp only [pL, pmNode_729, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_469_0, r_469_0 z, r_469_1 z] <;> rfl
 #a w_469_0
 theorem h_469_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_469_0 z).shape = [1, 8, 64] := by
   unfold v_469_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_446_0 z z_]
 #a h_469_0
 attribute [local irreducible] v_469_0
 attribute [local irreducible] s_470
 theorem r_470_0 (z : Store) : (s_470 z) 1033 = (v_469_0 z) := w_469_0 z
 #a r_470_0
 def v_470_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_469_0 z)
 def s_471 (z : Store) : Store := storeSet (s_470 z) [(1034, fw_view [1, 8, 4, 16] ((s_470 z) 1033))]
 theorem t_470 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_730) (pmPeers pmNode_730) (s_470 z) pmNode_730 none = some (s_471 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_470
 theorem k_470 (z : Store) (tid : Tid) (h : tid ∉ [1034]) : (s_471 z) tid = (s_470 z) tid := by
   unfold s_471
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_470
 theorem w_470_0 (z : Store) : (s_471 z) 1034 = v_470_0 z := by
   unfold s_471
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_470_0, r_470_0 z] <;> rfl
 #a w_470_0
 theorem h_470_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_470_0 z).shape = [1, 8, 4, 16] := by
   unfold v_470_0
   rfl
 #a h_470_0
 attribute [local irreducible] v_470_0
 attribute [local irreducible] s_471
 theorem r_471_0 (z : Store) : (s_471 z) 1034 = (v_470_0 z) := w_470_0 z
 #a r_471_0
 def v_471_0 (z : Store) : Tensor := transposeAxes 1 2 (v_470_0 z)
 def s_472 (z : Store) : Store := storeSet (s_471 z) [(1037, transposeAxes 1 2 ((s_471 z) 1034))]
 theorem t_471 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_731) (pmPeers pmNode_731) (s_471 z) pmNode_731 none = some (s_472 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_471
 theorem k_471 (z : Store) (tid : Tid) (h : tid ∉ [1037]) : (s_472 z) tid = (s_471 z) tid := by
   unfold s_472
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_471
 theorem w_471_0 (z : Store) : (s_472 z) 1037 = v_471_0 z := by
   unfold s_472
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_471_0, r_471_0 z] <;> rfl
 #a w_471_0
 theorem h_471_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_471_0 z).shape = [1, 4, 8, 16] := by
   unfold v_471_0
   change listSwapAt _ _ _ = _
   rw [h_470_0 z z_]
   rfl
 #a h_471_0
 attribute [local irreducible] v_471_0
 attribute [local irreducible] s_472
 theorem r_472_0 (z : Store) : (s_472 z) 1030 = (v_468_0 z) := pR (k_471 z) (pR (k_470 z) (pR (k_469 z) (w_468_0 z)))
 #a r_472_0
 def v_472_0 (z : Store) : Tensor := transposeAxes 2 3 (v_468_0 z)
 def s_473 (z : Store) : Store := storeSet (s_472 z) [(1039, transposeAxes 2 3 ((s_472 z) 1030))]
 theorem t_472 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_732) (pmPeers pmNode_732) (s_472 z) pmNode_732 none = some (s_473 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_472
 theorem k_472 (z : Store) (tid : Tid) (h : tid ∉ [1039]) : (s_473 z) tid = (s_472 z) tid := by
   unfold s_473
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_472
 theorem w_472_0 (z : Store) : (s_473 z) 1039 = v_472_0 z := by
   unfold s_473
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_472_0, r_472_0 z] <;> rfl
 #a w_472_0
 theorem h_472_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_472_0 z).shape = [1, 4, 8, 16] := by
   unfold v_472_0
   change listSwapAt _ _ _ = _
   rw [h_468_0 z z_]
   rfl
 #a h_472_0
 attribute [local irreducible] v_472_0
 attribute [local irreducible] s_473
 theorem n_468_472 (z : Store) (tid : Tid) (h : tid ∉ ([1030, 1033, 1034, 1037] : List Tid)) : (s_472 z) tid = (s_468 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_468 z) (k_469 z)) (pF _ _ _ _ _ (k_470 z) (k_471 z)) tid h
 #a n_468_472
 theorem r_473_0 (z : Store) : (s_473 z) 736 = (v_465_0 z) := pR (k_472 z) (pR (n_468_472 z) (pR (k_467 z) (pR (k_466 z) (w_465_0 z))))
 #a r_473_0
 theorem r_473_1 (z : Store) : (s_473 z) 1039 = (v_472_0 z) := w_472_0 z
 #a r_473_1
 def v_473_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_465_0 z), (v_472_0 z)]
 theorem g_473 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_498) (s_473 z) pmNode_498 2 1 739 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_498, r_473_0 z, r_473_1 z, h_465_0 z z_, h_472_0 z z_]
 #a g_473
 def s_474 (z : Store) : Store := pL [2, 3] (s_473 z) pmNode_498 2 1
 theorem t_473 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_498) (pmPeers pmNode_498) (s_473 z) pmNode_498 none = some (s_474 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_498) (s_473 z) pmNode_498).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 739 (by decide) (g_473 z z_)]
   rfl
 #a t_473
 theorem k_473 (z : Store) (tid : Tid) (h : tid ∉ [739]) : (s_474 z) tid = (s_473 z) tid := by
   unfold s_474
   dsimp only [pL, pmNode_498, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_473
 theorem w_473_0 (z : Store) : (s_474 z) 739 = v_473_0 z := by
   unfold s_474
   dsimp only [pL, pmNode_498, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_473_0, r_473_0 z, r_473_1 z] <;> rfl
 #a w_473_0
 theorem h_473_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_473_0 z).shape = [1, 2, 16, 16] := by
   unfold v_473_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_465_0 z z_]
 #a h_473_0
 attribute [local irreducible] v_473_0
 attribute [local irreducible] s_474
 theorem r_474_0 (z : Store) : (s_474 z) 738 = (v_466_0 z) := pR (k_473 z) (pR (k_472 z) (pR (n_468_472 z) (pR (k_467 z) (w_466_0 z))))
 #a r_474_0
 theorem r_474_1 (z : Store) : (s_474 z) 739 = (v_473_0 z) := w_473_0 z
 #a r_474_1
 def v_474_0 (z : Store) : Tensor := fw_matmul (v_466_0 z) (v_473_0 z)
 def s_475 (z : Store) : Store := storeSet (s_474 z) [(740, fw_matmul ((s_474 z) 738) ((s_474 z) 739))]
 theorem t_474 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_499) (pmPeers pmNode_499) (s_474 z) pmNode_499 none = some (s_475 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_474
 theorem k_474 (z : Store) (tid : Tid) (h : tid ∉ [740]) : (s_475 z) tid = (s_474 z) tid := by
   unfold s_475
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_474
 theorem w_474_0 (z : Store) : (s_475 z) 740 = v_474_0 z := by
   unfold s_475
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_474_0, r_474_0 z, r_474_1 z] <;> rfl
 #a w_474_0
 theorem h_474_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_474_0 z).shape = [1, 2, 16, 16] := by
   unfold v_474_0
   unfold fw_matmul batchedMatmul
   rw [h_466_0 z z_, h_473_0 z z_]
   rfl
 #a h_474_0
 attribute [local irreducible] v_474_0
 attribute [local irreducible] s_475
 record_prefix_opacity v_466_0 s_467 v_467_0 s_468 v_468_0 s_469 v_469_0 s_470 v_470_0 s_471 v_471_0 s_472 v_472_0 s_473 v_473_0 s_474 v_474_0 s_475

 end
 end TrainVerify.Denote.RuntimeWorld
