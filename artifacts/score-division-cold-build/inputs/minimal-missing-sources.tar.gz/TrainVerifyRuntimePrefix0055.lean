import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0054
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem n_0_256 (z : Store) (tid : Tid) (h : tid ∉ ([75, 76, 89, 91, 92, 378, 379, 392, 394, 395, 94, 95, 283, 163, 397, 398, 586, 466, 98, 99, 102, 285, 287, 103, 401, 402, 405, 588, 590, 86, 106, 87, 109, 112, 406, 389, 409, 390, 412, 415, 114, 115, 118, 417, 418, 421, 120, 121, 124, 125, 128, 130, 132, 423, 424, 427, 428, 431, 433, 133, 134, 435, 436, 437, 138, 139, 441, 442, 142, 143, 78, 445, 446, 146, 147, 151, 153, 381, 449, 450, 454, 456, 155, 156, 458, 459, 159, 160, 462, 463, 164, 165, 289, 179, 467, 468, 592, 482, 169, 170, 173, 175, 177, 472, 473, 476, 478, 480, 180, 181, 291, 252, 483, 484, 594, 555, 185, 186, 293, 295, 297, 488, 489, 596, 598, 600, 88, 189, 192, 193, 195, 196, 391, 492, 198, 199, 495, 496, 498, 499, 501, 502, 202, 203, 206, 207, 505, 506, 509, 510, 210, 211, 214, 215, 513, 514, 517, 518, 218, 219, 222, 521, 522, 525, 224, 225, 527, 528, 228, 229, 531, 532, 232, 233, 79, 236, 535, 536, 382, 539, 239, 240, 542, 543, 243, 244, 546, 547, 247, 248, 251, 550, 551, 554, 253, 254, 299, 301, 556, 557, 602, 604, 258, 259, 561, 562, 262, 263, 565, 566, 265, 266, 269, 271, 272, 275, 568, 569, 572, 574, 575, 578, 80, 277, 383, 580, 280, 281, 583, 584, 77, 282, 380, 585, 278, 279, 73, 582, 581, 376, 276, 274, 68, 70, 273, 270, 579, 577, 371, 373, 576, 573, 302, 268, 66, 267, 605, 571, 369, 570, 85, 264, 64, 388, 567, 367, 261, 260, 59, 61, 564, 563, 362, 364, 300, 257, 255, 256, 603, 560, 558, 559, 84, 250, 57, 249, 387, 553, 360, 552, 246, 245, 549, 548] : List Tid)) : (s_256 z) tid = (s_0 z) tid := by
   exact pF _ _ _ _ _ (n_0_128 z) (n_128_256 z) tid h
 #a n_0_256
 theorem r_423_0 (z : Store) : (s_423 z) 681 = (v_422_0 z) := w_422_0 z
 #a r_423_0
 theorem r_423_1 (z : Store) : (s_423 z) 622 = (z 622) := pR (k_422 z) (pR (k_421 z) (pR (k_420 z) (pR (n_416_420 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_50 z)))))))
 #a r_423_1
 def v_423_0 (z : Store) : Tensor := fw_embedding (v_422_0 z) (z 622)
 def s_424 (z : Store) : Store := storeSet (s_423 z) [(695, fw_embedding ((s_423 z) 681) ((s_423 z) 622))]
 theorem t_423 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_473) (pmPeers pmNode_473) (s_423 z) pmNode_473 none = some (s_424 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_423
 theorem k_423 (z : Store) (tid : Tid) (h : tid ∉ [695]) : (s_424 z) tid = (s_423 z) tid := by
   unfold s_424
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_423
 theorem w_423_0 (z : Store) : (s_424 z) 695 = v_423_0 z := by
   unfold s_424
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_423_0, r_423_0 z, r_423_1 z] <;> rfl
 #a w_423_0
 theorem h_423_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_423_0 z).shape = [1, 16, 32] := by
   unfold v_423_0
   simp [fw_embedding_shape, lastD, h_422_0 z z_, i_50 z z_]
 #a h_423_0
 attribute [local irreducible] v_423_0
 attribute [local irreducible] s_424
 theorem r_424_0 (z : Store) : (s_424 z) 682 = (v_422_1 z) := pR (k_423 z) (w_422_1 z)
 #a r_424_0
 def v_424_0 (z : Store) : Tensor := chunkPrimDimN 1 2 0 (v_422_1 z)
 def s_425 (z : Store) : Store := storeSet (s_424 z) [(697, chunkPrimDimN 1 2 0 ((s_424 z) 682))]
 theorem t_424 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_474) (pmPeers pmNode_474) (s_424 z) pmNode_474 none = some (s_425 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_424 z) pmNode_474 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_424
 theorem k_424 (z : Store) (tid : Tid) (h : tid ∉ [697]) : (s_425 z) tid = (s_424 z) tid := by
   unfold s_425
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_424
 theorem w_424_0 (z : Store) : (s_425 z) 697 = v_424_0 z := by
   unfold s_425
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_424_0, r_424_0 z] <;> rfl
 #a w_424_0
 theorem h_424_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_424_0 z).shape = [1, 8] := by
   unfold v_424_0
   exact chunkPrimDimN_shape 1 2 0 (v_422_1 z) [1, 16] (h_422_1 z z_) (by decide)
 #a h_424_0
 attribute [local irreducible] v_424_0
 attribute [local irreducible] s_425
 theorem n_420_424 (z : Store) (tid : Tid) (h : tid ∉ ([322, 320, 681, 682, 695] : List Tid)) : (s_424 z) tid = (s_420 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_420 z) (k_421 z)) (pF _ _ _ _ _ (k_422 z) (k_423 z)) tid h
 #a n_420_424
 theorem n_416_424 (z : Store) (tid : Tid) (h : tid ∉ ([93, 19, 17, 396, 322, 320, 681, 682, 695] : List Tid)) : (s_424 z) tid = (s_416 z) tid := by
   exact pF _ _ _ _ _ (n_416_420 z) (n_420_424 z) tid h
 #a n_416_424
 theorem r_425_0 (z : Store) : (s_425 z) 697 = (v_424_0 z) := w_424_0 z
 #a r_425_0
 theorem r_425_1 (z : Store) : (s_425 z) 606 = (z 606) := pR (k_424 z) (pR (n_416_424 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_51 z)))))
 #a r_425_1
 def v_425_0 (z : Store) : Tensor := fw_embedding (v_424_0 z) (z 606)
 def s_426 (z : Store) : Store := storeSet (s_425 z) [(698, fw_embedding ((s_425 z) 697) ((s_425 z) 606))]
 theorem t_425 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_475) (pmPeers pmNode_475) (s_425 z) pmNode_475 none = some (s_426 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_425
 theorem k_425 (z : Store) (tid : Tid) (h : tid ∉ [698]) : (s_426 z) tid = (s_425 z) tid := by
   unfold s_426
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_425
 theorem w_425_0 (z : Store) : (s_426 z) 698 = v_425_0 z := by
   unfold s_426
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_425_0, r_425_0 z, r_425_1 z] <;> rfl
 #a w_425_0
 theorem h_425_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_425_0 z).shape = [1, 8, 64] := by
   unfold v_425_0
   simp [fw_embedding_shape, lastD, h_424_0 z z_, i_51 z z_]
 #a h_425_0
 attribute [local irreducible] v_425_0
 attribute [local irreducible] s_426
 def v_426_0 (z : Store) : Tensor := pmNode_708_port0
 def v_426_1 (z : Store) : Tensor := pmNode_708_port1
 def s_427 (z : Store) : Store := storeSet (s_426 z) pmNode_708_feed
 theorem t_426 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_708) (pmPeers pmNode_708) (s_426 z) pmNode_708 (some pmNode_708_feed) = some (s_427 z) := by
   exact pmNode_708_scoped_step (s_426 z)
 #a t_426
 theorem k_426 (z : Store) (tid : Tid) (h : tid ∉ [984, 985]) : (s_427 z) tid = (s_426 z) tid := by
   unfold s_427
   dsimp only [pmNode_708_feed]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_426
 theorem w_426_0 (z : Store) : (s_427 z) 984 = v_426_0 z := by
   unfold s_427
   dsimp only [pmNode_708_feed]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_426_0] <;> rfl
 #a w_426_0
 theorem h_426_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_426_0 z).shape = [1, 16] := by
   unfold v_426_0
   simp [pmNode_708_port0, Tensor.mkShape]
 #a h_426_0
 attribute [local irreducible] v_426_0
 theorem w_426_1 (z : Store) : (s_427 z) 985 = v_426_1 z := by
   unfold s_427
   dsimp only [pmNode_708_feed]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_426_1] <;> rfl
 #a w_426_1
 theorem h_426_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_426_1 z).shape = [1, 16] := by
   unfold v_426_1
   simp [pmNode_708_port1, Tensor.mkShape]
 #a h_426_1
 attribute [local irreducible] v_426_1
 attribute [local irreducible] s_427
 theorem r_427_0 (z : Store) : (s_427 z) 984 = (v_426_0 z) := w_426_0 z
 #a r_427_0
 theorem r_427_1 (z : Store) : (s_427 z) 925 = (z 925) := pR (k_426 z) (pR (k_425 z) (pR (k_424 z) (pR (n_416_424 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_52 z)))))))
 #a r_427_1
 def v_427_0 (z : Store) : Tensor := fw_embedding (v_426_0 z) (z 925)
 def s_428 (z : Store) : Store := storeSet (s_427 z) [(998, fw_embedding ((s_427 z) 984) ((s_427 z) 925))]
 theorem t_427 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_709) (pmPeers pmNode_709) (s_427 z) pmNode_709 none = some (s_428 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_427
 theorem k_427 (z : Store) (tid : Tid) (h : tid ∉ [998]) : (s_428 z) tid = (s_427 z) tid := by
   unfold s_428
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_427
 theorem w_427_0 (z : Store) : (s_428 z) 998 = v_427_0 z := by
   unfold s_428
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_427_0, r_427_0 z, r_427_1 z] <;> rfl
 #a w_427_0
 theorem h_427_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_427_0 z).shape = [1, 16, 32] := by
   unfold v_427_0
   simp [fw_embedding_shape, lastD, h_426_0 z z_, i_52 z z_]
 #a h_427_0
 attribute [local irreducible] v_427_0
 attribute [local irreducible] s_428
 theorem r_428_0 (z : Store) : (s_428 z) 985 = (v_426_1 z) := pR (k_427 z) (w_426_1 z)
 #a r_428_0
 def v_428_0 (z : Store) : Tensor := chunkPrimDimN 1 2 1 (v_426_1 z)
 def s_429 (z : Store) : Store := storeSet (s_428 z) [(1000, chunkPrimDimN 1 2 1 ((s_428 z) 985))]
 theorem t_428 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_710) (pmPeers pmNode_710) (s_428 z) pmNode_710 none = some (s_429 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_428 z) pmNode_710 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_428
 theorem k_428 (z : Store) (tid : Tid) (h : tid ∉ [1000]) : (s_429 z) tid = (s_428 z) tid := by
   unfold s_429
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_428
 theorem w_428_0 (z : Store) : (s_429 z) 1000 = v_428_0 z := by
   unfold s_429
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_428_0, r_428_0 z] <;> rfl
 #a w_428_0
 theorem h_428_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_428_0 z).shape = [1, 8] := by
   unfold v_428_0
   exact chunkPrimDimN_shape 1 2 1 (v_426_1 z) [1, 16] (h_426_1 z z_) (by decide)
 #a h_428_0
 attribute [local irreducible] v_428_0
 attribute [local irreducible] s_429
 theorem n_424_428 (z : Store) (tid : Tid) (h : tid ∉ ([697, 698, 984, 985, 998] : List Tid)) : (s_428 z) tid = (s_424 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_424 z) (k_425 z)) (pF _ _ _ _ _ (k_426 z) (k_427 z)) tid h
 #a n_424_428
 theorem r_429_0 (z : Store) : (s_429 z) 1000 = (v_428_0 z) := w_428_0 z
 #a r_429_0
 theorem r_429_1 (z : Store) : (s_429 z) 909 = (z 909) := pR (k_428 z) (pR (n_424_428 z) (pR (n_416_424 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_53 z))))))
 #a r_429_1
 def v_429_0 (z : Store) : Tensor := fw_embedding (v_428_0 z) (z 909)
 def s_430 (z : Store) : Store := storeSet (s_429 z) [(1001, fw_embedding ((s_429 z) 1000) ((s_429 z) 909))]
 theorem t_429 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_711) (pmPeers pmNode_711) (s_429 z) pmNode_711 none = some (s_430 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_429
 theorem k_429 (z : Store) (tid : Tid) (h : tid ∉ [1001]) : (s_430 z) tid = (s_429 z) tid := by
   unfold s_430
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_429
 theorem w_429_0 (z : Store) : (s_430 z) 1001 = v_429_0 z := by
   unfold s_430
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_429_0, r_429_0 z, r_429_1 z] <;> rfl
 #a w_429_0
 theorem h_429_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_429_0 z).shape = [1, 8, 64] := by
   unfold v_429_0
   simp [fw_embedding_shape, lastD, h_428_0 z z_, i_53 z z_]
 #a h_429_0
 attribute [local irreducible] v_429_0
 attribute [local irreducible] s_430
 theorem r_430_0 (z : Store) : (s_430 z) 698 = (v_425_0 z) := pR (k_429 z) (pR (k_428 z) (pR (k_427 z) (pR (k_426 z) (w_425_0 z))))
 #a r_430_0
 theorem r_430_1 (z : Store) : (s_430 z) 1001 = (v_429_0 z) := w_429_0 z
 #a r_430_1
 def v_430_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_425_0 z), (v_429_0 z)]
 theorem g_430 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_476) (s_430 z) pmNode_476 1 2 700 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_476, r_430_0 z, r_430_1 z, h_425_0 z z_, h_429_0 z z_]
 #a g_430
 def s_431 (z : Store) : Store := pL [2, 3] (s_430 z) pmNode_476 1 2
 theorem t_430 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_476) (pmPeers pmNode_476) (s_430 z) pmNode_476 none = some (s_431 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_476) (s_430 z) pmNode_476).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 700 (by decide) (g_430 z z_)]
   rfl
 #a t_430
 theorem k_430 (z : Store) (tid : Tid) (h : tid ∉ [700]) : (s_431 z) tid = (s_430 z) tid := by
   unfold s_431
   dsimp only [pL, pmNode_476, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_430
 theorem w_430_0 (z : Store) : (s_431 z) 700 = v_430_0 z := by
   unfold s_431
   dsimp only [pL, pmNode_476, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_430_0, r_430_0 z, r_430_1 z] <;> rfl
 #a w_430_0
 theorem h_430_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_430_0 z).shape = [1, 16, 32] := by
   unfold v_430_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_425_0 z z_]
 #a h_430_0
 attribute [local irreducible] v_430_0
 attribute [local irreducible] s_431
 theorem r_431_0 (z : Store) : (s_431 z) 695 = (v_423_0 z) := pR (k_430 z) (pR (k_429 z) (pR (k_428 z) (pR (n_424_428 z) (w_423_0 z))))
 #a r_431_0
 theorem r_431_1 (z : Store) : (s_431 z) 700 = (v_430_0 z) := w_430_0 z
 #a r_431_1
 def v_431_0 (z : Store) : Tensor := elemwiseAdd (v_423_0 z) (v_430_0 z)
 def s_432 (z : Store) : Store := storeSet (s_431 z) [(701, elemwiseAdd ((s_431 z) 695) ((s_431 z) 700))]
 theorem t_431 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_477) (pmPeers pmNode_477) (s_431 z) pmNode_477 none = some (s_432 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_431
 theorem k_431 (z : Store) (tid : Tid) (h : tid ∉ [701]) : (s_432 z) tid = (s_431 z) tid := by
   unfold s_432
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_431
 theorem w_431_0 (z : Store) : (s_432 z) 701 = v_431_0 z := by
   unfold s_432
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_431_0, r_431_0 z, r_431_1 z] <;> rfl
 #a w_431_0
 theorem h_431_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_431_0 z).shape = [1, 16, 32] := by
   unfold v_431_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_423_0 z z_, h_430_0 z z_]
 #a h_431_0
 attribute [local irreducible] v_431_0
 attribute [local irreducible] s_432
 record_prefix_opacity v_423_0 s_424 v_424_0 s_425 v_425_0 s_426 v_426_0 v_426_1 s_427 v_427_0 s_428 v_428_0 s_429 v_429_0 s_430 v_430_0 s_431 v_431_0 s_432

 end
 end TrainVerify.Denote.RuntimeWorld
