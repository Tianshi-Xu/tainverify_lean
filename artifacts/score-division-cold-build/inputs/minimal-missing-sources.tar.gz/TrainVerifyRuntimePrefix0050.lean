import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0049
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_385_0 (z : Store) : (s_385 z) 426 = (v_379_0 z) := pR (k_384 z) (pR (n_380_384 z) (w_379_0 z))
 #a r_385_0
 theorem r_385_1 (z : Store) : (s_385 z) 423 = (v_45_0 z) := pR (k_384 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_48_64 z) (pR (k_47 z) (pR (k_46 z) (r_46_0 z)))))))
 #a r_385_1
 def v_385_0 (z : Store) : Tensor := transposeAxes 1 2 (v_379_0 z)
 def s_386 (z : Store) : Store := storeSet (s_385 z) [(425, transposeAxes 1 2 ((s_385 z) 426))]
 theorem t_385 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_428) (pmPeers pmNode_428) (s_385 z) pmNode_428 none = some (s_386 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_385
 theorem k_385 (z : Store) (tid : Tid) (h : tid ∉ [425]) : (s_386 z) tid = (s_385 z) tid := by
   unfold s_386
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_385
 theorem w_385_0 (z : Store) : (s_386 z) 425 = v_385_0 z := by
   unfold s_386
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_385_0, r_385_0 z, r_385_1 z] <;> rfl
 #a w_385_0
 theorem h_385_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_385_0 z).shape = [1, 16, 4, 8] := by
   unfold v_385_0
   change listSwapAt _ _ _ = _
   rw [h_379_0 z z_]
   rfl
 #a h_385_0
 attribute [local irreducible] v_385_0
 attribute [local irreducible] s_386
 theorem r_386_0 (z : Store) : (s_386 z) 122 = (v_383_0 z) := pR (k_385 z) (pR (k_384 z) (w_383_0 z))
 #a r_386_0
 theorem r_386_1 (z : Store) : (s_386 z) 425 = (v_385_0 z) := w_385_0 z
 #a r_386_1
 def v_386_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 2 [(v_383_0 z), (v_385_0 z)]
 theorem g_386 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_193) (s_386 z) pmNode_193 3 2 119 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_193, r_386_0 z, r_386_1 z, h_383_0 z z_, h_385_0 z z_]
 #a g_386
 def s_387 (z : Store) : Store := pL [0, 1] (s_386 z) pmNode_193 3 2
 theorem t_386 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_193) (pmPeers pmNode_193) (s_386 z) pmNode_193 none = some (s_387 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_193) (s_386 z) pmNode_193).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 2 119 (by decide) (g_386 z z_)]
   rfl
 #a t_386
 theorem k_386 (z : Store) (tid : Tid) (h : tid ∉ [119]) : (s_387 z) tid = (s_386 z) tid := by
   unfold s_387
   dsimp only [pL, pmNode_193, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_386
 theorem w_386_0 (z : Store) : (s_387 z) 119 = v_386_0 z := by
   unfold s_387
   dsimp only [pL, pmNode_193, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_386_0, r_386_0 z, r_386_1 z] <;> rfl
 #a w_386_0
 theorem h_386_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_386_0 z).shape = [1, 16, 2, 16] := by
   unfold v_386_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_383_0 z z_]
 #a h_386_0
 attribute [local irreducible] v_386_0
 attribute [local irreducible] s_387
 theorem r_387_0 (z : Store) : (s_387 z) 119 = (v_386_0 z) := w_386_0 z
 #a r_387_0
 theorem r_387_1 (z : Store) : (s_387 z) 106 = (v_22_0 z) := pR (k_386 z) (pR (k_385 z) (pR (k_384 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_48_64 z) (pR (n_40_48 z) (pR (n_36_40 z) (pR (k_35 z) (pR (k_34 z) (r_34_0 z)))))))))))
 #a r_387_1
 def v_387_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_386_0 z)
 def s_388 (z : Store) : Store := storeSet (s_387 z) [(107, fw_view [1, 16, 32] ((s_387 z) 119))]
 theorem t_387 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_194) (pmPeers pmNode_194) (s_387 z) pmNode_194 none = some (s_388 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_387
 theorem k_387 (z : Store) (tid : Tid) (h : tid ∉ [107]) : (s_388 z) tid = (s_387 z) tid := by
   unfold s_388
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_387
 theorem w_387_0 (z : Store) : (s_388 z) 107 = v_387_0 z := by
   unfold s_388
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_387_0, r_387_0 z, r_387_1 z] <;> rfl
 #a w_387_0
 theorem h_387_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_387_0 z).shape = [1, 16, 32] := by
   unfold v_387_0
   rfl
 #a h_387_0
 attribute [local irreducible] v_387_0
 attribute [local irreducible] s_388
 theorem n_384_388 (z : Store) (tid : Tid) (h : tid ∉ ([414, 425, 119, 107] : List Tid)) : (s_388 z) tid = (s_384 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_384 z) (k_385 z)) (pF _ _ _ _ _ (k_386 z) (k_387 z)) tid h
 #a n_384_388
 theorem r_388_0 (z : Store) : (s_388 z) 117 = (v_373_0 z) := pR (n_384_388 z) (pR (n_376_384 z) (pR (k_375 z) (pR (k_374 z) (w_373_0 z))))
 #a r_388_0
 theorem r_388_1 (z : Store) : (s_388 z) 114 = (v_32_0 z) := pR (n_384_388 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_48_64 z) (pR (n_40_48 z) (pR (n_36_40 z) (pR (k_35 z) (pR (k_34 z) (pR (k_33 z) (r_33_0 z))))))))))
 #a r_388_1
 def v_388_0 (z : Store) : Tensor := transposeAxes 1 2 (v_373_0 z)
 def s_389 (z : Store) : Store := storeSet (s_388 z) [(116, transposeAxes 1 2 ((s_388 z) 117))]
 theorem t_388 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_195) (pmPeers pmNode_195) (s_388 z) pmNode_195 none = some (s_389 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_388
 theorem k_388 (z : Store) (tid : Tid) (h : tid ∉ [116]) : (s_389 z) tid = (s_388 z) tid := by
   unfold s_389
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_388
 theorem w_388_0 (z : Store) : (s_389 z) 116 = v_388_0 z := by
   unfold s_389
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_388_0, r_388_0 z, r_388_1 z] <;> rfl
 #a w_388_0
 theorem h_388_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_388_0 z).shape = [1, 16, 4, 8] := by
   unfold v_388_0
   change listSwapAt _ _ _ = _
   rw [h_373_0 z z_]
   rfl
 #a h_388_0
 attribute [local irreducible] v_388_0
 attribute [local irreducible] s_389
 theorem r_389_0 (z : Store) : (s_389 z) 122 = (v_383_0 z) := pR (k_388 z) (pR (k_387 z) (pR (k_386 z) (r_386_0 z)))
 #a r_389_0
 theorem r_389_1 (z : Store) : (s_389 z) 425 = (v_385_0 z) := pR (k_388 z) (pR (k_387 z) (pR (k_386 z) (r_386_1 z)))
 #a r_389_1
 def v_389_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 2 [(v_383_0 z), (v_385_0 z)]
 theorem g_389 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_429) (s_389 z) pmNode_429 3 2 422 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_429, r_389_0 z, r_389_1 z, h_383_0 z z_, h_385_0 z z_]
 #a g_389
 def s_390 (z : Store) : Store := pL [0, 1] (s_389 z) pmNode_429 3 2
 theorem t_389 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_429) (pmPeers pmNode_429) (s_389 z) pmNode_429 none = some (s_390 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_429) (s_389 z) pmNode_429).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 2 422 (by decide) (g_389 z z_)]
   rfl
 #a t_389
 theorem k_389 (z : Store) (tid : Tid) (h : tid ∉ [422]) : (s_390 z) tid = (s_389 z) tid := by
   unfold s_390
   dsimp only [pL, pmNode_429, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_389
 theorem w_389_0 (z : Store) : (s_390 z) 422 = v_389_0 z := by
   unfold s_390
   dsimp only [pL, pmNode_429, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_389_0, r_389_0 z, r_389_1 z] <;> rfl
 #a w_389_0
 theorem h_389_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_389_0 z).shape = [1, 16, 2, 16] := by
   unfold v_389_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_383_0 z z_]
 #a h_389_0
 attribute [local irreducible] v_389_0
 attribute [local irreducible] s_390
 theorem r_390_0 (z : Store) : (s_390 z) 422 = (v_389_0 z) := w_389_0 z
 #a r_390_0
 theorem r_390_1 (z : Store) : (s_390 z) 409 = (v_28_0 z) := pR (k_389 z) (pR (k_388 z) (pR (n_384_388 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_48_64 z) (pR (n_40_48 z) (pR (k_39 z) (pR (k_38 z) (pR (k_37 z) (r_37_0 z)))))))))))
 #a r_390_1
 def v_390_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_389_0 z)
 def s_391 (z : Store) : Store := storeSet (s_390 z) [(411, fw_view [1, 16, 32] ((s_390 z) 422))]
 theorem t_390 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_430) (pmPeers pmNode_430) (s_390 z) pmNode_430 none = some (s_391 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_390
 theorem k_390 (z : Store) (tid : Tid) (h : tid ∉ [411]) : (s_391 z) tid = (s_390 z) tid := by
   unfold s_391
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_390
 theorem w_390_0 (z : Store) : (s_391 z) 411 = v_390_0 z := by
   unfold s_391
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_390_0, r_390_0 z, r_390_1 z] <;> rfl
 #a w_390_0
 theorem h_390_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_390_0 z).shape = [1, 16, 32] := by
   unfold v_390_0
   rfl
 #a h_390_0
 attribute [local irreducible] v_390_0
 attribute [local irreducible] s_391
 theorem r_391_0 (z : Store) : (s_391 z) 420 = (v_378_0 z) := pR (k_390 z) (pR (k_389 z) (pR (k_388 z) (pR (n_384_388 z) (pR (n_380_384 z) (pR (k_379 z) (w_378_0 z))))))
 #a r_391_0
 theorem r_391_1 (z : Store) : (s_391 z) 417 = (v_35_0 z) := pR (k_390 z) (pR (k_389 z) (pR (k_388 z) (pR (n_384_388 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_48_64 z) (pR (n_40_48 z) (pR (n_36_40 z) (r_36_0 z))))))))))
 #a r_391_1
 def v_391_0 (z : Store) : Tensor := transposeAxes 1 2 (v_378_0 z)
 def s_392 (z : Store) : Store := storeSet (s_391 z) [(419, transposeAxes 1 2 ((s_391 z) 420))]
 theorem t_391 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_431) (pmPeers pmNode_431) (s_391 z) pmNode_431 none = some (s_392 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_391
 theorem k_391 (z : Store) (tid : Tid) (h : tid ∉ [419]) : (s_392 z) tid = (s_391 z) tid := by
   unfold s_392
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_391
 theorem w_391_0 (z : Store) : (s_392 z) 419 = v_391_0 z := by
   unfold s_392
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_391_0, r_391_0 z, r_391_1 z] <;> rfl
 #a w_391_0
 theorem h_391_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_391_0 z).shape = [1, 16, 4, 8] := by
   unfold v_391_0
   change listSwapAt _ _ _ = _
   rw [h_378_0 z z_]
   rfl
 #a h_391_0
 attribute [local irreducible] v_391_0
 attribute [local irreducible] s_392
 theorem r_392_0 (z : Store) : (s_392 z) 116 = (v_388_0 z) := pR (k_391 z) (pR (k_390 z) (pR (k_389 z) (w_388_0 z)))
 #a r_392_0
 theorem r_392_1 (z : Store) : (s_392 z) 419 = (v_391_0 z) := w_391_0 z
 #a r_392_1
 def v_392_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_388_0 z), (v_391_0 z)]
 theorem g_392 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_196) (s_392 z) pmNode_196 3 1 113 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_196, r_392_0 z, r_392_1 z, h_388_0 z z_, h_391_0 z z_]
 #a g_392
 def s_393 (z : Store) : Store := pL [0, 1] (s_392 z) pmNode_196 3 1
 theorem t_392 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_196) (pmPeers pmNode_196) (s_392 z) pmNode_196 none = some (s_393 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_196) (s_392 z) pmNode_196).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 113 (by decide) (g_392 z z_)]
   rfl
 #a t_392
 theorem k_392 (z : Store) (tid : Tid) (h : tid ∉ [113]) : (s_393 z) tid = (s_392 z) tid := by
   unfold s_393
   dsimp only [pL, pmNode_196, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_392
 theorem w_392_0 (z : Store) : (s_393 z) 113 = v_392_0 z := by
   unfold s_393
   dsimp only [pL, pmNode_196, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_392_0, r_392_0 z, r_392_1 z] <;> rfl
 #a w_392_0
 theorem h_392_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_392_0 z).shape = [1, 8, 4, 16] := by
   unfold v_392_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_388_0 z z_]
 #a h_392_0
 attribute [local irreducible] v_392_0
 attribute [local irreducible] s_393
 theorem n_388_392 (z : Store) (tid : Tid) (h : tid ∉ ([116, 422, 411, 419] : List Tid)) : (s_392 z) tid = (s_388 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_388 z) (k_389 z)) (pF _ _ _ _ _ (k_390 z) (k_391 z)) tid h
 #a n_388_392
 theorem n_384_392 (z : Store) (tid : Tid) (h : tid ∉ ([414, 425, 119, 107, 116, 422, 411, 419] : List Tid)) : (s_392 z) tid = (s_384 z) tid := by
   exact pF _ _ _ _ _ (n_384_388 z) (n_388_392 z) tid h
 #a n_384_392
 theorem r_393_0 (z : Store) : (s_393 z) 113 = (v_392_0 z) := w_392_0 z
 #a r_393_0
 theorem r_393_1 (z : Store) : (s_393 z) 103 = (v_17_0 z) := pR (k_392 z) (pR (n_384_392 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_28_32 z) (pR (k_27 z) (pR (k_26 z) (pR (k_25 z) (r_25_0 z))))))))))
 #a r_393_1
 def v_393_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_392_0 z)
 def s_394 (z : Store) : Store := storeSet (s_393 z) [(105, fw_view [1, 8, 64] ((s_393 z) 113))]
 theorem t_393 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_197) (pmPeers pmNode_197) (s_393 z) pmNode_197 none = some (s_394 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_393
 theorem k_393 (z : Store) (tid : Tid) (h : tid ∉ [105]) : (s_394 z) tid = (s_393 z) tid := by
   unfold s_394
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_393
 theorem w_393_0 (z : Store) : (s_394 z) 105 = v_393_0 z := by
   unfold s_394
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_393_0, r_393_0 z, r_393_1 z] <;> rfl
 #a w_393_0
 theorem h_393_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_393_0 z).shape = [1, 8, 64] := by
   unfold v_393_0
   rfl
 #a h_393_0
 attribute [local irreducible] v_393_0
 attribute [local irreducible] s_394
 record_prefix_opacity v_385_0 s_386 v_386_0 s_387 v_387_0 s_388 v_388_0 s_389 v_389_0 s_390 v_390_0 s_391 v_391_0 s_392 v_392_0 s_393 v_393_0 s_394

 end
 end TrainVerify.Denote.RuntimeWorld
