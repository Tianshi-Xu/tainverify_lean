import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0045
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_353_0 (z : Store) : (s_353 z) 149 = (v_352_0 z) := w_352_0 z
 #a r_353_0
 theorem r_353_1 (z : Store) : (s_353 z) 146 = (v_65_0 z) := pR (k_352 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (n_72_80 z) (pR (n_68_72 z) (pR (k_67 z) (pR (k_66 z) (r_66_0 z))))))))))
 #a r_353_1
 theorem r_353_2 (z : Store) : (s_353 z) 78 = (v_62_0 z) := pR (k_352 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (n_72_80 z) (pR (n_68_72 z) (pR (k_67 z) (pR (k_66 z) (r_66_1 z))))))))))
 #a r_353_2
 def v_353_0 (z : Store) : Tensor := (batchedMatmulBwd (v_352_0 z) (v_65_0 z) (v_62_0 z)).1
 def v_353_1 (z : Store) : Tensor := (batchedMatmulBwd (v_352_0 z) (v_65_0 z) (v_62_0 z)).2
 def s_354 (z : Store) : Store := storeSet (s_353 z) [(148, (batchedMatmulBwd ((s_353 z) 149) ((s_353 z) 146) ((s_353 z) 78)).1), (150, (batchedMatmulBwd ((s_353 z) 149) ((s_353 z) 146) ((s_353 z) 78)).2)]
 theorem t_353 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_178) (pmPeers pmNode_178) (s_353 z) pmNode_178 none = some (s_354 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_353
 theorem k_353 (z : Store) (tid : Tid) (h : tid ∉ [148, 150]) : (s_354 z) tid = (s_353 z) tid := by
   unfold s_354
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_353
 theorem w_353_0 (z : Store) : (s_354 z) 148 = v_353_0 z := by
   unfold s_354
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_353_0, r_353_0 z, r_353_1 z, r_353_2 z] <;> rfl
 #a w_353_0
 theorem h_353_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_353_0 z).shape = [1, 4, 8, 16] := by
   unfold v_353_0
   change (batchedMatmul (v_352_0 z) (transpose2d (v_62_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_352_0 z z_, h_62_0 z z_]
   rfl
 #a h_353_0
 attribute [local irreducible] v_353_0
 theorem w_353_1 (z : Store) : (s_354 z) 150 = v_353_1 z := by
   unfold s_354
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_353_1, r_353_0 z, r_353_1 z, r_353_2 z] <;> rfl
 #a w_353_1
 theorem h_353_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_353_1 z).shape = [1, 4, 16, 16] := by
   unfold v_353_1
   change (batchedMatmul (transpose2d (v_65_0 z)) (v_352_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_352_0 z z_, h_65_0 z z_]
   rfl
 #a h_353_1
 attribute [local irreducible] v_353_1
 attribute [local irreducible] s_354
 theorem r_354_0 (z : Store) : (s_354 z) 157 = (v_347_0 z) := pR (k_353 z) (pR (k_352 z) (pR (k_351 z) (pR (k_350 z) (r_350_0 z))))
 #a r_354_0
 theorem r_354_1 (z : Store) : (s_354 z) 460 = (v_349_0 z) := pR (k_353 z) (pR (k_352 z) (pR (k_351 z) (pR (k_350 z) (r_350_1 z))))
 #a r_354_1
 def v_354_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_347_0 z), (v_349_0 z)]
 theorem g_354 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_411) (s_354 z) pmNode_411 2 1 457 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_411, r_354_0 z, r_354_1 z, h_347_0 z z_, h_349_0 z z_]
 #a g_354
 def s_355 (z : Store) : Store := pL [0, 1] (s_354 z) pmNode_411 2 1
 theorem t_354 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_411) (pmPeers pmNode_411) (s_354 z) pmNode_411 none = some (s_355 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_411) (s_354 z) pmNode_411).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 457 (by decide) (g_354 z z_)]
   rfl
 #a t_354
 theorem k_354 (z : Store) (tid : Tid) (h : tid ∉ [457]) : (s_355 z) tid = (s_354 z) tid := by
   unfold s_355
   dsimp only [pL, pmNode_411, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_354
 theorem w_354_0 (z : Store) : (s_355 z) 457 = v_354_0 z := by
   unfold s_355
   dsimp only [pL, pmNode_411, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_354_0, r_354_0 z, r_354_1 z] <;> rfl
 #a w_354_0
 theorem h_354_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_354_0 z).shape = [1, 8, 4, 16] := by
   unfold v_354_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_347_0 z z_]
 #a h_354_0
 attribute [local irreducible] v_354_0
 attribute [local irreducible] s_355
 theorem r_355_0 (z : Store) : (s_355 z) 457 = (v_354_0 z) := w_354_0 z
 #a r_355_0
 theorem r_355_1 (z : Store) : (s_355 z) 454 = (v_72_0 z) := pR (k_354 z) (pR (k_353 z) (pR (k_352 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (n_76_80 z) (pR (k_75 z) (pR (k_74 z) (pR (k_73 z) (r_73_0 z))))))))))))
 #a r_355_1
 def v_355_0 (z : Store) : Tensor := (v_354_0 z)
 def s_356 (z : Store) : Store := storeSet (s_355 z) [(455, ((s_355 z) 457))]
 theorem t_355 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_412) (pmPeers pmNode_412) (s_355 z) pmNode_412 none = some (s_356 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_355
 theorem k_355 (z : Store) (tid : Tid) (h : tid ∉ [455]) : (s_356 z) tid = (s_355 z) tid := by
   unfold s_356
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_355
 theorem w_355_0 (z : Store) : (s_356 z) 455 = v_355_0 z := by
   unfold s_356
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_355_0, r_355_0 z, r_355_1 z] <;> rfl
 #a w_355_0
 theorem h_355_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_355_0 z).shape = [1, 8, 4, 16] := by
   unfold v_355_0
   exact h_354_0 z z_
 #a h_355_0
 attribute [local irreducible] v_355_0
 attribute [local irreducible] s_356
 theorem n_352_356 (z : Store) (tid : Tid) (h : tid ∉ ([149, 148, 150, 457, 455] : List Tid)) : (s_356 z) tid = (s_352 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_352 z) (k_353 z)) (pF _ _ _ _ _ (k_354 z) (k_355 z)) tid h
 #a n_352_356
 theorem r_356_0 (z : Store) : (s_356 z) 455 = (v_355_0 z) := w_355_0 z
 #a r_356_0
 theorem r_356_1 (z : Store) : (s_356 z) 450 = (v_71_0 z) := pR (n_352_356 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (n_72_80 z) (r_72_0 z)))))))
 #a r_356_1
 def v_356_0 (z : Store) : Tensor := transposeAxes 1 2 (v_355_0 z)
 def s_357 (z : Store) : Store := storeSet (s_356 z) [(453, transposeAxes 1 2 ((s_356 z) 455))]
 theorem t_356 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_413) (pmPeers pmNode_413) (s_356 z) pmNode_413 none = some (s_357 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_356
 theorem k_356 (z : Store) (tid : Tid) (h : tid ∉ [453]) : (s_357 z) tid = (s_356 z) tid := by
   unfold s_357
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_356
 theorem w_356_0 (z : Store) : (s_357 z) 453 = v_356_0 z := by
   unfold s_357
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_356_0, r_356_0 z, r_356_1 z] <;> rfl
 #a w_356_0
 theorem h_356_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_356_0 z).shape = [1, 4, 8, 16] := by
   unfold v_356_0
   change listSwapAt _ _ _ = _
   rw [h_355_0 z z_]
   rfl
 #a h_356_0
 attribute [local irreducible] v_356_0
 attribute [local irreducible] s_357
 theorem r_357_0 (z : Store) : (s_357 z) 453 = (v_356_0 z) := w_356_0 z
 #a r_357_0
 theorem r_357_1 (z : Store) : (s_357 z) 449 = (v_70_0 z) := pR (k_356 z) (pR (n_352_356 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (n_72_80 z) (pR (k_71 z) (r_71_0 z)))))))))
 #a r_357_1
 theorem r_357_2 (z : Store) : (s_357 z) 381 = (v_69_0 z) := pR (k_356 z) (pR (n_352_356 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_80_96 z) (pR (n_72_80 z) (pR (k_71 z) (r_71_1 z)))))))))
 #a r_357_2
 def v_357_0 (z : Store) : Tensor := (batchedMatmulBwd (v_356_0 z) (v_70_0 z) (v_69_0 z)).1
 def v_357_1 (z : Store) : Tensor := (batchedMatmulBwd (v_356_0 z) (v_70_0 z) (v_69_0 z)).2
 def s_358 (z : Store) : Store := storeSet (s_357 z) [(452, (batchedMatmulBwd ((s_357 z) 453) ((s_357 z) 449) ((s_357 z) 381)).1), (451, (batchedMatmulBwd ((s_357 z) 453) ((s_357 z) 449) ((s_357 z) 381)).2)]
 theorem t_357 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_414) (pmPeers pmNode_414) (s_357 z) pmNode_414 none = some (s_358 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_357
 theorem k_357 (z : Store) (tid : Tid) (h : tid ∉ [452, 451]) : (s_358 z) tid = (s_357 z) tid := by
   unfold s_358
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_357
 theorem w_357_0 (z : Store) : (s_358 z) 452 = v_357_0 z := by
   unfold s_358
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_357_0, r_357_0 z, r_357_1 z, r_357_2 z] <;> rfl
 #a w_357_0
 theorem h_357_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_357_0 z).shape = [1, 4, 8, 16] := by
   unfold v_357_0
   change (batchedMatmul (v_356_0 z) (transpose2d (v_69_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_356_0 z z_, h_69_0 z z_]
   rfl
 #a h_357_0
 attribute [local irreducible] v_357_0
 theorem w_357_1 (z : Store) : (s_358 z) 451 = v_357_1 z := by
   unfold s_358
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_357_1, r_357_0 z, r_357_1 z, r_357_2 z] <;> rfl
 #a w_357_1
 theorem h_357_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_357_1 z).shape = [1, 4, 16, 16] := by
   unfold v_357_1
   change (batchedMatmul (transpose2d (v_70_0 z)) (v_356_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_356_0 z z_, h_70_0 z z_]
   rfl
 #a h_357_1
 attribute [local irreducible] v_357_1
 attribute [local irreducible] s_358
 theorem r_358_0 (z : Store) : (s_358 z) 148 = (v_353_0 z) := pR (k_357 z) (pR (k_356 z) (pR (k_355 z) (pR (k_354 z) (w_353_0 z))))
 #a r_358_0
 theorem r_358_1 (z : Store) : (s_358 z) 452 = (v_357_0 z) := w_357_0 z
 #a r_358_1
 def v_358_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_353_0 z), (v_357_0 z)]
 theorem g_358 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_179) (s_358 z) pmNode_179 2 1 145 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_179, r_358_0 z, r_358_1 z, h_353_0 z z_, h_357_0 z z_]
 #a g_358
 def s_359 (z : Store) : Store := pL [0, 1] (s_358 z) pmNode_179 2 1
 theorem t_358 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_179) (pmPeers pmNode_179) (s_358 z) pmNode_179 none = some (s_359 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_179) (s_358 z) pmNode_179).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 145 (by decide) (g_358 z z_)]
   rfl
 #a t_358
 theorem k_358 (z : Store) (tid : Tid) (h : tid ∉ [145]) : (s_359 z) tid = (s_358 z) tid := by
   unfold s_359
   dsimp only [pL, pmNode_179, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_358
 theorem w_358_0 (z : Store) : (s_359 z) 145 = v_358_0 z := by
   unfold s_359
   dsimp only [pL, pmNode_179, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_358_0, r_358_0 z, r_358_1 z] <;> rfl
 #a w_358_0
 theorem h_358_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_358_0 z).shape = [1, 2, 16, 16] := by
   unfold v_358_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_353_0 z z_]
 #a h_358_0
 attribute [local irreducible] v_358_0
 attribute [local irreducible] s_359
 theorem r_359_0 (z : Store) : (s_359 z) 150 = (v_353_1 z) := pR (k_358 z) (pR (k_357 z) (pR (k_356 z) (pR (k_355 z) (pR (k_354 z) (w_353_1 z)))))
 #a r_359_0
 theorem r_359_1 (z : Store) : (s_359 z) 451 = (v_357_1 z) := pR (k_358 z) (w_357_1 z)
 #a r_359_1
 def v_359_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 0 [(v_353_1 z), (v_357_1 z)]
 def s_360 (z : Store) : Store := storeSet (s_359 z) [(129, reduceScatterPrimDimN 2 2 0 [((s_359 z) 150), ((s_359 z) 451)])]
 theorem t_359 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_180) (pmPeers pmNode_180) (s_359 z) pmNode_180 none = some (s_360 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_359 z) pmNode_180 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_359
 theorem k_359 (z : Store) (tid : Tid) (h : tid ∉ [129]) : (s_360 z) tid = (s_359 z) tid := by
   unfold s_360
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_359
 theorem w_359_0 (z : Store) : (s_360 z) 129 = v_359_0 z := by
   unfold s_360
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_359_0, r_359_0 z, r_359_1 z] <;> rfl
 #a w_359_0
 theorem h_359_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_359_0 z).shape = [1, 4, 8, 16] := by
   unfold v_359_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 0 _ [1, 4, 16, 16]
   · rw [allReducePrim_shape _ _ _ (v_353_1 z) rfl]
     exact h_353_1 z z_
   · decide
 #a h_359_0
 attribute [local irreducible] v_359_0
 attribute [local irreducible] s_360
 theorem n_356_360 (z : Store) (tid : Tid) (h : tid ∉ ([453, 452, 451, 145, 129] : List Tid)) : (s_360 z) tid = (s_356 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_356 z) (k_357 z)) (pF _ _ _ _ _ (k_358 z) (k_359 z)) tid h
 #a n_356_360
 theorem n_352_360 (z : Store) (tid : Tid) (h : tid ∉ ([149, 148, 150, 457, 455, 453, 452, 451, 145, 129] : List Tid)) : (s_360 z) tid = (s_352 z) tid := by
   exact pF _ _ _ _ _ (n_352_356 z) (n_356_360 z) tid h
 #a n_352_360
 theorem r_360_0 (z : Store) : (s_360 z) 145 = (v_358_0 z) := pR (k_359 z) (w_358_0 z)
 #a r_360_0
 theorem r_360_1 (z : Store) : (s_360 z) 142 = (v_60_0 z) := pR (n_352_360 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (k_63 z) (pR (k_62 z) (pR (k_61 z) (r_61_0 z))))))))
 #a r_360_1
 def v_360_0 (z : Store) : Tensor := bw_softmax (v_358_0 z) (v_60_0 z)
 def s_361 (z : Store) : Store := storeSet (s_360 z) [(144, bw_softmax ((s_360 z) 145) ((s_360 z) 142))]
 theorem t_360 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_181) (pmPeers pmNode_181) (s_360 z) pmNode_181 none = some (s_361 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_360
 theorem k_360 (z : Store) (tid : Tid) (h : tid ∉ [144]) : (s_361 z) tid = (s_360 z) tid := by
   unfold s_361
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_360
 theorem w_360_0 (z : Store) : (s_361 z) 144 = v_360_0 z := by
   unfold s_361
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_360_0, r_360_0 z, r_360_1 z] <;> rfl
 #a w_360_0
 theorem h_360_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_360_0 z).shape = [1, 2, 16, 16] := by
   unfold v_360_0
   unfold bw_softmax softmaxBwd softmaxBwdFromOutput softmax
   rw [h_60_0 z z_]
   rfl
 #a h_360_0
 attribute [local irreducible] v_360_0
 attribute [local irreducible] s_361
 record_prefix_opacity v_353_0 v_353_1 s_354 v_354_0 s_355 v_355_0 s_356 v_356_0 s_357 v_357_0 v_357_1 s_358 v_358_0 s_359 v_359_0 s_360 v_360_0 s_361

 end
 end TrainVerify.Denote.RuntimeWorld
