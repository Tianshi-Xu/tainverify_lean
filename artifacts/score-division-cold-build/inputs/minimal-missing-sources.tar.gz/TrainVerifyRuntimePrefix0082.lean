import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0081
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_652_0 (z : Store) : (s_652 z) 1179 = (v_647_1 z) := pR (n_648_652 z) (w_647_1 z)
 #a r_652_0
 theorem r_652_1 (z : Store) : (s_652 z) 1175 = (v_621_0 z) := pR (n_648_652 z) (pR (n_640_648 z) (pR (n_624_640 z) (pR (k_623 z) (pR (k_622 z) (r_622_0 z)))))
 #a r_652_1
 theorem r_652_2 (z : Store) : (s_652 z) 922 = (z 922) := pR (n_648_652 z) (pR (n_640_648 z) (pR (n_624_640 z) (pR (k_623 z) (pR (k_622 z) (r_622_1 z)))))
 #a r_652_2
 def v_652_0 (z : Store) : Tensor := (bw_linear (v_647_1 z) (v_621_0 z) (z 922)).1
 def v_652_1 (z : Store) : Tensor := (bw_linear (v_647_1 z) (v_621_0 z) (z 922)).2
 def s_653 (z : Store) : Store := storeSet (s_652 z) [(1177, (bw_linear ((s_652 z) 1179) ((s_652 z) 1175) ((s_652 z) 922)).1), (975, (bw_linear ((s_652 z) 1179) ((s_652 z) 1175) ((s_652 z) 922)).2)]
 theorem t_652 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_822) (pmPeers pmNode_822) (s_652 z) pmNode_822 none = some (s_653 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_652
 theorem k_652 (z : Store) (tid : Tid) (h : tid ∉ [1177, 975]) : (s_653 z) tid = (s_652 z) tid := by
   unfold s_653
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_652
 theorem w_652_0 (z : Store) : (s_653 z) 1177 = v_652_0 z := by
   unfold s_653
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_652_0, r_652_0 z, r_652_1 z, r_652_2 z] <;> rfl
 #a w_652_0
 theorem h_652_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_652_0 z).shape = [1, 8, 256] := by
   unfold v_652_0
   exact bw_linear_3d_fst_shape 1 8 64 256 (v_647_1 z) (v_621_0 z) (z 922) (h_647_1 z z_) (h_621_0 z z_) (i_95 z z_)
 #a h_652_0
 attribute [local irreducible] v_652_0
 theorem w_652_1 (z : Store) : (s_653 z) 975 = v_652_1 z := by
   unfold s_653
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_652_1, r_652_0 z, r_652_1 z, r_652_2 z] <;> rfl
 #a w_652_1
 theorem h_652_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_652_1 z).shape = [64, 256] := by
   unfold v_652_1
   exact bw_linear_3d_snd_shape 1 8 64 256 (v_647_1 z) (v_621_0 z) (z 922) (h_647_1 z z_) (h_621_0 z z_) (i_95 z z_)
 #a h_652_1
 attribute [local irreducible] v_652_1
 attribute [local irreducible] s_653
 theorem r_653_0 (z : Store) : (s_653 z) 1177 = (v_652_0 z) := w_652_0 z
 #a r_653_0
 theorem r_653_1 (z : Store) : (s_653 z) 1174 = (v_620_0 z) := pR (k_652 z) (pR (n_648_652 z) (pR (n_640_648 z) (pR (n_624_640 z) (pR (k_623 z) (pR (k_622 z) (pR (k_621 z) (r_621_0 z)))))))
 #a r_653_1
 def v_653_0 (z : Store) : Tensor := bw_gelu (v_652_0 z) (v_620_0 z)
 def s_654 (z : Store) : Store := storeSet (s_653 z) [(1176, bw_gelu ((s_653 z) 1177) ((s_653 z) 1174))]
 theorem t_653 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_823) (pmPeers pmNode_823) (s_653 z) pmNode_823 none = some (s_654 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_653
 theorem k_653 (z : Store) (tid : Tid) (h : tid ∉ [1176]) : (s_654 z) tid = (s_653 z) tid := by
   unfold s_654
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_653
 theorem w_653_0 (z : Store) : (s_654 z) 1176 = v_653_0 z := by
   unfold s_654
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_653_0, r_653_0 z, r_653_1 z] <;> rfl
 #a w_653_0
 theorem h_653_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_653_0 z).shape = [1, 8, 256] := by
   unfold v_653_0
   exact h_620_0 z z_
 #a h_653_0
 attribute [local irreducible] v_653_0
 attribute [local irreducible] s_654
 theorem r_654_0 (z : Store) : (s_654 z) 873 = (v_650_0 z) := pR (k_653 z) (pR (k_652 z) (pR (k_651 z) (w_650_0 z)))
 #a r_654_0
 theorem r_654_1 (z : Store) : (s_654 z) 1176 = (v_653_0 z) := w_653_0 z
 #a r_654_1
 def v_654_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_650_0 z), (v_653_0 z)]
 def s_655 (z : Store) : Store := storeSet (s_654 z) [(691, allGatherPrimDimN 1 2 0 [((s_654 z) 873), ((s_654 z) 1176)])]
 theorem t_654 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_588) (pmPeers pmNode_588) (s_654 z) pmNode_588 none = some (s_655 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_654 z) pmNode_588 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_654
 theorem k_654 (z : Store) (tid : Tid) (h : tid ∉ [691]) : (s_655 z) tid = (s_654 z) tid := by
   unfold s_655
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_654
 theorem w_654_0 (z : Store) : (s_655 z) 691 = v_654_0 z := by
   unfold s_655
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_654_0, r_654_0 z, r_654_1 z] <;> rfl
 #a w_654_0
 theorem h_654_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_654_0 z).shape = [1, 16, 256] := by
   unfold v_654_0
   exact allGatherPrimDimN_shape 1 2 [(v_650_0 z), (v_653_0 z)] [1, 8, 256] (h_650_0 z z_)
 #a h_654_0
 attribute [local irreducible] v_654_0
 attribute [local irreducible] s_655
 theorem r_655_0 (z : Store) : (s_655 z) 691 = (v_654_0 z) := w_654_0 z
 #a r_655_0
 theorem r_655_1 (z : Store) : (s_655 z) 868 = (v_610_0 z) := pR (k_654 z) (pR (k_653 z) (pR (k_652 z) (pR (n_648_652 z) (pR (n_640_648 z) (pR (n_624_640 z) (pR (n_616_624 z) (pR (n_612_616 z) (pR (k_611 z) (r_611_0 z)))))))))
 #a r_655_1
 theorem r_655_2 (z : Store) : (s_655 z) 669 = (z 669) := pR (k_654 z) (pR (k_653 z) (pR (k_652 z) (pR (n_648_652 z) (pR (n_640_648 z) (pR (n_624_640 z) (pR (n_616_624 z) (pR (n_612_616 z) (pR (k_611 z) (r_611_1 z)))))))))
 #a r_655_2
 def v_655_0 (z : Store) : Tensor := (bw_linear (v_654_0 z) (v_610_0 z) (z 669)).1
 def v_655_1 (z : Store) : Tensor := (bw_linear (v_654_0 z) (v_610_0 z) (z 669)).2
 def s_656 (z : Store) : Store := storeSet (s_655 z) [(870, (bw_linear ((s_655 z) 691) ((s_655 z) 868) ((s_655 z) 669)).1), (670, (bw_linear ((s_655 z) 691) ((s_655 z) 868) ((s_655 z) 669)).2)]
 theorem t_655 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_589) (pmPeers pmNode_589) (s_655 z) pmNode_589 none = some (s_656 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_655
 theorem k_655 (z : Store) (tid : Tid) (h : tid ∉ [870, 670]) : (s_656 z) tid = (s_655 z) tid := by
   unfold s_656
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_655
 theorem w_655_0 (z : Store) : (s_656 z) 870 = v_655_0 z := by
   unfold s_656
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_655_0, r_655_0 z, r_655_1 z, r_655_2 z] <;> rfl
 #a w_655_0
 theorem h_655_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_655_0 z).shape = [1, 16, 32] := by
   unfold v_655_0
   exact bw_linear_3d_fst_shape 1 16 256 32 (v_654_0 z) (v_610_0 z) (z 669) (h_654_0 z z_) (h_610_0 z z_) (i_90 z z_)
 #a h_655_0
 attribute [local irreducible] v_655_0
 theorem w_655_1 (z : Store) : (s_656 z) 670 = v_655_1 z := by
   unfold s_656
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_655_1, r_655_0 z, r_655_1 z, r_655_2 z] <;> rfl
 #a w_655_1
 theorem h_655_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_655_1 z).shape = [256, 32] := by
   unfold v_655_1
   exact bw_linear_3d_snd_shape 1 16 256 32 (v_654_0 z) (v_610_0 z) (z 669) (h_654_0 z z_) (h_610_0 z z_) (i_90 z z_)
 #a h_655_1
 attribute [local irreducible] v_655_1
 attribute [local irreducible] s_656
 theorem r_656_0 (z : Store) : (s_656 z) 873 = (v_650_0 z) := pR (k_655 z) (pR (k_654 z) (r_654_0 z))
 #a r_656_0
 theorem r_656_1 (z : Store) : (s_656 z) 1176 = (v_653_0 z) := pR (k_655 z) (pR (k_654 z) (r_654_1 z))
 #a r_656_1
 def v_656_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_650_0 z), (v_653_0 z)]
 def s_657 (z : Store) : Store := storeSet (s_656 z) [(994, allGatherPrimDimN 1 2 1 [((s_656 z) 873), ((s_656 z) 1176)])]
 theorem t_656 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_824) (pmPeers pmNode_824) (s_656 z) pmNode_824 none = some (s_657 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_656 z) pmNode_824 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_656
 theorem k_656 (z : Store) (tid : Tid) (h : tid ∉ [994]) : (s_657 z) tid = (s_656 z) tid := by
   unfold s_657
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_656
 theorem w_656_0 (z : Store) : (s_657 z) 994 = v_656_0 z := by
   unfold s_657
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_656_0, r_656_0 z, r_656_1 z] <;> rfl
 #a w_656_0
 theorem h_656_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_656_0 z).shape = [1, 16, 256] := by
   unfold v_656_0
   exact allGatherPrimDimN_shape 1 2 [(v_650_0 z), (v_653_0 z)] [1, 8, 256] (h_650_0 z z_)
 #a h_656_0
 attribute [local irreducible] v_656_0
 attribute [local irreducible] s_657
 theorem n_652_656 (z : Store) (tid : Tid) (h : tid ∉ ([1177, 975, 1176, 691, 870, 670] : List Tid)) : (s_656 z) tid = (s_652 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_652 z) (k_653 z)) (pF _ _ _ _ _ (k_654 z) (k_655 z)) tid h
 #a n_652_656
 theorem n_648_656 (z : Store) (tid : Tid) (h : tid ∉ ([908, 874, 672, 873, 1211, 1177, 975, 1176, 691, 870, 670] : List Tid)) : (s_656 z) tid = (s_648 z) tid := by
   exact pF _ _ _ _ _ (n_648_652 z) (n_652_656 z) tid h
 #a n_648_656
 theorem n_640_656 (z : Store) (tid : Tid) (h : tid ∉ ([1188, 1187, 982, 882, 880, 674, 676, 879, 876, 1185, 1183, 977, 979, 1182, 1179, 908, 874, 672, 873, 1211, 1177, 975, 1176, 691, 870, 670] : List Tid)) : (s_656 z) tid = (s_640 z) tid := by
   exact pF _ _ _ _ _ (n_640_648 z) (n_648_656 z) tid h
 #a n_640_656
 theorem r_657_0 (z : Store) : (s_657 z) 994 = (v_656_0 z) := w_656_0 z
 #a r_657_0
 theorem r_657_1 (z : Store) : (s_657 z) 1171 = (v_612_0 z) := pR (k_656 z) (pR (n_640_656 z) (pR (n_624_640 z) (pR (n_616_624 z) (pR (k_615 z) (pR (k_614 z) (pR (k_613 z) (r_613_0 z)))))))
 #a r_657_1
 theorem r_657_2 (z : Store) : (s_657 z) 972 = (z 972) := pR (k_656 z) (pR (n_640_656 z) (pR (n_624_640 z) (pR (n_616_624 z) (pR (k_615 z) (pR (k_614 z) (pR (k_613 z) (r_613_1 z)))))))
 #a r_657_2
 def v_657_0 (z : Store) : Tensor := (bw_linear (v_656_0 z) (v_612_0 z) (z 972)).1
 def v_657_1 (z : Store) : Tensor := (bw_linear (v_656_0 z) (v_612_0 z) (z 972)).2
 def s_658 (z : Store) : Store := storeSet (s_657 z) [(1173, (bw_linear ((s_657 z) 994) ((s_657 z) 1171) ((s_657 z) 972)).1), (973, (bw_linear ((s_657 z) 994) ((s_657 z) 1171) ((s_657 z) 972)).2)]
 theorem t_657 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_825) (pmPeers pmNode_825) (s_657 z) pmNode_825 none = some (s_658 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_657
 theorem k_657 (z : Store) (tid : Tid) (h : tid ∉ [1173, 973]) : (s_658 z) tid = (s_657 z) tid := by
   unfold s_658
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_657
 theorem w_657_0 (z : Store) : (s_658 z) 1173 = v_657_0 z := by
   unfold s_658
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_657_0, r_657_0 z, r_657_1 z, r_657_2 z] <;> rfl
 #a w_657_0
 theorem h_657_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_657_0 z).shape = [1, 16, 32] := by
   unfold v_657_0
   exact bw_linear_3d_fst_shape 1 16 256 32 (v_656_0 z) (v_612_0 z) (z 972) (h_656_0 z z_) (h_612_0 z z_) (i_91 z z_)
 #a h_657_0
 attribute [local irreducible] v_657_0
 theorem w_657_1 (z : Store) : (s_658 z) 973 = v_657_1 z := by
   unfold s_658
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_657_1, r_657_0 z, r_657_1 z, r_657_2 z] <;> rfl
 #a w_657_1
 theorem h_657_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_657_1 z).shape = [256, 32] := by
   unfold v_657_1
   exact bw_linear_3d_snd_shape 1 16 256 32 (v_656_0 z) (v_612_0 z) (z 972) (h_656_0 z z_) (h_612_0 z z_) (i_91 z z_)
 #a h_657_1
 attribute [local irreducible] v_657_1
 attribute [local irreducible] s_658
 theorem r_658_0 (z : Store) : (s_658 z) 870 = (v_655_0 z) := pR (k_657 z) (pR (k_656 z) (w_655_0 z))
 #a r_658_0
 theorem r_658_1 (z : Store) : (s_658 z) 1173 = (v_657_0 z) := w_657_0 z
 #a r_658_1
 def v_658_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_655_0 z), (v_657_0 z)]
 theorem g_658 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_590) (s_658 z) pmNode_590 2 1 867 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_590, r_658_0 z, r_658_1 z, h_655_0 z z_, h_657_0 z z_]
 #a g_658
 def s_659 (z : Store) : Store := pL [2, 3] (s_658 z) pmNode_590 2 1
 theorem t_658 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_590) (pmPeers pmNode_590) (s_658 z) pmNode_590 none = some (s_659 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_590) (s_658 z) pmNode_590).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 867 (by decide) (g_658 z z_)]
   rfl
 #a t_658
 theorem k_658 (z : Store) (tid : Tid) (h : tid ∉ [867]) : (s_659 z) tid = (s_658 z) tid := by
   unfold s_659
   dsimp only [pL, pmNode_590, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_658
 theorem w_658_0 (z : Store) : (s_659 z) 867 = v_658_0 z := by
   unfold s_659
   dsimp only [pL, pmNode_590, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_658_0, r_658_0 z, r_658_1 z] <;> rfl
 #a w_658_0
 theorem h_658_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_658_0 z).shape = [1, 8, 64] := by
   unfold v_658_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_655_0 z z_]
 #a h_658_0
 attribute [local irreducible] v_658_0
 attribute [local irreducible] s_659
 theorem n_608_640 (z : Store) (tid : Tid) (h : tid ∉ ([1167, 1168, 868, 869, 1171, 1172, 871, 872, 875, 877, 878, 881, 1174, 1175, 1178, 1180, 1181, 1184, 686, 883, 989, 1186, 886, 887, 1189, 1190, 683, 888, 986, 1191, 884, 885, 679] : List Tid)) : (s_640 z) tid = (s_608 z) tid := by
   exact pF _ _ _ _ _ (n_608_624 z) (n_624_640 z) tid h
 #a n_608_640
 record_prefix_opacity v_652_0 v_652_1 s_653 v_653_0 s_654 v_654_0 s_655 v_655_0 v_655_1 s_656 v_656_0 s_657 v_657_0 v_657_1 s_658 v_658_0 s_659

 end
 end TrainVerify.Denote.RuntimeWorld
