import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0060
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_475_0 (z : Store) : (s_475 z) 721 = (v_455_0 z) := pR (k_474 z) (pR (k_473 z) (pR (k_472 z) (pR (n_468_472 z) (pR (k_467 z) (pR (k_466 z) (r_466_0 z))))))
 #a r_475_0
 theorem r_475_1 (z : Store) : (s_475 z) 1024 = (v_458_0 z) := pR (k_474 z) (pR (k_473 z) (pR (k_472 z) (pR (n_468_472 z) (pR (k_467 z) (pR (k_466 z) (r_466_1 z))))))
 #a r_475_1
 def v_475_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_455_0 z), (v_458_0 z)]
 theorem g_475 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_733) (s_475 z) pmNode_733 3 1 1041 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_733, r_475_0 z, r_475_1 z, h_455_0 z z_, h_458_0 z z_]
 #a g_475
 def s_476 (z : Store) : Store := pL [2, 3] (s_475 z) pmNode_733 3 1
 theorem t_475 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_733) (pmPeers pmNode_733) (s_475 z) pmNode_733 none = some (s_476 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_733) (s_475 z) pmNode_733).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 1041 (by decide) (g_475 z z_)]
   rfl
 #a t_475
 theorem k_475 (z : Store) (tid : Tid) (h : tid ∉ [1041]) : (s_476 z) tid = (s_475 z) tid := by
   unfold s_476
   dsimp only [pL, pmNode_733, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_475
 theorem w_475_0 (z : Store) : (s_476 z) 1041 = v_475_0 z := by
   unfold s_476
   dsimp only [pL, pmNode_733, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_475_0, r_475_0 z, r_475_1 z] <;> rfl
 #a w_475_0
 theorem h_475_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_475_0 z).shape = [1, 2, 16, 16] := by
   unfold v_475_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_455_0 z z_]
 #a h_475_0
 attribute [local irreducible] v_475_0
 attribute [local irreducible] s_476
 theorem r_476_0 (z : Store) : (s_476 z) 736 = (v_465_0 z) := pR (k_475 z) (pR (k_474 z) (pR (k_473 z) (r_473_0 z)))
 #a r_476_0
 theorem r_476_1 (z : Store) : (s_476 z) 1039 = (v_472_0 z) := pR (k_475 z) (pR (k_474 z) (pR (k_473 z) (r_473_1 z)))
 #a r_476_1
 def v_476_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_465_0 z), (v_472_0 z)]
 theorem g_476 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_734) (s_476 z) pmNode_734 2 1 1042 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_734, r_476_0 z, r_476_1 z, h_465_0 z z_, h_472_0 z z_]
 #a g_476
 def s_477 (z : Store) : Store := pL [2, 3] (s_476 z) pmNode_734 2 1
 theorem t_476 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_734) (pmPeers pmNode_734) (s_476 z) pmNode_734 none = some (s_477 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_734) (s_476 z) pmNode_734).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1042 (by decide) (g_476 z z_)]
   rfl
 #a t_476
 theorem k_476 (z : Store) (tid : Tid) (h : tid ∉ [1042]) : (s_477 z) tid = (s_476 z) tid := by
   unfold s_477
   dsimp only [pL, pmNode_734, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_476
 theorem w_476_0 (z : Store) : (s_477 z) 1042 = v_476_0 z := by
   unfold s_477
   dsimp only [pL, pmNode_734, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_476_0, r_476_0 z, r_476_1 z] <;> rfl
 #a w_476_0
 theorem h_476_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_476_0 z).shape = [1, 2, 16, 16] := by
   unfold v_476_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_465_0 z z_]
 #a h_476_0
 attribute [local irreducible] v_476_0
 attribute [local irreducible] s_477
 theorem r_477_0 (z : Store) : (s_477 z) 1041 = (v_475_0 z) := pR (k_476 z) (w_475_0 z)
 #a r_477_0
 theorem r_477_1 (z : Store) : (s_477 z) 1042 = (v_476_0 z) := w_476_0 z
 #a r_477_1
 def v_477_0 (z : Store) : Tensor := fw_matmul (v_475_0 z) (v_476_0 z)
 def s_478 (z : Store) : Store := storeSet (s_477 z) [(1043, fw_matmul ((s_477 z) 1041) ((s_477 z) 1042))]
 theorem t_477 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_735) (pmPeers pmNode_735) (s_477 z) pmNode_735 none = some (s_478 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_477
 theorem k_477 (z : Store) (tid : Tid) (h : tid ∉ [1043]) : (s_478 z) tid = (s_477 z) tid := by
   unfold s_478
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_477
 theorem w_477_0 (z : Store) : (s_478 z) 1043 = v_477_0 z := by
   unfold s_478
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_477_0, r_477_0 z, r_477_1 z] <;> rfl
 #a w_477_0
 theorem h_477_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_477_0 z).shape = [1, 2, 16, 16] := by
   unfold v_477_0
   unfold fw_matmul batchedMatmul
   rw [h_475_0 z z_, h_476_0 z z_]
   rfl
 #a h_477_0
 attribute [local irreducible] v_477_0
 attribute [local irreducible] s_478
 theorem r_478_0 (z : Store) : (s_478 z) 740 = (v_474_0 z) := pR (k_477 z) (pR (k_476 z) (pR (k_475 z) (w_474_0 z)))
 #a r_478_0
 theorem r_478_1 (z : Store) : (s_478 z) 1043 = (v_477_0 z) := w_477_0 z
 #a r_478_1
 def v_478_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_474_0 z), (v_477_0 z)]
 theorem g_478 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_500) (s_478 z) pmNode_500 1 3 744 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_500, r_478_0 z, r_478_1 z, h_474_0 z z_, h_477_0 z z_]
 #a g_478
 def s_479 (z : Store) : Store := pL [2, 3] (s_478 z) pmNode_500 1 3
 theorem t_478 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_500) (pmPeers pmNode_500) (s_478 z) pmNode_500 none = some (s_479 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_500) (s_478 z) pmNode_500).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 744 (by decide) (g_478 z z_)]
   rfl
 #a t_478
 theorem k_478 (z : Store) (tid : Tid) (h : tid ∉ [744]) : (s_479 z) tid = (s_478 z) tid := by
   unfold s_479
   dsimp only [pL, pmNode_500, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_478
 theorem w_478_0 (z : Store) : (s_479 z) 744 = v_478_0 z := by
   unfold s_479
   dsimp only [pL, pmNode_500, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_478_0, r_478_0 z, r_478_1 z] <;> rfl
 #a w_478_0
 theorem h_478_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_478_0 z).shape = [1, 4, 16, 8] := by
   unfold v_478_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_474_0 z z_]
 #a h_478_0
 attribute [local irreducible] v_478_0
 attribute [local irreducible] s_479
 theorem r_479_0 (z : Store) : (s_479 z) 744 = (v_478_0 z) := w_478_0 z
 #a r_479_0
 def v_479_0 (z : Store) : Tensor := fw_div ((4 : Nat) : Scalar) (v_478_0 z)
 def s_480 (z : Store) : Store := storeSet (s_479 z) [(745, fw_div ((4 : Nat) : Scalar) ((s_479 z) 744))]
 theorem t_479 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_501) (pmPeers pmNode_501) (s_479 z) pmNode_501 none = some (s_480 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_479
 theorem k_479 (z : Store) (tid : Tid) (h : tid ∉ [745]) : (s_480 z) tid = (s_479 z) tid := by
   unfold s_480
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_479
 theorem w_479_0 (z : Store) : (s_480 z) 745 = v_479_0 z := by
   unfold s_480
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_479_0, r_479_0 z] <;> rfl
 #a w_479_0
 theorem h_479_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_479_0 z).shape = [1, 4, 16, 8] := by
   unfold v_479_0
   exact h_478_0 z z_
 #a h_479_0
 attribute [local irreducible] v_479_0
 attribute [local irreducible] s_480
 theorem r_480_0 (z : Store) : (s_480 z) 740 = (v_474_0 z) := pR (k_479 z) (pR (k_478 z) (r_478_0 z))
 #a r_480_0
 theorem r_480_1 (z : Store) : (s_480 z) 1043 = (v_477_0 z) := pR (k_479 z) (pR (k_478 z) (r_478_1 z))
 #a r_480_1
 def v_480_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_474_0 z), (v_477_0 z)]
 theorem g_480 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_736) (s_480 z) pmNode_736 1 3 1047 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_736, r_480_0 z, r_480_1 z, h_474_0 z z_, h_477_0 z z_]
 #a g_480
 def s_481 (z : Store) : Store := pL [2, 3] (s_480 z) pmNode_736 1 3
 theorem t_480 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_736) (pmPeers pmNode_736) (s_480 z) pmNode_736 none = some (s_481 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_736) (s_480 z) pmNode_736).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 1047 (by decide) (g_480 z z_)]
   rfl
 #a t_480
 theorem k_480 (z : Store) (tid : Tid) (h : tid ∉ [1047]) : (s_481 z) tid = (s_480 z) tid := by
   unfold s_481
   dsimp only [pL, pmNode_736, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_480
 theorem w_480_0 (z : Store) : (s_481 z) 1047 = v_480_0 z := by
   unfold s_481
   dsimp only [pL, pmNode_736, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_480_0, r_480_0 z, r_480_1 z] <;> rfl
 #a w_480_0
 theorem h_480_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_480_0 z).shape = [1, 4, 16, 8] := by
   unfold v_480_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_474_0 z z_]
 #a h_480_0
 attribute [local irreducible] v_480_0
 attribute [local irreducible] s_481
 theorem r_481_0 (z : Store) : (s_481 z) 1047 = (v_480_0 z) := w_480_0 z
 #a r_481_0
 def v_481_0 (z : Store) : Tensor := fw_div ((4 : Nat) : Scalar) (v_480_0 z)
 def s_482 (z : Store) : Store := storeSet (s_481 z) [(1048, fw_div ((4 : Nat) : Scalar) ((s_481 z) 1047))]
 theorem t_481 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_737) (pmPeers pmNode_737) (s_481 z) pmNode_737 none = some (s_482 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_481
 theorem k_481 (z : Store) (tid : Tid) (h : tid ∉ [1048]) : (s_482 z) tid = (s_481 z) tid := by
   unfold s_482
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_481
 theorem w_481_0 (z : Store) : (s_482 z) 1048 = v_481_0 z := by
   unfold s_482
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_481_0, r_481_0 z] <;> rfl
 #a w_481_0
 theorem h_481_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_481_0 z).shape = [1, 4, 16, 8] := by
   unfold v_481_0
   exact h_480_0 z z_
 #a h_481_0
 attribute [local irreducible] v_481_0
 attribute [local irreducible] s_482
 theorem r_482_0 (z : Store) : (s_482 z) 745 = (v_479_0 z) := pR (k_481 z) (pR (k_480 z) (w_479_0 z))
 #a r_482_0
 theorem r_482_1 (z : Store) : (s_482 z) 1048 = (v_481_0 z) := w_481_0 z
 #a r_482_1
 def v_482_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_479_0 z), (v_481_0 z)]
 theorem g_482 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_502) (s_482 z) pmNode_502 3 1 748 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_502, r_482_0 z, r_482_1 z, h_479_0 z z_, h_481_0 z z_]
 #a g_482
 def s_483 (z : Store) : Store := pL [2, 3] (s_482 z) pmNode_502 3 1
 theorem t_482 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_502) (pmPeers pmNode_502) (s_482 z) pmNode_502 none = some (s_483 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_502) (s_482 z) pmNode_502).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 748 (by decide) (g_482 z z_)]
   rfl
 #a t_482
 theorem k_482 (z : Store) (tid : Tid) (h : tid ∉ [748]) : (s_483 z) tid = (s_482 z) tid := by
   unfold s_483
   dsimp only [pL, pmNode_502, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_482
 theorem w_482_0 (z : Store) : (s_483 z) 748 = v_482_0 z := by
   unfold s_483
   dsimp only [pL, pmNode_502, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_482_0, r_482_0 z, r_482_1 z] <;> rfl
 #a w_482_0
 theorem h_482_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_482_0 z).shape = [1, 2, 16, 16] := by
   unfold v_482_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_479_0 z z_]
 #a h_482_0
 attribute [local irreducible] v_482_0
 attribute [local irreducible] s_483
 theorem r_483_0 (z : Store) : (s_483 z) 748 = (v_482_0 z) := w_482_0 z
 #a r_483_0
 def v_483_0 (z : Store) : Tensor := fw_softmax (v_482_0 z)
 def s_484 (z : Store) : Store := storeSet (s_483 z) [(749, fw_softmax ((s_483 z) 748))]
 theorem t_483 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_503) (pmPeers pmNode_503) (s_483 z) pmNode_503 none = some (s_484 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_483
 theorem k_483 (z : Store) (tid : Tid) (h : tid ∉ [749]) : (s_484 z) tid = (s_483 z) tid := by
   unfold s_484
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_483
 theorem w_483_0 (z : Store) : (s_484 z) 749 = v_483_0 z := by
   unfold s_484
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_483_0, r_483_0 z] <;> rfl
 #a w_483_0
 theorem h_483_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_483_0 z).shape = [1, 2, 16, 16] := by
   unfold v_483_0
   unfold fw_softmax softmax
   split <;> exact h_482_0 z z_
 #a h_483_0
 attribute [local irreducible] v_483_0
 attribute [local irreducible] s_484
 theorem n_480_484 (z : Store) (tid : Tid) (h : tid ∉ ([1047, 1048, 748, 749] : List Tid)) : (s_484 z) tid = (s_480 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_480 z) (k_481 z)) (pF _ _ _ _ _ (k_482 z) (k_483 z)) tid h
 #a n_480_484
 theorem n_472_476 (z : Store) (tid : Tid) (h : tid ∉ ([1039, 739, 740, 1041] : List Tid)) : (s_476 z) tid = (s_472 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_472 z) (k_473 z)) (pF _ _ _ _ _ (k_474 z) (k_475 z)) tid h
 #a n_472_476
 theorem n_476_480 (z : Store) (tid : Tid) (h : tid ∉ ([1042, 1043, 744, 745] : List Tid)) : (s_480 z) tid = (s_476 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_476 z) (k_477 z)) (pF _ _ _ _ _ (k_478 z) (k_479 z)) tid h
 #a n_476_480
 theorem n_472_480 (z : Store) (tid : Tid) (h : tid ∉ ([1039, 739, 740, 1041, 1042, 1043, 744, 745] : List Tid)) : (s_480 z) tid = (s_472 z) tid := by
   exact pF _ _ _ _ _ (n_472_476 z) (n_476_480 z) tid h
 #a n_472_480
 record_prefix_opacity v_475_0 s_476 v_476_0 s_477 v_477_0 s_478 v_478_0 s_479 v_479_0 s_480 v_480_0 s_481 v_481_0 s_482 v_482_0 s_483 v_483_0 s_484

 end
 end TrainVerify.Denote.RuntimeWorld
