import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0028
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem n_208_224 (z : Store) (tid : Tid) (h : tid ∉ ([280, 281, 583, 584, 77, 282, 380, 585, 278, 279, 73, 582, 581, 376, 276, 274, 68, 70, 273, 270, 579] : List Tid)) : (s_224 z) tid = (s_208 z) tid := by
   exact pF _ _ _ _ _ (n_208_216 z) (n_216_224 z) tid h
 #a n_208_224
 theorem r_224_0 (z : Store) : (s_224 z) 579 = (v_223_0 z) := w_223_0 z
 #a r_224_0
 theorem r_224_1 (z : Store) : (s_224 z) 575 = (v_202_0 z) := pR (n_208_224 z) (pR (n_204_208 z) (pR (k_203 z) (r_203_0 z)))
 #a r_224_1
 theorem r_224_2 (z : Store) : (s_224 z) 317 = (z 317) := pR (n_208_224 z) (pR (n_204_208 z) (pR (k_203 z) (r_203_1 z)))
 #a r_224_2
 theorem r_224_3 (z : Store) : (s_224 z) 318 = (z 318) := pR (n_208_224 z) (pR (n_204_208 z) (pR (k_203 z) (r_203_2 z)))
 #a r_224_3
 def v_224_0 (z : Store) : Tensor := (bw_layernorm (v_223_0 z) (v_202_0 z) (z 317) (z 318)).1
 def v_224_1 (z : Store) : Tensor := (bw_layernorm (v_223_0 z) (v_202_0 z) (z 317) (z 318)).2.1
 def v_224_2 (z : Store) : Tensor := (bw_layernorm (v_223_0 z) (v_202_0 z) (z 317) (z 318)).2.2
 def s_225 (z : Store) : Store := storeSet (s_224 z) [(577, (bw_layernorm ((s_224 z) 579) ((s_224 z) 575) ((s_224 z) 317) ((s_224 z) 318)).1), (371, (bw_layernorm ((s_224 z) 579) ((s_224 z) 575) ((s_224 z) 317) ((s_224 z) 318)).2.1), (373, (bw_layernorm ((s_224 z) 579) ((s_224 z) 575) ((s_224 z) 317) ((s_224 z) 318)).2.2)]
 theorem t_224 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_347) (pmPeers pmNode_347) (s_224 z) pmNode_347 none = some (s_225 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_224
 theorem k_224 (z : Store) (tid : Tid) (h : tid ∉ [577, 371, 373]) : (s_225 z) tid = (s_224 z) tid := by
   unfold s_225
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_224
 theorem w_224_0 (z : Store) : (s_225 z) 577 = v_224_0 z := by
   unfold s_225
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_224_0, r_224_0 z, r_224_1 z, r_224_2 z, r_224_3 z] <;> rfl
 #a w_224_0
 theorem h_224_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_224_0 z).shape = [1, 8, 64] := by
   unfold v_224_0
   rw [bw_layernorm_dx_shape (v_223_0 z) (v_202_0 z) (z 317) (z 318) 64 [8, 1] (by rw [h_202_0 z z_]; rfl)]
   exact h_202_0 z z_
 #a h_224_0
 attribute [local irreducible] v_224_0
 theorem w_224_1 (z : Store) : (s_225 z) 371 = v_224_1 z := by
   unfold s_225
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_224_1, r_224_0 z, r_224_1 z, r_224_2 z, r_224_3 z] <;> rfl
 #a w_224_1
 theorem h_224_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_224_1 z).shape = [64] := by
   unfold v_224_1
   rw [bw_layernorm_dw_shape (v_223_0 z) (v_202_0 z) (z 317) (z 318) 64 [8, 1] (by rw [h_202_0 z z_]; rfl)]
   exact i_46 z z_
 #a h_224_1
 attribute [local irreducible] v_224_1
 theorem w_224_2 (z : Store) : (s_225 z) 373 = v_224_2 z := by
   unfold s_225
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_224_2, r_224_0 z, r_224_1 z, r_224_2 z, r_224_3 z] <;> rfl
 #a w_224_2
 theorem h_224_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_224_2 z).shape = [64] := by
   unfold v_224_2
   rw [bw_layernorm_db_shape (v_223_0 z) (v_202_0 z) (z 317) (z 318) 64 [8, 1] (by rw [h_202_0 z z_]; rfl)]
   exact i_47 z z_
 #a h_224_2
 attribute [local irreducible] v_224_2
 attribute [local irreducible] s_225
 theorem r_225_0 (z : Store) : (s_225 z) 577 = (v_224_0 z) := w_224_0 z
 #a r_225_0
 theorem r_225_1 (z : Store) : (s_225 z) 574 = (v_201_0 z) := pR (k_224 z) (pR (n_208_224 z) (pR (n_204_208 z) (pR (k_203 z) (pR (k_202 z) (r_202_0 z)))))
 #a r_225_1
 theorem r_225_2 (z : Store) : (s_225 z) 572 = (v_200_0 z) := pR (k_224 z) (pR (n_208_224 z) (pR (n_204_208 z) (pR (k_203 z) (pR (k_202 z) (r_202_1 z)))))
 #a r_225_2
 def v_225_0 (z : Store) : Tensor := (bw_add2 (v_224_0 z) (v_201_0 z) (v_200_0 z)).1
 def v_225_1 (z : Store) : Tensor := (bw_add2 (v_224_0 z) (v_201_0 z) (v_200_0 z)).2
 def s_226 (z : Store) : Store := storeSet (s_225 z) [(576, (bw_add2 ((s_225 z) 577) ((s_225 z) 574) ((s_225 z) 572)).1), (573, (bw_add2 ((s_225 z) 577) ((s_225 z) 574) ((s_225 z) 572)).2)]
 theorem t_225 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_348) (pmPeers pmNode_348) (s_225 z) pmNode_348 none = some (s_226 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_225
 theorem k_225 (z : Store) (tid : Tid) (h : tid ∉ [576, 573]) : (s_226 z) tid = (s_225 z) tid := by
   unfold s_226
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_225
 theorem w_225_0 (z : Store) : (s_226 z) 576 = v_225_0 z := by
   unfold s_226
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_225_0, r_225_0 z, r_225_1 z, r_225_2 z] <;> rfl
 #a w_225_0
 theorem h_225_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_225_0 z).shape = [1, 8, 64] := by
   unfold v_225_0
   exact h_201_0 z z_
 #a h_225_0
 attribute [local irreducible] v_225_0
 theorem w_225_1 (z : Store) : (s_226 z) 573 = v_225_1 z := by
   unfold s_226
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_225_1, r_225_0 z, r_225_1 z, r_225_2 z] <;> rfl
 #a w_225_1
 theorem h_225_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_225_1 z).shape = [1, 8, 64] := by
   unfold v_225_1
   exact h_200_0 z z_
 #a h_225_1
 attribute [local irreducible] v_225_1
 attribute [local irreducible] s_226
 theorem r_226_0 (z : Store) : (s_226 z) 273 = (v_222_0 z) := pR (k_225 z) (pR (k_224 z) (pR (k_223 z) (w_222_0 z)))
 #a r_226_0
 theorem r_226_1 (z : Store) : (s_226 z) 576 = (v_225_0 z) := w_225_0 z
 #a r_226_1
 def v_226_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_222_0 z), (v_225_0 z)]
 theorem g_226 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_113) (s_226 z) pmNode_113 1 2 302 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_113, r_226_0 z, r_226_1 z, h_222_0 z z_, h_225_0 z z_]
 #a g_226
 def s_227 (z : Store) : Store := pL [0, 1] (s_226 z) pmNode_113 1 2
 theorem t_226 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_113) (pmPeers pmNode_113) (s_226 z) pmNode_113 none = some (s_227 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_113) (s_226 z) pmNode_113).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 302 (by decide) (g_226 z z_)]
   rfl
 #a t_226
 theorem k_226 (z : Store) (tid : Tid) (h : tid ∉ [302]) : (s_227 z) tid = (s_226 z) tid := by
   unfold s_227
   dsimp only [pL, pmNode_113, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_226
 theorem w_226_0 (z : Store) : (s_227 z) 302 = v_226_0 z := by
   unfold s_227
   dsimp only [pL, pmNode_113, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_226_0, r_226_0 z, r_226_1 z] <;> rfl
 #a w_226_0
 theorem h_226_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_226_0 z).shape = [1, 16, 32] := by
   unfold v_226_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_222_0 z z_]
 #a h_226_0
 attribute [local irreducible] v_226_0
 attribute [local irreducible] s_227
 theorem r_227_0 (z : Store) : (s_227 z) 270 = (v_222_1 z) := pR (k_226 z) (pR (k_225 z) (pR (k_224 z) (pR (k_223 z) (w_222_1 z))))
 #a r_227_0
 theorem r_227_1 (z : Store) : (s_227 z) 266 = (v_193_0 z) := pR (k_226 z) (pR (k_225 z) (pR (k_224 z) (pR (n_208_224 z) (pR (n_200_208 z) (pR (n_196_200 z) (pR (k_195 z) (pR (k_194 z) (r_194_0 z))))))))
 #a r_227_1
 theorem r_227_2 (z : Store) : (s_227 z) 13 = (z 13) := pR (k_226 z) (pR (k_225 z) (pR (k_224 z) (pR (n_208_224 z) (pR (n_200_208 z) (pR (n_196_200 z) (pR (k_195 z) (pR (k_194 z) (r_194_1 z))))))))
 #a r_227_2
 def v_227_0 (z : Store) : Tensor := (bw_linear (v_222_1 z) (v_193_0 z) (z 13)).1
 def v_227_1 (z : Store) : Tensor := (bw_linear (v_222_1 z) (v_193_0 z) (z 13)).2
 def s_228 (z : Store) : Store := storeSet (s_227 z) [(268, (bw_linear ((s_227 z) 270) ((s_227 z) 266) ((s_227 z) 13)).1), (66, (bw_linear ((s_227 z) 270) ((s_227 z) 266) ((s_227 z) 13)).2)]
 theorem t_227 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_114) (pmPeers pmNode_114) (s_227 z) pmNode_114 none = some (s_228 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_227
 theorem k_227 (z : Store) (tid : Tid) (h : tid ∉ [268, 66]) : (s_228 z) tid = (s_227 z) tid := by
   unfold s_228
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_227
 theorem w_227_0 (z : Store) : (s_228 z) 268 = v_227_0 z := by
   unfold s_228
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_227_0, r_227_0 z, r_227_1 z, r_227_2 z] <;> rfl
 #a w_227_0
 theorem h_227_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_227_0 z).shape = [1, 8, 256] := by
   unfold v_227_0
   exact bw_linear_3d_fst_shape 1 8 64 256 (v_222_1 z) (v_193_0 z) (z 13) (h_222_1 z z_) (h_193_0 z z_) (i_42 z z_)
 #a h_227_0
 attribute [local irreducible] v_227_0
 theorem w_227_1 (z : Store) : (s_228 z) 66 = v_227_1 z := by
   unfold s_228
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_227_1, r_227_0 z, r_227_1 z, r_227_2 z] <;> rfl
 #a w_227_1
 theorem h_227_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_227_1 z).shape = [64, 256] := by
   unfold v_227_1
   exact bw_linear_3d_snd_shape 1 8 64 256 (v_222_1 z) (v_193_0 z) (z 13) (h_222_1 z z_) (h_193_0 z z_) (i_42 z z_)
 #a h_227_1
 attribute [local irreducible] v_227_1
 attribute [local irreducible] s_228
 theorem n_224_228 (z : Store) (tid : Tid) (h : tid ∉ ([577, 371, 373, 576, 573, 302, 268, 66] : List Tid)) : (s_228 z) tid = (s_224 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_224 z) (k_225 z)) (pF _ _ _ _ _ (k_226 z) (k_227 z)) tid h
 #a n_224_228
 theorem r_228_0 (z : Store) : (s_228 z) 268 = (v_227_0 z) := w_227_0 z
 #a r_228_0
 theorem r_228_1 (z : Store) : (s_228 z) 265 = (v_192_0 z) := pR (n_224_228 z) (pR (n_208_224 z) (pR (n_200_208 z) (pR (n_196_200 z) (pR (k_195 z) (pR (k_194 z) (pR (k_193 z) (r_193_0 z)))))))
 #a r_228_1
 def v_228_0 (z : Store) : Tensor := bw_gelu (v_227_0 z) (v_192_0 z)
 def s_229 (z : Store) : Store := storeSet (s_228 z) [(267, bw_gelu ((s_228 z) 268) ((s_228 z) 265))]
 theorem t_228 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_115) (pmPeers pmNode_115) (s_228 z) pmNode_115 none = some (s_229 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_228
 theorem k_228 (z : Store) (tid : Tid) (h : tid ∉ [267]) : (s_229 z) tid = (s_228 z) tid := by
   unfold s_229
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_228
 theorem w_228_0 (z : Store) : (s_229 z) 267 = v_228_0 z := by
   unfold s_229
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_228_0, r_228_0 z, r_228_1 z] <;> rfl
 #a w_228_0
 theorem h_228_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_228_0 z).shape = [1, 8, 256] := by
   unfold v_228_0
   exact h_192_0 z z_
 #a h_228_0
 attribute [local irreducible] v_228_0
 attribute [local irreducible] s_229
 theorem r_229_0 (z : Store) : (s_229 z) 273 = (v_222_0 z) := pR (k_228 z) (pR (k_227 z) (pR (k_226 z) (r_226_0 z)))
 #a r_229_0
 theorem r_229_1 (z : Store) : (s_229 z) 576 = (v_225_0 z) := pR (k_228 z) (pR (k_227 z) (pR (k_226 z) (r_226_1 z)))
 #a r_229_1
 def v_229_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_222_0 z), (v_225_0 z)]
 theorem g_229 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_349) (s_229 z) pmNode_349 1 2 605 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_349, r_229_0 z, r_229_1 z, h_222_0 z z_, h_225_0 z z_]
 #a g_229
 def s_230 (z : Store) : Store := pL [0, 1] (s_229 z) pmNode_349 1 2
 theorem t_229 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_349) (pmPeers pmNode_349) (s_229 z) pmNode_349 none = some (s_230 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_349) (s_229 z) pmNode_349).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 605 (by decide) (g_229 z z_)]
   rfl
 #a t_229
 theorem k_229 (z : Store) (tid : Tid) (h : tid ∉ [605]) : (s_230 z) tid = (s_229 z) tid := by
   unfold s_230
   dsimp only [pL, pmNode_349, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_229
 theorem w_229_0 (z : Store) : (s_230 z) 605 = v_229_0 z := by
   unfold s_230
   dsimp only [pL, pmNode_349, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_229_0, r_229_0 z, r_229_1 z] <;> rfl
 #a w_229_0
 theorem h_229_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_229_0 z).shape = [1, 16, 32] := by
   unfold v_229_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_222_0 z z_]
 #a h_229_0
 attribute [local irreducible] v_229_0
 attribute [local irreducible] s_230
 theorem r_230_0 (z : Store) : (s_230 z) 573 = (v_225_1 z) := pR (k_229 z) (pR (k_228 z) (pR (k_227 z) (pR (k_226 z) (w_225_1 z))))
 #a r_230_0
 theorem r_230_1 (z : Store) : (s_230 z) 569 = (v_199_0 z) := pR (k_229 z) (pR (k_228 z) (pR (n_224_228 z) (pR (n_208_224 z) (pR (n_200_208 z) (r_200_0 z)))))
 #a r_230_1
 theorem r_230_2 (z : Store) : (s_230 z) 316 = (z 316) := pR (k_229 z) (pR (k_228 z) (pR (n_224_228 z) (pR (n_208_224 z) (pR (n_200_208 z) (r_200_1 z)))))
 #a r_230_2
 def v_230_0 (z : Store) : Tensor := (bw_linear (v_225_1 z) (v_199_0 z) (z 316)).1
 def v_230_1 (z : Store) : Tensor := (bw_linear (v_225_1 z) (v_199_0 z) (z 316)).2
 def s_231 (z : Store) : Store := storeSet (s_230 z) [(571, (bw_linear ((s_230 z) 573) ((s_230 z) 569) ((s_230 z) 316)).1), (369, (bw_linear ((s_230 z) 573) ((s_230 z) 569) ((s_230 z) 316)).2)]
 theorem t_230 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_350) (pmPeers pmNode_350) (s_230 z) pmNode_350 none = some (s_231 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_230
 theorem k_230 (z : Store) (tid : Tid) (h : tid ∉ [571, 369]) : (s_231 z) tid = (s_230 z) tid := by
   unfold s_231
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_230
 theorem w_230_0 (z : Store) : (s_231 z) 571 = v_230_0 z := by
   unfold s_231
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_230_0, r_230_0 z, r_230_1 z, r_230_2 z] <;> rfl
 #a w_230_0
 theorem h_230_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_230_0 z).shape = [1, 8, 256] := by
   unfold v_230_0
   exact bw_linear_3d_fst_shape 1 8 64 256 (v_225_1 z) (v_199_0 z) (z 316) (h_225_1 z z_) (h_199_0 z z_) (i_45 z z_)
 #a h_230_0
 attribute [local irreducible] v_230_0
 theorem w_230_1 (z : Store) : (s_231 z) 369 = v_230_1 z := by
   unfold s_231
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_230_1, r_230_0 z, r_230_1 z, r_230_2 z] <;> rfl
 #a w_230_1
 theorem h_230_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_230_1 z).shape = [64, 256] := by
   unfold v_230_1
   exact bw_linear_3d_snd_shape 1 8 64 256 (v_225_1 z) (v_199_0 z) (z 316) (h_225_1 z z_) (h_199_0 z z_) (i_45 z z_)
 #a h_230_1
 attribute [local irreducible] v_230_1
 attribute [local irreducible] s_231
 record_prefix_opacity v_224_0 v_224_1 v_224_2 s_225 v_225_0 v_225_1 s_226 v_226_0 s_227 v_227_0 v_227_1 s_228 v_228_0 s_229 v_229_0 s_230 v_230_0 v_230_1 s_231

 end
 end TrainVerify.Denote.RuntimeWorld
