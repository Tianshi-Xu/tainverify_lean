import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0120
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_937_0 (z : Store) : (s_937 z) 331 = (v_401_1 z) := pR (k_936 z) (pR (n_928_936 z) (pR (n_912_928 z) (r_912_0 z)))
 #a r_937_0
 theorem r_937_1 (z : Store) : (s_937 z) 937 = (v_823_1 z) := pR (k_936 z) (pR (n_928_936 z) (pR (n_912_928 z) (r_912_1 z)))
 #a r_937_1
 def v_937_0 (z : Store) : Tensor := cross_dp_wred [(v_401_1 z), (v_823_1 z)]
 theorem g_937 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_937) (s_937 z) pmNode_937 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_937, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_937_1 z, r_937_0 z]
     exact (h_823_1 z z_).trans (h_401_1 z z_).symm
 #a g_937
 def s_938 (z : Store) : Store := storeSet (s_937 z) [(938, cross_dp_wred [((s_937 z) 331), ((s_937 z) 937)])]
 theorem t_937 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_937) (pmPeers pmNode_937) (s_937 z) pmNode_937 none = some (s_938 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_937) (s_937 z) pmNode_937 = _
   rw [wredStep, if_pos ⟨by decide, g_937 z z_⟩]
   rfl
 #a t_937
 theorem k_937 (z : Store) (tid : Tid) (h : tid ∉ [938]) : (s_938 z) tid = (s_937 z) tid := by
   unfold s_938
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_937
 theorem w_937_0 (z : Store) : (s_938 z) 938 = v_937_0 z := by
   unfold s_938
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_937_0, r_937_0 z, r_937_1 z] <;> rfl
 #a w_937_0
 theorem h_937_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_937_0 z).shape = [32, 64] := by
   unfold v_937_0
   rw [tensorSum_shape]
   exact h_401_1 z z_
 #a h_937_0
 attribute [local irreducible] v_937_0
 attribute [local irreducible] s_938
 theorem r_938_0 (z : Store) : (s_938 z) 367 = (v_235_1 z) := pR (k_937 z) (pR (k_936 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (n_916_920 z) (pR (k_915 z) (pR (k_914 z) (pR (k_913 z) (r_913_0 z))))))))
 #a r_938_0
 theorem r_938_1 (z : Store) : (s_938 z) 973 = (v_657_1 z) := pR (k_937 z) (pR (k_936 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (n_916_920 z) (pR (k_915 z) (pR (k_914 z) (pR (k_913 z) (r_913_1 z))))))))
 #a r_938_1
 def v_938_0 (z : Store) : Tensor := cross_dp_wred [(v_235_1 z), (v_657_1 z)]
 theorem g_938 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_938) (s_938 z) pmNode_938 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_938, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_938_1 z, r_938_0 z]
     exact (h_657_1 z z_).trans (h_235_1 z z_).symm
 #a g_938
 def s_939 (z : Store) : Store := storeSet (s_938 z) [(974, cross_dp_wred [((s_938 z) 367), ((s_938 z) 973)])]
 theorem t_938 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_938) (pmPeers pmNode_938) (s_938 z) pmNode_938 none = some (s_939 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_938) (s_938 z) pmNode_938 = _
   rw [wredStep, if_pos ⟨by decide, g_938 z z_⟩]
   rfl
 #a t_938
 theorem k_938 (z : Store) (tid : Tid) (h : tid ∉ [974]) : (s_939 z) tid = (s_938 z) tid := by
   unfold s_939
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_938
 theorem w_938_0 (z : Store) : (s_939 z) 974 = v_938_0 z := by
   unfold s_939
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_938_0, r_938_0 z, r_938_1 z] <;> rfl
 #a w_938_0
 theorem h_938_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_938_0 z).shape = [256, 32] := by
   unfold v_938_0
   rw [tensorSum_shape]
   exact h_235_1 z z_
 #a h_938_0
 attribute [local irreducible] v_938_0
 attribute [local irreducible] s_939
 theorem r_939_0 (z : Store) : (s_939 z) 334 = (v_397_1 z) := pR (k_938 z) (pR (k_937 z) (pR (k_936 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (n_916_920 z) (pR (k_915 z) (pR (k_914 z) (r_914_0 z))))))))
 #a r_939_0
 theorem r_939_1 (z : Store) : (s_939 z) 940 = (v_819_1 z) := pR (k_938 z) (pR (k_937 z) (pR (k_936 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (n_916_920 z) (pR (k_915 z) (pR (k_914 z) (r_914_1 z))))))))
 #a r_939_1
 def v_939_0 (z : Store) : Tensor := cross_dp_wred [(v_397_1 z), (v_819_1 z)]
 theorem g_939 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_939) (s_939 z) pmNode_939 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_939, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_939_1 z, r_939_0 z]
     exact (h_819_1 z z_).trans (h_397_1 z z_).symm
 #a g_939
 def s_940 (z : Store) : Store := storeSet (s_939 z) [(941, cross_dp_wred [((s_939 z) 334), ((s_939 z) 940)])]
 theorem t_939 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_939) (pmPeers pmNode_939) (s_939 z) pmNode_939 none = some (s_940 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_939) (s_939 z) pmNode_939 = _
   rw [wredStep, if_pos ⟨by decide, g_939 z z_⟩]
   rfl
 #a t_939
 theorem k_939 (z : Store) (tid : Tid) (h : tid ∉ [941]) : (s_940 z) tid = (s_939 z) tid := by
   unfold s_940
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_939
 theorem w_939_0 (z : Store) : (s_940 z) 941 = v_939_0 z := by
   unfold s_940
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_939_0, r_939_0 z, r_939_1 z] <;> rfl
 #a w_939_0
 theorem h_939_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_939_0 z).shape = [32, 64] := by
   unfold v_939_0
   rw [tensorSum_shape]
   exact h_397_1 z z_
 #a h_939_0
 attribute [local irreducible] v_939_0
 attribute [local irreducible] s_940
 theorem n_936_940 (z : Store) (tid : Tid) (h : tid ∉ ([967, 938, 974, 941] : List Tid)) : (s_940 z) tid = (s_936 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_936 z) (k_937 z)) (pF _ _ _ _ _ (k_938 z) (k_939 z)) tid h
 #a n_936_940
 theorem r_940_0 (z : Store) : (s_940 z) 376 = (v_219_1 z) := pR (n_936_940 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (n_916_920 z) (pR (k_915 z) (r_915_0 z)))))
 #a r_940_0
 theorem r_940_1 (z : Store) : (s_940 z) 982 = (v_641_1 z) := pR (n_936_940 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (n_916_920 z) (pR (k_915 z) (r_915_1 z)))))
 #a r_940_1
 def v_940_0 (z : Store) : Tensor := cross_dp_wred [(v_219_1 z), (v_641_1 z)]
 theorem g_940 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_940) (s_940 z) pmNode_940 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_940, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_940_1 z, r_940_0 z]
     exact (h_641_1 z z_).trans (h_219_1 z z_).symm
 #a g_940
 def s_941 (z : Store) : Store := storeSet (s_940 z) [(983, cross_dp_wred [((s_940 z) 376), ((s_940 z) 982)])]
 theorem t_940 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_940) (pmPeers pmNode_940) (s_940 z) pmNode_940 none = some (s_941 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_940) (s_940 z) pmNode_940 = _
   rw [wredStep, if_pos ⟨by decide, g_940 z z_⟩]
   rfl
 #a t_940
 theorem k_940 (z : Store) (tid : Tid) (h : tid ∉ [983]) : (s_941 z) tid = (s_940 z) tid := by
   unfold s_941
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_940
 theorem w_940_0 (z : Store) : (s_941 z) 983 = v_940_0 z := by
   unfold s_941
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_940_0, r_940_0 z, r_940_1 z] <;> rfl
 #a w_940_0
 theorem h_940_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_940_0 z).shape = [128, 64] := by
   unfold v_940_0
   rw [tensorSum_shape]
   exact h_219_1 z z_
 #a h_940_0
 attribute [local irreducible] v_940_0
 attribute [local irreducible] s_941
 theorem r_941_0 (z : Store) : (s_941 z) 351 = (v_313_1 z) := pR (k_940 z) (pR (n_936_940 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (n_916_920 z) (r_916_0 z)))))
 #a r_941_0
 theorem r_941_1 (z : Store) : (s_941 z) 957 = (v_735_1 z) := pR (k_940 z) (pR (n_936_940 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (n_916_920 z) (r_916_1 z)))))
 #a r_941_1
 def v_941_0 (z : Store) : Tensor := cross_dp_wred [(v_313_1 z), (v_735_1 z)]
 theorem g_941 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_941) (s_941 z) pmNode_941 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_941, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_941_1 z, r_941_0 z]
     exact (h_735_1 z z_).trans (h_313_1 z z_).symm
 #a g_941
 def s_942 (z : Store) : Store := storeSet (s_941 z) [(958, cross_dp_wred [((s_941 z) 351), ((s_941 z) 957)])]
 theorem t_941 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_941) (pmPeers pmNode_941) (s_941 z) pmNode_941 none = some (s_942 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_941) (s_941 z) pmNode_941 = _
   rw [wredStep, if_pos ⟨by decide, g_941 z z_⟩]
   rfl
 #a t_941
 theorem k_941 (z : Store) (tid : Tid) (h : tid ∉ [958]) : (s_942 z) tid = (s_941 z) tid := by
   unfold s_942
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_941
 theorem w_941_0 (z : Store) : (s_942 z) 958 = v_941_0 z := by
   unfold s_942
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_941_0, r_941_0 z, r_941_1 z] <;> rfl
 #a w_941_0
 theorem h_941_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_941_0 z).shape = [32, 64] := by
   unfold v_941_0
   rw [tensorSum_shape]
   exact h_313_1 z z_
 #a h_941_0
 attribute [local irreducible] v_941_0
 attribute [local irreducible] s_942
 theorem r_942_0 (z : Store) : (s_942 z) 354 = (v_309_1 z) := pR (k_941 z) (pR (k_940 z) (pR (n_936_940 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (k_919 z) (pR (k_918 z) (pR (k_917 z) (r_917_0 z))))))))
 #a r_942_0
 theorem r_942_1 (z : Store) : (s_942 z) 960 = (v_731_1 z) := pR (k_941 z) (pR (k_940 z) (pR (n_936_940 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (k_919 z) (pR (k_918 z) (pR (k_917 z) (r_917_1 z))))))))
 #a r_942_1
 def v_942_0 (z : Store) : Tensor := cross_dp_wred [(v_309_1 z), (v_731_1 z)]
 theorem g_942 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_942) (s_942 z) pmNode_942 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_942, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_942_1 z, r_942_0 z]
     exact (h_731_1 z z_).trans (h_309_1 z z_).symm
 #a g_942
 def s_943 (z : Store) : Store := storeSet (s_942 z) [(961, cross_dp_wred [((s_942 z) 354), ((s_942 z) 960)])]
 theorem t_942 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_942) (pmPeers pmNode_942) (s_942 z) pmNode_942 none = some (s_943 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_942) (s_942 z) pmNode_942 = _
   rw [wredStep, if_pos ⟨by decide, g_942 z z_⟩]
   rfl
 #a t_942
 theorem k_942 (z : Store) (tid : Tid) (h : tid ∉ [961]) : (s_943 z) tid = (s_942 z) tid := by
   unfold s_943
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_942
 theorem w_942_0 (z : Store) : (s_943 z) 961 = v_942_0 z := by
   unfold s_943
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_942_0, r_942_0 z, r_942_1 z] <;> rfl
 #a w_942_0
 theorem h_942_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_942_0 z).shape = [64, 32] := by
   unfold v_942_0
   rw [tensorSum_shape]
   exact h_309_1 z z_
 #a h_942_0
 attribute [local irreducible] v_942_0
 attribute [local irreducible] s_943
 theorem r_943_0 (z : Store) : (s_943 z) 357 = (v_305_1 z) := pR (k_942 z) (pR (k_941 z) (pR (k_940 z) (pR (n_936_940 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (k_919 z) (pR (k_918 z) (r_918_0 z))))))))
 #a r_943_0
 theorem r_943_1 (z : Store) : (s_943 z) 963 = (v_727_1 z) := pR (k_942 z) (pR (k_941 z) (pR (k_940 z) (pR (n_936_940 z) (pR (n_928_936 z) (pR (n_920_928 z) (pR (k_919 z) (pR (k_918 z) (r_918_1 z))))))))
 #a r_943_1
 def v_943_0 (z : Store) : Tensor := cross_dp_wred [(v_305_1 z), (v_727_1 z)]
 theorem g_943 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_943) (s_943 z) pmNode_943 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_943, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_943_1 z, r_943_0 z]
     exact (h_727_1 z z_).trans (h_305_1 z z_).symm
 #a g_943
 def s_944 (z : Store) : Store := storeSet (s_943 z) [(964, cross_dp_wred [((s_943 z) 357), ((s_943 z) 963)])]
 theorem t_943 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_943) (pmPeers pmNode_943) (s_943 z) pmNode_943 none = some (s_944 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_943) (s_943 z) pmNode_943 = _
   rw [wredStep, if_pos ⟨by decide, g_943 z z_⟩]
   rfl
 #a t_943
 theorem k_943 (z : Store) (tid : Tid) (h : tid ∉ [964]) : (s_944 z) tid = (s_943 z) tid := by
   unfold s_944
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_943
 theorem w_943_0 (z : Store) : (s_944 z) 964 = v_943_0 z := by
   unfold s_944
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_943_0, r_943_0 z, r_943_1 z] <;> rfl
 #a w_943_0
 theorem h_943_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_943_0 z).shape = [64, 32] := by
   unfold v_943_0
   rw [tensorSum_shape]
   exact h_305_1 z z_
 #a h_943_0
 attribute [local irreducible] v_943_0
 attribute [local irreducible] s_944
 def q_0_14 : List InputRequest := [(pmNode_0, some pmNode_0_feed), (pmNode_1, none), (pmNode_2, none), (pmNode_3, none), (pmNode_236, some pmNode_236_feed), (pmNode_237, none), (pmNode_238, none), (pmNode_239, none), (pmNode_4, none), (pmNode_5, none), (pmNode_6, none), (pmNode_240, none), (pmNode_241, none), (pmNode_242, none)]
 theorem u_0_14 (z : Store) (z_ : pmSeededPrefixInitShapes z) : runUsing (fun row s => stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) q_0_14 (some (s_0 z)) = some (s_14 z) := by
   simp only [q_0_14, runUsing, List.foldl_cons, List.foldl_nil, Option.bind_some, t_0 z, t_1 z, t_2 z, t_3 z, t_4 z, t_5 z, t_6 z, t_7 z, t_8 z z_, t_9 z, t_10 z, t_11 z z_, t_12 z, t_13 z]
 #a u_0_14
 def q_14_29 : List InputRequest := [(pmNode_7, none), (pmNode_8, none), (pmNode_9, none), (pmNode_10, none), (pmNode_243, none), (pmNode_244, none), (pmNode_245, none), (pmNode_11, none), (pmNode_12, none), (pmNode_13, none), (pmNode_14, none), (pmNode_15, none), (pmNode_246, none), (pmNode_247, none), (pmNode_248, none)]
 theorem u_14_29 (z : Store) (z_ : pmSeededPrefixInitShapes z) : runUsing (fun row s => stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) q_14_29 (some (s_14 z)) = some (s_29 z) := by
   simp only [q_14_29, runUsing, List.foldl_cons, List.foldl_nil, Option.bind_some, t_14 z z_, t_15 z, t_16 z, t_17 z, t_18 z z_, t_19 z, t_20 z, t_21 z, t_22 z, t_23 z, t_24 z, t_25 z, t_26 z, t_27 z, t_28 z]
 #a u_14_29
 def q_0_29 : List InputRequest := q_0_14 ++ q_14_29
 theorem u_0_29 (z : Store) (z_ : pmSeededPrefixInitShapes z) : runUsing (fun row s => stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) q_0_29 (some (s_0 z)) = some (s_29 z) := by
   unfold q_0_29
   rw [SourceScopedPrefix.runUsing_append, u_0_14 z z_]
   exact u_14_29 z z_
 #a u_0_29
 def q_29_44 : List InputRequest := [(pmNode_249, none), (pmNode_250, none), (pmNode_251, none), (pmNode_16, none), (pmNode_17, none), (pmNode_18, none), (pmNode_252, none), (pmNode_253, none), (pmNode_254, none), (pmNode_19, none), (pmNode_20, none), (pmNode_21, none), (pmNode_22, none), (pmNode_23, none), (pmNode_24, none)]
 theorem u_29_44 (z : Store) (z_ : pmSeededPrefixInitShapes z) : runUsing (fun row s => stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) q_29_44 (some (s_29 z)) = some (s_44 z) := by
   simp only [q_29_44, runUsing, List.foldl_cons, List.foldl_nil, Option.bind_some, t_29 z, t_30 z, t_31 z, t_32 z z_, t_33 z, t_34 z, t_35 z z_, t_36 z, t_37 z, t_38 z z_, t_39 z, t_40 z z_, t_41 z, t_42 z, t_43 z]
 #a u_29_44
 def q_44_59 : List InputRequest := [(pmNode_25, none), (pmNode_255, none), (pmNode_256, none), (pmNode_257, none), (pmNode_258, none), (pmNode_259, none), (pmNode_260, none), (pmNode_26, none), (pmNode_27, none), (pmNode_261, none), (pmNode_262, none), (pmNode_263, none), (pmNode_28, none), (pmNode_29, none), (pmNode_264, none)]
 theorem u_44_59 (z : Store) (z_ : pmSeededPrefixInitShapes z) : runUsing (fun row s => stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) q_44_59 (some (s_44 z)) = some (s_59 z) := by
   simp only [q_44_59, runUsing, List.foldl_cons, List.foldl_nil, Option.bind_some, t_44 z z_, t_45 z z_, t_46 z, t_47 z z_, t_48 z, t_49 z, t_50 z, t_51 z z_, t_52 z, t_53 z z_, t_54 z z_, t_55 z, t_56 z z_, t_57 z, t_58 z z_]
 #a u_44_59
 def q_29_59 : List InputRequest := q_29_44 ++ q_44_59
 theorem u_29_59 (z : Store) (z_ : pmSeededPrefixInitShapes z) : runUsing (fun row s => stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) q_29_59 (some (s_29 z)) = some (s_59 z) := by
   unfold q_29_59
   rw [SourceScopedPrefix.runUsing_append, u_29_44 z z_]
   exact u_44_59 z z_
 #a u_29_59
 def q_0_59 : List InputRequest := q_0_29 ++ q_29_59
 theorem u_0_59 (z : Store) (z_ : pmSeededPrefixInitShapes z) : runUsing (fun row s => stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) q_0_59 (some (s_0 z)) = some (s_59 z) := by
   unfold q_0_59
   rw [SourceScopedPrefix.runUsing_append, u_0_29 z z_]
   exact u_29_59 z z_
 #a u_0_59
 def q_59_73 : List InputRequest := [(pmNode_265, none), (pmNode_30, none), (pmNode_31, none), (pmNode_32, none), (pmNode_266, none), (pmNode_267, none), (pmNode_33, none), (pmNode_34, none), (pmNode_35, none), (pmNode_36, none), (pmNode_268, none), (pmNode_269, none), (pmNode_270, none), (pmNode_271, none)]
 theorem u_59_73 (z : Store) (z_ : pmSeededPrefixInitShapes z) : runUsing (fun row s => stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) q_59_73 (some (s_59 z)) = some (s_73 z) := by
   simp only [q_59_73, runUsing, List.foldl_cons, List.foldl_nil, Option.bind_some, t_59 z, t_60 z z_, t_61 z, t_62 z, t_63 z z_, t_64 z, t_65 z z_, t_66 z, t_67 z, t_68 z, t_69 z, t_70 z z_, t_71 z, t_72 z]
 #a u_59_73
 record_prefix_opacity v_937_0 s_938 v_938_0 s_939 v_939_0 s_940 v_940_0 s_941 v_941_0 s_942 v_942_0 s_943 v_943_0 s_944

 end
 end TrainVerify.Denote.RuntimeWorld
