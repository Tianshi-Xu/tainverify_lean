import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0100
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_794_0 (z : Store) : (s_794 z) 742 = (v_791_1 z) := pR (k_793 z) (pR (k_792 z) (w_791_1 z))
 #a r_794_0
 theorem r_794_1 (z : Store) : (s_794 z) 1045 = (v_793_1 z) := w_793_1 z
 #a r_794_1
 def v_794_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_791_1 z), (v_793_1 z)]
 theorem g_794 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_658) (s_794 z) pmNode_658 1 2 737 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_658, r_794_0 z, r_794_1 z, h_791_1 z z_, h_793_1 z z_]
 #a g_794
 def s_795 (z : Store) : Store := pL [2, 3] (s_794 z) pmNode_658 1 2
 theorem t_794 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_658) (pmPeers pmNode_658) (s_794 z) pmNode_658 none = some (s_795 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_658) (s_794 z) pmNode_658).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 737 (by decide) (g_794 z z_)]
   rfl
 #a t_794
 theorem k_794 (z : Store) (tid : Tid) (h : tid ∉ [737]) : (s_795 z) tid = (s_794 z) tid := by
   unfold s_795
   dsimp only [pL, pmNode_658, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_794
 theorem w_794_0 (z : Store) : (s_795 z) 737 = v_794_0 z := by
   unfold s_795
   dsimp only [pL, pmNode_658, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_794_0, r_794_0 z, r_794_1 z] <;> rfl
 #a w_794_0
 theorem h_794_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_794_0 z).shape = [1, 4, 8, 16] := by
   unfold v_794_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_791_1 z z_]
 #a h_794_0
 attribute [local irreducible] v_794_0
 attribute [local irreducible] s_795
 theorem r_795_0 (z : Store) : (s_795 z) 741 = (v_791_0 z) := pR (k_794 z) (pR (k_793 z) (pR (k_792 z) (w_791_0 z)))
 #a r_795_0
 theorem r_795_1 (z : Store) : (s_795 z) 1044 = (v_793_0 z) := pR (k_794 z) (w_793_0 z)
 #a r_795_1
 def v_795_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_791_0 z), (v_793_0 z)]
 theorem g_795 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_659) (s_795 z) pmNode_659 1 3 723 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_659, r_795_0 z, r_795_1 z, h_791_0 z z_, h_793_0 z z_]
 #a g_795
 def s_796 (z : Store) : Store := pL [2, 3] (s_795 z) pmNode_659 1 3
 theorem t_795 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_659) (pmPeers pmNode_659) (s_795 z) pmNode_659 none = some (s_796 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_659) (s_795 z) pmNode_659).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 723 (by decide) (g_795 z z_)]
   rfl
 #a t_795
 theorem k_795 (z : Store) (tid : Tid) (h : tid ∉ [723]) : (s_796 z) tid = (s_795 z) tid := by
   unfold s_796
   dsimp only [pL, pmNode_659, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_795
 theorem w_795_0 (z : Store) : (s_796 z) 723 = v_795_0 z := by
   unfold s_796
   dsimp only [pL, pmNode_659, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_795_0, r_795_0 z, r_795_1 z] <;> rfl
 #a w_795_0
 theorem h_795_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_795_0 z).shape = [1, 4, 16, 8] := by
   unfold v_795_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_791_0 z z_]
 #a h_795_0
 attribute [local irreducible] v_795_0
 attribute [local irreducible] s_796
 theorem n_792_796 (z : Store) (tid : Tid) (h : tid ∉ ([1046, 1044, 1045, 737, 723] : List Tid)) : (s_796 z) tid = (s_792 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_792 z) (k_793 z)) (pF _ _ _ _ _ (k_794 z) (k_795 z)) tid h
 #a n_792_796
 theorem r_796_0 (z : Store) : (s_796 z) 737 = (v_794_0 z) := pR (k_795 z) (w_794_0 z)
 #a r_796_0
 theorem r_796_1 (z : Store) : (s_796 z) 727 = (v_461_0 z) := pR (n_792_796 z) (pR (n_784_792 z) (pR (n_768_784 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_472_480 z) (pR (n_468_472 z) (pR (k_467 z) (pR (k_466 z) (pR (k_465 z) (r_465_0 z))))))))))
 #a r_796_1
 def v_796_0 (z : Store) : Tensor := transposeAxes 2 3 (v_794_0 z)
 def s_797 (z : Store) : Store := storeSet (s_796 z) [(729, transposeAxes 2 3 ((s_796 z) 737))]
 theorem t_796 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_660) (pmPeers pmNode_660) (s_796 z) pmNode_660 none = some (s_797 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_796
 theorem k_796 (z : Store) (tid : Tid) (h : tid ∉ [729]) : (s_797 z) tid = (s_796 z) tid := by
   unfold s_797
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_796
 theorem w_796_0 (z : Store) : (s_797 z) 729 = v_796_0 z := by
   unfold s_797
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_796_0, r_796_0 z, r_796_1 z] <;> rfl
 #a w_796_0
 theorem h_796_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_796_0 z).shape = [1, 4, 16, 8] := by
   unfold v_796_0
   change listSwapAt _ _ _ = _
   rw [h_794_0 z z_]
   rfl
 #a h_796_0
 attribute [local irreducible] v_796_0
 attribute [local irreducible] s_797
 theorem r_797_0 (z : Store) : (s_797 z) 735 = (v_781_0 z) := pR (k_796 z) (pR (n_792_796 z) (pR (n_784_792 z) (pR (k_783 z) (pR (k_782 z) (w_781_0 z)))))
 #a r_797_0
 theorem r_797_1 (z : Store) : (s_797 z) 731 = (v_463_0 z) := pR (k_796 z) (pR (n_792_796 z) (pR (n_784_792 z) (pR (n_768_784 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (r_464_0 z)))))))
 #a r_797_1
 def v_797_0 (z : Store) : Tensor := transposeAxes 1 2 (v_781_0 z)
 def s_798 (z : Store) : Store := storeSet (s_797 z) [(733, transposeAxes 1 2 ((s_797 z) 735))]
 theorem t_797 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_661) (pmPeers pmNode_661) (s_797 z) pmNode_661 none = some (s_798 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_797
 theorem k_797 (z : Store) (tid : Tid) (h : tid ∉ [733]) : (s_798 z) tid = (s_797 z) tid := by
   unfold s_798
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_797
 theorem w_797_0 (z : Store) : (s_798 z) 733 = v_797_0 z := by
   unfold s_798
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_797_0, r_797_0 z, r_797_1 z] <;> rfl
 #a w_797_0
 theorem h_797_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_797_0 z).shape = [1, 8, 4, 16] := by
   unfold v_797_0
   change listSwapAt _ _ _ = _
   rw [h_781_0 z z_]
   rfl
 #a h_797_0
 attribute [local irreducible] v_797_0
 attribute [local irreducible] s_798
 theorem r_798_0 (z : Store) : (s_798 z) 733 = (v_797_0 z) := w_797_0 z
 #a r_798_0
 theorem r_798_1 (z : Store) : (s_798 z) 730 = (v_462_0 z) := pR (k_797 z) (pR (k_796 z) (pR (n_792_796 z) (pR (n_784_792 z) (pR (n_768_784 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (k_463 z) (r_463_0 z)))))))))
 #a r_798_1
 def v_798_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_797_0 z)
 def s_799 (z : Store) : Store := storeSet (s_798 z) [(732, fw_view [1, 8, 64] ((s_798 z) 733))]
 theorem t_798 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_662) (pmPeers pmNode_662) (s_798 z) pmNode_662 none = some (s_799 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_798
 theorem k_798 (z : Store) (tid : Tid) (h : tid ∉ [732]) : (s_799 z) tid = (s_798 z) tid := by
   unfold s_799
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_798
 theorem w_798_0 (z : Store) : (s_799 z) 732 = v_798_0 z := by
   unfold s_799
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_798_0, r_798_0 z, r_798_1 z] <;> rfl
 #a w_798_0
 theorem h_798_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_798_0 z).shape = [1, 8, 64] := by
   unfold v_798_0
   rfl
 #a h_798_0
 attribute [local irreducible] v_798_0
 attribute [local irreducible] s_799
 theorem r_799_0 (z : Store) : (s_799 z) 742 = (v_791_1 z) := pR (k_798 z) (pR (k_797 z) (pR (k_796 z) (pR (k_795 z) (pR (k_794 z) (r_794_0 z)))))
 #a r_799_0
 theorem r_799_1 (z : Store) : (s_799 z) 1045 = (v_793_1 z) := pR (k_798 z) (pR (k_797 z) (pR (k_796 z) (pR (k_795 z) (pR (k_794 z) (r_794_1 z)))))
 #a r_799_1
 def v_799_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_791_1 z), (v_793_1 z)]
 theorem g_799 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_894) (s_799 z) pmNode_894 1 2 1040 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_894, r_799_0 z, r_799_1 z, h_791_1 z z_, h_793_1 z z_]
 #a g_799
 def s_800 (z : Store) : Store := pL [2, 3] (s_799 z) pmNode_894 1 2
 theorem t_799 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_894) (pmPeers pmNode_894) (s_799 z) pmNode_894 none = some (s_800 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_894) (s_799 z) pmNode_894).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1040 (by decide) (g_799 z z_)]
   rfl
 #a t_799
 theorem k_799 (z : Store) (tid : Tid) (h : tid ∉ [1040]) : (s_800 z) tid = (s_799 z) tid := by
   unfold s_800
   dsimp only [pL, pmNode_894, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_799
 theorem w_799_0 (z : Store) : (s_800 z) 1040 = v_799_0 z := by
   unfold s_800
   dsimp only [pL, pmNode_894, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_799_0, r_799_0 z, r_799_1 z] <;> rfl
 #a w_799_0
 theorem h_799_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_799_0 z).shape = [1, 4, 8, 16] := by
   unfold v_799_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_791_1 z z_]
 #a h_799_0
 attribute [local irreducible] v_799_0
 attribute [local irreducible] s_800
 theorem n_796_800 (z : Store) (tid : Tid) (h : tid ∉ ([729, 733, 732, 1040] : List Tid)) : (s_800 z) tid = (s_796 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_796 z) (k_797 z)) (pF _ _ _ _ _ (k_798 z) (k_799 z)) tid h
 #a n_796_800
 theorem r_800_0 (z : Store) : (s_800 z) 741 = (v_791_0 z) := pR (n_796_800 z) (pR (k_795 z) (r_795_0 z))
 #a r_800_0
 theorem r_800_1 (z : Store) : (s_800 z) 1044 = (v_793_0 z) := pR (n_796_800 z) (pR (k_795 z) (r_795_1 z))
 #a r_800_1
 def v_800_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_791_0 z), (v_793_0 z)]
 theorem g_800 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_895) (s_800 z) pmNode_895 1 3 1026 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_895, r_800_0 z, r_800_1 z, h_791_0 z z_, h_793_0 z z_]
 #a g_800
 def s_801 (z : Store) : Store := pL [2, 3] (s_800 z) pmNode_895 1 3
 theorem t_800 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_895) (pmPeers pmNode_895) (s_800 z) pmNode_895 none = some (s_801 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_895) (s_800 z) pmNode_895).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 1026 (by decide) (g_800 z z_)]
   rfl
 #a t_800
 theorem k_800 (z : Store) (tid : Tid) (h : tid ∉ [1026]) : (s_801 z) tid = (s_800 z) tid := by
   unfold s_801
   dsimp only [pL, pmNode_895, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_800
 theorem w_800_0 (z : Store) : (s_801 z) 1026 = v_800_0 z := by
   unfold s_801
   dsimp only [pL, pmNode_895, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_800_0, r_800_0 z, r_800_1 z] <;> rfl
 #a w_800_0
 theorem h_800_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_800_0 z).shape = [1, 4, 16, 8] := by
   unfold v_800_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_791_0 z z_]
 #a h_800_0
 attribute [local irreducible] v_800_0
 attribute [local irreducible] s_801
 theorem n_792_800 (z : Store) (tid : Tid) (h : tid ∉ ([1046, 1044, 1045, 737, 723, 729, 733, 732, 1040] : List Tid)) : (s_800 z) tid = (s_792 z) tid := by
   exact pF _ _ _ _ _ (n_792_796 z) (n_796_800 z) tid h
 #a n_792_800
 theorem n_784_800 (z : Store) (tid : Tid) (h : tid ∉ ([1038, 1053, 747, 746, 1050, 1049, 743, 741, 742, 1046, 1044, 1045, 737, 723, 729, 733, 732, 1040] : List Tid)) : (s_800 z) tid = (s_784 z) tid := by
   exact pF _ _ _ _ _ (n_784_792 z) (n_792_800 z) tid h
 #a n_784_800
 theorem n_768_800 (z : Store) (tid : Tid) (h : tid ∉ ([764, 763, 1067, 1066, 760, 758, 755, 754, 756, 1063, 1061, 1059, 1058, 1057, 751, 735, 750, 1054, 1038, 1053, 747, 746, 1050, 1049, 743, 741, 742, 1046, 1044, 1045, 737, 723, 729, 733, 732, 1040] : List Tid)) : (s_800 z) tid = (s_768 z) tid := by
   exact pF _ _ _ _ _ (n_768_784 z) (n_784_800 z) tid h
 #a n_768_800
 theorem r_801_0 (z : Store) : (s_801 z) 1040 = (v_799_0 z) := pR (k_800 z) (w_799_0 z)
 #a r_801_0
 theorem r_801_1 (z : Store) : (s_801 z) 1030 = (v_468_0 z) := pR (k_800 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_472_480 z) (r_472_0 z)))))
 #a r_801_1
 def v_801_0 (z : Store) : Tensor := transposeAxes 2 3 (v_799_0 z)
 def s_802 (z : Store) : Store := storeSet (s_801 z) [(1032, transposeAxes 2 3 ((s_801 z) 1040))]
 theorem t_801 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_896) (pmPeers pmNode_896) (s_801 z) pmNode_896 none = some (s_802 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_801
 theorem k_801 (z : Store) (tid : Tid) (h : tid ∉ [1032]) : (s_802 z) tid = (s_801 z) tid := by
   unfold s_802
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_801
 theorem w_801_0 (z : Store) : (s_802 z) 1032 = v_801_0 z := by
   unfold s_802
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_801_0, r_801_0 z, r_801_1 z] <;> rfl
 #a w_801_0
 theorem h_801_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_801_0 z).shape = [1, 4, 16, 8] := by
   unfold v_801_0
   change listSwapAt _ _ _ = _
   rw [h_799_0 z z_]
   rfl
 #a h_801_0
 attribute [local irreducible] v_801_0
 attribute [local irreducible] s_802
 record_prefix_opacity v_794_0 s_795 v_795_0 s_796 v_796_0 s_797 v_797_0 s_798 v_798_0 s_799 v_799_0 s_800 v_800_0 s_801 v_801_0 s_802

 end
 end TrainVerify.Denote.RuntimeWorld
