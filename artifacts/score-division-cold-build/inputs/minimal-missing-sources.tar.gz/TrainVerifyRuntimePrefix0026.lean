import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0025
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_200_0 (z : Store) : (s_200 z) 569 = (v_199_0 z) := w_199_0 z
 #a r_200_0
 theorem r_200_1 (z : Store) : (s_200 z) 316 = (z 316) := pR (n_192_200 z) (pR (n_128_192 z) (pR (n_0_128 z) (e_45 z)))
 #a r_200_1
 def v_200_0 (z : Store) : Tensor := fw_linear (v_199_0 z) (z 316)
 def s_201 (z : Store) : Store := storeSet (s_200 z) [(572, fw_linear ((s_200 z) 569) ((s_200 z) 316))]
 theorem t_200 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_334) (pmPeers pmNode_334) (s_200 z) pmNode_334 none = some (s_201 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_200
 theorem k_200 (z : Store) (tid : Tid) (h : tid ∉ [572]) : (s_201 z) tid = (s_200 z) tid := by
   unfold s_201
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_200
 theorem w_200_0 (z : Store) : (s_201 z) 572 = v_200_0 z := by
   unfold s_201
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_200_0, r_200_0 z, r_200_1 z] <;> rfl
 #a w_200_0
 theorem h_200_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_200_0 z).shape = [1, 8, 64] := by
   unfold v_200_0
   exact fw_linear_3d_shape 1 8 256 64 (v_199_0 z) (z 316) (h_199_0 z z_) (i_45 z z_)
 #a h_200_0
 attribute [local irreducible] v_200_0
 attribute [local irreducible] s_201
 theorem r_201_0 (z : Store) : (s_201 z) 301 = (v_180_1 z) := pR (k_200 z) (pR (n_196_200 z) (pR (k_195 z) (r_195_0 z)))
 #a r_201_0
 theorem r_201_1 (z : Store) : (s_201 z) 604 = (v_183_1 z) := pR (k_200 z) (pR (n_196_200 z) (pR (k_195 z) (r_195_1 z)))
 #a r_201_1
 def v_201_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_180_1 z), (v_183_1 z)]
 theorem g_201 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_335) (s_201 z) pmNode_335 2 1 574 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_335, r_201_0 z, r_201_1 z, h_180_1 z z_, h_183_1 z z_]
 #a g_201
 def s_202 (z : Store) : Store := pL [0, 1] (s_201 z) pmNode_335 2 1
 theorem t_201 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_335) (pmPeers pmNode_335) (s_201 z) pmNode_335 none = some (s_202 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_335) (s_201 z) pmNode_335).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 574 (by decide) (g_201 z z_)]
   rfl
 #a t_201
 theorem k_201 (z : Store) (tid : Tid) (h : tid ∉ [574]) : (s_202 z) tid = (s_201 z) tid := by
   unfold s_202
   dsimp only [pL, pmNode_335, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_201
 theorem w_201_0 (z : Store) : (s_202 z) 574 = v_201_0 z := by
   unfold s_202
   dsimp only [pL, pmNode_335, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_201_0, r_201_0 z, r_201_1 z] <;> rfl
 #a w_201_0
 theorem h_201_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_201_0 z).shape = [1, 8, 64] := by
   unfold v_201_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_180_1 z z_]
 #a h_201_0
 attribute [local irreducible] v_201_0
 attribute [local irreducible] s_202
 theorem r_202_0 (z : Store) : (s_202 z) 574 = (v_201_0 z) := w_201_0 z
 #a r_202_0
 theorem r_202_1 (z : Store) : (s_202 z) 572 = (v_200_0 z) := pR (k_201 z) (w_200_0 z)
 #a r_202_1
 def v_202_0 (z : Store) : Tensor := elemwiseAdd (v_201_0 z) (v_200_0 z)
 def s_203 (z : Store) : Store := storeSet (s_202 z) [(575, elemwiseAdd ((s_202 z) 574) ((s_202 z) 572))]
 theorem t_202 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_336) (pmPeers pmNode_336) (s_202 z) pmNode_336 none = some (s_203 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_202
 theorem k_202 (z : Store) (tid : Tid) (h : tid ∉ [575]) : (s_203 z) tid = (s_202 z) tid := by
   unfold s_203
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_202
 theorem w_202_0 (z : Store) : (s_203 z) 575 = v_202_0 z := by
   unfold s_203
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_202_0, r_202_0 z, r_202_1 z] <;> rfl
 #a w_202_0
 theorem h_202_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_202_0 z).shape = [1, 8, 64] := by
   unfold v_202_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_201_0 z z_, h_200_0 z z_]
 #a h_202_0
 attribute [local irreducible] v_202_0
 attribute [local irreducible] s_203
 theorem r_203_0 (z : Store) : (s_203 z) 575 = (v_202_0 z) := w_202_0 z
 #a r_203_0
 theorem r_203_1 (z : Store) : (s_203 z) 317 = (z 317) := pR (k_202 z) (pR (k_201 z) (pR (k_200 z) (pR (n_192_200 z) (pR (n_128_192 z) (pR (n_0_128 z) (e_46 z))))))
 #a r_203_1
 theorem r_203_2 (z : Store) : (s_203 z) 318 = (z 318) := pR (k_202 z) (pR (k_201 z) (pR (k_200 z) (pR (n_192_200 z) (pR (n_128_192 z) (pR (n_0_128 z) (e_47 z))))))
 #a r_203_2
 def v_203_0 (z : Store) : Tensor := fw_layernorm (v_202_0 z) (z 317) (z 318)
 def s_204 (z : Store) : Store := storeSet (s_203 z) [(578, fw_layernorm ((s_203 z) 575) ((s_203 z) 317) ((s_203 z) 318))]
 theorem t_203 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_337) (pmPeers pmNode_337) (s_203 z) pmNode_337 none = some (s_204 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_203
 theorem k_203 (z : Store) (tid : Tid) (h : tid ∉ [578]) : (s_204 z) tid = (s_203 z) tid := by
   unfold s_204
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_203
 theorem w_203_0 (z : Store) : (s_204 z) 578 = v_203_0 z := by
   unfold s_204
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_203_0, r_203_0 z, r_203_1 z, r_203_2 z] <;> rfl
 #a w_203_0
 theorem h_203_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_203_0 z).shape = [1, 8, 64] := by
   unfold v_203_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_202_0 z z_
 #a h_203_0
 attribute [local irreducible] v_203_0
 attribute [local irreducible] s_204
 theorem n_200_204 (z : Store) (tid : Tid) (h : tid ∉ ([572, 574, 575, 578] : List Tid)) : (s_204 z) tid = (s_200 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_200 z) (k_201 z)) (pF _ _ _ _ _ (k_202 z) (k_203 z)) tid h
 #a n_200_204
 theorem r_204_0 (z : Store) : (s_204 z) 275 = (v_197_0 z) := pR (n_200_204 z) (pR (k_199 z) (pR (k_198 z) (w_197_0 z)))
 #a r_204_0
 theorem r_204_1 (z : Store) : (s_204 z) 578 = (v_203_0 z) := w_203_0 z
 #a r_204_1
 def v_204_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_197_0 z), (v_203_0 z)]
 def s_205 (z : Store) : Store := storeSet (s_204 z) [(80, allGatherPrimDimN 1 2 0 [((s_204 z) 275), ((s_204 z) 578)])]
 theorem t_204 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_102) (pmPeers pmNode_102) (s_204 z) pmNode_102 none = some (s_205 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_204 z) pmNode_102 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_204
 theorem k_204 (z : Store) (tid : Tid) (h : tid ∉ [80]) : (s_205 z) tid = (s_204 z) tid := by
   unfold s_205
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_204
 theorem w_204_0 (z : Store) : (s_205 z) 80 = v_204_0 z := by
   unfold s_205
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_204_0, r_204_0 z, r_204_1 z] <;> rfl
 #a w_204_0
 theorem h_204_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_204_0 z).shape = [1, 16, 64] := by
   unfold v_204_0
   exact allGatherPrimDimN_shape 1 2 [(v_197_0 z), (v_203_0 z)] [1, 8, 64] (h_197_0 z z_)
 #a h_204_0
 attribute [local irreducible] v_204_0
 attribute [local irreducible] s_205
 theorem r_205_0 (z : Store) : (s_205 z) 80 = (v_204_0 z) := w_204_0 z
 #a r_205_0
 theorem r_205_1 (z : Store) : (s_205 z) 72 = (z 72) := pR (k_204 z) (pR (n_200_204 z) (pR (n_192_200 z) (pR (n_128_192 z) (pR (n_0_128 z) (e_48 z)))))
 #a r_205_1
 def v_205_0 (z : Store) : Tensor := fw_linear (v_204_0 z) (z 72)
 def s_206 (z : Store) : Store := storeSet (s_205 z) [(277, fw_linear ((s_205 z) 80) ((s_205 z) 72))]
 theorem t_205 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_103) (pmPeers pmNode_103) (s_205 z) pmNode_103 none = some (s_206 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_205
 theorem k_205 (z : Store) (tid : Tid) (h : tid ∉ [277]) : (s_206 z) tid = (s_205 z) tid := by
   unfold s_206
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_205
 theorem w_205_0 (z : Store) : (s_206 z) 277 = v_205_0 z := by
   unfold s_206
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_205_0, r_205_0 z, r_205_1 z] <;> rfl
 #a w_205_0
 theorem h_205_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_205_0 z).shape = [1, 16, 128] := by
   unfold v_205_0
   exact fw_linear_3d_shape 1 16 64 128 (v_204_0 z) (z 72) (h_204_0 z z_) (i_48 z z_)
 #a h_205_0
 attribute [local irreducible] v_205_0
 attribute [local irreducible] s_206
 theorem r_206_0 (z : Store) : (s_206 z) 275 = (v_197_0 z) := pR (k_205 z) (pR (k_204 z) (r_204_0 z))
 #a r_206_0
 theorem r_206_1 (z : Store) : (s_206 z) 578 = (v_203_0 z) := pR (k_205 z) (pR (k_204 z) (r_204_1 z))
 #a r_206_1
 def v_206_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_197_0 z), (v_203_0 z)]
 def s_207 (z : Store) : Store := storeSet (s_206 z) [(383, allGatherPrimDimN 1 2 1 [((s_206 z) 275), ((s_206 z) 578)])]
 theorem t_206 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_338) (pmPeers pmNode_338) (s_206 z) pmNode_338 none = some (s_207 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_206 z) pmNode_338 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_206
 theorem k_206 (z : Store) (tid : Tid) (h : tid ∉ [383]) : (s_207 z) tid = (s_206 z) tid := by
   unfold s_207
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_206
 theorem w_206_0 (z : Store) : (s_207 z) 383 = v_206_0 z := by
   unfold s_207
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_206_0, r_206_0 z, r_206_1 z] <;> rfl
 #a w_206_0
 theorem h_206_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_206_0 z).shape = [1, 16, 64] := by
   unfold v_206_0
   exact allGatherPrimDimN_shape 1 2 [(v_197_0 z), (v_203_0 z)] [1, 8, 64] (h_197_0 z z_)
 #a h_206_0
 attribute [local irreducible] v_206_0
 attribute [local irreducible] s_207
 theorem r_207_0 (z : Store) : (s_207 z) 383 = (v_206_0 z) := w_206_0 z
 #a r_207_0
 theorem r_207_1 (z : Store) : (s_207 z) 375 = (z 375) := pR (k_206 z) (pR (k_205 z) (pR (k_204 z) (pR (n_200_204 z) (pR (n_192_200 z) (pR (n_128_192 z) (pR (n_0_128 z) (e_49 z)))))))
 #a r_207_1
 def v_207_0 (z : Store) : Tensor := fw_linear (v_206_0 z) (z 375)
 def s_208 (z : Store) : Store := storeSet (s_207 z) [(580, fw_linear ((s_207 z) 383) ((s_207 z) 375))]
 theorem t_207 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_339) (pmPeers pmNode_339) (s_207 z) pmNode_339 none = some (s_208 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_207
 theorem k_207 (z : Store) (tid : Tid) (h : tid ∉ [580]) : (s_208 z) tid = (s_207 z) tid := by
   unfold s_208
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_207
 theorem w_207_0 (z : Store) : (s_208 z) 580 = v_207_0 z := by
   unfold s_208
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_207_0, r_207_0 z, r_207_1 z] <;> rfl
 #a w_207_0
 theorem h_207_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_207_0 z).shape = [1, 16, 128] := by
   unfold v_207_0
   exact fw_linear_3d_shape 1 16 64 128 (v_206_0 z) (z 375) (h_206_0 z z_) (i_49 z z_)
 #a h_207_0
 attribute [local irreducible] v_207_0
 attribute [local irreducible] s_208
 theorem r_208_0 (z : Store) : (s_208 z) 277 = (v_205_0 z) := pR (k_207 z) (pR (k_206 z) (w_205_0 z))
 #a r_208_0
 theorem r_208_1 (z : Store) : (s_208 z) 580 = (v_207_0 z) := w_207_0 z
 #a r_208_1
 def v_208_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_205_0 z), (v_207_0 z)]
 theorem g_208 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_104) (s_208 z) pmNode_104 2 1 280 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 128], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_104, r_208_0 z, r_208_1 z, h_205_0 z z_, h_207_0 z z_]
 #a g_208
 def s_209 (z : Store) : Store := pL [0, 1] (s_208 z) pmNode_104 2 1
 theorem t_208 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_104) (pmPeers pmNode_104) (s_208 z) pmNode_104 none = some (s_209 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_104) (s_208 z) pmNode_104).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 280 (by decide) (g_208 z z_)]
   rfl
 #a t_208
 theorem k_208 (z : Store) (tid : Tid) (h : tid ∉ [280]) : (s_209 z) tid = (s_208 z) tid := by
   unfold s_209
   dsimp only [pL, pmNode_104, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_208
 theorem w_208_0 (z : Store) : (s_209 z) 280 = v_208_0 z := by
   unfold s_209
   dsimp only [pL, pmNode_104, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_208_0, r_208_0 z, r_208_1 z] <;> rfl
 #a w_208_0
 theorem h_208_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_208_0 z).shape = [1, 8, 256] := by
   unfold v_208_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_205_0 z z_]
 #a h_208_0
 attribute [local irreducible] v_208_0
 attribute [local irreducible] s_209
 record_prefix_opacity v_200_0 s_201 v_201_0 s_202 v_202_0 s_203 v_203_0 s_204 v_204_0 s_205 v_205_0 s_206 v_206_0 s_207 v_207_0 s_208 v_208_0 s_209

 end
 end TrainVerify.Denote.RuntimeWorld
