import denote.SourceScopedEval
namespace TrainVerify.Denote.RuntimeWorld
set_option maxHeartbeats 500000
noncomputable section
-- Source-only definitions; no Torch refinement or public value closure.
def smNode_0 : NodeDecl := {rank := 0, op := "OpName.DATALOADER", ins := [], outs := [1262, 1263], params := []}
theorem smNode_0_blocked (g : GraphDecl) (s : Store) (peer : Nat → Tid) :
    SourceScopedEval.step g (.group none) peer s smNode_0 = none := rfl
#print axioms smNode_0_blocked
def smNode_1 : NodeDecl := {rank := 0, op := "OpName.FW_embedding", ins := [1262, 1212], outs := [1265], params := []}
def smNode_2 : NodeDecl := {rank := 0, op := "OpName.FW_embedding", ins := [1263, 1213], outs := [1266], params := []}
def smNode_3 : NodeDecl := {rank := 0, op := "OpName.FW_add", ins := [1265, 1266], outs := [1267], params := []}
def smNode_4 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [1267], outs := [1376, 1377], params := [2]}
def smNode_5 : NodeDecl := {rank := 0, op := "OpName.FW_layernorm", ins := [1376, 1214, 1215], outs := [1268], params := []}
def smNode_6 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [1268], outs := [1380, 1381, 1382], params := [3]}
def smNode_7 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1380, 1216], outs := [1269], params := []}
def smNode_8 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1381, 1217], outs := [1270], params := []}
def smNode_9 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1382, 1218], outs := [1271], params := []}
def smNode_10 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [1269], outs := [1272], params := [2, 16, 4, 16]}
def smNode_11 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [1272], outs := [1273], params := [1, 2]}
def smNode_12 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [1270], outs := [1274], params := [2, 16, 4, 16]}
def smNode_13 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [1274], outs := [1275], params := [1, 2]}
def smNode_14 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [1271], outs := [1276], params := [2, 16, 4, 16]}
def smNode_15 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [1276], outs := [1277], params := [1, 2]}
def smNode_16 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [1275], outs := [1278], params := [2, 3]}
def smNode_17 : NodeDecl := {rank := 0, op := "OpName.FW_matmul", ins := [1273, 1278], outs := [1279], params := []}
def smNode_18 : NodeDecl := {rank := 0, op := "OpName.FW_div", ins := [1279], outs := [1280], params := [4]}
def smNode_19 : NodeDecl := {rank := 0, op := "OpName.FW_softmax", ins := [1280], outs := [1281], params := []}
def smNode_20 : NodeDecl := {rank := 0, op := "OpName.FW_matmul", ins := [1281, 1277], outs := [1282], params := []}
def smNode_21 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [1282], outs := [1283], params := [1, 2]}
def smNode_22 : NodeDecl := {rank := 0, op := "OpName.FW_contiguous", ins := [1283], outs := [1284], params := []}
def smNode_23 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [1284], outs := [1285], params := [2, 16, 64]}
def smNode_24 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1285, 1219], outs := [1286], params := []}
def smNode_25 : NodeDecl := {rank := 0, op := "OpName.FW_add", ins := [1377, 1286], outs := [1287], params := []}
def smNode_26 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [1287], outs := [1386, 1387], params := [2]}
def smNode_27 : NodeDecl := {rank := 0, op := "OpName.FW_layernorm", ins := [1386, 1220, 1221], outs := [1288], params := []}
def smNode_28 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1288, 1222], outs := [1289], params := []}
def smNode_29 : NodeDecl := {rank := 0, op := "OpName.FW_gelu", ins := [1289], outs := [1290], params := []}
def smNode_30 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1290, 1223], outs := [1291], params := []}
def smNode_31 : NodeDecl := {rank := 0, op := "OpName.FW_add", ins := [1387, 1291], outs := [1292], params := []}
def smNode_32 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [1292], outs := [1390, 1391], params := [2]}
def smNode_33 : NodeDecl := {rank := 0, op := "OpName.FW_layernorm", ins := [1390, 1224, 1225], outs := [1293], params := []}
def smNode_34 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [1293], outs := [1394, 1395, 1396], params := [3]}
def smNode_35 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1394, 1226], outs := [1294], params := []}
def smNode_36 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1395, 1227], outs := [1295], params := []}
def smNode_37 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1396, 1228], outs := [1296], params := []}
def smNode_38 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [1294], outs := [1297], params := [2, 16, 4, 16]}
def smNode_39 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [1297], outs := [1298], params := [1, 2]}
def smNode_40 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [1295], outs := [1299], params := [2, 16, 4, 16]}
def smNode_41 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [1299], outs := [1300], params := [1, 2]}
def smNode_42 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [1296], outs := [1301], params := [2, 16, 4, 16]}
def smNode_43 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [1301], outs := [1302], params := [1, 2]}
def smNode_44 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [1300], outs := [1303], params := [2, 3]}
def smNode_45 : NodeDecl := {rank := 0, op := "OpName.FW_matmul", ins := [1298, 1303], outs := [1304], params := []}
def smNode_46 : NodeDecl := {rank := 0, op := "OpName.FW_div", ins := [1304], outs := [1305], params := [4]}
def smNode_47 : NodeDecl := {rank := 0, op := "OpName.FW_softmax", ins := [1305], outs := [1306], params := []}
def smNode_48 : NodeDecl := {rank := 0, op := "OpName.FW_matmul", ins := [1306, 1302], outs := [1307], params := []}
def smNode_49 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [1307], outs := [1308], params := [1, 2]}
def smNode_50 : NodeDecl := {rank := 0, op := "OpName.FW_contiguous", ins := [1308], outs := [1309], params := []}
def smNode_51 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [1309], outs := [1310], params := [2, 16, 64]}
def smNode_52 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1310, 1229], outs := [1311], params := []}
def smNode_53 : NodeDecl := {rank := 0, op := "OpName.FW_add", ins := [1391, 1311], outs := [1312], params := []}
def smNode_54 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [1312], outs := [1400, 1401], params := [2]}
def smNode_55 : NodeDecl := {rank := 0, op := "OpName.FW_layernorm", ins := [1400, 1230, 1231], outs := [1313], params := []}
def smNode_56 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1313, 1232], outs := [1314], params := []}
def smNode_57 : NodeDecl := {rank := 0, op := "OpName.FW_gelu", ins := [1314], outs := [1315], params := []}
def smNode_58 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1315, 1233], outs := [1316], params := []}
def smNode_59 : NodeDecl := {rank := 0, op := "OpName.FW_add", ins := [1401, 1316], outs := [1317], params := []}
def smNode_60 : NodeDecl := {rank := 0, op := "OpName.FW_layernorm", ins := [1317, 1234, 1235], outs := [1318], params := []}
def smNode_61 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [1318, 1236], outs := [1319], params := []}
def smNode_62 : NodeDecl := {rank := 0, op := "OpName.FW_sum", ins := [1319], outs := [1264], params := []}
def smNode_63 : NodeDecl := {rank := 0, op := "OpName.BW_sum", ins := [1320, 1319], outs := [1375], params := []}
def smNode_64 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1375, 1318, 1236], outs := [1374, 1261], params := []}
def smNode_65 : NodeDecl := {rank := 0, op := "OpName.BW_layernorm", ins := [1374, 1317, 1234, 1235], outs := [1373, 1259, 1260], params := []}
def smNode_66 : NodeDecl := {rank := 0, op := "OpName.BW_add", ins := [1373, 1401, 1316], outs := [1403, 1372], params := []}
def smNode_67 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1372, 1315, 1233], outs := [1371, 1258], params := []}
def smNode_68 : NodeDecl := {rank := 0, op := "OpName.BW_gelu", ins := [1371, 1314], outs := [1370], params := []}
def smNode_69 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1370, 1313, 1232], outs := [1369, 1257], params := []}
def smNode_70 : NodeDecl := {rank := 0, op := "OpName.BW_layernorm", ins := [1369, 1400, 1230, 1231], outs := [1402, 1255, 1256], params := []}
def smNode_71 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [1402, 1403], outs := [1368], params := []}
def smNode_72 : NodeDecl := {rank := 0, op := "OpName.BW_add", ins := [1368, 1391, 1311], outs := [1393, 1367], params := []}
def smNode_73 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1367, 1310, 1229], outs := [1366, 1254], params := []}
def smNode_74 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [1366, 1309], outs := [1365], params := [2, 16, 4, 16]}
def smNode_75 : NodeDecl := {rank := 0, op := "OpName.BW_contiguous", ins := [1365, 1308], outs := [1364], params := []}
def smNode_76 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [1364, 1307], outs := [1363], params := [1, 2]}
def smNode_77 : NodeDecl := {rank := 0, op := "OpName.BW_matmul", ins := [1363, 1306, 1302], outs := [1362, 1358], params := []}
def smNode_78 : NodeDecl := {rank := 0, op := "OpName.BW_softmax", ins := [1362, 1305], outs := [1361], params := []}
def smNode_79 : NodeDecl := {rank := 0, op := "OpName.BW_div", ins := [1361, 1304], outs := [1360], params := [4]}
def smNode_80 : NodeDecl := {rank := 0, op := "OpName.BW_matmul", ins := [1360, 1298, 1303], outs := [1354, 1359], params := []}
def smNode_81 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [1359, 1300], outs := [1356], params := [2, 3]}
def smNode_82 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [1358, 1301], outs := [1357], params := [1, 2]}
def smNode_83 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [1357, 1296], outs := [1352], params := [2, 16, 64]}
def smNode_84 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [1356, 1299], outs := [1355], params := [1, 2]}
def smNode_85 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [1355, 1295], outs := [1351], params := [2, 16, 64]}
def smNode_86 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [1354, 1297], outs := [1353], params := [1, 2]}
def smNode_87 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [1353, 1294], outs := [1350], params := [2, 16, 64]}
def smNode_88 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1352, 1396, 1228], outs := [1399, 1253], params := []}
def smNode_89 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1351, 1395, 1227], outs := [1398, 1252], params := []}
def smNode_90 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1350, 1394, 1226], outs := [1397, 1251], params := []}
def smNode_91 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [1397, 1398, 1399], outs := [1349], params := []}
def smNode_92 : NodeDecl := {rank := 0, op := "OpName.BW_layernorm", ins := [1349, 1390, 1224, 1225], outs := [1392, 1249, 1250], params := []}
def smNode_93 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [1392, 1393], outs := [1348], params := []}
def smNode_94 : NodeDecl := {rank := 0, op := "OpName.BW_add", ins := [1348, 1387, 1291], outs := [1389, 1347], params := []}
def smNode_95 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1347, 1290, 1223], outs := [1346, 1248], params := []}
def smNode_96 : NodeDecl := {rank := 0, op := "OpName.BW_gelu", ins := [1346, 1289], outs := [1345], params := []}
def smNode_97 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1345, 1288, 1222], outs := [1344, 1247], params := []}
def smNode_98 : NodeDecl := {rank := 0, op := "OpName.BW_layernorm", ins := [1344, 1386, 1220, 1221], outs := [1388, 1245, 1246], params := []}
def smNode_99 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [1388, 1389], outs := [1343], params := []}
def smNode_100 : NodeDecl := {rank := 0, op := "OpName.BW_add", ins := [1343, 1377, 1286], outs := [1379, 1342], params := []}
def smNode_101 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1342, 1285, 1219], outs := [1341, 1244], params := []}
def smNode_102 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [1341, 1284], outs := [1340], params := [2, 16, 4, 16]}
def smNode_103 : NodeDecl := {rank := 0, op := "OpName.BW_contiguous", ins := [1340, 1283], outs := [1339], params := []}
def smNode_104 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [1339, 1282], outs := [1338], params := [1, 2]}
def smNode_105 : NodeDecl := {rank := 0, op := "OpName.BW_matmul", ins := [1338, 1281, 1277], outs := [1337, 1333], params := []}
def smNode_106 : NodeDecl := {rank := 0, op := "OpName.BW_softmax", ins := [1337, 1280], outs := [1336], params := []}
def smNode_107 : NodeDecl := {rank := 0, op := "OpName.BW_div", ins := [1336, 1279], outs := [1335], params := [4]}
def smNode_108 : NodeDecl := {rank := 0, op := "OpName.BW_matmul", ins := [1335, 1273, 1278], outs := [1329, 1334], params := []}
def smNode_109 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [1334, 1275], outs := [1331], params := [2, 3]}
def smNode_110 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [1333, 1276], outs := [1332], params := [1, 2]}
def smNode_111 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [1332, 1271], outs := [1327], params := [2, 16, 64]}
def smNode_112 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [1331, 1274], outs := [1330], params := [1, 2]}
def smNode_113 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [1330, 1270], outs := [1326], params := [2, 16, 64]}
def smNode_114 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [1329, 1272], outs := [1328], params := [1, 2]}
def smNode_115 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [1328, 1269], outs := [1325], params := [2, 16, 64]}
def smNode_116 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1327, 1382, 1218], outs := [1385, 1243], params := []}
def smNode_117 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1326, 1381, 1217], outs := [1384, 1242], params := []}
def smNode_118 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [1325, 1380, 1216], outs := [1383, 1241], params := []}
def smNode_119 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [1383, 1384, 1385], outs := [1324], params := []}
def smNode_120 : NodeDecl := {rank := 0, op := "OpName.BW_layernorm", ins := [1324, 1376, 1214, 1215], outs := [1378, 1239, 1240], params := []}
def smNode_121 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [1378, 1379], outs := [1323], params := []}
def smNode_122 : NodeDecl := {rank := 0, op := "OpName.BW_add", ins := [1323, 1265, 1266], outs := [1321, 1322], params := []}
def smNode_123 : NodeDecl := {rank := 0, op := "OpName.BW_embedding", ins := [1322, 1263, 1213], outs := [1238], params := []}
def smNode_124 : NodeDecl := {rank := 0, op := "OpName.BW_embedding", ins := [1321, 1262, 1212], outs := [1237], params := []}
def smGraph : GraphDecl := {numRanks := 1, nodes := [smNode_0, smNode_1, smNode_2, smNode_3, smNode_4, smNode_5, smNode_6, smNode_7, smNode_8, smNode_9, smNode_10, smNode_11, smNode_12, smNode_13, smNode_14, smNode_15, smNode_16, smNode_17, smNode_18, smNode_19, smNode_20, smNode_21, smNode_22, smNode_23, smNode_24, smNode_25, smNode_26, smNode_27, smNode_28, smNode_29, smNode_30, smNode_31, smNode_32, smNode_33, smNode_34, smNode_35, smNode_36, smNode_37, smNode_38, smNode_39, smNode_40, smNode_41, smNode_42, smNode_43, smNode_44, smNode_45, smNode_46, smNode_47, smNode_48, smNode_49, smNode_50, smNode_51, smNode_52, smNode_53, smNode_54, smNode_55, smNode_56, smNode_57, smNode_58, smNode_59, smNode_60, smNode_61, smNode_62, smNode_63, smNode_64, smNode_65, smNode_66, smNode_67, smNode_68, smNode_69, smNode_70, smNode_71, smNode_72, smNode_73, smNode_74, smNode_75, smNode_76, smNode_77, smNode_78, smNode_79, smNode_80, smNode_81, smNode_82, smNode_83, smNode_84, smNode_85, smNode_86, smNode_87, smNode_88, smNode_89, smNode_90, smNode_91, smNode_92, smNode_93, smNode_94, smNode_95, smNode_96, smNode_97, smNode_98, smNode_99, smNode_100, smNode_101, smNode_102, smNode_103, smNode_104, smNode_105, smNode_106, smNode_107, smNode_108, smNode_109, smNode_110, smNode_111, smNode_112, smNode_113, smNode_114, smNode_115, smNode_116, smNode_117, smNode_118, smNode_119, smNode_120, smNode_121, smNode_122, smNode_123, smNode_124]}
def smRequests : List (NodeDecl × GroupScopedEval.Request × List (Nat × Tid)) := [
(smNode_0, .group none, []),
(smNode_1, .global, []),
(smNode_2, .global, []),
(smNode_3, .global, []),
(smNode_4, .global, []),
(smNode_5, .global, []),
(smNode_6, .global, []),
(smNode_7, .global, []),
(smNode_8, .global, []),
(smNode_9, .global, []),
(smNode_10, .global, []),
(smNode_11, .global, []),
(smNode_12, .global, []),
(smNode_13, .global, []),
(smNode_14, .global, []),
(smNode_15, .global, []),
(smNode_16, .global, []),
(smNode_17, .global, []),
(smNode_18, .global, []),
(smNode_19, .global, []),
(smNode_20, .global, []),
(smNode_21, .global, []),
(smNode_22, .global, []),
(smNode_23, .global, []),
(smNode_24, .global, []),
(smNode_25, .global, []),
(smNode_26, .global, []),
(smNode_27, .global, []),
(smNode_28, .global, []),
(smNode_29, .global, []),
(smNode_30, .global, []),
(smNode_31, .global, []),
(smNode_32, .global, []),
(smNode_33, .global, []),
(smNode_34, .global, []),
(smNode_35, .global, []),
(smNode_36, .global, []),
(smNode_37, .global, []),
(smNode_38, .global, []),
(smNode_39, .global, []),
(smNode_40, .global, []),
(smNode_41, .global, []),
(smNode_42, .global, []),
(smNode_43, .global, []),
(smNode_44, .global, []),
(smNode_45, .global, []),
(smNode_46, .global, []),
(smNode_47, .global, []),
(smNode_48, .global, []),
(smNode_49, .global, []),
(smNode_50, .global, []),
(smNode_51, .global, []),
(smNode_52, .global, []),
(smNode_53, .global, []),
(smNode_54, .global, []),
(smNode_55, .global, []),
(smNode_56, .global, []),
(smNode_57, .global, []),
(smNode_58, .global, []),
(smNode_59, .global, []),
(smNode_60, .global, []),
(smNode_61, .global, []),
(smNode_62, .global, []),
(smNode_63, .global, []),
(smNode_64, .global, []),
(smNode_65, .global, []),
(smNode_66, .global, []),
(smNode_67, .global, []),
(smNode_68, .global, []),
(smNode_69, .global, []),
(smNode_70, .global, []),
(smNode_71, .global, []),
(smNode_72, .global, []),
(smNode_73, .global, []),
(smNode_74, .global, []),
(smNode_75, .global, []),
(smNode_76, .global, []),
(smNode_77, .global, []),
(smNode_78, .global, []),
(smNode_79, .global, []),
(smNode_80, .global, []),
(smNode_81, .global, []),
(smNode_82, .global, []),
(smNode_83, .global, []),
(smNode_84, .global, []),
(smNode_85, .global, []),
(smNode_86, .global, []),
(smNode_87, .global, []),
(smNode_88, .global, []),
(smNode_89, .global, []),
(smNode_90, .global, []),
(smNode_91, .global, []),
(smNode_92, .global, []),
(smNode_93, .global, []),
(smNode_94, .global, []),
(smNode_95, .global, []),
(smNode_96, .global, []),
(smNode_97, .global, []),
(smNode_98, .global, []),
(smNode_99, .global, []),
(smNode_100, .global, []),
(smNode_101, .global, []),
(smNode_102, .global, []),
(smNode_103, .global, []),
(smNode_104, .global, []),
(smNode_105, .global, []),
(smNode_106, .global, []),
(smNode_107, .global, []),
(smNode_108, .global, []),
(smNode_109, .global, []),
(smNode_110, .global, []),
(smNode_111, .global, []),
(smNode_112, .global, []),
(smNode_113, .global, []),
(smNode_114, .global, []),
(smNode_115, .global, []),
(smNode_116, .global, []),
(smNode_117, .global, []),
(smNode_118, .global, []),
(smNode_119, .global, []),
(smNode_120, .global, []),
(smNode_121, .global, []),
(smNode_122, .global, []),
(smNode_123, .global, []),
(smNode_124, .global, [])
]
def smScope (n : NodeDecl) : GroupScopedEval.Request :=
  match smRequests.find? (fun row => row.1 == n) with
  | some row => row.2.1
  | none => .group none
def smPeers (n : NodeDecl) (r : Nat) : Tid :=
  match smRequests.find? (fun row => row.1 == n) with
  | some row => ((row.2.2.find? (fun p => p.1 == r)).map Prod.snd).getD 0
  | none => 0
def smDenote (s : Store) : Option Store := SourceScopedEval.denote smGraph smScope smPeers s
def pmNode_0 : NodeDecl := {rank := 0, op := "OpName.DATALOADER", ins := [], outs := [75, 76], params := []}
theorem pmNode_0_blocked (g : GraphDecl) (s : Store) (peer : Nat → Tid) :
    SourceScopedEval.step g (.group none) peer s pmNode_0 = none := rfl
#print axioms pmNode_0_blocked
def pmNode_1 : NodeDecl := {rank := 0, op := "OpName.FW_embedding", ins := [75, 16], outs := [89], params := []}
def pmNode_2 : NodeDecl := {rank := 0, op := "OpName.ChunkPrim", ins := [76], outs := [91], params := [1]}
def pmNode_3 : NodeDecl := {rank := 0, op := "OpName.FW_embedding", ins := [91, 0], outs := [92], params := []}
def pmNode_4 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [92, 395], outs := [94], params := [1, 2]}
def pmNode_5 : NodeDecl := {rank := 0, op := "OpName.FW_add", ins := [89, 94], outs := [95], params := []}
def pmNode_6 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [95], outs := [283, 163], params := [2]}
def pmNode_7 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [283, 586], outs := [98], params := [2, 1]}
def pmNode_8 : NodeDecl := {rank := 0, op := "OpName.FW_layernorm", ins := [98, 1, 2], outs := [99], params := []}
def pmNode_9 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [99], outs := [102, 285, 287], params := [3]}
def pmNode_10 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [102, 3], outs := [103], params := []}
def pmNode_11 : NodeDecl := {rank := 0, op := "OpName.AllGatherPrim", ins := [285, 588], outs := [86], params := [1]}
def pmNode_12 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [86, 27], outs := [106], params := []}
def pmNode_13 : NodeDecl := {rank := 0, op := "OpName.AllGatherPrim", ins := [287, 590], outs := [87], params := [1]}
def pmNode_14 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [87, 30], outs := [109], params := []}
def pmNode_15 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [103], outs := [112], params := [1, 8, 4, 16]}
def pmNode_16 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [112, 415], outs := [114], params := [1, 3]}
def pmNode_17 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [114], outs := [115], params := [1, 2]}
def pmNode_18 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [106], outs := [118], params := [1, 16, 2, 16]}
def pmNode_19 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [118, 421], outs := [120], params := [2, 3]}
def pmNode_20 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [120], outs := [121], params := [1, 2]}
def pmNode_21 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [109, 412], outs := [124], params := [2, 1]}
def pmNode_22 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [124], outs := [125], params := [1, 8, 4, 16]}
def pmNode_23 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [125], outs := [128], params := [1, 2]}
def pmNode_24 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [121], outs := [130], params := [2, 3]}
def pmNode_25 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [115, 418], outs := [132], params := [3, 1]}
def pmNode_26 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [130, 433], outs := [133], params := [2, 1]}
def pmNode_27 : NodeDecl := {rank := 0, op := "OpName.FW_matmul", ins := [132, 133], outs := [134], params := []}
def pmNode_28 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [134, 437], outs := [138], params := [1, 3]}
def pmNode_29 : NodeDecl := {rank := 0, op := "OpName.FW_div", ins := [138], outs := [139], params := [4]}
def pmNode_30 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [139, 442], outs := [142], params := [3, 1]}
def pmNode_31 : NodeDecl := {rank := 0, op := "OpName.FW_softmax", ins := [142], outs := [143], params := []}
def pmNode_32 : NodeDecl := {rank := 0, op := "OpName.AllGatherPrim", ins := [128, 431], outs := [78], params := [2]}
def pmNode_33 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [143, 446], outs := [146], params := [1, 2]}
def pmNode_34 : NodeDecl := {rank := 0, op := "OpName.FW_matmul", ins := [146, 78], outs := [147], params := []}
def pmNode_35 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [147], outs := [151], params := [1, 2]}
def pmNode_36 : NodeDecl := {rank := 0, op := "OpName.FW_contiguous", ins := [151], outs := [153], params := []}
def pmNode_37 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [153, 456], outs := [155], params := [1, 2]}
def pmNode_38 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [155], outs := [156], params := [1, 16, 32]}
def pmNode_39 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [156, 459], outs := [159], params := [2, 1]}
def pmNode_40 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [159, 4], outs := [160], params := []}
def pmNode_41 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [160, 463], outs := [164], params := [1, 2]}
def pmNode_42 : NodeDecl := {rank := 0, op := "OpName.FW_add", ins := [163, 164], outs := [165], params := []}
def pmNode_43 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [165], outs := [289, 179], params := [2]}
def pmNode_44 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [289, 592], outs := [169], params := [2, 1]}
def pmNode_45 : NodeDecl := {rank := 0, op := "OpName.FW_layernorm", ins := [169, 5, 6], outs := [170], params := []}
def pmNode_46 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [170, 7], outs := [173], params := []}
def pmNode_47 : NodeDecl := {rank := 0, op := "OpName.FW_gelu", ins := [173], outs := [175], params := []}
def pmNode_48 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [175, 8], outs := [177], params := []}
def pmNode_49 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [177, 480], outs := [180], params := [1, 2]}
def pmNode_50 : NodeDecl := {rank := 0, op := "OpName.FW_add", ins := [179, 180], outs := [181], params := []}
def pmNode_51 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [181], outs := [291, 252], params := [2]}
def pmNode_52 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [291, 594], outs := [185], params := [2, 1]}
def pmNode_53 : NodeDecl := {rank := 0, op := "OpName.FW_layernorm", ins := [185, 9, 10], outs := [186], params := []}
def pmNode_54 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [186], outs := [293, 295, 297], params := [3]}
def pmNode_55 : NodeDecl := {rank := 0, op := "OpName.AllGatherPrim", ins := [293, 596], outs := [88], params := [1]}
def pmNode_56 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [88, 47], outs := [189], params := []}
def pmNode_57 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [295, 598], outs := [192], params := [1, 2]}
def pmNode_58 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [192, 50], outs := [193], params := []}
def pmNode_59 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [297, 600], outs := [195], params := [1, 2]}
def pmNode_60 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [195, 53], outs := [196], params := []}
def pmNode_61 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [189, 492], outs := [198], params := [2, 1]}
def pmNode_62 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [198], outs := [199], params := [1, 8, 4, 16]}
def pmNode_63 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [199, 502], outs := [202], params := [1, 2]}
def pmNode_64 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [202], outs := [203], params := [1, 2]}
def pmNode_65 : NodeDecl := {rank := 0, op := "OpName.ReduceScatterPrim", ins := [193, 496], outs := [206], params := [1]}
def pmNode_66 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [206], outs := [207], params := [1, 8, 4, 16]}
def pmNode_67 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [207, 510], outs := [210], params := [1, 3]}
def pmNode_68 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [210], outs := [211], params := [1, 2]}
def pmNode_69 : NodeDecl := {rank := 0, op := "OpName.ReduceScatterPrim", ins := [196, 499], outs := [214], params := [2]}
def pmNode_70 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [214], outs := [215], params := [1, 16, 2, 16]}
def pmNode_71 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [215, 518], outs := [218], params := [2, 1]}
def pmNode_72 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [218], outs := [219], params := [1, 2]}
def pmNode_73 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [211], outs := [222], params := [2, 3]}
def pmNode_74 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [222, 525], outs := [224], params := [2, 1]}
def pmNode_75 : NodeDecl := {rank := 0, op := "OpName.FW_matmul", ins := [203, 224], outs := [225], params := []}
def pmNode_76 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [225, 528], outs := [228], params := [1, 3]}
def pmNode_77 : NodeDecl := {rank := 0, op := "OpName.FW_div", ins := [228], outs := [229], params := [4]}
def pmNode_78 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [229, 532], outs := [232], params := [3, 2]}
def pmNode_79 : NodeDecl := {rank := 0, op := "OpName.FW_softmax", ins := [232], outs := [233], params := []}
def pmNode_80 : NodeDecl := {rank := 0, op := "OpName.AllGatherPrim", ins := [219, 522], outs := [79], params := [2]}
def pmNode_81 : NodeDecl := {rank := 0, op := "OpName.FW_matmul", ins := [233, 79], outs := [236], params := []}
def pmNode_82 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [236, 539], outs := [239], params := [2, 1]}
def pmNode_83 : NodeDecl := {rank := 0, op := "OpName.FW_transpose", ins := [239], outs := [240], params := [1, 2]}
def pmNode_84 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [240, 543], outs := [243], params := [2, 1]}
def pmNode_85 : NodeDecl := {rank := 0, op := "OpName.FW_contiguous", ins := [243], outs := [244], params := []}
def pmNode_86 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [244, 547], outs := [247], params := [1, 2]}
def pmNode_87 : NodeDecl := {rank := 0, op := "OpName.FW_view", ins := [247], outs := [248], params := [1, 16, 32]}
def pmNode_88 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [248, 56], outs := [251], params := []}
def pmNode_89 : NodeDecl := {rank := 0, op := "OpName.ReduceScatterPrim", ins := [251, 554], outs := [253], params := [2]}
def pmNode_90 : NodeDecl := {rank := 0, op := "OpName.FW_add", ins := [252, 253], outs := [254], params := []}
def pmNode_91 : NodeDecl := {rank := 0, op := "OpName.FW_multiref", ins := [254], outs := [299, 301], params := [2]}
def pmNode_92 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [299, 602], outs := [258], params := [2, 1]}
def pmNode_93 : NodeDecl := {rank := 0, op := "OpName.FW_layernorm", ins := [258, 11, 12], outs := [259], params := []}
def pmNode_94 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [259, 562], outs := [262], params := [1, 2]}
def pmNode_95 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [262, 63], outs := [263], params := []}
def pmNode_96 : NodeDecl := {rank := 0, op := "OpName.ReduceScatterPrim", ins := [263, 566], outs := [265], params := [1]}
def pmNode_97 : NodeDecl := {rank := 0, op := "OpName.FW_gelu", ins := [265], outs := [266], params := []}
def pmNode_98 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [266, 13], outs := [269], params := []}
def pmNode_99 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [301, 604], outs := [271], params := [2, 1]}
def pmNode_100 : NodeDecl := {rank := 0, op := "OpName.FW_add", ins := [271, 269], outs := [272], params := []}
def pmNode_101 : NodeDecl := {rank := 0, op := "OpName.FW_layernorm", ins := [272, 14, 15], outs := [275], params := []}
def pmNode_102 : NodeDecl := {rank := 0, op := "OpName.AllGatherPrim", ins := [275, 578], outs := [80], params := [1]}
def pmNode_103 : NodeDecl := {rank := 0, op := "OpName.FW_linear", ins := [80, 72], outs := [277], params := []}
def pmNode_104 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [277, 580], outs := [280], params := [2, 1]}
def pmNode_105 : NodeDecl := {rank := 0, op := "OpName.FW_sum", ins := [280], outs := [281], params := []}
def pmNode_106 : NodeDecl := {rank := 0, op := "OpName.AllReducePrim", ins := [281, 584], outs := [77], params := []}
def pmNode_107 : NodeDecl := {rank := 0, op := "OpName.BW_sum", ins := [81, 280], outs := [282], params := []}
def pmNode_108 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [282, 585], outs := [278], params := [1, 2]}
def pmNode_109 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [278, 80, 72], outs := [279, 73], params := []}
def pmNode_110 : NodeDecl := {rank := 0, op := "OpName.ReduceScatterPrim", ins := [279, 581], outs := [276], params := [1]}
def pmNode_111 : NodeDecl := {rank := 0, op := "OpName.BW_layernorm", ins := [276, 272, 14, 15], outs := [274, 68, 70], params := []}
def pmNode_112 : NodeDecl := {rank := 0, op := "OpName.BW_add", ins := [274, 271, 269], outs := [273, 270], params := []}
def pmNode_113 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [273, 576], outs := [302], params := [1, 2]}
def pmNode_114 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [270, 266, 13], outs := [268, 66], params := []}
def pmNode_115 : NodeDecl := {rank := 0, op := "OpName.BW_gelu", ins := [268, 265], outs := [267], params := []}
def pmNode_116 : NodeDecl := {rank := 0, op := "OpName.AllGatherPrim", ins := [267, 570], outs := [85], params := [1]}
def pmNode_117 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [85, 262, 63], outs := [264, 64], params := []}
def pmNode_118 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [264, 567], outs := [261], params := [2, 1]}
def pmNode_119 : NodeDecl := {rank := 0, op := "OpName.BW_layernorm", ins := [261, 258, 11, 12], outs := [260, 59, 61], params := []}
def pmNode_120 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [260, 563], outs := [300], params := [1, 2]}
def pmNode_121 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [300, 302], outs := [257], params := []}
def pmNode_122 : NodeDecl := {rank := 0, op := "OpName.BW_add", ins := [257, 252, 253], outs := [255, 256], params := []}
def pmNode_123 : NodeDecl := {rank := 0, op := "OpName.AllGatherPrim", ins := [256, 559], outs := [84], params := [2]}
def pmNode_124 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [84, 248, 56], outs := [250, 57], params := []}
def pmNode_125 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [250, 247], outs := [249], params := [1, 16, 2, 16]}
def pmNode_126 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [249, 552], outs := [246], params := [2, 1]}
def pmNode_127 : NodeDecl := {rank := 0, op := "OpName.BW_contiguous", ins := [246, 243], outs := [245], params := []}
def pmNode_128 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [245, 548], outs := [242], params := [1, 2]}
def pmNode_129 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [242, 239], outs := [241], params := [1, 2]}
def pmNode_130 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [241, 544], outs := [237], params := [1, 2]}
def pmNode_131 : NodeDecl := {rank := 0, op := "OpName.BW_matmul", ins := [237, 233, 79], outs := [235, 238], params := []}
def pmNode_132 : NodeDecl := {rank := 0, op := "OpName.ReduceScatterPrim", ins := [238, 540], outs := [221], params := [2]}
def pmNode_133 : NodeDecl := {rank := 0, op := "OpName.BW_softmax", ins := [235, 232], outs := [234], params := []}
def pmNode_134 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [234, 537], outs := [231], params := [2, 3]}
def pmNode_135 : NodeDecl := {rank := 0, op := "OpName.BW_div", ins := [231, 228], outs := [230], params := [4]}
def pmNode_136 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [230, 533], outs := [227], params := [3, 1]}
def pmNode_137 : NodeDecl := {rank := 0, op := "OpName.BW_matmul", ins := [227, 203, 224], outs := [205, 226], params := []}
def pmNode_138 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [226, 529], outs := [223], params := [1, 2]}
def pmNode_139 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [223, 211], outs := [213], params := [2, 3]}
def pmNode_140 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [221, 218], outs := [220], params := [1, 2]}
def pmNode_141 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [220, 523], outs := [217], params := [1, 2]}
def pmNode_142 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [217, 214], outs := [216], params := [1, 16, 32]}
def pmNode_143 : NodeDecl := {rank := 0, op := "OpName.AllGatherPrim", ins := [216, 519], outs := [83], params := [2]}
def pmNode_144 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [213, 210], outs := [212], params := [1, 2]}
def pmNode_145 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [212, 515], outs := [209], params := [3, 1]}
def pmNode_146 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [209, 206], outs := [208], params := [1, 8, 64]}
def pmNode_147 : NodeDecl := {rank := 0, op := "OpName.AllGatherPrim", ins := [208, 511], outs := [82], params := [1]}
def pmNode_148 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [205, 202], outs := [204], params := [1, 2]}
def pmNode_149 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [204, 507], outs := [201], params := [2, 1]}
def pmNode_150 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [201, 198], outs := [200], params := [1, 8, 64]}
def pmNode_151 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [200, 503], outs := [190], params := [1, 2]}
def pmNode_152 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [83, 195, 53], outs := [197, 54], params := []}
def pmNode_153 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [197, 500], outs := [298], params := [2, 1]}
def pmNode_154 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [82, 192, 50], outs := [194, 51], params := []}
def pmNode_155 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [194, 497], outs := [296], params := [2, 1]}
def pmNode_156 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [190, 88, 47], outs := [191, 48], params := []}
def pmNode_157 : NodeDecl := {rank := 0, op := "OpName.ReduceScatterPrim", ins := [191, 493], outs := [294], params := [1]}
def pmNode_158 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [294, 296, 298], outs := [188], params := []}
def pmNode_159 : NodeDecl := {rank := 0, op := "OpName.BW_layernorm", ins := [188, 185, 9, 10], outs := [187, 43, 45], params := []}
def pmNode_160 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [187, 490], outs := [292], params := [1, 2]}
def pmNode_161 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [292, 255], outs := [184], params := []}
def pmNode_162 : NodeDecl := {rank := 0, op := "OpName.BW_add", ins := [184, 179, 180], outs := [182, 183], params := []}
def pmNode_163 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [183, 486], outs := [178], params := [2, 1]}
def pmNode_164 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [178, 175, 8], outs := [176, 41], params := []}
def pmNode_165 : NodeDecl := {rank := 0, op := "OpName.BW_gelu", ins := [176, 173], outs := [174], params := []}
def pmNode_166 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [174, 170, 7], outs := [172, 39], params := []}
def pmNode_167 : NodeDecl := {rank := 0, op := "OpName.BW_layernorm", ins := [172, 169, 5, 6], outs := [171, 35, 37], params := []}
def pmNode_168 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [171, 474], outs := [290], params := [1, 2]}
def pmNode_169 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [290, 182], outs := [168], params := []}
def pmNode_170 : NodeDecl := {rank := 0, op := "OpName.BW_add", ins := [168, 163, 164], outs := [166, 167], params := []}
def pmNode_171 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [167, 470], outs := [162], params := [2, 1]}
def pmNode_172 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [162, 159, 4], outs := [161, 33], params := []}
def pmNode_173 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [161, 464], outs := [158], params := [1, 2]}
def pmNode_174 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [158, 155], outs := [157], params := [1, 16, 2, 16]}
def pmNode_175 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [157, 460], outs := [154], params := [2, 1]}
def pmNode_176 : NodeDecl := {rank := 0, op := "OpName.BW_contiguous", ins := [154, 151], outs := [152], params := []}
def pmNode_177 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [152, 147], outs := [149], params := [1, 2]}
def pmNode_178 : NodeDecl := {rank := 0, op := "OpName.BW_matmul", ins := [149, 146, 78], outs := [148, 150], params := []}
def pmNode_179 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [148, 452], outs := [145], params := [2, 1]}
def pmNode_180 : NodeDecl := {rank := 0, op := "OpName.ReduceScatterPrim", ins := [150, 451], outs := [129], params := [2]}
def pmNode_181 : NodeDecl := {rank := 0, op := "OpName.BW_softmax", ins := [145, 142], outs := [144], params := []}
def pmNode_182 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [144, 447], outs := [141], params := [1, 3]}
def pmNode_183 : NodeDecl := {rank := 0, op := "OpName.BW_div", ins := [141, 138], outs := [140], params := [4]}
def pmNode_184 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [140, 443], outs := [137], params := [3, 1]}
def pmNode_185 : NodeDecl := {rank := 0, op := "OpName.BW_matmul", ins := [137, 132, 133], outs := [135, 136], params := []}
def pmNode_186 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [136, 439], outs := [131], params := [1, 2]}
def pmNode_187 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [135, 438], outs := [117], params := [1, 3]}
def pmNode_188 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [131, 121], outs := [123], params := [2, 3]}
def pmNode_189 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [129, 125], outs := [127], params := [1, 2]}
def pmNode_190 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [127, 124], outs := [126], params := [1, 8, 64]}
def pmNode_191 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [126, 429], outs := [110], params := [1, 2]}
def pmNode_192 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [123, 120], outs := [122], params := [1, 2]}
def pmNode_193 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [122, 425], outs := [119], params := [3, 2]}
def pmNode_194 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [119, 106], outs := [107], params := [1, 16, 32]}
def pmNode_195 : NodeDecl := {rank := 0, op := "OpName.BW_transpose", ins := [117, 114], outs := [116], params := [1, 2]}
def pmNode_196 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [116, 419], outs := [113], params := [3, 1]}
def pmNode_197 : NodeDecl := {rank := 0, op := "OpName.BW_view", ins := [113, 103], outs := [105], params := [1, 8, 64]}
def pmNode_198 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [110, 87, 30], outs := [111, 31], params := []}
def pmNode_199 : NodeDecl := {rank := 0, op := "OpName.ReduceScatterPrim", ins := [111, 413], outs := [288], params := [1]}
def pmNode_200 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [107, 86, 27], outs := [108, 28], params := []}
def pmNode_201 : NodeDecl := {rank := 0, op := "OpName.ReduceScatterPrim", ins := [108, 410], outs := [286], params := [1]}
def pmNode_202 : NodeDecl := {rank := 0, op := "OpName.BW_linear", ins := [105, 102, 3], outs := [104, 25], params := []}
def pmNode_203 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [104, 286, 288], outs := [101], params := []}
def pmNode_204 : NodeDecl := {rank := 0, op := "OpName.BW_layernorm", ins := [101, 98, 1, 2], outs := [100, 21, 23], params := []}
def pmNode_205 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [100, 403], outs := [284], params := [1, 2]}
def pmNode_206 : NodeDecl := {rank := 0, op := "OpName.BW_multiref", ins := [284, 166], outs := [97], params := []}
def pmNode_207 : NodeDecl := {rank := 0, op := "OpName.BW_add", ins := [97, 89, 94], outs := [90, 96], params := []}
def pmNode_208 : NodeDecl := {rank := 0, op := "OpName.AllToAllPrim", ins := [96, 399], outs := [93], params := [2, 1]}
def pmNode_209 : NodeDecl := {rank := 0, op := "OpName.BW_embedding", ins := [93, 91, 0], outs := [19], params := []}
def pmNode_210 : NodeDecl := {rank := 0, op := "OpName.BW_embedding", ins := [90, 75, 16], outs := [17], params := []}
def pmNode_211 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [19, 322, 625, 928], outs := [20], params := []}
def pmNode_212 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [21, 324, 627, 930], outs := [22], params := []}
def pmNode_213 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [23, 326, 629, 932], outs := [24], params := []}
def pmNode_214 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [59, 362, 665, 968], outs := [60], params := []}
def pmNode_215 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [25, 328, 631, 934], outs := [26], params := []}
def pmNode_216 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [61, 364, 667, 970], outs := [62], params := []}
def pmNode_217 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [66, 369, 672, 975], outs := [67], params := []}
def pmNode_218 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [68, 371, 674, 977], outs := [69], params := []}
def pmNode_219 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [70, 373, 676, 979], outs := [71], params := []}
def pmNode_220 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [33, 336, 639, 942], outs := [34], params := []}
def pmNode_221 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [35, 338, 641, 944], outs := [36], params := []}
def pmNode_222 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [37, 340, 643, 946], outs := [38], params := []}
def pmNode_223 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [39, 342, 645, 948], outs := [40], params := []}
def pmNode_224 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [41, 344, 647, 950], outs := [42], params := []}
def pmNode_225 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [43, 346, 649, 952], outs := [44], params := []}
def pmNode_226 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [45, 348, 651, 954], outs := [46], params := []}
def pmNode_227 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [17, 623], outs := [18], params := []}
def pmNode_228 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [57, 663], outs := [58], params := []}
def pmNode_229 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [28, 634], outs := [29], params := []}
def pmNode_230 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [64, 670], outs := [65], params := []}
def pmNode_231 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [31, 637], outs := [32], params := []}
def pmNode_232 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [73, 679], outs := [74], params := []}
def pmNode_233 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [48, 654], outs := [49], params := []}
def pmNode_234 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [51, 657], outs := [52], params := []}
def pmNode_235 : NodeDecl := {rank := 0, op := "OpName.CROSS_DP_WRED", ins := [54, 660], outs := [55], params := []}
def pmNode_236 : NodeDecl := {rank := 1, op := "OpName.DATALOADER", ins := [], outs := [378, 379], params := []}
theorem pmNode_236_blocked (g : GraphDecl) (s : Store) (peer : Nat → Tid) :
    SourceScopedEval.step g (.group none) peer s pmNode_236 = none := rfl
#print axioms pmNode_236_blocked
def pmNode_237 : NodeDecl := {rank := 1, op := "OpName.FW_embedding", ins := [378, 319], outs := [392], params := []}
def pmNode_238 : NodeDecl := {rank := 1, op := "OpName.ChunkPrim", ins := [379], outs := [394], params := [1]}
def pmNode_239 : NodeDecl := {rank := 1, op := "OpName.FW_embedding", ins := [394, 303], outs := [395], params := []}
def pmNode_240 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [92, 395], outs := [397], params := [1, 2]}
def pmNode_241 : NodeDecl := {rank := 1, op := "OpName.FW_add", ins := [392, 397], outs := [398], params := []}
def pmNode_242 : NodeDecl := {rank := 1, op := "OpName.FW_multiref", ins := [398], outs := [586, 466], params := [2]}
def pmNode_243 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [283, 586], outs := [401], params := [2, 1]}
def pmNode_244 : NodeDecl := {rank := 1, op := "OpName.FW_layernorm", ins := [401, 304, 305], outs := [402], params := []}
def pmNode_245 : NodeDecl := {rank := 1, op := "OpName.FW_multiref", ins := [402], outs := [405, 588, 590], params := [3]}
def pmNode_246 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [405, 306], outs := [406], params := []}
def pmNode_247 : NodeDecl := {rank := 1, op := "OpName.AllGatherPrim", ins := [285, 588], outs := [389], params := [1]}
def pmNode_248 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [389, 330], outs := [409], params := []}
def pmNode_249 : NodeDecl := {rank := 1, op := "OpName.AllGatherPrim", ins := [287, 590], outs := [390], params := [1]}
def pmNode_250 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [390, 333], outs := [412], params := []}
def pmNode_251 : NodeDecl := {rank := 1, op := "OpName.FW_view", ins := [406], outs := [415], params := [1, 8, 4, 16]}
def pmNode_252 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [112, 415], outs := [417], params := [1, 3]}
def pmNode_253 : NodeDecl := {rank := 1, op := "OpName.FW_transpose", ins := [417], outs := [418], params := [1, 2]}
def pmNode_254 : NodeDecl := {rank := 1, op := "OpName.FW_view", ins := [409], outs := [421], params := [1, 16, 2, 16]}
def pmNode_255 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [118, 421], outs := [423], params := [2, 3]}
def pmNode_256 : NodeDecl := {rank := 1, op := "OpName.FW_transpose", ins := [423], outs := [424], params := [1, 2]}
def pmNode_257 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [109, 412], outs := [427], params := [2, 1]}
def pmNode_258 : NodeDecl := {rank := 1, op := "OpName.FW_view", ins := [427], outs := [428], params := [1, 8, 4, 16]}
def pmNode_259 : NodeDecl := {rank := 1, op := "OpName.FW_transpose", ins := [428], outs := [431], params := [1, 2]}
def pmNode_260 : NodeDecl := {rank := 1, op := "OpName.FW_transpose", ins := [424], outs := [433], params := [2, 3]}
def pmNode_261 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [115, 418], outs := [435], params := [3, 1]}
def pmNode_262 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [130, 433], outs := [436], params := [2, 1]}
def pmNode_263 : NodeDecl := {rank := 1, op := "OpName.FW_matmul", ins := [435, 436], outs := [437], params := []}
def pmNode_264 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [134, 437], outs := [441], params := [1, 3]}
def pmNode_265 : NodeDecl := {rank := 1, op := "OpName.FW_div", ins := [441], outs := [442], params := [4]}
def pmNode_266 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [139, 442], outs := [445], params := [3, 1]}
def pmNode_267 : NodeDecl := {rank := 1, op := "OpName.FW_softmax", ins := [445], outs := [446], params := []}
def pmNode_268 : NodeDecl := {rank := 1, op := "OpName.AllGatherPrim", ins := [128, 431], outs := [381], params := [2]}
def pmNode_269 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [143, 446], outs := [449], params := [1, 2]}
def pmNode_270 : NodeDecl := {rank := 1, op := "OpName.FW_matmul", ins := [449, 381], outs := [450], params := []}
def pmNode_271 : NodeDecl := {rank := 1, op := "OpName.FW_transpose", ins := [450], outs := [454], params := [1, 2]}
def pmNode_272 : NodeDecl := {rank := 1, op := "OpName.FW_contiguous", ins := [454], outs := [456], params := []}
def pmNode_273 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [153, 456], outs := [458], params := [1, 2]}
def pmNode_274 : NodeDecl := {rank := 1, op := "OpName.FW_view", ins := [458], outs := [459], params := [1, 16, 32]}
def pmNode_275 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [156, 459], outs := [462], params := [2, 1]}
def pmNode_276 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [462, 307], outs := [463], params := []}
def pmNode_277 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [160, 463], outs := [467], params := [1, 2]}
def pmNode_278 : NodeDecl := {rank := 1, op := "OpName.FW_add", ins := [466, 467], outs := [468], params := []}
def pmNode_279 : NodeDecl := {rank := 1, op := "OpName.FW_multiref", ins := [468], outs := [592, 482], params := [2]}
def pmNode_280 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [289, 592], outs := [472], params := [2, 1]}
def pmNode_281 : NodeDecl := {rank := 1, op := "OpName.FW_layernorm", ins := [472, 308, 309], outs := [473], params := []}
def pmNode_282 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [473, 310], outs := [476], params := []}
def pmNode_283 : NodeDecl := {rank := 1, op := "OpName.FW_gelu", ins := [476], outs := [478], params := []}
def pmNode_284 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [478, 311], outs := [480], params := []}
def pmNode_285 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [177, 480], outs := [483], params := [1, 2]}
def pmNode_286 : NodeDecl := {rank := 1, op := "OpName.FW_add", ins := [482, 483], outs := [484], params := []}
def pmNode_287 : NodeDecl := {rank := 1, op := "OpName.FW_multiref", ins := [484], outs := [594, 555], params := [2]}
def pmNode_288 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [291, 594], outs := [488], params := [2, 1]}
def pmNode_289 : NodeDecl := {rank := 1, op := "OpName.FW_layernorm", ins := [488, 312, 313], outs := [489], params := []}
def pmNode_290 : NodeDecl := {rank := 1, op := "OpName.FW_multiref", ins := [489], outs := [596, 598, 600], params := [3]}
def pmNode_291 : NodeDecl := {rank := 1, op := "OpName.AllGatherPrim", ins := [293, 596], outs := [391], params := [1]}
def pmNode_292 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [391, 350], outs := [492], params := []}
def pmNode_293 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [295, 598], outs := [495], params := [1, 2]}
def pmNode_294 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [495, 353], outs := [496], params := []}
def pmNode_295 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [297, 600], outs := [498], params := [1, 2]}
def pmNode_296 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [498, 356], outs := [499], params := []}
def pmNode_297 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [189, 492], outs := [501], params := [2, 1]}
def pmNode_298 : NodeDecl := {rank := 1, op := "OpName.FW_view", ins := [501], outs := [502], params := [1, 8, 4, 16]}
def pmNode_299 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [199, 502], outs := [505], params := [1, 2]}
def pmNode_300 : NodeDecl := {rank := 1, op := "OpName.FW_transpose", ins := [505], outs := [506], params := [1, 2]}
def pmNode_301 : NodeDecl := {rank := 1, op := "OpName.ReduceScatterPrim", ins := [193, 496], outs := [509], params := [1]}
def pmNode_302 : NodeDecl := {rank := 1, op := "OpName.FW_view", ins := [509], outs := [510], params := [1, 8, 4, 16]}
def pmNode_303 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [207, 510], outs := [513], params := [1, 3]}
def pmNode_304 : NodeDecl := {rank := 1, op := "OpName.FW_transpose", ins := [513], outs := [514], params := [1, 2]}
def pmNode_305 : NodeDecl := {rank := 1, op := "OpName.ReduceScatterPrim", ins := [196, 499], outs := [517], params := [2]}
def pmNode_306 : NodeDecl := {rank := 1, op := "OpName.FW_view", ins := [517], outs := [518], params := [1, 16, 2, 16]}
def pmNode_307 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [215, 518], outs := [521], params := [2, 1]}
def pmNode_308 : NodeDecl := {rank := 1, op := "OpName.FW_transpose", ins := [521], outs := [522], params := [1, 2]}
def pmNode_309 : NodeDecl := {rank := 1, op := "OpName.FW_transpose", ins := [514], outs := [525], params := [2, 3]}
def pmNode_310 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [222, 525], outs := [527], params := [2, 1]}
def pmNode_311 : NodeDecl := {rank := 1, op := "OpName.FW_matmul", ins := [506, 527], outs := [528], params := []}
def pmNode_312 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [225, 528], outs := [531], params := [1, 3]}
def pmNode_313 : NodeDecl := {rank := 1, op := "OpName.FW_div", ins := [531], outs := [532], params := [4]}
def pmNode_314 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [229, 532], outs := [535], params := [3, 2]}
def pmNode_315 : NodeDecl := {rank := 1, op := "OpName.FW_softmax", ins := [535], outs := [536], params := []}
def pmNode_316 : NodeDecl := {rank := 1, op := "OpName.AllGatherPrim", ins := [219, 522], outs := [382], params := [2]}
def pmNode_317 : NodeDecl := {rank := 1, op := "OpName.FW_matmul", ins := [536, 382], outs := [539], params := []}
def pmNode_318 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [236, 539], outs := [542], params := [2, 1]}
def pmNode_319 : NodeDecl := {rank := 1, op := "OpName.FW_transpose", ins := [542], outs := [543], params := [1, 2]}
def pmNode_320 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [240, 543], outs := [546], params := [2, 1]}
def pmNode_321 : NodeDecl := {rank := 1, op := "OpName.FW_contiguous", ins := [546], outs := [547], params := []}
def pmNode_322 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [244, 547], outs := [550], params := [1, 2]}
def pmNode_323 : NodeDecl := {rank := 1, op := "OpName.FW_view", ins := [550], outs := [551], params := [1, 16, 32]}
def pmNode_324 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [551, 359], outs := [554], params := []}
def pmNode_325 : NodeDecl := {rank := 1, op := "OpName.ReduceScatterPrim", ins := [251, 554], outs := [556], params := [2]}
def pmNode_326 : NodeDecl := {rank := 1, op := "OpName.FW_add", ins := [555, 556], outs := [557], params := []}
def pmNode_327 : NodeDecl := {rank := 1, op := "OpName.FW_multiref", ins := [557], outs := [602, 604], params := [2]}
def pmNode_328 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [299, 602], outs := [561], params := [2, 1]}
def pmNode_329 : NodeDecl := {rank := 1, op := "OpName.FW_layernorm", ins := [561, 314, 315], outs := [562], params := []}
def pmNode_330 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [259, 562], outs := [565], params := [1, 2]}
def pmNode_331 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [565, 366], outs := [566], params := []}
def pmNode_332 : NodeDecl := {rank := 1, op := "OpName.ReduceScatterPrim", ins := [263, 566], outs := [568], params := [1]}
def pmNode_333 : NodeDecl := {rank := 1, op := "OpName.FW_gelu", ins := [568], outs := [569], params := []}
def pmNode_334 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [569, 316], outs := [572], params := []}
def pmNode_335 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [301, 604], outs := [574], params := [2, 1]}
def pmNode_336 : NodeDecl := {rank := 1, op := "OpName.FW_add", ins := [574, 572], outs := [575], params := []}
def pmNode_337 : NodeDecl := {rank := 1, op := "OpName.FW_layernorm", ins := [575, 317, 318], outs := [578], params := []}
def pmNode_338 : NodeDecl := {rank := 1, op := "OpName.AllGatherPrim", ins := [275, 578], outs := [383], params := [1]}
def pmNode_339 : NodeDecl := {rank := 1, op := "OpName.FW_linear", ins := [383, 375], outs := [580], params := []}
def pmNode_340 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [277, 580], outs := [583], params := [2, 1]}
def pmNode_341 : NodeDecl := {rank := 1, op := "OpName.FW_sum", ins := [583], outs := [584], params := []}
def pmNode_342 : NodeDecl := {rank := 1, op := "OpName.AllReducePrim", ins := [281, 584], outs := [380], params := []}
def pmNode_343 : NodeDecl := {rank := 1, op := "OpName.BW_sum", ins := [384, 583], outs := [585], params := []}
def pmNode_344 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [282, 585], outs := [582], params := [1, 2]}
def pmNode_345 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [582, 383, 375], outs := [581, 376], params := []}
def pmNode_346 : NodeDecl := {rank := 1, op := "OpName.ReduceScatterPrim", ins := [279, 581], outs := [579], params := [1]}
def pmNode_347 : NodeDecl := {rank := 1, op := "OpName.BW_layernorm", ins := [579, 575, 317, 318], outs := [577, 371, 373], params := []}
def pmNode_348 : NodeDecl := {rank := 1, op := "OpName.BW_add", ins := [577, 574, 572], outs := [576, 573], params := []}
def pmNode_349 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [273, 576], outs := [605], params := [1, 2]}
def pmNode_350 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [573, 569, 316], outs := [571, 369], params := []}
def pmNode_351 : NodeDecl := {rank := 1, op := "OpName.BW_gelu", ins := [571, 568], outs := [570], params := []}
def pmNode_352 : NodeDecl := {rank := 1, op := "OpName.AllGatherPrim", ins := [267, 570], outs := [388], params := [1]}
def pmNode_353 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [388, 565, 366], outs := [567, 367], params := []}
def pmNode_354 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [264, 567], outs := [564], params := [2, 1]}
def pmNode_355 : NodeDecl := {rank := 1, op := "OpName.BW_layernorm", ins := [564, 561, 314, 315], outs := [563, 362, 364], params := []}
def pmNode_356 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [260, 563], outs := [603], params := [1, 2]}
def pmNode_357 : NodeDecl := {rank := 1, op := "OpName.BW_multiref", ins := [603, 605], outs := [560], params := []}
def pmNode_358 : NodeDecl := {rank := 1, op := "OpName.BW_add", ins := [560, 555, 556], outs := [558, 559], params := []}
def pmNode_359 : NodeDecl := {rank := 1, op := "OpName.AllGatherPrim", ins := [256, 559], outs := [387], params := [2]}
def pmNode_360 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [387, 551, 359], outs := [553, 360], params := []}
def pmNode_361 : NodeDecl := {rank := 1, op := "OpName.BW_view", ins := [553, 550], outs := [552], params := [1, 16, 2, 16]}
def pmNode_362 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [249, 552], outs := [549], params := [2, 1]}
def pmNode_363 : NodeDecl := {rank := 1, op := "OpName.BW_contiguous", ins := [549, 546], outs := [548], params := []}
def pmNode_364 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [245, 548], outs := [545], params := [1, 2]}
def pmNode_365 : NodeDecl := {rank := 1, op := "OpName.BW_transpose", ins := [545, 542], outs := [544], params := [1, 2]}
def pmNode_366 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [241, 544], outs := [541], params := [1, 2]}
def pmNode_367 : NodeDecl := {rank := 1, op := "OpName.BW_matmul", ins := [541, 536, 382], outs := [538, 540], params := []}
def pmNode_368 : NodeDecl := {rank := 1, op := "OpName.ReduceScatterPrim", ins := [238, 540], outs := [524], params := [2]}
def pmNode_369 : NodeDecl := {rank := 1, op := "OpName.BW_softmax", ins := [538, 535], outs := [537], params := []}
def pmNode_370 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [234, 537], outs := [534], params := [2, 3]}
def pmNode_371 : NodeDecl := {rank := 1, op := "OpName.BW_div", ins := [534, 531], outs := [533], params := [4]}
def pmNode_372 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [230, 533], outs := [530], params := [3, 1]}
def pmNode_373 : NodeDecl := {rank := 1, op := "OpName.BW_matmul", ins := [530, 506, 527], outs := [508, 529], params := []}
def pmNode_374 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [226, 529], outs := [526], params := [1, 2]}
def pmNode_375 : NodeDecl := {rank := 1, op := "OpName.BW_transpose", ins := [526, 514], outs := [516], params := [2, 3]}
def pmNode_376 : NodeDecl := {rank := 1, op := "OpName.BW_transpose", ins := [524, 521], outs := [523], params := [1, 2]}
def pmNode_377 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [220, 523], outs := [520], params := [1, 2]}
def pmNode_378 : NodeDecl := {rank := 1, op := "OpName.BW_view", ins := [520, 517], outs := [519], params := [1, 16, 32]}
def pmNode_379 : NodeDecl := {rank := 1, op := "OpName.AllGatherPrim", ins := [216, 519], outs := [386], params := [2]}
def pmNode_380 : NodeDecl := {rank := 1, op := "OpName.BW_transpose", ins := [516, 513], outs := [515], params := [1, 2]}
def pmNode_381 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [212, 515], outs := [512], params := [3, 1]}
def pmNode_382 : NodeDecl := {rank := 1, op := "OpName.BW_view", ins := [512, 509], outs := [511], params := [1, 8, 64]}
def pmNode_383 : NodeDecl := {rank := 1, op := "OpName.AllGatherPrim", ins := [208, 511], outs := [385], params := [1]}
def pmNode_384 : NodeDecl := {rank := 1, op := "OpName.BW_transpose", ins := [508, 505], outs := [507], params := [1, 2]}
def pmNode_385 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [204, 507], outs := [504], params := [2, 1]}
def pmNode_386 : NodeDecl := {rank := 1, op := "OpName.BW_view", ins := [504, 501], outs := [503], params := [1, 8, 64]}
def pmNode_387 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [200, 503], outs := [494], params := [1, 2]}
def pmNode_388 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [386, 498, 356], outs := [500, 357], params := []}
def pmNode_389 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [197, 500], outs := [601], params := [2, 1]}
def pmNode_390 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [385, 495, 353], outs := [497, 354], params := []}
def pmNode_391 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [194, 497], outs := [599], params := [2, 1]}
def pmNode_392 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [494, 391, 350], outs := [493, 351], params := []}
def pmNode_393 : NodeDecl := {rank := 1, op := "OpName.ReduceScatterPrim", ins := [191, 493], outs := [597], params := [1]}
def pmNode_394 : NodeDecl := {rank := 1, op := "OpName.BW_multiref", ins := [597, 599, 601], outs := [491], params := []}
def pmNode_395 : NodeDecl := {rank := 1, op := "OpName.BW_layernorm", ins := [491, 488, 312, 313], outs := [490, 346, 348], params := []}
def pmNode_396 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [187, 490], outs := [595], params := [1, 2]}
def pmNode_397 : NodeDecl := {rank := 1, op := "OpName.BW_multiref", ins := [595, 558], outs := [487], params := []}
def pmNode_398 : NodeDecl := {rank := 1, op := "OpName.BW_add", ins := [487, 482, 483], outs := [485, 486], params := []}
def pmNode_399 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [183, 486], outs := [481], params := [2, 1]}
def pmNode_400 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [481, 478, 311], outs := [479, 344], params := []}
def pmNode_401 : NodeDecl := {rank := 1, op := "OpName.BW_gelu", ins := [479, 476], outs := [477], params := []}
def pmNode_402 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [477, 473, 310], outs := [475, 342], params := []}
def pmNode_403 : NodeDecl := {rank := 1, op := "OpName.BW_layernorm", ins := [475, 472, 308, 309], outs := [474, 338, 340], params := []}
def pmNode_404 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [171, 474], outs := [593], params := [1, 2]}
def pmNode_405 : NodeDecl := {rank := 1, op := "OpName.BW_multiref", ins := [593, 485], outs := [471], params := []}
def pmNode_406 : NodeDecl := {rank := 1, op := "OpName.BW_add", ins := [471, 466, 467], outs := [469, 470], params := []}
def pmNode_407 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [167, 470], outs := [465], params := [2, 1]}
def pmNode_408 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [465, 462, 307], outs := [464, 336], params := []}
def pmNode_409 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [161, 464], outs := [461], params := [1, 2]}
def pmNode_410 : NodeDecl := {rank := 1, op := "OpName.BW_view", ins := [461, 458], outs := [460], params := [1, 16, 2, 16]}
def pmNode_411 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [157, 460], outs := [457], params := [2, 1]}
def pmNode_412 : NodeDecl := {rank := 1, op := "OpName.BW_contiguous", ins := [457, 454], outs := [455], params := []}
def pmNode_413 : NodeDecl := {rank := 1, op := "OpName.BW_transpose", ins := [455, 450], outs := [453], params := [1, 2]}
def pmNode_414 : NodeDecl := {rank := 1, op := "OpName.BW_matmul", ins := [453, 449, 381], outs := [452, 451], params := []}
def pmNode_415 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [148, 452], outs := [448], params := [2, 1]}
def pmNode_416 : NodeDecl := {rank := 1, op := "OpName.ReduceScatterPrim", ins := [150, 451], outs := [432], params := [2]}
def pmNode_417 : NodeDecl := {rank := 1, op := "OpName.BW_softmax", ins := [448, 445], outs := [447], params := []}
def pmNode_418 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [144, 447], outs := [444], params := [1, 3]}
def pmNode_419 : NodeDecl := {rank := 1, op := "OpName.BW_div", ins := [444, 441], outs := [443], params := [4]}
def pmNode_420 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [140, 443], outs := [440], params := [3, 1]}
def pmNode_421 : NodeDecl := {rank := 1, op := "OpName.BW_matmul", ins := [440, 435, 436], outs := [438, 439], params := []}
def pmNode_422 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [136, 439], outs := [434], params := [1, 2]}
def pmNode_423 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [135, 438], outs := [420], params := [1, 3]}
def pmNode_424 : NodeDecl := {rank := 1, op := "OpName.BW_transpose", ins := [434, 424], outs := [426], params := [2, 3]}
def pmNode_425 : NodeDecl := {rank := 1, op := "OpName.BW_transpose", ins := [432, 428], outs := [430], params := [1, 2]}
def pmNode_426 : NodeDecl := {rank := 1, op := "OpName.BW_view", ins := [430, 427], outs := [429], params := [1, 8, 64]}
def pmNode_427 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [126, 429], outs := [414], params := [1, 2]}
def pmNode_428 : NodeDecl := {rank := 1, op := "OpName.BW_transpose", ins := [426, 423], outs := [425], params := [1, 2]}
def pmNode_429 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [122, 425], outs := [422], params := [3, 2]}
def pmNode_430 : NodeDecl := {rank := 1, op := "OpName.BW_view", ins := [422, 409], outs := [411], params := [1, 16, 32]}
def pmNode_431 : NodeDecl := {rank := 1, op := "OpName.BW_transpose", ins := [420, 417], outs := [419], params := [1, 2]}
def pmNode_432 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [116, 419], outs := [416], params := [3, 1]}
def pmNode_433 : NodeDecl := {rank := 1, op := "OpName.BW_view", ins := [416, 406], outs := [408], params := [1, 8, 64]}
def pmNode_434 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [414, 390, 333], outs := [413, 334], params := []}
def pmNode_435 : NodeDecl := {rank := 1, op := "OpName.ReduceScatterPrim", ins := [111, 413], outs := [591], params := [1]}
def pmNode_436 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [411, 389, 330], outs := [410, 331], params := []}
def pmNode_437 : NodeDecl := {rank := 1, op := "OpName.ReduceScatterPrim", ins := [108, 410], outs := [589], params := [1]}
def pmNode_438 : NodeDecl := {rank := 1, op := "OpName.BW_linear", ins := [408, 405, 306], outs := [407, 328], params := []}
def pmNode_439 : NodeDecl := {rank := 1, op := "OpName.BW_multiref", ins := [407, 589, 591], outs := [404], params := []}
def pmNode_440 : NodeDecl := {rank := 1, op := "OpName.BW_layernorm", ins := [404, 401, 304, 305], outs := [403, 324, 326], params := []}
def pmNode_441 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [100, 403], outs := [587], params := [1, 2]}
def pmNode_442 : NodeDecl := {rank := 1, op := "OpName.BW_multiref", ins := [587, 469], outs := [400], params := []}
def pmNode_443 : NodeDecl := {rank := 1, op := "OpName.BW_add", ins := [400, 392, 397], outs := [393, 399], params := []}
def pmNode_444 : NodeDecl := {rank := 1, op := "OpName.AllToAllPrim", ins := [96, 399], outs := [396], params := [2, 1]}
def pmNode_445 : NodeDecl := {rank := 1, op := "OpName.BW_embedding", ins := [396, 394, 303], outs := [322], params := []}
def pmNode_446 : NodeDecl := {rank := 1, op := "OpName.BW_embedding", ins := [393, 378, 319], outs := [320], params := []}
def pmNode_447 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [19, 322, 625, 928], outs := [323], params := []}
def pmNode_448 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [21, 324, 627, 930], outs := [325], params := []}
def pmNode_449 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [23, 326, 629, 932], outs := [327], params := []}
def pmNode_450 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [59, 362, 665, 968], outs := [363], params := []}
def pmNode_451 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [25, 328, 631, 934], outs := [329], params := []}
def pmNode_452 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [61, 364, 667, 970], outs := [365], params := []}
def pmNode_453 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [66, 369, 672, 975], outs := [370], params := []}
def pmNode_454 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [68, 371, 674, 977], outs := [372], params := []}
def pmNode_455 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [70, 373, 676, 979], outs := [374], params := []}
def pmNode_456 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [33, 336, 639, 942], outs := [337], params := []}
def pmNode_457 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [35, 338, 641, 944], outs := [339], params := []}
def pmNode_458 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [37, 340, 643, 946], outs := [341], params := []}
def pmNode_459 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [39, 342, 645, 948], outs := [343], params := []}
def pmNode_460 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [41, 344, 647, 950], outs := [345], params := []}
def pmNode_461 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [43, 346, 649, 952], outs := [347], params := []}
def pmNode_462 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [45, 348, 651, 954], outs := [349], params := []}
def pmNode_463 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [320, 926], outs := [321], params := []}
def pmNode_464 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [360, 966], outs := [361], params := []}
def pmNode_465 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [331, 937], outs := [332], params := []}
def pmNode_466 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [367, 973], outs := [368], params := []}
def pmNode_467 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [334, 940], outs := [335], params := []}
def pmNode_468 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [376, 982], outs := [377], params := []}
def pmNode_469 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [351, 957], outs := [352], params := []}
def pmNode_470 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [354, 960], outs := [355], params := []}
def pmNode_471 : NodeDecl := {rank := 1, op := "OpName.CROSS_DP_WRED", ins := [357, 963], outs := [358], params := []}
def pmNode_472 : NodeDecl := {rank := 2, op := "OpName.DATALOADER", ins := [], outs := [681, 682], params := []}
theorem pmNode_472_blocked (g : GraphDecl) (s : Store) (peer : Nat → Tid) :
    SourceScopedEval.step g (.group none) peer s pmNode_472 = none := rfl
#print axioms pmNode_472_blocked
def pmNode_473 : NodeDecl := {rank := 2, op := "OpName.FW_embedding", ins := [681, 622], outs := [695], params := []}
def pmNode_474 : NodeDecl := {rank := 2, op := "OpName.ChunkPrim", ins := [682], outs := [697], params := [1]}
def pmNode_475 : NodeDecl := {rank := 2, op := "OpName.FW_embedding", ins := [697, 606], outs := [698], params := []}
def pmNode_476 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [698, 1001], outs := [700], params := [1, 2]}
def pmNode_477 : NodeDecl := {rank := 2, op := "OpName.FW_add", ins := [695, 700], outs := [701], params := []}
def pmNode_478 : NodeDecl := {rank := 2, op := "OpName.FW_multiref", ins := [701], outs := [889, 769], params := [2]}
def pmNode_479 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [889, 1192], outs := [704], params := [2, 1]}
def pmNode_480 : NodeDecl := {rank := 2, op := "OpName.FW_layernorm", ins := [704, 607, 608], outs := [705], params := []}
def pmNode_481 : NodeDecl := {rank := 2, op := "OpName.FW_multiref", ins := [705], outs := [708, 891, 893], params := [3]}
def pmNode_482 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [708, 609], outs := [709], params := []}
def pmNode_483 : NodeDecl := {rank := 2, op := "OpName.AllGatherPrim", ins := [891, 1194], outs := [692], params := [1]}
def pmNode_484 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [692, 633], outs := [712], params := []}
def pmNode_485 : NodeDecl := {rank := 2, op := "OpName.AllGatherPrim", ins := [893, 1196], outs := [693], params := [1]}
def pmNode_486 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [693, 636], outs := [715], params := []}
def pmNode_487 : NodeDecl := {rank := 2, op := "OpName.FW_view", ins := [709], outs := [718], params := [1, 8, 4, 16]}
def pmNode_488 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [718, 1021], outs := [720], params := [1, 3]}
def pmNode_489 : NodeDecl := {rank := 2, op := "OpName.FW_transpose", ins := [720], outs := [721], params := [1, 2]}
def pmNode_490 : NodeDecl := {rank := 2, op := "OpName.FW_view", ins := [712], outs := [724], params := [1, 16, 2, 16]}
def pmNode_491 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [724, 1027], outs := [726], params := [2, 3]}
def pmNode_492 : NodeDecl := {rank := 2, op := "OpName.FW_transpose", ins := [726], outs := [727], params := [1, 2]}
def pmNode_493 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [715, 1018], outs := [730], params := [2, 1]}
def pmNode_494 : NodeDecl := {rank := 2, op := "OpName.FW_view", ins := [730], outs := [731], params := [1, 8, 4, 16]}
def pmNode_495 : NodeDecl := {rank := 2, op := "OpName.FW_transpose", ins := [731], outs := [734], params := [1, 2]}
def pmNode_496 : NodeDecl := {rank := 2, op := "OpName.FW_transpose", ins := [727], outs := [736], params := [2, 3]}
def pmNode_497 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [721, 1024], outs := [738], params := [3, 1]}
def pmNode_498 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [736, 1039], outs := [739], params := [2, 1]}
def pmNode_499 : NodeDecl := {rank := 2, op := "OpName.FW_matmul", ins := [738, 739], outs := [740], params := []}
def pmNode_500 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [740, 1043], outs := [744], params := [1, 3]}
def pmNode_501 : NodeDecl := {rank := 2, op := "OpName.FW_div", ins := [744], outs := [745], params := [4]}
def pmNode_502 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [745, 1048], outs := [748], params := [3, 1]}
def pmNode_503 : NodeDecl := {rank := 2, op := "OpName.FW_softmax", ins := [748], outs := [749], params := []}
def pmNode_504 : NodeDecl := {rank := 2, op := "OpName.AllGatherPrim", ins := [734, 1037], outs := [684], params := [2]}
def pmNode_505 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [749, 1052], outs := [752], params := [1, 2]}
def pmNode_506 : NodeDecl := {rank := 2, op := "OpName.FW_matmul", ins := [752, 684], outs := [753], params := []}
def pmNode_507 : NodeDecl := {rank := 2, op := "OpName.FW_transpose", ins := [753], outs := [757], params := [1, 2]}
def pmNode_508 : NodeDecl := {rank := 2, op := "OpName.FW_contiguous", ins := [757], outs := [759], params := []}
def pmNode_509 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [759, 1062], outs := [761], params := [1, 2]}
def pmNode_510 : NodeDecl := {rank := 2, op := "OpName.FW_view", ins := [761], outs := [762], params := [1, 16, 32]}
def pmNode_511 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [762, 1065], outs := [765], params := [2, 1]}
def pmNode_512 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [765, 610], outs := [766], params := []}
def pmNode_513 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [766, 1069], outs := [770], params := [1, 2]}
def pmNode_514 : NodeDecl := {rank := 2, op := "OpName.FW_add", ins := [769, 770], outs := [771], params := []}
def pmNode_515 : NodeDecl := {rank := 2, op := "OpName.FW_multiref", ins := [771], outs := [895, 785], params := [2]}
def pmNode_516 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [895, 1198], outs := [775], params := [2, 1]}
def pmNode_517 : NodeDecl := {rank := 2, op := "OpName.FW_layernorm", ins := [775, 611, 612], outs := [776], params := []}
def pmNode_518 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [776, 613], outs := [779], params := []}
def pmNode_519 : NodeDecl := {rank := 2, op := "OpName.FW_gelu", ins := [779], outs := [781], params := []}
def pmNode_520 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [781, 614], outs := [783], params := []}
def pmNode_521 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [783, 1086], outs := [786], params := [1, 2]}
def pmNode_522 : NodeDecl := {rank := 2, op := "OpName.FW_add", ins := [785, 786], outs := [787], params := []}
def pmNode_523 : NodeDecl := {rank := 2, op := "OpName.FW_multiref", ins := [787], outs := [897, 858], params := [2]}
def pmNode_524 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [897, 1200], outs := [791], params := [2, 1]}
def pmNode_525 : NodeDecl := {rank := 2, op := "OpName.FW_layernorm", ins := [791, 615, 616], outs := [792], params := []}
def pmNode_526 : NodeDecl := {rank := 2, op := "OpName.FW_multiref", ins := [792], outs := [899, 901, 903], params := [3]}
def pmNode_527 : NodeDecl := {rank := 2, op := "OpName.AllGatherPrim", ins := [899, 1202], outs := [694], params := [1]}
def pmNode_528 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [694, 653], outs := [795], params := []}
def pmNode_529 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [901, 1204], outs := [798], params := [1, 2]}
def pmNode_530 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [798, 656], outs := [799], params := []}
def pmNode_531 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [903, 1206], outs := [801], params := [1, 2]}
def pmNode_532 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [801, 659], outs := [802], params := []}
def pmNode_533 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [795, 1098], outs := [804], params := [2, 1]}
def pmNode_534 : NodeDecl := {rank := 2, op := "OpName.FW_view", ins := [804], outs := [805], params := [1, 8, 4, 16]}
def pmNode_535 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [805, 1108], outs := [808], params := [1, 2]}
def pmNode_536 : NodeDecl := {rank := 2, op := "OpName.FW_transpose", ins := [808], outs := [809], params := [1, 2]}
def pmNode_537 : NodeDecl := {rank := 2, op := "OpName.ReduceScatterPrim", ins := [799, 1102], outs := [812], params := [1]}
def pmNode_538 : NodeDecl := {rank := 2, op := "OpName.FW_view", ins := [812], outs := [813], params := [1, 8, 4, 16]}
def pmNode_539 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [813, 1116], outs := [816], params := [1, 3]}
def pmNode_540 : NodeDecl := {rank := 2, op := "OpName.FW_transpose", ins := [816], outs := [817], params := [1, 2]}
def pmNode_541 : NodeDecl := {rank := 2, op := "OpName.ReduceScatterPrim", ins := [802, 1105], outs := [820], params := [2]}
def pmNode_542 : NodeDecl := {rank := 2, op := "OpName.FW_view", ins := [820], outs := [821], params := [1, 16, 2, 16]}
def pmNode_543 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [821, 1124], outs := [824], params := [2, 1]}
def pmNode_544 : NodeDecl := {rank := 2, op := "OpName.FW_transpose", ins := [824], outs := [825], params := [1, 2]}
def pmNode_545 : NodeDecl := {rank := 2, op := "OpName.FW_transpose", ins := [817], outs := [828], params := [2, 3]}
def pmNode_546 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [828, 1131], outs := [830], params := [2, 1]}
def pmNode_547 : NodeDecl := {rank := 2, op := "OpName.FW_matmul", ins := [809, 830], outs := [831], params := []}
def pmNode_548 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [831, 1134], outs := [834], params := [1, 3]}
def pmNode_549 : NodeDecl := {rank := 2, op := "OpName.FW_div", ins := [834], outs := [835], params := [4]}
def pmNode_550 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [835, 1138], outs := [838], params := [3, 2]}
def pmNode_551 : NodeDecl := {rank := 2, op := "OpName.FW_softmax", ins := [838], outs := [839], params := []}
def pmNode_552 : NodeDecl := {rank := 2, op := "OpName.AllGatherPrim", ins := [825, 1128], outs := [685], params := [2]}
def pmNode_553 : NodeDecl := {rank := 2, op := "OpName.FW_matmul", ins := [839, 685], outs := [842], params := []}
def pmNode_554 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [842, 1145], outs := [845], params := [2, 1]}
def pmNode_555 : NodeDecl := {rank := 2, op := "OpName.FW_transpose", ins := [845], outs := [846], params := [1, 2]}
def pmNode_556 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [846, 1149], outs := [849], params := [2, 1]}
def pmNode_557 : NodeDecl := {rank := 2, op := "OpName.FW_contiguous", ins := [849], outs := [850], params := []}
def pmNode_558 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [850, 1153], outs := [853], params := [1, 2]}
def pmNode_559 : NodeDecl := {rank := 2, op := "OpName.FW_view", ins := [853], outs := [854], params := [1, 16, 32]}
def pmNode_560 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [854, 662], outs := [857], params := []}
def pmNode_561 : NodeDecl := {rank := 2, op := "OpName.ReduceScatterPrim", ins := [857, 1160], outs := [859], params := [2]}
def pmNode_562 : NodeDecl := {rank := 2, op := "OpName.FW_add", ins := [858, 859], outs := [860], params := []}
def pmNode_563 : NodeDecl := {rank := 2, op := "OpName.FW_multiref", ins := [860], outs := [905, 907], params := [2]}
def pmNode_564 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [905, 1208], outs := [864], params := [2, 1]}
def pmNode_565 : NodeDecl := {rank := 2, op := "OpName.FW_layernorm", ins := [864, 617, 618], outs := [865], params := []}
def pmNode_566 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [865, 1168], outs := [868], params := [1, 2]}
def pmNode_567 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [868, 669], outs := [869], params := []}
def pmNode_568 : NodeDecl := {rank := 2, op := "OpName.ReduceScatterPrim", ins := [869, 1172], outs := [871], params := [1]}
def pmNode_569 : NodeDecl := {rank := 2, op := "OpName.FW_gelu", ins := [871], outs := [872], params := []}
def pmNode_570 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [872, 619], outs := [875], params := []}
def pmNode_571 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [907, 1210], outs := [877], params := [2, 1]}
def pmNode_572 : NodeDecl := {rank := 2, op := "OpName.FW_add", ins := [877, 875], outs := [878], params := []}
def pmNode_573 : NodeDecl := {rank := 2, op := "OpName.FW_layernorm", ins := [878, 620, 621], outs := [881], params := []}
def pmNode_574 : NodeDecl := {rank := 2, op := "OpName.AllGatherPrim", ins := [881, 1184], outs := [686], params := [1]}
def pmNode_575 : NodeDecl := {rank := 2, op := "OpName.FW_linear", ins := [686, 678], outs := [883], params := []}
def pmNode_576 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [883, 1186], outs := [886], params := [2, 1]}
def pmNode_577 : NodeDecl := {rank := 2, op := "OpName.FW_sum", ins := [886], outs := [887], params := []}
def pmNode_578 : NodeDecl := {rank := 2, op := "OpName.AllReducePrim", ins := [887, 1190], outs := [683], params := []}
def pmNode_579 : NodeDecl := {rank := 2, op := "OpName.BW_sum", ins := [687, 886], outs := [888], params := []}
def pmNode_580 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [888, 1191], outs := [884], params := [1, 2]}
def pmNode_581 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [884, 686, 678], outs := [885, 679], params := []}
def pmNode_582 : NodeDecl := {rank := 2, op := "OpName.ReduceScatterPrim", ins := [885, 1187], outs := [882], params := [1]}
def pmNode_583 : NodeDecl := {rank := 2, op := "OpName.BW_layernorm", ins := [882, 878, 620, 621], outs := [880, 674, 676], params := []}
def pmNode_584 : NodeDecl := {rank := 2, op := "OpName.BW_add", ins := [880, 877, 875], outs := [879, 876], params := []}
def pmNode_585 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [879, 1182], outs := [908], params := [1, 2]}
def pmNode_586 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [876, 872, 619], outs := [874, 672], params := []}
def pmNode_587 : NodeDecl := {rank := 2, op := "OpName.BW_gelu", ins := [874, 871], outs := [873], params := []}
def pmNode_588 : NodeDecl := {rank := 2, op := "OpName.AllGatherPrim", ins := [873, 1176], outs := [691], params := [1]}
def pmNode_589 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [691, 868, 669], outs := [870, 670], params := []}
def pmNode_590 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [870, 1173], outs := [867], params := [2, 1]}
def pmNode_591 : NodeDecl := {rank := 2, op := "OpName.BW_layernorm", ins := [867, 864, 617, 618], outs := [866, 665, 667], params := []}
def pmNode_592 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [866, 1169], outs := [906], params := [1, 2]}
def pmNode_593 : NodeDecl := {rank := 2, op := "OpName.BW_multiref", ins := [906, 908], outs := [863], params := []}
def pmNode_594 : NodeDecl := {rank := 2, op := "OpName.BW_add", ins := [863, 858, 859], outs := [861, 862], params := []}
def pmNode_595 : NodeDecl := {rank := 2, op := "OpName.AllGatherPrim", ins := [862, 1165], outs := [690], params := [2]}
def pmNode_596 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [690, 854, 662], outs := [856, 663], params := []}
def pmNode_597 : NodeDecl := {rank := 2, op := "OpName.BW_view", ins := [856, 853], outs := [855], params := [1, 16, 2, 16]}
def pmNode_598 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [855, 1158], outs := [852], params := [2, 1]}
def pmNode_599 : NodeDecl := {rank := 2, op := "OpName.BW_contiguous", ins := [852, 849], outs := [851], params := []}
def pmNode_600 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [851, 1154], outs := [848], params := [1, 2]}
def pmNode_601 : NodeDecl := {rank := 2, op := "OpName.BW_transpose", ins := [848, 845], outs := [847], params := [1, 2]}
def pmNode_602 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [847, 1150], outs := [843], params := [1, 2]}
def pmNode_603 : NodeDecl := {rank := 2, op := "OpName.BW_matmul", ins := [843, 839, 685], outs := [841, 844], params := []}
def pmNode_604 : NodeDecl := {rank := 2, op := "OpName.ReduceScatterPrim", ins := [844, 1146], outs := [827], params := [2]}
def pmNode_605 : NodeDecl := {rank := 2, op := "OpName.BW_softmax", ins := [841, 838], outs := [840], params := []}
def pmNode_606 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [840, 1143], outs := [837], params := [2, 3]}
def pmNode_607 : NodeDecl := {rank := 2, op := "OpName.BW_div", ins := [837, 834], outs := [836], params := [4]}
def pmNode_608 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [836, 1139], outs := [833], params := [3, 1]}
def pmNode_609 : NodeDecl := {rank := 2, op := "OpName.BW_matmul", ins := [833, 809, 830], outs := [811, 832], params := []}
def pmNode_610 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [832, 1135], outs := [829], params := [1, 2]}
def pmNode_611 : NodeDecl := {rank := 2, op := "OpName.BW_transpose", ins := [829, 817], outs := [819], params := [2, 3]}
def pmNode_612 : NodeDecl := {rank := 2, op := "OpName.BW_transpose", ins := [827, 824], outs := [826], params := [1, 2]}
def pmNode_613 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [826, 1129], outs := [823], params := [1, 2]}
def pmNode_614 : NodeDecl := {rank := 2, op := "OpName.BW_view", ins := [823, 820], outs := [822], params := [1, 16, 32]}
def pmNode_615 : NodeDecl := {rank := 2, op := "OpName.AllGatherPrim", ins := [822, 1125], outs := [689], params := [2]}
def pmNode_616 : NodeDecl := {rank := 2, op := "OpName.BW_transpose", ins := [819, 816], outs := [818], params := [1, 2]}
def pmNode_617 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [818, 1121], outs := [815], params := [3, 1]}
def pmNode_618 : NodeDecl := {rank := 2, op := "OpName.BW_view", ins := [815, 812], outs := [814], params := [1, 8, 64]}
def pmNode_619 : NodeDecl := {rank := 2, op := "OpName.AllGatherPrim", ins := [814, 1117], outs := [688], params := [1]}
def pmNode_620 : NodeDecl := {rank := 2, op := "OpName.BW_transpose", ins := [811, 808], outs := [810], params := [1, 2]}
def pmNode_621 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [810, 1113], outs := [807], params := [2, 1]}
def pmNode_622 : NodeDecl := {rank := 2, op := "OpName.BW_view", ins := [807, 804], outs := [806], params := [1, 8, 64]}
def pmNode_623 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [806, 1109], outs := [796], params := [1, 2]}
def pmNode_624 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [689, 801, 659], outs := [803, 660], params := []}
def pmNode_625 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [803, 1106], outs := [904], params := [2, 1]}
def pmNode_626 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [688, 798, 656], outs := [800, 657], params := []}
def pmNode_627 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [800, 1103], outs := [902], params := [2, 1]}
def pmNode_628 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [796, 694, 653], outs := [797, 654], params := []}
def pmNode_629 : NodeDecl := {rank := 2, op := "OpName.ReduceScatterPrim", ins := [797, 1099], outs := [900], params := [1]}
def pmNode_630 : NodeDecl := {rank := 2, op := "OpName.BW_multiref", ins := [900, 902, 904], outs := [794], params := []}
def pmNode_631 : NodeDecl := {rank := 2, op := "OpName.BW_layernorm", ins := [794, 791, 615, 616], outs := [793, 649, 651], params := []}
def pmNode_632 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [793, 1096], outs := [898], params := [1, 2]}
def pmNode_633 : NodeDecl := {rank := 2, op := "OpName.BW_multiref", ins := [898, 861], outs := [790], params := []}
def pmNode_634 : NodeDecl := {rank := 2, op := "OpName.BW_add", ins := [790, 785, 786], outs := [788, 789], params := []}
def pmNode_635 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [789, 1092], outs := [784], params := [2, 1]}
def pmNode_636 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [784, 781, 614], outs := [782, 647], params := []}
def pmNode_637 : NodeDecl := {rank := 2, op := "OpName.BW_gelu", ins := [782, 779], outs := [780], params := []}
def pmNode_638 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [780, 776, 613], outs := [778, 645], params := []}
def pmNode_639 : NodeDecl := {rank := 2, op := "OpName.BW_layernorm", ins := [778, 775, 611, 612], outs := [777, 641, 643], params := []}
def pmNode_640 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [777, 1080], outs := [896], params := [1, 2]}
def pmNode_641 : NodeDecl := {rank := 2, op := "OpName.BW_multiref", ins := [896, 788], outs := [774], params := []}
def pmNode_642 : NodeDecl := {rank := 2, op := "OpName.BW_add", ins := [774, 769, 770], outs := [772, 773], params := []}
def pmNode_643 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [773, 1076], outs := [768], params := [2, 1]}
def pmNode_644 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [768, 765, 610], outs := [767, 639], params := []}
def pmNode_645 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [767, 1070], outs := [764], params := [1, 2]}
def pmNode_646 : NodeDecl := {rank := 2, op := "OpName.BW_view", ins := [764, 761], outs := [763], params := [1, 16, 2, 16]}
def pmNode_647 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [763, 1066], outs := [760], params := [2, 1]}
def pmNode_648 : NodeDecl := {rank := 2, op := "OpName.BW_contiguous", ins := [760, 757], outs := [758], params := []}
def pmNode_649 : NodeDecl := {rank := 2, op := "OpName.BW_transpose", ins := [758, 753], outs := [755], params := [1, 2]}
def pmNode_650 : NodeDecl := {rank := 2, op := "OpName.BW_matmul", ins := [755, 752, 684], outs := [754, 756], params := []}
def pmNode_651 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [754, 1058], outs := [751], params := [2, 1]}
def pmNode_652 : NodeDecl := {rank := 2, op := "OpName.ReduceScatterPrim", ins := [756, 1057], outs := [735], params := [2]}
def pmNode_653 : NodeDecl := {rank := 2, op := "OpName.BW_softmax", ins := [751, 748], outs := [750], params := []}
def pmNode_654 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [750, 1053], outs := [747], params := [1, 3]}
def pmNode_655 : NodeDecl := {rank := 2, op := "OpName.BW_div", ins := [747, 744], outs := [746], params := [4]}
def pmNode_656 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [746, 1049], outs := [743], params := [3, 1]}
def pmNode_657 : NodeDecl := {rank := 2, op := "OpName.BW_matmul", ins := [743, 738, 739], outs := [741, 742], params := []}
def pmNode_658 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [742, 1045], outs := [737], params := [1, 2]}
def pmNode_659 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [741, 1044], outs := [723], params := [1, 3]}
def pmNode_660 : NodeDecl := {rank := 2, op := "OpName.BW_transpose", ins := [737, 727], outs := [729], params := [2, 3]}
def pmNode_661 : NodeDecl := {rank := 2, op := "OpName.BW_transpose", ins := [735, 731], outs := [733], params := [1, 2]}
def pmNode_662 : NodeDecl := {rank := 2, op := "OpName.BW_view", ins := [733, 730], outs := [732], params := [1, 8, 64]}
def pmNode_663 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [732, 1035], outs := [716], params := [1, 2]}
def pmNode_664 : NodeDecl := {rank := 2, op := "OpName.BW_transpose", ins := [729, 726], outs := [728], params := [1, 2]}
def pmNode_665 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [728, 1031], outs := [725], params := [3, 2]}
def pmNode_666 : NodeDecl := {rank := 2, op := "OpName.BW_view", ins := [725, 712], outs := [713], params := [1, 16, 32]}
def pmNode_667 : NodeDecl := {rank := 2, op := "OpName.BW_transpose", ins := [723, 720], outs := [722], params := [1, 2]}
def pmNode_668 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [722, 1025], outs := [719], params := [3, 1]}
def pmNode_669 : NodeDecl := {rank := 2, op := "OpName.BW_view", ins := [719, 709], outs := [711], params := [1, 8, 64]}
def pmNode_670 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [716, 693, 636], outs := [717, 637], params := []}
def pmNode_671 : NodeDecl := {rank := 2, op := "OpName.ReduceScatterPrim", ins := [717, 1019], outs := [894], params := [1]}
def pmNode_672 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [713, 692, 633], outs := [714, 634], params := []}
def pmNode_673 : NodeDecl := {rank := 2, op := "OpName.ReduceScatterPrim", ins := [714, 1016], outs := [892], params := [1]}
def pmNode_674 : NodeDecl := {rank := 2, op := "OpName.BW_linear", ins := [711, 708, 609], outs := [710, 631], params := []}
def pmNode_675 : NodeDecl := {rank := 2, op := "OpName.BW_multiref", ins := [710, 892, 894], outs := [707], params := []}
def pmNode_676 : NodeDecl := {rank := 2, op := "OpName.BW_layernorm", ins := [707, 704, 607, 608], outs := [706, 627, 629], params := []}
def pmNode_677 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [706, 1009], outs := [890], params := [1, 2]}
def pmNode_678 : NodeDecl := {rank := 2, op := "OpName.BW_multiref", ins := [890, 772], outs := [703], params := []}
def pmNode_679 : NodeDecl := {rank := 2, op := "OpName.BW_add", ins := [703, 695, 700], outs := [696, 702], params := []}
def pmNode_680 : NodeDecl := {rank := 2, op := "OpName.AllToAllPrim", ins := [702, 1005], outs := [699], params := [2, 1]}
def pmNode_681 : NodeDecl := {rank := 2, op := "OpName.BW_embedding", ins := [699, 697, 606], outs := [625], params := []}
def pmNode_682 : NodeDecl := {rank := 2, op := "OpName.BW_embedding", ins := [696, 681, 622], outs := [623], params := []}
def pmNode_683 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [19, 322, 625, 928], outs := [626], params := []}
def pmNode_684 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [21, 324, 627, 930], outs := [628], params := []}
def pmNode_685 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [23, 326, 629, 932], outs := [630], params := []}
def pmNode_686 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [59, 362, 665, 968], outs := [666], params := []}
def pmNode_687 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [25, 328, 631, 934], outs := [632], params := []}
def pmNode_688 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [61, 364, 667, 970], outs := [668], params := []}
def pmNode_689 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [66, 369, 672, 975], outs := [673], params := []}
def pmNode_690 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [68, 371, 674, 977], outs := [675], params := []}
def pmNode_691 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [70, 373, 676, 979], outs := [677], params := []}
def pmNode_692 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [33, 336, 639, 942], outs := [640], params := []}
def pmNode_693 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [35, 338, 641, 944], outs := [642], params := []}
def pmNode_694 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [37, 340, 643, 946], outs := [644], params := []}
def pmNode_695 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [39, 342, 645, 948], outs := [646], params := []}
def pmNode_696 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [41, 344, 647, 950], outs := [648], params := []}
def pmNode_697 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [43, 346, 649, 952], outs := [650], params := []}
def pmNode_698 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [45, 348, 651, 954], outs := [652], params := []}
def pmNode_699 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [17, 623], outs := [624], params := []}
def pmNode_700 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [57, 663], outs := [664], params := []}
def pmNode_701 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [28, 634], outs := [635], params := []}
def pmNode_702 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [64, 670], outs := [671], params := []}
def pmNode_703 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [31, 637], outs := [638], params := []}
def pmNode_704 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [73, 679], outs := [680], params := []}
def pmNode_705 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [48, 654], outs := [655], params := []}
def pmNode_706 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [51, 657], outs := [658], params := []}
def pmNode_707 : NodeDecl := {rank := 2, op := "OpName.CROSS_DP_WRED", ins := [54, 660], outs := [661], params := []}
def pmNode_708 : NodeDecl := {rank := 3, op := "OpName.DATALOADER", ins := [], outs := [984, 985], params := []}
theorem pmNode_708_blocked (g : GraphDecl) (s : Store) (peer : Nat → Tid) :
    SourceScopedEval.step g (.group none) peer s pmNode_708 = none := rfl
#print axioms pmNode_708_blocked
def pmNode_709 : NodeDecl := {rank := 3, op := "OpName.FW_embedding", ins := [984, 925], outs := [998], params := []}
def pmNode_710 : NodeDecl := {rank := 3, op := "OpName.ChunkPrim", ins := [985], outs := [1000], params := [1]}
def pmNode_711 : NodeDecl := {rank := 3, op := "OpName.FW_embedding", ins := [1000, 909], outs := [1001], params := []}
def pmNode_712 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [698, 1001], outs := [1003], params := [1, 2]}
def pmNode_713 : NodeDecl := {rank := 3, op := "OpName.FW_add", ins := [998, 1003], outs := [1004], params := []}
def pmNode_714 : NodeDecl := {rank := 3, op := "OpName.FW_multiref", ins := [1004], outs := [1192, 1072], params := [2]}
def pmNode_715 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [889, 1192], outs := [1007], params := [2, 1]}
def pmNode_716 : NodeDecl := {rank := 3, op := "OpName.FW_layernorm", ins := [1007, 910, 911], outs := [1008], params := []}
def pmNode_717 : NodeDecl := {rank := 3, op := "OpName.FW_multiref", ins := [1008], outs := [1011, 1194, 1196], params := [3]}
def pmNode_718 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [1011, 912], outs := [1012], params := []}
def pmNode_719 : NodeDecl := {rank := 3, op := "OpName.AllGatherPrim", ins := [891, 1194], outs := [995], params := [1]}
def pmNode_720 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [995, 936], outs := [1015], params := []}
def pmNode_721 : NodeDecl := {rank := 3, op := "OpName.AllGatherPrim", ins := [893, 1196], outs := [996], params := [1]}
def pmNode_722 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [996, 939], outs := [1018], params := []}
def pmNode_723 : NodeDecl := {rank := 3, op := "OpName.FW_view", ins := [1012], outs := [1021], params := [1, 8, 4, 16]}
def pmNode_724 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [718, 1021], outs := [1023], params := [1, 3]}
def pmNode_725 : NodeDecl := {rank := 3, op := "OpName.FW_transpose", ins := [1023], outs := [1024], params := [1, 2]}
def pmNode_726 : NodeDecl := {rank := 3, op := "OpName.FW_view", ins := [1015], outs := [1027], params := [1, 16, 2, 16]}
def pmNode_727 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [724, 1027], outs := [1029], params := [2, 3]}
def pmNode_728 : NodeDecl := {rank := 3, op := "OpName.FW_transpose", ins := [1029], outs := [1030], params := [1, 2]}
def pmNode_729 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [715, 1018], outs := [1033], params := [2, 1]}
def pmNode_730 : NodeDecl := {rank := 3, op := "OpName.FW_view", ins := [1033], outs := [1034], params := [1, 8, 4, 16]}
def pmNode_731 : NodeDecl := {rank := 3, op := "OpName.FW_transpose", ins := [1034], outs := [1037], params := [1, 2]}
def pmNode_732 : NodeDecl := {rank := 3, op := "OpName.FW_transpose", ins := [1030], outs := [1039], params := [2, 3]}
def pmNode_733 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [721, 1024], outs := [1041], params := [3, 1]}
def pmNode_734 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [736, 1039], outs := [1042], params := [2, 1]}
def pmNode_735 : NodeDecl := {rank := 3, op := "OpName.FW_matmul", ins := [1041, 1042], outs := [1043], params := []}
def pmNode_736 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [740, 1043], outs := [1047], params := [1, 3]}
def pmNode_737 : NodeDecl := {rank := 3, op := "OpName.FW_div", ins := [1047], outs := [1048], params := [4]}
def pmNode_738 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [745, 1048], outs := [1051], params := [3, 1]}
def pmNode_739 : NodeDecl := {rank := 3, op := "OpName.FW_softmax", ins := [1051], outs := [1052], params := []}
def pmNode_740 : NodeDecl := {rank := 3, op := "OpName.AllGatherPrim", ins := [734, 1037], outs := [987], params := [2]}
def pmNode_741 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [749, 1052], outs := [1055], params := [1, 2]}
def pmNode_742 : NodeDecl := {rank := 3, op := "OpName.FW_matmul", ins := [1055, 987], outs := [1056], params := []}
def pmNode_743 : NodeDecl := {rank := 3, op := "OpName.FW_transpose", ins := [1056], outs := [1060], params := [1, 2]}
def pmNode_744 : NodeDecl := {rank := 3, op := "OpName.FW_contiguous", ins := [1060], outs := [1062], params := []}
def pmNode_745 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [759, 1062], outs := [1064], params := [1, 2]}
def pmNode_746 : NodeDecl := {rank := 3, op := "OpName.FW_view", ins := [1064], outs := [1065], params := [1, 16, 32]}
def pmNode_747 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [762, 1065], outs := [1068], params := [2, 1]}
def pmNode_748 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [1068, 913], outs := [1069], params := []}
def pmNode_749 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [766, 1069], outs := [1073], params := [1, 2]}
def pmNode_750 : NodeDecl := {rank := 3, op := "OpName.FW_add", ins := [1072, 1073], outs := [1074], params := []}
def pmNode_751 : NodeDecl := {rank := 3, op := "OpName.FW_multiref", ins := [1074], outs := [1198, 1088], params := [2]}
def pmNode_752 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [895, 1198], outs := [1078], params := [2, 1]}
def pmNode_753 : NodeDecl := {rank := 3, op := "OpName.FW_layernorm", ins := [1078, 914, 915], outs := [1079], params := []}
def pmNode_754 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [1079, 916], outs := [1082], params := []}
def pmNode_755 : NodeDecl := {rank := 3, op := "OpName.FW_gelu", ins := [1082], outs := [1084], params := []}
def pmNode_756 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [1084, 917], outs := [1086], params := []}
def pmNode_757 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [783, 1086], outs := [1089], params := [1, 2]}
def pmNode_758 : NodeDecl := {rank := 3, op := "OpName.FW_add", ins := [1088, 1089], outs := [1090], params := []}
def pmNode_759 : NodeDecl := {rank := 3, op := "OpName.FW_multiref", ins := [1090], outs := [1200, 1161], params := [2]}
def pmNode_760 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [897, 1200], outs := [1094], params := [2, 1]}
def pmNode_761 : NodeDecl := {rank := 3, op := "OpName.FW_layernorm", ins := [1094, 918, 919], outs := [1095], params := []}
def pmNode_762 : NodeDecl := {rank := 3, op := "OpName.FW_multiref", ins := [1095], outs := [1202, 1204, 1206], params := [3]}
def pmNode_763 : NodeDecl := {rank := 3, op := "OpName.AllGatherPrim", ins := [899, 1202], outs := [997], params := [1]}
def pmNode_764 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [997, 956], outs := [1098], params := []}
def pmNode_765 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [901, 1204], outs := [1101], params := [1, 2]}
def pmNode_766 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [1101, 959], outs := [1102], params := []}
def pmNode_767 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [903, 1206], outs := [1104], params := [1, 2]}
def pmNode_768 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [1104, 962], outs := [1105], params := []}
def pmNode_769 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [795, 1098], outs := [1107], params := [2, 1]}
def pmNode_770 : NodeDecl := {rank := 3, op := "OpName.FW_view", ins := [1107], outs := [1108], params := [1, 8, 4, 16]}
def pmNode_771 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [805, 1108], outs := [1111], params := [1, 2]}
def pmNode_772 : NodeDecl := {rank := 3, op := "OpName.FW_transpose", ins := [1111], outs := [1112], params := [1, 2]}
def pmNode_773 : NodeDecl := {rank := 3, op := "OpName.ReduceScatterPrim", ins := [799, 1102], outs := [1115], params := [1]}
def pmNode_774 : NodeDecl := {rank := 3, op := "OpName.FW_view", ins := [1115], outs := [1116], params := [1, 8, 4, 16]}
def pmNode_775 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [813, 1116], outs := [1119], params := [1, 3]}
def pmNode_776 : NodeDecl := {rank := 3, op := "OpName.FW_transpose", ins := [1119], outs := [1120], params := [1, 2]}
def pmNode_777 : NodeDecl := {rank := 3, op := "OpName.ReduceScatterPrim", ins := [802, 1105], outs := [1123], params := [2]}
def pmNode_778 : NodeDecl := {rank := 3, op := "OpName.FW_view", ins := [1123], outs := [1124], params := [1, 16, 2, 16]}
def pmNode_779 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [821, 1124], outs := [1127], params := [2, 1]}
def pmNode_780 : NodeDecl := {rank := 3, op := "OpName.FW_transpose", ins := [1127], outs := [1128], params := [1, 2]}
def pmNode_781 : NodeDecl := {rank := 3, op := "OpName.FW_transpose", ins := [1120], outs := [1131], params := [2, 3]}
def pmNode_782 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [828, 1131], outs := [1133], params := [2, 1]}
def pmNode_783 : NodeDecl := {rank := 3, op := "OpName.FW_matmul", ins := [1112, 1133], outs := [1134], params := []}
def pmNode_784 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [831, 1134], outs := [1137], params := [1, 3]}
def pmNode_785 : NodeDecl := {rank := 3, op := "OpName.FW_div", ins := [1137], outs := [1138], params := [4]}
def pmNode_786 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [835, 1138], outs := [1141], params := [3, 2]}
def pmNode_787 : NodeDecl := {rank := 3, op := "OpName.FW_softmax", ins := [1141], outs := [1142], params := []}
def pmNode_788 : NodeDecl := {rank := 3, op := "OpName.AllGatherPrim", ins := [825, 1128], outs := [988], params := [2]}
def pmNode_789 : NodeDecl := {rank := 3, op := "OpName.FW_matmul", ins := [1142, 988], outs := [1145], params := []}
def pmNode_790 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [842, 1145], outs := [1148], params := [2, 1]}
def pmNode_791 : NodeDecl := {rank := 3, op := "OpName.FW_transpose", ins := [1148], outs := [1149], params := [1, 2]}
def pmNode_792 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [846, 1149], outs := [1152], params := [2, 1]}
def pmNode_793 : NodeDecl := {rank := 3, op := "OpName.FW_contiguous", ins := [1152], outs := [1153], params := []}
def pmNode_794 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [850, 1153], outs := [1156], params := [1, 2]}
def pmNode_795 : NodeDecl := {rank := 3, op := "OpName.FW_view", ins := [1156], outs := [1157], params := [1, 16, 32]}
def pmNode_796 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [1157, 965], outs := [1160], params := []}
def pmNode_797 : NodeDecl := {rank := 3, op := "OpName.ReduceScatterPrim", ins := [857, 1160], outs := [1162], params := [2]}
def pmNode_798 : NodeDecl := {rank := 3, op := "OpName.FW_add", ins := [1161, 1162], outs := [1163], params := []}
def pmNode_799 : NodeDecl := {rank := 3, op := "OpName.FW_multiref", ins := [1163], outs := [1208, 1210], params := [2]}
def pmNode_800 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [905, 1208], outs := [1167], params := [2, 1]}
def pmNode_801 : NodeDecl := {rank := 3, op := "OpName.FW_layernorm", ins := [1167, 920, 921], outs := [1168], params := []}
def pmNode_802 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [865, 1168], outs := [1171], params := [1, 2]}
def pmNode_803 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [1171, 972], outs := [1172], params := []}
def pmNode_804 : NodeDecl := {rank := 3, op := "OpName.ReduceScatterPrim", ins := [869, 1172], outs := [1174], params := [1]}
def pmNode_805 : NodeDecl := {rank := 3, op := "OpName.FW_gelu", ins := [1174], outs := [1175], params := []}
def pmNode_806 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [1175, 922], outs := [1178], params := []}
def pmNode_807 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [907, 1210], outs := [1180], params := [2, 1]}
def pmNode_808 : NodeDecl := {rank := 3, op := "OpName.FW_add", ins := [1180, 1178], outs := [1181], params := []}
def pmNode_809 : NodeDecl := {rank := 3, op := "OpName.FW_layernorm", ins := [1181, 923, 924], outs := [1184], params := []}
def pmNode_810 : NodeDecl := {rank := 3, op := "OpName.AllGatherPrim", ins := [881, 1184], outs := [989], params := [1]}
def pmNode_811 : NodeDecl := {rank := 3, op := "OpName.FW_linear", ins := [989, 981], outs := [1186], params := []}
def pmNode_812 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [883, 1186], outs := [1189], params := [2, 1]}
def pmNode_813 : NodeDecl := {rank := 3, op := "OpName.FW_sum", ins := [1189], outs := [1190], params := []}
def pmNode_814 : NodeDecl := {rank := 3, op := "OpName.AllReducePrim", ins := [887, 1190], outs := [986], params := []}
def pmNode_815 : NodeDecl := {rank := 3, op := "OpName.BW_sum", ins := [990, 1189], outs := [1191], params := []}
def pmNode_816 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [888, 1191], outs := [1188], params := [1, 2]}
def pmNode_817 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [1188, 989, 981], outs := [1187, 982], params := []}
def pmNode_818 : NodeDecl := {rank := 3, op := "OpName.ReduceScatterPrim", ins := [885, 1187], outs := [1185], params := [1]}
def pmNode_819 : NodeDecl := {rank := 3, op := "OpName.BW_layernorm", ins := [1185, 1181, 923, 924], outs := [1183, 977, 979], params := []}
def pmNode_820 : NodeDecl := {rank := 3, op := "OpName.BW_add", ins := [1183, 1180, 1178], outs := [1182, 1179], params := []}
def pmNode_821 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [879, 1182], outs := [1211], params := [1, 2]}
def pmNode_822 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [1179, 1175, 922], outs := [1177, 975], params := []}
def pmNode_823 : NodeDecl := {rank := 3, op := "OpName.BW_gelu", ins := [1177, 1174], outs := [1176], params := []}
def pmNode_824 : NodeDecl := {rank := 3, op := "OpName.AllGatherPrim", ins := [873, 1176], outs := [994], params := [1]}
def pmNode_825 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [994, 1171, 972], outs := [1173, 973], params := []}
def pmNode_826 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [870, 1173], outs := [1170], params := [2, 1]}
def pmNode_827 : NodeDecl := {rank := 3, op := "OpName.BW_layernorm", ins := [1170, 1167, 920, 921], outs := [1169, 968, 970], params := []}
def pmNode_828 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [866, 1169], outs := [1209], params := [1, 2]}
def pmNode_829 : NodeDecl := {rank := 3, op := "OpName.BW_multiref", ins := [1209, 1211], outs := [1166], params := []}
def pmNode_830 : NodeDecl := {rank := 3, op := "OpName.BW_add", ins := [1166, 1161, 1162], outs := [1164, 1165], params := []}
def pmNode_831 : NodeDecl := {rank := 3, op := "OpName.AllGatherPrim", ins := [862, 1165], outs := [993], params := [2]}
def pmNode_832 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [993, 1157, 965], outs := [1159, 966], params := []}
def pmNode_833 : NodeDecl := {rank := 3, op := "OpName.BW_view", ins := [1159, 1156], outs := [1158], params := [1, 16, 2, 16]}
def pmNode_834 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [855, 1158], outs := [1155], params := [2, 1]}
def pmNode_835 : NodeDecl := {rank := 3, op := "OpName.BW_contiguous", ins := [1155, 1152], outs := [1154], params := []}
def pmNode_836 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [851, 1154], outs := [1151], params := [1, 2]}
def pmNode_837 : NodeDecl := {rank := 3, op := "OpName.BW_transpose", ins := [1151, 1148], outs := [1150], params := [1, 2]}
def pmNode_838 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [847, 1150], outs := [1147], params := [1, 2]}
def pmNode_839 : NodeDecl := {rank := 3, op := "OpName.BW_matmul", ins := [1147, 1142, 988], outs := [1144, 1146], params := []}
def pmNode_840 : NodeDecl := {rank := 3, op := "OpName.ReduceScatterPrim", ins := [844, 1146], outs := [1130], params := [2]}
def pmNode_841 : NodeDecl := {rank := 3, op := "OpName.BW_softmax", ins := [1144, 1141], outs := [1143], params := []}
def pmNode_842 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [840, 1143], outs := [1140], params := [2, 3]}
def pmNode_843 : NodeDecl := {rank := 3, op := "OpName.BW_div", ins := [1140, 1137], outs := [1139], params := [4]}
def pmNode_844 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [836, 1139], outs := [1136], params := [3, 1]}
def pmNode_845 : NodeDecl := {rank := 3, op := "OpName.BW_matmul", ins := [1136, 1112, 1133], outs := [1114, 1135], params := []}
def pmNode_846 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [832, 1135], outs := [1132], params := [1, 2]}
def pmNode_847 : NodeDecl := {rank := 3, op := "OpName.BW_transpose", ins := [1132, 1120], outs := [1122], params := [2, 3]}
def pmNode_848 : NodeDecl := {rank := 3, op := "OpName.BW_transpose", ins := [1130, 1127], outs := [1129], params := [1, 2]}
def pmNode_849 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [826, 1129], outs := [1126], params := [1, 2]}
def pmNode_850 : NodeDecl := {rank := 3, op := "OpName.BW_view", ins := [1126, 1123], outs := [1125], params := [1, 16, 32]}
def pmNode_851 : NodeDecl := {rank := 3, op := "OpName.AllGatherPrim", ins := [822, 1125], outs := [992], params := [2]}
def pmNode_852 : NodeDecl := {rank := 3, op := "OpName.BW_transpose", ins := [1122, 1119], outs := [1121], params := [1, 2]}
def pmNode_853 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [818, 1121], outs := [1118], params := [3, 1]}
def pmNode_854 : NodeDecl := {rank := 3, op := "OpName.BW_view", ins := [1118, 1115], outs := [1117], params := [1, 8, 64]}
def pmNode_855 : NodeDecl := {rank := 3, op := "OpName.AllGatherPrim", ins := [814, 1117], outs := [991], params := [1]}
def pmNode_856 : NodeDecl := {rank := 3, op := "OpName.BW_transpose", ins := [1114, 1111], outs := [1113], params := [1, 2]}
def pmNode_857 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [810, 1113], outs := [1110], params := [2, 1]}
def pmNode_858 : NodeDecl := {rank := 3, op := "OpName.BW_view", ins := [1110, 1107], outs := [1109], params := [1, 8, 64]}
def pmNode_859 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [806, 1109], outs := [1100], params := [1, 2]}
def pmNode_860 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [992, 1104, 962], outs := [1106, 963], params := []}
def pmNode_861 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [803, 1106], outs := [1207], params := [2, 1]}
def pmNode_862 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [991, 1101, 959], outs := [1103, 960], params := []}
def pmNode_863 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [800, 1103], outs := [1205], params := [2, 1]}
def pmNode_864 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [1100, 997, 956], outs := [1099, 957], params := []}
def pmNode_865 : NodeDecl := {rank := 3, op := "OpName.ReduceScatterPrim", ins := [797, 1099], outs := [1203], params := [1]}
def pmNode_866 : NodeDecl := {rank := 3, op := "OpName.BW_multiref", ins := [1203, 1205, 1207], outs := [1097], params := []}
def pmNode_867 : NodeDecl := {rank := 3, op := "OpName.BW_layernorm", ins := [1097, 1094, 918, 919], outs := [1096, 952, 954], params := []}
def pmNode_868 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [793, 1096], outs := [1201], params := [1, 2]}
def pmNode_869 : NodeDecl := {rank := 3, op := "OpName.BW_multiref", ins := [1201, 1164], outs := [1093], params := []}
def pmNode_870 : NodeDecl := {rank := 3, op := "OpName.BW_add", ins := [1093, 1088, 1089], outs := [1091, 1092], params := []}
def pmNode_871 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [789, 1092], outs := [1087], params := [2, 1]}
def pmNode_872 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [1087, 1084, 917], outs := [1085, 950], params := []}
def pmNode_873 : NodeDecl := {rank := 3, op := "OpName.BW_gelu", ins := [1085, 1082], outs := [1083], params := []}
def pmNode_874 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [1083, 1079, 916], outs := [1081, 948], params := []}
def pmNode_875 : NodeDecl := {rank := 3, op := "OpName.BW_layernorm", ins := [1081, 1078, 914, 915], outs := [1080, 944, 946], params := []}
def pmNode_876 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [777, 1080], outs := [1199], params := [1, 2]}
def pmNode_877 : NodeDecl := {rank := 3, op := "OpName.BW_multiref", ins := [1199, 1091], outs := [1077], params := []}
def pmNode_878 : NodeDecl := {rank := 3, op := "OpName.BW_add", ins := [1077, 1072, 1073], outs := [1075, 1076], params := []}
def pmNode_879 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [773, 1076], outs := [1071], params := [2, 1]}
def pmNode_880 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [1071, 1068, 913], outs := [1070, 942], params := []}
def pmNode_881 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [767, 1070], outs := [1067], params := [1, 2]}
def pmNode_882 : NodeDecl := {rank := 3, op := "OpName.BW_view", ins := [1067, 1064], outs := [1066], params := [1, 16, 2, 16]}
def pmNode_883 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [763, 1066], outs := [1063], params := [2, 1]}
def pmNode_884 : NodeDecl := {rank := 3, op := "OpName.BW_contiguous", ins := [1063, 1060], outs := [1061], params := []}
def pmNode_885 : NodeDecl := {rank := 3, op := "OpName.BW_transpose", ins := [1061, 1056], outs := [1059], params := [1, 2]}
def pmNode_886 : NodeDecl := {rank := 3, op := "OpName.BW_matmul", ins := [1059, 1055, 987], outs := [1058, 1057], params := []}
def pmNode_887 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [754, 1058], outs := [1054], params := [2, 1]}
def pmNode_888 : NodeDecl := {rank := 3, op := "OpName.ReduceScatterPrim", ins := [756, 1057], outs := [1038], params := [2]}
def pmNode_889 : NodeDecl := {rank := 3, op := "OpName.BW_softmax", ins := [1054, 1051], outs := [1053], params := []}
def pmNode_890 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [750, 1053], outs := [1050], params := [1, 3]}
def pmNode_891 : NodeDecl := {rank := 3, op := "OpName.BW_div", ins := [1050, 1047], outs := [1049], params := [4]}
def pmNode_892 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [746, 1049], outs := [1046], params := [3, 1]}
def pmNode_893 : NodeDecl := {rank := 3, op := "OpName.BW_matmul", ins := [1046, 1041, 1042], outs := [1044, 1045], params := []}
def pmNode_894 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [742, 1045], outs := [1040], params := [1, 2]}
def pmNode_895 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [741, 1044], outs := [1026], params := [1, 3]}
def pmNode_896 : NodeDecl := {rank := 3, op := "OpName.BW_transpose", ins := [1040, 1030], outs := [1032], params := [2, 3]}
def pmNode_897 : NodeDecl := {rank := 3, op := "OpName.BW_transpose", ins := [1038, 1034], outs := [1036], params := [1, 2]}
def pmNode_898 : NodeDecl := {rank := 3, op := "OpName.BW_view", ins := [1036, 1033], outs := [1035], params := [1, 8, 64]}
def pmNode_899 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [732, 1035], outs := [1020], params := [1, 2]}
def pmNode_900 : NodeDecl := {rank := 3, op := "OpName.BW_transpose", ins := [1032, 1029], outs := [1031], params := [1, 2]}
def pmNode_901 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [728, 1031], outs := [1028], params := [3, 2]}
def pmNode_902 : NodeDecl := {rank := 3, op := "OpName.BW_view", ins := [1028, 1015], outs := [1017], params := [1, 16, 32]}
def pmNode_903 : NodeDecl := {rank := 3, op := "OpName.BW_transpose", ins := [1026, 1023], outs := [1025], params := [1, 2]}
def pmNode_904 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [722, 1025], outs := [1022], params := [3, 1]}
def pmNode_905 : NodeDecl := {rank := 3, op := "OpName.BW_view", ins := [1022, 1012], outs := [1014], params := [1, 8, 64]}
def pmNode_906 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [1020, 996, 939], outs := [1019, 940], params := []}
def pmNode_907 : NodeDecl := {rank := 3, op := "OpName.ReduceScatterPrim", ins := [717, 1019], outs := [1197], params := [1]}
def pmNode_908 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [1017, 995, 936], outs := [1016, 937], params := []}
def pmNode_909 : NodeDecl := {rank := 3, op := "OpName.ReduceScatterPrim", ins := [714, 1016], outs := [1195], params := [1]}
def pmNode_910 : NodeDecl := {rank := 3, op := "OpName.BW_linear", ins := [1014, 1011, 912], outs := [1013, 934], params := []}
def pmNode_911 : NodeDecl := {rank := 3, op := "OpName.BW_multiref", ins := [1013, 1195, 1197], outs := [1010], params := []}
def pmNode_912 : NodeDecl := {rank := 3, op := "OpName.BW_layernorm", ins := [1010, 1007, 910, 911], outs := [1009, 930, 932], params := []}
def pmNode_913 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [706, 1009], outs := [1193], params := [1, 2]}
def pmNode_914 : NodeDecl := {rank := 3, op := "OpName.BW_multiref", ins := [1193, 1075], outs := [1006], params := []}
def pmNode_915 : NodeDecl := {rank := 3, op := "OpName.BW_add", ins := [1006, 998, 1003], outs := [999, 1005], params := []}
def pmNode_916 : NodeDecl := {rank := 3, op := "OpName.AllToAllPrim", ins := [702, 1005], outs := [1002], params := [2, 1]}
def pmNode_917 : NodeDecl := {rank := 3, op := "OpName.BW_embedding", ins := [1002, 1000, 909], outs := [928], params := []}
def pmNode_918 : NodeDecl := {rank := 3, op := "OpName.BW_embedding", ins := [999, 984, 925], outs := [926], params := []}
def pmNode_919 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [19, 322, 625, 928], outs := [929], params := []}
def pmNode_920 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [21, 324, 627, 930], outs := [931], params := []}
def pmNode_921 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [23, 326, 629, 932], outs := [933], params := []}
def pmNode_922 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [59, 362, 665, 968], outs := [969], params := []}
def pmNode_923 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [25, 328, 631, 934], outs := [935], params := []}
def pmNode_924 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [61, 364, 667, 970], outs := [971], params := []}
def pmNode_925 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [66, 369, 672, 975], outs := [976], params := []}
def pmNode_926 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [68, 371, 674, 977], outs := [978], params := []}
def pmNode_927 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [70, 373, 676, 979], outs := [980], params := []}
def pmNode_928 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [33, 336, 639, 942], outs := [943], params := []}
def pmNode_929 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [35, 338, 641, 944], outs := [945], params := []}
def pmNode_930 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [37, 340, 643, 946], outs := [947], params := []}
def pmNode_931 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [39, 342, 645, 948], outs := [949], params := []}
def pmNode_932 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [41, 344, 647, 950], outs := [951], params := []}
def pmNode_933 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [43, 346, 649, 952], outs := [953], params := []}
def pmNode_934 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [45, 348, 651, 954], outs := [955], params := []}
def pmNode_935 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [320, 926], outs := [927], params := []}
def pmNode_936 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [360, 966], outs := [967], params := []}
def pmNode_937 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [331, 937], outs := [938], params := []}
def pmNode_938 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [367, 973], outs := [974], params := []}
def pmNode_939 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [334, 940], outs := [941], params := []}
def pmNode_940 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [376, 982], outs := [983], params := []}
def pmNode_941 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [351, 957], outs := [958], params := []}
def pmNode_942 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [354, 960], outs := [961], params := []}
def pmNode_943 : NodeDecl := {rank := 3, op := "OpName.CROSS_DP_WRED", ins := [357, 963], outs := [964], params := []}
def pmGraph : GraphDecl := {numRanks := 4, nodes := [pmNode_0, pmNode_1, pmNode_2, pmNode_3, pmNode_236, pmNode_237, pmNode_238, pmNode_239, pmNode_4, pmNode_5, pmNode_6, pmNode_240, pmNode_241, pmNode_242, pmNode_7, pmNode_8, pmNode_9, pmNode_10, pmNode_243, pmNode_244, pmNode_245, pmNode_11, pmNode_12, pmNode_13, pmNode_14, pmNode_15, pmNode_246, pmNode_247, pmNode_248, pmNode_249, pmNode_250, pmNode_251, pmNode_16, pmNode_17, pmNode_18, pmNode_252, pmNode_253, pmNode_254, pmNode_19, pmNode_20, pmNode_21, pmNode_22, pmNode_23, pmNode_24, pmNode_25, pmNode_255, pmNode_256, pmNode_257, pmNode_258, pmNode_259, pmNode_260, pmNode_26, pmNode_27, pmNode_261, pmNode_262, pmNode_263, pmNode_28, pmNode_29, pmNode_264, pmNode_265, pmNode_30, pmNode_31, pmNode_32, pmNode_266, pmNode_267, pmNode_33, pmNode_34, pmNode_35, pmNode_36, pmNode_268, pmNode_269, pmNode_270, pmNode_271, pmNode_272, pmNode_37, pmNode_38, pmNode_273, pmNode_274, pmNode_39, pmNode_40, pmNode_275, pmNode_276, pmNode_41, pmNode_42, pmNode_43, pmNode_277, pmNode_278, pmNode_279, pmNode_44, pmNode_45, pmNode_46, pmNode_47, pmNode_48, pmNode_280, pmNode_281, pmNode_282, pmNode_283, pmNode_284, pmNode_49, pmNode_50, pmNode_51, pmNode_285, pmNode_286, pmNode_287, pmNode_52, pmNode_53, pmNode_54, pmNode_288, pmNode_289, pmNode_290, pmNode_55, pmNode_56, pmNode_57, pmNode_58, pmNode_59, pmNode_60, pmNode_291, pmNode_292, pmNode_61, pmNode_62, pmNode_293, pmNode_294, pmNode_295, pmNode_296, pmNode_297, pmNode_298, pmNode_63, pmNode_64, pmNode_65, pmNode_66, pmNode_299, pmNode_300, pmNode_301, pmNode_302, pmNode_67, pmNode_68, pmNode_69, pmNode_70, pmNode_303, pmNode_304, pmNode_305, pmNode_306, pmNode_71, pmNode_72, pmNode_73, pmNode_307, pmNode_308, pmNode_309, pmNode_74, pmNode_75, pmNode_310, pmNode_311, pmNode_76, pmNode_77, pmNode_312, pmNode_313, pmNode_78, pmNode_79, pmNode_80, pmNode_81, pmNode_314, pmNode_315, pmNode_316, pmNode_317, pmNode_82, pmNode_83, pmNode_318, pmNode_319, pmNode_84, pmNode_85, pmNode_320, pmNode_321, pmNode_86, pmNode_87, pmNode_88, pmNode_322, pmNode_323, pmNode_324, pmNode_89, pmNode_90, pmNode_91, pmNode_325, pmNode_326, pmNode_327, pmNode_92, pmNode_93, pmNode_328, pmNode_329, pmNode_94, pmNode_95, pmNode_330, pmNode_331, pmNode_96, pmNode_97, pmNode_98, pmNode_99, pmNode_100, pmNode_101, pmNode_332, pmNode_333, pmNode_334, pmNode_335, pmNode_336, pmNode_337, pmNode_102, pmNode_103, pmNode_338, pmNode_339, pmNode_104, pmNode_105, pmNode_340, pmNode_341, pmNode_106, pmNode_107, pmNode_342, pmNode_343, pmNode_108, pmNode_109, pmNode_344, pmNode_345, pmNode_110, pmNode_111, pmNode_112, pmNode_346, pmNode_347, pmNode_348, pmNode_113, pmNode_114, pmNode_115, pmNode_349, pmNode_350, pmNode_351, pmNode_116, pmNode_117, pmNode_352, pmNode_353, pmNode_118, pmNode_119, pmNode_354, pmNode_355, pmNode_120, pmNode_121, pmNode_122, pmNode_356, pmNode_357, pmNode_358, pmNode_123, pmNode_124, pmNode_125, pmNode_359, pmNode_360, pmNode_361, pmNode_126, pmNode_127, pmNode_362, pmNode_363, pmNode_128, pmNode_129, pmNode_364, pmNode_365, pmNode_130, pmNode_131, pmNode_366, pmNode_367, pmNode_132, pmNode_133, pmNode_368, pmNode_369, pmNode_134, pmNode_135, pmNode_370, pmNode_371, pmNode_136, pmNode_137, pmNode_372, pmNode_373, pmNode_138, pmNode_139, pmNode_140, pmNode_374, pmNode_375, pmNode_376, pmNode_141, pmNode_142, pmNode_377, pmNode_378, pmNode_143, pmNode_144, pmNode_379, pmNode_380, pmNode_145, pmNode_146, pmNode_381, pmNode_382, pmNode_147, pmNode_148, pmNode_383, pmNode_384, pmNode_149, pmNode_150, pmNode_385, pmNode_386, pmNode_151, pmNode_152, pmNode_387, pmNode_388, pmNode_153, pmNode_154, pmNode_389, pmNode_390, pmNode_155, pmNode_156, pmNode_391, pmNode_392, pmNode_157, pmNode_158, pmNode_159, pmNode_393, pmNode_394, pmNode_395, pmNode_160, pmNode_161, pmNode_162, pmNode_396, pmNode_397, pmNode_398, pmNode_163, pmNode_164, pmNode_165, pmNode_166, pmNode_167, pmNode_399, pmNode_400, pmNode_401, pmNode_402, pmNode_403, pmNode_168, pmNode_169, pmNode_170, pmNode_404, pmNode_405, pmNode_406, pmNode_171, pmNode_172, pmNode_407, pmNode_408, pmNode_173, pmNode_174, pmNode_409, pmNode_410, pmNode_175, pmNode_176, pmNode_177, pmNode_178, pmNode_411, pmNode_412, pmNode_413, pmNode_414, pmNode_179, pmNode_180, pmNode_181, pmNode_415, pmNode_416, pmNode_417, pmNode_182, pmNode_183, pmNode_418, pmNode_419, pmNode_184, pmNode_185, pmNode_420, pmNode_421, pmNode_186, pmNode_187, pmNode_188, pmNode_189, pmNode_190, pmNode_422, pmNode_423, pmNode_424, pmNode_425, pmNode_426, pmNode_191, pmNode_192, pmNode_427, pmNode_428, pmNode_193, pmNode_194, pmNode_195, pmNode_429, pmNode_430, pmNode_431, pmNode_196, pmNode_197, pmNode_198, pmNode_432, pmNode_433, pmNode_434, pmNode_199, pmNode_200, pmNode_435, pmNode_436, pmNode_201, pmNode_202, pmNode_203, pmNode_204, pmNode_437, pmNode_438, pmNode_439, pmNode_440, pmNode_205, pmNode_206, pmNode_207, pmNode_441, pmNode_442, pmNode_443, pmNode_208, pmNode_209, pmNode_210, pmNode_444, pmNode_445, pmNode_446, pmNode_472, pmNode_473, pmNode_474, pmNode_475, pmNode_708, pmNode_709, pmNode_710, pmNode_711, pmNode_476, pmNode_477, pmNode_478, pmNode_712, pmNode_713, pmNode_714, pmNode_479, pmNode_480, pmNode_481, pmNode_482, pmNode_715, pmNode_716, pmNode_717, pmNode_483, pmNode_484, pmNode_485, pmNode_486, pmNode_487, pmNode_718, pmNode_719, pmNode_720, pmNode_721, pmNode_722, pmNode_723, pmNode_488, pmNode_489, pmNode_490, pmNode_724, pmNode_725, pmNode_726, pmNode_491, pmNode_492, pmNode_493, pmNode_494, pmNode_495, pmNode_496, pmNode_497, pmNode_727, pmNode_728, pmNode_729, pmNode_730, pmNode_731, pmNode_732, pmNode_498, pmNode_499, pmNode_733, pmNode_734, pmNode_735, pmNode_500, pmNode_501, pmNode_736, pmNode_737, pmNode_502, pmNode_503, pmNode_504, pmNode_738, pmNode_739, pmNode_505, pmNode_506, pmNode_507, pmNode_508, pmNode_740, pmNode_741, pmNode_742, pmNode_743, pmNode_744, pmNode_509, pmNode_510, pmNode_745, pmNode_746, pmNode_511, pmNode_512, pmNode_747, pmNode_748, pmNode_513, pmNode_514, pmNode_515, pmNode_749, pmNode_750, pmNode_751, pmNode_516, pmNode_517, pmNode_518, pmNode_519, pmNode_520, pmNode_752, pmNode_753, pmNode_754, pmNode_755, pmNode_756, pmNode_521, pmNode_522, pmNode_523, pmNode_757, pmNode_758, pmNode_759, pmNode_524, pmNode_525, pmNode_526, pmNode_760, pmNode_761, pmNode_762, pmNode_527, pmNode_528, pmNode_529, pmNode_530, pmNode_531, pmNode_532, pmNode_763, pmNode_764, pmNode_533, pmNode_534, pmNode_765, pmNode_766, pmNode_767, pmNode_768, pmNode_769, pmNode_770, pmNode_535, pmNode_536, pmNode_537, pmNode_538, pmNode_771, pmNode_772, pmNode_773, pmNode_774, pmNode_539, pmNode_540, pmNode_541, pmNode_542, pmNode_775, pmNode_776, pmNode_777, pmNode_778, pmNode_543, pmNode_544, pmNode_545, pmNode_779, pmNode_780, pmNode_781, pmNode_546, pmNode_547, pmNode_782, pmNode_783, pmNode_548, pmNode_549, pmNode_784, pmNode_785, pmNode_550, pmNode_551, pmNode_552, pmNode_553, pmNode_786, pmNode_787, pmNode_788, pmNode_789, pmNode_554, pmNode_555, pmNode_790, pmNode_791, pmNode_556, pmNode_557, pmNode_792, pmNode_793, pmNode_558, pmNode_559, pmNode_560, pmNode_794, pmNode_795, pmNode_796, pmNode_561, pmNode_562, pmNode_563, pmNode_797, pmNode_798, pmNode_799, pmNode_564, pmNode_565, pmNode_800, pmNode_801, pmNode_566, pmNode_567, pmNode_802, pmNode_803, pmNode_568, pmNode_569, pmNode_570, pmNode_571, pmNode_572, pmNode_573, pmNode_804, pmNode_805, pmNode_806, pmNode_807, pmNode_808, pmNode_809, pmNode_574, pmNode_575, pmNode_810, pmNode_811, pmNode_576, pmNode_577, pmNode_812, pmNode_813, pmNode_578, pmNode_579, pmNode_814, pmNode_815, pmNode_580, pmNode_581, pmNode_816, pmNode_817, pmNode_582, pmNode_583, pmNode_584, pmNode_818, pmNode_819, pmNode_820, pmNode_585, pmNode_586, pmNode_587, pmNode_821, pmNode_822, pmNode_823, pmNode_588, pmNode_589, pmNode_824, pmNode_825, pmNode_590, pmNode_591, pmNode_826, pmNode_827, pmNode_592, pmNode_593, pmNode_594, pmNode_828, pmNode_829, pmNode_830, pmNode_595, pmNode_596, pmNode_597, pmNode_831, pmNode_832, pmNode_833, pmNode_598, pmNode_599, pmNode_834, pmNode_835, pmNode_600, pmNode_601, pmNode_836, pmNode_837, pmNode_602, pmNode_603, pmNode_838, pmNode_839, pmNode_604, pmNode_605, pmNode_840, pmNode_841, pmNode_606, pmNode_607, pmNode_842, pmNode_843, pmNode_608, pmNode_609, pmNode_844, pmNode_845, pmNode_610, pmNode_611, pmNode_612, pmNode_846, pmNode_847, pmNode_848, pmNode_613, pmNode_614, pmNode_849, pmNode_850, pmNode_615, pmNode_616, pmNode_851, pmNode_852, pmNode_617, pmNode_618, pmNode_853, pmNode_854, pmNode_619, pmNode_620, pmNode_855, pmNode_856, pmNode_621, pmNode_622, pmNode_857, pmNode_858, pmNode_623, pmNode_624, pmNode_859, pmNode_860, pmNode_625, pmNode_626, pmNode_861, pmNode_862, pmNode_627, pmNode_628, pmNode_863, pmNode_864, pmNode_629, pmNode_630, pmNode_631, pmNode_865, pmNode_866, pmNode_867, pmNode_632, pmNode_633, pmNode_634, pmNode_868, pmNode_869, pmNode_870, pmNode_635, pmNode_636, pmNode_637, pmNode_638, pmNode_639, pmNode_871, pmNode_872, pmNode_873, pmNode_874, pmNode_875, pmNode_640, pmNode_641, pmNode_642, pmNode_876, pmNode_877, pmNode_878, pmNode_643, pmNode_644, pmNode_879, pmNode_880, pmNode_645, pmNode_646, pmNode_881, pmNode_882, pmNode_647, pmNode_648, pmNode_649, pmNode_650, pmNode_883, pmNode_884, pmNode_885, pmNode_886, pmNode_651, pmNode_652, pmNode_653, pmNode_887, pmNode_888, pmNode_889, pmNode_654, pmNode_655, pmNode_890, pmNode_891, pmNode_656, pmNode_657, pmNode_892, pmNode_893, pmNode_658, pmNode_659, pmNode_660, pmNode_661, pmNode_662, pmNode_894, pmNode_895, pmNode_896, pmNode_897, pmNode_898, pmNode_663, pmNode_664, pmNode_899, pmNode_900, pmNode_665, pmNode_666, pmNode_667, pmNode_901, pmNode_902, pmNode_903, pmNode_668, pmNode_669, pmNode_670, pmNode_904, pmNode_905, pmNode_906, pmNode_671, pmNode_672, pmNode_907, pmNode_908, pmNode_673, pmNode_674, pmNode_675, pmNode_676, pmNode_909, pmNode_910, pmNode_911, pmNode_912, pmNode_677, pmNode_678, pmNode_679, pmNode_913, pmNode_914, pmNode_915, pmNode_680, pmNode_681, pmNode_682, pmNode_916, pmNode_917, pmNode_211, pmNode_212, pmNode_213, pmNode_214, pmNode_215, pmNode_216, pmNode_217, pmNode_218, pmNode_219, pmNode_220, pmNode_221, pmNode_222, pmNode_223, pmNode_224, pmNode_225, pmNode_226, pmNode_227, pmNode_228, pmNode_229, pmNode_230, pmNode_231, pmNode_232, pmNode_233, pmNode_234, pmNode_235, pmNode_447, pmNode_448, pmNode_449, pmNode_450, pmNode_451, pmNode_452, pmNode_453, pmNode_454, pmNode_455, pmNode_456, pmNode_457, pmNode_458, pmNode_459, pmNode_460, pmNode_461, pmNode_462, pmNode_683, pmNode_684, pmNode_685, pmNode_686, pmNode_687, pmNode_688, pmNode_689, pmNode_690, pmNode_691, pmNode_692, pmNode_693, pmNode_694, pmNode_695, pmNode_696, pmNode_697, pmNode_698, pmNode_699, pmNode_700, pmNode_701, pmNode_702, pmNode_703, pmNode_704, pmNode_705, pmNode_706, pmNode_707, pmNode_918, pmNode_463, pmNode_464, pmNode_465, pmNode_466, pmNode_467, pmNode_468, pmNode_469, pmNode_470, pmNode_471, pmNode_919, pmNode_920, pmNode_921, pmNode_922, pmNode_923, pmNode_924, pmNode_925, pmNode_926, pmNode_927, pmNode_928, pmNode_929, pmNode_930, pmNode_931, pmNode_932, pmNode_933, pmNode_934, pmNode_935, pmNode_936, pmNode_937, pmNode_938, pmNode_939, pmNode_940, pmNode_941, pmNode_942, pmNode_943]}
def pmRequests : List (NodeDecl × GroupScopedEval.Request × List (Nat × Tid)) := [
(pmNode_0, .group none, []),
(pmNode_1, .global, []),
(pmNode_2, .group (some [0, 1]), []),
(pmNode_3, .global, []),
(pmNode_4, .group (some [0, 1]), [(0, 92), (1, 395)]),
(pmNode_5, .global, []),
(pmNode_6, .global, []),
(pmNode_7, .group (some [0, 1]), [(0, 283), (1, 586)]),
(pmNode_8, .global, []),
(pmNode_9, .global, []),
(pmNode_10, .global, []),
(pmNode_11, .group (some [0, 1]), [(0, 285), (1, 588)]),
(pmNode_12, .global, []),
(pmNode_13, .group (some [0, 1]), [(0, 287), (1, 590)]),
(pmNode_14, .global, []),
(pmNode_15, .global, []),
(pmNode_16, .group (some [0, 1]), [(0, 112), (1, 415)]),
(pmNode_17, .global, []),
(pmNode_18, .global, []),
(pmNode_19, .group (some [0, 1]), [(0, 118), (1, 421)]),
(pmNode_20, .global, []),
(pmNode_21, .group (some [0, 1]), [(0, 109), (1, 412)]),
(pmNode_22, .global, []),
(pmNode_23, .global, []),
(pmNode_24, .global, []),
(pmNode_25, .group (some [0, 1]), [(0, 115), (1, 418)]),
(pmNode_26, .group (some [0, 1]), [(0, 130), (1, 433)]),
(pmNode_27, .global, []),
(pmNode_28, .group (some [0, 1]), [(0, 134), (1, 437)]),
(pmNode_29, .global, []),
(pmNode_30, .group (some [0, 1]), [(0, 139), (1, 442)]),
(pmNode_31, .global, []),
(pmNode_32, .group (some [0, 1]), [(0, 128), (1, 431)]),
(pmNode_33, .group (some [0, 1]), [(0, 143), (1, 446)]),
(pmNode_34, .global, []),
(pmNode_35, .global, []),
(pmNode_36, .global, []),
(pmNode_37, .group (some [0, 1]), [(0, 153), (1, 456)]),
(pmNode_38, .global, []),
(pmNode_39, .group (some [0, 1]), [(0, 156), (1, 459)]),
(pmNode_40, .global, []),
(pmNode_41, .group (some [0, 1]), [(0, 160), (1, 463)]),
(pmNode_42, .global, []),
(pmNode_43, .global, []),
(pmNode_44, .group (some [0, 1]), [(0, 289), (1, 592)]),
(pmNode_45, .global, []),
(pmNode_46, .global, []),
(pmNode_47, .global, []),
(pmNode_48, .global, []),
(pmNode_49, .group (some [0, 1]), [(0, 177), (1, 480)]),
(pmNode_50, .global, []),
(pmNode_51, .global, []),
(pmNode_52, .group (some [0, 1]), [(0, 291), (1, 594)]),
(pmNode_53, .global, []),
(pmNode_54, .global, []),
(pmNode_55, .group (some [0, 1]), [(0, 293), (1, 596)]),
(pmNode_56, .global, []),
(pmNode_57, .group (some [0, 1]), [(0, 295), (1, 598)]),
(pmNode_58, .global, []),
(pmNode_59, .group (some [0, 1]), [(0, 297), (1, 600)]),
(pmNode_60, .global, []),
(pmNode_61, .group (some [0, 1]), [(0, 189), (1, 492)]),
(pmNode_62, .global, []),
(pmNode_63, .group (some [0, 1]), [(0, 199), (1, 502)]),
(pmNode_64, .global, []),
(pmNode_65, .group (some [0, 1]), [(0, 193), (1, 496)]),
(pmNode_66, .global, []),
(pmNode_67, .group (some [0, 1]), [(0, 207), (1, 510)]),
(pmNode_68, .global, []),
(pmNode_69, .group (some [0, 1]), [(0, 196), (1, 499)]),
(pmNode_70, .global, []),
(pmNode_71, .group (some [0, 1]), [(0, 215), (1, 518)]),
(pmNode_72, .global, []),
(pmNode_73, .global, []),
(pmNode_74, .group (some [0, 1]), [(0, 222), (1, 525)]),
(pmNode_75, .global, []),
(pmNode_76, .group (some [0, 1]), [(0, 225), (1, 528)]),
(pmNode_77, .global, []),
(pmNode_78, .group (some [0, 1]), [(0, 229), (1, 532)]),
(pmNode_79, .global, []),
(pmNode_80, .group (some [0, 1]), [(0, 219), (1, 522)]),
(pmNode_81, .global, []),
(pmNode_82, .group (some [0, 1]), [(0, 236), (1, 539)]),
(pmNode_83, .global, []),
(pmNode_84, .group (some [0, 1]), [(0, 240), (1, 543)]),
(pmNode_85, .global, []),
(pmNode_86, .group (some [0, 1]), [(0, 244), (1, 547)]),
(pmNode_87, .global, []),
(pmNode_88, .global, []),
(pmNode_89, .group (some [0, 1]), [(0, 251), (1, 554)]),
(pmNode_90, .global, []),
(pmNode_91, .global, []),
(pmNode_92, .group (some [0, 1]), [(0, 299), (1, 602)]),
(pmNode_93, .global, []),
(pmNode_94, .group (some [0, 1]), [(0, 259), (1, 562)]),
(pmNode_95, .global, []),
(pmNode_96, .group (some [0, 1]), [(0, 263), (1, 566)]),
(pmNode_97, .global, []),
(pmNode_98, .global, []),
(pmNode_99, .group (some [0, 1]), [(0, 301), (1, 604)]),
(pmNode_100, .global, []),
(pmNode_101, .global, []),
(pmNode_102, .group (some [0, 1]), [(0, 275), (1, 578)]),
(pmNode_103, .global, []),
(pmNode_104, .group (some [0, 1]), [(0, 277), (1, 580)]),
(pmNode_105, .global, []),
(pmNode_106, .group (some [0, 1]), [(0, 281), (1, 584)]),
(pmNode_107, .global, []),
(pmNode_108, .group (some [0, 1]), [(0, 282), (1, 585)]),
(pmNode_109, .global, []),
(pmNode_110, .group (some [0, 1]), [(0, 279), (1, 581)]),
(pmNode_111, .global, []),
(pmNode_112, .global, []),
(pmNode_113, .group (some [0, 1]), [(0, 273), (1, 576)]),
(pmNode_114, .global, []),
(pmNode_115, .global, []),
(pmNode_116, .group (some [0, 1]), [(0, 267), (1, 570)]),
(pmNode_117, .global, []),
(pmNode_118, .group (some [0, 1]), [(0, 264), (1, 567)]),
(pmNode_119, .global, []),
(pmNode_120, .group (some [0, 1]), [(0, 260), (1, 563)]),
(pmNode_121, .global, []),
(pmNode_122, .global, []),
(pmNode_123, .group (some [0, 1]), [(0, 256), (1, 559)]),
(pmNode_124, .global, []),
(pmNode_125, .global, []),
(pmNode_126, .group (some [0, 1]), [(0, 249), (1, 552)]),
(pmNode_127, .global, []),
(pmNode_128, .group (some [0, 1]), [(0, 245), (1, 548)]),
(pmNode_129, .global, []),
(pmNode_130, .group (some [0, 1]), [(0, 241), (1, 544)]),
(pmNode_131, .global, []),
(pmNode_132, .group (some [0, 1]), [(0, 238), (1, 540)]),
(pmNode_133, .global, []),
(pmNode_134, .group (some [0, 1]), [(0, 234), (1, 537)]),
(pmNode_135, .global, []),
(pmNode_136, .group (some [0, 1]), [(0, 230), (1, 533)]),
(pmNode_137, .global, []),
(pmNode_138, .group (some [0, 1]), [(0, 226), (1, 529)]),
(pmNode_139, .global, []),
(pmNode_140, .global, []),
(pmNode_141, .group (some [0, 1]), [(0, 220), (1, 523)]),
(pmNode_142, .global, []),
(pmNode_143, .group (some [0, 1]), [(0, 216), (1, 519)]),
(pmNode_144, .global, []),
(pmNode_145, .group (some [0, 1]), [(0, 212), (1, 515)]),
(pmNode_146, .global, []),
(pmNode_147, .group (some [0, 1]), [(0, 208), (1, 511)]),
(pmNode_148, .global, []),
(pmNode_149, .group (some [0, 1]), [(0, 204), (1, 507)]),
(pmNode_150, .global, []),
(pmNode_151, .group (some [0, 1]), [(0, 200), (1, 503)]),
(pmNode_152, .global, []),
(pmNode_153, .group (some [0, 1]), [(0, 197), (1, 500)]),
(pmNode_154, .global, []),
(pmNode_155, .group (some [0, 1]), [(0, 194), (1, 497)]),
(pmNode_156, .global, []),
(pmNode_157, .group (some [0, 1]), [(0, 191), (1, 493)]),
(pmNode_158, .global, []),
(pmNode_159, .global, []),
(pmNode_160, .group (some [0, 1]), [(0, 187), (1, 490)]),
(pmNode_161, .global, []),
(pmNode_162, .global, []),
(pmNode_163, .group (some [0, 1]), [(0, 183), (1, 486)]),
(pmNode_164, .global, []),
(pmNode_165, .global, []),
(pmNode_166, .global, []),
(pmNode_167, .global, []),
(pmNode_168, .group (some [0, 1]), [(0, 171), (1, 474)]),
(pmNode_169, .global, []),
(pmNode_170, .global, []),
(pmNode_171, .group (some [0, 1]), [(0, 167), (1, 470)]),
(pmNode_172, .global, []),
(pmNode_173, .group (some [0, 1]), [(0, 161), (1, 464)]),
(pmNode_174, .global, []),
(pmNode_175, .group (some [0, 1]), [(0, 157), (1, 460)]),
(pmNode_176, .global, []),
(pmNode_177, .global, []),
(pmNode_178, .global, []),
(pmNode_179, .group (some [0, 1]), [(0, 148), (1, 452)]),
(pmNode_180, .group (some [0, 1]), [(0, 150), (1, 451)]),
(pmNode_181, .global, []),
(pmNode_182, .group (some [0, 1]), [(0, 144), (1, 447)]),
(pmNode_183, .global, []),
(pmNode_184, .group (some [0, 1]), [(0, 140), (1, 443)]),
(pmNode_185, .global, []),
(pmNode_186, .group (some [0, 1]), [(0, 136), (1, 439)]),
(pmNode_187, .group (some [0, 1]), [(0, 135), (1, 438)]),
(pmNode_188, .global, []),
(pmNode_189, .global, []),
(pmNode_190, .global, []),
(pmNode_191, .group (some [0, 1]), [(0, 126), (1, 429)]),
(pmNode_192, .global, []),
(pmNode_193, .group (some [0, 1]), [(0, 122), (1, 425)]),
(pmNode_194, .global, []),
(pmNode_195, .global, []),
(pmNode_196, .group (some [0, 1]), [(0, 116), (1, 419)]),
(pmNode_197, .global, []),
(pmNode_198, .global, []),
(pmNode_199, .group (some [0, 1]), [(0, 111), (1, 413)]),
(pmNode_200, .global, []),
(pmNode_201, .group (some [0, 1]), [(0, 108), (1, 410)]),
(pmNode_202, .global, []),
(pmNode_203, .global, []),
(pmNode_204, .global, []),
(pmNode_205, .group (some [0, 1]), [(0, 100), (1, 403)]),
(pmNode_206, .global, []),
(pmNode_207, .global, []),
(pmNode_208, .group (some [0, 1]), [(0, 96), (1, 399)]),
(pmNode_209, .global, []),
(pmNode_210, .global, []),
(pmNode_211, .group (some [0, 1, 2, 3]), [(0, 19), (1, 322), (2, 625), (3, 928)]),
(pmNode_212, .group (some [0, 1, 2, 3]), [(0, 21), (1, 324), (2, 627), (3, 930)]),
(pmNode_213, .group (some [0, 1, 2, 3]), [(0, 23), (1, 326), (2, 629), (3, 932)]),
(pmNode_214, .group (some [0, 1, 2, 3]), [(0, 59), (1, 362), (2, 665), (3, 968)]),
(pmNode_215, .group (some [0, 1, 2, 3]), [(0, 25), (1, 328), (2, 631), (3, 934)]),
(pmNode_216, .group (some [0, 1, 2, 3]), [(0, 61), (1, 364), (2, 667), (3, 970)]),
(pmNode_217, .group (some [0, 1, 2, 3]), [(0, 66), (1, 369), (2, 672), (3, 975)]),
(pmNode_218, .group (some [0, 1, 2, 3]), [(0, 68), (1, 371), (2, 674), (3, 977)]),
(pmNode_219, .group (some [0, 1, 2, 3]), [(0, 70), (1, 373), (2, 676), (3, 979)]),
(pmNode_220, .group (some [0, 1, 2, 3]), [(0, 33), (1, 336), (2, 639), (3, 942)]),
(pmNode_221, .group (some [0, 1, 2, 3]), [(0, 35), (1, 338), (2, 641), (3, 944)]),
(pmNode_222, .group (some [0, 1, 2, 3]), [(0, 37), (1, 340), (2, 643), (3, 946)]),
(pmNode_223, .group (some [0, 1, 2, 3]), [(0, 39), (1, 342), (2, 645), (3, 948)]),
(pmNode_224, .group (some [0, 1, 2, 3]), [(0, 41), (1, 344), (2, 647), (3, 950)]),
(pmNode_225, .group (some [0, 1, 2, 3]), [(0, 43), (1, 346), (2, 649), (3, 952)]),
(pmNode_226, .group (some [0, 1, 2, 3]), [(0, 45), (1, 348), (2, 651), (3, 954)]),
(pmNode_227, .group (some [0, 2]), [(0, 17), (2, 623)]),
(pmNode_228, .group (some [0, 2]), [(0, 57), (2, 663)]),
(pmNode_229, .group (some [0, 2]), [(0, 28), (2, 634)]),
(pmNode_230, .group (some [0, 2]), [(0, 64), (2, 670)]),
(pmNode_231, .group (some [0, 2]), [(0, 31), (2, 637)]),
(pmNode_232, .group (some [0, 2]), [(0, 73), (2, 679)]),
(pmNode_233, .group (some [0, 2]), [(0, 48), (2, 654)]),
(pmNode_234, .group (some [0, 2]), [(0, 51), (2, 657)]),
(pmNode_235, .group (some [0, 2]), [(0, 54), (2, 660)]),
(pmNode_236, .group none, []),
(pmNode_237, .global, []),
(pmNode_238, .group (some [0, 1]), []),
(pmNode_239, .global, []),
(pmNode_240, .group (some [0, 1]), [(0, 92), (1, 395)]),
(pmNode_241, .global, []),
(pmNode_242, .global, []),
(pmNode_243, .group (some [0, 1]), [(0, 283), (1, 586)]),
(pmNode_244, .global, []),
(pmNode_245, .global, []),
(pmNode_246, .global, []),
(pmNode_247, .group (some [0, 1]), [(0, 285), (1, 588)]),
(pmNode_248, .global, []),
(pmNode_249, .group (some [0, 1]), [(0, 287), (1, 590)]),
(pmNode_250, .global, []),
(pmNode_251, .global, []),
(pmNode_252, .group (some [0, 1]), [(0, 112), (1, 415)]),
(pmNode_253, .global, []),
(pmNode_254, .global, []),
(pmNode_255, .group (some [0, 1]), [(0, 118), (1, 421)]),
(pmNode_256, .global, []),
(pmNode_257, .group (some [0, 1]), [(0, 109), (1, 412)]),
(pmNode_258, .global, []),
(pmNode_259, .global, []),
(pmNode_260, .global, []),
(pmNode_261, .group (some [0, 1]), [(0, 115), (1, 418)]),
(pmNode_262, .group (some [0, 1]), [(0, 130), (1, 433)]),
(pmNode_263, .global, []),
(pmNode_264, .group (some [0, 1]), [(0, 134), (1, 437)]),
(pmNode_265, .global, []),
(pmNode_266, .group (some [0, 1]), [(0, 139), (1, 442)]),
(pmNode_267, .global, []),
(pmNode_268, .group (some [0, 1]), [(0, 128), (1, 431)]),
(pmNode_269, .group (some [0, 1]), [(0, 143), (1, 446)]),
(pmNode_270, .global, []),
(pmNode_271, .global, []),
(pmNode_272, .global, []),
(pmNode_273, .group (some [0, 1]), [(0, 153), (1, 456)]),
(pmNode_274, .global, []),
(pmNode_275, .group (some [0, 1]), [(0, 156), (1, 459)]),
(pmNode_276, .global, []),
(pmNode_277, .group (some [0, 1]), [(0, 160), (1, 463)]),
(pmNode_278, .global, []),
(pmNode_279, .global, []),
(pmNode_280, .group (some [0, 1]), [(0, 289), (1, 592)]),
(pmNode_281, .global, []),
(pmNode_282, .global, []),
(pmNode_283, .global, []),
(pmNode_284, .global, []),
(pmNode_285, .group (some [0, 1]), [(0, 177), (1, 480)]),
(pmNode_286, .global, []),
(pmNode_287, .global, []),
(pmNode_288, .group (some [0, 1]), [(0, 291), (1, 594)]),
(pmNode_289, .global, []),
(pmNode_290, .global, []),
(pmNode_291, .group (some [0, 1]), [(0, 293), (1, 596)]),
(pmNode_292, .global, []),
(pmNode_293, .group (some [0, 1]), [(0, 295), (1, 598)]),
(pmNode_294, .global, []),
(pmNode_295, .group (some [0, 1]), [(0, 297), (1, 600)]),
(pmNode_296, .global, []),
(pmNode_297, .group (some [0, 1]), [(0, 189), (1, 492)]),
(pmNode_298, .global, []),
(pmNode_299, .group (some [0, 1]), [(0, 199), (1, 502)]),
(pmNode_300, .global, []),
(pmNode_301, .group (some [0, 1]), [(0, 193), (1, 496)]),
(pmNode_302, .global, []),
(pmNode_303, .group (some [0, 1]), [(0, 207), (1, 510)]),
(pmNode_304, .global, []),
(pmNode_305, .group (some [0, 1]), [(0, 196), (1, 499)]),
(pmNode_306, .global, []),
(pmNode_307, .group (some [0, 1]), [(0, 215), (1, 518)]),
(pmNode_308, .global, []),
(pmNode_309, .global, []),
(pmNode_310, .group (some [0, 1]), [(0, 222), (1, 525)]),
(pmNode_311, .global, []),
(pmNode_312, .group (some [0, 1]), [(0, 225), (1, 528)]),
(pmNode_313, .global, []),
(pmNode_314, .group (some [0, 1]), [(0, 229), (1, 532)]),
(pmNode_315, .global, []),
(pmNode_316, .group (some [0, 1]), [(0, 219), (1, 522)]),
(pmNode_317, .global, []),
(pmNode_318, .group (some [0, 1]), [(0, 236), (1, 539)]),
(pmNode_319, .global, []),
(pmNode_320, .group (some [0, 1]), [(0, 240), (1, 543)]),
(pmNode_321, .global, []),
(pmNode_322, .group (some [0, 1]), [(0, 244), (1, 547)]),
(pmNode_323, .global, []),
(pmNode_324, .global, []),
(pmNode_325, .group (some [0, 1]), [(0, 251), (1, 554)]),
(pmNode_326, .global, []),
(pmNode_327, .global, []),
(pmNode_328, .group (some [0, 1]), [(0, 299), (1, 602)]),
(pmNode_329, .global, []),
(pmNode_330, .group (some [0, 1]), [(0, 259), (1, 562)]),
(pmNode_331, .global, []),
(pmNode_332, .group (some [0, 1]), [(0, 263), (1, 566)]),
(pmNode_333, .global, []),
(pmNode_334, .global, []),
(pmNode_335, .group (some [0, 1]), [(0, 301), (1, 604)]),
(pmNode_336, .global, []),
(pmNode_337, .global, []),
(pmNode_338, .group (some [0, 1]), [(0, 275), (1, 578)]),
(pmNode_339, .global, []),
(pmNode_340, .group (some [0, 1]), [(0, 277), (1, 580)]),
(pmNode_341, .global, []),
(pmNode_342, .group (some [0, 1]), [(0, 281), (1, 584)]),
(pmNode_343, .global, []),
(pmNode_344, .group (some [0, 1]), [(0, 282), (1, 585)]),
(pmNode_345, .global, []),
(pmNode_346, .group (some [0, 1]), [(0, 279), (1, 581)]),
(pmNode_347, .global, []),
(pmNode_348, .global, []),
(pmNode_349, .group (some [0, 1]), [(0, 273), (1, 576)]),
(pmNode_350, .global, []),
(pmNode_351, .global, []),
(pmNode_352, .group (some [0, 1]), [(0, 267), (1, 570)]),
(pmNode_353, .global, []),
(pmNode_354, .group (some [0, 1]), [(0, 264), (1, 567)]),
(pmNode_355, .global, []),
(pmNode_356, .group (some [0, 1]), [(0, 260), (1, 563)]),
(pmNode_357, .global, []),
(pmNode_358, .global, []),
(pmNode_359, .group (some [0, 1]), [(0, 256), (1, 559)]),
(pmNode_360, .global, []),
(pmNode_361, .global, []),
(pmNode_362, .group (some [0, 1]), [(0, 249), (1, 552)]),
(pmNode_363, .global, []),
(pmNode_364, .group (some [0, 1]), [(0, 245), (1, 548)]),
(pmNode_365, .global, []),
(pmNode_366, .group (some [0, 1]), [(0, 241), (1, 544)]),
(pmNode_367, .global, []),
(pmNode_368, .group (some [0, 1]), [(0, 238), (1, 540)]),
(pmNode_369, .global, []),
(pmNode_370, .group (some [0, 1]), [(0, 234), (1, 537)]),
(pmNode_371, .global, []),
(pmNode_372, .group (some [0, 1]), [(0, 230), (1, 533)]),
(pmNode_373, .global, []),
(pmNode_374, .group (some [0, 1]), [(0, 226), (1, 529)]),
(pmNode_375, .global, []),
(pmNode_376, .global, []),
(pmNode_377, .group (some [0, 1]), [(0, 220), (1, 523)]),
(pmNode_378, .global, []),
(pmNode_379, .group (some [0, 1]), [(0, 216), (1, 519)]),
(pmNode_380, .global, []),
(pmNode_381, .group (some [0, 1]), [(0, 212), (1, 515)]),
(pmNode_382, .global, []),
(pmNode_383, .group (some [0, 1]), [(0, 208), (1, 511)]),
(pmNode_384, .global, []),
(pmNode_385, .group (some [0, 1]), [(0, 204), (1, 507)]),
(pmNode_386, .global, []),
(pmNode_387, .group (some [0, 1]), [(0, 200), (1, 503)]),
(pmNode_388, .global, []),
(pmNode_389, .group (some [0, 1]), [(0, 197), (1, 500)]),
(pmNode_390, .global, []),
(pmNode_391, .group (some [0, 1]), [(0, 194), (1, 497)]),
(pmNode_392, .global, []),
(pmNode_393, .group (some [0, 1]), [(0, 191), (1, 493)]),
(pmNode_394, .global, []),
(pmNode_395, .global, []),
(pmNode_396, .group (some [0, 1]), [(0, 187), (1, 490)]),
(pmNode_397, .global, []),
(pmNode_398, .global, []),
(pmNode_399, .group (some [0, 1]), [(0, 183), (1, 486)]),
(pmNode_400, .global, []),
(pmNode_401, .global, []),
(pmNode_402, .global, []),
(pmNode_403, .global, []),
(pmNode_404, .group (some [0, 1]), [(0, 171), (1, 474)]),
(pmNode_405, .global, []),
(pmNode_406, .global, []),
(pmNode_407, .group (some [0, 1]), [(0, 167), (1, 470)]),
(pmNode_408, .global, []),
(pmNode_409, .group (some [0, 1]), [(0, 161), (1, 464)]),
(pmNode_410, .global, []),
(pmNode_411, .group (some [0, 1]), [(0, 157), (1, 460)]),
(pmNode_412, .global, []),
(pmNode_413, .global, []),
(pmNode_414, .global, []),
(pmNode_415, .group (some [0, 1]), [(0, 148), (1, 452)]),
(pmNode_416, .group (some [0, 1]), [(0, 150), (1, 451)]),
(pmNode_417, .global, []),
(pmNode_418, .group (some [0, 1]), [(0, 144), (1, 447)]),
(pmNode_419, .global, []),
(pmNode_420, .group (some [0, 1]), [(0, 140), (1, 443)]),
(pmNode_421, .global, []),
(pmNode_422, .group (some [0, 1]), [(0, 136), (1, 439)]),
(pmNode_423, .group (some [0, 1]), [(0, 135), (1, 438)]),
(pmNode_424, .global, []),
(pmNode_425, .global, []),
(pmNode_426, .global, []),
(pmNode_427, .group (some [0, 1]), [(0, 126), (1, 429)]),
(pmNode_428, .global, []),
(pmNode_429, .group (some [0, 1]), [(0, 122), (1, 425)]),
(pmNode_430, .global, []),
(pmNode_431, .global, []),
(pmNode_432, .group (some [0, 1]), [(0, 116), (1, 419)]),
(pmNode_433, .global, []),
(pmNode_434, .global, []),
(pmNode_435, .group (some [0, 1]), [(0, 111), (1, 413)]),
(pmNode_436, .global, []),
(pmNode_437, .group (some [0, 1]), [(0, 108), (1, 410)]),
(pmNode_438, .global, []),
(pmNode_439, .global, []),
(pmNode_440, .global, []),
(pmNode_441, .group (some [0, 1]), [(0, 100), (1, 403)]),
(pmNode_442, .global, []),
(pmNode_443, .global, []),
(pmNode_444, .group (some [0, 1]), [(0, 96), (1, 399)]),
(pmNode_445, .global, []),
(pmNode_446, .global, []),
(pmNode_447, .group (some [0, 1, 2, 3]), [(0, 19), (1, 322), (2, 625), (3, 928)]),
(pmNode_448, .group (some [0, 1, 2, 3]), [(0, 21), (1, 324), (2, 627), (3, 930)]),
(pmNode_449, .group (some [0, 1, 2, 3]), [(0, 23), (1, 326), (2, 629), (3, 932)]),
(pmNode_450, .group (some [0, 1, 2, 3]), [(0, 59), (1, 362), (2, 665), (3, 968)]),
(pmNode_451, .group (some [0, 1, 2, 3]), [(0, 25), (1, 328), (2, 631), (3, 934)]),
(pmNode_452, .group (some [0, 1, 2, 3]), [(0, 61), (1, 364), (2, 667), (3, 970)]),
(pmNode_453, .group (some [0, 1, 2, 3]), [(0, 66), (1, 369), (2, 672), (3, 975)]),
(pmNode_454, .group (some [0, 1, 2, 3]), [(0, 68), (1, 371), (2, 674), (3, 977)]),
(pmNode_455, .group (some [0, 1, 2, 3]), [(0, 70), (1, 373), (2, 676), (3, 979)]),
(pmNode_456, .group (some [0, 1, 2, 3]), [(0, 33), (1, 336), (2, 639), (3, 942)]),
(pmNode_457, .group (some [0, 1, 2, 3]), [(0, 35), (1, 338), (2, 641), (3, 944)]),
(pmNode_458, .group (some [0, 1, 2, 3]), [(0, 37), (1, 340), (2, 643), (3, 946)]),
(pmNode_459, .group (some [0, 1, 2, 3]), [(0, 39), (1, 342), (2, 645), (3, 948)]),
(pmNode_460, .group (some [0, 1, 2, 3]), [(0, 41), (1, 344), (2, 647), (3, 950)]),
(pmNode_461, .group (some [0, 1, 2, 3]), [(0, 43), (1, 346), (2, 649), (3, 952)]),
(pmNode_462, .group (some [0, 1, 2, 3]), [(0, 45), (1, 348), (2, 651), (3, 954)]),
(pmNode_463, .group (some [1, 3]), [(1, 320), (3, 926)]),
(pmNode_464, .group (some [1, 3]), [(1, 360), (3, 966)]),
(pmNode_465, .group (some [1, 3]), [(1, 331), (3, 937)]),
(pmNode_466, .group (some [1, 3]), [(1, 367), (3, 973)]),
(pmNode_467, .group (some [1, 3]), [(1, 334), (3, 940)]),
(pmNode_468, .group (some [1, 3]), [(1, 376), (3, 982)]),
(pmNode_469, .group (some [1, 3]), [(1, 351), (3, 957)]),
(pmNode_470, .group (some [1, 3]), [(1, 354), (3, 960)]),
(pmNode_471, .group (some [1, 3]), [(1, 357), (3, 963)]),
(pmNode_472, .group none, []),
(pmNode_473, .global, []),
(pmNode_474, .group (some [2, 3]), []),
(pmNode_475, .global, []),
(pmNode_476, .group (some [2, 3]), [(2, 698), (3, 1001)]),
(pmNode_477, .global, []),
(pmNode_478, .global, []),
(pmNode_479, .group (some [2, 3]), [(2, 889), (3, 1192)]),
(pmNode_480, .global, []),
(pmNode_481, .global, []),
(pmNode_482, .global, []),
(pmNode_483, .group (some [2, 3]), [(2, 891), (3, 1194)]),
(pmNode_484, .global, []),
(pmNode_485, .group (some [2, 3]), [(2, 893), (3, 1196)]),
(pmNode_486, .global, []),
(pmNode_487, .global, []),
(pmNode_488, .group (some [2, 3]), [(2, 718), (3, 1021)]),
(pmNode_489, .global, []),
(pmNode_490, .global, []),
(pmNode_491, .group (some [2, 3]), [(2, 724), (3, 1027)]),
(pmNode_492, .global, []),
(pmNode_493, .group (some [2, 3]), [(2, 715), (3, 1018)]),
(pmNode_494, .global, []),
(pmNode_495, .global, []),
(pmNode_496, .global, []),
(pmNode_497, .group (some [2, 3]), [(2, 721), (3, 1024)]),
(pmNode_498, .group (some [2, 3]), [(2, 736), (3, 1039)]),
(pmNode_499, .global, []),
(pmNode_500, .group (some [2, 3]), [(2, 740), (3, 1043)]),
(pmNode_501, .global, []),
(pmNode_502, .group (some [2, 3]), [(2, 745), (3, 1048)]),
(pmNode_503, .global, []),
(pmNode_504, .group (some [2, 3]), [(2, 734), (3, 1037)]),
(pmNode_505, .group (some [2, 3]), [(2, 749), (3, 1052)]),
(pmNode_506, .global, []),
(pmNode_507, .global, []),
(pmNode_508, .global, []),
(pmNode_509, .group (some [2, 3]), [(2, 759), (3, 1062)]),
(pmNode_510, .global, []),
(pmNode_511, .group (some [2, 3]), [(2, 762), (3, 1065)]),
(pmNode_512, .global, []),
(pmNode_513, .group (some [2, 3]), [(2, 766), (3, 1069)]),
(pmNode_514, .global, []),
(pmNode_515, .global, []),
(pmNode_516, .group (some [2, 3]), [(2, 895), (3, 1198)]),
(pmNode_517, .global, []),
(pmNode_518, .global, []),
(pmNode_519, .global, []),
(pmNode_520, .global, []),
(pmNode_521, .group (some [2, 3]), [(2, 783), (3, 1086)]),
(pmNode_522, .global, []),
(pmNode_523, .global, []),
(pmNode_524, .group (some [2, 3]), [(2, 897), (3, 1200)]),
(pmNode_525, .global, []),
(pmNode_526, .global, []),
(pmNode_527, .group (some [2, 3]), [(2, 899), (3, 1202)]),
(pmNode_528, .global, []),
(pmNode_529, .group (some [2, 3]), [(2, 901), (3, 1204)]),
(pmNode_530, .global, []),
(pmNode_531, .group (some [2, 3]), [(2, 903), (3, 1206)]),
(pmNode_532, .global, []),
(pmNode_533, .group (some [2, 3]), [(2, 795), (3, 1098)]),
(pmNode_534, .global, []),
(pmNode_535, .group (some [2, 3]), [(2, 805), (3, 1108)]),
(pmNode_536, .global, []),
(pmNode_537, .group (some [2, 3]), [(2, 799), (3, 1102)]),
(pmNode_538, .global, []),
(pmNode_539, .group (some [2, 3]), [(2, 813), (3, 1116)]),
(pmNode_540, .global, []),
(pmNode_541, .group (some [2, 3]), [(2, 802), (3, 1105)]),
(pmNode_542, .global, []),
(pmNode_543, .group (some [2, 3]), [(2, 821), (3, 1124)]),
(pmNode_544, .global, []),
(pmNode_545, .global, []),
(pmNode_546, .group (some [2, 3]), [(2, 828), (3, 1131)]),
(pmNode_547, .global, []),
(pmNode_548, .group (some [2, 3]), [(2, 831), (3, 1134)]),
(pmNode_549, .global, []),
(pmNode_550, .group (some [2, 3]), [(2, 835), (3, 1138)]),
(pmNode_551, .global, []),
(pmNode_552, .group (some [2, 3]), [(2, 825), (3, 1128)]),
(pmNode_553, .global, []),
(pmNode_554, .group (some [2, 3]), [(2, 842), (3, 1145)]),
(pmNode_555, .global, []),
(pmNode_556, .group (some [2, 3]), [(2, 846), (3, 1149)]),
(pmNode_557, .global, []),
(pmNode_558, .group (some [2, 3]), [(2, 850), (3, 1153)]),
(pmNode_559, .global, []),
(pmNode_560, .global, []),
(pmNode_561, .group (some [2, 3]), [(2, 857), (3, 1160)]),
(pmNode_562, .global, []),
(pmNode_563, .global, []),
(pmNode_564, .group (some [2, 3]), [(2, 905), (3, 1208)]),
(pmNode_565, .global, []),
(pmNode_566, .group (some [2, 3]), [(2, 865), (3, 1168)]),
(pmNode_567, .global, []),
(pmNode_568, .group (some [2, 3]), [(2, 869), (3, 1172)]),
(pmNode_569, .global, []),
(pmNode_570, .global, []),
(pmNode_571, .group (some [2, 3]), [(2, 907), (3, 1210)]),
(pmNode_572, .global, []),
(pmNode_573, .global, []),
(pmNode_574, .group (some [2, 3]), [(2, 881), (3, 1184)]),
(pmNode_575, .global, []),
(pmNode_576, .group (some [2, 3]), [(2, 883), (3, 1186)]),
(pmNode_577, .global, []),
(pmNode_578, .group (some [2, 3]), [(2, 887), (3, 1190)]),
(pmNode_579, .global, []),
(pmNode_580, .group (some [2, 3]), [(2, 888), (3, 1191)]),
(pmNode_581, .global, []),
(pmNode_582, .group (some [2, 3]), [(2, 885), (3, 1187)]),
(pmNode_583, .global, []),
(pmNode_584, .global, []),
(pmNode_585, .group (some [2, 3]), [(2, 879), (3, 1182)]),
(pmNode_586, .global, []),
(pmNode_587, .global, []),
(pmNode_588, .group (some [2, 3]), [(2, 873), (3, 1176)]),
(pmNode_589, .global, []),
(pmNode_590, .group (some [2, 3]), [(2, 870), (3, 1173)]),
(pmNode_591, .global, []),
(pmNode_592, .group (some [2, 3]), [(2, 866), (3, 1169)]),
(pmNode_593, .global, []),
(pmNode_594, .global, []),
(pmNode_595, .group (some [2, 3]), [(2, 862), (3, 1165)]),
(pmNode_596, .global, []),
(pmNode_597, .global, []),
(pmNode_598, .group (some [2, 3]), [(2, 855), (3, 1158)]),
(pmNode_599, .global, []),
(pmNode_600, .group (some [2, 3]), [(2, 851), (3, 1154)]),
(pmNode_601, .global, []),
(pmNode_602, .group (some [2, 3]), [(2, 847), (3, 1150)]),
(pmNode_603, .global, []),
(pmNode_604, .group (some [2, 3]), [(2, 844), (3, 1146)]),
(pmNode_605, .global, []),
(pmNode_606, .group (some [2, 3]), [(2, 840), (3, 1143)]),
(pmNode_607, .global, []),
(pmNode_608, .group (some [2, 3]), [(2, 836), (3, 1139)]),
(pmNode_609, .global, []),
(pmNode_610, .group (some [2, 3]), [(2, 832), (3, 1135)]),
(pmNode_611, .global, []),
(pmNode_612, .global, []),
(pmNode_613, .group (some [2, 3]), [(2, 826), (3, 1129)]),
(pmNode_614, .global, []),
(pmNode_615, .group (some [2, 3]), [(2, 822), (3, 1125)]),
(pmNode_616, .global, []),
(pmNode_617, .group (some [2, 3]), [(2, 818), (3, 1121)]),
(pmNode_618, .global, []),
(pmNode_619, .group (some [2, 3]), [(2, 814), (3, 1117)]),
(pmNode_620, .global, []),
(pmNode_621, .group (some [2, 3]), [(2, 810), (3, 1113)]),
(pmNode_622, .global, []),
(pmNode_623, .group (some [2, 3]), [(2, 806), (3, 1109)]),
(pmNode_624, .global, []),
(pmNode_625, .group (some [2, 3]), [(2, 803), (3, 1106)]),
(pmNode_626, .global, []),
(pmNode_627, .group (some [2, 3]), [(2, 800), (3, 1103)]),
(pmNode_628, .global, []),
(pmNode_629, .group (some [2, 3]), [(2, 797), (3, 1099)]),
(pmNode_630, .global, []),
(pmNode_631, .global, []),
(pmNode_632, .group (some [2, 3]), [(2, 793), (3, 1096)]),
(pmNode_633, .global, []),
(pmNode_634, .global, []),
(pmNode_635, .group (some [2, 3]), [(2, 789), (3, 1092)]),
(pmNode_636, .global, []),
(pmNode_637, .global, []),
(pmNode_638, .global, []),
(pmNode_639, .global, []),
(pmNode_640, .group (some [2, 3]), [(2, 777), (3, 1080)]),
(pmNode_641, .global, []),
(pmNode_642, .global, []),
(pmNode_643, .group (some [2, 3]), [(2, 773), (3, 1076)]),
(pmNode_644, .global, []),
(pmNode_645, .group (some [2, 3]), [(2, 767), (3, 1070)]),
(pmNode_646, .global, []),
(pmNode_647, .group (some [2, 3]), [(2, 763), (3, 1066)]),
(pmNode_648, .global, []),
(pmNode_649, .global, []),
(pmNode_650, .global, []),
(pmNode_651, .group (some [2, 3]), [(2, 754), (3, 1058)]),
(pmNode_652, .group (some [2, 3]), [(2, 756), (3, 1057)]),
(pmNode_653, .global, []),
(pmNode_654, .group (some [2, 3]), [(2, 750), (3, 1053)]),
(pmNode_655, .global, []),
(pmNode_656, .group (some [2, 3]), [(2, 746), (3, 1049)]),
(pmNode_657, .global, []),
(pmNode_658, .group (some [2, 3]), [(2, 742), (3, 1045)]),
(pmNode_659, .group (some [2, 3]), [(2, 741), (3, 1044)]),
(pmNode_660, .global, []),
(pmNode_661, .global, []),
(pmNode_662, .global, []),
(pmNode_663, .group (some [2, 3]), [(2, 732), (3, 1035)]),
(pmNode_664, .global, []),
(pmNode_665, .group (some [2, 3]), [(2, 728), (3, 1031)]),
(pmNode_666, .global, []),
(pmNode_667, .global, []),
(pmNode_668, .group (some [2, 3]), [(2, 722), (3, 1025)]),
(pmNode_669, .global, []),
(pmNode_670, .global, []),
(pmNode_671, .group (some [2, 3]), [(2, 717), (3, 1019)]),
(pmNode_672, .global, []),
(pmNode_673, .group (some [2, 3]), [(2, 714), (3, 1016)]),
(pmNode_674, .global, []),
(pmNode_675, .global, []),
(pmNode_676, .global, []),
(pmNode_677, .group (some [2, 3]), [(2, 706), (3, 1009)]),
(pmNode_678, .global, []),
(pmNode_679, .global, []),
(pmNode_680, .group (some [2, 3]), [(2, 702), (3, 1005)]),
(pmNode_681, .global, []),
(pmNode_682, .global, []),
(pmNode_683, .group (some [0, 1, 2, 3]), [(0, 19), (1, 322), (2, 625), (3, 928)]),
(pmNode_684, .group (some [0, 1, 2, 3]), [(0, 21), (1, 324), (2, 627), (3, 930)]),
(pmNode_685, .group (some [0, 1, 2, 3]), [(0, 23), (1, 326), (2, 629), (3, 932)]),
(pmNode_686, .group (some [0, 1, 2, 3]), [(0, 59), (1, 362), (2, 665), (3, 968)]),
(pmNode_687, .group (some [0, 1, 2, 3]), [(0, 25), (1, 328), (2, 631), (3, 934)]),
(pmNode_688, .group (some [0, 1, 2, 3]), [(0, 61), (1, 364), (2, 667), (3, 970)]),
(pmNode_689, .group (some [0, 1, 2, 3]), [(0, 66), (1, 369), (2, 672), (3, 975)]),
(pmNode_690, .group (some [0, 1, 2, 3]), [(0, 68), (1, 371), (2, 674), (3, 977)]),
(pmNode_691, .group (some [0, 1, 2, 3]), [(0, 70), (1, 373), (2, 676), (3, 979)]),
(pmNode_692, .group (some [0, 1, 2, 3]), [(0, 33), (1, 336), (2, 639), (3, 942)]),
(pmNode_693, .group (some [0, 1, 2, 3]), [(0, 35), (1, 338), (2, 641), (3, 944)]),
(pmNode_694, .group (some [0, 1, 2, 3]), [(0, 37), (1, 340), (2, 643), (3, 946)]),
(pmNode_695, .group (some [0, 1, 2, 3]), [(0, 39), (1, 342), (2, 645), (3, 948)]),
(pmNode_696, .group (some [0, 1, 2, 3]), [(0, 41), (1, 344), (2, 647), (3, 950)]),
(pmNode_697, .group (some [0, 1, 2, 3]), [(0, 43), (1, 346), (2, 649), (3, 952)]),
(pmNode_698, .group (some [0, 1, 2, 3]), [(0, 45), (1, 348), (2, 651), (3, 954)]),
(pmNode_699, .group (some [0, 2]), [(0, 17), (2, 623)]),
(pmNode_700, .group (some [0, 2]), [(0, 57), (2, 663)]),
(pmNode_701, .group (some [0, 2]), [(0, 28), (2, 634)]),
(pmNode_702, .group (some [0, 2]), [(0, 64), (2, 670)]),
(pmNode_703, .group (some [0, 2]), [(0, 31), (2, 637)]),
(pmNode_704, .group (some [0, 2]), [(0, 73), (2, 679)]),
(pmNode_705, .group (some [0, 2]), [(0, 48), (2, 654)]),
(pmNode_706, .group (some [0, 2]), [(0, 51), (2, 657)]),
(pmNode_707, .group (some [0, 2]), [(0, 54), (2, 660)]),
(pmNode_708, .group none, []),
(pmNode_709, .global, []),
(pmNode_710, .group (some [2, 3]), []),
(pmNode_711, .global, []),
(pmNode_712, .group (some [2, 3]), [(2, 698), (3, 1001)]),
(pmNode_713, .global, []),
(pmNode_714, .global, []),
(pmNode_715, .group (some [2, 3]), [(2, 889), (3, 1192)]),
(pmNode_716, .global, []),
(pmNode_717, .global, []),
(pmNode_718, .global, []),
(pmNode_719, .group (some [2, 3]), [(2, 891), (3, 1194)]),
(pmNode_720, .global, []),
(pmNode_721, .group (some [2, 3]), [(2, 893), (3, 1196)]),
(pmNode_722, .global, []),
(pmNode_723, .global, []),
(pmNode_724, .group (some [2, 3]), [(2, 718), (3, 1021)]),
(pmNode_725, .global, []),
(pmNode_726, .global, []),
(pmNode_727, .group (some [2, 3]), [(2, 724), (3, 1027)]),
(pmNode_728, .global, []),
(pmNode_729, .group (some [2, 3]), [(2, 715), (3, 1018)]),
(pmNode_730, .global, []),
(pmNode_731, .global, []),
(pmNode_732, .global, []),
(pmNode_733, .group (some [2, 3]), [(2, 721), (3, 1024)]),
(pmNode_734, .group (some [2, 3]), [(2, 736), (3, 1039)]),
(pmNode_735, .global, []),
(pmNode_736, .group (some [2, 3]), [(2, 740), (3, 1043)]),
(pmNode_737, .global, []),
(pmNode_738, .group (some [2, 3]), [(2, 745), (3, 1048)]),
(pmNode_739, .global, []),
(pmNode_740, .group (some [2, 3]), [(2, 734), (3, 1037)]),
(pmNode_741, .group (some [2, 3]), [(2, 749), (3, 1052)]),
(pmNode_742, .global, []),
(pmNode_743, .global, []),
(pmNode_744, .global, []),
(pmNode_745, .group (some [2, 3]), [(2, 759), (3, 1062)]),
(pmNode_746, .global, []),
(pmNode_747, .group (some [2, 3]), [(2, 762), (3, 1065)]),
(pmNode_748, .global, []),
(pmNode_749, .group (some [2, 3]), [(2, 766), (3, 1069)]),
(pmNode_750, .global, []),
(pmNode_751, .global, []),
(pmNode_752, .group (some [2, 3]), [(2, 895), (3, 1198)]),
(pmNode_753, .global, []),
(pmNode_754, .global, []),
(pmNode_755, .global, []),
(pmNode_756, .global, []),
(pmNode_757, .group (some [2, 3]), [(2, 783), (3, 1086)]),
(pmNode_758, .global, []),
(pmNode_759, .global, []),
(pmNode_760, .group (some [2, 3]), [(2, 897), (3, 1200)]),
(pmNode_761, .global, []),
(pmNode_762, .global, []),
(pmNode_763, .group (some [2, 3]), [(2, 899), (3, 1202)]),
(pmNode_764, .global, []),
(pmNode_765, .group (some [2, 3]), [(2, 901), (3, 1204)]),
(pmNode_766, .global, []),
(pmNode_767, .group (some [2, 3]), [(2, 903), (3, 1206)]),
(pmNode_768, .global, []),
(pmNode_769, .group (some [2, 3]), [(2, 795), (3, 1098)]),
(pmNode_770, .global, []),
(pmNode_771, .group (some [2, 3]), [(2, 805), (3, 1108)]),
(pmNode_772, .global, []),
(pmNode_773, .group (some [2, 3]), [(2, 799), (3, 1102)]),
(pmNode_774, .global, []),
(pmNode_775, .group (some [2, 3]), [(2, 813), (3, 1116)]),
(pmNode_776, .global, []),
(pmNode_777, .group (some [2, 3]), [(2, 802), (3, 1105)]),
(pmNode_778, .global, []),
(pmNode_779, .group (some [2, 3]), [(2, 821), (3, 1124)]),
(pmNode_780, .global, []),
(pmNode_781, .global, []),
(pmNode_782, .group (some [2, 3]), [(2, 828), (3, 1131)]),
(pmNode_783, .global, []),
(pmNode_784, .group (some [2, 3]), [(2, 831), (3, 1134)]),
(pmNode_785, .global, []),
(pmNode_786, .group (some [2, 3]), [(2, 835), (3, 1138)]),
(pmNode_787, .global, []),
(pmNode_788, .group (some [2, 3]), [(2, 825), (3, 1128)]),
(pmNode_789, .global, []),
(pmNode_790, .group (some [2, 3]), [(2, 842), (3, 1145)]),
(pmNode_791, .global, []),
(pmNode_792, .group (some [2, 3]), [(2, 846), (3, 1149)]),
(pmNode_793, .global, []),
(pmNode_794, .group (some [2, 3]), [(2, 850), (3, 1153)]),
(pmNode_795, .global, []),
(pmNode_796, .global, []),
(pmNode_797, .group (some [2, 3]), [(2, 857), (3, 1160)]),
(pmNode_798, .global, []),
(pmNode_799, .global, []),
(pmNode_800, .group (some [2, 3]), [(2, 905), (3, 1208)]),
(pmNode_801, .global, []),
(pmNode_802, .group (some [2, 3]), [(2, 865), (3, 1168)]),
(pmNode_803, .global, []),
(pmNode_804, .group (some [2, 3]), [(2, 869), (3, 1172)]),
(pmNode_805, .global, []),
(pmNode_806, .global, []),
(pmNode_807, .group (some [2, 3]), [(2, 907), (3, 1210)]),
(pmNode_808, .global, []),
(pmNode_809, .global, []),
(pmNode_810, .group (some [2, 3]), [(2, 881), (3, 1184)]),
(pmNode_811, .global, []),
(pmNode_812, .group (some [2, 3]), [(2, 883), (3, 1186)]),
(pmNode_813, .global, []),
(pmNode_814, .group (some [2, 3]), [(2, 887), (3, 1190)]),
(pmNode_815, .global, []),
(pmNode_816, .group (some [2, 3]), [(2, 888), (3, 1191)]),
(pmNode_817, .global, []),
(pmNode_818, .group (some [2, 3]), [(2, 885), (3, 1187)]),
(pmNode_819, .global, []),
(pmNode_820, .global, []),
(pmNode_821, .group (some [2, 3]), [(2, 879), (3, 1182)]),
(pmNode_822, .global, []),
(pmNode_823, .global, []),
(pmNode_824, .group (some [2, 3]), [(2, 873), (3, 1176)]),
(pmNode_825, .global, []),
(pmNode_826, .group (some [2, 3]), [(2, 870), (3, 1173)]),
(pmNode_827, .global, []),
(pmNode_828, .group (some [2, 3]), [(2, 866), (3, 1169)]),
(pmNode_829, .global, []),
(pmNode_830, .global, []),
(pmNode_831, .group (some [2, 3]), [(2, 862), (3, 1165)]),
(pmNode_832, .global, []),
(pmNode_833, .global, []),
(pmNode_834, .group (some [2, 3]), [(2, 855), (3, 1158)]),
(pmNode_835, .global, []),
(pmNode_836, .group (some [2, 3]), [(2, 851), (3, 1154)]),
(pmNode_837, .global, []),
(pmNode_838, .group (some [2, 3]), [(2, 847), (3, 1150)]),
(pmNode_839, .global, []),
(pmNode_840, .group (some [2, 3]), [(2, 844), (3, 1146)]),
(pmNode_841, .global, []),
(pmNode_842, .group (some [2, 3]), [(2, 840), (3, 1143)]),
(pmNode_843, .global, []),
(pmNode_844, .group (some [2, 3]), [(2, 836), (3, 1139)]),
(pmNode_845, .global, []),
(pmNode_846, .group (some [2, 3]), [(2, 832), (3, 1135)]),
(pmNode_847, .global, []),
(pmNode_848, .global, []),
(pmNode_849, .group (some [2, 3]), [(2, 826), (3, 1129)]),
(pmNode_850, .global, []),
(pmNode_851, .group (some [2, 3]), [(2, 822), (3, 1125)]),
(pmNode_852, .global, []),
(pmNode_853, .group (some [2, 3]), [(2, 818), (3, 1121)]),
(pmNode_854, .global, []),
(pmNode_855, .group (some [2, 3]), [(2, 814), (3, 1117)]),
(pmNode_856, .global, []),
(pmNode_857, .group (some [2, 3]), [(2, 810), (3, 1113)]),
(pmNode_858, .global, []),
(pmNode_859, .group (some [2, 3]), [(2, 806), (3, 1109)]),
(pmNode_860, .global, []),
(pmNode_861, .group (some [2, 3]), [(2, 803), (3, 1106)]),
(pmNode_862, .global, []),
(pmNode_863, .group (some [2, 3]), [(2, 800), (3, 1103)]),
(pmNode_864, .global, []),
(pmNode_865, .group (some [2, 3]), [(2, 797), (3, 1099)]),
(pmNode_866, .global, []),
(pmNode_867, .global, []),
(pmNode_868, .group (some [2, 3]), [(2, 793), (3, 1096)]),
(pmNode_869, .global, []),
(pmNode_870, .global, []),
(pmNode_871, .group (some [2, 3]), [(2, 789), (3, 1092)]),
(pmNode_872, .global, []),
(pmNode_873, .global, []),
(pmNode_874, .global, []),
(pmNode_875, .global, []),
(pmNode_876, .group (some [2, 3]), [(2, 777), (3, 1080)]),
(pmNode_877, .global, []),
(pmNode_878, .global, []),
(pmNode_879, .group (some [2, 3]), [(2, 773), (3, 1076)]),
(pmNode_880, .global, []),
(pmNode_881, .group (some [2, 3]), [(2, 767), (3, 1070)]),
(pmNode_882, .global, []),
(pmNode_883, .group (some [2, 3]), [(2, 763), (3, 1066)]),
(pmNode_884, .global, []),
(pmNode_885, .global, []),
(pmNode_886, .global, []),
(pmNode_887, .group (some [2, 3]), [(2, 754), (3, 1058)]),
(pmNode_888, .group (some [2, 3]), [(2, 756), (3, 1057)]),
(pmNode_889, .global, []),
(pmNode_890, .group (some [2, 3]), [(2, 750), (3, 1053)]),
(pmNode_891, .global, []),
(pmNode_892, .group (some [2, 3]), [(2, 746), (3, 1049)]),
(pmNode_893, .global, []),
(pmNode_894, .group (some [2, 3]), [(2, 742), (3, 1045)]),
(pmNode_895, .group (some [2, 3]), [(2, 741), (3, 1044)]),
(pmNode_896, .global, []),
(pmNode_897, .global, []),
(pmNode_898, .global, []),
(pmNode_899, .group (some [2, 3]), [(2, 732), (3, 1035)]),
(pmNode_900, .global, []),
(pmNode_901, .group (some [2, 3]), [(2, 728), (3, 1031)]),
(pmNode_902, .global, []),
(pmNode_903, .global, []),
(pmNode_904, .group (some [2, 3]), [(2, 722), (3, 1025)]),
(pmNode_905, .global, []),
(pmNode_906, .global, []),
(pmNode_907, .group (some [2, 3]), [(2, 717), (3, 1019)]),
(pmNode_908, .global, []),
(pmNode_909, .group (some [2, 3]), [(2, 714), (3, 1016)]),
(pmNode_910, .global, []),
(pmNode_911, .global, []),
(pmNode_912, .global, []),
(pmNode_913, .group (some [2, 3]), [(2, 706), (3, 1009)]),
(pmNode_914, .global, []),
(pmNode_915, .global, []),
(pmNode_916, .group (some [2, 3]), [(2, 702), (3, 1005)]),
(pmNode_917, .global, []),
(pmNode_918, .global, []),
(pmNode_919, .group (some [0, 1, 2, 3]), [(0, 19), (1, 322), (2, 625), (3, 928)]),
(pmNode_920, .group (some [0, 1, 2, 3]), [(0, 21), (1, 324), (2, 627), (3, 930)]),
(pmNode_921, .group (some [0, 1, 2, 3]), [(0, 23), (1, 326), (2, 629), (3, 932)]),
(pmNode_922, .group (some [0, 1, 2, 3]), [(0, 59), (1, 362), (2, 665), (3, 968)]),
(pmNode_923, .group (some [0, 1, 2, 3]), [(0, 25), (1, 328), (2, 631), (3, 934)]),
(pmNode_924, .group (some [0, 1, 2, 3]), [(0, 61), (1, 364), (2, 667), (3, 970)]),
(pmNode_925, .group (some [0, 1, 2, 3]), [(0, 66), (1, 369), (2, 672), (3, 975)]),
(pmNode_926, .group (some [0, 1, 2, 3]), [(0, 68), (1, 371), (2, 674), (3, 977)]),
(pmNode_927, .group (some [0, 1, 2, 3]), [(0, 70), (1, 373), (2, 676), (3, 979)]),
(pmNode_928, .group (some [0, 1, 2, 3]), [(0, 33), (1, 336), (2, 639), (3, 942)]),
(pmNode_929, .group (some [0, 1, 2, 3]), [(0, 35), (1, 338), (2, 641), (3, 944)]),
(pmNode_930, .group (some [0, 1, 2, 3]), [(0, 37), (1, 340), (2, 643), (3, 946)]),
(pmNode_931, .group (some [0, 1, 2, 3]), [(0, 39), (1, 342), (2, 645), (3, 948)]),
(pmNode_932, .group (some [0, 1, 2, 3]), [(0, 41), (1, 344), (2, 647), (3, 950)]),
(pmNode_933, .group (some [0, 1, 2, 3]), [(0, 43), (1, 346), (2, 649), (3, 952)]),
(pmNode_934, .group (some [0, 1, 2, 3]), [(0, 45), (1, 348), (2, 651), (3, 954)]),
(pmNode_935, .group (some [1, 3]), [(1, 320), (3, 926)]),
(pmNode_936, .group (some [1, 3]), [(1, 360), (3, 966)]),
(pmNode_937, .group (some [1, 3]), [(1, 331), (3, 937)]),
(pmNode_938, .group (some [1, 3]), [(1, 367), (3, 973)]),
(pmNode_939, .group (some [1, 3]), [(1, 334), (3, 940)]),
(pmNode_940, .group (some [1, 3]), [(1, 376), (3, 982)]),
(pmNode_941, .group (some [1, 3]), [(1, 351), (3, 957)]),
(pmNode_942, .group (some [1, 3]), [(1, 354), (3, 960)]),
(pmNode_943, .group (some [1, 3]), [(1, 357), (3, 963)])
]
def pmScope (n : NodeDecl) : GroupScopedEval.Request :=
  match pmRequests.find? (fun row => row.1 == n) with
  | some row => row.2.1
  | none => .group none
def pmPeers (n : NodeDecl) (r : Nat) : Tid :=
  match pmRequests.find? (fun row => row.1 == n) with
  | some row => ((row.2.2.find? (fun p => p.1 == r)).map Prod.snd).getD 0
  | none => 0
def pmDenote (s : Store) : Option Store := SourceScopedEval.denote pmGraph pmScope pmPeers s
end
end TrainVerify.Denote.RuntimeWorld

namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
set_option maxRecDepth 4096
open SourceScopedEval
def smNode_0_port0_values : List Int := [156, 253, 250, 4, 202, 242, 159, 41, 53, 62, 111, 210, 69, 58, 110, 91, 173, 14, 11, 21, 219, 3, 176, 58, 70, 79, 128, 227, 86, 75, 127, 108]
def smNode_0_port0 : Tensor := {shape := [2, 16], val := fun i => ((smNode_0_port0_values.getD i.val 0 : Int) : Scalar)}
theorem smNode_0_port0_shape : smNode_0_port0.shape = [2, 16] := rfl
#print axioms smNode_0_port0_shape
theorem smNode_0_port0_length : smNode_0_port0_values.length = prodShape smNode_0_port0.shape := rfl
#print axioms smNode_0_port0_length
theorem smNode_0_port0_encoding (i : Fin (prodShape smNode_0_port0.shape)) : smNode_0_port0.val i = ((smNode_0_port0_values.getD i.val 0 : Int) : Scalar) := rfl
#print axioms smNode_0_port0_encoding
def smNode_0_port1_values : List Int := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
def smNode_0_port1 : Tensor := {shape := [2, 16], val := fun i => ((smNode_0_port1_values.getD i.val 0 : Int) : Scalar)}
theorem smNode_0_port1_shape : smNode_0_port1.shape = [2, 16] := rfl
#print axioms smNode_0_port1_shape
theorem smNode_0_port1_length : smNode_0_port1_values.length = prodShape smNode_0_port1.shape := rfl
#print axioms smNode_0_port1_length
theorem smNode_0_port1_encoding (i : Fin (prodShape smNode_0_port1.shape)) : smNode_0_port1.val i = ((smNode_0_port1_values.getD i.val 0 : Int) : Scalar) := rfl
#print axioms smNode_0_port1_encoding
def smNode_0_feed : PortFeed := [(1262, smNode_0_port0), (1263, smNode_0_port1)]
theorem smNode_0_contract : InputContract smNode_0 smNode_0_feed := by decide
#print axioms smNode_0_contract
theorem smNode_0_step (s : Store) : checkedInputStep s smNode_0 smNode_0_feed = some (storeSet s smNode_0_feed) := checkedInputStep_valid s smNode_0 smNode_0_feed smNode_0_contract
#print axioms smNode_0_step
theorem smNode_0_scoped_step (s : Store) : stepWithInputs smGraph (smScope smNode_0) (smPeers smNode_0) s smNode_0 (some smNode_0_feed) = some (storeSet s smNode_0_feed) := by
  change checkedInputStep s smNode_0 smNode_0_feed = _
  exact smNode_0_step s
#print axioms smNode_0_scoped_step
theorem smNode_0_frame (s : Store) (tid : Tid) (h : tid ∉ smNode_0.outs) : storeSet s smNode_0_feed tid = s tid := checkedInputStep_skip s (storeSet s smNode_0_feed) smNode_0 smNode_0_feed tid h (smNode_0_step s)
#print axioms smNode_0_frame
theorem smNode_0_read0 (s : Store) : storeSet s smNode_0_feed 1262 = smNode_0_port0 := checkedInputStep_value s (storeSet s smNode_0_feed) smNode_0 smNode_0_feed 1262 smNode_0_port0 (by simp [smNode_0_feed]) (smNode_0_step s)
#print axioms smNode_0_read0
theorem smNode_0_read1 (s : Store) : storeSet s smNode_0_feed 1263 = smNode_0_port1 := checkedInputStep_value s (storeSet s smNode_0_feed) smNode_0 smNode_0_feed 1263 smNode_0_port1 (by simp [smNode_0_feed]) (smNode_0_step s)
#print axioms smNode_0_read1
def smInputRequests : List InputRequest := [
(smNode_0, some smNode_0_feed),
(smNode_1, none),
(smNode_2, none),
(smNode_3, none),
(smNode_4, none),
(smNode_5, none),
(smNode_6, none),
(smNode_7, none),
(smNode_8, none),
(smNode_9, none),
(smNode_10, none),
(smNode_11, none),
(smNode_12, none),
(smNode_13, none),
(smNode_14, none),
(smNode_15, none),
(smNode_16, none),
(smNode_17, none),
(smNode_18, none),
(smNode_19, none),
(smNode_20, none),
(smNode_21, none),
(smNode_22, none),
(smNode_23, none),
(smNode_24, none),
(smNode_25, none),
(smNode_26, none),
(smNode_27, none),
(smNode_28, none),
(smNode_29, none),
(smNode_30, none),
(smNode_31, none),
(smNode_32, none),
(smNode_33, none),
(smNode_34, none),
(smNode_35, none),
(smNode_36, none),
(smNode_37, none),
(smNode_38, none),
(smNode_39, none),
(smNode_40, none),
(smNode_41, none),
(smNode_42, none),
(smNode_43, none),
(smNode_44, none),
(smNode_45, none),
(smNode_46, none),
(smNode_47, none),
(smNode_48, none),
(smNode_49, none),
(smNode_50, none),
(smNode_51, none),
(smNode_52, none),
(smNode_53, none),
(smNode_54, none),
(smNode_55, none),
(smNode_56, none),
(smNode_57, none),
(smNode_58, none),
(smNode_59, none),
(smNode_60, none),
(smNode_61, none),
(smNode_62, none),
(smNode_63, none),
(smNode_64, none),
(smNode_65, none),
(smNode_66, none),
(smNode_67, none),
(smNode_68, none),
(smNode_69, none),
(smNode_70, none),
(smNode_71, none),
(smNode_72, none),
(smNode_73, none),
(smNode_74, none),
(smNode_75, none),
(smNode_76, none),
(smNode_77, none),
(smNode_78, none),
(smNode_79, none),
(smNode_80, none),
(smNode_81, none),
(smNode_82, none),
(smNode_83, none),
(smNode_84, none),
(smNode_85, none),
(smNode_86, none),
(smNode_87, none),
(smNode_88, none),
(smNode_89, none),
(smNode_90, none),
(smNode_91, none),
(smNode_92, none),
(smNode_93, none),
(smNode_94, none),
(smNode_95, none),
(smNode_96, none),
(smNode_97, none),
(smNode_98, none),
(smNode_99, none),
(smNode_100, none),
(smNode_101, none),
(smNode_102, none),
(smNode_103, none),
(smNode_104, none),
(smNode_105, none),
(smNode_106, none),
(smNode_107, none),
(smNode_108, none),
(smNode_109, none),
(smNode_110, none),
(smNode_111, none),
(smNode_112, none),
(smNode_113, none),
(smNode_114, none),
(smNode_115, none),
(smNode_116, none),
(smNode_117, none),
(smNode_118, none),
(smNode_119, none),
(smNode_120, none),
(smNode_121, none),
(smNode_122, none),
(smNode_123, none),
(smNode_124, none)
]
def smDenoteWithInputs (s : Store) : Option Store := SourceScopedEval.denoteWithInputs smGraph smScope smPeers (some smInputRequests) s
theorem smInputSchedule_valid : SourceScopedEval.InputSchedule smGraph.nodes smInputRequests := by
  constructor
  · rfl
  · apply (List.perm_insertionSort (fun a b : Nat => a ≤ b) _).nodup_iff.mp
    apply List.Pairwise.nodup (r := fun a b : Nat => a < b)
    apply List.isChain_iff_pairwise.mp
    decide +kernel
#print axioms smInputSchedule_valid
theorem smDenoteWithInputs_entry (s : Store) : smDenoteWithInputs s = SourceScopedEval.runUsing (fun row s => SourceScopedEval.stepWithInputs smGraph (smScope row.1) (smPeers row.1) s row.1 row.2) smInputRequests (some s) := by
  unfold smDenoteWithInputs SourceScopedEval.denoteWithInputs SourceScopedEval.runWithInputs
  exact if_pos smInputSchedule_valid
#print axioms smDenoteWithInputs_entry
def pmNode_0_port0_values : List Int := [156, 253, 250, 4, 202, 242, 159, 41, 53, 62, 111, 210, 69, 58, 110, 91]
def pmNode_0_port0 : Tensor := {shape := [1, 16], val := fun i => ((pmNode_0_port0_values.getD i.val 0 : Int) : Scalar)}
theorem pmNode_0_port0_shape : pmNode_0_port0.shape = [1, 16] := rfl
#print axioms pmNode_0_port0_shape
theorem pmNode_0_port0_length : pmNode_0_port0_values.length = prodShape pmNode_0_port0.shape := rfl
#print axioms pmNode_0_port0_length
theorem pmNode_0_port0_encoding (i : Fin (prodShape pmNode_0_port0.shape)) : pmNode_0_port0.val i = ((pmNode_0_port0_values.getD i.val 0 : Int) : Scalar) := rfl
#print axioms pmNode_0_port0_encoding
def pmNode_0_port1_values : List Int := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
def pmNode_0_port1 : Tensor := {shape := [1, 16], val := fun i => ((pmNode_0_port1_values.getD i.val 0 : Int) : Scalar)}
theorem pmNode_0_port1_shape : pmNode_0_port1.shape = [1, 16] := rfl
#print axioms pmNode_0_port1_shape
theorem pmNode_0_port1_length : pmNode_0_port1_values.length = prodShape pmNode_0_port1.shape := rfl
#print axioms pmNode_0_port1_length
theorem pmNode_0_port1_encoding (i : Fin (prodShape pmNode_0_port1.shape)) : pmNode_0_port1.val i = ((pmNode_0_port1_values.getD i.val 0 : Int) : Scalar) := rfl
#print axioms pmNode_0_port1_encoding
def pmNode_0_feed : PortFeed := [(75, pmNode_0_port0), (76, pmNode_0_port1)]
theorem pmNode_0_contract : InputContract pmNode_0 pmNode_0_feed := by decide
#print axioms pmNode_0_contract
theorem pmNode_0_step (s : Store) : checkedInputStep s pmNode_0 pmNode_0_feed = some (storeSet s pmNode_0_feed) := checkedInputStep_valid s pmNode_0 pmNode_0_feed pmNode_0_contract
#print axioms pmNode_0_step
theorem pmNode_0_scoped_step (s : Store) : stepWithInputs pmGraph (pmScope pmNode_0) (pmPeers pmNode_0) s pmNode_0 (some pmNode_0_feed) = some (storeSet s pmNode_0_feed) := by
  change checkedInputStep s pmNode_0 pmNode_0_feed = _
  exact pmNode_0_step s
#print axioms pmNode_0_scoped_step
theorem pmNode_0_frame (s : Store) (tid : Tid) (h : tid ∉ pmNode_0.outs) : storeSet s pmNode_0_feed tid = s tid := checkedInputStep_skip s (storeSet s pmNode_0_feed) pmNode_0 pmNode_0_feed tid h (pmNode_0_step s)
#print axioms pmNode_0_frame
theorem pmNode_0_read0 (s : Store) : storeSet s pmNode_0_feed 75 = pmNode_0_port0 := checkedInputStep_value s (storeSet s pmNode_0_feed) pmNode_0 pmNode_0_feed 75 pmNode_0_port0 (by simp [pmNode_0_feed]) (pmNode_0_step s)
#print axioms pmNode_0_read0
theorem pmNode_0_read1 (s : Store) : storeSet s pmNode_0_feed 76 = pmNode_0_port1 := checkedInputStep_value s (storeSet s pmNode_0_feed) pmNode_0 pmNode_0_feed 76 pmNode_0_port1 (by simp [pmNode_0_feed]) (pmNode_0_step s)
#print axioms pmNode_0_read1
def pmNode_236_port0_values : List Int := [156, 253, 250, 4, 202, 242, 159, 41, 53, 62, 111, 210, 69, 58, 110, 91]
def pmNode_236_port0 : Tensor := {shape := [1, 16], val := fun i => ((pmNode_236_port0_values.getD i.val 0 : Int) : Scalar)}
theorem pmNode_236_port0_shape : pmNode_236_port0.shape = [1, 16] := rfl
#print axioms pmNode_236_port0_shape
theorem pmNode_236_port0_length : pmNode_236_port0_values.length = prodShape pmNode_236_port0.shape := rfl
#print axioms pmNode_236_port0_length
theorem pmNode_236_port0_encoding (i : Fin (prodShape pmNode_236_port0.shape)) : pmNode_236_port0.val i = ((pmNode_236_port0_values.getD i.val 0 : Int) : Scalar) := rfl
#print axioms pmNode_236_port0_encoding
def pmNode_236_port1_values : List Int := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
def pmNode_236_port1 : Tensor := {shape := [1, 16], val := fun i => ((pmNode_236_port1_values.getD i.val 0 : Int) : Scalar)}
theorem pmNode_236_port1_shape : pmNode_236_port1.shape = [1, 16] := rfl
#print axioms pmNode_236_port1_shape
theorem pmNode_236_port1_length : pmNode_236_port1_values.length = prodShape pmNode_236_port1.shape := rfl
#print axioms pmNode_236_port1_length
theorem pmNode_236_port1_encoding (i : Fin (prodShape pmNode_236_port1.shape)) : pmNode_236_port1.val i = ((pmNode_236_port1_values.getD i.val 0 : Int) : Scalar) := rfl
#print axioms pmNode_236_port1_encoding
def pmNode_236_feed : PortFeed := [(378, pmNode_236_port0), (379, pmNode_236_port1)]
theorem pmNode_236_contract : InputContract pmNode_236 pmNode_236_feed := by decide
#print axioms pmNode_236_contract
theorem pmNode_236_step (s : Store) : checkedInputStep s pmNode_236 pmNode_236_feed = some (storeSet s pmNode_236_feed) := checkedInputStep_valid s pmNode_236 pmNode_236_feed pmNode_236_contract
#print axioms pmNode_236_step
theorem pmNode_236_scoped_step (s : Store) : stepWithInputs pmGraph (pmScope pmNode_236) (pmPeers pmNode_236) s pmNode_236 (some pmNode_236_feed) = some (storeSet s pmNode_236_feed) := by
  change checkedInputStep s pmNode_236 pmNode_236_feed = _
  exact pmNode_236_step s
#print axioms pmNode_236_scoped_step
theorem pmNode_236_frame (s : Store) (tid : Tid) (h : tid ∉ pmNode_236.outs) : storeSet s pmNode_236_feed tid = s tid := checkedInputStep_skip s (storeSet s pmNode_236_feed) pmNode_236 pmNode_236_feed tid h (pmNode_236_step s)
#print axioms pmNode_236_frame
theorem pmNode_236_read0 (s : Store) : storeSet s pmNode_236_feed 378 = pmNode_236_port0 := checkedInputStep_value s (storeSet s pmNode_236_feed) pmNode_236 pmNode_236_feed 378 pmNode_236_port0 (by simp [pmNode_236_feed]) (pmNode_236_step s)
#print axioms pmNode_236_read0
theorem pmNode_236_read1 (s : Store) : storeSet s pmNode_236_feed 379 = pmNode_236_port1 := checkedInputStep_value s (storeSet s pmNode_236_feed) pmNode_236 pmNode_236_feed 379 pmNode_236_port1 (by simp [pmNode_236_feed]) (pmNode_236_step s)
#print axioms pmNode_236_read1
def pmNode_472_port0_values : List Int := [173, 14, 11, 21, 219, 3, 176, 58, 70, 79, 128, 227, 86, 75, 127, 108]
def pmNode_472_port0 : Tensor := {shape := [1, 16], val := fun i => ((pmNode_472_port0_values.getD i.val 0 : Int) : Scalar)}
theorem pmNode_472_port0_shape : pmNode_472_port0.shape = [1, 16] := rfl
#print axioms pmNode_472_port0_shape
theorem pmNode_472_port0_length : pmNode_472_port0_values.length = prodShape pmNode_472_port0.shape := rfl
#print axioms pmNode_472_port0_length
theorem pmNode_472_port0_encoding (i : Fin (prodShape pmNode_472_port0.shape)) : pmNode_472_port0.val i = ((pmNode_472_port0_values.getD i.val 0 : Int) : Scalar) := rfl
#print axioms pmNode_472_port0_encoding
def pmNode_472_port1_values : List Int := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
def pmNode_472_port1 : Tensor := {shape := [1, 16], val := fun i => ((pmNode_472_port1_values.getD i.val 0 : Int) : Scalar)}
theorem pmNode_472_port1_shape : pmNode_472_port1.shape = [1, 16] := rfl
#print axioms pmNode_472_port1_shape
theorem pmNode_472_port1_length : pmNode_472_port1_values.length = prodShape pmNode_472_port1.shape := rfl
#print axioms pmNode_472_port1_length
theorem pmNode_472_port1_encoding (i : Fin (prodShape pmNode_472_port1.shape)) : pmNode_472_port1.val i = ((pmNode_472_port1_values.getD i.val 0 : Int) : Scalar) := rfl
#print axioms pmNode_472_port1_encoding
def pmNode_472_feed : PortFeed := [(681, pmNode_472_port0), (682, pmNode_472_port1)]
theorem pmNode_472_contract : InputContract pmNode_472 pmNode_472_feed := by decide
#print axioms pmNode_472_contract
theorem pmNode_472_step (s : Store) : checkedInputStep s pmNode_472 pmNode_472_feed = some (storeSet s pmNode_472_feed) := checkedInputStep_valid s pmNode_472 pmNode_472_feed pmNode_472_contract
#print axioms pmNode_472_step
theorem pmNode_472_scoped_step (s : Store) : stepWithInputs pmGraph (pmScope pmNode_472) (pmPeers pmNode_472) s pmNode_472 (some pmNode_472_feed) = some (storeSet s pmNode_472_feed) := by
  change checkedInputStep s pmNode_472 pmNode_472_feed = _
  exact pmNode_472_step s
#print axioms pmNode_472_scoped_step
theorem pmNode_472_frame (s : Store) (tid : Tid) (h : tid ∉ pmNode_472.outs) : storeSet s pmNode_472_feed tid = s tid := checkedInputStep_skip s (storeSet s pmNode_472_feed) pmNode_472 pmNode_472_feed tid h (pmNode_472_step s)
#print axioms pmNode_472_frame
theorem pmNode_472_read0 (s : Store) : storeSet s pmNode_472_feed 681 = pmNode_472_port0 := checkedInputStep_value s (storeSet s pmNode_472_feed) pmNode_472 pmNode_472_feed 681 pmNode_472_port0 (by simp [pmNode_472_feed]) (pmNode_472_step s)
#print axioms pmNode_472_read0
theorem pmNode_472_read1 (s : Store) : storeSet s pmNode_472_feed 682 = pmNode_472_port1 := checkedInputStep_value s (storeSet s pmNode_472_feed) pmNode_472 pmNode_472_feed 682 pmNode_472_port1 (by simp [pmNode_472_feed]) (pmNode_472_step s)
#print axioms pmNode_472_read1
def pmNode_708_port0_values : List Int := [173, 14, 11, 21, 219, 3, 176, 58, 70, 79, 128, 227, 86, 75, 127, 108]
def pmNode_708_port0 : Tensor := {shape := [1, 16], val := fun i => ((pmNode_708_port0_values.getD i.val 0 : Int) : Scalar)}
theorem pmNode_708_port0_shape : pmNode_708_port0.shape = [1, 16] := rfl
#print axioms pmNode_708_port0_shape
theorem pmNode_708_port0_length : pmNode_708_port0_values.length = prodShape pmNode_708_port0.shape := rfl
#print axioms pmNode_708_port0_length
theorem pmNode_708_port0_encoding (i : Fin (prodShape pmNode_708_port0.shape)) : pmNode_708_port0.val i = ((pmNode_708_port0_values.getD i.val 0 : Int) : Scalar) := rfl
#print axioms pmNode_708_port0_encoding
def pmNode_708_port1_values : List Int := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
def pmNode_708_port1 : Tensor := {shape := [1, 16], val := fun i => ((pmNode_708_port1_values.getD i.val 0 : Int) : Scalar)}
theorem pmNode_708_port1_shape : pmNode_708_port1.shape = [1, 16] := rfl
#print axioms pmNode_708_port1_shape
theorem pmNode_708_port1_length : pmNode_708_port1_values.length = prodShape pmNode_708_port1.shape := rfl
#print axioms pmNode_708_port1_length
theorem pmNode_708_port1_encoding (i : Fin (prodShape pmNode_708_port1.shape)) : pmNode_708_port1.val i = ((pmNode_708_port1_values.getD i.val 0 : Int) : Scalar) := rfl
#print axioms pmNode_708_port1_encoding
def pmNode_708_feed : PortFeed := [(984, pmNode_708_port0), (985, pmNode_708_port1)]
theorem pmNode_708_contract : InputContract pmNode_708 pmNode_708_feed := by decide
#print axioms pmNode_708_contract
theorem pmNode_708_step (s : Store) : checkedInputStep s pmNode_708 pmNode_708_feed = some (storeSet s pmNode_708_feed) := checkedInputStep_valid s pmNode_708 pmNode_708_feed pmNode_708_contract
#print axioms pmNode_708_step
theorem pmNode_708_scoped_step (s : Store) : stepWithInputs pmGraph (pmScope pmNode_708) (pmPeers pmNode_708) s pmNode_708 (some pmNode_708_feed) = some (storeSet s pmNode_708_feed) := by
  change checkedInputStep s pmNode_708 pmNode_708_feed = _
  exact pmNode_708_step s
#print axioms pmNode_708_scoped_step
theorem pmNode_708_frame (s : Store) (tid : Tid) (h : tid ∉ pmNode_708.outs) : storeSet s pmNode_708_feed tid = s tid := checkedInputStep_skip s (storeSet s pmNode_708_feed) pmNode_708 pmNode_708_feed tid h (pmNode_708_step s)
#print axioms pmNode_708_frame
theorem pmNode_708_read0 (s : Store) : storeSet s pmNode_708_feed 984 = pmNode_708_port0 := checkedInputStep_value s (storeSet s pmNode_708_feed) pmNode_708 pmNode_708_feed 984 pmNode_708_port0 (by simp [pmNode_708_feed]) (pmNode_708_step s)
#print axioms pmNode_708_read0
theorem pmNode_708_read1 (s : Store) : storeSet s pmNode_708_feed 985 = pmNode_708_port1 := checkedInputStep_value s (storeSet s pmNode_708_feed) pmNode_708 pmNode_708_feed 985 pmNode_708_port1 (by simp [pmNode_708_feed]) (pmNode_708_step s)
#print axioms pmNode_708_read1
def pmInputRequests : List InputRequest := [
(pmNode_0, some pmNode_0_feed),
(pmNode_1, none),
(pmNode_2, none),
(pmNode_3, none),
(pmNode_236, some pmNode_236_feed),
(pmNode_237, none),
(pmNode_238, none),
(pmNode_239, none),
(pmNode_4, none),
(pmNode_5, none),
(pmNode_6, none),
(pmNode_240, none),
(pmNode_241, none),
(pmNode_242, none),
(pmNode_7, none),
(pmNode_8, none),
(pmNode_9, none),
(pmNode_10, none),
(pmNode_243, none),
(pmNode_244, none),
(pmNode_245, none),
(pmNode_11, none),
(pmNode_12, none),
(pmNode_13, none),
(pmNode_14, none),
(pmNode_15, none),
(pmNode_246, none),
(pmNode_247, none),
(pmNode_248, none),
(pmNode_249, none),
(pmNode_250, none),
(pmNode_251, none),
(pmNode_16, none),
(pmNode_17, none),
(pmNode_18, none),
(pmNode_252, none),
(pmNode_253, none),
(pmNode_254, none),
(pmNode_19, none),
(pmNode_20, none),
(pmNode_21, none),
(pmNode_22, none),
(pmNode_23, none),
(pmNode_24, none),
(pmNode_25, none),
(pmNode_255, none),
(pmNode_256, none),
(pmNode_257, none),
(pmNode_258, none),
(pmNode_259, none),
(pmNode_260, none),
(pmNode_26, none),
(pmNode_27, none),
(pmNode_261, none),
(pmNode_262, none),
(pmNode_263, none),
(pmNode_28, none),
(pmNode_29, none),
(pmNode_264, none),
(pmNode_265, none),
(pmNode_30, none),
(pmNode_31, none),
(pmNode_32, none),
(pmNode_266, none),
(pmNode_267, none),
(pmNode_33, none),
(pmNode_34, none),
(pmNode_35, none),
(pmNode_36, none),
(pmNode_268, none),
(pmNode_269, none),
(pmNode_270, none),
(pmNode_271, none),
(pmNode_272, none),
(pmNode_37, none),
(pmNode_38, none),
(pmNode_273, none),
(pmNode_274, none),
(pmNode_39, none),
(pmNode_40, none),
(pmNode_275, none),
(pmNode_276, none),
(pmNode_41, none),
(pmNode_42, none),
(pmNode_43, none),
(pmNode_277, none),
(pmNode_278, none),
(pmNode_279, none),
(pmNode_44, none),
(pmNode_45, none),
(pmNode_46, none),
(pmNode_47, none),
(pmNode_48, none),
(pmNode_280, none),
(pmNode_281, none),
(pmNode_282, none),
(pmNode_283, none),
(pmNode_284, none),
(pmNode_49, none),
(pmNode_50, none),
(pmNode_51, none),
(pmNode_285, none),
(pmNode_286, none),
(pmNode_287, none),
(pmNode_52, none),
(pmNode_53, none),
(pmNode_54, none),
(pmNode_288, none),
(pmNode_289, none),
(pmNode_290, none),
(pmNode_55, none),
(pmNode_56, none),
(pmNode_57, none),
(pmNode_58, none),
(pmNode_59, none),
(pmNode_60, none),
(pmNode_291, none),
(pmNode_292, none),
(pmNode_61, none),
(pmNode_62, none),
(pmNode_293, none),
(pmNode_294, none),
(pmNode_295, none),
(pmNode_296, none),
(pmNode_297, none),
(pmNode_298, none),
(pmNode_63, none),
(pmNode_64, none),
(pmNode_65, none),
(pmNode_66, none),
(pmNode_299, none),
(pmNode_300, none),
(pmNode_301, none),
(pmNode_302, none),
(pmNode_67, none),
(pmNode_68, none),
(pmNode_69, none),
(pmNode_70, none),
(pmNode_303, none),
(pmNode_304, none),
(pmNode_305, none),
(pmNode_306, none),
(pmNode_71, none),
(pmNode_72, none),
(pmNode_73, none),
(pmNode_307, none),
(pmNode_308, none),
(pmNode_309, none),
(pmNode_74, none),
(pmNode_75, none),
(pmNode_310, none),
(pmNode_311, none),
(pmNode_76, none),
(pmNode_77, none),
(pmNode_312, none),
(pmNode_313, none),
(pmNode_78, none),
(pmNode_79, none),
(pmNode_80, none),
(pmNode_81, none),
(pmNode_314, none),
(pmNode_315, none),
(pmNode_316, none),
(pmNode_317, none),
(pmNode_82, none),
(pmNode_83, none),
(pmNode_318, none),
(pmNode_319, none),
(pmNode_84, none),
(pmNode_85, none),
(pmNode_320, none),
(pmNode_321, none),
(pmNode_86, none),
(pmNode_87, none),
(pmNode_88, none),
(pmNode_322, none),
(pmNode_323, none),
(pmNode_324, none),
(pmNode_89, none),
(pmNode_90, none),
(pmNode_91, none),
(pmNode_325, none),
(pmNode_326, none),
(pmNode_327, none),
(pmNode_92, none),
(pmNode_93, none),
(pmNode_328, none),
(pmNode_329, none),
(pmNode_94, none),
(pmNode_95, none),
(pmNode_330, none),
(pmNode_331, none),
(pmNode_96, none),
(pmNode_97, none),
(pmNode_98, none),
(pmNode_99, none),
(pmNode_100, none),
(pmNode_101, none),
(pmNode_332, none),
(pmNode_333, none),
(pmNode_334, none),
(pmNode_335, none),
(pmNode_336, none),
(pmNode_337, none),
(pmNode_102, none),
(pmNode_103, none),
(pmNode_338, none),
(pmNode_339, none),
(pmNode_104, none),
(pmNode_105, none),
(pmNode_340, none),
(pmNode_341, none),
(pmNode_106, none),
(pmNode_107, none),
(pmNode_342, none),
(pmNode_343, none),
(pmNode_108, none),
(pmNode_109, none),
(pmNode_344, none),
(pmNode_345, none),
(pmNode_110, none),
(pmNode_111, none),
(pmNode_112, none),
(pmNode_346, none),
(pmNode_347, none),
(pmNode_348, none),
(pmNode_113, none),
(pmNode_114, none),
(pmNode_115, none),
(pmNode_349, none),
(pmNode_350, none),
(pmNode_351, none),
(pmNode_116, none),
(pmNode_117, none),
(pmNode_352, none),
(pmNode_353, none),
(pmNode_118, none),
(pmNode_119, none),
(pmNode_354, none),
(pmNode_355, none),
(pmNode_120, none),
(pmNode_121, none),
(pmNode_122, none),
(pmNode_356, none),
(pmNode_357, none),
(pmNode_358, none),
(pmNode_123, none),
(pmNode_124, none),
(pmNode_125, none),
(pmNode_359, none),
(pmNode_360, none),
(pmNode_361, none),
(pmNode_126, none),
(pmNode_127, none),
(pmNode_362, none),
(pmNode_363, none),
(pmNode_128, none),
(pmNode_129, none),
(pmNode_364, none),
(pmNode_365, none),
(pmNode_130, none),
(pmNode_131, none),
(pmNode_366, none),
(pmNode_367, none),
(pmNode_132, none),
(pmNode_133, none),
(pmNode_368, none),
(pmNode_369, none),
(pmNode_134, none),
(pmNode_135, none),
(pmNode_370, none),
(pmNode_371, none),
(pmNode_136, none),
(pmNode_137, none),
(pmNode_372, none),
(pmNode_373, none),
(pmNode_138, none),
(pmNode_139, none),
(pmNode_140, none),
(pmNode_374, none),
(pmNode_375, none),
(pmNode_376, none),
(pmNode_141, none),
(pmNode_142, none),
(pmNode_377, none),
(pmNode_378, none),
(pmNode_143, none),
(pmNode_144, none),
(pmNode_379, none),
(pmNode_380, none),
(pmNode_145, none),
(pmNode_146, none),
(pmNode_381, none),
(pmNode_382, none),
(pmNode_147, none),
(pmNode_148, none),
(pmNode_383, none),
(pmNode_384, none),
(pmNode_149, none),
(pmNode_150, none),
(pmNode_385, none),
(pmNode_386, none),
(pmNode_151, none),
(pmNode_152, none),
(pmNode_387, none),
(pmNode_388, none),
(pmNode_153, none),
(pmNode_154, none),
(pmNode_389, none),
(pmNode_390, none),
(pmNode_155, none),
(pmNode_156, none),
(pmNode_391, none),
(pmNode_392, none),
(pmNode_157, none),
(pmNode_158, none),
(pmNode_159, none),
(pmNode_393, none),
(pmNode_394, none),
(pmNode_395, none),
(pmNode_160, none),
(pmNode_161, none),
(pmNode_162, none),
(pmNode_396, none),
(pmNode_397, none),
(pmNode_398, none),
(pmNode_163, none),
(pmNode_164, none),
(pmNode_165, none),
(pmNode_166, none),
(pmNode_167, none),
(pmNode_399, none),
(pmNode_400, none),
(pmNode_401, none),
(pmNode_402, none),
(pmNode_403, none),
(pmNode_168, none),
(pmNode_169, none),
(pmNode_170, none),
(pmNode_404, none),
(pmNode_405, none),
(pmNode_406, none),
(pmNode_171, none),
(pmNode_172, none),
(pmNode_407, none),
(pmNode_408, none),
(pmNode_173, none),
(pmNode_174, none),
(pmNode_409, none),
(pmNode_410, none),
(pmNode_175, none),
(pmNode_176, none),
(pmNode_177, none),
(pmNode_178, none),
(pmNode_411, none),
(pmNode_412, none),
(pmNode_413, none),
(pmNode_414, none),
(pmNode_179, none),
(pmNode_180, none),
(pmNode_181, none),
(pmNode_415, none),
(pmNode_416, none),
(pmNode_417, none),
(pmNode_182, none),
(pmNode_183, none),
(pmNode_418, none),
(pmNode_419, none),
(pmNode_184, none),
(pmNode_185, none),
(pmNode_420, none),
(pmNode_421, none),
(pmNode_186, none),
(pmNode_187, none),
(pmNode_188, none),
(pmNode_189, none),
(pmNode_190, none),
(pmNode_422, none),
(pmNode_423, none),
(pmNode_424, none),
(pmNode_425, none),
(pmNode_426, none),
(pmNode_191, none),
(pmNode_192, none),
(pmNode_427, none),
(pmNode_428, none),
(pmNode_193, none),
(pmNode_194, none),
(pmNode_195, none),
(pmNode_429, none),
(pmNode_430, none),
(pmNode_431, none),
(pmNode_196, none),
(pmNode_197, none),
(pmNode_198, none),
(pmNode_432, none),
(pmNode_433, none),
(pmNode_434, none),
(pmNode_199, none),
(pmNode_200, none),
(pmNode_435, none),
(pmNode_436, none),
(pmNode_201, none),
(pmNode_202, none),
(pmNode_203, none),
(pmNode_204, none),
(pmNode_437, none),
(pmNode_438, none),
(pmNode_439, none),
(pmNode_440, none),
(pmNode_205, none),
(pmNode_206, none),
(pmNode_207, none),
(pmNode_441, none),
(pmNode_442, none),
(pmNode_443, none),
(pmNode_208, none),
(pmNode_209, none),
(pmNode_210, none),
(pmNode_444, none),
(pmNode_445, none),
(pmNode_446, none),
(pmNode_472, some pmNode_472_feed),
(pmNode_473, none),
(pmNode_474, none),
(pmNode_475, none),
(pmNode_708, some pmNode_708_feed),
(pmNode_709, none),
(pmNode_710, none),
(pmNode_711, none),
(pmNode_476, none),
(pmNode_477, none),
(pmNode_478, none),
(pmNode_712, none),
(pmNode_713, none),
(pmNode_714, none),
(pmNode_479, none),
(pmNode_480, none),
(pmNode_481, none),
(pmNode_482, none),
(pmNode_715, none),
(pmNode_716, none),
(pmNode_717, none),
(pmNode_483, none),
(pmNode_484, none),
(pmNode_485, none),
(pmNode_486, none),
(pmNode_487, none),
(pmNode_718, none),
(pmNode_719, none),
(pmNode_720, none),
(pmNode_721, none),
(pmNode_722, none),
(pmNode_723, none),
(pmNode_488, none),
(pmNode_489, none),
(pmNode_490, none),
(pmNode_724, none),
(pmNode_725, none),
(pmNode_726, none),
(pmNode_491, none),
(pmNode_492, none),
(pmNode_493, none),
(pmNode_494, none),
(pmNode_495, none),
(pmNode_496, none),
(pmNode_497, none),
(pmNode_727, none),
(pmNode_728, none),
(pmNode_729, none),
(pmNode_730, none),
(pmNode_731, none),
(pmNode_732, none),
(pmNode_498, none),
(pmNode_499, none),
(pmNode_733, none),
(pmNode_734, none),
(pmNode_735, none),
(pmNode_500, none),
(pmNode_501, none),
(pmNode_736, none),
(pmNode_737, none),
(pmNode_502, none),
(pmNode_503, none),
(pmNode_504, none),
(pmNode_738, none),
(pmNode_739, none),
(pmNode_505, none),
(pmNode_506, none),
(pmNode_507, none),
(pmNode_508, none),
(pmNode_740, none),
(pmNode_741, none),
(pmNode_742, none),
(pmNode_743, none),
(pmNode_744, none),
(pmNode_509, none),
(pmNode_510, none),
(pmNode_745, none),
(pmNode_746, none),
(pmNode_511, none),
(pmNode_512, none),
(pmNode_747, none),
(pmNode_748, none),
(pmNode_513, none),
(pmNode_514, none),
(pmNode_515, none),
(pmNode_749, none),
(pmNode_750, none),
(pmNode_751, none),
(pmNode_516, none),
(pmNode_517, none),
(pmNode_518, none),
(pmNode_519, none),
(pmNode_520, none),
(pmNode_752, none),
(pmNode_753, none),
(pmNode_754, none),
(pmNode_755, none),
(pmNode_756, none),
(pmNode_521, none),
(pmNode_522, none),
(pmNode_523, none),
(pmNode_757, none),
(pmNode_758, none),
(pmNode_759, none),
(pmNode_524, none),
(pmNode_525, none),
(pmNode_526, none),
(pmNode_760, none),
(pmNode_761, none),
(pmNode_762, none),
(pmNode_527, none),
(pmNode_528, none),
(pmNode_529, none),
(pmNode_530, none),
(pmNode_531, none),
(pmNode_532, none),
(pmNode_763, none),
(pmNode_764, none),
(pmNode_533, none),
(pmNode_534, none),
(pmNode_765, none),
(pmNode_766, none),
(pmNode_767, none),
(pmNode_768, none),
(pmNode_769, none),
(pmNode_770, none),
(pmNode_535, none),
(pmNode_536, none),
(pmNode_537, none),
(pmNode_538, none),
(pmNode_771, none),
(pmNode_772, none),
(pmNode_773, none),
(pmNode_774, none),
(pmNode_539, none),
(pmNode_540, none),
(pmNode_541, none),
(pmNode_542, none),
(pmNode_775, none),
(pmNode_776, none),
(pmNode_777, none),
(pmNode_778, none),
(pmNode_543, none),
(pmNode_544, none),
(pmNode_545, none),
(pmNode_779, none),
(pmNode_780, none),
(pmNode_781, none),
(pmNode_546, none),
(pmNode_547, none),
(pmNode_782, none),
(pmNode_783, none),
(pmNode_548, none),
(pmNode_549, none),
(pmNode_784, none),
(pmNode_785, none),
(pmNode_550, none),
(pmNode_551, none),
(pmNode_552, none),
(pmNode_553, none),
(pmNode_786, none),
(pmNode_787, none),
(pmNode_788, none),
(pmNode_789, none),
(pmNode_554, none),
(pmNode_555, none),
(pmNode_790, none),
(pmNode_791, none),
(pmNode_556, none),
(pmNode_557, none),
(pmNode_792, none),
(pmNode_793, none),
(pmNode_558, none),
(pmNode_559, none),
(pmNode_560, none),
(pmNode_794, none),
(pmNode_795, none),
(pmNode_796, none),
(pmNode_561, none),
(pmNode_562, none),
(pmNode_563, none),
(pmNode_797, none),
(pmNode_798, none),
(pmNode_799, none),
(pmNode_564, none),
(pmNode_565, none),
(pmNode_800, none),
(pmNode_801, none),
(pmNode_566, none),
(pmNode_567, none),
(pmNode_802, none),
(pmNode_803, none),
(pmNode_568, none),
(pmNode_569, none),
(pmNode_570, none),
(pmNode_571, none),
(pmNode_572, none),
(pmNode_573, none),
(pmNode_804, none),
(pmNode_805, none),
(pmNode_806, none),
(pmNode_807, none),
(pmNode_808, none),
(pmNode_809, none),
(pmNode_574, none),
(pmNode_575, none),
(pmNode_810, none),
(pmNode_811, none),
(pmNode_576, none),
(pmNode_577, none),
(pmNode_812, none),
(pmNode_813, none),
(pmNode_578, none),
(pmNode_579, none),
(pmNode_814, none),
(pmNode_815, none),
(pmNode_580, none),
(pmNode_581, none),
(pmNode_816, none),
(pmNode_817, none),
(pmNode_582, none),
(pmNode_583, none),
(pmNode_584, none),
(pmNode_818, none),
(pmNode_819, none),
(pmNode_820, none),
(pmNode_585, none),
(pmNode_586, none),
(pmNode_587, none),
(pmNode_821, none),
(pmNode_822, none),
(pmNode_823, none),
(pmNode_588, none),
(pmNode_589, none),
(pmNode_824, none),
(pmNode_825, none),
(pmNode_590, none),
(pmNode_591, none),
(pmNode_826, none),
(pmNode_827, none),
(pmNode_592, none),
(pmNode_593, none),
(pmNode_594, none),
(pmNode_828, none),
(pmNode_829, none),
(pmNode_830, none),
(pmNode_595, none),
(pmNode_596, none),
(pmNode_597, none),
(pmNode_831, none),
(pmNode_832, none),
(pmNode_833, none),
(pmNode_598, none),
(pmNode_599, none),
(pmNode_834, none),
(pmNode_835, none),
(pmNode_600, none),
(pmNode_601, none),
(pmNode_836, none),
(pmNode_837, none),
(pmNode_602, none),
(pmNode_603, none),
(pmNode_838, none),
(pmNode_839, none),
(pmNode_604, none),
(pmNode_605, none),
(pmNode_840, none),
(pmNode_841, none),
(pmNode_606, none),
(pmNode_607, none),
(pmNode_842, none),
(pmNode_843, none),
(pmNode_608, none),
(pmNode_609, none),
(pmNode_844, none),
(pmNode_845, none),
(pmNode_610, none),
(pmNode_611, none),
(pmNode_612, none),
(pmNode_846, none),
(pmNode_847, none),
(pmNode_848, none),
(pmNode_613, none),
(pmNode_614, none),
(pmNode_849, none),
(pmNode_850, none),
(pmNode_615, none),
(pmNode_616, none),
(pmNode_851, none),
(pmNode_852, none),
(pmNode_617, none),
(pmNode_618, none),
(pmNode_853, none),
(pmNode_854, none),
(pmNode_619, none),
(pmNode_620, none),
(pmNode_855, none),
(pmNode_856, none),
(pmNode_621, none),
(pmNode_622, none),
(pmNode_857, none),
(pmNode_858, none),
(pmNode_623, none),
(pmNode_624, none),
(pmNode_859, none),
(pmNode_860, none),
(pmNode_625, none),
(pmNode_626, none),
(pmNode_861, none),
(pmNode_862, none),
(pmNode_627, none),
(pmNode_628, none),
(pmNode_863, none),
(pmNode_864, none),
(pmNode_629, none),
(pmNode_630, none),
(pmNode_631, none),
(pmNode_865, none),
(pmNode_866, none),
(pmNode_867, none),
(pmNode_632, none),
(pmNode_633, none),
(pmNode_634, none),
(pmNode_868, none),
(pmNode_869, none),
(pmNode_870, none),
(pmNode_635, none),
(pmNode_636, none),
(pmNode_637, none),
(pmNode_638, none),
(pmNode_639, none),
(pmNode_871, none),
(pmNode_872, none),
(pmNode_873, none),
(pmNode_874, none),
(pmNode_875, none),
(pmNode_640, none),
(pmNode_641, none),
(pmNode_642, none),
(pmNode_876, none),
(pmNode_877, none),
(pmNode_878, none),
(pmNode_643, none),
(pmNode_644, none),
(pmNode_879, none),
(pmNode_880, none),
(pmNode_645, none),
(pmNode_646, none),
(pmNode_881, none),
(pmNode_882, none),
(pmNode_647, none),
(pmNode_648, none),
(pmNode_649, none),
(pmNode_650, none),
(pmNode_883, none),
(pmNode_884, none),
(pmNode_885, none),
(pmNode_886, none),
(pmNode_651, none),
(pmNode_652, none),
(pmNode_653, none),
(pmNode_887, none),
(pmNode_888, none),
(pmNode_889, none),
(pmNode_654, none),
(pmNode_655, none),
(pmNode_890, none),
(pmNode_891, none),
(pmNode_656, none),
(pmNode_657, none),
(pmNode_892, none),
(pmNode_893, none),
(pmNode_658, none),
(pmNode_659, none),
(pmNode_660, none),
(pmNode_661, none),
(pmNode_662, none),
(pmNode_894, none),
(pmNode_895, none),
(pmNode_896, none),
(pmNode_897, none),
(pmNode_898, none),
(pmNode_663, none),
(pmNode_664, none),
(pmNode_899, none),
(pmNode_900, none),
(pmNode_665, none),
(pmNode_666, none),
(pmNode_667, none),
(pmNode_901, none),
(pmNode_902, none),
(pmNode_903, none),
(pmNode_668, none),
(pmNode_669, none),
(pmNode_670, none),
(pmNode_904, none),
(pmNode_905, none),
(pmNode_906, none),
(pmNode_671, none),
(pmNode_672, none),
(pmNode_907, none),
(pmNode_908, none),
(pmNode_673, none),
(pmNode_674, none),
(pmNode_675, none),
(pmNode_676, none),
(pmNode_909, none),
(pmNode_910, none),
(pmNode_911, none),
(pmNode_912, none),
(pmNode_677, none),
(pmNode_678, none),
(pmNode_679, none),
(pmNode_913, none),
(pmNode_914, none),
(pmNode_915, none),
(pmNode_680, none),
(pmNode_681, none),
(pmNode_682, none),
(pmNode_916, none),
(pmNode_917, none),
(pmNode_211, none),
(pmNode_212, none),
(pmNode_213, none),
(pmNode_214, none),
(pmNode_215, none),
(pmNode_216, none),
(pmNode_217, none),
(pmNode_218, none),
(pmNode_219, none),
(pmNode_220, none),
(pmNode_221, none),
(pmNode_222, none),
(pmNode_223, none),
(pmNode_224, none),
(pmNode_225, none),
(pmNode_226, none),
(pmNode_227, none),
(pmNode_228, none),
(pmNode_229, none),
(pmNode_230, none),
(pmNode_231, none),
(pmNode_232, none),
(pmNode_233, none),
(pmNode_234, none),
(pmNode_235, none),
(pmNode_447, none),
(pmNode_448, none),
(pmNode_449, none),
(pmNode_450, none),
(pmNode_451, none),
(pmNode_452, none),
(pmNode_453, none),
(pmNode_454, none),
(pmNode_455, none),
(pmNode_456, none),
(pmNode_457, none),
(pmNode_458, none),
(pmNode_459, none),
(pmNode_460, none),
(pmNode_461, none),
(pmNode_462, none),
(pmNode_683, none),
(pmNode_684, none),
(pmNode_685, none),
(pmNode_686, none),
(pmNode_687, none),
(pmNode_688, none),
(pmNode_689, none),
(pmNode_690, none),
(pmNode_691, none),
(pmNode_692, none),
(pmNode_693, none),
(pmNode_694, none),
(pmNode_695, none),
(pmNode_696, none),
(pmNode_697, none),
(pmNode_698, none),
(pmNode_699, none),
(pmNode_700, none),
(pmNode_701, none),
(pmNode_702, none),
(pmNode_703, none),
(pmNode_704, none),
(pmNode_705, none),
(pmNode_706, none),
(pmNode_707, none),
(pmNode_918, none),
(pmNode_463, none),
(pmNode_464, none),
(pmNode_465, none),
(pmNode_466, none),
(pmNode_467, none),
(pmNode_468, none),
(pmNode_469, none),
(pmNode_470, none),
(pmNode_471, none),
(pmNode_919, none),
(pmNode_920, none),
(pmNode_921, none),
(pmNode_922, none),
(pmNode_923, none),
(pmNode_924, none),
(pmNode_925, none),
(pmNode_926, none),
(pmNode_927, none),
(pmNode_928, none),
(pmNode_929, none),
(pmNode_930, none),
(pmNode_931, none),
(pmNode_932, none),
(pmNode_933, none),
(pmNode_934, none),
(pmNode_935, none),
(pmNode_936, none),
(pmNode_937, none),
(pmNode_938, none),
(pmNode_939, none),
(pmNode_940, none),
(pmNode_941, none),
(pmNode_942, none),
(pmNode_943, none)
]
def pmDenoteWithInputs (s : Store) : Option Store := SourceScopedEval.denoteWithInputs pmGraph pmScope pmPeers (some pmInputRequests) s
theorem pmInputSchedule_valid : SourceScopedEval.InputSchedule pmGraph.nodes pmInputRequests := by
  constructor
  · rfl
  · apply (List.perm_insertionSort (fun a b : Nat => a ≤ b) _).nodup_iff.mp
    apply List.Pairwise.nodup (r := fun a b : Nat => a < b)
    apply List.isChain_iff_pairwise.mp
    decide +kernel
#print axioms pmInputSchedule_valid
theorem pmDenoteWithInputs_entry (s : Store) : pmDenoteWithInputs s = SourceScopedEval.runUsing (fun row s => SourceScopedEval.stepWithInputs pmGraph (pmScope row.1) (pmPeers row.1) s row.1 row.2) pmInputRequests (some s) := by
  unfold pmDenoteWithInputs SourceScopedEval.denoteWithInputs SourceScopedEval.runWithInputs
  exact if_pos pmInputSchedule_valid
#print axioms pmDenoteWithInputs_entry
end
end TrainVerify.Denote.RuntimeWorld
