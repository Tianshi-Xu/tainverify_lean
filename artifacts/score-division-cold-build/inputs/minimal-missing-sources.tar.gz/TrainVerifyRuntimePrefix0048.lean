import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0047
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_369_0 (z : Store) : (s_369 z) 137 = (v_368_0 z) := w_368_0 z
 #a r_369_0
 theorem r_369_1 (z : Store) : (s_369 z) 132 = (v_44_0 z) := pR (k_368 z) (pR (n_352_368 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_56_64 z) (pR (n_52_56 z) (r_52_0 z))))))))
 #a r_369_1
 theorem r_369_2 (z : Store) : (s_369 z) 133 = (v_51_0 z) := pR (k_368 z) (pR (n_352_368 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_56_64 z) (pR (n_52_56 z) (r_52_1 z))))))))
 #a r_369_2
 def v_369_0 (z : Store) : Tensor := (batchedMatmulBwd (v_368_0 z) (v_44_0 z) (v_51_0 z)).1
 def v_369_1 (z : Store) : Tensor := (batchedMatmulBwd (v_368_0 z) (v_44_0 z) (v_51_0 z)).2
 def s_370 (z : Store) : Store := storeSet (s_369 z) [(135, (batchedMatmulBwd ((s_369 z) 137) ((s_369 z) 132) ((s_369 z) 133)).1), (136, (batchedMatmulBwd ((s_369 z) 137) ((s_369 z) 132) ((s_369 z) 133)).2)]
 theorem t_369 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_185) (pmPeers pmNode_185) (s_369 z) pmNode_185 none = some (s_370 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_369
 theorem k_369 (z : Store) (tid : Tid) (h : tid ∉ [135, 136]) : (s_370 z) tid = (s_369 z) tid := by
   unfold s_370
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_369
 theorem w_369_0 (z : Store) : (s_370 z) 135 = v_369_0 z := by
   unfold s_370
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_369_0, r_369_0 z, r_369_1 z, r_369_2 z] <;> rfl
 #a w_369_0
 theorem h_369_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_369_0 z).shape = [1, 2, 16, 16] := by
   unfold v_369_0
   change (batchedMatmul (v_368_0 z) (transpose2d (v_51_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_368_0 z z_, h_51_0 z z_]
   rfl
 #a h_369_0
 attribute [local irreducible] v_369_0
 theorem w_369_1 (z : Store) : (s_370 z) 136 = v_369_1 z := by
   unfold s_370
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_369_1, r_369_0 z, r_369_1 z, r_369_2 z] <;> rfl
 #a w_369_1
 theorem h_369_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_369_1 z).shape = [1, 2, 16, 16] := by
   unfold v_369_1
   change (batchedMatmul (transpose2d (v_44_0 z)) (v_368_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_368_0 z z_, h_44_0 z z_]
   rfl
 #a h_369_1
 attribute [local irreducible] v_369_1
 attribute [local irreducible] s_370
 theorem r_370_0 (z : Store) : (s_370 z) 140 = (v_365_0 z) := pR (k_369 z) (pR (k_368 z) (r_368_0 z))
 #a r_370_0
 theorem r_370_1 (z : Store) : (s_370 z) 443 = (v_367_0 z) := pR (k_369 z) (pR (k_368 z) (r_368_1 z))
 #a r_370_1
 def v_370_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_365_0 z), (v_367_0 z)]
 theorem g_370 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_420) (s_370 z) pmNode_420 3 1 440 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_420, r_370_0 z, r_370_1 z, h_365_0 z z_, h_367_0 z z_]
 #a g_370
 def s_371 (z : Store) : Store := pL [0, 1] (s_370 z) pmNode_420 3 1
 theorem t_370 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_420) (pmPeers pmNode_420) (s_370 z) pmNode_420 none = some (s_371 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_420) (s_370 z) pmNode_420).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 440 (by decide) (g_370 z z_)]
   rfl
 #a t_370
 theorem k_370 (z : Store) (tid : Tid) (h : tid ∉ [440]) : (s_371 z) tid = (s_370 z) tid := by
   unfold s_371
   dsimp only [pL, pmNode_420, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_370
 theorem w_370_0 (z : Store) : (s_371 z) 440 = v_370_0 z := by
   unfold s_371
   dsimp only [pL, pmNode_420, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_370_0, r_370_0 z, r_370_1 z] <;> rfl
 #a w_370_0
 theorem h_370_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_370_0 z).shape = [1, 2, 16, 16] := by
   unfold v_370_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_365_0 z z_]
 #a h_370_0
 attribute [local irreducible] v_370_0
 attribute [local irreducible] s_371
 theorem r_371_0 (z : Store) : (s_371 z) 440 = (v_370_0 z) := w_370_0 z
 #a r_371_0
 theorem r_371_1 (z : Store) : (s_371 z) 435 = (v_53_0 z) := pR (k_370 z) (pR (k_369 z) (pR (k_368 z) (pR (n_352_368 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_56_64 z) (pR (k_55 z) (r_55_0 z))))))))))
 #a r_371_1
 theorem r_371_2 (z : Store) : (s_371 z) 436 = (v_54_0 z) := pR (k_370 z) (pR (k_369 z) (pR (k_368 z) (pR (n_352_368 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_56_64 z) (pR (k_55 z) (r_55_1 z))))))))))
 #a r_371_2
 def v_371_0 (z : Store) : Tensor := (batchedMatmulBwd (v_370_0 z) (v_53_0 z) (v_54_0 z)).1
 def v_371_1 (z : Store) : Tensor := (batchedMatmulBwd (v_370_0 z) (v_53_0 z) (v_54_0 z)).2
 def s_372 (z : Store) : Store := storeSet (s_371 z) [(438, (batchedMatmulBwd ((s_371 z) 440) ((s_371 z) 435) ((s_371 z) 436)).1), (439, (batchedMatmulBwd ((s_371 z) 440) ((s_371 z) 435) ((s_371 z) 436)).2)]
 theorem t_371 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_421) (pmPeers pmNode_421) (s_371 z) pmNode_421 none = some (s_372 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_371
 theorem k_371 (z : Store) (tid : Tid) (h : tid ∉ [438, 439]) : (s_372 z) tid = (s_371 z) tid := by
   unfold s_372
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_371
 theorem w_371_0 (z : Store) : (s_372 z) 438 = v_371_0 z := by
   unfold s_372
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_371_0, r_371_0 z, r_371_1 z, r_371_2 z] <;> rfl
 #a w_371_0
 theorem h_371_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_371_0 z).shape = [1, 2, 16, 16] := by
   unfold v_371_0
   change (batchedMatmul (v_370_0 z) (transpose2d (v_54_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_370_0 z z_, h_54_0 z z_]
   rfl
 #a h_371_0
 attribute [local irreducible] v_371_0
 theorem w_371_1 (z : Store) : (s_372 z) 439 = v_371_1 z := by
   unfold s_372
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_371_1, r_371_0 z, r_371_1 z, r_371_2 z] <;> rfl
 #a w_371_1
 theorem h_371_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_371_1 z).shape = [1, 2, 16, 16] := by
   unfold v_371_1
   change (batchedMatmul (transpose2d (v_53_0 z)) (v_370_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_370_0 z z_, h_53_0 z z_]
   rfl
 #a h_371_1
 attribute [local irreducible] v_371_1
 attribute [local irreducible] s_372
 theorem r_372_0 (z : Store) : (s_372 z) 136 = (v_369_1 z) := pR (k_371 z) (pR (k_370 z) (w_369_1 z))
 #a r_372_0
 theorem r_372_1 (z : Store) : (s_372 z) 439 = (v_371_1 z) := w_371_1 z
 #a r_372_1
 def v_372_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_369_1 z), (v_371_1 z)]
 theorem g_372 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_186) (s_372 z) pmNode_186 1 2 131 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_186, r_372_0 z, r_372_1 z, h_369_1 z z_, h_371_1 z z_]
 #a g_372
 def s_373 (z : Store) : Store := pL [0, 1] (s_372 z) pmNode_186 1 2
 theorem t_372 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_186) (pmPeers pmNode_186) (s_372 z) pmNode_186 none = some (s_373 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_186) (s_372 z) pmNode_186).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 131 (by decide) (g_372 z z_)]
   rfl
 #a t_372
 theorem k_372 (z : Store) (tid : Tid) (h : tid ∉ [131]) : (s_373 z) tid = (s_372 z) tid := by
   unfold s_373
   dsimp only [pL, pmNode_186, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_372
 theorem w_372_0 (z : Store) : (s_373 z) 131 = v_372_0 z := by
   unfold s_373
   dsimp only [pL, pmNode_186, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_372_0, r_372_0 z, r_372_1 z] <;> rfl
 #a w_372_0
 theorem h_372_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_372_0 z).shape = [1, 4, 8, 16] := by
   unfold v_372_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_369_1 z z_]
 #a h_372_0
 attribute [local irreducible] v_372_0
 attribute [local irreducible] s_373
 theorem r_373_0 (z : Store) : (s_373 z) 135 = (v_369_0 z) := pR (k_372 z) (pR (k_371 z) (pR (k_370 z) (w_369_0 z)))
 #a r_373_0
 theorem r_373_1 (z : Store) : (s_373 z) 438 = (v_371_0 z) := pR (k_372 z) (w_371_0 z)
 #a r_373_1
 def v_373_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_369_0 z), (v_371_0 z)]
 theorem g_373 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_187) (s_373 z) pmNode_187 1 3 117 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_187, r_373_0 z, r_373_1 z, h_369_0 z z_, h_371_0 z z_]
 #a g_373
 def s_374 (z : Store) : Store := pL [0, 1] (s_373 z) pmNode_187 1 3
 theorem t_373 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_187) (pmPeers pmNode_187) (s_373 z) pmNode_187 none = some (s_374 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_187) (s_373 z) pmNode_187).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 117 (by decide) (g_373 z z_)]
   rfl
 #a t_373
 theorem k_373 (z : Store) (tid : Tid) (h : tid ∉ [117]) : (s_374 z) tid = (s_373 z) tid := by
   unfold s_374
   dsimp only [pL, pmNode_187, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_373
 theorem w_373_0 (z : Store) : (s_374 z) 117 = v_373_0 z := by
   unfold s_374
   dsimp only [pL, pmNode_187, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_373_0, r_373_0 z, r_373_1 z] <;> rfl
 #a w_373_0
 theorem h_373_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_373_0 z).shape = [1, 4, 16, 8] := by
   unfold v_373_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_369_0 z z_]
 #a h_373_0
 attribute [local irreducible] v_373_0
 attribute [local irreducible] s_374
 theorem n_368_372 (z : Store) (tid : Tid) (h : tid ∉ ([137, 135, 136, 440, 438, 439] : List Tid)) : (s_372 z) tid = (s_368 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_368 z) (k_369 z)) (pF _ _ _ _ _ (k_370 z) (k_371 z)) tid h
 #a n_368_372
 theorem r_374_0 (z : Store) : (s_374 z) 131 = (v_372_0 z) := pR (k_373 z) (w_372_0 z)
 #a r_374_0
 theorem r_374_1 (z : Store) : (s_374 z) 121 = (v_39_0 z) := pR (k_373 z) (pR (k_372 z) (pR (n_368_372 z) (pR (n_352_368 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_48_64 z) (pR (n_44_48 z) (pR (k_43 z) (r_43_0 z)))))))))))
 #a r_374_1
 def v_374_0 (z : Store) : Tensor := transposeAxes 2 3 (v_372_0 z)
 def s_375 (z : Store) : Store := storeSet (s_374 z) [(123, transposeAxes 2 3 ((s_374 z) 131))]
 theorem t_374 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_188) (pmPeers pmNode_188) (s_374 z) pmNode_188 none = some (s_375 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_374
 theorem k_374 (z : Store) (tid : Tid) (h : tid ∉ [123]) : (s_375 z) tid = (s_374 z) tid := by
   unfold s_375
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_374
 theorem w_374_0 (z : Store) : (s_375 z) 123 = v_374_0 z := by
   unfold s_375
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_374_0, r_374_0 z, r_374_1 z] <;> rfl
 #a w_374_0
 theorem h_374_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_374_0 z).shape = [1, 4, 16, 8] := by
   unfold v_374_0
   change listSwapAt _ _ _ = _
   rw [h_372_0 z z_]
   rfl
 #a h_374_0
 attribute [local irreducible] v_374_0
 attribute [local irreducible] s_375
 theorem r_375_0 (z : Store) : (s_375 z) 129 = (v_359_0 z) := pR (k_374 z) (pR (k_373 z) (pR (k_372 z) (pR (n_368_372 z) (pR (n_360_368 z) (w_359_0 z)))))
 #a r_375_0
 theorem r_375_1 (z : Store) : (s_375 z) 125 = (v_41_0 z) := pR (k_374 z) (pR (k_373 z) (pR (k_372 z) (pR (n_368_372 z) (pR (n_352_368 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_48_64 z) (pR (n_44_48 z) (pR (k_43 z) (pR (k_42 z) (r_42_0 z)))))))))))))
 #a r_375_1
 def v_375_0 (z : Store) : Tensor := transposeAxes 1 2 (v_359_0 z)
 def s_376 (z : Store) : Store := storeSet (s_375 z) [(127, transposeAxes 1 2 ((s_375 z) 129))]
 theorem t_375 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_189) (pmPeers pmNode_189) (s_375 z) pmNode_189 none = some (s_376 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_375
 theorem k_375 (z : Store) (tid : Tid) (h : tid ∉ [127]) : (s_376 z) tid = (s_375 z) tid := by
   unfold s_376
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_375
 theorem w_375_0 (z : Store) : (s_376 z) 127 = v_375_0 z := by
   unfold s_376
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_375_0, r_375_0 z, r_375_1 z] <;> rfl
 #a w_375_0
 theorem h_375_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_375_0 z).shape = [1, 8, 4, 16] := by
   unfold v_375_0
   change listSwapAt _ _ _ = _
   rw [h_359_0 z z_]
   rfl
 #a h_375_0
 attribute [local irreducible] v_375_0
 attribute [local irreducible] s_376
 theorem n_372_376 (z : Store) (tid : Tid) (h : tid ∉ ([131, 117, 123, 127] : List Tid)) : (s_376 z) tid = (s_372 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_372 z) (k_373 z)) (pF _ _ _ _ _ (k_374 z) (k_375 z)) tid h
 #a n_372_376
 theorem n_368_376 (z : Store) (tid : Tid) (h : tid ∉ ([137, 135, 136, 440, 438, 439, 131, 117, 123, 127] : List Tid)) : (s_376 z) tid = (s_368 z) tid := by
   exact pF _ _ _ _ _ (n_368_372 z) (n_372_376 z) tid h
 #a n_368_376
 theorem r_376_0 (z : Store) : (s_376 z) 127 = (v_375_0 z) := w_375_0 z
 #a r_376_0
 theorem r_376_1 (z : Store) : (s_376 z) 124 = (v_40_0 z) := pR (n_368_376 z) (pR (n_352_368 z) (pR (n_320_352 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_48_64 z) (pR (n_44_48 z) (pR (k_43 z) (pR (k_42 z) (pR (k_41 z) (r_41_0 z)))))))))))
 #a r_376_1
 def v_376_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_375_0 z)
 def s_377 (z : Store) : Store := storeSet (s_376 z) [(126, fw_view [1, 8, 64] ((s_376 z) 127))]
 theorem t_376 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_190) (pmPeers pmNode_190) (s_376 z) pmNode_190 none = some (s_377 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_376
 theorem k_376 (z : Store) (tid : Tid) (h : tid ∉ [126]) : (s_377 z) tid = (s_376 z) tid := by
   unfold s_377
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_376
 theorem w_376_0 (z : Store) : (s_377 z) 126 = v_376_0 z := by
   unfold s_377
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_376_0, r_376_0 z, r_376_1 z] <;> rfl
 #a w_376_0
 theorem h_376_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_376_0 z).shape = [1, 8, 64] := by
   unfold v_376_0
   rfl
 #a h_376_0
 attribute [local irreducible] v_376_0
 attribute [local irreducible] s_377
 record_prefix_opacity v_369_0 v_369_1 s_370 v_370_0 s_371 v_371_0 v_371_1 s_372 v_372_0 s_373 v_373_0 s_374 v_374_0 s_375 v_375_0 s_376 v_376_0 s_377

 end
 end TrainVerify.Denote.RuntimeWorld
