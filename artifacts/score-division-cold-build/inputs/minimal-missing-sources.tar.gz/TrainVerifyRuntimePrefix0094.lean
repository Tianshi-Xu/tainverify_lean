import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0093
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_743_0 (z : Store) : (s_743 z) 898 = (v_742_0 z) := w_742_0 z
 #a r_743_0
 theorem r_743_1 (z : Store) : (s_743 z) 861 = (v_664_0 z) := pR (k_742 z) (pR (k_741 z) (pR (k_740 z) (pR (n_736_740 z) (pR (n_704_736 z) (pR (n_672_704 z) (pR (n_668_672 z) (pR (k_667 z) (pR (k_666 z) (pR (k_665 z) (w_664_0 z))))))))))
 #a r_743_1
 def v_743_0 (z : Store) : Tensor := tensorSum [(v_742_0 z), (v_664_0 z)]
 def s_744 (z : Store) : Store := storeSet (s_743 z) [(790, tensorSum [((s_743 z) 898), ((s_743 z) 861)])]
 theorem t_743 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_633) (pmPeers pmNode_633) (s_743 z) pmNode_633 none = some (s_744 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_743
 theorem k_743 (z : Store) (tid : Tid) (h : tid ∉ [790]) : (s_744 z) tid = (s_743 z) tid := by
   unfold s_744
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_743
 theorem w_743_0 (z : Store) : (s_744 z) 790 = v_743_0 z := by
   unfold s_744
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_743_0, r_743_0 z, r_743_1 z] <;> rfl
 #a w_743_0
 theorem h_743_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_743_0 z).shape = [1, 16, 32] := by
   unfold v_743_0
   rw [tensorSum_shape]
   exact h_742_0 z z_
 #a h_743_0
 attribute [local irreducible] v_743_0
 attribute [local irreducible] s_744
 theorem n_740_744 (z : Store) (tid : Tid) (h : tid ∉ ([1097, 1096, 952, 954, 898, 790] : List Tid)) : (s_744 z) tid = (s_740 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_740 z) (k_741 z)) (pF _ _ _ _ _ (k_742 z) (k_743 z)) tid h
 #a n_740_744
 theorem n_736_744 (z : Store) (tid : Tid) (h : tid ∉ ([900, 794, 793, 649, 651, 1203, 1097, 1096, 952, 954, 898, 790] : List Tid)) : (s_744 z) tid = (s_736 z) tid := by
   exact pF _ _ _ _ _ (n_736_740 z) (n_740_744 z) tid h
 #a n_736_744
 theorem r_744_0 (z : Store) : (s_744 z) 790 = (v_743_0 z) := w_743_0 z
 #a r_744_0
 theorem r_744_1 (z : Store) : (s_744 z) 785 = (v_506_1 z) := pR (n_736_744 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_524_528 z) (pR (k_523 z) (pR (k_522 z) (pR (k_521 z) (r_521_0 z))))))))))
 #a r_744_1
 theorem r_744_2 (z : Store) : (s_744 z) 786 = (v_520_0 z) := pR (n_736_744 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_524_528 z) (pR (k_523 z) (pR (k_522 z) (pR (k_521 z) (r_521_1 z))))))))))
 #a r_744_2
 def v_744_0 (z : Store) : Tensor := (bw_add2 (v_743_0 z) (v_506_1 z) (v_520_0 z)).1
 def v_744_1 (z : Store) : Tensor := (bw_add2 (v_743_0 z) (v_506_1 z) (v_520_0 z)).2
 def s_745 (z : Store) : Store := storeSet (s_744 z) [(788, (bw_add2 ((s_744 z) 790) ((s_744 z) 785) ((s_744 z) 786)).1), (789, (bw_add2 ((s_744 z) 790) ((s_744 z) 785) ((s_744 z) 786)).2)]
 theorem t_744 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_634) (pmPeers pmNode_634) (s_744 z) pmNode_634 none = some (s_745 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_744
 theorem k_744 (z : Store) (tid : Tid) (h : tid ∉ [788, 789]) : (s_745 z) tid = (s_744 z) tid := by
   unfold s_745
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_744
 theorem w_744_0 (z : Store) : (s_745 z) 788 = v_744_0 z := by
   unfold s_745
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_744_0, r_744_0 z, r_744_1 z, r_744_2 z] <;> rfl
 #a w_744_0
 theorem h_744_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_744_0 z).shape = [1, 16, 32] := by
   unfold v_744_0
   exact h_506_1 z z_
 #a h_744_0
 attribute [local irreducible] v_744_0
 theorem w_744_1 (z : Store) : (s_745 z) 789 = v_744_1 z := by
   unfold s_745
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_744_1, r_744_0 z, r_744_1 z, r_744_2 z] <;> rfl
 #a w_744_1
 theorem h_744_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_744_1 z).shape = [1, 16, 32] := by
   unfold v_744_1
   exact h_520_0 z z_
 #a h_744_1
 attribute [local irreducible] v_744_1
 attribute [local irreducible] s_745
 theorem r_745_0 (z : Store) : (s_745 z) 793 = (v_738_0 z) := pR (k_744 z) (pR (k_743 z) (pR (k_742 z) (r_742_0 z)))
 #a r_745_0
 theorem r_745_1 (z : Store) : (s_745 z) 1096 = (v_741_0 z) := pR (k_744 z) (pR (k_743 z) (pR (k_742 z) (r_742_1 z)))
 #a r_745_1
 def v_745_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_738_0 z), (v_741_0 z)]
 theorem g_745 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_868) (s_745 z) pmNode_868 1 2 1201 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_868, r_745_0 z, r_745_1 z, h_738_0 z z_, h_741_0 z z_]
 #a g_745
 def s_746 (z : Store) : Store := pL [2, 3] (s_745 z) pmNode_868 1 2
 theorem t_745 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_868) (pmPeers pmNode_868) (s_745 z) pmNode_868 none = some (s_746 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_868) (s_745 z) pmNode_868).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1201 (by decide) (g_745 z z_)]
   rfl
 #a t_745
 theorem k_745 (z : Store) (tid : Tid) (h : tid ∉ [1201]) : (s_746 z) tid = (s_745 z) tid := by
   unfold s_746
   dsimp only [pL, pmNode_868, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_745
 theorem w_745_0 (z : Store) : (s_746 z) 1201 = v_745_0 z := by
   unfold s_746
   dsimp only [pL, pmNode_868, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_745_0, r_745_0 z, r_745_1 z] <;> rfl
 #a w_745_0
 theorem h_745_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_745_0 z).shape = [1, 16, 32] := by
   unfold v_745_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_738_0 z z_]
 #a h_745_0
 attribute [local irreducible] v_745_0
 attribute [local irreducible] s_746
 theorem r_746_0 (z : Store) : (s_746 z) 1201 = (v_745_0 z) := w_745_0 z
 #a r_746_0
 theorem r_746_1 (z : Store) : (s_746 z) 1164 = (v_667_0 z) := pR (k_745 z) (pR (k_744 z) (pR (n_736_744 z) (pR (n_704_736 z) (pR (n_672_704 z) (pR (n_668_672 z) (w_667_0 z))))))
 #a r_746_1
 def v_746_0 (z : Store) : Tensor := tensorSum [(v_745_0 z), (v_667_0 z)]
 def s_747 (z : Store) : Store := storeSet (s_746 z) [(1093, tensorSum [((s_746 z) 1201), ((s_746 z) 1164)])]
 theorem t_746 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_869) (pmPeers pmNode_869) (s_746 z) pmNode_869 none = some (s_747 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_746
 theorem k_746 (z : Store) (tid : Tid) (h : tid ∉ [1093]) : (s_747 z) tid = (s_746 z) tid := by
   unfold s_747
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_746
 theorem w_746_0 (z : Store) : (s_747 z) 1093 = v_746_0 z := by
   unfold s_747
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_746_0, r_746_0 z, r_746_1 z] <;> rfl
 #a w_746_0
 theorem h_746_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_746_0 z).shape = [1, 16, 32] := by
   unfold v_746_0
   rw [tensorSum_shape]
   exact h_745_0 z z_
 #a h_746_0
 attribute [local irreducible] v_746_0
 attribute [local irreducible] s_747
 theorem r_747_0 (z : Store) : (s_747 z) 1093 = (v_746_0 z) := w_746_0 z
 #a r_747_0
 theorem r_747_1 (z : Store) : (s_747 z) 1088 = (v_509_1 z) := pR (k_746 z) (pR (k_745 z) (pR (k_744 z) (pR (n_736_744 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_524_528 z) (r_524_0 z))))))))))
 #a r_747_1
 theorem r_747_2 (z : Store) : (s_747 z) 1089 = (v_523_0 z) := pR (k_746 z) (pR (k_745 z) (pR (k_744 z) (pR (n_736_744 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_524_528 z) (r_524_1 z))))))))))
 #a r_747_2
 def v_747_0 (z : Store) : Tensor := (bw_add2 (v_746_0 z) (v_509_1 z) (v_523_0 z)).1
 def v_747_1 (z : Store) : Tensor := (bw_add2 (v_746_0 z) (v_509_1 z) (v_523_0 z)).2
 def s_748 (z : Store) : Store := storeSet (s_747 z) [(1091, (bw_add2 ((s_747 z) 1093) ((s_747 z) 1088) ((s_747 z) 1089)).1), (1092, (bw_add2 ((s_747 z) 1093) ((s_747 z) 1088) ((s_747 z) 1089)).2)]
 theorem t_747 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_870) (pmPeers pmNode_870) (s_747 z) pmNode_870 none = some (s_748 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_747
 theorem k_747 (z : Store) (tid : Tid) (h : tid ∉ [1091, 1092]) : (s_748 z) tid = (s_747 z) tid := by
   unfold s_748
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_747
 theorem w_747_0 (z : Store) : (s_748 z) 1091 = v_747_0 z := by
   unfold s_748
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_747_0, r_747_0 z, r_747_1 z, r_747_2 z] <;> rfl
 #a w_747_0
 theorem h_747_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_747_0 z).shape = [1, 16, 32] := by
   unfold v_747_0
   exact h_509_1 z z_
 #a h_747_0
 attribute [local irreducible] v_747_0
 theorem w_747_1 (z : Store) : (s_748 z) 1092 = v_747_1 z := by
   unfold s_748
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_747_1, r_747_0 z, r_747_1 z, r_747_2 z] <;> rfl
 #a w_747_1
 theorem h_747_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_747_1 z).shape = [1, 16, 32] := by
   unfold v_747_1
   exact h_523_0 z z_
 #a h_747_1
 attribute [local irreducible] v_747_1
 attribute [local irreducible] s_748
 theorem r_748_0 (z : Store) : (s_748 z) 789 = (v_744_1 z) := pR (k_747 z) (pR (k_746 z) (pR (k_745 z) (w_744_1 z)))
 #a r_748_0
 theorem r_748_1 (z : Store) : (s_748 z) 1092 = (v_747_1 z) := w_747_1 z
 #a r_748_1
 def v_748_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_744_1 z), (v_747_1 z)]
 theorem g_748 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_635) (s_748 z) pmNode_635 2 1 784 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_635, r_748_0 z, r_748_1 z, h_744_1 z z_, h_747_1 z z_]
 #a g_748
 def s_749 (z : Store) : Store := pL [2, 3] (s_748 z) pmNode_635 2 1
 theorem t_748 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_635) (pmPeers pmNode_635) (s_748 z) pmNode_635 none = some (s_749 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_635) (s_748 z) pmNode_635).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 784 (by decide) (g_748 z z_)]
   rfl
 #a t_748
 theorem k_748 (z : Store) (tid : Tid) (h : tid ∉ [784]) : (s_749 z) tid = (s_748 z) tid := by
   unfold s_749
   dsimp only [pL, pmNode_635, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_748
 theorem w_748_0 (z : Store) : (s_749 z) 784 = v_748_0 z := by
   unfold s_749
   dsimp only [pL, pmNode_635, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_748_0, r_748_0 z, r_748_1 z] <;> rfl
 #a w_748_0
 theorem h_748_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_748_0 z).shape = [1, 8, 64] := by
   unfold v_748_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_744_1 z z_]
 #a h_748_0
 attribute [local irreducible] v_748_0
 attribute [local irreducible] s_749
 theorem n_744_748 (z : Store) (tid : Tid) (h : tid ∉ ([788, 789, 1201, 1093, 1091, 1092] : List Tid)) : (s_748 z) tid = (s_744 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_744 z) (k_745 z)) (pF _ _ _ _ _ (k_746 z) (k_747 z)) tid h
 #a n_744_748
 theorem r_749_0 (z : Store) : (s_749 z) 784 = (v_748_0 z) := w_748_0 z
 #a r_749_0
 theorem r_749_1 (z : Store) : (s_749 z) 781 = (v_513_0 z) := pR (k_748 z) (pR (n_744_748 z) (pR (n_736_744 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (n_516_520 z) (pR (k_515 z) (pR (k_514 z) (r_514_0 z))))))))))))
 #a r_749_1
 theorem r_749_2 (z : Store) : (s_749 z) 614 = (z 614) := pR (k_748 z) (pR (n_744_748 z) (pR (n_736_744 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (n_516_520 z) (pR (k_515 z) (pR (k_514 z) (r_514_1 z))))))))))))
 #a r_749_2
 def v_749_0 (z : Store) : Tensor := (bw_linear (v_748_0 z) (v_513_0 z) (z 614)).1
 def v_749_1 (z : Store) : Tensor := (bw_linear (v_748_0 z) (v_513_0 z) (z 614)).2
 def s_750 (z : Store) : Store := storeSet (s_749 z) [(782, (bw_linear ((s_749 z) 784) ((s_749 z) 781) ((s_749 z) 614)).1), (647, (bw_linear ((s_749 z) 784) ((s_749 z) 781) ((s_749 z) 614)).2)]
 theorem t_749 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_636) (pmPeers pmNode_636) (s_749 z) pmNode_636 none = some (s_750 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_749
 theorem k_749 (z : Store) (tid : Tid) (h : tid ∉ [782, 647]) : (s_750 z) tid = (s_749 z) tid := by
   unfold s_750
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_749
 theorem w_749_0 (z : Store) : (s_750 z) 782 = v_749_0 z := by
   unfold s_750
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_749_0, r_749_0 z, r_749_1 z, r_749_2 z] <;> rfl
 #a w_749_0
 theorem h_749_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_749_0 z).shape = [1, 8, 256] := by
   unfold v_749_0
   exact bw_linear_3d_fst_shape 1 8 64 256 (v_748_0 z) (v_513_0 z) (z 614) (h_748_0 z z_) (h_513_0 z z_) (i_69 z z_)
 #a h_749_0
 attribute [local irreducible] v_749_0
 theorem w_749_1 (z : Store) : (s_750 z) 647 = v_749_1 z := by
   unfold s_750
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_749_1, r_749_0 z, r_749_1 z, r_749_2 z] <;> rfl
 #a w_749_1
 theorem h_749_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_749_1 z).shape = [64, 256] := by
   unfold v_749_1
   exact bw_linear_3d_snd_shape 1 8 64 256 (v_748_0 z) (v_513_0 z) (z 614) (h_748_0 z z_) (h_513_0 z z_) (i_69 z z_)
 #a h_749_1
 attribute [local irreducible] v_749_1
 attribute [local irreducible] s_750
 record_prefix_opacity v_743_0 s_744 v_744_0 v_744_1 s_745 v_745_0 s_746 v_746_0 s_747 v_747_0 v_747_1 s_748 v_748_0 s_749 v_749_0 v_749_1 s_750

 end
 end TrainVerify.Denote.RuntimeWorld
