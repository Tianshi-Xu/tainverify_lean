import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0086
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_688_0 (z : Store) : (s_688 z) 844 = (v_683_1 z) := pR (k_687 z) (pR (k_686 z) (r_686_0 z))
 #a r_688_0
 theorem r_688_1 (z : Store) : (s_688 z) 1146 = (v_685_1 z) := pR (k_687 z) (pR (k_686 z) (r_686_1 z))
 #a r_688_1
 def v_688_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 1 [(v_683_1 z), (v_685_1 z)]
 def s_689 (z : Store) : Store := storeSet (s_688 z) [(1130, reduceScatterPrimDimN 2 2 1 [((s_688 z) 844), ((s_688 z) 1146)])]
 theorem t_688 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_840) (pmPeers pmNode_840) (s_688 z) pmNode_840 none = some (s_689 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_688 z) pmNode_840 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_688
 theorem k_688 (z : Store) (tid : Tid) (h : tid ∉ [1130]) : (s_689 z) tid = (s_688 z) tid := by
   unfold s_689
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_688
 theorem w_688_0 (z : Store) : (s_689 z) 1130 = v_688_0 z := by
   unfold s_689
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_688_0, r_688_0 z, r_688_1 z] <;> rfl
 #a w_688_0
 theorem h_688_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_688_0 z).shape = [1, 4, 8, 16] := by
   unfold v_688_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 1 _ [1, 4, 16, 16]
   · rw [allReducePrim_shape _ _ _ (v_683_1 z) rfl]
     exact h_683_1 z z_
   · decide
 #a h_688_0
 attribute [local irreducible] v_688_0
 attribute [local irreducible] s_689
 theorem n_684_688 (z : Store) (tid : Tid) (h : tid ∉ ([1147, 1144, 1146, 827, 840] : List Tid)) : (s_688 z) tid = (s_684 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_684 z) (k_685 z)) (pF _ _ _ _ _ (k_686 z) (k_687 z)) tid h
 #a n_684_688
 theorem n_680_688 (z : Store) (tid : Tid) (h : tid ∉ ([1151, 1150, 843, 841, 844, 1147, 1144, 1146, 827, 840] : List Tid)) : (s_688 z) tid = (s_680 z) tid := by
   exact pF _ _ _ _ _ (n_680_684 z) (n_684_688 z) tid h
 #a n_680_688
 theorem n_672_688 (z : Store) (tid : Tid) (h : tid ∉ ([1159, 966, 1158, 852, 851, 1155, 1154, 848, 847, 1151, 1150, 843, 841, 844, 1147, 1144, 1146, 827, 840] : List Tid)) : (s_688 z) tid = (s_672 z) tid := by
   exact pF _ _ _ _ _ (n_672_680 z) (n_680_688 z) tid h
 #a n_672_688
 theorem r_689_0 (z : Store) : (s_689 z) 1144 = (v_685_0 z) := pR (k_688 z) (pR (k_687 z) (pR (k_686 z) (w_685_0 z)))
 #a r_689_0
 theorem r_689_1 (z : Store) : (s_689 z) 1141 = (v_582_0 z) := pR (k_688 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_592_608 z) (pR (n_584_592 z) (pR (k_583 z) (r_583_0 z)))))))
 #a r_689_1
 def v_689_0 (z : Store) : Tensor := bw_softmax (v_685_0 z) (v_582_0 z)
 def s_690 (z : Store) : Store := storeSet (s_689 z) [(1143, bw_softmax ((s_689 z) 1144) ((s_689 z) 1141))]
 theorem t_689 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_841) (pmPeers pmNode_841) (s_689 z) pmNode_841 none = some (s_690 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_689
 theorem k_689 (z : Store) (tid : Tid) (h : tid ∉ [1143]) : (s_690 z) tid = (s_689 z) tid := by
   unfold s_690
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_689
 theorem w_689_0 (z : Store) : (s_690 z) 1143 = v_689_0 z := by
   unfold s_690
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_689_0, r_689_0 z, r_689_1 z] <;> rfl
 #a w_689_0
 theorem h_689_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_689_0 z).shape = [1, 4, 8, 16] := by
   unfold v_689_0
   unfold bw_softmax softmaxBwd softmaxBwdFromOutput softmax
   rw [h_582_0 z z_]
   rfl
 #a h_689_0
 attribute [local irreducible] v_689_0
 attribute [local irreducible] s_690
 theorem r_690_0 (z : Store) : (s_690 z) 840 = (v_687_0 z) := pR (k_689 z) (pR (k_688 z) (w_687_0 z))
 #a r_690_0
 theorem r_690_1 (z : Store) : (s_690 z) 1143 = (v_689_0 z) := w_689_0 z
 #a r_690_1
 def v_690_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 3 [(v_687_0 z), (v_689_0 z)]
 theorem g_690 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_606) (s_690 z) pmNode_606 2 3 837 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_606, r_690_0 z, r_690_1 z, h_687_0 z z_, h_689_0 z z_]
 #a g_690
 def s_691 (z : Store) : Store := pL [2, 3] (s_690 z) pmNode_606 2 3
 theorem t_690 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_606) (pmPeers pmNode_606) (s_690 z) pmNode_606 none = some (s_691 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_606) (s_690 z) pmNode_606).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 3 837 (by decide) (g_690 z z_)]
   rfl
 #a t_690
 theorem k_690 (z : Store) (tid : Tid) (h : tid ∉ [837]) : (s_691 z) tid = (s_690 z) tid := by
   unfold s_691
   dsimp only [pL, pmNode_606, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_690
 theorem w_690_0 (z : Store) : (s_691 z) 837 = v_690_0 z := by
   unfold s_691
   dsimp only [pL, pmNode_606, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_690_0, r_690_0 z, r_690_1 z] <;> rfl
 #a w_690_0
 theorem h_690_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_690_0 z).shape = [1, 4, 16, 8] := by
   unfold v_690_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_687_0 z z_]
 #a h_690_0
 attribute [local irreducible] v_690_0
 attribute [local irreducible] s_691
 theorem n_576_640 (z : Store) (tid : Tid) (h : tid ∉ ([1137, 1138, 838, 839, 685, 842, 1141, 1142, 988, 1145, 845, 846, 1148, 1149, 849, 850, 1152, 1153, 853, 854, 857, 1156, 1157, 1160, 859, 860, 905, 907, 1162, 1163, 1208, 1210, 864, 865, 1167, 1168, 868, 869, 1171, 1172, 871, 872, 875, 877, 878, 881, 1174, 1175, 1178, 1180, 1181, 1184, 686, 883, 989, 1186, 886, 887, 1189, 1190, 683, 888, 986, 1191, 884, 885, 679] : List Tid)) : (s_640 z) tid = (s_576 z) tid := by
   exact pF _ _ _ _ _ (n_576_608 z) (n_608_640 z) tid h
 #a n_576_640
 theorem r_691_0 (z : Store) : (s_691 z) 837 = (v_690_0 z) := w_690_0 z
 #a r_691_0
 theorem r_691_1 (z : Store) : (s_691 z) 834 = (v_574_0 z) := pR (k_690 z) (pR (k_689 z) (pR (k_688 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_576_640 z) (pR (k_575 z) (r_575_0 z)))))))
 #a r_691_1
 def v_691_0 (z : Store) : Tensor := bw_div ((4 : Nat) : Scalar) (v_690_0 z)
 def s_692 (z : Store) : Store := storeSet (s_691 z) [(836, bw_div ((4 : Nat) : Scalar) ((s_691 z) 837))]
 theorem t_691 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_607) (pmPeers pmNode_607) (s_691 z) pmNode_607 none = some (s_692 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_691
 theorem k_691 (z : Store) (tid : Tid) (h : tid ∉ [836]) : (s_692 z) tid = (s_691 z) tid := by
   unfold s_692
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_691
 theorem w_691_0 (z : Store) : (s_692 z) 836 = v_691_0 z := by
   unfold s_692
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_691_0, r_691_0 z, r_691_1 z] <;> rfl
 #a w_691_0
 theorem h_691_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_691_0 z).shape = [1, 4, 16, 8] := by
   unfold v_691_0
   exact h_690_0 z z_
 #a h_691_0
 attribute [local irreducible] v_691_0
 attribute [local irreducible] s_692
 theorem r_692_0 (z : Store) : (s_692 z) 840 = (v_687_0 z) := pR (k_691 z) (pR (k_690 z) (r_690_0 z))
 #a r_692_0
 theorem r_692_1 (z : Store) : (s_692 z) 1143 = (v_689_0 z) := pR (k_691 z) (pR (k_690 z) (r_690_1 z))
 #a r_692_1
 def v_692_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 3 [(v_687_0 z), (v_689_0 z)]
 theorem g_692 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_842) (s_692 z) pmNode_842 2 3 1140 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_842, r_692_0 z, r_692_1 z, h_687_0 z z_, h_689_0 z z_]
 #a g_692
 def s_693 (z : Store) : Store := pL [2, 3] (s_692 z) pmNode_842 2 3
 theorem t_692 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_842) (pmPeers pmNode_842) (s_692 z) pmNode_842 none = some (s_693 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_842) (s_692 z) pmNode_842).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 3 1140 (by decide) (g_692 z z_)]
   rfl
 #a t_692
 theorem k_692 (z : Store) (tid : Tid) (h : tid ∉ [1140]) : (s_693 z) tid = (s_692 z) tid := by
   unfold s_693
   dsimp only [pL, pmNode_842, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_692
 theorem w_692_0 (z : Store) : (s_693 z) 1140 = v_692_0 z := by
   unfold s_693
   dsimp only [pL, pmNode_842, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_692_0, r_692_0 z, r_692_1 z] <;> rfl
 #a w_692_0
 theorem h_692_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_692_0 z).shape = [1, 4, 16, 8] := by
   unfold v_692_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_687_0 z z_]
 #a h_692_0
 attribute [local irreducible] v_692_0
 attribute [local irreducible] s_693
 theorem n_688_692 (z : Store) (tid : Tid) (h : tid ∉ ([1130, 1143, 837, 836] : List Tid)) : (s_692 z) tid = (s_688 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_688 z) (k_689 z)) (pF _ _ _ _ _ (k_690 z) (k_691 z)) tid h
 #a n_688_692
 theorem r_693_0 (z : Store) : (s_693 z) 1140 = (v_692_0 z) := w_692_0 z
 #a r_693_0
 theorem r_693_1 (z : Store) : (s_693 z) 1137 = (v_576_0 z) := pR (k_692 z) (pR (n_688_692 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_592_608 z) (pR (n_584_592 z) (pR (n_580_584 z) (pR (k_579 z) (pR (k_578 z) (pR (k_577 z) (r_577_0 z)))))))))))
 #a r_693_1
 def v_693_0 (z : Store) : Tensor := bw_div ((4 : Nat) : Scalar) (v_692_0 z)
 def s_694 (z : Store) : Store := storeSet (s_693 z) [(1139, bw_div ((4 : Nat) : Scalar) ((s_693 z) 1140))]
 theorem t_693 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_843) (pmPeers pmNode_843) (s_693 z) pmNode_843 none = some (s_694 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_693
 theorem k_693 (z : Store) (tid : Tid) (h : tid ∉ [1139]) : (s_694 z) tid = (s_693 z) tid := by
   unfold s_694
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_693
 theorem w_693_0 (z : Store) : (s_694 z) 1139 = v_693_0 z := by
   unfold s_694
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_693_0, r_693_0 z, r_693_1 z] <;> rfl
 #a w_693_0
 theorem h_693_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_693_0 z).shape = [1, 4, 16, 8] := by
   unfold v_693_0
   exact h_692_0 z z_
 #a h_693_0
 attribute [local irreducible] v_693_0
 attribute [local irreducible] s_694
 theorem r_694_0 (z : Store) : (s_694 z) 836 = (v_691_0 z) := pR (k_693 z) (pR (k_692 z) (w_691_0 z))
 #a r_694_0
 theorem r_694_1 (z : Store) : (s_694 z) 1139 = (v_693_0 z) := w_693_0 z
 #a r_694_1
 def v_694_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_691_0 z), (v_693_0 z)]
 theorem g_694 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_608) (s_694 z) pmNode_608 3 1 833 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_608, r_694_0 z, r_694_1 z, h_691_0 z z_, h_693_0 z z_]
 #a g_694
 def s_695 (z : Store) : Store := pL [2, 3] (s_694 z) pmNode_608 3 1
 theorem t_694 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_608) (pmPeers pmNode_608) (s_694 z) pmNode_608 none = some (s_695 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_608) (s_694 z) pmNode_608).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 833 (by decide) (g_694 z z_)]
   rfl
 #a t_694
 theorem k_694 (z : Store) (tid : Tid) (h : tid ∉ [833]) : (s_695 z) tid = (s_694 z) tid := by
   unfold s_695
   dsimp only [pL, pmNode_608, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_694
 theorem w_694_0 (z : Store) : (s_695 z) 833 = v_694_0 z := by
   unfold s_695
   dsimp only [pL, pmNode_608, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_694_0, r_694_0 z, r_694_1 z] <;> rfl
 #a w_694_0
 theorem h_694_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_694_0 z).shape = [1, 2, 16, 16] := by
   unfold v_694_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_691_0 z z_]
 #a h_694_0
 attribute [local irreducible] v_694_0
 attribute [local irreducible] s_695
 theorem r_695_0 (z : Store) : (s_695 z) 833 = (v_694_0 z) := w_694_0 z
 #a r_695_0
 theorem r_695_1 (z : Store) : (s_695 z) 809 = (v_549_0 z) := pR (k_694 z) (pR (k_693 z) (pR (k_692 z) (pR (n_688_692 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_576_640 z) (pR (n_572_576 z) (pR (k_571 z) (r_571_0 z)))))))))
 #a r_695_1
 theorem r_695_2 (z : Store) : (s_695 z) 830 = (v_570_0 z) := pR (k_694 z) (pR (k_693 z) (pR (k_692 z) (pR (n_688_692 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_576_640 z) (pR (n_572_576 z) (pR (k_571 z) (r_571_1 z)))))))))
 #a r_695_2
 def v_695_0 (z : Store) : Tensor := (batchedMatmulBwd (v_694_0 z) (v_549_0 z) (v_570_0 z)).1
 def v_695_1 (z : Store) : Tensor := (batchedMatmulBwd (v_694_0 z) (v_549_0 z) (v_570_0 z)).2
 def s_696 (z : Store) : Store := storeSet (s_695 z) [(811, (batchedMatmulBwd ((s_695 z) 833) ((s_695 z) 809) ((s_695 z) 830)).1), (832, (batchedMatmulBwd ((s_695 z) 833) ((s_695 z) 809) ((s_695 z) 830)).2)]
 theorem t_695 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_609) (pmPeers pmNode_609) (s_695 z) pmNode_609 none = some (s_696 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_695
 theorem k_695 (z : Store) (tid : Tid) (h : tid ∉ [811, 832]) : (s_696 z) tid = (s_695 z) tid := by
   unfold s_696
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_695
 theorem w_695_0 (z : Store) : (s_696 z) 811 = v_695_0 z := by
   unfold s_696
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_695_0, r_695_0 z, r_695_1 z, r_695_2 z] <;> rfl
 #a w_695_0
 theorem h_695_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_695_0 z).shape = [1, 2, 16, 16] := by
   unfold v_695_0
   change (batchedMatmul (v_694_0 z) (transpose2d (v_570_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_694_0 z z_, h_570_0 z z_]
   rfl
 #a h_695_0
 attribute [local irreducible] v_695_0
 theorem w_695_1 (z : Store) : (s_696 z) 832 = v_695_1 z := by
   unfold s_696
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_695_1, r_695_0 z, r_695_1 z, r_695_2 z] <;> rfl
 #a w_695_1
 theorem h_695_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_695_1 z).shape = [1, 2, 16, 16] := by
   unfold v_695_1
   change (batchedMatmul (transpose2d (v_549_0 z)) (v_694_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_694_0 z z_, h_549_0 z z_]
   rfl
 #a h_695_1
 attribute [local irreducible] v_695_1
 attribute [local irreducible] s_696
 record_prefix_opacity v_688_0 s_689 v_689_0 s_690 v_690_0 s_691 v_691_0 s_692 v_692_0 s_693 v_693_0 s_694 v_694_0 s_695 v_695_0 v_695_1 s_696

 end
 end TrainVerify.Denote.RuntimeWorld
