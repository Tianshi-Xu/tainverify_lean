import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0075
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_605_0 (z : Store) : (s_605 z) 1163 = (v_604_0 z) := w_604_0 z
 #a r_605_0
 def v_605_0 (z : Store) : Tensor := (v_604_0 z)
 def v_605_1 (z : Store) : Tensor := (v_604_0 z)
 def s_606 (z : Store) : Store := storeSet (s_605 z) [(1208, ((s_605 z) 1163)), (1210, ((s_605 z) 1163))]
 theorem t_605 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_799) (pmPeers pmNode_799) (s_605 z) pmNode_799 none = some (s_606 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_605
 theorem k_605 (z : Store) (tid : Tid) (h : tid ∉ [1208, 1210]) : (s_606 z) tid = (s_605 z) tid := by
   unfold s_606
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_605
 theorem w_605_0 (z : Store) : (s_606 z) 1208 = v_605_0 z := by
   unfold s_606
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_605_0, r_605_0 z] <;> rfl
 #a w_605_0
 theorem h_605_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_605_0 z).shape = [1, 16, 32] := by
   unfold v_605_0
   exact h_604_0 z z_
 #a h_605_0
 attribute [local irreducible] v_605_0
 theorem w_605_1 (z : Store) : (s_606 z) 1210 = v_605_1 z := by
   unfold s_606
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_605_1, r_605_0 z] <;> rfl
 #a w_605_1
 theorem h_605_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_605_1 z).shape = [1, 16, 32] := by
   unfold v_605_1
   exact h_604_0 z z_
 #a h_605_1
 attribute [local irreducible] v_605_1
 attribute [local irreducible] s_606
 theorem r_606_0 (z : Store) : (s_606 z) 905 = (v_602_0 z) := pR (k_605 z) (pR (k_604 z) (pR (k_603 z) (w_602_0 z)))
 #a r_606_0
 theorem r_606_1 (z : Store) : (s_606 z) 1208 = (v_605_0 z) := w_605_0 z
 #a r_606_1
 def v_606_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_602_0 z), (v_605_0 z)]
 theorem g_606 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_564) (s_606 z) pmNode_564 2 1 864 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_564, r_606_0 z, r_606_1 z, h_602_0 z z_, h_605_0 z z_]
 #a g_606
 def s_607 (z : Store) : Store := pL [2, 3] (s_606 z) pmNode_564 2 1
 theorem t_606 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_564) (pmPeers pmNode_564) (s_606 z) pmNode_564 none = some (s_607 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_564) (s_606 z) pmNode_564).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 864 (by decide) (g_606 z z_)]
   rfl
 #a t_606
 theorem k_606 (z : Store) (tid : Tid) (h : tid ∉ [864]) : (s_607 z) tid = (s_606 z) tid := by
   unfold s_607
   dsimp only [pL, pmNode_564, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_606
 theorem w_606_0 (z : Store) : (s_607 z) 864 = v_606_0 z := by
   unfold s_607
   dsimp only [pL, pmNode_564, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_606_0, r_606_0 z, r_606_1 z] <;> rfl
 #a w_606_0
 theorem h_606_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_606_0 z).shape = [1, 8, 64] := by
   unfold v_606_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_602_0 z z_]
 #a h_606_0
 attribute [local irreducible] v_606_0
 attribute [local irreducible] s_607
 theorem r_607_0 (z : Store) : (s_607 z) 864 = (v_606_0 z) := w_606_0 z
 #a r_607_0
 theorem r_607_1 (z : Store) : (s_607 z) 617 = (z 617) := pR (k_606 z) (pR (k_605 z) (pR (k_604 z) (pR (n_600_604 z) (pR (n_592_600 z) (pR (n_576_592 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_86 z))))))))
 #a r_607_1
 theorem r_607_2 (z : Store) : (s_607 z) 618 = (z 618) := pR (k_606 z) (pR (k_605 z) (pR (k_604 z) (pR (n_600_604 z) (pR (n_592_600 z) (pR (n_576_592 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_87 z))))))))
 #a r_607_2
 def v_607_0 (z : Store) : Tensor := fw_layernorm (v_606_0 z) (z 617) (z 618)
 def s_608 (z : Store) : Store := storeSet (s_607 z) [(865, fw_layernorm ((s_607 z) 864) ((s_607 z) 617) ((s_607 z) 618))]
 theorem t_607 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_565) (pmPeers pmNode_565) (s_607 z) pmNode_565 none = some (s_608 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_607
 theorem k_607 (z : Store) (tid : Tid) (h : tid ∉ [865]) : (s_608 z) tid = (s_607 z) tid := by
   unfold s_608
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_607
 theorem w_607_0 (z : Store) : (s_608 z) 865 = v_607_0 z := by
   unfold s_608
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_607_0, r_607_0 z, r_607_1 z, r_607_2 z] <;> rfl
 #a w_607_0
 theorem h_607_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_607_0 z).shape = [1, 8, 64] := by
   unfold v_607_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_606_0 z z_
 #a h_607_0
 attribute [local irreducible] v_607_0
 attribute [local irreducible] s_608
 theorem r_608_0 (z : Store) : (s_608 z) 905 = (v_602_0 z) := pR (k_607 z) (pR (k_606 z) (r_606_0 z))
 #a r_608_0
 theorem r_608_1 (z : Store) : (s_608 z) 1208 = (v_605_0 z) := pR (k_607 z) (pR (k_606 z) (r_606_1 z))
 #a r_608_1
 def v_608_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_602_0 z), (v_605_0 z)]
 theorem g_608 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_800) (s_608 z) pmNode_800 2 1 1167 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_800, r_608_0 z, r_608_1 z, h_602_0 z z_, h_605_0 z z_]
 #a g_608
 def s_609 (z : Store) : Store := pL [2, 3] (s_608 z) pmNode_800 2 1
 theorem t_608 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_800) (pmPeers pmNode_800) (s_608 z) pmNode_800 none = some (s_609 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_800) (s_608 z) pmNode_800).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1167 (by decide) (g_608 z z_)]
   rfl
 #a t_608
 theorem k_608 (z : Store) (tid : Tid) (h : tid ∉ [1167]) : (s_609 z) tid = (s_608 z) tid := by
   unfold s_609
   dsimp only [pL, pmNode_800, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_608
 theorem w_608_0 (z : Store) : (s_609 z) 1167 = v_608_0 z := by
   unfold s_609
   dsimp only [pL, pmNode_800, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_608_0, r_608_0 z, r_608_1 z] <;> rfl
 #a w_608_0
 theorem h_608_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_608_0 z).shape = [1, 8, 64] := by
   unfold v_608_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_602_0 z z_]
 #a h_608_0
 attribute [local irreducible] v_608_0
 attribute [local irreducible] s_609
 theorem n_604_608 (z : Store) (tid : Tid) (h : tid ∉ ([1163, 1208, 1210, 864, 865] : List Tid)) : (s_608 z) tid = (s_604 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_604 z) (k_605 z)) (pF _ _ _ _ _ (k_606 z) (k_607 z)) tid h
 #a n_604_608
 theorem n_600_608 (z : Store) (tid : Tid) (h : tid ∉ ([859, 860, 905, 907, 1162, 1163, 1208, 1210, 864, 865] : List Tid)) : (s_608 z) tid = (s_600 z) tid := by
   exact pF _ _ _ _ _ (n_600_604 z) (n_604_608 z) tid h
 #a n_600_608
 theorem n_592_608 (z : Store) (tid : Tid) (h : tid ∉ ([1152, 1153, 853, 854, 857, 1156, 1157, 1160, 859, 860, 905, 907, 1162, 1163, 1208, 1210, 864, 865] : List Tid)) : (s_608 z) tid = (s_592 z) tid := by
   exact pF _ _ _ _ _ (n_592_600 z) (n_600_608 z) tid h
 #a n_592_608
 theorem n_576_608 (z : Store) (tid : Tid) (h : tid ∉ ([1137, 1138, 838, 839, 685, 842, 1141, 1142, 988, 1145, 845, 846, 1148, 1149, 849, 850, 1152, 1153, 853, 854, 857, 1156, 1157, 1160, 859, 860, 905, 907, 1162, 1163, 1208, 1210, 864, 865] : List Tid)) : (s_608 z) tid = (s_576 z) tid := by
   exact pF _ _ _ _ _ (n_576_592 z) (n_592_608 z) tid h
 #a n_576_608
 theorem r_609_0 (z : Store) : (s_609 z) 1167 = (v_608_0 z) := w_608_0 z
 #a r_609_0
 theorem r_609_1 (z : Store) : (s_609 z) 920 = (z 920) := pR (k_608 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_88 z))))
 #a r_609_1
 theorem r_609_2 (z : Store) : (s_609 z) 921 = (z 921) := pR (k_608 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_89 z))))
 #a r_609_2
 def v_609_0 (z : Store) : Tensor := fw_layernorm (v_608_0 z) (z 920) (z 921)
 def s_610 (z : Store) : Store := storeSet (s_609 z) [(1168, fw_layernorm ((s_609 z) 1167) ((s_609 z) 920) ((s_609 z) 921))]
 theorem t_609 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_801) (pmPeers pmNode_801) (s_609 z) pmNode_801 none = some (s_610 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_609
 theorem k_609 (z : Store) (tid : Tid) (h : tid ∉ [1168]) : (s_610 z) tid = (s_609 z) tid := by
   unfold s_610
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_609
 theorem w_609_0 (z : Store) : (s_610 z) 1168 = v_609_0 z := by
   unfold s_610
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_609_0, r_609_0 z, r_609_1 z, r_609_2 z] <;> rfl
 #a w_609_0
 theorem h_609_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_609_0 z).shape = [1, 8, 64] := by
   unfold v_609_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_608_0 z z_
 #a h_609_0
 attribute [local irreducible] v_609_0
 attribute [local irreducible] s_610
 theorem r_610_0 (z : Store) : (s_610 z) 865 = (v_607_0 z) := pR (k_609 z) (pR (k_608 z) (w_607_0 z))
 #a r_610_0
 theorem r_610_1 (z : Store) : (s_610 z) 1168 = (v_609_0 z) := w_609_0 z
 #a r_610_1
 def v_610_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_607_0 z), (v_609_0 z)]
 theorem g_610 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_566) (s_610 z) pmNode_566 1 2 868 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_566, r_610_0 z, r_610_1 z, h_607_0 z z_, h_609_0 z z_]
 #a g_610
 def s_611 (z : Store) : Store := pL [2, 3] (s_610 z) pmNode_566 1 2
 theorem t_610 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_566) (pmPeers pmNode_566) (s_610 z) pmNode_566 none = some (s_611 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_566) (s_610 z) pmNode_566).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 868 (by decide) (g_610 z z_)]
   rfl
 #a t_610
 theorem k_610 (z : Store) (tid : Tid) (h : tid ∉ [868]) : (s_611 z) tid = (s_610 z) tid := by
   unfold s_611
   dsimp only [pL, pmNode_566, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_610
 theorem w_610_0 (z : Store) : (s_611 z) 868 = v_610_0 z := by
   unfold s_611
   dsimp only [pL, pmNode_566, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_610_0, r_610_0 z, r_610_1 z] <;> rfl
 #a w_610_0
 theorem h_610_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_610_0 z).shape = [1, 16, 32] := by
   unfold v_610_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_607_0 z z_]
 #a h_610_0
 attribute [local irreducible] v_610_0
 attribute [local irreducible] s_611
 theorem r_611_0 (z : Store) : (s_611 z) 868 = (v_610_0 z) := w_610_0 z
 #a r_611_0
 theorem r_611_1 (z : Store) : (s_611 z) 669 = (z 669) := pR (k_610 z) (pR (k_609 z) (pR (k_608 z) (pR (n_576_608 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_90 z))))))
 #a r_611_1
 def v_611_0 (z : Store) : Tensor := fw_linear (v_610_0 z) (z 669)
 def s_612 (z : Store) : Store := storeSet (s_611 z) [(869, fw_linear ((s_611 z) 868) ((s_611 z) 669))]
 theorem t_611 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_567) (pmPeers pmNode_567) (s_611 z) pmNode_567 none = some (s_612 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_611
 theorem k_611 (z : Store) (tid : Tid) (h : tid ∉ [869]) : (s_612 z) tid = (s_611 z) tid := by
   unfold s_612
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_611
 theorem w_611_0 (z : Store) : (s_612 z) 869 = v_611_0 z := by
   unfold s_612
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_611_0, r_611_0 z, r_611_1 z] <;> rfl
 #a w_611_0
 theorem h_611_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_611_0 z).shape = [1, 16, 256] := by
   unfold v_611_0
   exact fw_linear_3d_shape 1 16 32 256 (v_610_0 z) (z 669) (h_610_0 z z_) (i_90 z z_)
 #a h_611_0
 attribute [local irreducible] v_611_0
 attribute [local irreducible] s_612
 theorem r_612_0 (z : Store) : (s_612 z) 865 = (v_607_0 z) := pR (k_611 z) (pR (k_610 z) (r_610_0 z))
 #a r_612_0
 theorem r_612_1 (z : Store) : (s_612 z) 1168 = (v_609_0 z) := pR (k_611 z) (pR (k_610 z) (r_610_1 z))
 #a r_612_1
 def v_612_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_607_0 z), (v_609_0 z)]
 theorem g_612 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_802) (s_612 z) pmNode_802 1 2 1171 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_802, r_612_0 z, r_612_1 z, h_607_0 z z_, h_609_0 z z_]
 #a g_612
 def s_613 (z : Store) : Store := pL [2, 3] (s_612 z) pmNode_802 1 2
 theorem t_612 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_802) (pmPeers pmNode_802) (s_612 z) pmNode_802 none = some (s_613 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_802) (s_612 z) pmNode_802).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1171 (by decide) (g_612 z z_)]
   rfl
 #a t_612
 theorem k_612 (z : Store) (tid : Tid) (h : tid ∉ [1171]) : (s_613 z) tid = (s_612 z) tid := by
   unfold s_613
   dsimp only [pL, pmNode_802, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_612
 theorem w_612_0 (z : Store) : (s_613 z) 1171 = v_612_0 z := by
   unfold s_613
   dsimp only [pL, pmNode_802, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_612_0, r_612_0 z, r_612_1 z] <;> rfl
 #a w_612_0
 theorem h_612_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_612_0 z).shape = [1, 16, 32] := by
   unfold v_612_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_607_0 z z_]
 #a h_612_0
 attribute [local irreducible] v_612_0
 attribute [local irreducible] s_613
 theorem n_608_612 (z : Store) (tid : Tid) (h : tid ∉ ([1167, 1168, 868, 869] : List Tid)) : (s_612 z) tid = (s_608 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_608 z) (k_609 z)) (pF _ _ _ _ _ (k_610 z) (k_611 z)) tid h
 #a n_608_612
 record_prefix_opacity v_605_0 v_605_1 s_606 v_606_0 s_607 v_607_0 s_608 v_608_0 s_609 v_609_0 s_610 v_610_0 s_611 v_611_0 s_612 v_612_0 s_613

 end
 end TrainVerify.Denote.RuntimeWorld
