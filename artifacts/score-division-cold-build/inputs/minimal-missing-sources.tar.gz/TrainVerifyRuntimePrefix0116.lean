import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0115
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_901_0 (z : Store) : (s_901 z) 57 = (v_247_1 z) := pR (k_900 z) (pR (n_896_900 z) (pR (n_864_896 z) (pR (n_860_864 z) (r_860_0 z))))
 #a r_901_0
 theorem r_901_1 (z : Store) : (s_901 z) 663 = (v_669_1 z) := pR (k_900 z) (pR (n_896_900 z) (pR (n_864_896 z) (pR (n_860_864 z) (r_860_1 z))))
 #a r_901_1
 def v_901_0 (z : Store) : Tensor := cross_dp_wred [(v_247_1 z), (v_669_1 z)]
 theorem g_901 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_700) (s_901 z) pmNode_700 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_700, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_901_1 z, r_901_0 z]
     exact (h_669_1 z z_).trans (h_247_1 z z_).symm
 #a g_901
 def s_902 (z : Store) : Store := storeSet (s_901 z) [(664, cross_dp_wred [((s_901 z) 57), ((s_901 z) 663)])]
 theorem t_901 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_700) (pmPeers pmNode_700) (s_901 z) pmNode_700 none = some (s_902 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_700) (s_901 z) pmNode_700 = _
   rw [wredStep, if_pos ⟨by decide, g_901 z z_⟩]
   rfl
 #a t_901
 theorem k_901 (z : Store) (tid : Tid) (h : tid ∉ [664]) : (s_902 z) tid = (s_901 z) tid := by
   unfold s_902
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_901
 theorem w_901_0 (z : Store) : (s_902 z) 664 = v_901_0 z := by
   unfold s_902
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_901_0, r_901_0 z, r_901_1 z] <;> rfl
 #a w_901_0
 theorem h_901_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_901_0 z).shape = [64, 32] := by
   unfold v_901_0
   rw [tensorSum_shape]
   exact h_247_1 z z_
 #a h_901_0
 attribute [local irreducible] v_901_0
 attribute [local irreducible] s_902
 theorem r_902_0 (z : Store) : (s_902 z) 28 = (v_399_1 z) := pR (k_901 z) (pR (k_900 z) (pR (n_896_900 z) (pR (n_864_896 z) (pR (k_863 z) (pR (k_862 z) (pR (k_861 z) (r_861_0 z)))))))
 #a r_902_0
 theorem r_902_1 (z : Store) : (s_902 z) 634 = (v_821_1 z) := pR (k_901 z) (pR (k_900 z) (pR (n_896_900 z) (pR (n_864_896 z) (pR (k_863 z) (pR (k_862 z) (pR (k_861 z) (r_861_1 z)))))))
 #a r_902_1
 def v_902_0 (z : Store) : Tensor := cross_dp_wred [(v_399_1 z), (v_821_1 z)]
 theorem g_902 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_701) (s_902 z) pmNode_701 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_701, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_902_1 z, r_902_0 z]
     exact (h_821_1 z z_).trans (h_399_1 z z_).symm
 #a g_902
 def s_903 (z : Store) : Store := storeSet (s_902 z) [(635, cross_dp_wred [((s_902 z) 28), ((s_902 z) 634)])]
 theorem t_902 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_701) (pmPeers pmNode_701) (s_902 z) pmNode_701 none = some (s_903 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_701) (s_902 z) pmNode_701 = _
   rw [wredStep, if_pos ⟨by decide, g_902 z z_⟩]
   rfl
 #a t_902
 theorem k_902 (z : Store) (tid : Tid) (h : tid ∉ [635]) : (s_903 z) tid = (s_902 z) tid := by
   unfold s_903
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_902
 theorem w_902_0 (z : Store) : (s_903 z) 635 = v_902_0 z := by
   unfold s_903
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_902_0, r_902_0 z, r_902_1 z] <;> rfl
 #a w_902_0
 theorem h_902_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_902_0 z).shape = [32, 64] := by
   unfold v_902_0
   rw [tensorSum_shape]
   exact h_399_1 z z_
 #a h_902_0
 attribute [local irreducible] v_902_0
 attribute [local irreducible] s_903
 theorem r_903_0 (z : Store) : (s_903 z) 64 = (v_233_1 z) := pR (k_902 z) (pR (k_901 z) (pR (k_900 z) (pR (n_896_900 z) (pR (n_864_896 z) (pR (k_863 z) (pR (k_862 z) (r_862_0 z)))))))
 #a r_903_0
 theorem r_903_1 (z : Store) : (s_903 z) 670 = (v_655_1 z) := pR (k_902 z) (pR (k_901 z) (pR (k_900 z) (pR (n_896_900 z) (pR (n_864_896 z) (pR (k_863 z) (pR (k_862 z) (r_862_1 z)))))))
 #a r_903_1
 def v_903_0 (z : Store) : Tensor := cross_dp_wred [(v_233_1 z), (v_655_1 z)]
 theorem g_903 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_702) (s_903 z) pmNode_702 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_702, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_903_1 z, r_903_0 z]
     exact (h_655_1 z z_).trans (h_233_1 z z_).symm
 #a g_903
 def s_904 (z : Store) : Store := storeSet (s_903 z) [(671, cross_dp_wred [((s_903 z) 64), ((s_903 z) 670)])]
 theorem t_903 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_702) (pmPeers pmNode_702) (s_903 z) pmNode_702 none = some (s_904 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_702) (s_903 z) pmNode_702 = _
   rw [wredStep, if_pos ⟨by decide, g_903 z z_⟩]
   rfl
 #a t_903
 theorem k_903 (z : Store) (tid : Tid) (h : tid ∉ [671]) : (s_904 z) tid = (s_903 z) tid := by
   unfold s_904
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_903
 theorem w_903_0 (z : Store) : (s_904 z) 671 = v_903_0 z := by
   unfold s_904
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_903_0, r_903_0 z, r_903_1 z] <;> rfl
 #a w_903_0
 theorem h_903_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_903_0 z).shape = [256, 32] := by
   unfold v_903_0
   rw [tensorSum_shape]
   exact h_233_1 z z_
 #a h_903_0
 attribute [local irreducible] v_903_0
 attribute [local irreducible] s_904
 theorem n_900_904 (z : Store) (tid : Tid) (h : tid ∉ ([624, 664, 635, 671] : List Tid)) : (s_904 z) tid = (s_900 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_900 z) (k_901 z)) (pF _ _ _ _ _ (k_902 z) (k_903 z)) tid h
 #a n_900_904
 theorem n_896_904 (z : Store) (tid : Tid) (h : tid ∉ ([646, 648, 650, 652, 624, 664, 635, 671] : List Tid)) : (s_904 z) tid = (s_896 z) tid := by
   exact pF _ _ _ _ _ (n_896_900 z) (n_900_904 z) tid h
 #a n_896_904
 theorem r_904_0 (z : Store) : (s_904 z) 31 = (v_394_1 z) := pR (n_896_904 z) (pR (n_864_896 z) (pR (k_863 z) (r_863_0 z)))
 #a r_904_0
 theorem r_904_1 (z : Store) : (s_904 z) 637 = (v_816_1 z) := pR (n_896_904 z) (pR (n_864_896 z) (pR (k_863 z) (r_863_1 z)))
 #a r_904_1
 def v_904_0 (z : Store) : Tensor := cross_dp_wred [(v_394_1 z), (v_816_1 z)]
 theorem g_904 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_703) (s_904 z) pmNode_703 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_703, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_904_1 z, r_904_0 z]
     exact (h_816_1 z z_).trans (h_394_1 z z_).symm
 #a g_904
 def s_905 (z : Store) : Store := storeSet (s_904 z) [(638, cross_dp_wred [((s_904 z) 31), ((s_904 z) 637)])]
 theorem t_904 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_703) (pmPeers pmNode_703) (s_904 z) pmNode_703 none = some (s_905 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_703) (s_904 z) pmNode_703 = _
   rw [wredStep, if_pos ⟨by decide, g_904 z z_⟩]
   rfl
 #a t_904
 theorem k_904 (z : Store) (tid : Tid) (h : tid ∉ [638]) : (s_905 z) tid = (s_904 z) tid := by
   unfold s_905
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_904
 theorem w_904_0 (z : Store) : (s_905 z) 638 = v_904_0 z := by
   unfold s_905
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_904_0, r_904_0 z, r_904_1 z] <;> rfl
 #a w_904_0
 theorem h_904_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_904_0 z).shape = [32, 64] := by
   unfold v_904_0
   rw [tensorSum_shape]
   exact h_394_1 z z_
 #a h_904_0
 attribute [local irreducible] v_904_0
 attribute [local irreducible] s_905
 theorem r_905_0 (z : Store) : (s_905 z) 73 = (v_217_1 z) := pR (k_904 z) (pR (n_896_904 z) (pR (n_864_896 z) (r_864_0 z)))
 #a r_905_0
 theorem r_905_1 (z : Store) : (s_905 z) 679 = (v_639_1 z) := pR (k_904 z) (pR (n_896_904 z) (pR (n_864_896 z) (r_864_1 z)))
 #a r_905_1
 def v_905_0 (z : Store) : Tensor := cross_dp_wred [(v_217_1 z), (v_639_1 z)]
 theorem g_905 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_704) (s_905 z) pmNode_704 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_704, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_905_1 z, r_905_0 z]
     exact (h_639_1 z z_).trans (h_217_1 z z_).symm
 #a g_905
 def s_906 (z : Store) : Store := storeSet (s_905 z) [(680, cross_dp_wred [((s_905 z) 73), ((s_905 z) 679)])]
 theorem t_905 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_704) (pmPeers pmNode_704) (s_905 z) pmNode_704 none = some (s_906 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_704) (s_905 z) pmNode_704 = _
   rw [wredStep, if_pos ⟨by decide, g_905 z z_⟩]
   rfl
 #a t_905
 theorem k_905 (z : Store) (tid : Tid) (h : tid ∉ [680]) : (s_906 z) tid = (s_905 z) tid := by
   unfold s_906
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_905
 theorem w_905_0 (z : Store) : (s_906 z) 680 = v_905_0 z := by
   unfold s_906
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_905_0, r_905_0 z, r_905_1 z] <;> rfl
 #a w_905_0
 theorem h_905_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_905_0 z).shape = [128, 64] := by
   unfold v_905_0
   rw [tensorSum_shape]
   exact h_217_1 z z_
 #a h_905_0
 attribute [local irreducible] v_905_0
 attribute [local irreducible] s_906
 theorem r_906_0 (z : Store) : (s_906 z) 48 = (v_311_1 z) := pR (k_905 z) (pR (k_904 z) (pR (n_896_904 z) (pR (n_880_896 z) (pR (n_872_880 z) (pR (n_868_872 z) (pR (k_867 z) (pR (k_866 z) (pR (k_865 z) (r_865_0 z)))))))))
 #a r_906_0
 theorem r_906_1 (z : Store) : (s_906 z) 654 = (v_733_1 z) := pR (k_905 z) (pR (k_904 z) (pR (n_896_904 z) (pR (n_880_896 z) (pR (n_872_880 z) (pR (n_868_872 z) (pR (k_867 z) (pR (k_866 z) (pR (k_865 z) (r_865_1 z)))))))))
 #a r_906_1
 def v_906_0 (z : Store) : Tensor := cross_dp_wred [(v_311_1 z), (v_733_1 z)]
 theorem g_906 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_705) (s_906 z) pmNode_705 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_705, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_906_1 z, r_906_0 z]
     exact (h_733_1 z z_).trans (h_311_1 z z_).symm
 #a g_906
 def s_907 (z : Store) : Store := storeSet (s_906 z) [(655, cross_dp_wred [((s_906 z) 48), ((s_906 z) 654)])]
 theorem t_906 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_705) (pmPeers pmNode_705) (s_906 z) pmNode_705 none = some (s_907 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_705) (s_906 z) pmNode_705 = _
   rw [wredStep, if_pos ⟨by decide, g_906 z z_⟩]
   rfl
 #a t_906
 theorem k_906 (z : Store) (tid : Tid) (h : tid ∉ [655]) : (s_907 z) tid = (s_906 z) tid := by
   unfold s_907
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_906
 theorem w_906_0 (z : Store) : (s_907 z) 655 = v_906_0 z := by
   unfold s_907
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_906_0, r_906_0 z, r_906_1 z] <;> rfl
 #a w_906_0
 theorem h_906_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_906_0 z).shape = [32, 64] := by
   unfold v_906_0
   rw [tensorSum_shape]
   exact h_311_1 z z_
 #a h_906_0
 attribute [local irreducible] v_906_0
 attribute [local irreducible] s_907
 theorem r_907_0 (z : Store) : (s_907 z) 51 = (v_307_1 z) := pR (k_906 z) (pR (k_905 z) (pR (k_904 z) (pR (n_896_904 z) (pR (n_880_896 z) (pR (n_872_880 z) (pR (n_868_872 z) (pR (k_867 z) (pR (k_866 z) (r_866_0 z)))))))))
 #a r_907_0
 theorem r_907_1 (z : Store) : (s_907 z) 657 = (v_729_1 z) := pR (k_906 z) (pR (k_905 z) (pR (k_904 z) (pR (n_896_904 z) (pR (n_880_896 z) (pR (n_872_880 z) (pR (n_868_872 z) (pR (k_867 z) (pR (k_866 z) (r_866_1 z)))))))))
 #a r_907_1
 def v_907_0 (z : Store) : Tensor := cross_dp_wred [(v_307_1 z), (v_729_1 z)]
 theorem g_907 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_706) (s_907 z) pmNode_706 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_706, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_907_1 z, r_907_0 z]
     exact (h_729_1 z z_).trans (h_307_1 z z_).symm
 #a g_907
 def s_908 (z : Store) : Store := storeSet (s_907 z) [(658, cross_dp_wred [((s_907 z) 51), ((s_907 z) 657)])]
 theorem t_907 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_706) (pmPeers pmNode_706) (s_907 z) pmNode_706 none = some (s_908 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_706) (s_907 z) pmNode_706 = _
   rw [wredStep, if_pos ⟨by decide, g_907 z z_⟩]
   rfl
 #a t_907
 theorem k_907 (z : Store) (tid : Tid) (h : tid ∉ [658]) : (s_908 z) tid = (s_907 z) tid := by
   unfold s_908
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_907
 theorem w_907_0 (z : Store) : (s_908 z) 658 = v_907_0 z := by
   unfold s_908
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_907_0, r_907_0 z, r_907_1 z] <;> rfl
 #a w_907_0
 theorem h_907_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_907_0 z).shape = [64, 32] := by
   unfold v_907_0
   rw [tensorSum_shape]
   exact h_307_1 z z_
 #a h_907_0
 attribute [local irreducible] v_907_0
 attribute [local irreducible] s_908
 theorem n_904_908 (z : Store) (tid : Tid) (h : tid ∉ ([638, 680, 655, 658] : List Tid)) : (s_908 z) tid = (s_904 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_904 z) (k_905 z)) (pF _ _ _ _ _ (k_906 z) (k_907 z)) tid h
 #a n_904_908
 theorem r_908_0 (z : Store) : (s_908 z) 54 = (v_303_1 z) := pR (n_904_908 z) (pR (n_896_904 z) (pR (n_880_896 z) (pR (n_872_880 z) (pR (n_868_872 z) (pR (k_867 z) (r_867_0 z))))))
 #a r_908_0
 theorem r_908_1 (z : Store) : (s_908 z) 660 = (v_725_1 z) := pR (n_904_908 z) (pR (n_896_904 z) (pR (n_880_896 z) (pR (n_872_880 z) (pR (n_868_872 z) (pR (k_867 z) (r_867_1 z))))))
 #a r_908_1
 def v_908_0 (z : Store) : Tensor := cross_dp_wred [(v_303_1 z), (v_725_1 z)]
 theorem g_908 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_707) (s_908 z) pmNode_707 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_707, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_908_1 z, r_908_0 z]
     exact (h_725_1 z z_).trans (h_303_1 z z_).symm
 #a g_908
 def s_909 (z : Store) : Store := storeSet (s_908 z) [(661, cross_dp_wred [((s_908 z) 54), ((s_908 z) 660)])]
 theorem t_908 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_707) (pmPeers pmNode_707) (s_908 z) pmNode_707 none = some (s_909 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_707) (s_908 z) pmNode_707 = _
   rw [wredStep, if_pos ⟨by decide, g_908 z z_⟩]
   rfl
 #a t_908
 theorem k_908 (z : Store) (tid : Tid) (h : tid ∉ [661]) : (s_909 z) tid = (s_908 z) tid := by
   unfold s_909
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_908
 theorem w_908_0 (z : Store) : (s_909 z) 661 = v_908_0 z := by
   unfold s_909
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_908_0, r_908_0 z, r_908_1 z] <;> rfl
 #a w_908_0
 theorem h_908_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_908_0 z).shape = [64, 32] := by
   unfold v_908_0
   rw [tensorSum_shape]
   exact h_303_1 z z_
 #a h_908_0
 attribute [local irreducible] v_908_0
 attribute [local irreducible] s_909
 theorem n_832_896 (z : Store) (tid : Tid) (h : tid ∉ ([890, 703, 696, 702, 1193, 1006, 999, 1005, 699, 625, 623, 1002, 928, 20, 22, 24, 60, 26, 62, 67, 69, 71, 34, 36, 38, 40, 42, 44, 46, 18, 58, 29, 65, 32, 74, 49, 52, 55, 323, 325, 327, 363, 329, 365, 370, 372, 374, 337, 339, 341, 343, 345, 347, 349, 626, 628, 630, 666, 632, 668, 673, 675, 677, 640, 642, 644] : List Tid)) : (s_896 z) tid = (s_832 z) tid := by
   exact pF _ _ _ _ _ (n_832_864 z) (n_864_896 z) tid h
 #a n_832_896
 theorem n_768_896 (z : Store) (tid : Tid) (h : tid ∉ ([764, 763, 1067, 1066, 760, 758, 755, 754, 756, 1063, 1061, 1059, 1058, 1057, 751, 735, 750, 1054, 1038, 1053, 747, 746, 1050, 1049, 743, 741, 742, 1046, 1044, 1045, 737, 723, 729, 733, 732, 1040, 1026, 1032, 1036, 1035, 716, 728, 1020, 1031, 725, 713, 722, 1028, 1017, 1025, 719, 711, 717, 637, 1022, 1014, 1019, 940, 894, 714, 634, 1197, 1016, 937, 892, 710, 631, 707, 706, 627, 629, 1195, 1013, 934, 1010, 1009, 930, 932, 890, 703, 696, 702, 1193, 1006, 999, 1005, 699, 625, 623, 1002, 928, 20, 22, 24, 60, 26, 62, 67, 69, 71, 34, 36, 38, 40, 42, 44, 46, 18, 58, 29, 65, 32, 74, 49, 52, 55, 323, 325, 327, 363, 329, 365, 370, 372, 374, 337, 339, 341, 343, 345, 347, 349, 626, 628, 630, 666, 632, 668, 673, 675, 677, 640, 642, 644] : List Tid)) : (s_896 z) tid = (s_768 z) tid := by
   exact pF _ _ _ _ _ (n_768_832 z) (n_832_896 z) tid h
 #a n_768_896
 record_prefix_opacity v_901_0 s_902 v_902_0 s_903 v_903_0 s_904 v_904_0 s_905 v_905_0 s_906 v_906_0 s_907 v_907_0 s_908 v_908_0 s_909

 end
 end TrainVerify.Denote.RuntimeWorld
