import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0074
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_596_0 (z : Store) : (s_596 z) 854 = (v_595_0 z) := w_595_0 z
 #a r_596_0
 theorem r_596_1 (z : Store) : (s_596 z) 662 = (z 662) := pR (n_592_596 z) (pR (n_576_592 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_84 z))))
 #a r_596_1
 def v_596_0 (z : Store) : Tensor := fw_linear (v_595_0 z) (z 662)
 def s_597 (z : Store) : Store := storeSet (s_596 z) [(857, fw_linear ((s_596 z) 854) ((s_596 z) 662))]
 theorem t_596 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_560) (pmPeers pmNode_560) (s_596 z) pmNode_560 none = some (s_597 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_596
 theorem k_596 (z : Store) (tid : Tid) (h : tid ∉ [857]) : (s_597 z) tid = (s_596 z) tid := by
   unfold s_597
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_596
 theorem w_596_0 (z : Store) : (s_597 z) 857 = v_596_0 z := by
   unfold s_597
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_596_0, r_596_0 z, r_596_1 z] <;> rfl
 #a w_596_0
 theorem h_596_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_596_0 z).shape = [1, 16, 64] := by
   unfold v_596_0
   exact fw_linear_3d_shape 1 16 32 64 (v_595_0 z) (z 662) (h_595_0 z z_) (i_84 z z_)
 #a h_596_0
 attribute [local irreducible] v_596_0
 attribute [local irreducible] s_597
 theorem r_597_0 (z : Store) : (s_597 z) 850 = (v_591_0 z) := pR (k_596 z) (pR (k_595 z) (pR (k_594 z) (r_594_0 z)))
 #a r_597_0
 theorem r_597_1 (z : Store) : (s_597 z) 1153 = (v_593_0 z) := pR (k_596 z) (pR (k_595 z) (pR (k_594 z) (r_594_1 z)))
 #a r_597_1
 def v_597_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_591_0 z), (v_593_0 z)]
 theorem g_597 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_794) (s_597 z) pmNode_794 1 2 1156 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_794, r_597_0 z, r_597_1 z, h_591_0 z z_, h_593_0 z z_]
 #a g_597
 def s_598 (z : Store) : Store := pL [2, 3] (s_597 z) pmNode_794 1 2
 theorem t_597 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_794) (pmPeers pmNode_794) (s_597 z) pmNode_794 none = some (s_598 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_794) (s_597 z) pmNode_794).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1156 (by decide) (g_597 z z_)]
   rfl
 #a t_597
 theorem k_597 (z : Store) (tid : Tid) (h : tid ∉ [1156]) : (s_598 z) tid = (s_597 z) tid := by
   unfold s_598
   dsimp only [pL, pmNode_794, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_597
 theorem w_597_0 (z : Store) : (s_598 z) 1156 = v_597_0 z := by
   unfold s_598
   dsimp only [pL, pmNode_794, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_597_0, r_597_0 z, r_597_1 z] <;> rfl
 #a w_597_0
 theorem h_597_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_597_0 z).shape = [1, 16, 2, 16] := by
   unfold v_597_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_591_0 z z_]
 #a h_597_0
 attribute [local irreducible] v_597_0
 attribute [local irreducible] s_598
 theorem r_598_0 (z : Store) : (s_598 z) 1156 = (v_597_0 z) := w_597_0 z
 #a r_598_0
 def v_598_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_597_0 z)
 def s_599 (z : Store) : Store := storeSet (s_598 z) [(1157, fw_view [1, 16, 32] ((s_598 z) 1156))]
 theorem t_598 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_795) (pmPeers pmNode_795) (s_598 z) pmNode_795 none = some (s_599 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_598
 theorem k_598 (z : Store) (tid : Tid) (h : tid ∉ [1157]) : (s_599 z) tid = (s_598 z) tid := by
   unfold s_599
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_598
 theorem w_598_0 (z : Store) : (s_599 z) 1157 = v_598_0 z := by
   unfold s_599
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_598_0, r_598_0 z] <;> rfl
 #a w_598_0
 theorem h_598_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_598_0 z).shape = [1, 16, 32] := by
   unfold v_598_0
   rfl
 #a h_598_0
 attribute [local irreducible] v_598_0
 attribute [local irreducible] s_599
 theorem r_599_0 (z : Store) : (s_599 z) 1157 = (v_598_0 z) := w_598_0 z
 #a r_599_0
 theorem r_599_1 (z : Store) : (s_599 z) 965 = (z 965) := pR (k_598 z) (pR (k_597 z) (pR (k_596 z) (pR (n_592_596 z) (pR (n_576_592 z) (pR (n_512_576 z) (pR (n_0_512 z) (e_85 z)))))))
 #a r_599_1
 def v_599_0 (z : Store) : Tensor := fw_linear (v_598_0 z) (z 965)
 def s_600 (z : Store) : Store := storeSet (s_599 z) [(1160, fw_linear ((s_599 z) 1157) ((s_599 z) 965))]
 theorem t_599 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_796) (pmPeers pmNode_796) (s_599 z) pmNode_796 none = some (s_600 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_599
 theorem k_599 (z : Store) (tid : Tid) (h : tid ∉ [1160]) : (s_600 z) tid = (s_599 z) tid := by
   unfold s_600
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_599
 theorem w_599_0 (z : Store) : (s_600 z) 1160 = v_599_0 z := by
   unfold s_600
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_599_0, r_599_0 z, r_599_1 z] <;> rfl
 #a w_599_0
 theorem h_599_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_599_0 z).shape = [1, 16, 64] := by
   unfold v_599_0
   exact fw_linear_3d_shape 1 16 32 64 (v_598_0 z) (z 965) (h_598_0 z z_) (i_85 z z_)
 #a h_599_0
 attribute [local irreducible] v_599_0
 attribute [local irreducible] s_600
 theorem r_600_0 (z : Store) : (s_600 z) 857 = (v_596_0 z) := pR (k_599 z) (pR (k_598 z) (pR (k_597 z) (w_596_0 z)))
 #a r_600_0
 theorem r_600_1 (z : Store) : (s_600 z) 1160 = (v_599_0 z) := w_599_0 z
 #a r_600_1
 def v_600_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 0 [(v_596_0 z), (v_599_0 z)]
 def s_601 (z : Store) : Store := storeSet (s_600 z) [(859, reduceScatterPrimDimN 2 2 0 [((s_600 z) 857), ((s_600 z) 1160)])]
 theorem t_600 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_561) (pmPeers pmNode_561) (s_600 z) pmNode_561 none = some (s_601 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_600 z) pmNode_561 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_600
 theorem k_600 (z : Store) (tid : Tid) (h : tid ∉ [859]) : (s_601 z) tid = (s_600 z) tid := by
   unfold s_601
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_600
 theorem w_600_0 (z : Store) : (s_601 z) 859 = v_600_0 z := by
   unfold s_601
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_600_0, r_600_0 z, r_600_1 z] <;> rfl
 #a w_600_0
 theorem h_600_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_600_0 z).shape = [1, 16, 32] := by
   unfold v_600_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_596_0 z) rfl]
     exact h_596_0 z z_
   · decide
 #a h_600_0
 attribute [local irreducible] v_600_0
 attribute [local irreducible] s_601
 theorem n_596_600 (z : Store) (tid : Tid) (h : tid ∉ ([857, 1156, 1157, 1160] : List Tid)) : (s_600 z) tid = (s_596 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_596 z) (k_597 z)) (pF _ _ _ _ _ (k_598 z) (k_599 z)) tid h
 #a n_596_600
 theorem n_592_600 (z : Store) (tid : Tid) (h : tid ∉ ([1152, 1153, 853, 854, 857, 1156, 1157, 1160] : List Tid)) : (s_600 z) tid = (s_592 z) tid := by
   exact pF _ _ _ _ _ (n_592_596 z) (n_596_600 z) tid h
 #a n_592_600
 theorem r_601_0 (z : Store) : (s_601 z) 858 = (v_522_1 z) := pR (k_600 z) (pR (n_592_600 z) (pR (n_576_592 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_524_528 z) (pR (k_523 z) (w_522_1 z)))))))
 #a r_601_0
 theorem r_601_1 (z : Store) : (s_601 z) 859 = (v_600_0 z) := w_600_0 z
 #a r_601_1
 def v_601_0 (z : Store) : Tensor := elemwiseAdd (v_522_1 z) (v_600_0 z)
 def s_602 (z : Store) : Store := storeSet (s_601 z) [(860, elemwiseAdd ((s_601 z) 858) ((s_601 z) 859))]
 theorem t_601 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_562) (pmPeers pmNode_562) (s_601 z) pmNode_562 none = some (s_602 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_601
 theorem k_601 (z : Store) (tid : Tid) (h : tid ∉ [860]) : (s_602 z) tid = (s_601 z) tid := by
   unfold s_602
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_601
 theorem w_601_0 (z : Store) : (s_602 z) 860 = v_601_0 z := by
   unfold s_602
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_601_0, r_601_0 z, r_601_1 z] <;> rfl
 #a w_601_0
 theorem h_601_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_601_0 z).shape = [1, 16, 32] := by
   unfold v_601_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_522_1 z z_, h_600_0 z z_]
 #a h_601_0
 attribute [local irreducible] v_601_0
 attribute [local irreducible] s_602
 theorem r_602_0 (z : Store) : (s_602 z) 860 = (v_601_0 z) := w_601_0 z
 #a r_602_0
 def v_602_0 (z : Store) : Tensor := (v_601_0 z)
 def v_602_1 (z : Store) : Tensor := (v_601_0 z)
 def s_603 (z : Store) : Store := storeSet (s_602 z) [(905, ((s_602 z) 860)), (907, ((s_602 z) 860))]
 theorem t_602 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_563) (pmPeers pmNode_563) (s_602 z) pmNode_563 none = some (s_603 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_602
 theorem k_602 (z : Store) (tid : Tid) (h : tid ∉ [905, 907]) : (s_603 z) tid = (s_602 z) tid := by
   unfold s_603
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_602
 theorem w_602_0 (z : Store) : (s_603 z) 905 = v_602_0 z := by
   unfold s_603
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_602_0, r_602_0 z] <;> rfl
 #a w_602_0
 theorem h_602_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_602_0 z).shape = [1, 16, 32] := by
   unfold v_602_0
   exact h_601_0 z z_
 #a h_602_0
 attribute [local irreducible] v_602_0
 theorem w_602_1 (z : Store) : (s_603 z) 907 = v_602_1 z := by
   unfold s_603
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_602_1, r_602_0 z] <;> rfl
 #a w_602_1
 theorem h_602_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_602_1 z).shape = [1, 16, 32] := by
   unfold v_602_1
   exact h_601_0 z z_
 #a h_602_1
 attribute [local irreducible] v_602_1
 attribute [local irreducible] s_603
 theorem r_603_0 (z : Store) : (s_603 z) 857 = (v_596_0 z) := pR (k_602 z) (pR (k_601 z) (pR (k_600 z) (r_600_0 z)))
 #a r_603_0
 theorem r_603_1 (z : Store) : (s_603 z) 1160 = (v_599_0 z) := pR (k_602 z) (pR (k_601 z) (pR (k_600 z) (r_600_1 z)))
 #a r_603_1
 def v_603_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 1 [(v_596_0 z), (v_599_0 z)]
 def s_604 (z : Store) : Store := storeSet (s_603 z) [(1162, reduceScatterPrimDimN 2 2 1 [((s_603 z) 857), ((s_603 z) 1160)])]
 theorem t_603 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_797) (pmPeers pmNode_797) (s_603 z) pmNode_797 none = some (s_604 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_603 z) pmNode_797 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_603
 theorem k_603 (z : Store) (tid : Tid) (h : tid ∉ [1162]) : (s_604 z) tid = (s_603 z) tid := by
   unfold s_604
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_603
 theorem w_603_0 (z : Store) : (s_604 z) 1162 = v_603_0 z := by
   unfold s_604
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_603_0, r_603_0 z, r_603_1 z] <;> rfl
 #a w_603_0
 theorem h_603_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_603_0 z).shape = [1, 16, 32] := by
   unfold v_603_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_596_0 z) rfl]
     exact h_596_0 z z_
   · decide
 #a h_603_0
 attribute [local irreducible] v_603_0
 attribute [local irreducible] s_604
 theorem n_600_604 (z : Store) (tid : Tid) (h : tid ∉ ([859, 860, 905, 907, 1162] : List Tid)) : (s_604 z) tid = (s_600 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_600 z) (k_601 z)) (pF _ _ _ _ _ (k_602 z) (k_603 z)) tid h
 #a n_600_604
 theorem r_604_0 (z : Store) : (s_604 z) 1161 = (v_525_1 z) := pR (n_600_604 z) (pR (n_592_600 z) (pR (n_576_592 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (k_527 z) (pR (k_526 z) (w_525_1 z)))))))
 #a r_604_0
 theorem r_604_1 (z : Store) : (s_604 z) 1162 = (v_603_0 z) := w_603_0 z
 #a r_604_1
 def v_604_0 (z : Store) : Tensor := elemwiseAdd (v_525_1 z) (v_603_0 z)
 def s_605 (z : Store) : Store := storeSet (s_604 z) [(1163, elemwiseAdd ((s_604 z) 1161) ((s_604 z) 1162))]
 theorem t_604 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_798) (pmPeers pmNode_798) (s_604 z) pmNode_798 none = some (s_605 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_604
 theorem k_604 (z : Store) (tid : Tid) (h : tid ∉ [1163]) : (s_605 z) tid = (s_604 z) tid := by
   unfold s_605
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_604
 theorem w_604_0 (z : Store) : (s_605 z) 1163 = v_604_0 z := by
   unfold s_605
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_604_0, r_604_0 z, r_604_1 z] <;> rfl
 #a w_604_0
 theorem h_604_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_604_0 z).shape = [1, 16, 32] := by
   unfold v_604_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_525_1 z z_, h_603_0 z z_]
 #a h_604_0
 attribute [local irreducible] v_604_0
 attribute [local irreducible] s_605
 record_prefix_opacity v_596_0 s_597 v_597_0 s_598 v_598_0 s_599 v_599_0 s_600 v_600_0 s_601 v_601_0 s_602 v_602_0 v_602_1 s_603 v_603_0 s_604 v_604_0 s_605

 end
 end TrainVerify.Denote.RuntimeWorld
