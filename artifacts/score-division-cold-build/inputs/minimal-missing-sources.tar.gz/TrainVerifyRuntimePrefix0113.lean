import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0112
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_880_0 (z : Store) : (s_880 z) 39 = (v_329_1 z) := pR (n_864_880 z) (pR (n_856_864 z) (pR (k_855 z) (r_855_0 z)))
 #a r_880_0
 theorem r_880_1 (z : Store) : (s_880 z) 342 = (v_334_1 z) := pR (n_864_880 z) (pR (n_856_864 z) (pR (k_855 z) (r_855_1 z)))
 #a r_880_1
 theorem r_880_2 (z : Store) : (s_880 z) 645 = (v_751_1 z) := pR (n_864_880 z) (pR (n_856_864 z) (pR (k_855 z) (r_855_2 z)))
 #a r_880_2
 theorem r_880_3 (z : Store) : (s_880 z) 948 = (v_756_1 z) := pR (n_864_880 z) (pR (n_856_864 z) (pR (k_855 z) (r_855_3 z)))
 #a r_880_3
 def v_880_0 (z : Store) : Tensor := cross_dp_wred [(v_329_1 z), (v_334_1 z), (v_751_1 z), (v_756_1 z)]
 theorem g_880 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_459) (s_880 z) pmNode_459 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_459, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_880_1 z, r_880_0 z]
     exact (h_334_1 z z_).trans (h_329_1 z z_).symm
   · rw [r_880_2 z, r_880_0 z]
     exact (h_751_1 z z_).trans (h_329_1 z z_).symm
   · rw [r_880_3 z, r_880_0 z]
     exact (h_756_1 z z_).trans (h_329_1 z z_).symm
 #a g_880
 def s_881 (z : Store) : Store := storeSet (s_880 z) [(343, cross_dp_wred [((s_880 z) 39), ((s_880 z) 342), ((s_880 z) 645), ((s_880 z) 948)])]
 theorem t_880 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_459) (pmPeers pmNode_459) (s_880 z) pmNode_459 none = some (s_881 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_459) (s_880 z) pmNode_459 = _
   rw [wredStep, if_pos ⟨by decide, g_880 z z_⟩]
   rfl
 #a t_880
 theorem k_880 (z : Store) (tid : Tid) (h : tid ∉ [343]) : (s_881 z) tid = (s_880 z) tid := by
   unfold s_881
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_880
 theorem w_880_0 (z : Store) : (s_881 z) 343 = v_880_0 z := by
   unfold s_881
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_880_0, r_880_0 z, r_880_1 z, r_880_2 z, r_880_3 z] <;> rfl
 #a w_880_0
 theorem h_880_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_880_0 z).shape = [256, 64] := by
   unfold v_880_0
   rw [tensorSum_shape]
   exact h_329_1 z z_
 #a h_880_0
 attribute [local irreducible] v_880_0
 attribute [local irreducible] s_881
 theorem r_881_0 (z : Store) : (s_881 z) 41 = (v_327_1 z) := pR (k_880 z) (pR (n_864_880 z) (pR (n_856_864 z) (r_856_0 z)))
 #a r_881_0
 theorem r_881_1 (z : Store) : (s_881 z) 344 = (v_332_1 z) := pR (k_880 z) (pR (n_864_880 z) (pR (n_856_864 z) (r_856_1 z)))
 #a r_881_1
 theorem r_881_2 (z : Store) : (s_881 z) 647 = (v_749_1 z) := pR (k_880 z) (pR (n_864_880 z) (pR (n_856_864 z) (r_856_2 z)))
 #a r_881_2
 theorem r_881_3 (z : Store) : (s_881 z) 950 = (v_754_1 z) := pR (k_880 z) (pR (n_864_880 z) (pR (n_856_864 z) (r_856_3 z)))
 #a r_881_3
 def v_881_0 (z : Store) : Tensor := cross_dp_wred [(v_327_1 z), (v_332_1 z), (v_749_1 z), (v_754_1 z)]
 theorem g_881 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_460) (s_881 z) pmNode_460 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_460, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_881_1 z, r_881_0 z]
     exact (h_332_1 z z_).trans (h_327_1 z z_).symm
   · rw [r_881_2 z, r_881_0 z]
     exact (h_749_1 z z_).trans (h_327_1 z z_).symm
   · rw [r_881_3 z, r_881_0 z]
     exact (h_754_1 z z_).trans (h_327_1 z z_).symm
 #a g_881
 def s_882 (z : Store) : Store := storeSet (s_881 z) [(345, cross_dp_wred [((s_881 z) 41), ((s_881 z) 344), ((s_881 z) 647), ((s_881 z) 950)])]
 theorem t_881 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_460) (pmPeers pmNode_460) (s_881 z) pmNode_460 none = some (s_882 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_460) (s_881 z) pmNode_460 = _
   rw [wredStep, if_pos ⟨by decide, g_881 z z_⟩]
   rfl
 #a t_881
 theorem k_881 (z : Store) (tid : Tid) (h : tid ∉ [345]) : (s_882 z) tid = (s_881 z) tid := by
   unfold s_882
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_881
 theorem w_881_0 (z : Store) : (s_882 z) 345 = v_881_0 z := by
   unfold s_882
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_881_0, r_881_0 z, r_881_1 z, r_881_2 z, r_881_3 z] <;> rfl
 #a w_881_0
 theorem h_881_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_881_0 z).shape = [64, 256] := by
   unfold v_881_0
   rw [tensorSum_shape]
   exact h_327_1 z z_
 #a h_881_0
 attribute [local irreducible] v_881_0
 attribute [local irreducible] s_882
 theorem r_882_0 (z : Store) : (s_882 z) 43 = (v_316_1 z) := pR (k_881 z) (pR (k_880 z) (pR (n_864_880 z) (pR (n_860_864 z) (pR (k_859 z) (pR (k_858 z) (pR (k_857 z) (r_857_0 z)))))))
 #a r_882_0
 theorem r_882_1 (z : Store) : (s_882 z) 346 = (v_319_1 z) := pR (k_881 z) (pR (k_880 z) (pR (n_864_880 z) (pR (n_860_864 z) (pR (k_859 z) (pR (k_858 z) (pR (k_857 z) (r_857_1 z)))))))
 #a r_882_1
 theorem r_882_2 (z : Store) : (s_882 z) 649 = (v_738_1 z) := pR (k_881 z) (pR (k_880 z) (pR (n_864_880 z) (pR (n_860_864 z) (pR (k_859 z) (pR (k_858 z) (pR (k_857 z) (r_857_2 z)))))))
 #a r_882_2
 theorem r_882_3 (z : Store) : (s_882 z) 952 = (v_741_1 z) := pR (k_881 z) (pR (k_880 z) (pR (n_864_880 z) (pR (n_860_864 z) (pR (k_859 z) (pR (k_858 z) (pR (k_857 z) (r_857_3 z)))))))
 #a r_882_3
 def v_882_0 (z : Store) : Tensor := cross_dp_wred [(v_316_1 z), (v_319_1 z), (v_738_1 z), (v_741_1 z)]
 theorem g_882 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_461) (s_882 z) pmNode_461 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_461, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_882_1 z, r_882_0 z]
     exact (h_319_1 z z_).trans (h_316_1 z z_).symm
   · rw [r_882_2 z, r_882_0 z]
     exact (h_738_1 z z_).trans (h_316_1 z z_).symm
   · rw [r_882_3 z, r_882_0 z]
     exact (h_741_1 z z_).trans (h_316_1 z z_).symm
 #a g_882
 def s_883 (z : Store) : Store := storeSet (s_882 z) [(347, cross_dp_wred [((s_882 z) 43), ((s_882 z) 346), ((s_882 z) 649), ((s_882 z) 952)])]
 theorem t_882 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_461) (pmPeers pmNode_461) (s_882 z) pmNode_461 none = some (s_883 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_461) (s_882 z) pmNode_461 = _
   rw [wredStep, if_pos ⟨by decide, g_882 z z_⟩]
   rfl
 #a t_882
 theorem k_882 (z : Store) (tid : Tid) (h : tid ∉ [347]) : (s_883 z) tid = (s_882 z) tid := by
   unfold s_883
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_882
 theorem w_882_0 (z : Store) : (s_883 z) 347 = v_882_0 z := by
   unfold s_883
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_882_0, r_882_0 z, r_882_1 z, r_882_2 z, r_882_3 z] <;> rfl
 #a w_882_0
 theorem h_882_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_882_0 z).shape = [64] := by
   unfold v_882_0
   rw [tensorSum_shape]
   exact h_316_1 z z_
 #a h_882_0
 attribute [local irreducible] v_882_0
 attribute [local irreducible] s_883
 theorem r_883_0 (z : Store) : (s_883 z) 45 = (v_316_2 z) := pR (k_882 z) (pR (k_881 z) (pR (k_880 z) (pR (n_864_880 z) (pR (n_860_864 z) (pR (k_859 z) (pR (k_858 z) (r_858_0 z)))))))
 #a r_883_0
 theorem r_883_1 (z : Store) : (s_883 z) 348 = (v_319_2 z) := pR (k_882 z) (pR (k_881 z) (pR (k_880 z) (pR (n_864_880 z) (pR (n_860_864 z) (pR (k_859 z) (pR (k_858 z) (r_858_1 z)))))))
 #a r_883_1
 theorem r_883_2 (z : Store) : (s_883 z) 651 = (v_738_2 z) := pR (k_882 z) (pR (k_881 z) (pR (k_880 z) (pR (n_864_880 z) (pR (n_860_864 z) (pR (k_859 z) (pR (k_858 z) (r_858_2 z)))))))
 #a r_883_2
 theorem r_883_3 (z : Store) : (s_883 z) 954 = (v_741_2 z) := pR (k_882 z) (pR (k_881 z) (pR (k_880 z) (pR (n_864_880 z) (pR (n_860_864 z) (pR (k_859 z) (pR (k_858 z) (r_858_3 z)))))))
 #a r_883_3
 def v_883_0 (z : Store) : Tensor := cross_dp_wred [(v_316_2 z), (v_319_2 z), (v_738_2 z), (v_741_2 z)]
 theorem g_883 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_462) (s_883 z) pmNode_462 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_462, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_883_1 z, r_883_0 z]
     exact (h_319_2 z z_).trans (h_316_2 z z_).symm
   · rw [r_883_2 z, r_883_0 z]
     exact (h_738_2 z z_).trans (h_316_2 z z_).symm
   · rw [r_883_3 z, r_883_0 z]
     exact (h_741_2 z z_).trans (h_316_2 z z_).symm
 #a g_883
 def s_884 (z : Store) : Store := storeSet (s_883 z) [(349, cross_dp_wred [((s_883 z) 45), ((s_883 z) 348), ((s_883 z) 651), ((s_883 z) 954)])]
 theorem t_883 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_462) (pmPeers pmNode_462) (s_883 z) pmNode_462 none = some (s_884 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_462) (s_883 z) pmNode_462 = _
   rw [wredStep, if_pos ⟨by decide, g_883 z z_⟩]
   rfl
 #a t_883
 theorem k_883 (z : Store) (tid : Tid) (h : tid ∉ [349]) : (s_884 z) tid = (s_883 z) tid := by
   unfold s_884
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_883
 theorem w_883_0 (z : Store) : (s_884 z) 349 = v_883_0 z := by
   unfold s_884
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_883_0, r_883_0 z, r_883_1 z, r_883_2 z, r_883_3 z] <;> rfl
 #a w_883_0
 theorem h_883_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_883_0 z).shape = [64] := by
   unfold v_883_0
   rw [tensorSum_shape]
   exact h_316_2 z z_
 #a h_883_0
 attribute [local irreducible] v_883_0
 attribute [local irreducible] s_884
 theorem n_880_884 (z : Store) (tid : Tid) (h : tid ∉ ([343, 345, 347, 349] : List Tid)) : (s_884 z) tid = (s_880 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_880 z) (k_881 z)) (pF _ _ _ _ _ (k_882 z) (k_883 z)) tid h
 #a n_880_884
 theorem r_884_0 (z : Store) : (s_884 z) 19 = (v_417_0 z) := pR (n_880_884 z) (pR (n_872_880 z) (pR (n_868_872 z) (r_868_0 z)))
 #a r_884_0
 theorem r_884_1 (z : Store) : (s_884 z) 322 = (v_420_0 z) := pR (n_880_884 z) (pR (n_872_880 z) (pR (n_868_872 z) (r_868_1 z)))
 #a r_884_1
 theorem r_884_2 (z : Store) : (s_884 z) 625 = (v_839_0 z) := pR (n_880_884 z) (pR (n_872_880 z) (pR (n_868_872 z) (r_868_2 z)))
 #a r_884_2
 theorem r_884_3 (z : Store) : (s_884 z) 928 = (v_842_0 z) := pR (n_880_884 z) (pR (n_872_880 z) (pR (n_868_872 z) (r_868_3 z)))
 #a r_884_3
 def v_884_0 (z : Store) : Tensor := cross_dp_wred [(v_417_0 z), (v_420_0 z), (v_839_0 z), (v_842_0 z)]
 theorem g_884 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_683) (s_884 z) pmNode_683 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_683, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_884_1 z, r_884_0 z]
     exact (h_420_0 z z_).trans (h_417_0 z z_).symm
   · rw [r_884_2 z, r_884_0 z]
     exact (h_839_0 z z_).trans (h_417_0 z z_).symm
   · rw [r_884_3 z, r_884_0 z]
     exact (h_842_0 z z_).trans (h_417_0 z z_).symm
 #a g_884
 def s_885 (z : Store) : Store := storeSet (s_884 z) [(626, cross_dp_wred [((s_884 z) 19), ((s_884 z) 322), ((s_884 z) 625), ((s_884 z) 928)])]
 theorem t_884 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_683) (pmPeers pmNode_683) (s_884 z) pmNode_683 none = some (s_885 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_683) (s_884 z) pmNode_683 = _
   rw [wredStep, if_pos ⟨by decide, g_884 z z_⟩]
   rfl
 #a t_884
 theorem k_884 (z : Store) (tid : Tid) (h : tid ∉ [626]) : (s_885 z) tid = (s_884 z) tid := by
   unfold s_885
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_884
 theorem w_884_0 (z : Store) : (s_885 z) 626 = v_884_0 z := by
   unfold s_885
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_884_0, r_884_0 z, r_884_1 z, r_884_2 z, r_884_3 z] <;> rfl
 #a w_884_0
 theorem h_884_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_884_0 z).shape = [16, 64] := by
   unfold v_884_0
   rw [tensorSum_shape]
   exact h_417_0 z z_
 #a h_884_0
 attribute [local irreducible] v_884_0
 attribute [local irreducible] s_885
 theorem r_885_0 (z : Store) : (s_885 z) 21 = (v_405_1 z) := pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (pR (k_870 z) (pR (k_869 z) (r_869_0 z))))))
 #a r_885_0
 theorem r_885_1 (z : Store) : (s_885 z) 324 = (v_409_1 z) := pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (pR (k_870 z) (pR (k_869 z) (r_869_1 z))))))
 #a r_885_1
 theorem r_885_2 (z : Store) : (s_885 z) 627 = (v_827_1 z) := pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (pR (k_870 z) (pR (k_869 z) (r_869_2 z))))))
 #a r_885_2
 theorem r_885_3 (z : Store) : (s_885 z) 930 = (v_831_1 z) := pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (pR (k_870 z) (pR (k_869 z) (r_869_3 z))))))
 #a r_885_3
 def v_885_0 (z : Store) : Tensor := cross_dp_wred [(v_405_1 z), (v_409_1 z), (v_827_1 z), (v_831_1 z)]
 theorem g_885 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_684) (s_885 z) pmNode_684 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_684, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_885_1 z, r_885_0 z]
     exact (h_409_1 z z_).trans (h_405_1 z z_).symm
   · rw [r_885_2 z, r_885_0 z]
     exact (h_827_1 z z_).trans (h_405_1 z z_).symm
   · rw [r_885_3 z, r_885_0 z]
     exact (h_831_1 z z_).trans (h_405_1 z z_).symm
 #a g_885
 def s_886 (z : Store) : Store := storeSet (s_885 z) [(628, cross_dp_wred [((s_885 z) 21), ((s_885 z) 324), ((s_885 z) 627), ((s_885 z) 930)])]
 theorem t_885 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_684) (pmPeers pmNode_684) (s_885 z) pmNode_684 none = some (s_886 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_684) (s_885 z) pmNode_684 = _
   rw [wredStep, if_pos ⟨by decide, g_885 z z_⟩]
   rfl
 #a t_885
 theorem k_885 (z : Store) (tid : Tid) (h : tid ∉ [628]) : (s_886 z) tid = (s_885 z) tid := by
   unfold s_886
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_885
 theorem w_885_0 (z : Store) : (s_886 z) 628 = v_885_0 z := by
   unfold s_886
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_885_0, r_885_0 z, r_885_1 z, r_885_2 z, r_885_3 z] <;> rfl
 #a w_885_0
 theorem h_885_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_885_0 z).shape = [64] := by
   unfold v_885_0
   rw [tensorSum_shape]
   exact h_405_1 z z_
 #a h_885_0
 attribute [local irreducible] v_885_0
 attribute [local irreducible] s_886
 theorem r_886_0 (z : Store) : (s_886 z) 23 = (v_405_2 z) := pR (k_885 z) (pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (pR (k_870 z) (r_870_0 z))))))
 #a r_886_0
 theorem r_886_1 (z : Store) : (s_886 z) 326 = (v_409_2 z) := pR (k_885 z) (pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (pR (k_870 z) (r_870_1 z))))))
 #a r_886_1
 theorem r_886_2 (z : Store) : (s_886 z) 629 = (v_827_2 z) := pR (k_885 z) (pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (pR (k_870 z) (r_870_2 z))))))
 #a r_886_2
 theorem r_886_3 (z : Store) : (s_886 z) 932 = (v_831_2 z) := pR (k_885 z) (pR (k_884 z) (pR (n_880_884 z) (pR (n_872_880 z) (pR (k_871 z) (pR (k_870 z) (r_870_3 z))))))
 #a r_886_3
 def v_886_0 (z : Store) : Tensor := cross_dp_wred [(v_405_2 z), (v_409_2 z), (v_827_2 z), (v_831_2 z)]
 theorem g_886 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_685) (s_886 z) pmNode_685 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_685, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_886_1 z, r_886_0 z]
     exact (h_409_2 z z_).trans (h_405_2 z z_).symm
   · rw [r_886_2 z, r_886_0 z]
     exact (h_827_2 z z_).trans (h_405_2 z z_).symm
   · rw [r_886_3 z, r_886_0 z]
     exact (h_831_2 z z_).trans (h_405_2 z z_).symm
 #a g_886
 def s_887 (z : Store) : Store := storeSet (s_886 z) [(630, cross_dp_wred [((s_886 z) 23), ((s_886 z) 326), ((s_886 z) 629), ((s_886 z) 932)])]
 theorem t_886 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_685) (pmPeers pmNode_685) (s_886 z) pmNode_685 none = some (s_887 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_685) (s_886 z) pmNode_685 = _
   rw [wredStep, if_pos ⟨by decide, g_886 z z_⟩]
   rfl
 #a t_886
 theorem k_886 (z : Store) (tid : Tid) (h : tid ∉ [630]) : (s_887 z) tid = (s_886 z) tid := by
   unfold s_887
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_886
 theorem w_886_0 (z : Store) : (s_887 z) 630 = v_886_0 z := by
   unfold s_887
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_886_0, r_886_0 z, r_886_1 z, r_886_2 z, r_886_3 z] <;> rfl
 #a w_886_0
 theorem h_886_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_886_0 z).shape = [64] := by
   unfold v_886_0
   rw [tensorSum_shape]
   exact h_405_2 z z_
 #a h_886_0
 attribute [local irreducible] v_886_0
 attribute [local irreducible] s_887
 record_prefix_opacity v_880_0 s_881 v_881_0 s_882 v_882_0 s_883 v_883_0 s_884 v_884_0 s_885 v_885_0 s_886 v_886_0 s_887

 end
 end TrainVerify.Denote.RuntimeWorld
