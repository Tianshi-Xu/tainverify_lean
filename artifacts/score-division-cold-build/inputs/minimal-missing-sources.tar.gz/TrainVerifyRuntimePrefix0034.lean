import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0033
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_261_0 (z : Store) : (s_261 z) 237 = (v_260_0 z) := w_260_0 z
 #a r_261_0
 theorem r_261_1 (z : Store) : (s_261 z) 233 = (v_157_0 z) := pR (k_260 z) (pR (n_256_260 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (k_159 z) (r_159_0 z)))))
 #a r_261_1
 theorem r_261_2 (z : Store) : (s_261 z) 79 = (v_158_0 z) := pR (k_260 z) (pR (n_256_260 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (k_159 z) (r_159_1 z)))))
 #a r_261_2
 def v_261_0 (z : Store) : Tensor := (batchedMatmulBwd (v_260_0 z) (v_157_0 z) (v_158_0 z)).1
 def v_261_1 (z : Store) : Tensor := (batchedMatmulBwd (v_260_0 z) (v_157_0 z) (v_158_0 z)).2
 def s_262 (z : Store) : Store := storeSet (s_261 z) [(235, (batchedMatmulBwd ((s_261 z) 237) ((s_261 z) 233) ((s_261 z) 79)).1), (238, (batchedMatmulBwd ((s_261 z) 237) ((s_261 z) 233) ((s_261 z) 79)).2)]
 theorem t_261 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_131) (pmPeers pmNode_131) (s_261 z) pmNode_131 none = some (s_262 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_261
 theorem k_261 (z : Store) (tid : Tid) (h : tid ∉ [235, 238]) : (s_262 z) tid = (s_261 z) tid := by
   unfold s_262
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_261
 theorem w_261_0 (z : Store) : (s_262 z) 235 = v_261_0 z := by
   unfold s_262
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_261_0, r_261_0 z, r_261_1 z, r_261_2 z] <;> rfl
 #a w_261_0
 theorem h_261_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_261_0 z).shape = [1, 4, 8, 16] := by
   unfold v_261_0
   change (batchedMatmul (v_260_0 z) (transpose2d (v_158_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_260_0 z z_, h_158_0 z z_]
   rfl
 #a h_261_0
 attribute [local irreducible] v_261_0
 theorem w_261_1 (z : Store) : (s_262 z) 238 = v_261_1 z := by
   unfold s_262
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_261_1, r_261_0 z, r_261_1 z, r_261_2 z] <;> rfl
 #a w_261_1
 theorem h_261_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_261_1 z).shape = [1, 4, 16, 16] := by
   unfold v_261_1
   change (batchedMatmul (transpose2d (v_157_0 z)) (v_260_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_260_0 z z_, h_157_0 z z_]
   rfl
 #a h_261_1
 attribute [local irreducible] v_261_1
 attribute [local irreducible] s_262
 theorem r_262_0 (z : Store) : (s_262 z) 241 = (v_257_0 z) := pR (k_261 z) (pR (k_260 z) (r_260_0 z))
 #a r_262_0
 theorem r_262_1 (z : Store) : (s_262 z) 544 = (v_259_0 z) := pR (k_261 z) (pR (k_260 z) (r_260_1 z))
 #a r_262_1
 def v_262_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_257_0 z), (v_259_0 z)]
 theorem g_262 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_366) (s_262 z) pmNode_366 1 2 541 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_366, r_262_0 z, r_262_1 z, h_257_0 z z_, h_259_0 z z_]
 #a g_262
 def s_263 (z : Store) : Store := pL [0, 1] (s_262 z) pmNode_366 1 2
 theorem t_262 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_366) (pmPeers pmNode_366) (s_262 z) pmNode_366 none = some (s_263 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_366) (s_262 z) pmNode_366).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 541 (by decide) (g_262 z z_)]
   rfl
 #a t_262
 theorem k_262 (z : Store) (tid : Tid) (h : tid ∉ [541]) : (s_263 z) tid = (s_262 z) tid := by
   unfold s_263
   dsimp only [pL, pmNode_366, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_262
 theorem w_262_0 (z : Store) : (s_263 z) 541 = v_262_0 z := by
   unfold s_263
   dsimp only [pL, pmNode_366, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_262_0, r_262_0 z, r_262_1 z] <;> rfl
 #a w_262_0
 theorem h_262_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_262_0 z).shape = [1, 4, 8, 16] := by
   unfold v_262_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_257_0 z z_]
 #a h_262_0
 attribute [local irreducible] v_262_0
 attribute [local irreducible] s_263
 theorem r_263_0 (z : Store) : (s_263 z) 541 = (v_262_0 z) := w_262_0 z
 #a r_263_0
 theorem r_263_1 (z : Store) : (s_263 z) 536 = (v_161_0 z) := pR (k_262 z) (pR (k_261 z) (pR (k_260 z) (pR (n_256_260 z) (pR (n_192_256 z) (pR (n_176_192 z) (pR (n_168_176 z) (pR (n_164_168 z) (pR (k_163 z) (r_163_0 z)))))))))
 #a r_263_1
 theorem r_263_2 (z : Store) : (s_263 z) 382 = (v_162_0 z) := pR (k_262 z) (pR (k_261 z) (pR (k_260 z) (pR (n_256_260 z) (pR (n_192_256 z) (pR (n_176_192 z) (pR (n_168_176 z) (pR (n_164_168 z) (pR (k_163 z) (r_163_1 z)))))))))
 #a r_263_2
 def v_263_0 (z : Store) : Tensor := (batchedMatmulBwd (v_262_0 z) (v_161_0 z) (v_162_0 z)).1
 def v_263_1 (z : Store) : Tensor := (batchedMatmulBwd (v_262_0 z) (v_161_0 z) (v_162_0 z)).2
 def s_264 (z : Store) : Store := storeSet (s_263 z) [(538, (batchedMatmulBwd ((s_263 z) 541) ((s_263 z) 536) ((s_263 z) 382)).1), (540, (batchedMatmulBwd ((s_263 z) 541) ((s_263 z) 536) ((s_263 z) 382)).2)]
 theorem t_263 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_367) (pmPeers pmNode_367) (s_263 z) pmNode_367 none = some (s_264 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_263
 theorem k_263 (z : Store) (tid : Tid) (h : tid ∉ [538, 540]) : (s_264 z) tid = (s_263 z) tid := by
   unfold s_264
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_263
 theorem w_263_0 (z : Store) : (s_264 z) 538 = v_263_0 z := by
   unfold s_264
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_263_0, r_263_0 z, r_263_1 z, r_263_2 z] <;> rfl
 #a w_263_0
 theorem h_263_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_263_0 z).shape = [1, 4, 8, 16] := by
   unfold v_263_0
   change (batchedMatmul (v_262_0 z) (transpose2d (v_162_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_262_0 z z_, h_162_0 z z_]
   rfl
 #a h_263_0
 attribute [local irreducible] v_263_0
 theorem w_263_1 (z : Store) : (s_264 z) 540 = v_263_1 z := by
   unfold s_264
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_263_1, r_263_0 z, r_263_1 z, r_263_2 z] <;> rfl
 #a w_263_1
 theorem h_263_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_263_1 z).shape = [1, 4, 16, 16] := by
   unfold v_263_1
   change (batchedMatmul (transpose2d (v_161_0 z)) (v_262_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_262_0 z z_, h_161_0 z z_]
   rfl
 #a h_263_1
 attribute [local irreducible] v_263_1
 attribute [local irreducible] s_264
 theorem r_264_0 (z : Store) : (s_264 z) 238 = (v_261_1 z) := pR (k_263 z) (pR (k_262 z) (w_261_1 z))
 #a r_264_0
 theorem r_264_1 (z : Store) : (s_264 z) 540 = (v_263_1 z) := w_263_1 z
 #a r_264_1
 def v_264_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 0 [(v_261_1 z), (v_263_1 z)]
 def s_265 (z : Store) : Store := storeSet (s_264 z) [(221, reduceScatterPrimDimN 2 2 0 [((s_264 z) 238), ((s_264 z) 540)])]
 theorem t_264 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_132) (pmPeers pmNode_132) (s_264 z) pmNode_132 none = some (s_265 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_264 z) pmNode_132 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_264
 theorem k_264 (z : Store) (tid : Tid) (h : tid ∉ [221]) : (s_265 z) tid = (s_264 z) tid := by
   unfold s_265
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_264
 theorem w_264_0 (z : Store) : (s_265 z) 221 = v_264_0 z := by
   unfold s_265
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_264_0, r_264_0 z, r_264_1 z] <;> rfl
 #a w_264_0
 theorem h_264_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_264_0 z).shape = [1, 4, 8, 16] := by
   unfold v_264_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 0 _ [1, 4, 16, 16]
   · rw [allReducePrim_shape _ _ _ (v_261_1 z) rfl]
     exact h_261_1 z z_
   · decide
 #a h_264_0
 attribute [local irreducible] v_264_0
 attribute [local irreducible] s_265
 theorem n_260_264 (z : Store) (tid : Tid) (h : tid ∉ ([237, 235, 238, 541, 538, 540] : List Tid)) : (s_264 z) tid = (s_260 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_260 z) (k_261 z)) (pF _ _ _ _ _ (k_262 z) (k_263 z)) tid h
 #a n_260_264
 theorem n_256_264 (z : Store) (tid : Tid) (h : tid ∉ ([242, 241, 545, 544, 237, 235, 238, 541, 538, 540] : List Tid)) : (s_264 z) tid = (s_256 z) tid := by
   exact pF _ _ _ _ _ (n_256_260 z) (n_260_264 z) tid h
 #a n_256_264
 theorem r_265_0 (z : Store) : (s_265 z) 235 = (v_261_0 z) := pR (k_264 z) (pR (k_263 z) (pR (k_262 z) (w_261_0 z)))
 #a r_265_0
 theorem r_265_1 (z : Store) : (s_265 z) 232 = (v_156_0 z) := pR (k_264 z) (pR (n_256_264 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (k_159 z) (pR (k_158 z) (pR (k_157 z) (r_157_0 z)))))))
 #a r_265_1
 def v_265_0 (z : Store) : Tensor := bw_softmax (v_261_0 z) (v_156_0 z)
 def s_266 (z : Store) : Store := storeSet (s_265 z) [(234, bw_softmax ((s_265 z) 235) ((s_265 z) 232))]
 theorem t_265 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_133) (pmPeers pmNode_133) (s_265 z) pmNode_133 none = some (s_266 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_265
 theorem k_265 (z : Store) (tid : Tid) (h : tid ∉ [234]) : (s_266 z) tid = (s_265 z) tid := by
   unfold s_266
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_265
 theorem w_265_0 (z : Store) : (s_266 z) 234 = v_265_0 z := by
   unfold s_266
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_265_0, r_265_0 z, r_265_1 z] <;> rfl
 #a w_265_0
 theorem h_265_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_265_0 z).shape = [1, 4, 8, 16] := by
   unfold v_265_0
   unfold bw_softmax softmaxBwd softmaxBwdFromOutput softmax
   rw [h_156_0 z z_]
   rfl
 #a h_265_0
 attribute [local irreducible] v_265_0
 attribute [local irreducible] s_266
 theorem r_266_0 (z : Store) : (s_266 z) 238 = (v_261_1 z) := pR (k_265 z) (pR (k_264 z) (r_264_0 z))
 #a r_266_0
 theorem r_266_1 (z : Store) : (s_266 z) 540 = (v_263_1 z) := pR (k_265 z) (pR (k_264 z) (r_264_1 z))
 #a r_266_1
 def v_266_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 1 [(v_261_1 z), (v_263_1 z)]
 def s_267 (z : Store) : Store := storeSet (s_266 z) [(524, reduceScatterPrimDimN 2 2 1 [((s_266 z) 238), ((s_266 z) 540)])]
 theorem t_266 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_368) (pmPeers pmNode_368) (s_266 z) pmNode_368 none = some (s_267 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_266 z) pmNode_368 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_266
 theorem k_266 (z : Store) (tid : Tid) (h : tid ∉ [524]) : (s_267 z) tid = (s_266 z) tid := by
   unfold s_267
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_266
 theorem w_266_0 (z : Store) : (s_267 z) 524 = v_266_0 z := by
   unfold s_267
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_266_0, r_266_0 z, r_266_1 z] <;> rfl
 #a w_266_0
 theorem h_266_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_266_0 z).shape = [1, 4, 8, 16] := by
   unfold v_266_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 1 _ [1, 4, 16, 16]
   · rw [allReducePrim_shape _ _ _ (v_261_1 z) rfl]
     exact h_261_1 z z_
   · decide
 #a h_266_0
 attribute [local irreducible] v_266_0
 attribute [local irreducible] s_267
 theorem r_267_0 (z : Store) : (s_267 z) 538 = (v_263_0 z) := pR (k_266 z) (pR (k_265 z) (pR (k_264 z) (w_263_0 z)))
 #a r_267_0
 theorem r_267_1 (z : Store) : (s_267 z) 535 = (v_160_0 z) := pR (k_266 z) (pR (k_265 z) (pR (k_264 z) (pR (n_256_264 z) (pR (n_192_256 z) (pR (n_176_192 z) (pR (n_168_176 z) (pR (n_164_168 z) (pR (k_163 z) (pR (k_162 z) (pR (k_161 z) (r_161_0 z)))))))))))
 #a r_267_1
 def v_267_0 (z : Store) : Tensor := bw_softmax (v_263_0 z) (v_160_0 z)
 def s_268 (z : Store) : Store := storeSet (s_267 z) [(537, bw_softmax ((s_267 z) 538) ((s_267 z) 535))]
 theorem t_267 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_369) (pmPeers pmNode_369) (s_267 z) pmNode_369 none = some (s_268 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_267
 theorem k_267 (z : Store) (tid : Tid) (h : tid ∉ [537]) : (s_268 z) tid = (s_267 z) tid := by
   unfold s_268
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_267
 theorem w_267_0 (z : Store) : (s_268 z) 537 = v_267_0 z := by
   unfold s_268
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_267_0, r_267_0 z, r_267_1 z] <;> rfl
 #a w_267_0
 theorem h_267_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_267_0 z).shape = [1, 4, 8, 16] := by
   unfold v_267_0
   unfold bw_softmax softmaxBwd softmaxBwdFromOutput softmax
   rw [h_160_0 z z_]
   rfl
 #a h_267_0
 attribute [local irreducible] v_267_0
 attribute [local irreducible] s_268
 theorem r_268_0 (z : Store) : (s_268 z) 234 = (v_265_0 z) := pR (k_267 z) (pR (k_266 z) (w_265_0 z))
 #a r_268_0
 theorem r_268_1 (z : Store) : (s_268 z) 537 = (v_267_0 z) := w_267_0 z
 #a r_268_1
 def v_268_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 3 [(v_265_0 z), (v_267_0 z)]
 theorem g_268 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_134) (s_268 z) pmNode_134 2 3 231 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_134, r_268_0 z, r_268_1 z, h_265_0 z z_, h_267_0 z z_]
 #a g_268
 def s_269 (z : Store) : Store := pL [0, 1] (s_268 z) pmNode_134 2 3
 theorem t_268 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_134) (pmPeers pmNode_134) (s_268 z) pmNode_134 none = some (s_269 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_134) (s_268 z) pmNode_134).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 3 231 (by decide) (g_268 z z_)]
   rfl
 #a t_268
 theorem k_268 (z : Store) (tid : Tid) (h : tid ∉ [231]) : (s_269 z) tid = (s_268 z) tid := by
   unfold s_269
   dsimp only [pL, pmNode_134, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_268
 theorem w_268_0 (z : Store) : (s_269 z) 231 = v_268_0 z := by
   unfold s_269
   dsimp only [pL, pmNode_134, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_268_0, r_268_0 z, r_268_1 z] <;> rfl
 #a w_268_0
 theorem h_268_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_268_0 z).shape = [1, 4, 16, 8] := by
   unfold v_268_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_265_0 z z_]
 #a h_268_0
 attribute [local irreducible] v_268_0
 attribute [local irreducible] s_269
 theorem n_264_268 (z : Store) (tid : Tid) (h : tid ∉ ([221, 234, 524, 537] : List Tid)) : (s_268 z) tid = (s_264 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_264 z) (k_265 z)) (pF _ _ _ _ _ (k_266 z) (k_267 z)) tid h
 #a n_264_268
 record_prefix_opacity v_261_0 v_261_1 s_262 v_262_0 s_263 v_263_0 v_263_1 s_264 v_264_0 s_265 v_265_0 s_266 v_266_0 s_267 v_267_0 s_268 v_268_0 s_269

 end
 end TrainVerify.Denote.RuntimeWorld
