import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0056
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem n_436_440 (z : Store) (tid : Tid) (h : tid ∉ ([704, 705, 708, 891, 893, 709] : List Tid)) : (s_440 z) tid = (s_436 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_436 z) (k_437 z)) (pF _ _ _ _ _ (k_438 z) (k_439 z)) tid h
 #a n_436_440
 theorem r_440_0 (z : Store) : (s_440 z) 889 = (v_432_0 z) := pR (n_436_440 z) (r_436_0 z)
 #a r_440_0
 theorem r_440_1 (z : Store) : (s_440 z) 1192 = (v_435_0 z) := pR (n_436_440 z) (r_436_1 z)
 #a r_440_1
 def v_440_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_432_0 z), (v_435_0 z)]
 theorem g_440 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_715) (s_440 z) pmNode_715 2 1 1007 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_715, r_440_0 z, r_440_1 z, h_432_0 z z_, h_435_0 z z_]
 #a g_440
 def s_441 (z : Store) : Store := pL [2, 3] (s_440 z) pmNode_715 2 1
 theorem t_440 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_715) (pmPeers pmNode_715) (s_440 z) pmNode_715 none = some (s_441 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_715) (s_440 z) pmNode_715).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1007 (by decide) (g_440 z z_)]
   rfl
 #a t_440
 theorem k_440 (z : Store) (tid : Tid) (h : tid ∉ [1007]) : (s_441 z) tid = (s_440 z) tid := by
   unfold s_441
   dsimp only [pL, pmNode_715, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_440
 theorem w_440_0 (z : Store) : (s_441 z) 1007 = v_440_0 z := by
   unfold s_441
   dsimp only [pL, pmNode_715, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_440_0, r_440_0 z, r_440_1 z] <;> rfl
 #a w_440_0
 theorem h_440_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_440_0 z).shape = [1, 8, 64] := by
   unfold v_440_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_432_0 z z_]
 #a h_440_0
 attribute [local irreducible] v_440_0
 attribute [local irreducible] s_441
 theorem n_432_440 (z : Store) (tid : Tid) (h : tid ∉ ([889, 769, 1003, 1004, 1192, 1072, 704, 705, 708, 891, 893, 709] : List Tid)) : (s_440 z) tid = (s_432 z) tid := by
   exact pF _ _ _ _ _ (n_432_436 z) (n_436_440 z) tid h
 #a n_432_440
 theorem r_441_0 (z : Store) : (s_441 z) 1007 = (v_440_0 z) := w_440_0 z
 #a r_441_0
 theorem r_441_1 (z : Store) : (s_441 z) 910 = (z 910) := pR (k_440 z) (pR (n_432_440 z) (pR (n_416_432 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_57 z))))))
 #a r_441_1
 theorem r_441_2 (z : Store) : (s_441 z) 911 = (z 911) := pR (k_440 z) (pR (n_432_440 z) (pR (n_416_432 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_58 z))))))
 #a r_441_2
 def v_441_0 (z : Store) : Tensor := fw_layernorm (v_440_0 z) (z 910) (z 911)
 def s_442 (z : Store) : Store := storeSet (s_441 z) [(1008, fw_layernorm ((s_441 z) 1007) ((s_441 z) 910) ((s_441 z) 911))]
 theorem t_441 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_716) (pmPeers pmNode_716) (s_441 z) pmNode_716 none = some (s_442 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_441
 theorem k_441 (z : Store) (tid : Tid) (h : tid ∉ [1008]) : (s_442 z) tid = (s_441 z) tid := by
   unfold s_442
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_441
 theorem w_441_0 (z : Store) : (s_442 z) 1008 = v_441_0 z := by
   unfold s_442
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_441_0, r_441_0 z, r_441_1 z, r_441_2 z] <;> rfl
 #a w_441_0
 theorem h_441_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_441_0 z).shape = [1, 8, 64] := by
   unfold v_441_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_440_0 z z_
 #a h_441_0
 attribute [local irreducible] v_441_0
 attribute [local irreducible] s_442
 theorem r_442_0 (z : Store) : (s_442 z) 1008 = (v_441_0 z) := w_441_0 z
 #a r_442_0
 def v_442_0 (z : Store) : Tensor := (v_441_0 z)
 def v_442_1 (z : Store) : Tensor := (v_441_0 z)
 def v_442_2 (z : Store) : Tensor := (v_441_0 z)
 def s_443 (z : Store) : Store := storeSet (s_442 z) [(1011, ((s_442 z) 1008)), (1194, ((s_442 z) 1008)), (1196, ((s_442 z) 1008))]
 theorem t_442 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_717) (pmPeers pmNode_717) (s_442 z) pmNode_717 none = some (s_443 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_442
 theorem k_442 (z : Store) (tid : Tid) (h : tid ∉ [1011, 1194, 1196]) : (s_443 z) tid = (s_442 z) tid := by
   unfold s_443
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_442
 theorem w_442_0 (z : Store) : (s_443 z) 1011 = v_442_0 z := by
   unfold s_443
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_442_0, r_442_0 z] <;> rfl
 #a w_442_0
 theorem h_442_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_442_0 z).shape = [1, 8, 64] := by
   unfold v_442_0
   exact h_441_0 z z_
 #a h_442_0
 attribute [local irreducible] v_442_0
 theorem w_442_1 (z : Store) : (s_443 z) 1194 = v_442_1 z := by
   unfold s_443
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_442_1, r_442_0 z] <;> rfl
 #a w_442_1
 theorem h_442_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_442_1 z).shape = [1, 8, 64] := by
   unfold v_442_1
   exact h_441_0 z z_
 #a h_442_1
 attribute [local irreducible] v_442_1
 theorem w_442_2 (z : Store) : (s_443 z) 1196 = v_442_2 z := by
   unfold s_443
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_442_2, r_442_0 z] <;> rfl
 #a w_442_2
 theorem h_442_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_442_2 z).shape = [1, 8, 64] := by
   unfold v_442_2
   exact h_441_0 z z_
 #a h_442_2
 attribute [local irreducible] v_442_2
 attribute [local irreducible] s_443
 theorem r_443_0 (z : Store) : (s_443 z) 891 = (v_438_1 z) := pR (k_442 z) (pR (k_441 z) (pR (k_440 z) (pR (k_439 z) (w_438_1 z))))
 #a r_443_0
 theorem r_443_1 (z : Store) : (s_443 z) 1194 = (v_442_1 z) := w_442_1 z
 #a r_443_1
 def v_443_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_438_1 z), (v_442_1 z)]
 def s_444 (z : Store) : Store := storeSet (s_443 z) [(692, allGatherPrimDimN 1 2 0 [((s_443 z) 891), ((s_443 z) 1194)])]
 theorem t_443 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_483) (pmPeers pmNode_483) (s_443 z) pmNode_483 none = some (s_444 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_443 z) pmNode_483 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_443
 theorem k_443 (z : Store) (tid : Tid) (h : tid ∉ [692]) : (s_444 z) tid = (s_443 z) tid := by
   unfold s_444
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_443
 theorem w_443_0 (z : Store) : (s_444 z) 692 = v_443_0 z := by
   unfold s_444
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_443_0, r_443_0 z, r_443_1 z] <;> rfl
 #a w_443_0
 theorem h_443_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_443_0 z).shape = [1, 16, 64] := by
   unfold v_443_0
   exact allGatherPrimDimN_shape 1 2 [(v_438_1 z), (v_442_1 z)] [1, 8, 64] (h_438_1 z z_)
 #a h_443_0
 attribute [local irreducible] v_443_0
 attribute [local irreducible] s_444
 theorem n_440_444 (z : Store) (tid : Tid) (h : tid ∉ ([1007, 1008, 1011, 1194, 1196, 692] : List Tid)) : (s_444 z) tid = (s_440 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_440 z) (k_441 z)) (pF _ _ _ _ _ (k_442 z) (k_443 z)) tid h
 #a n_440_444
 theorem r_444_0 (z : Store) : (s_444 z) 692 = (v_443_0 z) := w_443_0 z
 #a r_444_0
 theorem r_444_1 (z : Store) : (s_444 z) 633 = (z 633) := pR (n_440_444 z) (pR (n_432_440 z) (pR (n_416_432 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_59 z))))))
 #a r_444_1
 def v_444_0 (z : Store) : Tensor := fw_linear (v_443_0 z) (z 633)
 def s_445 (z : Store) : Store := storeSet (s_444 z) [(712, fw_linear ((s_444 z) 692) ((s_444 z) 633))]
 theorem t_444 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_484) (pmPeers pmNode_484) (s_444 z) pmNode_484 none = some (s_445 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_444
 theorem k_444 (z : Store) (tid : Tid) (h : tid ∉ [712]) : (s_445 z) tid = (s_444 z) tid := by
   unfold s_445
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_444
 theorem w_444_0 (z : Store) : (s_445 z) 712 = v_444_0 z := by
   unfold s_445
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_444_0, r_444_0 z, r_444_1 z] <;> rfl
 #a w_444_0
 theorem h_444_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_444_0 z).shape = [1, 16, 32] := by
   unfold v_444_0
   exact fw_linear_3d_shape 1 16 64 32 (v_443_0 z) (z 633) (h_443_0 z z_) (i_59 z z_)
 #a h_444_0
 attribute [local irreducible] v_444_0
 attribute [local irreducible] s_445
 theorem r_445_0 (z : Store) : (s_445 z) 893 = (v_438_2 z) := pR (k_444 z) (pR (n_440_444 z) (pR (k_439 z) (w_438_2 z)))
 #a r_445_0
 theorem r_445_1 (z : Store) : (s_445 z) 1196 = (v_442_2 z) := pR (k_444 z) (pR (k_443 z) (w_442_2 z))
 #a r_445_1
 def v_445_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_438_2 z), (v_442_2 z)]
 def s_446 (z : Store) : Store := storeSet (s_445 z) [(693, allGatherPrimDimN 1 2 0 [((s_445 z) 893), ((s_445 z) 1196)])]
 theorem t_445 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_485) (pmPeers pmNode_485) (s_445 z) pmNode_485 none = some (s_446 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_445 z) pmNode_485 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_445
 theorem k_445 (z : Store) (tid : Tid) (h : tid ∉ [693]) : (s_446 z) tid = (s_445 z) tid := by
   unfold s_446
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_445
 theorem w_445_0 (z : Store) : (s_446 z) 693 = v_445_0 z := by
   unfold s_446
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_445_0, r_445_0 z, r_445_1 z] <;> rfl
 #a w_445_0
 theorem h_445_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_445_0 z).shape = [1, 16, 64] := by
   unfold v_445_0
   exact allGatherPrimDimN_shape 1 2 [(v_438_2 z), (v_442_2 z)] [1, 8, 64] (h_438_2 z z_)
 #a h_445_0
 attribute [local irreducible] v_445_0
 attribute [local irreducible] s_446
 theorem r_446_0 (z : Store) : (s_446 z) 693 = (v_445_0 z) := w_445_0 z
 #a r_446_0
 theorem r_446_1 (z : Store) : (s_446 z) 636 = (z 636) := pR (k_445 z) (pR (k_444 z) (pR (n_440_444 z) (pR (n_432_440 z) (pR (n_416_432 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_60 z))))))))
 #a r_446_1
 def v_446_0 (z : Store) : Tensor := fw_linear (v_445_0 z) (z 636)
 def s_447 (z : Store) : Store := storeSet (s_446 z) [(715, fw_linear ((s_446 z) 693) ((s_446 z) 636))]
 theorem t_446 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_486) (pmPeers pmNode_486) (s_446 z) pmNode_486 none = some (s_447 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_446
 theorem k_446 (z : Store) (tid : Tid) (h : tid ∉ [715]) : (s_447 z) tid = (s_446 z) tid := by
   unfold s_447
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_446
 theorem w_446_0 (z : Store) : (s_447 z) 715 = v_446_0 z := by
   unfold s_447
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_446_0, r_446_0 z, r_446_1 z] <;> rfl
 #a w_446_0
 theorem h_446_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_446_0 z).shape = [1, 16, 32] := by
   unfold v_446_0
   exact fw_linear_3d_shape 1 16 64 32 (v_445_0 z) (z 636) (h_445_0 z z_) (i_60 z z_)
 #a h_446_0
 attribute [local irreducible] v_446_0
 attribute [local irreducible] s_447
 theorem r_447_0 (z : Store) : (s_447 z) 709 = (v_439_0 z) := pR (k_446 z) (pR (k_445 z) (pR (k_444 z) (pR (n_440_444 z) (w_439_0 z))))
 #a r_447_0
 def v_447_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_439_0 z)
 def s_448 (z : Store) : Store := storeSet (s_447 z) [(718, fw_view [1, 8, 4, 16] ((s_447 z) 709))]
 theorem t_447 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_487) (pmPeers pmNode_487) (s_447 z) pmNode_487 none = some (s_448 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_447
 theorem k_447 (z : Store) (tid : Tid) (h : tid ∉ [718]) : (s_448 z) tid = (s_447 z) tid := by
   unfold s_448
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_447
 theorem w_447_0 (z : Store) : (s_448 z) 718 = v_447_0 z := by
   unfold s_448
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_447_0, r_447_0 z] <;> rfl
 #a w_447_0
 theorem h_447_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_447_0 z).shape = [1, 8, 4, 16] := by
   unfold v_447_0
   rfl
 #a h_447_0
 attribute [local irreducible] v_447_0
 attribute [local irreducible] s_448
 theorem n_444_448 (z : Store) (tid : Tid) (h : tid ∉ ([712, 693, 715, 718] : List Tid)) : (s_448 z) tid = (s_444 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_444 z) (k_445 z)) (pF _ _ _ _ _ (k_446 z) (k_447 z)) tid h
 #a n_444_448
 theorem n_440_448 (z : Store) (tid : Tid) (h : tid ∉ ([1007, 1008, 1011, 1194, 1196, 692, 712, 693, 715, 718] : List Tid)) : (s_448 z) tid = (s_440 z) tid := by
   exact pF _ _ _ _ _ (n_440_444 z) (n_444_448 z) tid h
 #a n_440_448
 theorem n_432_448 (z : Store) (tid : Tid) (h : tid ∉ ([889, 769, 1003, 1004, 1192, 1072, 704, 705, 708, 891, 893, 709, 1007, 1008, 1011, 1194, 1196, 692, 712, 693, 715, 718] : List Tid)) : (s_448 z) tid = (s_432 z) tid := by
   exact pF _ _ _ _ _ (n_432_440 z) (n_440_448 z) tid h
 #a n_432_448
 theorem n_416_448 (z : Store) (tid : Tid) (h : tid ∉ ([93, 19, 17, 396, 322, 320, 681, 682, 695, 697, 698, 984, 985, 998, 1000, 1001, 700, 701, 889, 769, 1003, 1004, 1192, 1072, 704, 705, 708, 891, 893, 709, 1007, 1008, 1011, 1194, 1196, 692, 712, 693, 715, 718] : List Tid)) : (s_448 z) tid = (s_416 z) tid := by
   exact pF _ _ _ _ _ (n_416_432 z) (n_432_448 z) tid h
 #a n_416_448
 theorem n_384_448 (z : Store) (tid : Tid) (h : tid ∉ ([414, 425, 119, 107, 116, 422, 411, 419, 113, 105, 111, 31, 416, 408, 413, 334, 288, 108, 28, 591, 410, 331, 286, 104, 25, 101, 100, 21, 23, 589, 407, 328, 404, 403, 324, 326, 284, 97, 90, 96, 587, 400, 393, 399, 93, 19, 17, 396, 322, 320, 681, 682, 695, 697, 698, 984, 985, 998, 1000, 1001, 700, 701, 889, 769, 1003, 1004, 1192, 1072, 704, 705, 708, 891, 893, 709, 1007, 1008, 1011, 1194, 1196, 692, 712, 693, 715, 718] : List Tid)) : (s_448 z) tid = (s_384 z) tid := by
   exact pF _ _ _ _ _ (n_384_416 z) (n_416_448 z) tid h
 #a n_384_448
 record_prefix_opacity v_440_0 s_441 v_441_0 s_442 v_442_0 v_442_1 v_442_2 s_443 v_443_0 s_444 v_444_0 s_445 v_445_0 s_446 v_446_0 s_447 v_447_0 s_448

 end
 end TrainVerify.Denote.RuntimeWorld
