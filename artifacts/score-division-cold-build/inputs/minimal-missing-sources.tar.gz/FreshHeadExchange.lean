import FreshProjectionView
-- UNCOMPILED: parent owns imports, predecessors, frame, aggregate costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierHeadExchangeRead_pm_202 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 202 = AllToAllSourceFaithful.tensor 2 0 1 2 (([199, 502] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 126) (pmInputRequests.drop 127) pmNode_63 0 [0, 1] [199, 502] 202 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 126 ++ pmInputRequests.drop 126 := (List.take_append_drop 126 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([199, 502] : List Tid), ∀ row ∈ pmInputRequests.drop 126, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_202
theorem frontierHeadExchangeRead_pm_505 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 505 = AllToAllSourceFaithful.tensor 2 1 1 2 (([199, 502] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 130) (pmInputRequests.drop 131) pmNode_299 1 [0, 1] [199, 502] 505 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 130 ++ pmInputRequests.drop 130 := (List.take_append_drop 130 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([199, 502] : List Tid), ∀ row ∈ pmInputRequests.drop 130, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_505
theorem frontierHeadExchangeUnitFacts_1297_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1297).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 202, q 505], y.shape = [1, 16, 2, 16]) ∧
    chunkPrimDimN 0 2 0 (t 1297) = allGatherPrimDimN 2 2 0 [q 202, q 505] := by
  have predecessor := frontierProjectionViewUnitFacts_1297_0_slot0 s p t q hs hp hvalues
  have outputs : [q 202, q 505] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 1 2 [q 199, q 502]) := by
    change [q 202, q 505] = [AllToAllSourceFaithful.tensor 2 0 1 2 [q 199, q 502], AllToAllSourceFaithful.tensor 2 1 1 2 [q 199, q 502]]
    exact congrArg₂ List.cons (frontierHeadExchangeRead_pm_202 p q hp) (congrArg₂ List.cons (frontierHeadExchangeRead_pm_505 p q hp) (rfl))
  exact SourceRank4InnerExchange.axis1_output_facts 2 0 2 1 8 2 16 (t 1297) [q 199, q 502] [q 202, q 505]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierHeadExchangeUnitFacts_1297_0_slot0
theorem frontierHeadExchangeRead_pm_210 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 210 = AllToAllSourceFaithful.tensor 2 0 1 3 (([207, 510] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 134) (pmInputRequests.drop 135) pmNode_67 0 [0, 1] [207, 510] 210 1 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 134 ++ pmInputRequests.drop 134 := (List.take_append_drop 134 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([207, 510] : List Tid), ∀ row ∈ pmInputRequests.drop 134, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_210
theorem frontierHeadExchangeRead_pm_513 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 513 = AllToAllSourceFaithful.tensor 2 1 1 3 (([207, 510] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 138) (pmInputRequests.drop 139) pmNode_303 1 [0, 1] [207, 510] 513 1 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 138 ++ pmInputRequests.drop 138 := (List.take_append_drop 138 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([207, 510] : List Tid), ∀ row ∈ pmInputRequests.drop 138, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_513
theorem frontierHeadExchangeUnitFacts_1299_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1299).shape = [2, 16, 4, 16] ∧
    (∀ x ∈ [q 210, q 513], x.shape = [1, 16, 4, 8]) ∧
    chunkPrimDimN 0 2 0 (t 1299) = allGatherPrimDimN 3 2 0 [q 210, q 513] := by
  have predecessor := frontierProjectionViewUnitFacts_1299_0_slot0 s p t q hs hp hvalues
  have outputs : [q 210, q 513] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 1 3 [q 207, q 510]) := by
    change [q 210, q 513] = [AllToAllSourceFaithful.tensor 2 0 1 3 [q 207, q 510], AllToAllSourceFaithful.tensor 2 1 1 3 [q 207, q 510]]
    exact congrArg₂ List.cons (frontierHeadExchangeRead_pm_210 p q hp) (congrArg₂ List.cons (frontierHeadExchangeRead_pm_513 p q hp) (rfl))
  exact SourceRank4Exchange.axis1_output_facts 2 0 2 1 8 4 8 (t 1299) [q 207, q 510] [q 210, q 513]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierHeadExchangeUnitFacts_1299_0_slot0
theorem frontierHeadExchangeRead_pm_218 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 218 = AllToAllSourceFaithful.tensor 2 0 2 1 (([215, 518] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 142) (pmInputRequests.drop 143) pmNode_71 0 [0, 1] [215, 518] 218 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 142 ++ pmInputRequests.drop 142 := (List.take_append_drop 142 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([215, 518] : List Tid), ∀ row ∈ pmInputRequests.drop 142, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_218
theorem frontierHeadExchangeRead_pm_521 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 521 = AllToAllSourceFaithful.tensor 2 1 2 1 (([215, 518] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 145) (pmInputRequests.drop 146) pmNode_307 1 [0, 1] [215, 518] 521 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 145 ++ pmInputRequests.drop 145 := (List.take_append_drop 145 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([215, 518] : List Tid), ∀ row ∈ pmInputRequests.drop 145, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_521
theorem frontierHeadExchangeUnitFacts_1301_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1301).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 218, q 521], y.shape = [1, 8, 4, 16]) ∧
    chunkPrimDimN 0 2 0 (t 1301) = allGatherPrimDimN 1 2 0 [q 218, q 521] := by
  have predecessor := frontierProjectionViewUnitFacts_1301_0_slot0 s p t q hs hp hvalues
  have outputs : [q 218, q 521] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 2 1 [q 215, q 518]) := by
    change [q 218, q 521] = [AllToAllSourceFaithful.tensor 2 0 2 1 [q 215, q 518], AllToAllSourceFaithful.tensor 2 1 2 1 [q 215, q 518]]
    exact congrArg₂ List.cons (frontierHeadExchangeRead_pm_218 p q hp) (congrArg₂ List.cons (frontierHeadExchangeRead_pm_521 p q hp) (rfl))
  exact SourceRank4MiddleExchange.axis2_output_facts 2 0 2 1 8 2 16 (t 1301) [q 215, q 518] [q 218, q 521]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierHeadExchangeUnitFacts_1301_0_slot0
theorem frontierHeadExchangeRead_pm_808 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 808 = AllToAllSourceFaithful.tensor 2 0 1 2 (([805, 1108] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 548) (pmInputRequests.drop 549) pmNode_535 2 [2, 3] [805, 1108] 808 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 548 ++ pmInputRequests.drop 548 := (List.take_append_drop 548 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([805, 1108] : List Tid), ∀ row ∈ pmInputRequests.drop 548, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_808
theorem frontierHeadExchangeRead_pm_1111 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1111 = AllToAllSourceFaithful.tensor 2 1 1 2 (([805, 1108] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 552) (pmInputRequests.drop 553) pmNode_771 3 [2, 3] [805, 1108] 1111 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 552 ++ pmInputRequests.drop 552 := (List.take_append_drop 552 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([805, 1108] : List Tid), ∀ row ∈ pmInputRequests.drop 552, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_1111
theorem frontierHeadExchangeUnitFacts_1297_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1297).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 808, q 1111], y.shape = [1, 16, 2, 16]) ∧
    chunkPrimDimN 0 2 1 (t 1297) = allGatherPrimDimN 2 2 0 [q 808, q 1111] := by
  have predecessor := frontierProjectionViewUnitFacts_1297_1_slot0 s p t q hs hp hvalues
  have outputs : [q 808, q 1111] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 1 2 [q 805, q 1108]) := by
    change [q 808, q 1111] = [AllToAllSourceFaithful.tensor 2 0 1 2 [q 805, q 1108], AllToAllSourceFaithful.tensor 2 1 1 2 [q 805, q 1108]]
    exact congrArg₂ List.cons (frontierHeadExchangeRead_pm_808 p q hp) (congrArg₂ List.cons (frontierHeadExchangeRead_pm_1111 p q hp) (rfl))
  exact SourceRank4InnerExchange.axis1_output_facts 2 1 2 1 8 2 16 (t 1297) [q 805, q 1108] [q 808, q 1111]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierHeadExchangeUnitFacts_1297_1_slot0
theorem frontierHeadExchangeRead_pm_816 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 816 = AllToAllSourceFaithful.tensor 2 0 1 3 (([813, 1116] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 556) (pmInputRequests.drop 557) pmNode_539 2 [2, 3] [813, 1116] 816 1 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 556 ++ pmInputRequests.drop 556 := (List.take_append_drop 556 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([813, 1116] : List Tid), ∀ row ∈ pmInputRequests.drop 556, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_816
theorem frontierHeadExchangeRead_pm_1119 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1119 = AllToAllSourceFaithful.tensor 2 1 1 3 (([813, 1116] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 560) (pmInputRequests.drop 561) pmNode_775 3 [2, 3] [813, 1116] 1119 1 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 560 ++ pmInputRequests.drop 560 := (List.take_append_drop 560 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([813, 1116] : List Tid), ∀ row ∈ pmInputRequests.drop 560, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_1119
theorem frontierHeadExchangeUnitFacts_1299_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1299).shape = [2, 16, 4, 16] ∧
    (∀ x ∈ [q 816, q 1119], x.shape = [1, 16, 4, 8]) ∧
    chunkPrimDimN 0 2 1 (t 1299) = allGatherPrimDimN 3 2 0 [q 816, q 1119] := by
  have predecessor := frontierProjectionViewUnitFacts_1299_1_slot0 s p t q hs hp hvalues
  have outputs : [q 816, q 1119] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 1 3 [q 813, q 1116]) := by
    change [q 816, q 1119] = [AllToAllSourceFaithful.tensor 2 0 1 3 [q 813, q 1116], AllToAllSourceFaithful.tensor 2 1 1 3 [q 813, q 1116]]
    exact congrArg₂ List.cons (frontierHeadExchangeRead_pm_816 p q hp) (congrArg₂ List.cons (frontierHeadExchangeRead_pm_1119 p q hp) (rfl))
  exact SourceRank4Exchange.axis1_output_facts 2 1 2 1 8 4 8 (t 1299) [q 813, q 1116] [q 816, q 1119]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierHeadExchangeUnitFacts_1299_1_slot0
theorem frontierHeadExchangeRead_pm_824 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 824 = AllToAllSourceFaithful.tensor 2 0 2 1 (([821, 1124] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 564) (pmInputRequests.drop 565) pmNode_543 2 [2, 3] [821, 1124] 824 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 564 ++ pmInputRequests.drop 564 := (List.take_append_drop 564 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([821, 1124] : List Tid), ∀ row ∈ pmInputRequests.drop 564, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_824
theorem frontierHeadExchangeRead_pm_1127 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1127 = AllToAllSourceFaithful.tensor 2 1 2 1 (([821, 1124] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 567) (pmInputRequests.drop 568) pmNode_779 3 [2, 3] [821, 1124] 1127 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 567 ++ pmInputRequests.drop 567 := (List.take_append_drop 567 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([821, 1124] : List Tid), ∀ row ∈ pmInputRequests.drop 567, tid ∉ row.1.outs
    decide
#print axioms frontierHeadExchangeRead_pm_1127
theorem frontierHeadExchangeUnitFacts_1301_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1301).shape = [2, 16, 4, 16] ∧
    (∀ y ∈ [q 824, q 1127], y.shape = [1, 8, 4, 16]) ∧
    chunkPrimDimN 0 2 1 (t 1301) = allGatherPrimDimN 1 2 0 [q 824, q 1127] := by
  have predecessor := frontierProjectionViewUnitFacts_1301_1_slot0 s p t q hs hp hvalues
  have outputs : [q 824, q 1127] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 2 1 [q 821, q 1124]) := by
    change [q 824, q 1127] = [AllToAllSourceFaithful.tensor 2 0 2 1 [q 821, q 1124], AllToAllSourceFaithful.tensor 2 1 2 1 [q 821, q 1124]]
    exact congrArg₂ List.cons (frontierHeadExchangeRead_pm_824 p q hp) (congrArg₂ List.cons (frontierHeadExchangeRead_pm_1127 p q hp) (rfl))
  exact SourceRank4MiddleExchange.axis2_output_facts 2 1 2 1 8 2 16 (t 1301) [q 821, q 1124] [q 824, q 1127]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierHeadExchangeUnitFacts_1301_1_slot0
end
end TrainVerify.Denote.RuntimeWorld
