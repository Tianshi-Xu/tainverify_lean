import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0012
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_87_0 (z : Store) : (s_87 z) 468 = (v_86_0 z) := w_86_0 z
 #a r_87_0
 def v_87_0 (z : Store) : Tensor := (v_86_0 z)
 def v_87_1 (z : Store) : Tensor := (v_86_0 z)
 def s_88 (z : Store) : Store := storeSet (s_87 z) [(592, ((s_87 z) 468)), (482, ((s_87 z) 468))]
 theorem t_87 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_279) (pmPeers pmNode_279) (s_87 z) pmNode_279 none = some (s_88 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_87
 theorem k_87 (z : Store) (tid : Tid) (h : tid ∉ [592, 482]) : (s_88 z) tid = (s_87 z) tid := by
   unfold s_88
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_87
 theorem w_87_0 (z : Store) : (s_88 z) 592 = v_87_0 z := by
   unfold s_88
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_87_0, r_87_0 z] <;> rfl
 #a w_87_0
 theorem h_87_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_87_0 z).shape = [1, 16, 32] := by
   unfold v_87_0
   exact h_86_0 z z_
 #a h_87_0
 attribute [local irreducible] v_87_0
 theorem w_87_1 (z : Store) : (s_88 z) 482 = v_87_1 z := by
   unfold s_88
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_87_1, r_87_0 z] <;> rfl
 #a w_87_1
 theorem h_87_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_87_1 z).shape = [1, 16, 32] := by
   unfold v_87_1
   exact h_86_0 z z_
 #a h_87_1
 attribute [local irreducible] v_87_1
 attribute [local irreducible] s_88
 theorem r_88_0 (z : Store) : (s_88 z) 289 = (v_84_0 z) := pR (k_87 z) (pR (k_86 z) (pR (k_85 z) (w_84_0 z)))
 #a r_88_0
 theorem r_88_1 (z : Store) : (s_88 z) 592 = (v_87_0 z) := w_87_0 z
 #a r_88_1
 def v_88_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_84_0 z), (v_87_0 z)]
 theorem g_88 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_44) (s_88 z) pmNode_44 2 1 169 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_44, r_88_0 z, r_88_1 z, h_84_0 z z_, h_87_0 z z_]
 #a g_88
 def s_89 (z : Store) : Store := pL [0, 1] (s_88 z) pmNode_44 2 1
 theorem t_88 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_44) (pmPeers pmNode_44) (s_88 z) pmNode_44 none = some (s_89 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_44) (s_88 z) pmNode_44).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 169 (by decide) (g_88 z z_)]
   rfl
 #a t_88
 theorem k_88 (z : Store) (tid : Tid) (h : tid ∉ [169]) : (s_89 z) tid = (s_88 z) tid := by
   unfold s_89
   dsimp only [pL, pmNode_44, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_88
 theorem w_88_0 (z : Store) : (s_89 z) 169 = v_88_0 z := by
   unfold s_89
   dsimp only [pL, pmNode_44, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_88_0, r_88_0 z, r_88_1 z] <;> rfl
 #a w_88_0
 theorem h_88_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_88_0 z).shape = [1, 8, 64] := by
   unfold v_88_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_84_0 z z_]
 #a h_88_0
 attribute [local irreducible] v_88_0
 attribute [local irreducible] s_89
 theorem n_84_88 (z : Store) (tid : Tid) (h : tid ∉ ([289, 179, 467, 468, 592, 482] : List Tid)) : (s_88 z) tid = (s_84 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_84 z) (k_85 z)) (pF _ _ _ _ _ (k_86 z) (k_87 z)) tid h
 #a n_84_88
 theorem n_80_88 (z : Store) (tid : Tid) (h : tid ∉ ([462, 463, 164, 165, 289, 179, 467, 468, 592, 482] : List Tid)) : (s_88 z) tid = (s_80 z) tid := by
   exact pF _ _ _ _ _ (n_80_84 z) (n_84_88 z) tid h
 #a n_80_88
 theorem r_89_0 (z : Store) : (s_89 z) 169 = (v_88_0 z) := w_88_0 z
 #a r_89_0
 theorem r_89_1 (z : Store) : (s_89 z) 5 = (z 5) := pR (k_88 z) (pR (n_80_88 z) (pR (n_64_80 z) (pR (n_0_64 z) (e_16 z))))
 #a r_89_1
 theorem r_89_2 (z : Store) : (s_89 z) 6 = (z 6) := pR (k_88 z) (pR (n_80_88 z) (pR (n_64_80 z) (pR (n_0_64 z) (e_17 z))))
 #a r_89_2
 def v_89_0 (z : Store) : Tensor := fw_layernorm (v_88_0 z) (z 5) (z 6)
 def s_90 (z : Store) : Store := storeSet (s_89 z) [(170, fw_layernorm ((s_89 z) 169) ((s_89 z) 5) ((s_89 z) 6))]
 theorem t_89 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_45) (pmPeers pmNode_45) (s_89 z) pmNode_45 none = some (s_90 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_89
 theorem k_89 (z : Store) (tid : Tid) (h : tid ∉ [170]) : (s_90 z) tid = (s_89 z) tid := by
   unfold s_90
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_89
 theorem w_89_0 (z : Store) : (s_90 z) 170 = v_89_0 z := by
   unfold s_90
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_89_0, r_89_0 z, r_89_1 z, r_89_2 z] <;> rfl
 #a w_89_0
 theorem h_89_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_89_0 z).shape = [1, 8, 64] := by
   unfold v_89_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_88_0 z z_
 #a h_89_0
 attribute [local irreducible] v_89_0
 attribute [local irreducible] s_90
 theorem r_90_0 (z : Store) : (s_90 z) 170 = (v_89_0 z) := w_89_0 z
 #a r_90_0
 theorem r_90_1 (z : Store) : (s_90 z) 7 = (z 7) := pR (k_89 z) (pR (k_88 z) (pR (n_80_88 z) (pR (n_64_80 z) (pR (n_0_64 z) (e_18 z)))))
 #a r_90_1
 def v_90_0 (z : Store) : Tensor := fw_linear (v_89_0 z) (z 7)
 def s_91 (z : Store) : Store := storeSet (s_90 z) [(173, fw_linear ((s_90 z) 170) ((s_90 z) 7))]
 theorem t_90 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_46) (pmPeers pmNode_46) (s_90 z) pmNode_46 none = some (s_91 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_90
 theorem k_90 (z : Store) (tid : Tid) (h : tid ∉ [173]) : (s_91 z) tid = (s_90 z) tid := by
   unfold s_91
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_90
 theorem w_90_0 (z : Store) : (s_91 z) 173 = v_90_0 z := by
   unfold s_91
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_90_0, r_90_0 z, r_90_1 z] <;> rfl
 #a w_90_0
 theorem h_90_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_90_0 z).shape = [1, 8, 256] := by
   unfold v_90_0
   exact fw_linear_3d_shape 1 8 64 256 (v_89_0 z) (z 7) (h_89_0 z z_) (i_18 z z_)
 #a h_90_0
 attribute [local irreducible] v_90_0
 attribute [local irreducible] s_91
 theorem r_91_0 (z : Store) : (s_91 z) 173 = (v_90_0 z) := w_90_0 z
 #a r_91_0
 def v_91_0 (z : Store) : Tensor := fw_gelu (v_90_0 z)
 def s_92 (z : Store) : Store := storeSet (s_91 z) [(175, fw_gelu ((s_91 z) 173))]
 theorem t_91 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_47) (pmPeers pmNode_47) (s_91 z) pmNode_47 none = some (s_92 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_91
 theorem k_91 (z : Store) (tid : Tid) (h : tid ∉ [175]) : (s_92 z) tid = (s_91 z) tid := by
   unfold s_92
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_91
 theorem w_91_0 (z : Store) : (s_92 z) 175 = v_91_0 z := by
   unfold s_92
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_91_0, r_91_0 z] <;> rfl
 #a w_91_0
 theorem h_91_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_91_0 z).shape = [1, 8, 256] := by
   unfold v_91_0
   exact h_90_0 z z_
 #a h_91_0
 attribute [local irreducible] v_91_0
 attribute [local irreducible] s_92
 theorem n_88_92 (z : Store) (tid : Tid) (h : tid ∉ ([169, 170, 173, 175] : List Tid)) : (s_92 z) tid = (s_88 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_88 z) (k_89 z)) (pF _ _ _ _ _ (k_90 z) (k_91 z)) tid h
 #a n_88_92
 theorem r_92_0 (z : Store) : (s_92 z) 175 = (v_91_0 z) := w_91_0 z
 #a r_92_0
 theorem r_92_1 (z : Store) : (s_92 z) 8 = (z 8) := pR (n_88_92 z) (pR (n_80_88 z) (pR (n_64_80 z) (pR (n_0_64 z) (e_19 z))))
 #a r_92_1
 def v_92_0 (z : Store) : Tensor := fw_linear (v_91_0 z) (z 8)
 def s_93 (z : Store) : Store := storeSet (s_92 z) [(177, fw_linear ((s_92 z) 175) ((s_92 z) 8))]
 theorem t_92 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_48) (pmPeers pmNode_48) (s_92 z) pmNode_48 none = some (s_93 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_92
 theorem k_92 (z : Store) (tid : Tid) (h : tid ∉ [177]) : (s_93 z) tid = (s_92 z) tid := by
   unfold s_93
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_92
 theorem w_92_0 (z : Store) : (s_93 z) 177 = v_92_0 z := by
   unfold s_93
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_92_0, r_92_0 z, r_92_1 z] <;> rfl
 #a w_92_0
 theorem h_92_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_92_0 z).shape = [1, 8, 64] := by
   unfold v_92_0
   exact fw_linear_3d_shape 1 8 256 64 (v_91_0 z) (z 8) (h_91_0 z z_) (i_19 z z_)
 #a h_92_0
 attribute [local irreducible] v_92_0
 attribute [local irreducible] s_93
 theorem r_93_0 (z : Store) : (s_93 z) 289 = (v_84_0 z) := pR (k_92 z) (pR (n_88_92 z) (r_88_0 z))
 #a r_93_0
 theorem r_93_1 (z : Store) : (s_93 z) 592 = (v_87_0 z) := pR (k_92 z) (pR (n_88_92 z) (r_88_1 z))
 #a r_93_1
 def v_93_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_84_0 z), (v_87_0 z)]
 theorem g_93 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_280) (s_93 z) pmNode_280 2 1 472 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_280, r_93_0 z, r_93_1 z, h_84_0 z z_, h_87_0 z z_]
 #a g_93
 def s_94 (z : Store) : Store := pL [0, 1] (s_93 z) pmNode_280 2 1
 theorem t_93 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_280) (pmPeers pmNode_280) (s_93 z) pmNode_280 none = some (s_94 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_280) (s_93 z) pmNode_280).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 472 (by decide) (g_93 z z_)]
   rfl
 #a t_93
 theorem k_93 (z : Store) (tid : Tid) (h : tid ∉ [472]) : (s_94 z) tid = (s_93 z) tid := by
   unfold s_94
   dsimp only [pL, pmNode_280, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_93
 theorem w_93_0 (z : Store) : (s_94 z) 472 = v_93_0 z := by
   unfold s_94
   dsimp only [pL, pmNode_280, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_93_0, r_93_0 z, r_93_1 z] <;> rfl
 #a w_93_0
 theorem h_93_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_93_0 z).shape = [1, 8, 64] := by
   unfold v_93_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_84_0 z z_]
 #a h_93_0
 attribute [local irreducible] v_93_0
 attribute [local irreducible] s_94
 theorem r_94_0 (z : Store) : (s_94 z) 472 = (v_93_0 z) := w_93_0 z
 #a r_94_0
 theorem r_94_1 (z : Store) : (s_94 z) 308 = (z 308) := pR (k_93 z) (pR (k_92 z) (pR (n_88_92 z) (pR (n_80_88 z) (pR (n_64_80 z) (pR (n_0_64 z) (e_20 z))))))
 #a r_94_1
 theorem r_94_2 (z : Store) : (s_94 z) 309 = (z 309) := pR (k_93 z) (pR (k_92 z) (pR (n_88_92 z) (pR (n_80_88 z) (pR (n_64_80 z) (pR (n_0_64 z) (e_21 z))))))
 #a r_94_2
 def v_94_0 (z : Store) : Tensor := fw_layernorm (v_93_0 z) (z 308) (z 309)
 def s_95 (z : Store) : Store := storeSet (s_94 z) [(473, fw_layernorm ((s_94 z) 472) ((s_94 z) 308) ((s_94 z) 309))]
 theorem t_94 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_281) (pmPeers pmNode_281) (s_94 z) pmNode_281 none = some (s_95 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_94
 theorem k_94 (z : Store) (tid : Tid) (h : tid ∉ [473]) : (s_95 z) tid = (s_94 z) tid := by
   unfold s_95
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_94
 theorem w_94_0 (z : Store) : (s_95 z) 473 = v_94_0 z := by
   unfold s_95
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_94_0, r_94_0 z, r_94_1 z, r_94_2 z] <;> rfl
 #a w_94_0
 theorem h_94_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_94_0 z).shape = [1, 8, 64] := by
   unfold v_94_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_93_0 z z_
 #a h_94_0
 attribute [local irreducible] v_94_0
 attribute [local irreducible] s_95
 theorem r_95_0 (z : Store) : (s_95 z) 473 = (v_94_0 z) := w_94_0 z
 #a r_95_0
 theorem r_95_1 (z : Store) : (s_95 z) 310 = (z 310) := pR (k_94 z) (pR (k_93 z) (pR (k_92 z) (pR (n_88_92 z) (pR (n_80_88 z) (pR (n_64_80 z) (pR (n_0_64 z) (e_22 z)))))))
 #a r_95_1
 def v_95_0 (z : Store) : Tensor := fw_linear (v_94_0 z) (z 310)
 def s_96 (z : Store) : Store := storeSet (s_95 z) [(476, fw_linear ((s_95 z) 473) ((s_95 z) 310))]
 theorem t_95 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_282) (pmPeers pmNode_282) (s_95 z) pmNode_282 none = some (s_96 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_95
 theorem k_95 (z : Store) (tid : Tid) (h : tid ∉ [476]) : (s_96 z) tid = (s_95 z) tid := by
   unfold s_96
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_95
 theorem w_95_0 (z : Store) : (s_96 z) 476 = v_95_0 z := by
   unfold s_96
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_95_0, r_95_0 z, r_95_1 z] <;> rfl
 #a w_95_0
 theorem h_95_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_95_0 z).shape = [1, 8, 256] := by
   unfold v_95_0
   exact fw_linear_3d_shape 1 8 64 256 (v_94_0 z) (z 310) (h_94_0 z z_) (i_22 z z_)
 #a h_95_0
 attribute [local irreducible] v_95_0
 attribute [local irreducible] s_96
 record_prefix_opacity v_87_0 v_87_1 s_88 v_88_0 s_89 v_89_0 s_90 v_90_0 s_91 v_91_0 s_92 v_92_0 s_93 v_93_0 s_94 v_94_0 s_95 v_95_0 s_96

 end
 end TrainVerify.Denote.RuntimeWorld
