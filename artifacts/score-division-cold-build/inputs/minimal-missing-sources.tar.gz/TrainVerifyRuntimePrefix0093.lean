import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0092
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_736_0 (z : Store) : (s_736 z) 797 = (v_733_0 z) := pR (k_735 z) (pR (k_734 z) (w_733_0 z))
 #a r_736_0
 theorem r_736_1 (z : Store) : (s_736 z) 1099 = (v_735_0 z) := w_735_0 z
 #a r_736_1
 def v_736_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_733_0 z), (v_735_0 z)]
 def s_737 (z : Store) : Store := storeSet (s_736 z) [(900, reduceScatterPrimDimN 1 2 0 [((s_736 z) 797), ((s_736 z) 1099)])]
 theorem t_736 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_629) (pmPeers pmNode_629) (s_736 z) pmNode_629 none = some (s_737 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_736 z) pmNode_629 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_736
 theorem k_736 (z : Store) (tid : Tid) (h : tid ∉ [900]) : (s_737 z) tid = (s_736 z) tid := by
   unfold s_737
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_736
 theorem w_736_0 (z : Store) : (s_737 z) 900 = v_736_0 z := by
   unfold s_737
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_736_0, r_736_0 z, r_736_1 z] <;> rfl
 #a w_736_0
 theorem h_736_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_736_0 z).shape = [1, 8, 64] := by
   unfold v_736_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_733_0 z) rfl]
     exact h_733_0 z z_
   · decide
 #a h_736_0
 attribute [local irreducible] v_736_0
 attribute [local irreducible] s_737
 theorem n_732_736 (z : Store) (tid : Tid) (h : tid ∉ ([902, 797, 654, 1205, 1099, 957] : List Tid)) : (s_736 z) tid = (s_732 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_732 z) (k_733 z)) (pF _ _ _ _ _ (k_734 z) (k_735 z)) tid h
 #a n_732_736
 theorem r_737_0 (z : Store) : (s_737 z) 900 = (v_736_0 z) := w_736_0 z
 #a r_737_0
 theorem r_737_1 (z : Store) : (s_737 z) 902 = (v_732_0 z) := pR (k_736 z) (pR (k_735 z) (pR (k_734 z) (pR (k_733 z) (w_732_0 z))))
 #a r_737_1
 theorem r_737_2 (z : Store) : (s_737 z) 904 = (v_728_0 z) := pR (k_736 z) (pR (n_732_736 z) (pR (k_731 z) (pR (k_730 z) (pR (k_729 z) (w_728_0 z)))))
 #a r_737_2
 def v_737_0 (z : Store) : Tensor := tensorSum [(v_736_0 z), (v_732_0 z), (v_728_0 z)]
 def s_738 (z : Store) : Store := storeSet (s_737 z) [(794, tensorSum [((s_737 z) 900), ((s_737 z) 902), ((s_737 z) 904)])]
 theorem t_737 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_630) (pmPeers pmNode_630) (s_737 z) pmNode_630 none = some (s_738 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_737
 theorem k_737 (z : Store) (tid : Tid) (h : tid ∉ [794]) : (s_738 z) tid = (s_737 z) tid := by
   unfold s_738
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_737
 theorem w_737_0 (z : Store) : (s_738 z) 794 = v_737_0 z := by
   unfold s_738
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_737_0, r_737_0 z, r_737_1 z, r_737_2 z] <;> rfl
 #a w_737_0
 theorem h_737_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_737_0 z).shape = [1, 8, 64] := by
   unfold v_737_0
   rw [tensorSum_shape]
   exact h_736_0 z z_
 #a h_737_0
 attribute [local irreducible] v_737_0
 attribute [local irreducible] s_738
 theorem n_728_736 (z : Store) (tid : Tid) (h : tid ∉ ([904, 800, 657, 1207, 1103, 960, 902, 797, 654, 1205, 1099, 957] : List Tid)) : (s_736 z) tid = (s_728 z) tid := by
   exact pF _ _ _ _ _ (n_728_732 z) (n_732_736 z) tid h
 #a n_728_736
 theorem n_720_736 (z : Store) (tid : Tid) (h : tid ∉ ([807, 806, 1110, 1109, 796, 803, 660, 1100, 1106, 963, 904, 800, 657, 1207, 1103, 960, 902, 797, 654, 1205, 1099, 957] : List Tid)) : (s_736 z) tid = (s_720 z) tid := by
   exact pF _ _ _ _ _ (n_720_728 z) (n_728_736 z) tid h
 #a n_720_736
 theorem n_704_736 (z : Store) (tid : Tid) (h : tid ∉ ([823, 822, 1126, 1125, 689, 818, 992, 1121, 815, 814, 1118, 1117, 688, 810, 991, 1113, 807, 806, 1110, 1109, 796, 803, 660, 1100, 1106, 963, 904, 800, 657, 1207, 1103, 960, 902, 797, 654, 1205, 1099, 957] : List Tid)) : (s_736 z) tid = (s_704 z) tid := by
   exact pF _ _ _ _ _ (n_704_720 z) (n_720_736 z) tid h
 #a n_704_736
 theorem r_738_0 (z : Store) : (s_738 z) 794 = (v_737_0 z) := w_737_0 z
 #a r_738_0
 theorem r_738_1 (z : Store) : (s_738 z) 791 = (v_526_0 z) := pR (k_737 z) (pR (k_736 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (k_527 z) (r_527_0 z))))))))
 #a r_738_1
 theorem r_738_2 (z : Store) : (s_738 z) 615 = (z 615) := pR (k_737 z) (pR (k_736 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (k_527 z) (r_527_1 z))))))))
 #a r_738_2
 theorem r_738_3 (z : Store) : (s_738 z) 616 = (z 616) := pR (k_737 z) (pR (k_736 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (k_527 z) (r_527_2 z))))))))
 #a r_738_3
 def v_738_0 (z : Store) : Tensor := (bw_layernorm (v_737_0 z) (v_526_0 z) (z 615) (z 616)).1
 def v_738_1 (z : Store) : Tensor := (bw_layernorm (v_737_0 z) (v_526_0 z) (z 615) (z 616)).2.1
 def v_738_2 (z : Store) : Tensor := (bw_layernorm (v_737_0 z) (v_526_0 z) (z 615) (z 616)).2.2
 def s_739 (z : Store) : Store := storeSet (s_738 z) [(793, (bw_layernorm ((s_738 z) 794) ((s_738 z) 791) ((s_738 z) 615) ((s_738 z) 616)).1), (649, (bw_layernorm ((s_738 z) 794) ((s_738 z) 791) ((s_738 z) 615) ((s_738 z) 616)).2.1), (651, (bw_layernorm ((s_738 z) 794) ((s_738 z) 791) ((s_738 z) 615) ((s_738 z) 616)).2.2)]
 theorem t_738 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_631) (pmPeers pmNode_631) (s_738 z) pmNode_631 none = some (s_739 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_738
 theorem k_738 (z : Store) (tid : Tid) (h : tid ∉ [793, 649, 651]) : (s_739 z) tid = (s_738 z) tid := by
   unfold s_739
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_738
 theorem w_738_0 (z : Store) : (s_739 z) 793 = v_738_0 z := by
   unfold s_739
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_738_0, r_738_0 z, r_738_1 z, r_738_2 z, r_738_3 z] <;> rfl
 #a w_738_0
 theorem h_738_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_738_0 z).shape = [1, 8, 64] := by
   unfold v_738_0
   rw [bw_layernorm_dx_shape (v_737_0 z) (v_526_0 z) (z 615) (z 616) 64 [8, 1] (by rw [h_526_0 z z_]; rfl)]
   exact h_526_0 z z_
 #a h_738_0
 attribute [local irreducible] v_738_0
 theorem w_738_1 (z : Store) : (s_739 z) 649 = v_738_1 z := by
   unfold s_739
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_738_1, r_738_0 z, r_738_1 z, r_738_2 z, r_738_3 z] <;> rfl
 #a w_738_1
 theorem h_738_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_738_1 z).shape = [64] := by
   unfold v_738_1
   rw [bw_layernorm_dw_shape (v_737_0 z) (v_526_0 z) (z 615) (z 616) 64 [8, 1] (by rw [h_526_0 z z_]; rfl)]
   exact i_74 z z_
 #a h_738_1
 attribute [local irreducible] v_738_1
 theorem w_738_2 (z : Store) : (s_739 z) 651 = v_738_2 z := by
   unfold s_739
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_738_2, r_738_0 z, r_738_1 z, r_738_2 z, r_738_3 z] <;> rfl
 #a w_738_2
 theorem h_738_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_738_2 z).shape = [64] := by
   unfold v_738_2
   rw [bw_layernorm_db_shape (v_737_0 z) (v_526_0 z) (z 615) (z 616) 64 [8, 1] (by rw [h_526_0 z z_]; rfl)]
   exact i_75 z z_
 #a h_738_2
 attribute [local irreducible] v_738_2
 attribute [local irreducible] s_739
 theorem r_739_0 (z : Store) : (s_739 z) 797 = (v_733_0 z) := pR (k_738 z) (pR (k_737 z) (pR (k_736 z) (r_736_0 z)))
 #a r_739_0
 theorem r_739_1 (z : Store) : (s_739 z) 1099 = (v_735_0 z) := pR (k_738 z) (pR (k_737 z) (pR (k_736 z) (r_736_1 z)))
 #a r_739_1
 def v_739_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_733_0 z), (v_735_0 z)]
 def s_740 (z : Store) : Store := storeSet (s_739 z) [(1203, reduceScatterPrimDimN 1 2 1 [((s_739 z) 797), ((s_739 z) 1099)])]
 theorem t_739 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_865) (pmPeers pmNode_865) (s_739 z) pmNode_865 none = some (s_740 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_739 z) pmNode_865 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_739
 theorem k_739 (z : Store) (tid : Tid) (h : tid ∉ [1203]) : (s_740 z) tid = (s_739 z) tid := by
   unfold s_740
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_739
 theorem w_739_0 (z : Store) : (s_740 z) 1203 = v_739_0 z := by
   unfold s_740
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_739_0, r_739_0 z, r_739_1 z] <;> rfl
 #a w_739_0
 theorem h_739_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_739_0 z).shape = [1, 8, 64] := by
   unfold v_739_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_733_0 z) rfl]
     exact h_733_0 z z_
   · decide
 #a h_739_0
 attribute [local irreducible] v_739_0
 attribute [local irreducible] s_740
 theorem n_736_740 (z : Store) (tid : Tid) (h : tid ∉ ([900, 794, 793, 649, 651, 1203] : List Tid)) : (s_740 z) tid = (s_736 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_736 z) (k_737 z)) (pF _ _ _ _ _ (k_738 z) (k_739 z)) tid h
 #a n_736_740
 theorem r_740_0 (z : Store) : (s_740 z) 1203 = (v_739_0 z) := w_739_0 z
 #a r_740_0
 theorem r_740_1 (z : Store) : (s_740 z) 1205 = (v_734_0 z) := pR (n_736_740 z) (pR (k_735 z) (w_734_0 z))
 #a r_740_1
 theorem r_740_2 (z : Store) : (s_740 z) 1207 = (v_730_0 z) := pR (n_736_740 z) (pR (n_732_736 z) (pR (k_731 z) (w_730_0 z)))
 #a r_740_2
 def v_740_0 (z : Store) : Tensor := tensorSum [(v_739_0 z), (v_734_0 z), (v_730_0 z)]
 def s_741 (z : Store) : Store := storeSet (s_740 z) [(1097, tensorSum [((s_740 z) 1203), ((s_740 z) 1205), ((s_740 z) 1207)])]
 theorem t_740 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_866) (pmPeers pmNode_866) (s_740 z) pmNode_866 none = some (s_741 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_740
 theorem k_740 (z : Store) (tid : Tid) (h : tid ∉ [1097]) : (s_741 z) tid = (s_740 z) tid := by
   unfold s_741
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_740
 theorem w_740_0 (z : Store) : (s_741 z) 1097 = v_740_0 z := by
   unfold s_741
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_740_0, r_740_0 z, r_740_1 z, r_740_2 z] <;> rfl
 #a w_740_0
 theorem h_740_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_740_0 z).shape = [1, 8, 64] := by
   unfold v_740_0
   rw [tensorSum_shape]
   exact h_739_0 z z_
 #a h_740_0
 attribute [local irreducible] v_740_0
 attribute [local irreducible] s_741
 theorem r_741_0 (z : Store) : (s_741 z) 1097 = (v_740_0 z) := w_740_0 z
 #a r_741_0
 theorem r_741_1 (z : Store) : (s_741 z) 1094 = (v_529_0 z) := pR (k_740 z) (pR (n_736_740 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_536_544 z) (pR (n_532_536 z) (pR (k_531 z) (pR (k_530 z) (r_530_0 z))))))))))
 #a r_741_1
 theorem r_741_2 (z : Store) : (s_741 z) 918 = (z 918) := pR (k_740 z) (pR (n_736_740 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_536_544 z) (pR (n_532_536 z) (pR (k_531 z) (pR (k_530 z) (r_530_1 z))))))))))
 #a r_741_2
 theorem r_741_3 (z : Store) : (s_741 z) 919 = (z 919) := pR (k_740 z) (pR (n_736_740 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_536_544 z) (pR (n_532_536 z) (pR (k_531 z) (pR (k_530 z) (r_530_2 z))))))))))
 #a r_741_3
 def v_741_0 (z : Store) : Tensor := (bw_layernorm (v_740_0 z) (v_529_0 z) (z 918) (z 919)).1
 def v_741_1 (z : Store) : Tensor := (bw_layernorm (v_740_0 z) (v_529_0 z) (z 918) (z 919)).2.1
 def v_741_2 (z : Store) : Tensor := (bw_layernorm (v_740_0 z) (v_529_0 z) (z 918) (z 919)).2.2
 def s_742 (z : Store) : Store := storeSet (s_741 z) [(1096, (bw_layernorm ((s_741 z) 1097) ((s_741 z) 1094) ((s_741 z) 918) ((s_741 z) 919)).1), (952, (bw_layernorm ((s_741 z) 1097) ((s_741 z) 1094) ((s_741 z) 918) ((s_741 z) 919)).2.1), (954, (bw_layernorm ((s_741 z) 1097) ((s_741 z) 1094) ((s_741 z) 918) ((s_741 z) 919)).2.2)]
 theorem t_741 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_867) (pmPeers pmNode_867) (s_741 z) pmNode_867 none = some (s_742 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_741
 theorem k_741 (z : Store) (tid : Tid) (h : tid ∉ [1096, 952, 954]) : (s_742 z) tid = (s_741 z) tid := by
   unfold s_742
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_741
 theorem w_741_0 (z : Store) : (s_742 z) 1096 = v_741_0 z := by
   unfold s_742
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_741_0, r_741_0 z, r_741_1 z, r_741_2 z, r_741_3 z] <;> rfl
 #a w_741_0
 theorem h_741_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_741_0 z).shape = [1, 8, 64] := by
   unfold v_741_0
   rw [bw_layernorm_dx_shape (v_740_0 z) (v_529_0 z) (z 918) (z 919) 64 [8, 1] (by rw [h_529_0 z z_]; rfl)]
   exact h_529_0 z z_
 #a h_741_0
 attribute [local irreducible] v_741_0
 theorem w_741_1 (z : Store) : (s_742 z) 952 = v_741_1 z := by
   unfold s_742
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_741_1, r_741_0 z, r_741_1 z, r_741_2 z, r_741_3 z] <;> rfl
 #a w_741_1
 theorem h_741_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_741_1 z).shape = [64] := by
   unfold v_741_1
   rw [bw_layernorm_dw_shape (v_740_0 z) (v_529_0 z) (z 918) (z 919) 64 [8, 1] (by rw [h_529_0 z z_]; rfl)]
   exact i_76 z z_
 #a h_741_1
 attribute [local irreducible] v_741_1
 theorem w_741_2 (z : Store) : (s_742 z) 954 = v_741_2 z := by
   unfold s_742
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_741_2, r_741_0 z, r_741_1 z, r_741_2 z, r_741_3 z] <;> rfl
 #a w_741_2
 theorem h_741_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_741_2 z).shape = [64] := by
   unfold v_741_2
   rw [bw_layernorm_db_shape (v_740_0 z) (v_529_0 z) (z 918) (z 919) 64 [8, 1] (by rw [h_529_0 z z_]; rfl)]
   exact i_77 z z_
 #a h_741_2
 attribute [local irreducible] v_741_2
 attribute [local irreducible] s_742
 theorem r_742_0 (z : Store) : (s_742 z) 793 = (v_738_0 z) := pR (k_741 z) (pR (k_740 z) (pR (k_739 z) (w_738_0 z)))
 #a r_742_0
 theorem r_742_1 (z : Store) : (s_742 z) 1096 = (v_741_0 z) := w_741_0 z
 #a r_742_1
 def v_742_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_738_0 z), (v_741_0 z)]
 theorem g_742 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_632) (s_742 z) pmNode_632 1 2 898 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_632, r_742_0 z, r_742_1 z, h_738_0 z z_, h_741_0 z z_]
 #a g_742
 def s_743 (z : Store) : Store := pL [2, 3] (s_742 z) pmNode_632 1 2
 theorem t_742 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_632) (pmPeers pmNode_632) (s_742 z) pmNode_632 none = some (s_743 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_632) (s_742 z) pmNode_632).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 898 (by decide) (g_742 z z_)]
   rfl
 #a t_742
 theorem k_742 (z : Store) (tid : Tid) (h : tid ∉ [898]) : (s_743 z) tid = (s_742 z) tid := by
   unfold s_743
   dsimp only [pL, pmNode_632, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_742
 theorem w_742_0 (z : Store) : (s_743 z) 898 = v_742_0 z := by
   unfold s_743
   dsimp only [pL, pmNode_632, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_742_0, r_742_0 z, r_742_1 z] <;> rfl
 #a w_742_0
 theorem h_742_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_742_0 z).shape = [1, 16, 32] := by
   unfold v_742_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_738_0 z z_]
 #a h_742_0
 attribute [local irreducible] v_742_0
 attribute [local irreducible] s_743
 record_prefix_opacity v_736_0 s_737 v_737_0 s_738 v_738_0 v_738_1 v_738_2 s_739 v_739_0 s_740 v_740_0 s_741 v_741_0 v_741_1 v_741_2 s_742 v_742_0 s_743

 end
 end TrainVerify.Denote.RuntimeWorld
