import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0019
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_148_0 (z : Store) : (s_148 z) 222 = (v_144_0 z) := pR (k_147 z) (pR (k_146 z) (pR (k_145 z) (w_144_0 z)))
 #a r_148_0
 theorem r_148_1 (z : Store) : (s_148 z) 525 = (v_147_0 z) := w_147_0 z
 #a r_148_1
 def v_148_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_144_0 z), (v_147_0 z)]
 theorem g_148 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_74) (s_148 z) pmNode_74 2 1 224 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_74, r_148_0 z, r_148_1 z, h_144_0 z z_, h_147_0 z z_]
 #a g_148
 def s_149 (z : Store) : Store := pL [0, 1] (s_148 z) pmNode_74 2 1
 theorem t_148 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_74) (pmPeers pmNode_74) (s_148 z) pmNode_74 none = some (s_149 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_74) (s_148 z) pmNode_74).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 224 (by decide) (g_148 z z_)]
   rfl
 #a t_148
 theorem k_148 (z : Store) (tid : Tid) (h : tid ∉ [224]) : (s_149 z) tid = (s_148 z) tid := by
   unfold s_149
   dsimp only [pL, pmNode_74, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_148
 theorem w_148_0 (z : Store) : (s_149 z) 224 = v_148_0 z := by
   unfold s_149
   dsimp only [pL, pmNode_74, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_148_0, r_148_0 z, r_148_1 z] <;> rfl
 #a w_148_0
 theorem h_148_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_148_0 z).shape = [1, 2, 16, 16] := by
   unfold v_148_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_144_0 z z_]
 #a h_148_0
 attribute [local irreducible] v_148_0
 attribute [local irreducible] s_149
 theorem n_144_148 (z : Store) (tid : Tid) (h : tid ∉ ([222, 521, 522, 525] : List Tid)) : (s_148 z) tid = (s_144 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_144 z) (k_145 z)) (pF _ _ _ _ _ (k_146 z) (k_147 z)) tid h
 #a n_144_148
 theorem n_128_144 (z : Store) (tid : Tid) (h : tid ∉ ([206, 207, 505, 506, 509, 510, 210, 211, 214, 215, 513, 514, 517, 518, 218, 219] : List Tid)) : (s_144 z) tid = (s_128 z) tid := by
   exact pF _ _ _ _ _ (n_128_136 z) (n_136_144 z) tid h
 #a n_128_144
 theorem r_149_0 (z : Store) : (s_149 z) 203 = (v_127_0 z) := pR (k_148 z) (pR (n_144_148 z) (pR (n_128_144 z) (w_127_0 z)))
 #a r_149_0
 theorem r_149_1 (z : Store) : (s_149 z) 224 = (v_148_0 z) := w_148_0 z
 #a r_149_1
 def v_149_0 (z : Store) : Tensor := fw_matmul (v_127_0 z) (v_148_0 z)
 def s_150 (z : Store) : Store := storeSet (s_149 z) [(225, fw_matmul ((s_149 z) 203) ((s_149 z) 224))]
 theorem t_149 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_75) (pmPeers pmNode_75) (s_149 z) pmNode_75 none = some (s_150 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_149
 theorem k_149 (z : Store) (tid : Tid) (h : tid ∉ [225]) : (s_150 z) tid = (s_149 z) tid := by
   unfold s_150
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_149
 theorem w_149_0 (z : Store) : (s_150 z) 225 = v_149_0 z := by
   unfold s_150
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_149_0, r_149_0 z, r_149_1 z] <;> rfl
 #a w_149_0
 theorem h_149_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_149_0 z).shape = [1, 2, 16, 16] := by
   unfold v_149_0
   unfold fw_matmul batchedMatmul
   rw [h_127_0 z z_, h_148_0 z z_]
   rfl
 #a h_149_0
 attribute [local irreducible] v_149_0
 attribute [local irreducible] s_150
 theorem r_150_0 (z : Store) : (s_150 z) 222 = (v_144_0 z) := pR (k_149 z) (pR (k_148 z) (r_148_0 z))
 #a r_150_0
 theorem r_150_1 (z : Store) : (s_150 z) 525 = (v_147_0 z) := pR (k_149 z) (pR (k_148 z) (r_148_1 z))
 #a r_150_1
 def v_150_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_144_0 z), (v_147_0 z)]
 theorem g_150 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_310) (s_150 z) pmNode_310 2 1 527 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_310, r_150_0 z, r_150_1 z, h_144_0 z z_, h_147_0 z z_]
 #a g_150
 def s_151 (z : Store) : Store := pL [0, 1] (s_150 z) pmNode_310 2 1
 theorem t_150 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_310) (pmPeers pmNode_310) (s_150 z) pmNode_310 none = some (s_151 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_310) (s_150 z) pmNode_310).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 527 (by decide) (g_150 z z_)]
   rfl
 #a t_150
 theorem k_150 (z : Store) (tid : Tid) (h : tid ∉ [527]) : (s_151 z) tid = (s_150 z) tid := by
   unfold s_151
   dsimp only [pL, pmNode_310, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_150
 theorem w_150_0 (z : Store) : (s_151 z) 527 = v_150_0 z := by
   unfold s_151
   dsimp only [pL, pmNode_310, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_150_0, r_150_0 z, r_150_1 z] <;> rfl
 #a w_150_0
 theorem h_150_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_150_0 z).shape = [1, 2, 16, 16] := by
   unfold v_150_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_144_0 z z_]
 #a h_150_0
 attribute [local irreducible] v_150_0
 attribute [local irreducible] s_151
 theorem r_151_0 (z : Store) : (s_151 z) 506 = (v_131_0 z) := pR (k_150 z) (pR (k_149 z) (pR (k_148 z) (pR (n_144_148 z) (pR (n_136_144 z) (pR (n_132_136 z) (w_131_0 z))))))
 #a r_151_0
 theorem r_151_1 (z : Store) : (s_151 z) 527 = (v_150_0 z) := w_150_0 z
 #a r_151_1
 def v_151_0 (z : Store) : Tensor := fw_matmul (v_131_0 z) (v_150_0 z)
 def s_152 (z : Store) : Store := storeSet (s_151 z) [(528, fw_matmul ((s_151 z) 506) ((s_151 z) 527))]
 theorem t_151 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_311) (pmPeers pmNode_311) (s_151 z) pmNode_311 none = some (s_152 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_151
 theorem k_151 (z : Store) (tid : Tid) (h : tid ∉ [528]) : (s_152 z) tid = (s_151 z) tid := by
   unfold s_152
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_151
 theorem w_151_0 (z : Store) : (s_152 z) 528 = v_151_0 z := by
   unfold s_152
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_151_0, r_151_0 z, r_151_1 z] <;> rfl
 #a w_151_0
 theorem h_151_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_151_0 z).shape = [1, 2, 16, 16] := by
   unfold v_151_0
   unfold fw_matmul batchedMatmul
   rw [h_131_0 z z_, h_150_0 z z_]
   rfl
 #a h_151_0
 attribute [local irreducible] v_151_0
 attribute [local irreducible] s_152
 theorem r_152_0 (z : Store) : (s_152 z) 225 = (v_149_0 z) := pR (k_151 z) (pR (k_150 z) (w_149_0 z))
 #a r_152_0
 theorem r_152_1 (z : Store) : (s_152 z) 528 = (v_151_0 z) := w_151_0 z
 #a r_152_1
 def v_152_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_149_0 z), (v_151_0 z)]
 theorem g_152 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_76) (s_152 z) pmNode_76 1 3 228 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_76, r_152_0 z, r_152_1 z, h_149_0 z z_, h_151_0 z z_]
 #a g_152
 def s_153 (z : Store) : Store := pL [0, 1] (s_152 z) pmNode_76 1 3
 theorem t_152 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_76) (pmPeers pmNode_76) (s_152 z) pmNode_76 none = some (s_153 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_76) (s_152 z) pmNode_76).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 228 (by decide) (g_152 z z_)]
   rfl
 #a t_152
 theorem k_152 (z : Store) (tid : Tid) (h : tid ∉ [228]) : (s_153 z) tid = (s_152 z) tid := by
   unfold s_153
   dsimp only [pL, pmNode_76, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_152
 theorem w_152_0 (z : Store) : (s_153 z) 228 = v_152_0 z := by
   unfold s_153
   dsimp only [pL, pmNode_76, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_152_0, r_152_0 z, r_152_1 z] <;> rfl
 #a w_152_0
 theorem h_152_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_152_0 z).shape = [1, 4, 16, 8] := by
   unfold v_152_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_149_0 z z_]
 #a h_152_0
 attribute [local irreducible] v_152_0
 attribute [local irreducible] s_153
 theorem r_153_0 (z : Store) : (s_153 z) 228 = (v_152_0 z) := w_152_0 z
 #a r_153_0
 def v_153_0 (z : Store) : Tensor := fw_div ((4 : Nat) : Scalar) (v_152_0 z)
 def s_154 (z : Store) : Store := storeSet (s_153 z) [(229, fw_div ((4 : Nat) : Scalar) ((s_153 z) 228))]
 theorem t_153 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_77) (pmPeers pmNode_77) (s_153 z) pmNode_77 none = some (s_154 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_153
 theorem k_153 (z : Store) (tid : Tid) (h : tid ∉ [229]) : (s_154 z) tid = (s_153 z) tid := by
   unfold s_154
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_153
 theorem w_153_0 (z : Store) : (s_154 z) 229 = v_153_0 z := by
   unfold s_154
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_153_0, r_153_0 z] <;> rfl
 #a w_153_0
 theorem h_153_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_153_0 z).shape = [1, 4, 16, 8] := by
   unfold v_153_0
   exact h_152_0 z z_
 #a h_153_0
 attribute [local irreducible] v_153_0
 attribute [local irreducible] s_154
 theorem r_154_0 (z : Store) : (s_154 z) 225 = (v_149_0 z) := pR (k_153 z) (pR (k_152 z) (r_152_0 z))
 #a r_154_0
 theorem r_154_1 (z : Store) : (s_154 z) 528 = (v_151_0 z) := pR (k_153 z) (pR (k_152 z) (r_152_1 z))
 #a r_154_1
 def v_154_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_149_0 z), (v_151_0 z)]
 theorem g_154 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_312) (s_154 z) pmNode_312 1 3 531 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_312, r_154_0 z, r_154_1 z, h_149_0 z z_, h_151_0 z z_]
 #a g_154
 def s_155 (z : Store) : Store := pL [0, 1] (s_154 z) pmNode_312 1 3
 theorem t_154 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_312) (pmPeers pmNode_312) (s_154 z) pmNode_312 none = some (s_155 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_312) (s_154 z) pmNode_312).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 531 (by decide) (g_154 z z_)]
   rfl
 #a t_154
 theorem k_154 (z : Store) (tid : Tid) (h : tid ∉ [531]) : (s_155 z) tid = (s_154 z) tid := by
   unfold s_155
   dsimp only [pL, pmNode_312, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_154
 theorem w_154_0 (z : Store) : (s_155 z) 531 = v_154_0 z := by
   unfold s_155
   dsimp only [pL, pmNode_312, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_154_0, r_154_0 z, r_154_1 z] <;> rfl
 #a w_154_0
 theorem h_154_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_154_0 z).shape = [1, 4, 16, 8] := by
   unfold v_154_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_149_0 z z_]
 #a h_154_0
 attribute [local irreducible] v_154_0
 attribute [local irreducible] s_155
 theorem r_155_0 (z : Store) : (s_155 z) 531 = (v_154_0 z) := w_154_0 z
 #a r_155_0
 def v_155_0 (z : Store) : Tensor := fw_div ((4 : Nat) : Scalar) (v_154_0 z)
 def s_156 (z : Store) : Store := storeSet (s_155 z) [(532, fw_div ((4 : Nat) : Scalar) ((s_155 z) 531))]
 theorem t_155 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_313) (pmPeers pmNode_313) (s_155 z) pmNode_313 none = some (s_156 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_155
 theorem k_155 (z : Store) (tid : Tid) (h : tid ∉ [532]) : (s_156 z) tid = (s_155 z) tid := by
   unfold s_156
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_155
 theorem w_155_0 (z : Store) : (s_156 z) 532 = v_155_0 z := by
   unfold s_156
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_155_0, r_155_0 z] <;> rfl
 #a w_155_0
 theorem h_155_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_155_0 z).shape = [1, 4, 16, 8] := by
   unfold v_155_0
   exact h_154_0 z z_
 #a h_155_0
 attribute [local irreducible] v_155_0
 attribute [local irreducible] s_156
 theorem r_156_0 (z : Store) : (s_156 z) 229 = (v_153_0 z) := pR (k_155 z) (pR (k_154 z) (w_153_0 z))
 #a r_156_0
 theorem r_156_1 (z : Store) : (s_156 z) 532 = (v_155_0 z) := w_155_0 z
 #a r_156_1
 def v_156_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 2 [(v_153_0 z), (v_155_0 z)]
 theorem g_156 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_78) (s_156 z) pmNode_78 3 2 232 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_78, r_156_0 z, r_156_1 z, h_153_0 z z_, h_155_0 z z_]
 #a g_156
 def s_157 (z : Store) : Store := pL [0, 1] (s_156 z) pmNode_78 3 2
 theorem t_156 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_78) (pmPeers pmNode_78) (s_156 z) pmNode_78 none = some (s_157 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_78) (s_156 z) pmNode_78).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 2 232 (by decide) (g_156 z z_)]
   rfl
 #a t_156
 theorem k_156 (z : Store) (tid : Tid) (h : tid ∉ [232]) : (s_157 z) tid = (s_156 z) tid := by
   unfold s_157
   dsimp only [pL, pmNode_78, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_156
 theorem w_156_0 (z : Store) : (s_157 z) 232 = v_156_0 z := by
   unfold s_157
   dsimp only [pL, pmNode_78, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_156_0, r_156_0 z, r_156_1 z] <;> rfl
 #a w_156_0
 theorem h_156_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_156_0 z).shape = [1, 4, 8, 16] := by
   unfold v_156_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_153_0 z z_]
 #a h_156_0
 attribute [local irreducible] v_156_0
 attribute [local irreducible] s_157
 record_prefix_opacity v_148_0 s_149 v_149_0 s_150 v_150_0 s_151 v_151_0 s_152 v_152_0 s_153 v_153_0 s_154 v_154_0 s_155 v_155_0 s_156 v_156_0 s_157

 end
 end TrainVerify.Denote.RuntimeWorld
