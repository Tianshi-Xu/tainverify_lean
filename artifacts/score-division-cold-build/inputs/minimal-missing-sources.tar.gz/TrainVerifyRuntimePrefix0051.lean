import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0050
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_394_0 (z : Store) : (s_394 z) 110 = (v_382_0 z) := pR (k_393 z) (pR (k_392 z) (pR (n_384_392 z) (pR (k_383 z) (w_382_0 z))))
 #a r_394_0
 theorem r_394_1 (z : Store) : (s_394 z) 87 = (v_23_0 z) := pR (k_393 z) (pR (k_392 z) (pR (n_384_392 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_24_32 z) (r_24_0 z))))))))
 #a r_394_1
 theorem r_394_2 (z : Store) : (s_394 z) 30 = (z 30) := pR (k_393 z) (pR (k_392 z) (pR (n_384_392 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_24_32 z) (r_24_1 z))))))))
 #a r_394_2
 def v_394_0 (z : Store) : Tensor := (bw_linear (v_382_0 z) (v_23_0 z) (z 30)).1
 def v_394_1 (z : Store) : Tensor := (bw_linear (v_382_0 z) (v_23_0 z) (z 30)).2
 def s_395 (z : Store) : Store := storeSet (s_394 z) [(111, (bw_linear ((s_394 z) 110) ((s_394 z) 87) ((s_394 z) 30)).1), (31, (bw_linear ((s_394 z) 110) ((s_394 z) 87) ((s_394 z) 30)).2)]
 theorem t_394 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_198) (pmPeers pmNode_198) (s_394 z) pmNode_198 none = some (s_395 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_394
 theorem k_394 (z : Store) (tid : Tid) (h : tid ∉ [111, 31]) : (s_395 z) tid = (s_394 z) tid := by
   unfold s_395
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_394
 theorem w_394_0 (z : Store) : (s_395 z) 111 = v_394_0 z := by
   unfold s_395
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_394_0, r_394_0 z, r_394_1 z, r_394_2 z] <;> rfl
 #a w_394_0
 theorem h_394_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_394_0 z).shape = [1, 16, 64] := by
   unfold v_394_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_382_0 z) (v_23_0 z) (z 30) (h_382_0 z z_) (h_23_0 z z_) (i_10 z z_)
 #a h_394_0
 attribute [local irreducible] v_394_0
 theorem w_394_1 (z : Store) : (s_395 z) 31 = v_394_1 z := by
   unfold s_395
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_394_1, r_394_0 z, r_394_1 z, r_394_2 z] <;> rfl
 #a w_394_1
 theorem h_394_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_394_1 z).shape = [32, 64] := by
   unfold v_394_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_382_0 z) (v_23_0 z) (z 30) (h_382_0 z z_) (h_23_0 z z_) (i_10 z z_)
 #a h_394_1
 attribute [local irreducible] v_394_1
 attribute [local irreducible] s_395
 theorem r_395_0 (z : Store) : (s_395 z) 116 = (v_388_0 z) := pR (k_394 z) (pR (k_393 z) (pR (k_392 z) (r_392_0 z)))
 #a r_395_0
 theorem r_395_1 (z : Store) : (s_395 z) 419 = (v_391_0 z) := pR (k_394 z) (pR (k_393 z) (pR (k_392 z) (r_392_1 z)))
 #a r_395_1
 def v_395_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_388_0 z), (v_391_0 z)]
 theorem g_395 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_432) (s_395 z) pmNode_432 3 1 416 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_432, r_395_0 z, r_395_1 z, h_388_0 z z_, h_391_0 z z_]
 #a g_395
 def s_396 (z : Store) : Store := pL [0, 1] (s_395 z) pmNode_432 3 1
 theorem t_395 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_432) (pmPeers pmNode_432) (s_395 z) pmNode_432 none = some (s_396 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_432) (s_395 z) pmNode_432).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 416 (by decide) (g_395 z z_)]
   rfl
 #a t_395
 theorem k_395 (z : Store) (tid : Tid) (h : tid ∉ [416]) : (s_396 z) tid = (s_395 z) tid := by
   unfold s_396
   dsimp only [pL, pmNode_432, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_395
 theorem w_395_0 (z : Store) : (s_396 z) 416 = v_395_0 z := by
   unfold s_396
   dsimp only [pL, pmNode_432, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_395_0, r_395_0 z, r_395_1 z] <;> rfl
 #a w_395_0
 theorem h_395_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_395_0 z).shape = [1, 8, 4, 16] := by
   unfold v_395_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_388_0 z z_]
 #a h_395_0
 attribute [local irreducible] v_395_0
 attribute [local irreducible] s_396
 theorem n_392_396 (z : Store) (tid : Tid) (h : tid ∉ ([113, 105, 111, 31, 416] : List Tid)) : (s_396 z) tid = (s_392 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_392 z) (k_393 z)) (pF _ _ _ _ _ (k_394 z) (k_395 z)) tid h
 #a n_392_396
 theorem r_396_0 (z : Store) : (s_396 z) 416 = (v_395_0 z) := w_395_0 z
 #a r_396_0
 theorem r_396_1 (z : Store) : (s_396 z) 406 = (v_26_0 z) := pR (n_392_396 z) (pR (n_384_392 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (k_31 z) (r_31_0 z)))))))
 #a r_396_1
 def v_396_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_395_0 z)
 def s_397 (z : Store) : Store := storeSet (s_396 z) [(408, fw_view [1, 8, 64] ((s_396 z) 416))]
 theorem t_396 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_433) (pmPeers pmNode_433) (s_396 z) pmNode_433 none = some (s_397 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_396
 theorem k_396 (z : Store) (tid : Tid) (h : tid ∉ [408]) : (s_397 z) tid = (s_396 z) tid := by
   unfold s_397
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_396
 theorem w_396_0 (z : Store) : (s_397 z) 408 = v_396_0 z := by
   unfold s_397
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_396_0, r_396_0 z, r_396_1 z] <;> rfl
 #a w_396_0
 theorem h_396_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_396_0 z).shape = [1, 8, 64] := by
   unfold v_396_0
   rfl
 #a h_396_0
 attribute [local irreducible] v_396_0
 attribute [local irreducible] s_397
 theorem r_397_0 (z : Store) : (s_397 z) 414 = (v_384_0 z) := pR (k_396 z) (pR (n_392_396 z) (pR (n_388_392 z) (pR (k_387 z) (pR (k_386 z) (pR (k_385 z) (w_384_0 z))))))
 #a r_397_0
 theorem r_397_1 (z : Store) : (s_397 z) 390 = (v_29_0 z) := pR (k_396 z) (pR (n_392_396 z) (pR (n_384_392 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (k_31 z) (pR (k_30 z) (r_30_0 z)))))))))
 #a r_397_1
 theorem r_397_2 (z : Store) : (s_397 z) 333 = (z 333) := pR (k_396 z) (pR (n_392_396 z) (pR (n_384_392 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (k_31 z) (pR (k_30 z) (r_30_1 z)))))))))
 #a r_397_2
 def v_397_0 (z : Store) : Tensor := (bw_linear (v_384_0 z) (v_29_0 z) (z 333)).1
 def v_397_1 (z : Store) : Tensor := (bw_linear (v_384_0 z) (v_29_0 z) (z 333)).2
 def s_398 (z : Store) : Store := storeSet (s_397 z) [(413, (bw_linear ((s_397 z) 414) ((s_397 z) 390) ((s_397 z) 333)).1), (334, (bw_linear ((s_397 z) 414) ((s_397 z) 390) ((s_397 z) 333)).2)]
 theorem t_397 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_434) (pmPeers pmNode_434) (s_397 z) pmNode_434 none = some (s_398 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_397
 theorem k_397 (z : Store) (tid : Tid) (h : tid ∉ [413, 334]) : (s_398 z) tid = (s_397 z) tid := by
   unfold s_398
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_397
 theorem w_397_0 (z : Store) : (s_398 z) 413 = v_397_0 z := by
   unfold s_398
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_397_0, r_397_0 z, r_397_1 z, r_397_2 z] <;> rfl
 #a w_397_0
 theorem h_397_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_397_0 z).shape = [1, 16, 64] := by
   unfold v_397_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_384_0 z) (v_29_0 z) (z 333) (h_384_0 z z_) (h_29_0 z z_) (i_13 z z_)
 #a h_397_0
 attribute [local irreducible] v_397_0
 theorem w_397_1 (z : Store) : (s_398 z) 334 = v_397_1 z := by
   unfold s_398
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_397_1, r_397_0 z, r_397_1 z, r_397_2 z] <;> rfl
 #a w_397_1
 theorem h_397_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_397_1 z).shape = [32, 64] := by
   unfold v_397_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_384_0 z) (v_29_0 z) (z 333) (h_384_0 z z_) (h_29_0 z z_) (i_13 z z_)
 #a h_397_1
 attribute [local irreducible] v_397_1
 attribute [local irreducible] s_398
 theorem r_398_0 (z : Store) : (s_398 z) 111 = (v_394_0 z) := pR (k_397 z) (pR (k_396 z) (pR (k_395 z) (w_394_0 z)))
 #a r_398_0
 theorem r_398_1 (z : Store) : (s_398 z) 413 = (v_397_0 z) := w_397_0 z
 #a r_398_1
 def v_398_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_394_0 z), (v_397_0 z)]
 def s_399 (z : Store) : Store := storeSet (s_398 z) [(288, reduceScatterPrimDimN 1 2 0 [((s_398 z) 111), ((s_398 z) 413)])]
 theorem t_398 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_199) (pmPeers pmNode_199) (s_398 z) pmNode_199 none = some (s_399 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_398 z) pmNode_199 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_398
 theorem k_398 (z : Store) (tid : Tid) (h : tid ∉ [288]) : (s_399 z) tid = (s_398 z) tid := by
   unfold s_399
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_398
 theorem w_398_0 (z : Store) : (s_399 z) 288 = v_398_0 z := by
   unfold s_399
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_398_0, r_398_0 z, r_398_1 z] <;> rfl
 #a w_398_0
 theorem h_398_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_398_0 z).shape = [1, 8, 64] := by
   unfold v_398_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_394_0 z) rfl]
     exact h_394_0 z z_
   · decide
 #a h_398_0
 attribute [local irreducible] v_398_0
 attribute [local irreducible] s_399
 theorem r_399_0 (z : Store) : (s_399 z) 107 = (v_387_0 z) := pR (k_398 z) (pR (k_397 z) (pR (k_396 z) (pR (n_392_396 z) (pR (n_388_392 z) (w_387_0 z)))))
 #a r_399_0
 theorem r_399_1 (z : Store) : (s_399 z) 86 = (v_21_0 z) := pR (k_398 z) (pR (k_397 z) (pR (k_396 z) (pR (n_392_396 z) (pR (n_384_392 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_24_32 z) (pR (k_23 z) (pR (k_22 z) (r_22_0 z))))))))))))
 #a r_399_1
 theorem r_399_2 (z : Store) : (s_399 z) 27 = (z 27) := pR (k_398 z) (pR (k_397 z) (pR (k_396 z) (pR (n_392_396 z) (pR (n_384_392 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_24_32 z) (pR (k_23 z) (pR (k_22 z) (r_22_1 z))))))))))))
 #a r_399_2
 def v_399_0 (z : Store) : Tensor := (bw_linear (v_387_0 z) (v_21_0 z) (z 27)).1
 def v_399_1 (z : Store) : Tensor := (bw_linear (v_387_0 z) (v_21_0 z) (z 27)).2
 def s_400 (z : Store) : Store := storeSet (s_399 z) [(108, (bw_linear ((s_399 z) 107) ((s_399 z) 86) ((s_399 z) 27)).1), (28, (bw_linear ((s_399 z) 107) ((s_399 z) 86) ((s_399 z) 27)).2)]
 theorem t_399 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_200) (pmPeers pmNode_200) (s_399 z) pmNode_200 none = some (s_400 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_399
 theorem k_399 (z : Store) (tid : Tid) (h : tid ∉ [108, 28]) : (s_400 z) tid = (s_399 z) tid := by
   unfold s_400
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_399
 theorem w_399_0 (z : Store) : (s_400 z) 108 = v_399_0 z := by
   unfold s_400
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_399_0, r_399_0 z, r_399_1 z, r_399_2 z] <;> rfl
 #a w_399_0
 theorem h_399_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_399_0 z).shape = [1, 16, 64] := by
   unfold v_399_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_387_0 z) (v_21_0 z) (z 27) (h_387_0 z z_) (h_21_0 z z_) (i_9 z z_)
 #a h_399_0
 attribute [local irreducible] v_399_0
 theorem w_399_1 (z : Store) : (s_400 z) 28 = v_399_1 z := by
   unfold s_400
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_399_1, r_399_0 z, r_399_1 z, r_399_2 z] <;> rfl
 #a w_399_1
 theorem h_399_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_399_1 z).shape = [32, 64] := by
   unfold v_399_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_387_0 z) (v_21_0 z) (z 27) (h_387_0 z z_) (h_21_0 z z_) (i_9 z z_)
 #a h_399_1
 attribute [local irreducible] v_399_1
 attribute [local irreducible] s_400
 theorem r_400_0 (z : Store) : (s_400 z) 111 = (v_394_0 z) := pR (k_399 z) (pR (k_398 z) (r_398_0 z))
 #a r_400_0
 theorem r_400_1 (z : Store) : (s_400 z) 413 = (v_397_0 z) := pR (k_399 z) (pR (k_398 z) (r_398_1 z))
 #a r_400_1
 def v_400_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_394_0 z), (v_397_0 z)]
 def s_401 (z : Store) : Store := storeSet (s_400 z) [(591, reduceScatterPrimDimN 1 2 1 [((s_400 z) 111), ((s_400 z) 413)])]
 theorem t_400 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_435) (pmPeers pmNode_435) (s_400 z) pmNode_435 none = some (s_401 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_400 z) pmNode_435 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_400
 theorem k_400 (z : Store) (tid : Tid) (h : tid ∉ [591]) : (s_401 z) tid = (s_400 z) tid := by
   unfold s_401
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_400
 theorem w_400_0 (z : Store) : (s_401 z) 591 = v_400_0 z := by
   unfold s_401
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_400_0, r_400_0 z, r_400_1 z] <;> rfl
 #a w_400_0
 theorem h_400_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_400_0 z).shape = [1, 8, 64] := by
   unfold v_400_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_394_0 z) rfl]
     exact h_394_0 z z_
   · decide
 #a h_400_0
 attribute [local irreducible] v_400_0
 attribute [local irreducible] s_401
 theorem n_396_400 (z : Store) (tid : Tid) (h : tid ∉ ([408, 413, 334, 288, 108, 28] : List Tid)) : (s_400 z) tid = (s_396 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_396 z) (k_397 z)) (pF _ _ _ _ _ (k_398 z) (k_399 z)) tid h
 #a n_396_400
 theorem n_392_400 (z : Store) (tid : Tid) (h : tid ∉ ([113, 105, 111, 31, 416, 408, 413, 334, 288, 108, 28] : List Tid)) : (s_400 z) tid = (s_392 z) tid := by
   exact pF _ _ _ _ _ (n_392_396 z) (n_396_400 z) tid h
 #a n_392_400
 theorem n_384_400 (z : Store) (tid : Tid) (h : tid ∉ ([414, 425, 119, 107, 116, 422, 411, 419, 113, 105, 111, 31, 416, 408, 413, 334, 288, 108, 28] : List Tid)) : (s_400 z) tid = (s_384 z) tid := by
   exact pF _ _ _ _ _ (n_384_392 z) (n_392_400 z) tid h
 #a n_384_400
 record_prefix_opacity v_394_0 v_394_1 s_395 v_395_0 s_396 v_396_0 s_397 v_397_0 v_397_1 s_398 v_398_0 s_399 v_399_0 v_399_1 s_400 v_400_0 s_401

 end
 end TrainVerify.Denote.RuntimeWorld
