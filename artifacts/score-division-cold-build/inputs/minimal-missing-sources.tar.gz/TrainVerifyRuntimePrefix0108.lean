import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0107
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_846_0 (z : Store) : (s_846 z) 59 = (v_237_1 z) := pR (k_845 z) (pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_240_256 z) (pR (k_239 z) (pR (k_238 z) (w_237_1 z))))))))))
 #a r_846_0
 theorem r_846_1 (z : Store) : (s_846 z) 362 = (v_239_1 z) := pR (k_845 z) (pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_240_256 z) (w_239_1 z))))))))
 #a r_846_1
 theorem r_846_2 (z : Store) : (s_846 z) 665 = (v_659_1 z) := pR (k_845 z) (pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_664_672 z) (pR (n_660_664 z) (w_659_1 z)))))))))
 #a r_846_2
 theorem r_846_3 (z : Store) : (s_846 z) 968 = (v_661_1 z) := pR (k_845 z) (pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_664_672 z) (pR (k_663 z) (pR (k_662 z) (w_661_1 z))))))))))
 #a r_846_3
 def v_846_0 (z : Store) : Tensor := cross_dp_wred [(v_237_1 z), (v_239_1 z), (v_659_1 z), (v_661_1 z)]
 theorem g_846 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_214) (s_846 z) pmNode_214 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_214, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_846_1 z, r_846_0 z]
     exact (h_239_1 z z_).trans (h_237_1 z z_).symm
   · rw [r_846_2 z, r_846_0 z]
     exact (h_659_1 z z_).trans (h_237_1 z z_).symm
   · rw [r_846_3 z, r_846_0 z]
     exact (h_661_1 z z_).trans (h_237_1 z z_).symm
 #a g_846
 def s_847 (z : Store) : Store := storeSet (s_846 z) [(60, cross_dp_wred [((s_846 z) 59), ((s_846 z) 362), ((s_846 z) 665), ((s_846 z) 968)])]
 theorem t_846 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_214) (pmPeers pmNode_214) (s_846 z) pmNode_214 none = some (s_847 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_214) (s_846 z) pmNode_214 = _
   rw [wredStep, if_pos ⟨by decide, g_846 z z_⟩]
   rfl
 #a t_846
 theorem k_846 (z : Store) (tid : Tid) (h : tid ∉ [60]) : (s_847 z) tid = (s_846 z) tid := by
   unfold s_847
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_846
 theorem w_846_0 (z : Store) : (s_847 z) 60 = v_846_0 z := by
   unfold s_847
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_846_0, r_846_0 z, r_846_1 z, r_846_2 z, r_846_3 z] <;> rfl
 #a w_846_0
 theorem h_846_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_846_0 z).shape = [64] := by
   unfold v_846_0
   rw [tensorSum_shape]
   exact h_237_1 z z_
 #a h_846_0
 attribute [local irreducible] v_846_0
 attribute [local irreducible] s_847
 theorem r_847_0 (z : Store) : (s_847 z) 25 = (v_403_1 z) := pR (k_846 z) (pR (k_845 z) (pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_416_448 z) (pR (n_408_416 z) (pR (n_404_408 z) (w_403_1 z)))))))))))
 #a r_847_0
 theorem r_847_1 (z : Store) : (s_847 z) 328 = (v_407_1 z) := pR (k_846 z) (pR (k_845 z) (pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_416_448 z) (pR (n_408_416 z) (w_407_1 z))))))))))
 #a r_847_1
 theorem r_847_2 (z : Store) : (s_847 z) 631 = (v_825_1 z) := pR (k_846 z) (pR (k_845 z) (pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (n_828_832 z) (pR (k_827 z) (pR (k_826 z) (w_825_1 z))))))))
 #a r_847_2
 theorem r_847_3 (z : Store) : (s_847 z) 934 = (v_829_1 z) := pR (k_846 z) (pR (k_845 z) (pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (k_831 z) (pR (k_830 z) (w_829_1 z)))))))
 #a r_847_3
 def v_847_0 (z : Store) : Tensor := cross_dp_wred [(v_403_1 z), (v_407_1 z), (v_825_1 z), (v_829_1 z)]
 theorem g_847 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_215) (s_847 z) pmNode_215 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_215, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_847_1 z, r_847_0 z]
     exact (h_407_1 z z_).trans (h_403_1 z z_).symm
   · rw [r_847_2 z, r_847_0 z]
     exact (h_825_1 z z_).trans (h_403_1 z z_).symm
   · rw [r_847_3 z, r_847_0 z]
     exact (h_829_1 z z_).trans (h_403_1 z z_).symm
 #a g_847
 def s_848 (z : Store) : Store := storeSet (s_847 z) [(26, cross_dp_wred [((s_847 z) 25), ((s_847 z) 328), ((s_847 z) 631), ((s_847 z) 934)])]
 theorem t_847 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_215) (pmPeers pmNode_215) (s_847 z) pmNode_215 none = some (s_848 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_215) (s_847 z) pmNode_215 = _
   rw [wredStep, if_pos ⟨by decide, g_847 z z_⟩]
   rfl
 #a t_847
 theorem k_847 (z : Store) (tid : Tid) (h : tid ∉ [26]) : (s_848 z) tid = (s_847 z) tid := by
   unfold s_848
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_847
 theorem w_847_0 (z : Store) : (s_848 z) 26 = v_847_0 z := by
   unfold s_848
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_847_0, r_847_0 z, r_847_1 z, r_847_2 z, r_847_3 z] <;> rfl
 #a w_847_0
 theorem h_847_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_847_0 z).shape = [64, 64] := by
   unfold v_847_0
   rw [tensorSum_shape]
   exact h_403_1 z z_
 #a h_847_0
 attribute [local irreducible] v_847_0
 attribute [local irreducible] s_848
 theorem n_844_848 (z : Store) (tid : Tid) (h : tid ∉ ([22, 24, 60, 26] : List Tid)) : (s_848 z) tid = (s_844 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_844 z) (k_845 z)) (pF _ _ _ _ _ (k_846 z) (k_847 z)) tid h
 #a n_844_848
 theorem n_840_848 (z : Store) (tid : Tid) (h : tid ∉ ([623, 1002, 928, 20, 22, 24, 60, 26] : List Tid)) : (s_848 z) tid = (s_840 z) tid := by
   exact pF _ _ _ _ _ (n_840_844 z) (n_844_848 z) tid h
 #a n_840_848
 theorem n_832_848 (z : Store) (tid : Tid) (h : tid ∉ ([890, 703, 696, 702, 1193, 1006, 999, 1005, 699, 625, 623, 1002, 928, 20, 22, 24, 60, 26] : List Tid)) : (s_848 z) tid = (s_832 z) tid := by
   exact pF _ _ _ _ _ (n_832_840 z) (n_840_848 z) tid h
 #a n_832_848
 theorem r_848_0 (z : Store) : (s_848 z) 61 = (v_237_2 z) := pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_240_256 z) (pR (k_239 z) (pR (k_238 z) (w_237_2 z)))))))
 #a r_848_0
 theorem r_848_1 (z : Store) : (s_848 z) 364 = (v_239_2 z) := pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_240_256 z) (w_239_2 z)))))
 #a r_848_1
 theorem r_848_2 (z : Store) : (s_848 z) 667 = (v_659_2 z) := pR (n_832_848 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_664_672 z) (pR (n_660_664 z) (w_659_2 z))))))
 #a r_848_2
 theorem r_848_3 (z : Store) : (s_848 z) 970 = (v_661_2 z) := pR (n_832_848 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_664_672 z) (pR (k_663 z) (pR (k_662 z) (w_661_2 z)))))))
 #a r_848_3
 def v_848_0 (z : Store) : Tensor := cross_dp_wred [(v_237_2 z), (v_239_2 z), (v_659_2 z), (v_661_2 z)]
 theorem g_848 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_216) (s_848 z) pmNode_216 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_216, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_848_1 z, r_848_0 z]
     exact (h_239_2 z z_).trans (h_237_2 z z_).symm
   · rw [r_848_2 z, r_848_0 z]
     exact (h_659_2 z z_).trans (h_237_2 z z_).symm
   · rw [r_848_3 z, r_848_0 z]
     exact (h_661_2 z z_).trans (h_237_2 z z_).symm
 #a g_848
 def s_849 (z : Store) : Store := storeSet (s_848 z) [(62, cross_dp_wred [((s_848 z) 61), ((s_848 z) 364), ((s_848 z) 667), ((s_848 z) 970)])]
 theorem t_848 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_216) (pmPeers pmNode_216) (s_848 z) pmNode_216 none = some (s_849 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_216) (s_848 z) pmNode_216 = _
   rw [wredStep, if_pos ⟨by decide, g_848 z z_⟩]
   rfl
 #a t_848
 theorem k_848 (z : Store) (tid : Tid) (h : tid ∉ [62]) : (s_849 z) tid = (s_848 z) tid := by
   unfold s_849
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_848
 theorem w_848_0 (z : Store) : (s_849 z) 62 = v_848_0 z := by
   unfold s_849
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_848_0, r_848_0 z, r_848_1 z, r_848_2 z, r_848_3 z] <;> rfl
 #a w_848_0
 theorem h_848_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_848_0 z).shape = [64] := by
   unfold v_848_0
   rw [tensorSum_shape]
   exact h_237_2 z z_
 #a h_848_0
 attribute [local irreducible] v_848_0
 attribute [local irreducible] s_849
 theorem r_849_0 (z : Store) : (s_849 z) 66 = (v_227_1 z) := pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_240_256 z) (pR (n_232_240 z) (pR (n_228_232 z) (w_227_1 z))))))))
 #a r_849_0
 theorem r_849_1 (z : Store) : (s_849 z) 369 = (v_230_1 z) := pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_240_256 z) (pR (n_232_240 z) (pR (k_231 z) (w_230_1 z))))))))
 #a r_849_1
 theorem r_849_2 (z : Store) : (s_849 z) 672 = (v_649_1 z) := pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_656_672 z) (pR (n_652_656 z) (pR (k_651 z) (pR (k_650 z) (w_649_1 z)))))))))
 #a r_849_2
 theorem r_849_3 (z : Store) : (s_849 z) 975 = (v_652_1 z) := pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_656_672 z) (pR (k_655 z) (pR (k_654 z) (pR (k_653 z) (w_652_1 z)))))))))
 #a r_849_3
 def v_849_0 (z : Store) : Tensor := cross_dp_wred [(v_227_1 z), (v_230_1 z), (v_649_1 z), (v_652_1 z)]
 theorem g_849 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_217) (s_849 z) pmNode_217 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_217, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_849_1 z, r_849_0 z]
     exact (h_230_1 z z_).trans (h_227_1 z z_).symm
   · rw [r_849_2 z, r_849_0 z]
     exact (h_649_1 z z_).trans (h_227_1 z z_).symm
   · rw [r_849_3 z, r_849_0 z]
     exact (h_652_1 z z_).trans (h_227_1 z z_).symm
 #a g_849
 def s_850 (z : Store) : Store := storeSet (s_849 z) [(67, cross_dp_wred [((s_849 z) 66), ((s_849 z) 369), ((s_849 z) 672), ((s_849 z) 975)])]
 theorem t_849 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_217) (pmPeers pmNode_217) (s_849 z) pmNode_217 none = some (s_850 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_217) (s_849 z) pmNode_217 = _
   rw [wredStep, if_pos ⟨by decide, g_849 z z_⟩]
   rfl
 #a t_849
 theorem k_849 (z : Store) (tid : Tid) (h : tid ∉ [67]) : (s_850 z) tid = (s_849 z) tid := by
   unfold s_850
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_849
 theorem w_849_0 (z : Store) : (s_850 z) 67 = v_849_0 z := by
   unfold s_850
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_849_0, r_849_0 z, r_849_1 z, r_849_2 z, r_849_3 z] <;> rfl
 #a w_849_0
 theorem h_849_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_849_0 z).shape = [64, 256] := by
   unfold v_849_0
   rw [tensorSum_shape]
   exact h_227_1 z z_
 #a h_849_0
 attribute [local irreducible] v_849_0
 attribute [local irreducible] s_850
 theorem r_850_0 (z : Store) : (s_850 z) 68 = (v_221_1 z) := pR (k_849 z) (pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_224_256 z) (pR (k_223 z) (pR (k_222 z) (w_221_1 z)))))))))
 #a r_850_0
 theorem r_850_1 (z : Store) : (s_850 z) 371 = (v_224_1 z) := pR (k_849 z) (pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_240_256 z) (pR (n_232_240 z) (pR (n_228_232 z) (pR (k_227 z) (pR (k_226 z) (pR (k_225 z) (w_224_1 z))))))))))))
 #a r_850_1
 theorem r_850_2 (z : Store) : (s_850 z) 674 = (v_643_1 z) := pR (k_849 z) (pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_656_672 z) (pR (n_648_656 z) (pR (n_644_648 z) (w_643_1 z)))))))))
 #a r_850_2
 theorem r_850_3 (z : Store) : (s_850 z) 977 = (v_646_1 z) := pR (k_849 z) (pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_656_672 z) (pR (n_648_656 z) (pR (k_647 z) (w_646_1 z)))))))))
 #a r_850_3
 def v_850_0 (z : Store) : Tensor := cross_dp_wred [(v_221_1 z), (v_224_1 z), (v_643_1 z), (v_646_1 z)]
 theorem g_850 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_218) (s_850 z) pmNode_218 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_218, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_850_1 z, r_850_0 z]
     exact (h_224_1 z z_).trans (h_221_1 z z_).symm
   · rw [r_850_2 z, r_850_0 z]
     exact (h_643_1 z z_).trans (h_221_1 z z_).symm
   · rw [r_850_3 z, r_850_0 z]
     exact (h_646_1 z z_).trans (h_221_1 z z_).symm
 #a g_850
 def s_851 (z : Store) : Store := storeSet (s_850 z) [(69, cross_dp_wred [((s_850 z) 68), ((s_850 z) 371), ((s_850 z) 674), ((s_850 z) 977)])]
 theorem t_850 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_218) (pmPeers pmNode_218) (s_850 z) pmNode_218 none = some (s_851 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_218) (s_850 z) pmNode_218 = _
   rw [wredStep, if_pos ⟨by decide, g_850 z z_⟩]
   rfl
 #a t_850
 theorem k_850 (z : Store) (tid : Tid) (h : tid ∉ [69]) : (s_851 z) tid = (s_850 z) tid := by
   unfold s_851
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_850
 theorem w_850_0 (z : Store) : (s_851 z) 69 = v_850_0 z := by
   unfold s_851
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_850_0, r_850_0 z, r_850_1 z, r_850_2 z, r_850_3 z] <;> rfl
 #a w_850_0
 theorem h_850_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_850_0 z).shape = [64] := by
   unfold v_850_0
   rw [tensorSum_shape]
   exact h_221_1 z z_
 #a h_850_0
 attribute [local irreducible] v_850_0
 attribute [local irreducible] s_851
 theorem r_851_0 (z : Store) : (s_851 z) 70 = (v_221_2 z) := pR (k_850 z) (pR (k_849 z) (pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_224_256 z) (pR (k_223 z) (pR (k_222 z) (w_221_2 z))))))))))
 #a r_851_0
 theorem r_851_1 (z : Store) : (s_851 z) 373 = (v_224_2 z) := pR (k_850 z) (pR (k_849 z) (pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_240_256 z) (pR (n_232_240 z) (pR (n_228_232 z) (pR (k_227 z) (pR (k_226 z) (pR (k_225 z) (w_224_2 z)))))))))))))
 #a r_851_1
 theorem r_851_2 (z : Store) : (s_851 z) 676 = (v_643_2 z) := pR (k_850 z) (pR (k_849 z) (pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_656_672 z) (pR (n_648_656 z) (pR (n_644_648 z) (w_643_2 z))))))))))
 #a r_851_2
 theorem r_851_3 (z : Store) : (s_851 z) 979 = (v_646_2 z) := pR (k_850 z) (pR (k_849 z) (pR (k_848 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_656_672 z) (pR (n_648_656 z) (pR (k_647 z) (w_646_2 z))))))))))
 #a r_851_3
 def v_851_0 (z : Store) : Tensor := cross_dp_wred [(v_221_2 z), (v_224_2 z), (v_643_2 z), (v_646_2 z)]
 theorem g_851 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_219) (s_851 z) pmNode_219 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_219, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_851_1 z, r_851_0 z]
     exact (h_224_2 z z_).trans (h_221_2 z z_).symm
   · rw [r_851_2 z, r_851_0 z]
     exact (h_643_2 z z_).trans (h_221_2 z z_).symm
   · rw [r_851_3 z, r_851_0 z]
     exact (h_646_2 z z_).trans (h_221_2 z z_).symm
 #a g_851
 def s_852 (z : Store) : Store := storeSet (s_851 z) [(71, cross_dp_wred [((s_851 z) 70), ((s_851 z) 373), ((s_851 z) 676), ((s_851 z) 979)])]
 theorem t_851 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_219) (pmPeers pmNode_219) (s_851 z) pmNode_219 none = some (s_852 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_219) (s_851 z) pmNode_219 = _
   rw [wredStep, if_pos ⟨by decide, g_851 z z_⟩]
   rfl
 #a t_851
 theorem k_851 (z : Store) (tid : Tid) (h : tid ∉ [71]) : (s_852 z) tid = (s_851 z) tid := by
   unfold s_852
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_851
 theorem w_851_0 (z : Store) : (s_852 z) 71 = v_851_0 z := by
   unfold s_852
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_851_0, r_851_0 z, r_851_1 z, r_851_2 z, r_851_3 z] <;> rfl
 #a w_851_0
 theorem h_851_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_851_0 z).shape = [64] := by
   unfold v_851_0
   rw [tensorSum_shape]
   exact h_221_2 z z_
 #a h_851_0
 attribute [local irreducible] v_851_0
 attribute [local irreducible] s_852
 theorem n_848_852 (z : Store) (tid : Tid) (h : tid ∉ ([62, 67, 69, 71] : List Tid)) : (s_852 z) tid = (s_848 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_848 z) (k_849 z)) (pF _ _ _ _ _ (k_850 z) (k_851 z)) tid h
 #a n_848_852
 record_prefix_opacity v_846_0 s_847 v_847_0 s_848 v_848_0 s_849 v_849_0 s_850 v_850_0 s_851 v_851_0 s_852

 end
 end TrainVerify.Denote.RuntimeWorld
