import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0116
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_909_0 (z : Store) : (s_909 z) 999 = (v_837_0 z) := pR (k_908 z) (pR (n_904_908 z) (pR (n_896_904 z) (pR (n_864_896 z) (pR (n_848_864 z) (pR (n_840_848 z) (pR (k_839 z) (pR (k_838 z) (w_837_0 z))))))))
 #a r_909_0
 theorem r_909_1 (z : Store) : (s_909 z) 984 = (v_426_0 z) := pR (k_908 z) (pR (n_904_908 z) (pR (n_896_904 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (n_428_432 z) (pR (k_427 z) (r_427_0 z)))))))))
 #a r_909_1
 theorem r_909_2 (z : Store) : (s_909 z) 925 = (z 925) := pR (k_908 z) (pR (n_904_908 z) (pR (n_896_904 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (n_428_432 z) (pR (k_427 z) (r_427_1 z)))))))))
 #a r_909_2
 def v_909_0 (z : Store) : Tensor := bw_embedding (v_837_0 z) (v_426_0 z) (z 925)
 def s_910 (z : Store) : Store := storeSet (s_909 z) [(926, bw_embedding ((s_909 z) 999) ((s_909 z) 984) ((s_909 z) 925))]
 theorem t_909 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_918) (pmPeers pmNode_918) (s_909 z) pmNode_918 none = some (s_910 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_909
 theorem k_909 (z : Store) (tid : Tid) (h : tid ∉ [926]) : (s_910 z) tid = (s_909 z) tid := by
   unfold s_910
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_909
 theorem w_909_0 (z : Store) : (s_910 z) 926 = v_909_0 z := by
   unfold s_910
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_909_0, r_909_0 z, r_909_1 z, r_909_2 z] <;> rfl
 #a w_909_0
 theorem h_909_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_909_0 z).shape = [256, 32] := by
   unfold v_909_0
   exact i_52 z z_
 #a h_909_0
 attribute [local irreducible] v_909_0
 attribute [local irreducible] s_910
 theorem r_910_0 (z : Store) : (s_910 z) 320 = (v_421_0 z) := pR (k_909 z) (pR (k_908 z) (pR (n_904_908 z) (pR (n_896_904 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (n_424_432 z) (pR (k_423 z) (pR (k_422 z) (w_421_0 z)))))))))))
 #a r_910_0
 theorem r_910_1 (z : Store) : (s_910 z) 926 = (v_909_0 z) := w_909_0 z
 #a r_910_1
 def v_910_0 (z : Store) : Tensor := cross_dp_wred [(v_421_0 z), (v_909_0 z)]
 theorem g_910 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_463) (s_910 z) pmNode_463 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_463, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_910_1 z, r_910_0 z]
     exact (h_909_0 z z_).trans (h_421_0 z z_).symm
 #a g_910
 def s_911 (z : Store) : Store := storeSet (s_910 z) [(321, cross_dp_wred [((s_910 z) 320), ((s_910 z) 926)])]
 theorem t_910 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_463) (pmPeers pmNode_463) (s_910 z) pmNode_463 none = some (s_911 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_463) (s_910 z) pmNode_463 = _
   rw [wredStep, if_pos ⟨by decide, g_910 z z_⟩]
   rfl
 #a t_910
 theorem k_910 (z : Store) (tid : Tid) (h : tid ∉ [321]) : (s_911 z) tid = (s_910 z) tid := by
   unfold s_911
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_910
 theorem w_910_0 (z : Store) : (s_911 z) 321 = v_910_0 z := by
   unfold s_911
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_910_0, r_910_0 z, r_910_1 z] <;> rfl
 #a w_910_0
 theorem h_910_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_910_0 z).shape = [256, 32] := by
   unfold v_910_0
   rw [tensorSum_shape]
   exact h_421_0 z z_
 #a h_910_0
 attribute [local irreducible] v_910_0
 attribute [local irreducible] s_911
 theorem r_911_0 (z : Store) : (s_911 z) 360 = (v_250_1 z) := pR (k_910 z) (pR (k_909 z) (pR (k_908 z) (pR (n_904_908 z) (pR (n_896_904 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_252_256 z) (pR (k_251 z) (w_250_1 z))))))))))
 #a r_911_0
 theorem r_911_1 (z : Store) : (s_911 z) 966 = (v_672_1 z) := pR (k_910 z) (pR (k_909 z) (pR (k_908 z) (pR (n_904_908 z) (pR (n_896_904 z) (pR (n_768_896 z) (pR (n_704_768 z) (pR (n_688_704 z) (pR (n_680_688 z) (pR (n_676_680 z) (pR (k_675 z) (pR (k_674 z) (pR (k_673 z) (w_672_1 z)))))))))))))
 #a r_911_1
 def v_911_0 (z : Store) : Tensor := cross_dp_wred [(v_250_1 z), (v_672_1 z)]
 theorem g_911 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_464) (s_911 z) pmNode_464 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_464, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_911_1 z, r_911_0 z]
     exact (h_672_1 z z_).trans (h_250_1 z z_).symm
 #a g_911
 def s_912 (z : Store) : Store := storeSet (s_911 z) [(361, cross_dp_wred [((s_911 z) 360), ((s_911 z) 966)])]
 theorem t_911 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_464) (pmPeers pmNode_464) (s_911 z) pmNode_464 none = some (s_912 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_464) (s_911 z) pmNode_464 = _
   rw [wredStep, if_pos ⟨by decide, g_911 z z_⟩]
   rfl
 #a t_911
 theorem k_911 (z : Store) (tid : Tid) (h : tid ∉ [361]) : (s_912 z) tid = (s_911 z) tid := by
   unfold s_912
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_911
 theorem w_911_0 (z : Store) : (s_912 z) 361 = v_911_0 z := by
   unfold s_912
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_911_0, r_911_0 z, r_911_1 z] <;> rfl
 #a w_911_0
 theorem h_911_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_911_0 z).shape = [64, 32] := by
   unfold v_911_0
   rw [tensorSum_shape]
   exact h_250_1 z z_
 #a h_911_0
 attribute [local irreducible] v_911_0
 attribute [local irreducible] s_912
 theorem n_908_912 (z : Store) (tid : Tid) (h : tid ∉ ([661, 926, 321, 361] : List Tid)) : (s_912 z) tid = (s_908 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_908 z) (k_909 z)) (pF _ _ _ _ _ (k_910 z) (k_911 z)) tid h
 #a n_908_912
 theorem n_904_912 (z : Store) (tid : Tid) (h : tid ∉ ([638, 680, 655, 658, 661, 926, 321, 361] : List Tid)) : (s_912 z) tid = (s_904 z) tid := by
   exact pF _ _ _ _ _ (n_904_908 z) (n_908_912 z) tid h
 #a n_904_912
 theorem n_896_912 (z : Store) (tid : Tid) (h : tid ∉ ([646, 648, 650, 652, 624, 664, 635, 671, 638, 680, 655, 658, 661, 926, 321, 361] : List Tid)) : (s_912 z) tid = (s_896 z) tid := by
   exact pF _ _ _ _ _ (n_896_904 z) (n_904_912 z) tid h
 #a n_896_912
 theorem r_912_0 (z : Store) : (s_912 z) 331 = (v_401_1 z) := pR (n_896_912 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_416_448 z) (pR (n_408_416 z) (pR (n_404_408 z) (pR (k_403 z) (pR (k_402 z) (w_401_1 z)))))))))
 #a r_912_0
 theorem r_912_1 (z : Store) : (s_912 z) 937 = (v_823_1 z) := pR (n_896_912 z) (pR (n_832_896 z) (pR (n_824_832 z) (w_823_1 z)))
 #a r_912_1
 def v_912_0 (z : Store) : Tensor := cross_dp_wred [(v_401_1 z), (v_823_1 z)]
 theorem g_912 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_465) (s_912 z) pmNode_465 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_465, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_912_1 z, r_912_0 z]
     exact (h_823_1 z z_).trans (h_401_1 z z_).symm
 #a g_912
 def s_913 (z : Store) : Store := storeSet (s_912 z) [(332, cross_dp_wred [((s_912 z) 331), ((s_912 z) 937)])]
 theorem t_912 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_465) (pmPeers pmNode_465) (s_912 z) pmNode_465 none = some (s_913 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_465) (s_912 z) pmNode_465 = _
   rw [wredStep, if_pos ⟨by decide, g_912 z z_⟩]
   rfl
 #a t_912
 theorem k_912 (z : Store) (tid : Tid) (h : tid ∉ [332]) : (s_913 z) tid = (s_912 z) tid := by
   unfold s_913
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_912
 theorem w_912_0 (z : Store) : (s_913 z) 332 = v_912_0 z := by
   unfold s_913
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_912_0, r_912_0 z, r_912_1 z] <;> rfl
 #a w_912_0
 theorem h_912_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_912_0 z).shape = [32, 64] := by
   unfold v_912_0
   rw [tensorSum_shape]
   exact h_401_1 z z_
 #a h_912_0
 attribute [local irreducible] v_912_0
 attribute [local irreducible] s_913
 theorem r_913_0 (z : Store) : (s_913 z) 367 = (v_235_1 z) := pR (k_912 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_240_256 z) (pR (n_236_240 z) (w_235_1 z)))))))
 #a r_913_0
 theorem r_913_1 (z : Store) : (s_913 z) 973 = (v_657_1 z) := pR (k_912 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_664_672 z) (pR (n_660_664 z) (pR (k_659 z) (pR (k_658 z) (w_657_1 z)))))))))
 #a r_913_1
 def v_913_0 (z : Store) : Tensor := cross_dp_wred [(v_235_1 z), (v_657_1 z)]
 theorem g_913 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_466) (s_913 z) pmNode_466 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_466, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_913_1 z, r_913_0 z]
     exact (h_657_1 z z_).trans (h_235_1 z z_).symm
 #a g_913
 def s_914 (z : Store) : Store := storeSet (s_913 z) [(368, cross_dp_wred [((s_913 z) 367), ((s_913 z) 973)])]
 theorem t_913 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_466) (pmPeers pmNode_466) (s_913 z) pmNode_466 none = some (s_914 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_466) (s_913 z) pmNode_466 = _
   rw [wredStep, if_pos ⟨by decide, g_913 z z_⟩]
   rfl
 #a t_913
 theorem k_913 (z : Store) (tid : Tid) (h : tid ∉ [368]) : (s_914 z) tid = (s_913 z) tid := by
   unfold s_914
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_913
 theorem w_913_0 (z : Store) : (s_914 z) 368 = v_913_0 z := by
   unfold s_914
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_913_0, r_913_0 z, r_913_1 z] <;> rfl
 #a w_913_0
 theorem h_913_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_913_0 z).shape = [256, 32] := by
   unfold v_913_0
   rw [tensorSum_shape]
   exact h_235_1 z z_
 #a h_913_0
 attribute [local irreducible] v_913_0
 attribute [local irreducible] s_914
 theorem r_914_0 (z : Store) : (s_914 z) 334 = (v_397_1 z) := pR (k_913 z) (pR (k_912 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_416_448 z) (pR (n_400_416 z) (pR (k_399 z) (pR (k_398 z) (w_397_1 z))))))))))
 #a r_914_0
 theorem r_914_1 (z : Store) : (s_914 z) 940 = (v_819_1 z) := pR (k_913 z) (pR (k_912 z) (pR (n_896_912 z) (pR (n_832_896 z) (pR (n_824_832 z) (pR (n_820_824 z) (w_819_1 z))))))
 #a r_914_1
 def v_914_0 (z : Store) : Tensor := cross_dp_wred [(v_397_1 z), (v_819_1 z)]
 theorem g_914 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_467) (s_914 z) pmNode_467 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_467, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_914_1 z, r_914_0 z]
     exact (h_819_1 z z_).trans (h_397_1 z z_).symm
 #a g_914
 def s_915 (z : Store) : Store := storeSet (s_914 z) [(335, cross_dp_wred [((s_914 z) 334), ((s_914 z) 940)])]
 theorem t_914 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_467) (pmPeers pmNode_467) (s_914 z) pmNode_467 none = some (s_915 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_467) (s_914 z) pmNode_467 = _
   rw [wredStep, if_pos ⟨by decide, g_914 z z_⟩]
   rfl
 #a t_914
 theorem k_914 (z : Store) (tid : Tid) (h : tid ∉ [335]) : (s_915 z) tid = (s_914 z) tid := by
   unfold s_915
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_914
 theorem w_914_0 (z : Store) : (s_915 z) 335 = v_914_0 z := by
   unfold s_915
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_914_0, r_914_0 z, r_914_1 z] <;> rfl
 #a w_914_0
 theorem h_914_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_914_0 z).shape = [32, 64] := by
   unfold v_914_0
   rw [tensorSum_shape]
   exact h_397_1 z z_
 #a h_914_0
 attribute [local irreducible] v_914_0
 attribute [local irreducible] s_915
 theorem r_915_0 (z : Store) : (s_915 z) 376 = (v_219_1 z) := pR (k_914 z) (pR (k_913 z) (pR (k_912 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_224_256 z) (pR (n_220_224 z) (w_219_1 z)))))))))
 #a r_915_0
 theorem r_915_1 (z : Store) : (s_915 z) 982 = (v_641_1 z) := pR (k_914 z) (pR (k_913 z) (pR (k_912 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_656_672 z) (pR (n_648_656 z) (pR (n_644_648 z) (pR (k_643 z) (pR (k_642 z) (w_641_1 z))))))))))))
 #a r_915_1
 def v_915_0 (z : Store) : Tensor := cross_dp_wred [(v_219_1 z), (v_641_1 z)]
 theorem g_915 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_468) (s_915 z) pmNode_468 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_468, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_915_1 z, r_915_0 z]
     exact (h_641_1 z z_).trans (h_219_1 z z_).symm
 #a g_915
 def s_916 (z : Store) : Store := storeSet (s_915 z) [(377, cross_dp_wred [((s_915 z) 376), ((s_915 z) 982)])]
 theorem t_915 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_468) (pmPeers pmNode_468) (s_915 z) pmNode_468 none = some (s_916 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_468) (s_915 z) pmNode_468 = _
   rw [wredStep, if_pos ⟨by decide, g_915 z z_⟩]
   rfl
 #a t_915
 theorem k_915 (z : Store) (tid : Tid) (h : tid ∉ [377]) : (s_916 z) tid = (s_915 z) tid := by
   unfold s_916
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_915
 theorem w_915_0 (z : Store) : (s_916 z) 377 = v_915_0 z := by
   unfold s_916
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_915_0, r_915_0 z, r_915_1 z] <;> rfl
 #a w_915_0
 theorem h_915_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_915_0 z).shape = [128, 64] := by
   unfold v_915_0
   rw [tensorSum_shape]
   exact h_219_1 z z_
 #a h_915_0
 attribute [local irreducible] v_915_0
 attribute [local irreducible] s_916
 theorem n_912_916 (z : Store) (tid : Tid) (h : tid ∉ ([332, 368, 335, 377] : List Tid)) : (s_916 z) tid = (s_912 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_912 z) (k_913 z)) (pF _ _ _ _ _ (k_914 z) (k_915 z)) tid h
 #a n_912_916
 theorem r_916_0 (z : Store) : (s_916 z) 351 = (v_313_1 z) := pR (n_912_916 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_320_384 z) (pR (n_316_320 z) (pR (k_315 z) (pR (k_314 z) (w_313_1 z)))))))))
 #a r_916_0
 theorem r_916_1 (z : Store) : (s_916 z) 957 = (v_735_1 z) := pR (n_912_916 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_736_768 z) (w_735_1 z))))
 #a r_916_1
 def v_916_0 (z : Store) : Tensor := cross_dp_wred [(v_313_1 z), (v_735_1 z)]
 theorem g_916 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_469) (s_916 z) pmNode_469 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_469, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_916_1 z, r_916_0 z]
     exact (h_735_1 z z_).trans (h_313_1 z z_).symm
 #a g_916
 def s_917 (z : Store) : Store := storeSet (s_916 z) [(352, cross_dp_wred [((s_916 z) 351), ((s_916 z) 957)])]
 theorem t_916 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_469) (pmPeers pmNode_469) (s_916 z) pmNode_469 none = some (s_917 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_469) (s_916 z) pmNode_469 = _
   rw [wredStep, if_pos ⟨by decide, g_916 z z_⟩]
   rfl
 #a t_916
 theorem k_916 (z : Store) (tid : Tid) (h : tid ∉ [352]) : (s_917 z) tid = (s_916 z) tid := by
   unfold s_917
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_916
 theorem w_916_0 (z : Store) : (s_917 z) 352 = v_916_0 z := by
   unfold s_917
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_916_0, r_916_0 z, r_916_1 z] <;> rfl
 #a w_916_0
 theorem h_916_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_916_0 z).shape = [32, 64] := by
   unfold v_916_0
   rw [tensorSum_shape]
   exact h_313_1 z z_
 #a h_916_0
 attribute [local irreducible] v_916_0
 attribute [local irreducible] s_917
 record_prefix_opacity v_909_0 s_910 v_910_0 s_911 v_911_0 s_912 v_912_0 s_913 v_913_0 s_914 v_914_0 s_915 v_915_0 s_916 v_916_0 s_917

 end
 end TrainVerify.Denote.RuntimeWorld
