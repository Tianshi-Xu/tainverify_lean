import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0000
prefix_names pmSeededPrefix ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem i_26 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 312).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_26
 theorem e_26 (z : Store) : (s_0 z) 312 = z 312 := pmInitialWithSeeds_frame z 312 (by decide)
 #a e_26
 theorem i_27 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 313).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_27
 theorem e_27 (z : Store) : (s_0 z) 313 = z 313 := pmInitialWithSeeds_frame z 313 (by decide)
 #a e_27
 theorem i_28 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 47).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_28
 theorem e_28 (z : Store) : (s_0 z) 47 = z 47 := pmInitialWithSeeds_frame z 47 (by decide)
 #a e_28
 theorem i_29 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 50).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_29
 theorem e_29 (z : Store) : (s_0 z) 50 = z 50 := pmInitialWithSeeds_frame z 50 (by decide)
 #a e_29
 theorem i_30 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 53).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_30
 theorem e_30 (z : Store) : (s_0 z) 53 = z 53 := pmInitialWithSeeds_frame z 53 (by decide)
 #a e_30
 theorem i_31 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 350).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_31
 theorem e_31 (z : Store) : (s_0 z) 350 = z 350 := pmInitialWithSeeds_frame z 350 (by decide)
 #a e_31
 theorem i_32 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 353).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_32
 theorem e_32 (z : Store) : (s_0 z) 353 = z 353 := pmInitialWithSeeds_frame z 353 (by decide)
 #a e_32
 theorem i_33 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 356).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_33
 theorem e_33 (z : Store) : (s_0 z) 356 = z 356 := pmInitialWithSeeds_frame z 356 (by decide)
 #a e_33
 theorem i_34 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 56).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_34
 theorem e_34 (z : Store) : (s_0 z) 56 = z 56 := pmInitialWithSeeds_frame z 56 (by decide)
 #a e_34
 theorem i_35 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 359).shape = [64, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_35
 theorem e_35 (z : Store) : (s_0 z) 359 = z 359 := pmInitialWithSeeds_frame z 359 (by decide)
 #a e_35
 theorem i_36 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 11).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_36
 theorem e_36 (z : Store) : (s_0 z) 11 = z 11 := pmInitialWithSeeds_frame z 11 (by decide)
 #a e_36
 theorem i_37 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 12).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_37
 theorem e_37 (z : Store) : (s_0 z) 12 = z 12 := pmInitialWithSeeds_frame z 12 (by decide)
 #a e_37
 theorem i_38 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 314).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_38
 theorem e_38 (z : Store) : (s_0 z) 314 = z 314 := pmInitialWithSeeds_frame z 314 (by decide)
 #a e_38
 theorem i_39 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 315).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_39
 theorem e_39 (z : Store) : (s_0 z) 315 = z 315 := pmInitialWithSeeds_frame z 315 (by decide)
 #a e_39
 theorem i_40 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 63).shape = [256, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_40
 theorem e_40 (z : Store) : (s_0 z) 63 = z 63 := pmInitialWithSeeds_frame z 63 (by decide)
 #a e_40
 theorem i_41 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 366).shape = [256, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_41
 theorem e_41 (z : Store) : (s_0 z) 366 = z 366 := pmInitialWithSeeds_frame z 366 (by decide)
 #a e_41
 theorem i_42 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 13).shape = [64, 256] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_42
 theorem e_42 (z : Store) : (s_0 z) 13 = z 13 := pmInitialWithSeeds_frame z 13 (by decide)
 #a e_42
 theorem i_43 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 14).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_43
 theorem e_43 (z : Store) : (s_0 z) 14 = z 14 := pmInitialWithSeeds_frame z 14 (by decide)
 #a e_43
 theorem i_44 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 15).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_44
 theorem e_44 (z : Store) : (s_0 z) 15 = z 15 := pmInitialWithSeeds_frame z 15 (by decide)
 #a e_44
 theorem i_45 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 316).shape = [64, 256] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_45
 theorem e_45 (z : Store) : (s_0 z) 316 = z 316 := pmInitialWithSeeds_frame z 316 (by decide)
 #a e_45
 theorem i_46 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 317).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_46
 theorem e_46 (z : Store) : (s_0 z) 317 = z 317 := pmInitialWithSeeds_frame z 317 (by decide)
 #a e_46
 theorem i_47 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 318).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_47
 theorem e_47 (z : Store) : (s_0 z) 318 = z 318 := pmInitialWithSeeds_frame z 318 (by decide)
 #a e_47
 theorem i_48 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 72).shape = [128, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_48
 theorem e_48 (z : Store) : (s_0 z) 72 = z 72 := pmInitialWithSeeds_frame z 72 (by decide)
 #a e_48
 theorem i_49 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 375).shape = [128, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_49
 theorem e_49 (z : Store) : (s_0 z) 375 = z 375 := pmInitialWithSeeds_frame z 375 (by decide)
 #a e_49
 theorem i_50 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 622).shape = [256, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_50
 theorem e_50 (z : Store) : (s_0 z) 622 = z 622 := pmInitialWithSeeds_frame z 622 (by decide)
 #a e_50
 theorem i_51 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 606).shape = [16, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_51
 theorem e_51 (z : Store) : (s_0 z) 606 = z 606 := pmInitialWithSeeds_frame z 606 (by decide)
 #a e_51
 theorem i_52 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 925).shape = [256, 32] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_52
 theorem e_52 (z : Store) : (s_0 z) 925 = z 925 := pmInitialWithSeeds_frame z 925 (by decide)
 #a e_52
 theorem i_53 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 909).shape = [16, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_53
 theorem e_53 (z : Store) : (s_0 z) 909 = z 909 := pmInitialWithSeeds_frame z 909 (by decide)
 #a e_53
 theorem i_54 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 607).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_54
 theorem e_54 (z : Store) : (s_0 z) 607 = z 607 := pmInitialWithSeeds_frame z 607 (by decide)
 #a e_54
 theorem i_55 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 608).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_55
 theorem e_55 (z : Store) : (s_0 z) 608 = z 608 := pmInitialWithSeeds_frame z 608 (by decide)
 #a e_55
 theorem i_56 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 609).shape = [64, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_56
 theorem e_56 (z : Store) : (s_0 z) 609 = z 609 := pmInitialWithSeeds_frame z 609 (by decide)
 #a e_56
 theorem i_57 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 910).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_57
 theorem e_57 (z : Store) : (s_0 z) 910 = z 910 := pmInitialWithSeeds_frame z 910 (by decide)
 #a e_57
 theorem i_58 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 911).shape = [64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_58
 theorem e_58 (z : Store) : (s_0 z) 911 = z 911 := pmInitialWithSeeds_frame z 911 (by decide)
 #a e_58
 theorem i_59 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 633).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_59
 theorem e_59 (z : Store) : (s_0 z) 633 = z 633 := pmInitialWithSeeds_frame z 633 (by decide)
 #a e_59
 theorem i_60 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 636).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_60
 theorem e_60 (z : Store) : (s_0 z) 636 = z 636 := pmInitialWithSeeds_frame z 636 (by decide)
 #a e_60
 theorem i_61 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 912).shape = [64, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_61
 theorem e_61 (z : Store) : (s_0 z) 912 = z 912 := pmInitialWithSeeds_frame z 912 (by decide)
 #a e_61
 theorem i_62 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 936).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_62
 theorem e_62 (z : Store) : (s_0 z) 936 = z 936 := pmInitialWithSeeds_frame z 936 (by decide)
 #a e_62
 theorem i_63 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 939).shape = [32, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_63
 theorem e_63 (z : Store) : (s_0 z) 939 = z 939 := pmInitialWithSeeds_frame z 939 (by decide)
 #a e_63
 theorem i_64 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 610).shape = [64, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_64
 theorem e_64 (z : Store) : (s_0 z) 610 = z 610 := pmInitialWithSeeds_frame z 610 (by decide)
 #a e_64
 theorem i_65 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (z 913).shape = [64, 64] := by
   exact z_.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
 #a i_65
 theorem e_65 (z : Store) : (s_0 z) 913 = z 913 := pmInitialWithSeeds_frame z 913 (by decide)
 #a e_65
 end
 end TrainVerify.Denote.RuntimeWorld
