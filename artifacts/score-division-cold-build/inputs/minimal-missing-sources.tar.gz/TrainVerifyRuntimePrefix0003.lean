import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0002
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_1_0 (z : Store) : (s_1 z) 75 = (v_0_0 z) := w_0_0 z
 #a r_1_0
 theorem r_1_1 (z : Store) : (s_1 z) 16 = (z 16) := pR (k_0 z) (e_0 z)
 #a r_1_1
 def v_1_0 (z : Store) : Tensor := fw_embedding (v_0_0 z) (z 16)
 def s_2 (z : Store) : Store := storeSet (s_1 z) [(89, fw_embedding ((s_1 z) 75) ((s_1 z) 16))]
 theorem t_1 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_1) (pmPeers pmNode_1) (s_1 z) pmNode_1 none = some (s_2 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_1
 theorem k_1 (z : Store) (tid : Tid) (h : tid ∉ [89]) : (s_2 z) tid = (s_1 z) tid := by
   unfold s_2
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_1
 theorem w_1_0 (z : Store) : (s_2 z) 89 = v_1_0 z := by
   unfold s_2
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_1_0, r_1_0 z, r_1_1 z] <;> rfl
 #a w_1_0
 theorem h_1_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_1_0 z).shape = [1, 16, 32] := by
   unfold v_1_0
   simp [fw_embedding_shape, lastD, h_0_0 z z_, i_0 z z_]
 #a h_1_0
 attribute [local irreducible] v_1_0
 attribute [local irreducible] s_2
 theorem r_2_0 (z : Store) : (s_2 z) 76 = (v_0_1 z) := pR (k_1 z) (w_0_1 z)
 #a r_2_0
 def v_2_0 (z : Store) : Tensor := chunkPrimDimN 1 2 0 (v_0_1 z)
 def s_3 (z : Store) : Store := storeSet (s_2 z) [(91, chunkPrimDimN 1 2 0 ((s_2 z) 76))]
 theorem t_2 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_2) (pmPeers pmNode_2) (s_2 z) pmNode_2 none = some (s_3 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_2 z) pmNode_2 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_2
 theorem k_2 (z : Store) (tid : Tid) (h : tid ∉ [91]) : (s_3 z) tid = (s_2 z) tid := by
   unfold s_3
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_2
 theorem w_2_0 (z : Store) : (s_3 z) 91 = v_2_0 z := by
   unfold s_3
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_2_0, r_2_0 z] <;> rfl
 #a w_2_0
 theorem h_2_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_2_0 z).shape = [1, 8] := by
   unfold v_2_0
   exact chunkPrimDimN_shape 1 2 0 (v_0_1 z) [1, 16] (h_0_1 z z_) (by decide)
 #a h_2_0
 attribute [local irreducible] v_2_0
 attribute [local irreducible] s_3
 theorem r_3_0 (z : Store) : (s_3 z) 91 = (v_2_0 z) := w_2_0 z
 #a r_3_0
 theorem r_3_1 (z : Store) : (s_3 z) 0 = (z 0) := pR (k_2 z) (pR (k_1 z) (pR (k_0 z) (e_1 z)))
 #a r_3_1
 def v_3_0 (z : Store) : Tensor := fw_embedding (v_2_0 z) (z 0)
 def s_4 (z : Store) : Store := storeSet (s_3 z) [(92, fw_embedding ((s_3 z) 91) ((s_3 z) 0))]
 theorem t_3 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_3) (pmPeers pmNode_3) (s_3 z) pmNode_3 none = some (s_4 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_3
 theorem k_3 (z : Store) (tid : Tid) (h : tid ∉ [92]) : (s_4 z) tid = (s_3 z) tid := by
   unfold s_4
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_3
 theorem w_3_0 (z : Store) : (s_4 z) 92 = v_3_0 z := by
   unfold s_4
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_3_0, r_3_0 z, r_3_1 z] <;> rfl
 #a w_3_0
 theorem h_3_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_3_0 z).shape = [1, 8, 64] := by
   unfold v_3_0
   simp [fw_embedding_shape, lastD, h_2_0 z z_, i_1 z z_]
 #a h_3_0
 attribute [local irreducible] v_3_0
 attribute [local irreducible] s_4
 def v_4_0 (z : Store) : Tensor := pmNode_236_port0
 def v_4_1 (z : Store) : Tensor := pmNode_236_port1
 def s_5 (z : Store) : Store := storeSet (s_4 z) pmNode_236_feed
 theorem t_4 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_236) (pmPeers pmNode_236) (s_4 z) pmNode_236 (some pmNode_236_feed) = some (s_5 z) := by
   exact pmNode_236_scoped_step (s_4 z)
 #a t_4
 theorem k_4 (z : Store) (tid : Tid) (h : tid ∉ [378, 379]) : (s_5 z) tid = (s_4 z) tid := by
   unfold s_5
   dsimp only [pmNode_236_feed]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_4
 theorem w_4_0 (z : Store) : (s_5 z) 378 = v_4_0 z := by
   unfold s_5
   dsimp only [pmNode_236_feed]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_4_0] <;> rfl
 #a w_4_0
 theorem h_4_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_4_0 z).shape = [1, 16] := by
   unfold v_4_0
   simp [pmNode_236_port0, Tensor.mkShape]
 #a h_4_0
 attribute [local irreducible] v_4_0
 theorem w_4_1 (z : Store) : (s_5 z) 379 = v_4_1 z := by
   unfold s_5
   dsimp only [pmNode_236_feed]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_4_1] <;> rfl
 #a w_4_1
 theorem h_4_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_4_1 z).shape = [1, 16] := by
   unfold v_4_1
   simp [pmNode_236_port1, Tensor.mkShape]
 #a h_4_1
 attribute [local irreducible] v_4_1
 attribute [local irreducible] s_5
 theorem n_0_4 (z : Store) (tid : Tid) (h : tid ∉ ([75, 76, 89, 91, 92] : List Tid)) : (s_4 z) tid = (s_0 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_0 z) (k_1 z)) (pF _ _ _ _ _ (k_2 z) (k_3 z)) tid h
 #a n_0_4
 theorem r_5_0 (z : Store) : (s_5 z) 378 = (v_4_0 z) := w_4_0 z
 #a r_5_0
 theorem r_5_1 (z : Store) : (s_5 z) 319 = (z 319) := pR (k_4 z) (pR (n_0_4 z) (e_2 z))
 #a r_5_1
 def v_5_0 (z : Store) : Tensor := fw_embedding (v_4_0 z) (z 319)
 def s_6 (z : Store) : Store := storeSet (s_5 z) [(392, fw_embedding ((s_5 z) 378) ((s_5 z) 319))]
 theorem t_5 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_237) (pmPeers pmNode_237) (s_5 z) pmNode_237 none = some (s_6 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_5
 theorem k_5 (z : Store) (tid : Tid) (h : tid ∉ [392]) : (s_6 z) tid = (s_5 z) tid := by
   unfold s_6
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_5
 theorem w_5_0 (z : Store) : (s_6 z) 392 = v_5_0 z := by
   unfold s_6
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_5_0, r_5_0 z, r_5_1 z] <;> rfl
 #a w_5_0
 theorem h_5_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_5_0 z).shape = [1, 16, 32] := by
   unfold v_5_0
   simp [fw_embedding_shape, lastD, h_4_0 z z_, i_2 z z_]
 #a h_5_0
 attribute [local irreducible] v_5_0
 attribute [local irreducible] s_6
 theorem r_6_0 (z : Store) : (s_6 z) 379 = (v_4_1 z) := pR (k_5 z) (w_4_1 z)
 #a r_6_0
 def v_6_0 (z : Store) : Tensor := chunkPrimDimN 1 2 1 (v_4_1 z)
 def s_7 (z : Store) : Store := storeSet (s_6 z) [(394, chunkPrimDimN 1 2 1 ((s_6 z) 379))]
 theorem t_6 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_238) (pmPeers pmNode_238) (s_6 z) pmNode_238 none = some (s_7 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_6 z) pmNode_238 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_6
 theorem k_6 (z : Store) (tid : Tid) (h : tid ∉ [394]) : (s_7 z) tid = (s_6 z) tid := by
   unfold s_7
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_6
 theorem w_6_0 (z : Store) : (s_7 z) 394 = v_6_0 z := by
   unfold s_7
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_6_0, r_6_0 z] <;> rfl
 #a w_6_0
 theorem h_6_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_6_0 z).shape = [1, 8] := by
   unfold v_6_0
   exact chunkPrimDimN_shape 1 2 1 (v_4_1 z) [1, 16] (h_4_1 z z_) (by decide)
 #a h_6_0
 attribute [local irreducible] v_6_0
 attribute [local irreducible] s_7
 theorem r_7_0 (z : Store) : (s_7 z) 394 = (v_6_0 z) := w_6_0 z
 #a r_7_0
 theorem r_7_1 (z : Store) : (s_7 z) 303 = (z 303) := pR (k_6 z) (pR (k_5 z) (pR (k_4 z) (pR (n_0_4 z) (e_3 z))))
 #a r_7_1
 def v_7_0 (z : Store) : Tensor := fw_embedding (v_6_0 z) (z 303)
 def s_8 (z : Store) : Store := storeSet (s_7 z) [(395, fw_embedding ((s_7 z) 394) ((s_7 z) 303))]
 theorem t_7 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_239) (pmPeers pmNode_239) (s_7 z) pmNode_239 none = some (s_8 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_7
 theorem k_7 (z : Store) (tid : Tid) (h : tid ∉ [395]) : (s_8 z) tid = (s_7 z) tid := by
   unfold s_8
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_7
 theorem w_7_0 (z : Store) : (s_8 z) 395 = v_7_0 z := by
   unfold s_8
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_7_0, r_7_0 z, r_7_1 z] <;> rfl
 #a w_7_0
 theorem h_7_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_7_0 z).shape = [1, 8, 64] := by
   unfold v_7_0
   simp [fw_embedding_shape, lastD, h_6_0 z z_, i_3 z z_]
 #a h_7_0
 attribute [local irreducible] v_7_0
 attribute [local irreducible] s_8
 theorem n_4_8 (z : Store) (tid : Tid) (h : tid ∉ ([378, 379, 392, 394, 395] : List Tid)) : (s_8 z) tid = (s_4 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_4 z) (k_5 z)) (pF _ _ _ _ _ (k_6 z) (k_7 z)) tid h
 #a n_4_8
 theorem r_8_0 (z : Store) : (s_8 z) 92 = (v_3_0 z) := pR (n_4_8 z) (w_3_0 z)
 #a r_8_0
 theorem r_8_1 (z : Store) : (s_8 z) 395 = (v_7_0 z) := w_7_0 z
 #a r_8_1
 def v_8_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_3_0 z), (v_7_0 z)]
 theorem g_8 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_4) (s_8 z) pmNode_4 1 2 94 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_4, r_8_0 z, r_8_1 z, h_3_0 z z_, h_7_0 z z_]
 #a g_8
 def s_9 (z : Store) : Store := pL [0, 1] (s_8 z) pmNode_4 1 2
 theorem t_8 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_4) (pmPeers pmNode_4) (s_8 z) pmNode_4 none = some (s_9 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_4) (s_8 z) pmNode_4).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 94 (by decide) (g_8 z z_)]
   rfl
 #a t_8
 theorem k_8 (z : Store) (tid : Tid) (h : tid ∉ [94]) : (s_9 z) tid = (s_8 z) tid := by
   unfold s_9
   dsimp only [pL, pmNode_4, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_8
 theorem w_8_0 (z : Store) : (s_9 z) 94 = v_8_0 z := by
   unfold s_9
   dsimp only [pL, pmNode_4, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_8_0, r_8_0 z, r_8_1 z] <;> rfl
 #a w_8_0
 theorem h_8_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_8_0 z).shape = [1, 16, 32] := by
   unfold v_8_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_3_0 z z_]
 #a h_8_0
 attribute [local irreducible] v_8_0
 attribute [local irreducible] s_9
 theorem r_9_0 (z : Store) : (s_9 z) 89 = (v_1_0 z) := pR (k_8 z) (pR (n_4_8 z) (pR (k_3 z) (pR (k_2 z) (w_1_0 z))))
 #a r_9_0
 theorem r_9_1 (z : Store) : (s_9 z) 94 = (v_8_0 z) := w_8_0 z
 #a r_9_1
 def v_9_0 (z : Store) : Tensor := elemwiseAdd (v_1_0 z) (v_8_0 z)
 def s_10 (z : Store) : Store := storeSet (s_9 z) [(95, elemwiseAdd ((s_9 z) 89) ((s_9 z) 94))]
 theorem t_9 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_5) (pmPeers pmNode_5) (s_9 z) pmNode_5 none = some (s_10 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_9
 theorem k_9 (z : Store) (tid : Tid) (h : tid ∉ [95]) : (s_10 z) tid = (s_9 z) tid := by
   unfold s_10
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_9
 theorem w_9_0 (z : Store) : (s_10 z) 95 = v_9_0 z := by
   unfold s_10
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_9_0, r_9_0 z, r_9_1 z] <;> rfl
 #a w_9_0
 theorem h_9_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_9_0 z).shape = [1, 16, 32] := by
   unfold v_9_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_1_0 z z_, h_8_0 z z_]
 #a h_9_0
 attribute [local irreducible] v_9_0
 attribute [local irreducible] s_10
 record_prefix_opacity v_1_0 s_2 v_2_0 s_3 v_3_0 s_4 v_4_0 v_4_1 s_5 v_5_0 s_6 v_6_0 s_7 v_7_0 s_8 v_8_0 s_9 v_9_0 s_10

 end
 end TrainVerify.Denote.RuntimeWorld
