import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0016
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_120_0 (z : Store) : (s_120 z) 295 = (v_106_1 z) := pR (n_112_120 z) (r_112_0 z)
 #a r_120_0
 theorem r_120_1 (z : Store) : (s_120 z) 598 = (v_109_1 z) := pR (n_112_120 z) (r_112_1 z)
 #a r_120_1
 def v_120_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_106_1 z), (v_109_1 z)]
 theorem g_120 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_293) (s_120 z) pmNode_293 1 2 495 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_293, r_120_0 z, r_120_1 z, h_106_1 z z_, h_109_1 z z_]
 #a g_120
 def s_121 (z : Store) : Store := pL [0, 1] (s_120 z) pmNode_293 1 2
 theorem t_120 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_293) (pmPeers pmNode_293) (s_120 z) pmNode_293 none = some (s_121 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_293) (s_120 z) pmNode_293).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 495 (by decide) (g_120 z z_)]
   rfl
 #a t_120
 theorem k_120 (z : Store) (tid : Tid) (h : tid ∉ [495]) : (s_121 z) tid = (s_120 z) tid := by
   unfold s_121
   dsimp only [pL, pmNode_293, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_120
 theorem w_120_0 (z : Store) : (s_121 z) 495 = v_120_0 z := by
   unfold s_121
   dsimp only [pL, pmNode_293, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_120_0, r_120_0 z, r_120_1 z] <;> rfl
 #a w_120_0
 theorem h_120_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_120_0 z).shape = [1, 16, 32] := by
   unfold v_120_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_106_1 z z_]
 #a h_120_0
 attribute [local irreducible] v_120_0
 attribute [local irreducible] s_121
 theorem r_121_0 (z : Store) : (s_121 z) 495 = (v_120_0 z) := w_120_0 z
 #a r_121_0
 theorem r_121_1 (z : Store) : (s_121 z) 353 = (z 353) := pR (k_120 z) (pR (n_112_120 z) (pR (n_96_112 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_32 z)))))
 #a r_121_1
 def v_121_0 (z : Store) : Tensor := fw_linear (v_120_0 z) (z 353)
 def s_122 (z : Store) : Store := storeSet (s_121 z) [(496, fw_linear ((s_121 z) 495) ((s_121 z) 353))]
 theorem t_121 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_294) (pmPeers pmNode_294) (s_121 z) pmNode_294 none = some (s_122 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_121
 theorem k_121 (z : Store) (tid : Tid) (h : tid ∉ [496]) : (s_122 z) tid = (s_121 z) tid := by
   unfold s_122
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_121
 theorem w_121_0 (z : Store) : (s_122 z) 496 = v_121_0 z := by
   unfold s_122
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_121_0, r_121_0 z, r_121_1 z] <;> rfl
 #a w_121_0
 theorem h_121_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_121_0 z).shape = [1, 16, 64] := by
   unfold v_121_0
   exact fw_linear_3d_shape 1 16 32 64 (v_120_0 z) (z 353) (h_120_0 z z_) (i_32 z z_)
 #a h_121_0
 attribute [local irreducible] v_121_0
 attribute [local irreducible] s_122
 theorem r_122_0 (z : Store) : (s_122 z) 297 = (v_106_2 z) := pR (k_121 z) (pR (k_120 z) (pR (n_116_120 z) (pR (k_115 z) (pR (k_114 z) (r_114_0 z)))))
 #a r_122_0
 theorem r_122_1 (z : Store) : (s_122 z) 600 = (v_109_2 z) := pR (k_121 z) (pR (k_120 z) (pR (n_116_120 z) (pR (k_115 z) (pR (k_114 z) (r_114_1 z)))))
 #a r_122_1
 def v_122_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_106_2 z), (v_109_2 z)]
 theorem g_122 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_295) (s_122 z) pmNode_295 1 2 498 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_295, r_122_0 z, r_122_1 z, h_106_2 z z_, h_109_2 z z_]
 #a g_122
 def s_123 (z : Store) : Store := pL [0, 1] (s_122 z) pmNode_295 1 2
 theorem t_122 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_295) (pmPeers pmNode_295) (s_122 z) pmNode_295 none = some (s_123 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_295) (s_122 z) pmNode_295).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 498 (by decide) (g_122 z z_)]
   rfl
 #a t_122
 theorem k_122 (z : Store) (tid : Tid) (h : tid ∉ [498]) : (s_123 z) tid = (s_122 z) tid := by
   unfold s_123
   dsimp only [pL, pmNode_295, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_122
 theorem w_122_0 (z : Store) : (s_123 z) 498 = v_122_0 z := by
   unfold s_123
   dsimp only [pL, pmNode_295, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_122_0, r_122_0 z, r_122_1 z] <;> rfl
 #a w_122_0
 theorem h_122_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_122_0 z).shape = [1, 16, 32] := by
   unfold v_122_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_106_2 z z_]
 #a h_122_0
 attribute [local irreducible] v_122_0
 attribute [local irreducible] s_123
 theorem r_123_0 (z : Store) : (s_123 z) 498 = (v_122_0 z) := w_122_0 z
 #a r_123_0
 theorem r_123_1 (z : Store) : (s_123 z) 356 = (z 356) := pR (k_122 z) (pR (k_121 z) (pR (k_120 z) (pR (n_112_120 z) (pR (n_96_112 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_33 z)))))))
 #a r_123_1
 def v_123_0 (z : Store) : Tensor := fw_linear (v_122_0 z) (z 356)
 def s_124 (z : Store) : Store := storeSet (s_123 z) [(499, fw_linear ((s_123 z) 498) ((s_123 z) 356))]
 theorem t_123 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_296) (pmPeers pmNode_296) (s_123 z) pmNode_296 none = some (s_124 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_123
 theorem k_123 (z : Store) (tid : Tid) (h : tid ∉ [499]) : (s_124 z) tid = (s_123 z) tid := by
   unfold s_124
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_123
 theorem w_123_0 (z : Store) : (s_124 z) 499 = v_123_0 z := by
   unfold s_124
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_123_0, r_123_0 z, r_123_1 z] <;> rfl
 #a w_123_0
 theorem h_123_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_123_0 z).shape = [1, 16, 64] := by
   unfold v_123_0
   exact fw_linear_3d_shape 1 16 32 64 (v_122_0 z) (z 356) (h_122_0 z z_) (i_33 z z_)
 #a h_123_0
 attribute [local irreducible] v_123_0
 attribute [local irreducible] s_124
 theorem n_120_124 (z : Store) (tid : Tid) (h : tid ∉ ([495, 496, 498, 499] : List Tid)) : (s_124 z) tid = (s_120 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_120 z) (k_121 z)) (pF _ _ _ _ _ (k_122 z) (k_123 z)) tid h
 #a n_120_124
 theorem r_124_0 (z : Store) : (s_124 z) 189 = (v_111_0 z) := pR (n_120_124 z) (pR (k_119 z) (pR (k_118 z) (r_118_0 z)))
 #a r_124_0
 theorem r_124_1 (z : Store) : (s_124 z) 492 = (v_117_0 z) := pR (n_120_124 z) (pR (k_119 z) (pR (k_118 z) (r_118_1 z)))
 #a r_124_1
 def v_124_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_111_0 z), (v_117_0 z)]
 theorem g_124 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_297) (s_124 z) pmNode_297 2 1 501 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_297, r_124_0 z, r_124_1 z, h_111_0 z z_, h_117_0 z z_]
 #a g_124
 def s_125 (z : Store) : Store := pL [0, 1] (s_124 z) pmNode_297 2 1
 theorem t_124 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_297) (pmPeers pmNode_297) (s_124 z) pmNode_297 none = some (s_125 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_297) (s_124 z) pmNode_297).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 501 (by decide) (g_124 z z_)]
   rfl
 #a t_124
 theorem k_124 (z : Store) (tid : Tid) (h : tid ∉ [501]) : (s_125 z) tid = (s_124 z) tid := by
   unfold s_125
   dsimp only [pL, pmNode_297, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_124
 theorem w_124_0 (z : Store) : (s_125 z) 501 = v_124_0 z := by
   unfold s_125
   dsimp only [pL, pmNode_297, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_124_0, r_124_0 z, r_124_1 z] <;> rfl
 #a w_124_0
 theorem h_124_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_124_0 z).shape = [1, 8, 64] := by
   unfold v_124_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_111_0 z z_]
 #a h_124_0
 attribute [local irreducible] v_124_0
 attribute [local irreducible] s_125
 theorem r_125_0 (z : Store) : (s_125 z) 501 = (v_124_0 z) := w_124_0 z
 #a r_125_0
 def v_125_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_124_0 z)
 def s_126 (z : Store) : Store := storeSet (s_125 z) [(502, fw_view [1, 8, 4, 16] ((s_125 z) 501))]
 theorem t_125 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_298) (pmPeers pmNode_298) (s_125 z) pmNode_298 none = some (s_126 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_125
 theorem k_125 (z : Store) (tid : Tid) (h : tid ∉ [502]) : (s_126 z) tid = (s_125 z) tid := by
   unfold s_126
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_125
 theorem w_125_0 (z : Store) : (s_126 z) 502 = v_125_0 z := by
   unfold s_126
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_125_0, r_125_0 z] <;> rfl
 #a w_125_0
 theorem h_125_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_125_0 z).shape = [1, 8, 4, 16] := by
   unfold v_125_0
   rfl
 #a h_125_0
 attribute [local irreducible] v_125_0
 attribute [local irreducible] s_126
 theorem r_126_0 (z : Store) : (s_126 z) 199 = (v_119_0 z) := pR (k_125 z) (pR (k_124 z) (pR (n_120_124 z) (w_119_0 z)))
 #a r_126_0
 theorem r_126_1 (z : Store) : (s_126 z) 502 = (v_125_0 z) := w_125_0 z
 #a r_126_1
 def v_126_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_119_0 z), (v_125_0 z)]
 theorem g_126 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_63) (s_126 z) pmNode_63 1 2 202 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_63, r_126_0 z, r_126_1 z, h_119_0 z z_, h_125_0 z z_]
 #a g_126
 def s_127 (z : Store) : Store := pL [0, 1] (s_126 z) pmNode_63 1 2
 theorem t_126 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_63) (pmPeers pmNode_63) (s_126 z) pmNode_63 none = some (s_127 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_63) (s_126 z) pmNode_63).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 202 (by decide) (g_126 z z_)]
   rfl
 #a t_126
 theorem k_126 (z : Store) (tid : Tid) (h : tid ∉ [202]) : (s_127 z) tid = (s_126 z) tid := by
   unfold s_127
   dsimp only [pL, pmNode_63, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_126
 theorem w_126_0 (z : Store) : (s_127 z) 202 = v_126_0 z := by
   unfold s_127
   dsimp only [pL, pmNode_63, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_126_0, r_126_0 z, r_126_1 z] <;> rfl
 #a w_126_0
 theorem h_126_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_126_0 z).shape = [1, 16, 2, 16] := by
   unfold v_126_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_119_0 z z_]
 #a h_126_0
 attribute [local irreducible] v_126_0
 attribute [local irreducible] s_127
 theorem r_127_0 (z : Store) : (s_127 z) 202 = (v_126_0 z) := w_126_0 z
 #a r_127_0
 def v_127_0 (z : Store) : Tensor := transposeAxes 1 2 (v_126_0 z)
 def s_128 (z : Store) : Store := storeSet (s_127 z) [(203, transposeAxes 1 2 ((s_127 z) 202))]
 theorem t_127 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_64) (pmPeers pmNode_64) (s_127 z) pmNode_64 none = some (s_128 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_127
 theorem k_127 (z : Store) (tid : Tid) (h : tid ∉ [203]) : (s_128 z) tid = (s_127 z) tid := by
   unfold s_128
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_127
 theorem w_127_0 (z : Store) : (s_128 z) 203 = v_127_0 z := by
   unfold s_128
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_127_0, r_127_0 z] <;> rfl
 #a w_127_0
 theorem h_127_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_127_0 z).shape = [1, 2, 16, 16] := by
   unfold v_127_0
   change listSwapAt _ _ _ = _
   rw [h_126_0 z z_]
   rfl
 #a h_127_0
 attribute [local irreducible] v_127_0
 attribute [local irreducible] s_128
 theorem n_124_128 (z : Store) (tid : Tid) (h : tid ∉ ([501, 502, 202, 203] : List Tid)) : (s_128 z) tid = (s_124 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_124 z) (k_125 z)) (pF _ _ _ _ _ (k_126 z) (k_127 z)) tid h
 #a n_124_128
 theorem n_120_128 (z : Store) (tid : Tid) (h : tid ∉ ([495, 496, 498, 499, 501, 502, 202, 203] : List Tid)) : (s_128 z) tid = (s_120 z) tid := by
   exact pF _ _ _ _ _ (n_120_124 z) (n_124_128 z) tid h
 #a n_120_128
 theorem r_128_0 (z : Store) : (s_128 z) 193 = (v_113_0 z) := pR (n_120_128 z) (pR (n_116_120 z) (pR (k_115 z) (pR (k_114 z) (w_113_0 z))))
 #a r_128_0
 theorem r_128_1 (z : Store) : (s_128 z) 496 = (v_121_0 z) := pR (n_124_128 z) (pR (k_123 z) (pR (k_122 z) (w_121_0 z)))
 #a r_128_1
 def v_128_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_113_0 z), (v_121_0 z)]
 def s_129 (z : Store) : Store := storeSet (s_128 z) [(206, reduceScatterPrimDimN 1 2 0 [((s_128 z) 193), ((s_128 z) 496)])]
 theorem t_128 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_65) (pmPeers pmNode_65) (s_128 z) pmNode_65 none = some (s_129 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_128 z) pmNode_65 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_128
 theorem k_128 (z : Store) (tid : Tid) (h : tid ∉ [206]) : (s_129 z) tid = (s_128 z) tid := by
   unfold s_129
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_128
 theorem w_128_0 (z : Store) : (s_129 z) 206 = v_128_0 z := by
   unfold s_129
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_128_0, r_128_0 z, r_128_1 z] <;> rfl
 #a w_128_0
 theorem h_128_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_128_0 z).shape = [1, 8, 64] := by
   unfold v_128_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_113_0 z) rfl]
     exact h_113_0 z z_
   · decide
 #a h_128_0
 attribute [local irreducible] v_128_0
 attribute [local irreducible] s_129
 record_prefix_opacity v_120_0 s_121 v_121_0 s_122 v_122_0 s_123 v_123_0 s_124 v_124_0 s_125 v_125_0 s_126 v_126_0 s_127 v_127_0 s_128 v_128_0 s_129

 end
 end TrainVerify.Denote.RuntimeWorld
