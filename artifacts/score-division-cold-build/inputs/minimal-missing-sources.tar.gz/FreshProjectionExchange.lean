import FreshSequenceAlias
-- UNCOMPILED: parent owns imports, predecessors, frame, costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierProjectionExchangeRead_pm_192 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 192 = AllToAllSourceFaithful.tensor 2 0 1 2 (([295, 598] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 112) (pmInputRequests.drop 113) pmNode_57 0 [0, 1] [295, 598] 192 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 112 ++ pmInputRequests.drop 112 := (List.take_append_drop 112 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([295, 598] : List Tid), ∀ row ∈ pmInputRequests.drop 112, tid ∉ row.1.outs
    decide
#print axioms frontierProjectionExchangeRead_pm_192
theorem frontierProjectionExchangeRead_pm_495 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 495 = AllToAllSourceFaithful.tensor 2 1 1 2 (([295, 598] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 120) (pmInputRequests.drop 121) pmNode_293 1 [0, 1] [295, 598] 495 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 120 ++ pmInputRequests.drop 120 := (List.take_append_drop 120 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([295, 598] : List Tid), ∀ row ∈ pmInputRequests.drop 120, tid ∉ row.1.outs
    decide
#print axioms frontierProjectionExchangeRead_pm_495
theorem frontierProjectionExchangeUnitFacts_1395_0_192_495 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1395).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 192, q 495], y.shape = [1, 16, 32]) ∧
    chunkPrimDimN 0 2 0 (t 1395) = allGatherPrimDimN 2 2 0 [q 192, q 495] := by
  have predecessor := frontierSequenceAliasFacts_1395_0 s p t q hs hp hvalues
  have outputs : [q 192, q 495] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 1 2 [q 295, q 598]) := by
    change [q 192, q 495] = [AllToAllSourceFaithful.tensor 2 0 1 2 [q 295, q 598], AllToAllSourceFaithful.tensor 2 1 1 2 [q 295, q 598]]
    exact congrArg₂ List.cons (frontierProjectionExchangeRead_pm_192 p q hp) (congrArg₂ List.cons (frontierProjectionExchangeRead_pm_495 p q hp) (rfl))
  exact SourceSequenceHiddenExchange.output_facts 2 0 2 1 8 32 (t 1395) [q 295, q 598] [q 192, q 495]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierProjectionExchangeUnitFacts_1395_0_192_495
theorem frontierProjectionExchangeRead_pm_195 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 195 = AllToAllSourceFaithful.tensor 2 0 1 2 (([297, 600] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 114) (pmInputRequests.drop 115) pmNode_59 0 [0, 1] [297, 600] 195 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 114 ++ pmInputRequests.drop 114 := (List.take_append_drop 114 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([297, 600] : List Tid), ∀ row ∈ pmInputRequests.drop 114, tid ∉ row.1.outs
    decide
#print axioms frontierProjectionExchangeRead_pm_195
theorem frontierProjectionExchangeRead_pm_498 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 498 = AllToAllSourceFaithful.tensor 2 1 1 2 (([297, 600] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 122) (pmInputRequests.drop 123) pmNode_295 1 [0, 1] [297, 600] 498 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 122 ++ pmInputRequests.drop 122 := (List.take_append_drop 122 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([297, 600] : List Tid), ∀ row ∈ pmInputRequests.drop 122, tid ∉ row.1.outs
    decide
#print axioms frontierProjectionExchangeRead_pm_498
theorem frontierProjectionExchangeUnitFacts_1396_0_195_498 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1396).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 195, q 498], y.shape = [1, 16, 32]) ∧
    chunkPrimDimN 0 2 0 (t 1396) = allGatherPrimDimN 2 2 0 [q 195, q 498] := by
  have predecessor := frontierSequenceAliasFacts_1396_0 s p t q hs hp hvalues
  have outputs : [q 195, q 498] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 1 2 [q 297, q 600]) := by
    change [q 195, q 498] = [AllToAllSourceFaithful.tensor 2 0 1 2 [q 297, q 600], AllToAllSourceFaithful.tensor 2 1 1 2 [q 297, q 600]]
    exact congrArg₂ List.cons (frontierProjectionExchangeRead_pm_195 p q hp) (congrArg₂ List.cons (frontierProjectionExchangeRead_pm_498 p q hp) (rfl))
  exact SourceSequenceHiddenExchange.output_facts 2 0 2 1 8 32 (t 1396) [q 297, q 600] [q 195, q 498]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierProjectionExchangeUnitFacts_1396_0_195_498
theorem frontierProjectionExchangeRead_pm_798 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 798 = AllToAllSourceFaithful.tensor 2 0 1 2 (([901, 1204] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 534) (pmInputRequests.drop 535) pmNode_529 2 [2, 3] [901, 1204] 798 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 534 ++ pmInputRequests.drop 534 := (List.take_append_drop 534 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([901, 1204] : List Tid), ∀ row ∈ pmInputRequests.drop 534, tid ∉ row.1.outs
    decide
#print axioms frontierProjectionExchangeRead_pm_798
theorem frontierProjectionExchangeRead_pm_1101 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1101 = AllToAllSourceFaithful.tensor 2 1 1 2 (([901, 1204] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 542) (pmInputRequests.drop 543) pmNode_765 3 [2, 3] [901, 1204] 1101 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 542 ++ pmInputRequests.drop 542 := (List.take_append_drop 542 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([901, 1204] : List Tid), ∀ row ∈ pmInputRequests.drop 542, tid ∉ row.1.outs
    decide
#print axioms frontierProjectionExchangeRead_pm_1101
theorem frontierProjectionExchangeUnitFacts_1395_1_798_1101 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1395).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 798, q 1101], y.shape = [1, 16, 32]) ∧
    chunkPrimDimN 0 2 1 (t 1395) = allGatherPrimDimN 2 2 0 [q 798, q 1101] := by
  have predecessor := frontierSequenceAliasFacts_1395_1 s p t q hs hp hvalues
  have outputs : [q 798, q 1101] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 1 2 [q 901, q 1204]) := by
    change [q 798, q 1101] = [AllToAllSourceFaithful.tensor 2 0 1 2 [q 901, q 1204], AllToAllSourceFaithful.tensor 2 1 1 2 [q 901, q 1204]]
    exact congrArg₂ List.cons (frontierProjectionExchangeRead_pm_798 p q hp) (congrArg₂ List.cons (frontierProjectionExchangeRead_pm_1101 p q hp) (rfl))
  exact SourceSequenceHiddenExchange.output_facts 2 1 2 1 8 32 (t 1395) [q 901, q 1204] [q 798, q 1101]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierProjectionExchangeUnitFacts_1395_1_798_1101
theorem frontierProjectionExchangeRead_pm_801 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 801 = AllToAllSourceFaithful.tensor 2 0 1 2 (([903, 1206] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 536) (pmInputRequests.drop 537) pmNode_531 2 [2, 3] [903, 1206] 801 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 536 ++ pmInputRequests.drop 536 := (List.take_append_drop 536 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([903, 1206] : List Tid), ∀ row ∈ pmInputRequests.drop 536, tid ∉ row.1.outs
    decide
#print axioms frontierProjectionExchangeRead_pm_801
theorem frontierProjectionExchangeRead_pm_1104 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1104 = AllToAllSourceFaithful.tensor 2 1 1 2 (([903, 1206] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 544) (pmInputRequests.drop 545) pmNode_767 3 [2, 3] [903, 1206] 1104 1 2 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 544 ++ pmInputRequests.drop 544 := (List.take_append_drop 544 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([903, 1206] : List Tid), ∀ row ∈ pmInputRequests.drop 544, tid ∉ row.1.outs
    decide
#print axioms frontierProjectionExchangeRead_pm_1104
theorem frontierProjectionExchangeUnitFacts_1396_1_801_1104 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1396).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 801, q 1104], y.shape = [1, 16, 32]) ∧
    chunkPrimDimN 0 2 1 (t 1396) = allGatherPrimDimN 2 2 0 [q 801, q 1104] := by
  have predecessor := frontierSequenceAliasFacts_1396_1 s p t q hs hp hvalues
  have outputs : [q 801, q 1104] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 1 2 [q 903, q 1206]) := by
    change [q 801, q 1104] = [AllToAllSourceFaithful.tensor 2 0 1 2 [q 903, q 1206], AllToAllSourceFaithful.tensor 2 1 1 2 [q 903, q 1206]]
    exact congrArg₂ List.cons (frontierProjectionExchangeRead_pm_801 p q hp) (congrArg₂ List.cons (frontierProjectionExchangeRead_pm_1104 p q hp) (rfl))
  exact SourceSequenceHiddenExchange.output_facts 2 1 2 1 8 32 (t 1396) [q 903, q 1206] [q 801, q 1104]
    (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierProjectionExchangeUnitFacts_1396_1_801_1104
end
end TrainVerify.Denote.RuntimeWorld
