import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0036
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_286_0 (z : Store) : (s_286 z) 216 = (v_283_0 z) := pR (k_285 z) (pR (k_284 z) (w_283_0 z))
 #a r_286_0
 theorem r_286_1 (z : Store) : (s_286 z) 519 = (v_285_0 z) := w_285_0 z
 #a r_286_1
 def v_286_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 0 [(v_283_0 z), (v_285_0 z)]
 def s_287 (z : Store) : Store := storeSet (s_286 z) [(83, allGatherPrimDimN 2 2 0 [((s_286 z) 216), ((s_286 z) 519)])]
 theorem t_286 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_143) (pmPeers pmNode_143) (s_286 z) pmNode_143 none = some (s_287 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_286 z) pmNode_143 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_286
 theorem k_286 (z : Store) (tid : Tid) (h : tid ∉ [83]) : (s_287 z) tid = (s_286 z) tid := by
   unfold s_287
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_286
 theorem w_286_0 (z : Store) : (s_287 z) 83 = v_286_0 z := by
   unfold s_287
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_286_0, r_286_0 z, r_286_1 z] <;> rfl
 #a w_286_0
 theorem h_286_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_286_0 z).shape = [1, 16, 64] := by
   unfold v_286_0
   exact allGatherPrimDimN_shape 2 2 [(v_283_0 z), (v_285_0 z)] [1, 16, 32] (h_283_0 z z_)
 #a h_286_0
 attribute [local irreducible] v_286_0
 attribute [local irreducible] s_287
 theorem r_287_0 (z : Store) : (s_287 z) 213 = (v_277_0 z) := pR (k_286 z) (pR (k_285 z) (pR (k_284 z) (pR (n_280_284 z) (pR (k_279 z) (pR (k_278 z) (w_277_0 z))))))
 #a r_287_0
 theorem r_287_1 (z : Store) : (s_287 z) 210 = (v_134_0 z) := pR (k_286 z) (pR (k_285 z) (pR (k_284 z) (pR (n_280_284 z) (pR (n_272_280 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_144_160 z) (pR (n_136_144 z) (pR (k_135 z) (r_135_0 z)))))))))))
 #a r_287_1
 def v_287_0 (z : Store) : Tensor := transposeAxes 1 2 (v_277_0 z)
 def s_288 (z : Store) : Store := storeSet (s_287 z) [(212, transposeAxes 1 2 ((s_287 z) 213))]
 theorem t_287 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_144) (pmPeers pmNode_144) (s_287 z) pmNode_144 none = some (s_288 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_287
 theorem k_287 (z : Store) (tid : Tid) (h : tid ∉ [212]) : (s_288 z) tid = (s_287 z) tid := by
   unfold s_288
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_287
 theorem w_287_0 (z : Store) : (s_288 z) 212 = v_287_0 z := by
   unfold s_288
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_287_0, r_287_0 z, r_287_1 z] <;> rfl
 #a w_287_0
 theorem h_287_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_287_0 z).shape = [1, 16, 4, 8] := by
   unfold v_287_0
   change listSwapAt _ _ _ = _
   rw [h_277_0 z z_]
   rfl
 #a h_287_0
 attribute [local irreducible] v_287_0
 attribute [local irreducible] s_288
 theorem r_288_0 (z : Store) : (s_288 z) 216 = (v_283_0 z) := pR (k_287 z) (pR (k_286 z) (r_286_0 z))
 #a r_288_0
 theorem r_288_1 (z : Store) : (s_288 z) 519 = (v_285_0 z) := pR (k_287 z) (pR (k_286 z) (r_286_1 z))
 #a r_288_1
 def v_288_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 1 [(v_283_0 z), (v_285_0 z)]
 def s_289 (z : Store) : Store := storeSet (s_288 z) [(386, allGatherPrimDimN 2 2 1 [((s_288 z) 216), ((s_288 z) 519)])]
 theorem t_288 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_379) (pmPeers pmNode_379) (s_288 z) pmNode_379 none = some (s_289 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_288 z) pmNode_379 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_288
 theorem k_288 (z : Store) (tid : Tid) (h : tid ∉ [386]) : (s_289 z) tid = (s_288 z) tid := by
   unfold s_289
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_288
 theorem w_288_0 (z : Store) : (s_289 z) 386 = v_288_0 z := by
   unfold s_289
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_288_0, r_288_0 z, r_288_1 z] <;> rfl
 #a w_288_0
 theorem h_288_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_288_0 z).shape = [1, 16, 64] := by
   unfold v_288_0
   exact allGatherPrimDimN_shape 2 2 [(v_283_0 z), (v_285_0 z)] [1, 16, 32] (h_283_0 z z_)
 #a h_288_0
 attribute [local irreducible] v_288_0
 attribute [local irreducible] s_289
 theorem n_284_288 (z : Store) (tid : Tid) (h : tid ∉ ([520, 519, 83, 212] : List Tid)) : (s_288 z) tid = (s_284 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_284 z) (k_285 z)) (pF _ _ _ _ _ (k_286 z) (k_287 z)) tid h
 #a n_284_288
 theorem n_280_288 (z : Store) (tid : Tid) (h : tid ∉ ([516, 523, 217, 216, 520, 519, 83, 212] : List Tid)) : (s_288 z) tid = (s_280 z) tid := by
   exact pF _ _ _ _ _ (n_280_284 z) (n_284_288 z) tid h
 #a n_280_288
 theorem n_272_288 (z : Store) (tid : Tid) (h : tid ∉ ([227, 205, 226, 530, 508, 529, 223, 213, 220, 526, 516, 523, 217, 216, 520, 519, 83, 212] : List Tid)) : (s_288 z) tid = (s_272 z) tid := by
   exact pF _ _ _ _ _ (n_272_280 z) (n_280_288 z) tid h
 #a n_272_288
 theorem n_256_288 (z : Store) (tid : Tid) (h : tid ∉ ([242, 241, 545, 544, 237, 235, 238, 541, 538, 540, 221, 234, 524, 537, 231, 230, 534, 533, 227, 205, 226, 530, 508, 529, 223, 213, 220, 526, 516, 523, 217, 216, 520, 519, 83, 212] : List Tid)) : (s_288 z) tid = (s_256 z) tid := by
   exact pF _ _ _ _ _ (n_256_272 z) (n_272_288 z) tid h
 #a n_256_288
 theorem r_289_0 (z : Store) : (s_289 z) 516 = (v_280_0 z) := pR (k_288 z) (pR (n_284_288 z) (pR (k_283 z) (pR (k_282 z) (pR (k_281 z) (w_280_0 z)))))
 #a r_289_0
 theorem r_289_1 (z : Store) : (s_289 z) 513 = (v_138_0 z) := pR (k_288 z) (pR (n_256_288 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_144_160 z) (pR (n_140_144 z) (pR (k_139 z) (r_139_0 z)))))))
 #a r_289_1
 def v_289_0 (z : Store) : Tensor := transposeAxes 1 2 (v_280_0 z)
 def s_290 (z : Store) : Store := storeSet (s_289 z) [(515, transposeAxes 1 2 ((s_289 z) 516))]
 theorem t_289 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_380) (pmPeers pmNode_380) (s_289 z) pmNode_380 none = some (s_290 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_289
 theorem k_289 (z : Store) (tid : Tid) (h : tid ∉ [515]) : (s_290 z) tid = (s_289 z) tid := by
   unfold s_290
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_289
 theorem w_289_0 (z : Store) : (s_290 z) 515 = v_289_0 z := by
   unfold s_290
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_289_0, r_289_0 z, r_289_1 z] <;> rfl
 #a w_289_0
 theorem h_289_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_289_0 z).shape = [1, 16, 4, 8] := by
   unfold v_289_0
   change listSwapAt _ _ _ = _
   rw [h_280_0 z z_]
   rfl
 #a h_289_0
 attribute [local irreducible] v_289_0
 attribute [local irreducible] s_290
 theorem r_290_0 (z : Store) : (s_290 z) 212 = (v_287_0 z) := pR (k_289 z) (pR (k_288 z) (w_287_0 z))
 #a r_290_0
 theorem r_290_1 (z : Store) : (s_290 z) 515 = (v_289_0 z) := w_289_0 z
 #a r_290_1
 def v_290_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_287_0 z), (v_289_0 z)]
 theorem g_290 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_145) (s_290 z) pmNode_145 3 1 209 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_145, r_290_0 z, r_290_1 z, h_287_0 z z_, h_289_0 z z_]
 #a g_290
 def s_291 (z : Store) : Store := pL [0, 1] (s_290 z) pmNode_145 3 1
 theorem t_290 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_145) (pmPeers pmNode_145) (s_290 z) pmNode_145 none = some (s_291 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_145) (s_290 z) pmNode_145).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 209 (by decide) (g_290 z z_)]
   rfl
 #a t_290
 theorem k_290 (z : Store) (tid : Tid) (h : tid ∉ [209]) : (s_291 z) tid = (s_290 z) tid := by
   unfold s_291
   dsimp only [pL, pmNode_145, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_290
 theorem w_290_0 (z : Store) : (s_291 z) 209 = v_290_0 z := by
   unfold s_291
   dsimp only [pL, pmNode_145, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_290_0, r_290_0 z, r_290_1 z] <;> rfl
 #a w_290_0
 theorem h_290_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_290_0 z).shape = [1, 8, 4, 16] := by
   unfold v_290_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_287_0 z z_]
 #a h_290_0
 attribute [local irreducible] v_290_0
 attribute [local irreducible] s_291
 theorem r_291_0 (z : Store) : (s_291 z) 209 = (v_290_0 z) := w_290_0 z
 #a r_291_0
 theorem r_291_1 (z : Store) : (s_291 z) 206 = (v_128_0 z) := pR (k_290 z) (pR (k_289 z) (pR (k_288 z) (pR (n_256_288 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_144_160 z) (pR (n_136_144 z) (pR (n_132_136 z) (pR (k_131 z) (pR (k_130 z) (pR (k_129 z) (r_129_0 z))))))))))))
 #a r_291_1
 def v_291_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_290_0 z)
 def s_292 (z : Store) : Store := storeSet (s_291 z) [(208, fw_view [1, 8, 64] ((s_291 z) 209))]
 theorem t_291 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_146) (pmPeers pmNode_146) (s_291 z) pmNode_146 none = some (s_292 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_291
 theorem k_291 (z : Store) (tid : Tid) (h : tid ∉ [208]) : (s_292 z) tid = (s_291 z) tid := by
   unfold s_292
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_291
 theorem w_291_0 (z : Store) : (s_292 z) 208 = v_291_0 z := by
   unfold s_292
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_291_0, r_291_0 z, r_291_1 z] <;> rfl
 #a w_291_0
 theorem h_291_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_291_0 z).shape = [1, 8, 64] := by
   unfold v_291_0
   rfl
 #a h_291_0
 attribute [local irreducible] v_291_0
 attribute [local irreducible] s_292
 theorem r_292_0 (z : Store) : (s_292 z) 212 = (v_287_0 z) := pR (k_291 z) (pR (k_290 z) (r_290_0 z))
 #a r_292_0
 theorem r_292_1 (z : Store) : (s_292 z) 515 = (v_289_0 z) := pR (k_291 z) (pR (k_290 z) (r_290_1 z))
 #a r_292_1
 def v_292_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_287_0 z), (v_289_0 z)]
 theorem g_292 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_381) (s_292 z) pmNode_381 3 1 512 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_381, r_292_0 z, r_292_1 z, h_287_0 z z_, h_289_0 z z_]
 #a g_292
 def s_293 (z : Store) : Store := pL [0, 1] (s_292 z) pmNode_381 3 1
 theorem t_292 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_381) (pmPeers pmNode_381) (s_292 z) pmNode_381 none = some (s_293 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_381) (s_292 z) pmNode_381).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 512 (by decide) (g_292 z z_)]
   rfl
 #a t_292
 theorem k_292 (z : Store) (tid : Tid) (h : tid ∉ [512]) : (s_293 z) tid = (s_292 z) tid := by
   unfold s_293
   dsimp only [pL, pmNode_381, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_292
 theorem w_292_0 (z : Store) : (s_293 z) 512 = v_292_0 z := by
   unfold s_293
   dsimp only [pL, pmNode_381, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_292_0, r_292_0 z, r_292_1 z] <;> rfl
 #a w_292_0
 theorem h_292_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_292_0 z).shape = [1, 8, 4, 16] := by
   unfold v_292_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_287_0 z z_]
 #a h_292_0
 attribute [local irreducible] v_292_0
 attribute [local irreducible] s_293
 theorem n_288_292 (z : Store) (tid : Tid) (h : tid ∉ ([386, 515, 209, 208] : List Tid)) : (s_292 z) tid = (s_288 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_288 z) (k_289 z)) (pF _ _ _ _ _ (k_290 z) (k_291 z)) tid h
 #a n_288_292
 theorem r_293_0 (z : Store) : (s_293 z) 512 = (v_292_0 z) := w_292_0 z
 #a r_293_0
 theorem r_293_1 (z : Store) : (s_293 z) 509 = (v_132_0 z) := pR (k_292 z) (pR (n_288_292 z) (pR (n_256_288 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_144_160 z) (pR (n_136_144 z) (pR (k_135 z) (pR (k_134 z) (pR (k_133 z) (r_133_0 z))))))))))
 #a r_293_1
 def v_293_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_292_0 z)
 def s_294 (z : Store) : Store := storeSet (s_293 z) [(511, fw_view [1, 8, 64] ((s_293 z) 512))]
 theorem t_293 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_382) (pmPeers pmNode_382) (s_293 z) pmNode_382 none = some (s_294 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_293
 theorem k_293 (z : Store) (tid : Tid) (h : tid ∉ [511]) : (s_294 z) tid = (s_293 z) tid := by
   unfold s_294
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_293
 theorem w_293_0 (z : Store) : (s_294 z) 511 = v_293_0 z := by
   unfold s_294
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_293_0, r_293_0 z, r_293_1 z] <;> rfl
 #a w_293_0
 theorem h_293_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_293_0 z).shape = [1, 8, 64] := by
   unfold v_293_0
   rfl
 #a h_293_0
 attribute [local irreducible] v_293_0
 attribute [local irreducible] s_294
 theorem r_294_0 (z : Store) : (s_294 z) 208 = (v_291_0 z) := pR (k_293 z) (pR (k_292 z) (w_291_0 z))
 #a r_294_0
 theorem r_294_1 (z : Store) : (s_294 z) 511 = (v_293_0 z) := w_293_0 z
 #a r_294_1
 def v_294_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_291_0 z), (v_293_0 z)]
 def s_295 (z : Store) : Store := storeSet (s_294 z) [(82, allGatherPrimDimN 1 2 0 [((s_294 z) 208), ((s_294 z) 511)])]
 theorem t_294 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_147) (pmPeers pmNode_147) (s_294 z) pmNode_147 none = some (s_295 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_294 z) pmNode_147 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_294
 theorem k_294 (z : Store) (tid : Tid) (h : tid ∉ [82]) : (s_295 z) tid = (s_294 z) tid := by
   unfold s_295
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_294
 theorem w_294_0 (z : Store) : (s_295 z) 82 = v_294_0 z := by
   unfold s_295
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_294_0, r_294_0 z, r_294_1 z] <;> rfl
 #a w_294_0
 theorem h_294_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_294_0 z).shape = [1, 16, 64] := by
   unfold v_294_0
   exact allGatherPrimDimN_shape 1 2 [(v_291_0 z), (v_293_0 z)] [1, 8, 64] (h_291_0 z z_)
 #a h_294_0
 attribute [local irreducible] v_294_0
 attribute [local irreducible] s_295
 theorem n_128_256 (z : Store) (tid : Tid) (h : tid ∉ ([206, 207, 505, 506, 509, 510, 210, 211, 214, 215, 513, 514, 517, 518, 218, 219, 222, 521, 522, 525, 224, 225, 527, 528, 228, 229, 531, 532, 232, 233, 79, 236, 535, 536, 382, 539, 239, 240, 542, 543, 243, 244, 546, 547, 247, 248, 251, 550, 551, 554, 253, 254, 299, 301, 556, 557, 602, 604, 258, 259, 561, 562, 262, 263, 565, 566, 265, 266, 269, 271, 272, 275, 568, 569, 572, 574, 575, 578, 80, 277, 383, 580, 280, 281, 583, 584, 77, 282, 380, 585, 278, 279, 73, 582, 581, 376, 276, 274, 68, 70, 273, 270, 579, 577, 371, 373, 576, 573, 302, 268, 66, 267, 605, 571, 369, 570, 85, 264, 64, 388, 567, 367, 261, 260, 59, 61, 564, 563, 362, 364, 300, 257, 255, 256, 603, 560, 558, 559, 84, 250, 57, 249, 387, 553, 360, 552, 246, 245, 549, 548] : List Tid)) : (s_256 z) tid = (s_128 z) tid := by
   exact pF _ _ _ _ _ (n_128_192 z) (n_192_256 z) tid h
 #a n_128_256
 record_prefix_opacity v_286_0 s_287 v_287_0 s_288 v_288_0 s_289 v_289_0 s_290 v_290_0 s_291 v_291_0 s_292 v_292_0 s_293 v_293_0 s_294 v_294_0 s_295

 end
 end TrainVerify.Denote.RuntimeWorld
