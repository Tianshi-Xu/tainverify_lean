import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0058
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_457_0 (z : Store) : (s_457 z) 718 = (v_447_0 z) := pR (k_456 z) (pR (k_455 z) (pR (k_454 z) (r_454_0 z)))
 #a r_457_0
 theorem r_457_1 (z : Store) : (s_457 z) 1021 = (v_453_0 z) := pR (k_456 z) (pR (k_455 z) (pR (k_454 z) (r_454_1 z)))
 #a r_457_1
 def v_457_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_447_0 z), (v_453_0 z)]
 theorem g_457 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_724) (s_457 z) pmNode_724 1 3 1023 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_724, r_457_0 z, r_457_1 z, h_447_0 z z_, h_453_0 z z_]
 #a g_457
 def s_458 (z : Store) : Store := pL [2, 3] (s_457 z) pmNode_724 1 3
 theorem t_457 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_724) (pmPeers pmNode_724) (s_457 z) pmNode_724 none = some (s_458 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_724) (s_457 z) pmNode_724).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 1023 (by decide) (g_457 z z_)]
   rfl
 #a t_457
 theorem k_457 (z : Store) (tid : Tid) (h : tid ∉ [1023]) : (s_458 z) tid = (s_457 z) tid := by
   unfold s_458
   dsimp only [pL, pmNode_724, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_457
 theorem w_457_0 (z : Store) : (s_458 z) 1023 = v_457_0 z := by
   unfold s_458
   dsimp only [pL, pmNode_724, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_457_0, r_457_0 z, r_457_1 z] <;> rfl
 #a w_457_0
 theorem h_457_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_457_0 z).shape = [1, 16, 4, 8] := by
   unfold v_457_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_447_0 z z_]
 #a h_457_0
 attribute [local irreducible] v_457_0
 attribute [local irreducible] s_458
 theorem r_458_0 (z : Store) : (s_458 z) 1023 = (v_457_0 z) := w_457_0 z
 #a r_458_0
 def v_458_0 (z : Store) : Tensor := transposeAxes 1 2 (v_457_0 z)
 def s_459 (z : Store) : Store := storeSet (s_458 z) [(1024, transposeAxes 1 2 ((s_458 z) 1023))]
 theorem t_458 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_725) (pmPeers pmNode_725) (s_458 z) pmNode_725 none = some (s_459 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_458
 theorem k_458 (z : Store) (tid : Tid) (h : tid ∉ [1024]) : (s_459 z) tid = (s_458 z) tid := by
   unfold s_459
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_458
 theorem w_458_0 (z : Store) : (s_459 z) 1024 = v_458_0 z := by
   unfold s_459
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_458_0, r_458_0 z] <;> rfl
 #a w_458_0
 theorem h_458_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_458_0 z).shape = [1, 4, 16, 8] := by
   unfold v_458_0
   change listSwapAt _ _ _ = _
   rw [h_457_0 z z_]
   rfl
 #a h_458_0
 attribute [local irreducible] v_458_0
 attribute [local irreducible] s_459
 theorem r_459_0 (z : Store) : (s_459 z) 1015 = (v_450_0 z) := pR (k_458 z) (pR (k_457 z) (pR (k_456 z) (pR (n_452_456 z) (pR (k_451 z) (w_450_0 z)))))
 #a r_459_0
 def v_459_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_450_0 z)
 def s_460 (z : Store) : Store := storeSet (s_459 z) [(1027, fw_view [1, 16, 2, 16] ((s_459 z) 1015))]
 theorem t_459 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_726) (pmPeers pmNode_726) (s_459 z) pmNode_726 none = some (s_460 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_459
 theorem k_459 (z : Store) (tid : Tid) (h : tid ∉ [1027]) : (s_460 z) tid = (s_459 z) tid := by
   unfold s_460
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_459
 theorem w_459_0 (z : Store) : (s_460 z) 1027 = v_459_0 z := by
   unfold s_460
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_459_0, r_459_0 z] <;> rfl
 #a w_459_0
 theorem h_459_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_459_0 z).shape = [1, 16, 2, 16] := by
   unfold v_459_0
   rfl
 #a h_459_0
 attribute [local irreducible] v_459_0
 attribute [local irreducible] s_460
 theorem r_460_0 (z : Store) : (s_460 z) 724 = (v_456_0 z) := pR (k_459 z) (pR (k_458 z) (pR (k_457 z) (w_456_0 z)))
 #a r_460_0
 theorem r_460_1 (z : Store) : (s_460 z) 1027 = (v_459_0 z) := w_459_0 z
 #a r_460_1
 def v_460_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 3 [(v_456_0 z), (v_459_0 z)]
 theorem g_460 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_491) (s_460 z) pmNode_491 2 3 726 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_491, r_460_0 z, r_460_1 z, h_456_0 z z_, h_459_0 z z_]
 #a g_460
 def s_461 (z : Store) : Store := pL [2, 3] (s_460 z) pmNode_491 2 3
 theorem t_460 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_491) (pmPeers pmNode_491) (s_460 z) pmNode_491 none = some (s_461 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_491) (s_460 z) pmNode_491).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 3 726 (by decide) (g_460 z z_)]
   rfl
 #a t_460
 theorem k_460 (z : Store) (tid : Tid) (h : tid ∉ [726]) : (s_461 z) tid = (s_460 z) tid := by
   unfold s_461
   dsimp only [pL, pmNode_491, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_460
 theorem w_460_0 (z : Store) : (s_461 z) 726 = v_460_0 z := by
   unfold s_461
   dsimp only [pL, pmNode_491, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_460_0, r_460_0 z, r_460_1 z] <;> rfl
 #a w_460_0
 theorem h_460_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_460_0 z).shape = [1, 16, 4, 8] := by
   unfold v_460_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_456_0 z z_]
 #a h_460_0
 attribute [local irreducible] v_460_0
 attribute [local irreducible] s_461
 theorem r_461_0 (z : Store) : (s_461 z) 726 = (v_460_0 z) := w_460_0 z
 #a r_461_0
 def v_461_0 (z : Store) : Tensor := transposeAxes 1 2 (v_460_0 z)
 def s_462 (z : Store) : Store := storeSet (s_461 z) [(727, transposeAxes 1 2 ((s_461 z) 726))]
 theorem t_461 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_492) (pmPeers pmNode_492) (s_461 z) pmNode_492 none = some (s_462 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_461
 theorem k_461 (z : Store) (tid : Tid) (h : tid ∉ [727]) : (s_462 z) tid = (s_461 z) tid := by
   unfold s_462
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_461
 theorem w_461_0 (z : Store) : (s_462 z) 727 = v_461_0 z := by
   unfold s_462
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_461_0, r_461_0 z] <;> rfl
 #a w_461_0
 theorem h_461_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_461_0 z).shape = [1, 4, 16, 8] := by
   unfold v_461_0
   change listSwapAt _ _ _ = _
   rw [h_460_0 z z_]
   rfl
 #a h_461_0
 attribute [local irreducible] v_461_0
 attribute [local irreducible] s_462
 theorem n_456_460 (z : Store) (tid : Tid) (h : tid ∉ ([724, 1023, 1024, 1027] : List Tid)) : (s_460 z) tid = (s_456 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_456 z) (k_457 z)) (pF _ _ _ _ _ (k_458 z) (k_459 z)) tid h
 #a n_456_460
 theorem r_462_0 (z : Store) : (s_462 z) 715 = (v_446_0 z) := pR (k_461 z) (pR (k_460 z) (pR (n_456_460 z) (pR (n_448_456 z) (pR (k_447 z) (w_446_0 z)))))
 #a r_462_0
 theorem r_462_1 (z : Store) : (s_462 z) 1018 = (v_452_0 z) := pR (k_461 z) (pR (k_460 z) (pR (n_456_460 z) (pR (k_455 z) (pR (k_454 z) (pR (k_453 z) (w_452_0 z))))))
 #a r_462_1
 def v_462_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_446_0 z), (v_452_0 z)]
 theorem g_462 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_493) (s_462 z) pmNode_493 2 1 730 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_493, r_462_0 z, r_462_1 z, h_446_0 z z_, h_452_0 z z_]
 #a g_462
 def s_463 (z : Store) : Store := pL [2, 3] (s_462 z) pmNode_493 2 1
 theorem t_462 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_493) (pmPeers pmNode_493) (s_462 z) pmNode_493 none = some (s_463 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_493) (s_462 z) pmNode_493).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 730 (by decide) (g_462 z z_)]
   rfl
 #a t_462
 theorem k_462 (z : Store) (tid : Tid) (h : tid ∉ [730]) : (s_463 z) tid = (s_462 z) tid := by
   unfold s_463
   dsimp only [pL, pmNode_493, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_462
 theorem w_462_0 (z : Store) : (s_463 z) 730 = v_462_0 z := by
   unfold s_463
   dsimp only [pL, pmNode_493, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_462_0, r_462_0 z, r_462_1 z] <;> rfl
 #a w_462_0
 theorem h_462_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_462_0 z).shape = [1, 8, 64] := by
   unfold v_462_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_446_0 z z_]
 #a h_462_0
 attribute [local irreducible] v_462_0
 attribute [local irreducible] s_463
 theorem r_463_0 (z : Store) : (s_463 z) 730 = (v_462_0 z) := w_462_0 z
 #a r_463_0
 def v_463_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_462_0 z)
 def s_464 (z : Store) : Store := storeSet (s_463 z) [(731, fw_view [1, 8, 4, 16] ((s_463 z) 730))]
 theorem t_463 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_494) (pmPeers pmNode_494) (s_463 z) pmNode_494 none = some (s_464 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_463
 theorem k_463 (z : Store) (tid : Tid) (h : tid ∉ [731]) : (s_464 z) tid = (s_463 z) tid := by
   unfold s_464
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_463
 theorem w_463_0 (z : Store) : (s_464 z) 731 = v_463_0 z := by
   unfold s_464
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_463_0, r_463_0 z] <;> rfl
 #a w_463_0
 theorem h_463_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_463_0 z).shape = [1, 8, 4, 16] := by
   unfold v_463_0
   rfl
 #a h_463_0
 attribute [local irreducible] v_463_0
 attribute [local irreducible] s_464
 theorem r_464_0 (z : Store) : (s_464 z) 731 = (v_463_0 z) := w_463_0 z
 #a r_464_0
 def v_464_0 (z : Store) : Tensor := transposeAxes 1 2 (v_463_0 z)
 def s_465 (z : Store) : Store := storeSet (s_464 z) [(734, transposeAxes 1 2 ((s_464 z) 731))]
 theorem t_464 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_495) (pmPeers pmNode_495) (s_464 z) pmNode_495 none = some (s_465 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_464
 theorem k_464 (z : Store) (tid : Tid) (h : tid ∉ [734]) : (s_465 z) tid = (s_464 z) tid := by
   unfold s_465
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_464
 theorem w_464_0 (z : Store) : (s_465 z) 734 = v_464_0 z := by
   unfold s_465
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_464_0, r_464_0 z] <;> rfl
 #a w_464_0
 theorem h_464_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_464_0 z).shape = [1, 4, 8, 16] := by
   unfold v_464_0
   change listSwapAt _ _ _ = _
   rw [h_463_0 z z_]
   rfl
 #a h_464_0
 attribute [local irreducible] v_464_0
 attribute [local irreducible] s_465
 theorem r_465_0 (z : Store) : (s_465 z) 727 = (v_461_0 z) := pR (k_464 z) (pR (k_463 z) (pR (k_462 z) (w_461_0 z)))
 #a r_465_0
 def v_465_0 (z : Store) : Tensor := transposeAxes 2 3 (v_461_0 z)
 def s_466 (z : Store) : Store := storeSet (s_465 z) [(736, transposeAxes 2 3 ((s_465 z) 727))]
 theorem t_465 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_496) (pmPeers pmNode_496) (s_465 z) pmNode_496 none = some (s_466 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_465
 theorem k_465 (z : Store) (tid : Tid) (h : tid ∉ [736]) : (s_466 z) tid = (s_465 z) tid := by
   unfold s_466
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_465
 theorem w_465_0 (z : Store) : (s_466 z) 736 = v_465_0 z := by
   unfold s_466
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_465_0, r_465_0 z] <;> rfl
 #a w_465_0
 theorem h_465_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_465_0 z).shape = [1, 4, 8, 16] := by
   unfold v_465_0
   change listSwapAt _ _ _ = _
   rw [h_461_0 z z_]
   rfl
 #a h_465_0
 attribute [local irreducible] v_465_0
 attribute [local irreducible] s_466
 theorem n_460_464 (z : Store) (tid : Tid) (h : tid ∉ ([726, 727, 730, 731] : List Tid)) : (s_464 z) tid = (s_460 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_460 z) (k_461 z)) (pF _ _ _ _ _ (k_462 z) (k_463 z)) tid h
 #a n_460_464
 theorem n_456_464 (z : Store) (tid : Tid) (h : tid ∉ ([724, 1023, 1024, 1027, 726, 727, 730, 731] : List Tid)) : (s_464 z) tid = (s_456 z) tid := by
   exact pF _ _ _ _ _ (n_456_460 z) (n_460_464 z) tid h
 #a n_456_464
 record_prefix_opacity v_457_0 s_458 v_458_0 s_459 v_459_0 s_460 v_460_0 s_461 v_461_0 s_462 v_462_0 s_463 v_463_0 s_464 v_464_0 s_465 v_465_0 s_466

 end
 end TrainVerify.Denote.RuntimeWorld
