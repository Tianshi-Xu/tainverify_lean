import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0084
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_672_0 (z : Store) : (s_672 z) 993 = (v_671_0 z) := w_671_0 z
 #a r_672_0
 theorem r_672_1 (z : Store) : (s_672 z) 1157 = (v_598_0 z) := pR (n_640_672 z) (pR (n_608_640 z) (pR (n_600_608 z) (pR (k_599 z) (r_599_0 z))))
 #a r_672_1
 theorem r_672_2 (z : Store) : (s_672 z) 965 = (z 965) := pR (n_640_672 z) (pR (n_608_640 z) (pR (n_600_608 z) (pR (k_599 z) (r_599_1 z))))
 #a r_672_2
 def v_672_0 (z : Store) : Tensor := (bw_linear (v_671_0 z) (v_598_0 z) (z 965)).1
 def v_672_1 (z : Store) : Tensor := (bw_linear (v_671_0 z) (v_598_0 z) (z 965)).2
 def s_673 (z : Store) : Store := storeSet (s_672 z) [(1159, (bw_linear ((s_672 z) 993) ((s_672 z) 1157) ((s_672 z) 965)).1), (966, (bw_linear ((s_672 z) 993) ((s_672 z) 1157) ((s_672 z) 965)).2)]
 theorem t_672 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_832) (pmPeers pmNode_832) (s_672 z) pmNode_832 none = some (s_673 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_672
 theorem k_672 (z : Store) (tid : Tid) (h : tid ∉ [1159, 966]) : (s_673 z) tid = (s_672 z) tid := by
   unfold s_673
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_672
 theorem w_672_0 (z : Store) : (s_673 z) 1159 = v_672_0 z := by
   unfold s_673
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_672_0, r_672_0 z, r_672_1 z, r_672_2 z] <;> rfl
 #a w_672_0
 theorem h_672_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_672_0 z).shape = [1, 16, 32] := by
   unfold v_672_0
   exact bw_linear_3d_fst_shape 1 16 64 32 (v_671_0 z) (v_598_0 z) (z 965) (h_671_0 z z_) (h_598_0 z z_) (i_85 z z_)
 #a h_672_0
 attribute [local irreducible] v_672_0
 theorem w_672_1 (z : Store) : (s_673 z) 966 = v_672_1 z := by
   unfold s_673
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_672_1, r_672_0 z, r_672_1 z, r_672_2 z] <;> rfl
 #a w_672_1
 theorem h_672_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_672_1 z).shape = [64, 32] := by
   unfold v_672_1
   exact bw_linear_3d_snd_shape 1 16 64 32 (v_671_0 z) (v_598_0 z) (z 965) (h_671_0 z z_) (h_598_0 z z_) (i_85 z z_)
 #a h_672_1
 attribute [local irreducible] v_672_1
 attribute [local irreducible] s_673
 theorem r_673_0 (z : Store) : (s_673 z) 1159 = (v_672_0 z) := w_672_0 z
 #a r_673_0
 theorem r_673_1 (z : Store) : (s_673 z) 1156 = (v_597_0 z) := pR (k_672 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_600_608 z) (pR (k_599 z) (pR (k_598 z) (r_598_0 z))))))
 #a r_673_1
 def v_673_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_672_0 z)
 def s_674 (z : Store) : Store := storeSet (s_673 z) [(1158, fw_view [1, 16, 2, 16] ((s_673 z) 1159))]
 theorem t_673 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_833) (pmPeers pmNode_833) (s_673 z) pmNode_833 none = some (s_674 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_673
 theorem k_673 (z : Store) (tid : Tid) (h : tid ∉ [1158]) : (s_674 z) tid = (s_673 z) tid := by
   unfold s_674
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_673
 theorem w_673_0 (z : Store) : (s_674 z) 1158 = v_673_0 z := by
   unfold s_674
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_673_0, r_673_0 z, r_673_1 z] <;> rfl
 #a w_673_0
 theorem h_673_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_673_0 z).shape = [1, 16, 2, 16] := by
   unfold v_673_0
   rfl
 #a h_673_0
 attribute [local irreducible] v_673_0
 attribute [local irreducible] s_674
 theorem r_674_0 (z : Store) : (s_674 z) 855 = (v_670_0 z) := pR (k_673 z) (pR (k_672 z) (pR (k_671 z) (w_670_0 z)))
 #a r_674_0
 theorem r_674_1 (z : Store) : (s_674 z) 1158 = (v_673_0 z) := w_673_0 z
 #a r_674_1
 def v_674_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_670_0 z), (v_673_0 z)]
 theorem g_674 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_598) (s_674 z) pmNode_598 2 1 852 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_598, r_674_0 z, r_674_1 z, h_670_0 z z_, h_673_0 z z_]
 #a g_674
 def s_675 (z : Store) : Store := pL [2, 3] (s_674 z) pmNode_598 2 1
 theorem t_674 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_598) (pmPeers pmNode_598) (s_674 z) pmNode_598 none = some (s_675 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_598) (s_674 z) pmNode_598).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 852 (by decide) (g_674 z z_)]
   rfl
 #a t_674
 theorem k_674 (z : Store) (tid : Tid) (h : tid ∉ [852]) : (s_675 z) tid = (s_674 z) tid := by
   unfold s_675
   dsimp only [pL, pmNode_598, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_674
 theorem w_674_0 (z : Store) : (s_675 z) 852 = v_674_0 z := by
   unfold s_675
   dsimp only [pL, pmNode_598, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_674_0, r_674_0 z, r_674_1 z] <;> rfl
 #a w_674_0
 theorem h_674_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_674_0 z).shape = [1, 8, 4, 16] := by
   unfold v_674_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_670_0 z z_]
 #a h_674_0
 attribute [local irreducible] v_674_0
 attribute [local irreducible] s_675
 theorem r_675_0 (z : Store) : (s_675 z) 852 = (v_674_0 z) := w_674_0 z
 #a r_675_0
 theorem r_675_1 (z : Store) : (s_675 z) 849 = (v_590_0 z) := pR (k_674 z) (pR (k_673 z) (pR (k_672 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_592_608 z) (pR (k_591 z) (r_591_0 z)))))))
 #a r_675_1
 def v_675_0 (z : Store) : Tensor := (v_674_0 z)
 def s_676 (z : Store) : Store := storeSet (s_675 z) [(851, ((s_675 z) 852))]
 theorem t_675 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_599) (pmPeers pmNode_599) (s_675 z) pmNode_599 none = some (s_676 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_675
 theorem k_675 (z : Store) (tid : Tid) (h : tid ∉ [851]) : (s_676 z) tid = (s_675 z) tid := by
   unfold s_676
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_675
 theorem w_675_0 (z : Store) : (s_676 z) 851 = v_675_0 z := by
   unfold s_676
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_675_0, r_675_0 z, r_675_1 z] <;> rfl
 #a w_675_0
 theorem h_675_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_675_0 z).shape = [1, 8, 4, 16] := by
   unfold v_675_0
   exact h_674_0 z z_
 #a h_675_0
 attribute [local irreducible] v_675_0
 attribute [local irreducible] s_676
 theorem r_676_0 (z : Store) : (s_676 z) 855 = (v_670_0 z) := pR (k_675 z) (pR (k_674 z) (r_674_0 z))
 #a r_676_0
 theorem r_676_1 (z : Store) : (s_676 z) 1158 = (v_673_0 z) := pR (k_675 z) (pR (k_674 z) (r_674_1 z))
 #a r_676_1
 def v_676_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_670_0 z), (v_673_0 z)]
 theorem g_676 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_834) (s_676 z) pmNode_834 2 1 1155 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_834, r_676_0 z, r_676_1 z, h_670_0 z z_, h_673_0 z z_]
 #a g_676
 def s_677 (z : Store) : Store := pL [2, 3] (s_676 z) pmNode_834 2 1
 theorem t_676 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_834) (pmPeers pmNode_834) (s_676 z) pmNode_834 none = some (s_677 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_834) (s_676 z) pmNode_834).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1155 (by decide) (g_676 z z_)]
   rfl
 #a t_676
 theorem k_676 (z : Store) (tid : Tid) (h : tid ∉ [1155]) : (s_677 z) tid = (s_676 z) tid := by
   unfold s_677
   dsimp only [pL, pmNode_834, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_676
 theorem w_676_0 (z : Store) : (s_677 z) 1155 = v_676_0 z := by
   unfold s_677
   dsimp only [pL, pmNode_834, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_676_0, r_676_0 z, r_676_1 z] <;> rfl
 #a w_676_0
 theorem h_676_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_676_0 z).shape = [1, 8, 4, 16] := by
   unfold v_676_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_670_0 z z_]
 #a h_676_0
 attribute [local irreducible] v_676_0
 attribute [local irreducible] s_677
 theorem n_672_676 (z : Store) (tid : Tid) (h : tid ∉ ([1159, 966, 1158, 852, 851] : List Tid)) : (s_676 z) tid = (s_672 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_672 z) (k_673 z)) (pF _ _ _ _ _ (k_674 z) (k_675 z)) tid h
 #a n_672_676
 theorem r_677_0 (z : Store) : (s_677 z) 1155 = (v_676_0 z) := w_676_0 z
 #a r_677_0
 theorem r_677_1 (z : Store) : (s_677 z) 1152 = (v_592_0 z) := pR (k_676 z) (pR (n_672_676 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_600_608 z) (pR (n_596_600 z) (pR (k_595 z) (pR (k_594 z) (pR (k_593 z) (r_593_0 z)))))))))
 #a r_677_1
 def v_677_0 (z : Store) : Tensor := (v_676_0 z)
 def s_678 (z : Store) : Store := storeSet (s_677 z) [(1154, ((s_677 z) 1155))]
 theorem t_677 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_835) (pmPeers pmNode_835) (s_677 z) pmNode_835 none = some (s_678 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_677
 theorem k_677 (z : Store) (tid : Tid) (h : tid ∉ [1154]) : (s_678 z) tid = (s_677 z) tid := by
   unfold s_678
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_677
 theorem w_677_0 (z : Store) : (s_678 z) 1154 = v_677_0 z := by
   unfold s_678
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_677_0, r_677_0 z, r_677_1 z] <;> rfl
 #a w_677_0
 theorem h_677_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_677_0 z).shape = [1, 8, 4, 16] := by
   unfold v_677_0
   exact h_676_0 z z_
 #a h_677_0
 attribute [local irreducible] v_677_0
 attribute [local irreducible] s_678
 theorem r_678_0 (z : Store) : (s_678 z) 851 = (v_675_0 z) := pR (k_677 z) (pR (k_676 z) (w_675_0 z))
 #a r_678_0
 theorem r_678_1 (z : Store) : (s_678 z) 1154 = (v_677_0 z) := w_677_0 z
 #a r_678_1
 def v_678_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_675_0 z), (v_677_0 z)]
 theorem g_678 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_600) (s_678 z) pmNode_600 1 2 848 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_600, r_678_0 z, r_678_1 z, h_675_0 z z_, h_677_0 z z_]
 #a g_678
 def s_679 (z : Store) : Store := pL [2, 3] (s_678 z) pmNode_600 1 2
 theorem t_678 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_600) (pmPeers pmNode_600) (s_678 z) pmNode_600 none = some (s_679 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_600) (s_678 z) pmNode_600).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 848 (by decide) (g_678 z z_)]
   rfl
 #a t_678
 theorem k_678 (z : Store) (tid : Tid) (h : tid ∉ [848]) : (s_679 z) tid = (s_678 z) tid := by
   unfold s_679
   dsimp only [pL, pmNode_600, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_678
 theorem w_678_0 (z : Store) : (s_679 z) 848 = v_678_0 z := by
   unfold s_679
   dsimp only [pL, pmNode_600, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_678_0, r_678_0 z, r_678_1 z] <;> rfl
 #a w_678_0
 theorem h_678_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_678_0 z).shape = [1, 16, 2, 16] := by
   unfold v_678_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_675_0 z z_]
 #a h_678_0
 attribute [local irreducible] v_678_0
 attribute [local irreducible] s_679
 theorem r_679_0 (z : Store) : (s_679 z) 848 = (v_678_0 z) := w_678_0 z
 #a r_679_0
 theorem r_679_1 (z : Store) : (s_679 z) 845 = (v_586_0 z) := pR (k_678 z) (pR (k_677 z) (pR (k_676 z) (pR (n_672_676 z) (pR (n_640_672 z) (pR (n_608_640 z) (pR (n_592_608 z) (pR (n_588_592 z) (pR (k_587 z) (r_587_0 z)))))))))
 #a r_679_1
 def v_679_0 (z : Store) : Tensor := transposeAxes 1 2 (v_678_0 z)
 def s_680 (z : Store) : Store := storeSet (s_679 z) [(847, transposeAxes 1 2 ((s_679 z) 848))]
 theorem t_679 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_601) (pmPeers pmNode_601) (s_679 z) pmNode_601 none = some (s_680 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_679
 theorem k_679 (z : Store) (tid : Tid) (h : tid ∉ [847]) : (s_680 z) tid = (s_679 z) tid := by
   unfold s_680
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_679
 theorem w_679_0 (z : Store) : (s_680 z) 847 = v_679_0 z := by
   unfold s_680
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_679_0, r_679_0 z, r_679_1 z] <;> rfl
 #a w_679_0
 theorem h_679_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_679_0 z).shape = [1, 2, 16, 16] := by
   unfold v_679_0
   change listSwapAt _ _ _ = _
   rw [h_678_0 z z_]
   rfl
 #a h_679_0
 attribute [local irreducible] v_679_0
 attribute [local irreducible] s_680
 record_prefix_opacity v_672_0 v_672_1 s_673 v_673_0 s_674 v_674_0 s_675 v_675_0 s_676 v_676_0 s_677 v_677_0 s_678 v_678_0 s_679 v_679_0 s_680

 end
 end TrainVerify.Denote.RuntimeWorld
