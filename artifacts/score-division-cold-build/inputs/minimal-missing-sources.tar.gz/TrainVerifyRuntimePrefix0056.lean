import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0055
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_432_0 (z : Store) : (s_432 z) 701 = (v_431_0 z) := w_431_0 z
 #a r_432_0
 def v_432_0 (z : Store) : Tensor := (v_431_0 z)
 def v_432_1 (z : Store) : Tensor := (v_431_0 z)
 def s_433 (z : Store) : Store := storeSet (s_432 z) [(889, ((s_432 z) 701)), (769, ((s_432 z) 701))]
 theorem t_432 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_478) (pmPeers pmNode_478) (s_432 z) pmNode_478 none = some (s_433 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_432
 theorem k_432 (z : Store) (tid : Tid) (h : tid ∉ [889, 769]) : (s_433 z) tid = (s_432 z) tid := by
   unfold s_433
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_432
 theorem w_432_0 (z : Store) : (s_433 z) 889 = v_432_0 z := by
   unfold s_433
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_432_0, r_432_0 z] <;> rfl
 #a w_432_0
 theorem h_432_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_432_0 z).shape = [1, 16, 32] := by
   unfold v_432_0
   exact h_431_0 z z_
 #a h_432_0
 attribute [local irreducible] v_432_0
 theorem w_432_1 (z : Store) : (s_433 z) 769 = v_432_1 z := by
   unfold s_433
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_432_1, r_432_0 z] <;> rfl
 #a w_432_1
 theorem h_432_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_432_1 z).shape = [1, 16, 32] := by
   unfold v_432_1
   exact h_431_0 z z_
 #a h_432_1
 attribute [local irreducible] v_432_1
 attribute [local irreducible] s_433
 theorem r_433_0 (z : Store) : (s_433 z) 698 = (v_425_0 z) := pR (k_432 z) (pR (k_431 z) (pR (k_430 z) (r_430_0 z)))
 #a r_433_0
 theorem r_433_1 (z : Store) : (s_433 z) 1001 = (v_429_0 z) := pR (k_432 z) (pR (k_431 z) (pR (k_430 z) (r_430_1 z)))
 #a r_433_1
 def v_433_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_425_0 z), (v_429_0 z)]
 theorem g_433 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_712) (s_433 z) pmNode_712 1 2 1003 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_712, r_433_0 z, r_433_1 z, h_425_0 z z_, h_429_0 z z_]
 #a g_433
 def s_434 (z : Store) : Store := pL [2, 3] (s_433 z) pmNode_712 1 2
 theorem t_433 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_712) (pmPeers pmNode_712) (s_433 z) pmNode_712 none = some (s_434 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_712) (s_433 z) pmNode_712).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1003 (by decide) (g_433 z z_)]
   rfl
 #a t_433
 theorem k_433 (z : Store) (tid : Tid) (h : tid ∉ [1003]) : (s_434 z) tid = (s_433 z) tid := by
   unfold s_434
   dsimp only [pL, pmNode_712, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_433
 theorem w_433_0 (z : Store) : (s_434 z) 1003 = v_433_0 z := by
   unfold s_434
   dsimp only [pL, pmNode_712, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_433_0, r_433_0 z, r_433_1 z] <;> rfl
 #a w_433_0
 theorem h_433_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_433_0 z).shape = [1, 16, 32] := by
   unfold v_433_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_425_0 z z_]
 #a h_433_0
 attribute [local irreducible] v_433_0
 attribute [local irreducible] s_434
 theorem n_428_432 (z : Store) (tid : Tid) (h : tid ∉ ([1000, 1001, 700, 701] : List Tid)) : (s_432 z) tid = (s_428 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_428 z) (k_429 z)) (pF _ _ _ _ _ (k_430 z) (k_431 z)) tid h
 #a n_428_432
 theorem r_434_0 (z : Store) : (s_434 z) 998 = (v_427_0 z) := pR (k_433 z) (pR (k_432 z) (pR (n_428_432 z) (w_427_0 z)))
 #a r_434_0
 theorem r_434_1 (z : Store) : (s_434 z) 1003 = (v_433_0 z) := w_433_0 z
 #a r_434_1
 def v_434_0 (z : Store) : Tensor := elemwiseAdd (v_427_0 z) (v_433_0 z)
 def s_435 (z : Store) : Store := storeSet (s_434 z) [(1004, elemwiseAdd ((s_434 z) 998) ((s_434 z) 1003))]
 theorem t_434 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_713) (pmPeers pmNode_713) (s_434 z) pmNode_713 none = some (s_435 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_434
 theorem k_434 (z : Store) (tid : Tid) (h : tid ∉ [1004]) : (s_435 z) tid = (s_434 z) tid := by
   unfold s_435
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_434
 theorem w_434_0 (z : Store) : (s_435 z) 1004 = v_434_0 z := by
   unfold s_435
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_434_0, r_434_0 z, r_434_1 z] <;> rfl
 #a w_434_0
 theorem h_434_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_434_0 z).shape = [1, 16, 32] := by
   unfold v_434_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_427_0 z z_, h_433_0 z z_]
 #a h_434_0
 attribute [local irreducible] v_434_0
 attribute [local irreducible] s_435
 theorem r_435_0 (z : Store) : (s_435 z) 1004 = (v_434_0 z) := w_434_0 z
 #a r_435_0
 def v_435_0 (z : Store) : Tensor := (v_434_0 z)
 def v_435_1 (z : Store) : Tensor := (v_434_0 z)
 def s_436 (z : Store) : Store := storeSet (s_435 z) [(1192, ((s_435 z) 1004)), (1072, ((s_435 z) 1004))]
 theorem t_435 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_714) (pmPeers pmNode_714) (s_435 z) pmNode_714 none = some (s_436 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_435
 theorem k_435 (z : Store) (tid : Tid) (h : tid ∉ [1192, 1072]) : (s_436 z) tid = (s_435 z) tid := by
   unfold s_436
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_435
 theorem w_435_0 (z : Store) : (s_436 z) 1192 = v_435_0 z := by
   unfold s_436
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_435_0, r_435_0 z] <;> rfl
 #a w_435_0
 theorem h_435_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_435_0 z).shape = [1, 16, 32] := by
   unfold v_435_0
   exact h_434_0 z z_
 #a h_435_0
 attribute [local irreducible] v_435_0
 theorem w_435_1 (z : Store) : (s_436 z) 1072 = v_435_1 z := by
   unfold s_436
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_435_1, r_435_0 z] <;> rfl
 #a w_435_1
 theorem h_435_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_435_1 z).shape = [1, 16, 32] := by
   unfold v_435_1
   exact h_434_0 z z_
 #a h_435_1
 attribute [local irreducible] v_435_1
 attribute [local irreducible] s_436
 theorem r_436_0 (z : Store) : (s_436 z) 889 = (v_432_0 z) := pR (k_435 z) (pR (k_434 z) (pR (k_433 z) (w_432_0 z)))
 #a r_436_0
 theorem r_436_1 (z : Store) : (s_436 z) 1192 = (v_435_0 z) := w_435_0 z
 #a r_436_1
 def v_436_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_432_0 z), (v_435_0 z)]
 theorem g_436 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_479) (s_436 z) pmNode_479 2 1 704 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_479, r_436_0 z, r_436_1 z, h_432_0 z z_, h_435_0 z z_]
 #a g_436
 def s_437 (z : Store) : Store := pL [2, 3] (s_436 z) pmNode_479 2 1
 theorem t_436 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_479) (pmPeers pmNode_479) (s_436 z) pmNode_479 none = some (s_437 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_479) (s_436 z) pmNode_479).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 704 (by decide) (g_436 z z_)]
   rfl
 #a t_436
 theorem k_436 (z : Store) (tid : Tid) (h : tid ∉ [704]) : (s_437 z) tid = (s_436 z) tid := by
   unfold s_437
   dsimp only [pL, pmNode_479, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_436
 theorem w_436_0 (z : Store) : (s_437 z) 704 = v_436_0 z := by
   unfold s_437
   dsimp only [pL, pmNode_479, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_436_0, r_436_0 z, r_436_1 z] <;> rfl
 #a w_436_0
 theorem h_436_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_436_0 z).shape = [1, 8, 64] := by
   unfold v_436_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_432_0 z z_]
 #a h_436_0
 attribute [local irreducible] v_436_0
 attribute [local irreducible] s_437
 theorem n_432_436 (z : Store) (tid : Tid) (h : tid ∉ ([889, 769, 1003, 1004, 1192, 1072] : List Tid)) : (s_436 z) tid = (s_432 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_432 z) (k_433 z)) (pF _ _ _ _ _ (k_434 z) (k_435 z)) tid h
 #a n_432_436
 theorem n_424_432 (z : Store) (tid : Tid) (h : tid ∉ ([697, 698, 984, 985, 998, 1000, 1001, 700, 701] : List Tid)) : (s_432 z) tid = (s_424 z) tid := by
   exact pF _ _ _ _ _ (n_424_428 z) (n_428_432 z) tid h
 #a n_424_432
 theorem n_416_432 (z : Store) (tid : Tid) (h : tid ∉ ([93, 19, 17, 396, 322, 320, 681, 682, 695, 697, 698, 984, 985, 998, 1000, 1001, 700, 701] : List Tid)) : (s_432 z) tid = (s_416 z) tid := by
   exact pF _ _ _ _ _ (n_416_424 z) (n_424_432 z) tid h
 #a n_416_432
 theorem r_437_0 (z : Store) : (s_437 z) 704 = (v_436_0 z) := w_436_0 z
 #a r_437_0
 theorem r_437_1 (z : Store) : (s_437 z) 607 = (z 607) := pR (k_436 z) (pR (n_432_436 z) (pR (n_416_432 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_54 z))))))
 #a r_437_1
 theorem r_437_2 (z : Store) : (s_437 z) 608 = (z 608) := pR (k_436 z) (pR (n_432_436 z) (pR (n_416_432 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_55 z))))))
 #a r_437_2
 def v_437_0 (z : Store) : Tensor := fw_layernorm (v_436_0 z) (z 607) (z 608)
 def s_438 (z : Store) : Store := storeSet (s_437 z) [(705, fw_layernorm ((s_437 z) 704) ((s_437 z) 607) ((s_437 z) 608))]
 theorem t_437 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_480) (pmPeers pmNode_480) (s_437 z) pmNode_480 none = some (s_438 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_437
 theorem k_437 (z : Store) (tid : Tid) (h : tid ∉ [705]) : (s_438 z) tid = (s_437 z) tid := by
   unfold s_438
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_437
 theorem w_437_0 (z : Store) : (s_438 z) 705 = v_437_0 z := by
   unfold s_438
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_437_0, r_437_0 z, r_437_1 z, r_437_2 z] <;> rfl
 #a w_437_0
 theorem h_437_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_437_0 z).shape = [1, 8, 64] := by
   unfold v_437_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_436_0 z z_
 #a h_437_0
 attribute [local irreducible] v_437_0
 attribute [local irreducible] s_438
 theorem r_438_0 (z : Store) : (s_438 z) 705 = (v_437_0 z) := w_437_0 z
 #a r_438_0
 def v_438_0 (z : Store) : Tensor := (v_437_0 z)
 def v_438_1 (z : Store) : Tensor := (v_437_0 z)
 def v_438_2 (z : Store) : Tensor := (v_437_0 z)
 def s_439 (z : Store) : Store := storeSet (s_438 z) [(708, ((s_438 z) 705)), (891, ((s_438 z) 705)), (893, ((s_438 z) 705))]
 theorem t_438 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_481) (pmPeers pmNode_481) (s_438 z) pmNode_481 none = some (s_439 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_438
 theorem k_438 (z : Store) (tid : Tid) (h : tid ∉ [708, 891, 893]) : (s_439 z) tid = (s_438 z) tid := by
   unfold s_439
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_438
 theorem w_438_0 (z : Store) : (s_439 z) 708 = v_438_0 z := by
   unfold s_439
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_438_0, r_438_0 z] <;> rfl
 #a w_438_0
 theorem h_438_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_438_0 z).shape = [1, 8, 64] := by
   unfold v_438_0
   exact h_437_0 z z_
 #a h_438_0
 attribute [local irreducible] v_438_0
 theorem w_438_1 (z : Store) : (s_439 z) 891 = v_438_1 z := by
   unfold s_439
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_438_1, r_438_0 z] <;> rfl
 #a w_438_1
 theorem h_438_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_438_1 z).shape = [1, 8, 64] := by
   unfold v_438_1
   exact h_437_0 z z_
 #a h_438_1
 attribute [local irreducible] v_438_1
 theorem w_438_2 (z : Store) : (s_439 z) 893 = v_438_2 z := by
   unfold s_439
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_438_2, r_438_0 z] <;> rfl
 #a w_438_2
 theorem h_438_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_438_2 z).shape = [1, 8, 64] := by
   unfold v_438_2
   exact h_437_0 z z_
 #a h_438_2
 attribute [local irreducible] v_438_2
 attribute [local irreducible] s_439
 theorem r_439_0 (z : Store) : (s_439 z) 708 = (v_438_0 z) := w_438_0 z
 #a r_439_0
 theorem r_439_1 (z : Store) : (s_439 z) 609 = (z 609) := pR (k_438 z) (pR (k_437 z) (pR (k_436 z) (pR (n_432_436 z) (pR (n_416_432 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_56 z))))))))
 #a r_439_1
 def v_439_0 (z : Store) : Tensor := fw_linear (v_438_0 z) (z 609)
 def s_440 (z : Store) : Store := storeSet (s_439 z) [(709, fw_linear ((s_439 z) 708) ((s_439 z) 609))]
 theorem t_439 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_482) (pmPeers pmNode_482) (s_439 z) pmNode_482 none = some (s_440 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_439
 theorem k_439 (z : Store) (tid : Tid) (h : tid ∉ [709]) : (s_440 z) tid = (s_439 z) tid := by
   unfold s_440
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_439
 theorem w_439_0 (z : Store) : (s_440 z) 709 = v_439_0 z := by
   unfold s_440
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_439_0, r_439_0 z, r_439_1 z] <;> rfl
 #a w_439_0
 theorem h_439_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_439_0 z).shape = [1, 8, 64] := by
   unfold v_439_0
   exact fw_linear_3d_shape 1 8 64 64 (v_438_0 z) (z 609) (h_438_0 z z_) (i_56 z z_)
 #a h_439_0
 attribute [local irreducible] v_439_0
 attribute [local irreducible] s_440
 record_prefix_opacity v_432_0 v_432_1 s_433 v_433_0 s_434 v_434_0 s_435 v_435_0 v_435_1 s_436 v_436_0 s_437 v_437_0 s_438 v_438_0 v_438_1 v_438_2 s_439 v_439_0 s_440

 end
 end TrainVerify.Denote.RuntimeWorld
