import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0029
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_231_0 (z : Store) : (s_231 z) 571 = (v_230_0 z) := w_230_0 z
 #a r_231_0
 theorem r_231_1 (z : Store) : (s_231 z) 568 = (v_198_0 z) := pR (k_230 z) (pR (k_229 z) (pR (k_228 z) (pR (n_224_228 z) (pR (n_208_224 z) (pR (n_200_208 z) (pR (k_199 z) (r_199_0 z)))))))
 #a r_231_1
 def v_231_0 (z : Store) : Tensor := bw_gelu (v_230_0 z) (v_198_0 z)
 def s_232 (z : Store) : Store := storeSet (s_231 z) [(570, bw_gelu ((s_231 z) 571) ((s_231 z) 568))]
 theorem t_231 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_351) (pmPeers pmNode_351) (s_231 z) pmNode_351 none = some (s_232 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_231
 theorem k_231 (z : Store) (tid : Tid) (h : tid ∉ [570]) : (s_232 z) tid = (s_231 z) tid := by
   unfold s_232
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_231
 theorem w_231_0 (z : Store) : (s_232 z) 570 = v_231_0 z := by
   unfold s_232
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_231_0, r_231_0 z, r_231_1 z] <;> rfl
 #a w_231_0
 theorem h_231_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_231_0 z).shape = [1, 8, 256] := by
   unfold v_231_0
   exact h_198_0 z z_
 #a h_231_0
 attribute [local irreducible] v_231_0
 attribute [local irreducible] s_232
 theorem r_232_0 (z : Store) : (s_232 z) 267 = (v_228_0 z) := pR (k_231 z) (pR (k_230 z) (pR (k_229 z) (w_228_0 z)))
 #a r_232_0
 theorem r_232_1 (z : Store) : (s_232 z) 570 = (v_231_0 z) := w_231_0 z
 #a r_232_1
 def v_232_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_228_0 z), (v_231_0 z)]
 def s_233 (z : Store) : Store := storeSet (s_232 z) [(85, allGatherPrimDimN 1 2 0 [((s_232 z) 267), ((s_232 z) 570)])]
 theorem t_232 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_116) (pmPeers pmNode_116) (s_232 z) pmNode_116 none = some (s_233 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_232 z) pmNode_116 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_232
 theorem k_232 (z : Store) (tid : Tid) (h : tid ∉ [85]) : (s_233 z) tid = (s_232 z) tid := by
   unfold s_233
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_232
 theorem w_232_0 (z : Store) : (s_233 z) 85 = v_232_0 z := by
   unfold s_233
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_232_0, r_232_0 z, r_232_1 z] <;> rfl
 #a w_232_0
 theorem h_232_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_232_0 z).shape = [1, 16, 256] := by
   unfold v_232_0
   exact allGatherPrimDimN_shape 1 2 [(v_228_0 z), (v_231_0 z)] [1, 8, 256] (h_228_0 z z_)
 #a h_232_0
 attribute [local irreducible] v_232_0
 attribute [local irreducible] s_233
 theorem n_228_232 (z : Store) (tid : Tid) (h : tid ∉ ([267, 605, 571, 369, 570] : List Tid)) : (s_232 z) tid = (s_228 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_228 z) (k_229 z)) (pF _ _ _ _ _ (k_230 z) (k_231 z)) tid h
 #a n_228_232
 theorem n_224_232 (z : Store) (tid : Tid) (h : tid ∉ ([577, 371, 373, 576, 573, 302, 268, 66, 267, 605, 571, 369, 570] : List Tid)) : (s_232 z) tid = (s_224 z) tid := by
   exact pF _ _ _ _ _ (n_224_228 z) (n_228_232 z) tid h
 #a n_224_232
 theorem n_192_224 (z : Store) (tid : Tid) (h : tid ∉ ([265, 266, 269, 271, 272, 275, 568, 569, 572, 574, 575, 578, 80, 277, 383, 580, 280, 281, 583, 584, 77, 282, 380, 585, 278, 279, 73, 582, 581, 376, 276, 274, 68, 70, 273, 270, 579] : List Tid)) : (s_224 z) tid = (s_192 z) tid := by
   exact pF _ _ _ _ _ (n_192_208 z) (n_208_224 z) tid h
 #a n_192_224
 theorem r_233_0 (z : Store) : (s_233 z) 85 = (v_232_0 z) := w_232_0 z
 #a r_233_0
 theorem r_233_1 (z : Store) : (s_233 z) 262 = (v_188_0 z) := pR (k_232 z) (pR (n_224_232 z) (pR (n_192_224 z) (pR (k_191 z) (pR (k_190 z) (pR (k_189 z) (r_189_0 z))))))
 #a r_233_1
 theorem r_233_2 (z : Store) : (s_233 z) 63 = (z 63) := pR (k_232 z) (pR (n_224_232 z) (pR (n_192_224 z) (pR (k_191 z) (pR (k_190 z) (pR (k_189 z) (r_189_1 z))))))
 #a r_233_2
 def v_233_0 (z : Store) : Tensor := (bw_linear (v_232_0 z) (v_188_0 z) (z 63)).1
 def v_233_1 (z : Store) : Tensor := (bw_linear (v_232_0 z) (v_188_0 z) (z 63)).2
 def s_234 (z : Store) : Store := storeSet (s_233 z) [(264, (bw_linear ((s_233 z) 85) ((s_233 z) 262) ((s_233 z) 63)).1), (64, (bw_linear ((s_233 z) 85) ((s_233 z) 262) ((s_233 z) 63)).2)]
 theorem t_233 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_117) (pmPeers pmNode_117) (s_233 z) pmNode_117 none = some (s_234 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_233
 theorem k_233 (z : Store) (tid : Tid) (h : tid ∉ [264, 64]) : (s_234 z) tid = (s_233 z) tid := by
   unfold s_234
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_233
 theorem w_233_0 (z : Store) : (s_234 z) 264 = v_233_0 z := by
   unfold s_234
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_233_0, r_233_0 z, r_233_1 z, r_233_2 z] <;> rfl
 #a w_233_0
 theorem h_233_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_233_0 z).shape = [1, 16, 32] := by
   unfold v_233_0
   exact bw_linear_3d_fst_shape 1 16 256 32 (v_232_0 z) (v_188_0 z) (z 63) (h_232_0 z z_) (h_188_0 z z_) (i_40 z z_)
 #a h_233_0
 attribute [local irreducible] v_233_0
 theorem w_233_1 (z : Store) : (s_234 z) 64 = v_233_1 z := by
   unfold s_234
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_233_1, r_233_0 z, r_233_1 z, r_233_2 z] <;> rfl
 #a w_233_1
 theorem h_233_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_233_1 z).shape = [256, 32] := by
   unfold v_233_1
   exact bw_linear_3d_snd_shape 1 16 256 32 (v_232_0 z) (v_188_0 z) (z 63) (h_232_0 z z_) (h_188_0 z z_) (i_40 z z_)
 #a h_233_1
 attribute [local irreducible] v_233_1
 attribute [local irreducible] s_234
 theorem r_234_0 (z : Store) : (s_234 z) 267 = (v_228_0 z) := pR (k_233 z) (pR (k_232 z) (r_232_0 z))
 #a r_234_0
 theorem r_234_1 (z : Store) : (s_234 z) 570 = (v_231_0 z) := pR (k_233 z) (pR (k_232 z) (r_232_1 z))
 #a r_234_1
 def v_234_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_228_0 z), (v_231_0 z)]
 def s_235 (z : Store) : Store := storeSet (s_234 z) [(388, allGatherPrimDimN 1 2 1 [((s_234 z) 267), ((s_234 z) 570)])]
 theorem t_234 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_352) (pmPeers pmNode_352) (s_234 z) pmNode_352 none = some (s_235 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_234 z) pmNode_352 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_234
 theorem k_234 (z : Store) (tid : Tid) (h : tid ∉ [388]) : (s_235 z) tid = (s_234 z) tid := by
   unfold s_235
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_234
 theorem w_234_0 (z : Store) : (s_235 z) 388 = v_234_0 z := by
   unfold s_235
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_234_0, r_234_0 z, r_234_1 z] <;> rfl
 #a w_234_0
 theorem h_234_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_234_0 z).shape = [1, 16, 256] := by
   unfold v_234_0
   exact allGatherPrimDimN_shape 1 2 [(v_228_0 z), (v_231_0 z)] [1, 8, 256] (h_228_0 z z_)
 #a h_234_0
 attribute [local irreducible] v_234_0
 attribute [local irreducible] s_235
 theorem r_235_0 (z : Store) : (s_235 z) 388 = (v_234_0 z) := w_234_0 z
 #a r_235_0
 theorem r_235_1 (z : Store) : (s_235 z) 565 = (v_190_0 z) := pR (k_234 z) (pR (k_233 z) (pR (k_232 z) (pR (n_224_232 z) (pR (n_192_224 z) (pR (k_191 z) (r_191_0 z))))))
 #a r_235_1
 theorem r_235_2 (z : Store) : (s_235 z) 366 = (z 366) := pR (k_234 z) (pR (k_233 z) (pR (k_232 z) (pR (n_224_232 z) (pR (n_192_224 z) (pR (k_191 z) (r_191_1 z))))))
 #a r_235_2
 def v_235_0 (z : Store) : Tensor := (bw_linear (v_234_0 z) (v_190_0 z) (z 366)).1
 def v_235_1 (z : Store) : Tensor := (bw_linear (v_234_0 z) (v_190_0 z) (z 366)).2
 def s_236 (z : Store) : Store := storeSet (s_235 z) [(567, (bw_linear ((s_235 z) 388) ((s_235 z) 565) ((s_235 z) 366)).1), (367, (bw_linear ((s_235 z) 388) ((s_235 z) 565) ((s_235 z) 366)).2)]
 theorem t_235 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_353) (pmPeers pmNode_353) (s_235 z) pmNode_353 none = some (s_236 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_235
 theorem k_235 (z : Store) (tid : Tid) (h : tid ∉ [567, 367]) : (s_236 z) tid = (s_235 z) tid := by
   unfold s_236
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_235
 theorem w_235_0 (z : Store) : (s_236 z) 567 = v_235_0 z := by
   unfold s_236
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_235_0, r_235_0 z, r_235_1 z, r_235_2 z] <;> rfl
 #a w_235_0
 theorem h_235_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_235_0 z).shape = [1, 16, 32] := by
   unfold v_235_0
   exact bw_linear_3d_fst_shape 1 16 256 32 (v_234_0 z) (v_190_0 z) (z 366) (h_234_0 z z_) (h_190_0 z z_) (i_41 z z_)
 #a h_235_0
 attribute [local irreducible] v_235_0
 theorem w_235_1 (z : Store) : (s_236 z) 367 = v_235_1 z := by
   unfold s_236
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_235_1, r_235_0 z, r_235_1 z, r_235_2 z] <;> rfl
 #a w_235_1
 theorem h_235_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_235_1 z).shape = [256, 32] := by
   unfold v_235_1
   exact bw_linear_3d_snd_shape 1 16 256 32 (v_234_0 z) (v_190_0 z) (z 366) (h_234_0 z z_) (h_190_0 z z_) (i_41 z z_)
 #a h_235_1
 attribute [local irreducible] v_235_1
 attribute [local irreducible] s_236
 theorem r_236_0 (z : Store) : (s_236 z) 264 = (v_233_0 z) := pR (k_235 z) (pR (k_234 z) (w_233_0 z))
 #a r_236_0
 theorem r_236_1 (z : Store) : (s_236 z) 567 = (v_235_0 z) := w_235_0 z
 #a r_236_1
 def v_236_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_233_0 z), (v_235_0 z)]
 theorem g_236 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_118) (s_236 z) pmNode_118 2 1 261 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_118, r_236_0 z, r_236_1 z, h_233_0 z z_, h_235_0 z z_]
 #a g_236
 def s_237 (z : Store) : Store := pL [0, 1] (s_236 z) pmNode_118 2 1
 theorem t_236 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_118) (pmPeers pmNode_118) (s_236 z) pmNode_118 none = some (s_237 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_118) (s_236 z) pmNode_118).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 261 (by decide) (g_236 z z_)]
   rfl
 #a t_236
 theorem k_236 (z : Store) (tid : Tid) (h : tid ∉ [261]) : (s_237 z) tid = (s_236 z) tid := by
   unfold s_237
   dsimp only [pL, pmNode_118, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_236
 theorem w_236_0 (z : Store) : (s_237 z) 261 = v_236_0 z := by
   unfold s_237
   dsimp only [pL, pmNode_118, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_236_0, r_236_0 z, r_236_1 z] <;> rfl
 #a w_236_0
 theorem h_236_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_236_0 z).shape = [1, 8, 64] := by
   unfold v_236_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_233_0 z z_]
 #a h_236_0
 attribute [local irreducible] v_236_0
 attribute [local irreducible] s_237
 theorem n_232_236 (z : Store) (tid : Tid) (h : tid ∉ ([85, 264, 64, 388, 567, 367] : List Tid)) : (s_236 z) tid = (s_232 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_232 z) (k_233 z)) (pF _ _ _ _ _ (k_234 z) (k_235 z)) tid h
 #a n_232_236
 theorem r_237_0 (z : Store) : (s_237 z) 261 = (v_236_0 z) := w_236_0 z
 #a r_237_0
 theorem r_237_1 (z : Store) : (s_237 z) 258 = (v_184_0 z) := pR (k_236 z) (pR (n_232_236 z) (pR (n_224_232 z) (pR (n_192_224 z) (pR (n_188_192 z) (pR (k_187 z) (pR (k_186 z) (pR (k_185 z) (r_185_0 z))))))))
 #a r_237_1
 theorem r_237_2 (z : Store) : (s_237 z) 11 = (z 11) := pR (k_236 z) (pR (n_232_236 z) (pR (n_224_232 z) (pR (n_192_224 z) (pR (n_188_192 z) (pR (k_187 z) (pR (k_186 z) (pR (k_185 z) (r_185_1 z))))))))
 #a r_237_2
 theorem r_237_3 (z : Store) : (s_237 z) 12 = (z 12) := pR (k_236 z) (pR (n_232_236 z) (pR (n_224_232 z) (pR (n_192_224 z) (pR (n_188_192 z) (pR (k_187 z) (pR (k_186 z) (pR (k_185 z) (r_185_2 z))))))))
 #a r_237_3
 def v_237_0 (z : Store) : Tensor := (bw_layernorm (v_236_0 z) (v_184_0 z) (z 11) (z 12)).1
 def v_237_1 (z : Store) : Tensor := (bw_layernorm (v_236_0 z) (v_184_0 z) (z 11) (z 12)).2.1
 def v_237_2 (z : Store) : Tensor := (bw_layernorm (v_236_0 z) (v_184_0 z) (z 11) (z 12)).2.2
 def s_238 (z : Store) : Store := storeSet (s_237 z) [(260, (bw_layernorm ((s_237 z) 261) ((s_237 z) 258) ((s_237 z) 11) ((s_237 z) 12)).1), (59, (bw_layernorm ((s_237 z) 261) ((s_237 z) 258) ((s_237 z) 11) ((s_237 z) 12)).2.1), (61, (bw_layernorm ((s_237 z) 261) ((s_237 z) 258) ((s_237 z) 11) ((s_237 z) 12)).2.2)]
 theorem t_237 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_119) (pmPeers pmNode_119) (s_237 z) pmNode_119 none = some (s_238 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_237
 theorem k_237 (z : Store) (tid : Tid) (h : tid ∉ [260, 59, 61]) : (s_238 z) tid = (s_237 z) tid := by
   unfold s_238
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_237
 theorem w_237_0 (z : Store) : (s_238 z) 260 = v_237_0 z := by
   unfold s_238
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_237_0, r_237_0 z, r_237_1 z, r_237_2 z, r_237_3 z] <;> rfl
 #a w_237_0
 theorem h_237_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_237_0 z).shape = [1, 8, 64] := by
   unfold v_237_0
   rw [bw_layernorm_dx_shape (v_236_0 z) (v_184_0 z) (z 11) (z 12) 64 [8, 1] (by rw [h_184_0 z z_]; rfl)]
   exact h_184_0 z z_
 #a h_237_0
 attribute [local irreducible] v_237_0
 theorem w_237_1 (z : Store) : (s_238 z) 59 = v_237_1 z := by
   unfold s_238
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_237_1, r_237_0 z, r_237_1 z, r_237_2 z, r_237_3 z] <;> rfl
 #a w_237_1
 theorem h_237_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_237_1 z).shape = [64] := by
   unfold v_237_1
   rw [bw_layernorm_dw_shape (v_236_0 z) (v_184_0 z) (z 11) (z 12) 64 [8, 1] (by rw [h_184_0 z z_]; rfl)]
   exact i_36 z z_
 #a h_237_1
 attribute [local irreducible] v_237_1
 theorem w_237_2 (z : Store) : (s_238 z) 61 = v_237_2 z := by
   unfold s_238
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_237_2, r_237_0 z, r_237_1 z, r_237_2 z, r_237_3 z] <;> rfl
 #a w_237_2
 theorem h_237_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_237_2 z).shape = [64] := by
   unfold v_237_2
   rw [bw_layernorm_db_shape (v_236_0 z) (v_184_0 z) (z 11) (z 12) 64 [8, 1] (by rw [h_184_0 z z_]; rfl)]
   exact i_37 z z_
 #a h_237_2
 attribute [local irreducible] v_237_2
 attribute [local irreducible] s_238
 record_prefix_opacity v_231_0 s_232 v_232_0 s_233 v_233_0 v_233_1 s_234 v_234_0 s_235 v_235_0 v_235_1 s_236 v_236_0 s_237 v_237_0 v_237_1 v_237_2 s_238

 end
 end TrainVerify.Denote.RuntimeWorld
