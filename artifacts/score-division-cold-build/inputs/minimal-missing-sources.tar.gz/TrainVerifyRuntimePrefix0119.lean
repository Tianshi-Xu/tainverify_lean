import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0118
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_924_0 (z : Store) : (s_924 z) 61 = (v_237_2 z) := pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (pR (k_890 z) (pR (k_889 z) (r_889_0 z)))))))
 #a r_924_0
 theorem r_924_1 (z : Store) : (s_924 z) 364 = (v_239_2 z) := pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (pR (k_890 z) (pR (k_889 z) (r_889_1 z)))))))
 #a r_924_1
 theorem r_924_2 (z : Store) : (s_924 z) 667 = (v_659_2 z) := pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (pR (k_890 z) (pR (k_889 z) (r_889_2 z)))))))
 #a r_924_2
 theorem r_924_3 (z : Store) : (s_924 z) 970 = (v_661_2 z) := pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (pR (k_890 z) (pR (k_889 z) (r_889_3 z)))))))
 #a r_924_3
 def v_924_0 (z : Store) : Tensor := cross_dp_wred [(v_237_2 z), (v_239_2 z), (v_659_2 z), (v_661_2 z)]
 theorem g_924 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_924) (s_924 z) pmNode_924 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_924, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_924_1 z, r_924_0 z]
     exact (h_239_2 z z_).trans (h_237_2 z z_).symm
   · rw [r_924_2 z, r_924_0 z]
     exact (h_659_2 z z_).trans (h_237_2 z z_).symm
   · rw [r_924_3 z, r_924_0 z]
     exact (h_661_2 z z_).trans (h_237_2 z z_).symm
 #a g_924
 def s_925 (z : Store) : Store := storeSet (s_924 z) [(971, cross_dp_wred [((s_924 z) 61), ((s_924 z) 364), ((s_924 z) 667), ((s_924 z) 970)])]
 theorem t_924 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_924) (pmPeers pmNode_924) (s_924 z) pmNode_924 none = some (s_925 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_924) (s_924 z) pmNode_924 = _
   rw [wredStep, if_pos ⟨by decide, g_924 z z_⟩]
   rfl
 #a t_924
 theorem k_924 (z : Store) (tid : Tid) (h : tid ∉ [971]) : (s_925 z) tid = (s_924 z) tid := by
   unfold s_925
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_924
 theorem w_924_0 (z : Store) : (s_925 z) 971 = v_924_0 z := by
   unfold s_925
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_924_0, r_924_0 z, r_924_1 z, r_924_2 z, r_924_3 z] <;> rfl
 #a w_924_0
 theorem h_924_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_924_0 z).shape = [64] := by
   unfold v_924_0
   rw [tensorSum_shape]
   exact h_237_2 z z_
 #a h_924_0
 attribute [local irreducible] v_924_0
 attribute [local irreducible] s_925
 theorem r_925_0 (z : Store) : (s_925 z) 66 = (v_227_1 z) := pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (pR (k_890 z) (r_890_0 z)))))))
 #a r_925_0
 theorem r_925_1 (z : Store) : (s_925 z) 369 = (v_230_1 z) := pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (pR (k_890 z) (r_890_1 z)))))))
 #a r_925_1
 theorem r_925_2 (z : Store) : (s_925 z) 672 = (v_649_1 z) := pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (pR (k_890 z) (r_890_2 z)))))))
 #a r_925_2
 theorem r_925_3 (z : Store) : (s_925 z) 975 = (v_652_1 z) := pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (pR (k_890 z) (r_890_3 z)))))))
 #a r_925_3
 def v_925_0 (z : Store) : Tensor := cross_dp_wred [(v_227_1 z), (v_230_1 z), (v_649_1 z), (v_652_1 z)]
 theorem g_925 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_925) (s_925 z) pmNode_925 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_925, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_925_1 z, r_925_0 z]
     exact (h_230_1 z z_).trans (h_227_1 z z_).symm
   · rw [r_925_2 z, r_925_0 z]
     exact (h_649_1 z z_).trans (h_227_1 z z_).symm
   · rw [r_925_3 z, r_925_0 z]
     exact (h_652_1 z z_).trans (h_227_1 z z_).symm
 #a g_925
 def s_926 (z : Store) : Store := storeSet (s_925 z) [(976, cross_dp_wred [((s_925 z) 66), ((s_925 z) 369), ((s_925 z) 672), ((s_925 z) 975)])]
 theorem t_925 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_925) (pmPeers pmNode_925) (s_925 z) pmNode_925 none = some (s_926 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_925) (s_925 z) pmNode_925 = _
   rw [wredStep, if_pos ⟨by decide, g_925 z z_⟩]
   rfl
 #a t_925
 theorem k_925 (z : Store) (tid : Tid) (h : tid ∉ [976]) : (s_926 z) tid = (s_925 z) tid := by
   unfold s_926
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_925
 theorem w_925_0 (z : Store) : (s_926 z) 976 = v_925_0 z := by
   unfold s_926
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_925_0, r_925_0 z, r_925_1 z, r_925_2 z, r_925_3 z] <;> rfl
 #a w_925_0
 theorem h_925_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_925_0 z).shape = [64, 256] := by
   unfold v_925_0
   rw [tensorSum_shape]
   exact h_227_1 z z_
 #a h_925_0
 attribute [local irreducible] v_925_0
 attribute [local irreducible] s_926
 theorem r_926_0 (z : Store) : (s_926 z) 68 = (v_221_1 z) := pR (k_925 z) (pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (r_891_0 z)))))))
 #a r_926_0
 theorem r_926_1 (z : Store) : (s_926 z) 371 = (v_224_1 z) := pR (k_925 z) (pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (r_891_1 z)))))))
 #a r_926_1
 theorem r_926_2 (z : Store) : (s_926 z) 674 = (v_643_1 z) := pR (k_925 z) (pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (r_891_2 z)))))))
 #a r_926_2
 theorem r_926_3 (z : Store) : (s_926 z) 977 = (v_646_1 z) := pR (k_925 z) (pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (pR (k_891 z) (r_891_3 z)))))))
 #a r_926_3
 def v_926_0 (z : Store) : Tensor := cross_dp_wred [(v_221_1 z), (v_224_1 z), (v_643_1 z), (v_646_1 z)]
 theorem g_926 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_926) (s_926 z) pmNode_926 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_926, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_926_1 z, r_926_0 z]
     exact (h_224_1 z z_).trans (h_221_1 z z_).symm
   · rw [r_926_2 z, r_926_0 z]
     exact (h_643_1 z z_).trans (h_221_1 z z_).symm
   · rw [r_926_3 z, r_926_0 z]
     exact (h_646_1 z z_).trans (h_221_1 z z_).symm
 #a g_926
 def s_927 (z : Store) : Store := storeSet (s_926 z) [(978, cross_dp_wred [((s_926 z) 68), ((s_926 z) 371), ((s_926 z) 674), ((s_926 z) 977)])]
 theorem t_926 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_926) (pmPeers pmNode_926) (s_926 z) pmNode_926 none = some (s_927 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_926) (s_926 z) pmNode_926 = _
   rw [wredStep, if_pos ⟨by decide, g_926 z z_⟩]
   rfl
 #a t_926
 theorem k_926 (z : Store) (tid : Tid) (h : tid ∉ [978]) : (s_927 z) tid = (s_926 z) tid := by
   unfold s_927
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_926
 theorem w_926_0 (z : Store) : (s_927 z) 978 = v_926_0 z := by
   unfold s_927
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_926_0, r_926_0 z, r_926_1 z, r_926_2 z, r_926_3 z] <;> rfl
 #a w_926_0
 theorem h_926_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_926_0 z).shape = [64] := by
   unfold v_926_0
   rw [tensorSum_shape]
   exact h_221_1 z z_
 #a h_926_0
 attribute [local irreducible] v_926_0
 attribute [local irreducible] s_927
 theorem r_927_0 (z : Store) : (s_927 z) 70 = (v_221_2 z) := pR (k_926 z) (pR (k_925 z) (pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (r_892_0 z)))))))
 #a r_927_0
 theorem r_927_1 (z : Store) : (s_927 z) 373 = (v_224_2 z) := pR (k_926 z) (pR (k_925 z) (pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (r_892_1 z)))))))
 #a r_927_1
 theorem r_927_2 (z : Store) : (s_927 z) 676 = (v_643_2 z) := pR (k_926 z) (pR (k_925 z) (pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (r_892_2 z)))))))
 #a r_927_2
 theorem r_927_3 (z : Store) : (s_927 z) 979 = (v_646_2 z) := pR (k_926 z) (pR (k_925 z) (pR (k_924 z) (pR (n_920_924 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_892_896 z) (r_892_3 z)))))))
 #a r_927_3
 def v_927_0 (z : Store) : Tensor := cross_dp_wred [(v_221_2 z), (v_224_2 z), (v_643_2 z), (v_646_2 z)]
 theorem g_927 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_927) (s_927 z) pmNode_927 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_927, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_927_1 z, r_927_0 z]
     exact (h_224_2 z z_).trans (h_221_2 z z_).symm
   · rw [r_927_2 z, r_927_0 z]
     exact (h_643_2 z z_).trans (h_221_2 z z_).symm
   · rw [r_927_3 z, r_927_0 z]
     exact (h_646_2 z z_).trans (h_221_2 z z_).symm
 #a g_927
 def s_928 (z : Store) : Store := storeSet (s_927 z) [(980, cross_dp_wred [((s_927 z) 70), ((s_927 z) 373), ((s_927 z) 676), ((s_927 z) 979)])]
 theorem t_927 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_927) (pmPeers pmNode_927) (s_927 z) pmNode_927 none = some (s_928 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_927) (s_927 z) pmNode_927 = _
   rw [wredStep, if_pos ⟨by decide, g_927 z z_⟩]
   rfl
 #a t_927
 theorem k_927 (z : Store) (tid : Tid) (h : tid ∉ [980]) : (s_928 z) tid = (s_927 z) tid := by
   unfold s_928
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_927
 theorem w_927_0 (z : Store) : (s_928 z) 980 = v_927_0 z := by
   unfold s_928
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_927_0, r_927_0 z, r_927_1 z, r_927_2 z, r_927_3 z] <;> rfl
 #a w_927_0
 theorem h_927_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_927_0 z).shape = [64] := by
   unfold v_927_0
   rw [tensorSum_shape]
   exact h_221_2 z z_
 #a h_927_0
 attribute [local irreducible] v_927_0
 attribute [local irreducible] s_928
 theorem n_924_928 (z : Store) (tid : Tid) (h : tid ∉ ([971, 976, 978, 980] : List Tid)) : (s_928 z) tid = (s_924 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_924 z) (k_925 z)) (pF _ _ _ _ _ (k_926 z) (k_927 z)) tid h
 #a n_924_928
 theorem n_920_928 (z : Store) (tid : Tid) (h : tid ∉ ([931, 933, 969, 935, 971, 976, 978, 980] : List Tid)) : (s_928 z) tid = (s_920 z) tid := by
   exact pF _ _ _ _ _ (n_920_924 z) (n_924_928 z) tid h
 #a n_920_928
 theorem n_912_928 (z : Store) (tid : Tid) (h : tid ∉ ([332, 368, 335, 377, 352, 355, 358, 929, 931, 933, 969, 935, 971, 976, 978, 980] : List Tid)) : (s_928 z) tid = (s_912 z) tid := by
   exact pF _ _ _ _ _ (n_912_920 z) (n_920_928 z) tid h
 #a n_912_928
 theorem n_896_928 (z : Store) (tid : Tid) (h : tid ∉ ([646, 648, 650, 652, 624, 664, 635, 671, 638, 680, 655, 658, 661, 926, 321, 361, 332, 368, 335, 377, 352, 355, 358, 929, 931, 933, 969, 935, 971, 976, 978, 980] : List Tid)) : (s_928 z) tid = (s_896 z) tid := by
   exact pF _ _ _ _ _ (n_896_912 z) (n_912_928 z) tid h
 #a n_896_928
 theorem r_928_0 (z : Store) : (s_928 z) 33 = (v_343_1 z) := pR (n_896_928 z) (pR (k_895 z) (pR (k_894 z) (pR (k_893 z) (r_893_0 z))))
 #a r_928_0
 theorem r_928_1 (z : Store) : (s_928 z) 336 = (v_345_1 z) := pR (n_896_928 z) (pR (k_895 z) (pR (k_894 z) (pR (k_893 z) (r_893_1 z))))
 #a r_928_1
 theorem r_928_2 (z : Store) : (s_928 z) 639 = (v_765_1 z) := pR (n_896_928 z) (pR (k_895 z) (pR (k_894 z) (pR (k_893 z) (r_893_2 z))))
 #a r_928_2
 theorem r_928_3 (z : Store) : (s_928 z) 942 = (v_767_1 z) := pR (n_896_928 z) (pR (k_895 z) (pR (k_894 z) (pR (k_893 z) (r_893_3 z))))
 #a r_928_3
 def v_928_0 (z : Store) : Tensor := cross_dp_wred [(v_343_1 z), (v_345_1 z), (v_765_1 z), (v_767_1 z)]
 theorem g_928 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_928) (s_928 z) pmNode_928 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_928, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_928_1 z, r_928_0 z]
     exact (h_345_1 z z_).trans (h_343_1 z z_).symm
   · rw [r_928_2 z, r_928_0 z]
     exact (h_765_1 z z_).trans (h_343_1 z z_).symm
   · rw [r_928_3 z, r_928_0 z]
     exact (h_767_1 z z_).trans (h_343_1 z z_).symm
 #a g_928
 def s_929 (z : Store) : Store := storeSet (s_928 z) [(943, cross_dp_wred [((s_928 z) 33), ((s_928 z) 336), ((s_928 z) 639), ((s_928 z) 942)])]
 theorem t_928 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_928) (pmPeers pmNode_928) (s_928 z) pmNode_928 none = some (s_929 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_928) (s_928 z) pmNode_928 = _
   rw [wredStep, if_pos ⟨by decide, g_928 z z_⟩]
   rfl
 #a t_928
 theorem k_928 (z : Store) (tid : Tid) (h : tid ∉ [943]) : (s_929 z) tid = (s_928 z) tid := by
   unfold s_929
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_928
 theorem w_928_0 (z : Store) : (s_929 z) 943 = v_928_0 z := by
   unfold s_929
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_928_0, r_928_0 z, r_928_1 z, r_928_2 z, r_928_3 z] <;> rfl
 #a w_928_0
 theorem h_928_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_928_0 z).shape = [64, 64] := by
   unfold v_928_0
   rw [tensorSum_shape]
   exact h_343_1 z z_
 #a h_928_0
 attribute [local irreducible] v_928_0
 attribute [local irreducible] s_929
 theorem r_929_0 (z : Store) : (s_929 z) 35 = (v_330_1 z) := pR (k_928 z) (pR (n_896_928 z) (pR (k_895 z) (pR (k_894 z) (r_894_0 z))))
 #a r_929_0
 theorem r_929_1 (z : Store) : (s_929 z) 338 = (v_335_1 z) := pR (k_928 z) (pR (n_896_928 z) (pR (k_895 z) (pR (k_894 z) (r_894_1 z))))
 #a r_929_1
 theorem r_929_2 (z : Store) : (s_929 z) 641 = (v_752_1 z) := pR (k_928 z) (pR (n_896_928 z) (pR (k_895 z) (pR (k_894 z) (r_894_2 z))))
 #a r_929_2
 theorem r_929_3 (z : Store) : (s_929 z) 944 = (v_757_1 z) := pR (k_928 z) (pR (n_896_928 z) (pR (k_895 z) (pR (k_894 z) (r_894_3 z))))
 #a r_929_3
 def v_929_0 (z : Store) : Tensor := cross_dp_wred [(v_330_1 z), (v_335_1 z), (v_752_1 z), (v_757_1 z)]
 theorem g_929 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_929) (s_929 z) pmNode_929 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_929, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_929_1 z, r_929_0 z]
     exact (h_335_1 z z_).trans (h_330_1 z z_).symm
   · rw [r_929_2 z, r_929_0 z]
     exact (h_752_1 z z_).trans (h_330_1 z z_).symm
   · rw [r_929_3 z, r_929_0 z]
     exact (h_757_1 z z_).trans (h_330_1 z z_).symm
 #a g_929
 def s_930 (z : Store) : Store := storeSet (s_929 z) [(945, cross_dp_wred [((s_929 z) 35), ((s_929 z) 338), ((s_929 z) 641), ((s_929 z) 944)])]
 theorem t_929 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_929) (pmPeers pmNode_929) (s_929 z) pmNode_929 none = some (s_930 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_929) (s_929 z) pmNode_929 = _
   rw [wredStep, if_pos ⟨by decide, g_929 z z_⟩]
   rfl
 #a t_929
 theorem k_929 (z : Store) (tid : Tid) (h : tid ∉ [945]) : (s_930 z) tid = (s_929 z) tid := by
   unfold s_930
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_929
 theorem w_929_0 (z : Store) : (s_930 z) 945 = v_929_0 z := by
   unfold s_930
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_929_0, r_929_0 z, r_929_1 z, r_929_2 z, r_929_3 z] <;> rfl
 #a w_929_0
 theorem h_929_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_929_0 z).shape = [64] := by
   unfold v_929_0
   rw [tensorSum_shape]
   exact h_330_1 z z_
 #a h_929_0
 attribute [local irreducible] v_929_0
 attribute [local irreducible] s_930
 record_prefix_opacity v_924_0 s_925 v_925_0 s_926 v_926_0 s_927 v_927_0 s_928 v_928_0 s_929 v_929_0 s_930

 end
 end TrainVerify.Denote.RuntimeWorld
