import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0095
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_756_0 (z : Store) : (s_756 z) 1083 = (v_755_0 z) := w_755_0 z
 #a r_756_0
 theorem r_756_1 (z : Store) : (s_756 z) 1079 = (v_516_0 z) := pR (n_752_756 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (k_519 z) (pR (k_518 z) (pR (k_517 z) (r_517_0 z)))))))))))
 #a r_756_1
 theorem r_756_2 (z : Store) : (s_756 z) 916 = (z 916) := pR (n_752_756 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (k_519 z) (pR (k_518 z) (pR (k_517 z) (r_517_1 z)))))))))))
 #a r_756_2
 def v_756_0 (z : Store) : Tensor := (bw_linear (v_755_0 z) (v_516_0 z) (z 916)).1
 def v_756_1 (z : Store) : Tensor := (bw_linear (v_755_0 z) (v_516_0 z) (z 916)).2
 def s_757 (z : Store) : Store := storeSet (s_756 z) [(1081, (bw_linear ((s_756 z) 1083) ((s_756 z) 1079) ((s_756 z) 916)).1), (948, (bw_linear ((s_756 z) 1083) ((s_756 z) 1079) ((s_756 z) 916)).2)]
 theorem t_756 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_874) (pmPeers pmNode_874) (s_756 z) pmNode_874 none = some (s_757 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_756
 theorem k_756 (z : Store) (tid : Tid) (h : tid ∉ [1081, 948]) : (s_757 z) tid = (s_756 z) tid := by
   unfold s_757
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_756
 theorem w_756_0 (z : Store) : (s_757 z) 1081 = v_756_0 z := by
   unfold s_757
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_756_0, r_756_0 z, r_756_1 z, r_756_2 z] <;> rfl
 #a w_756_0
 theorem h_756_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_756_0 z).shape = [1, 8, 64] := by
   unfold v_756_0
   exact bw_linear_3d_fst_shape 1 8 256 64 (v_755_0 z) (v_516_0 z) (z 916) (h_755_0 z z_) (h_516_0 z z_) (i_72 z z_)
 #a h_756_0
 attribute [local irreducible] v_756_0
 theorem w_756_1 (z : Store) : (s_757 z) 948 = v_756_1 z := by
   unfold s_757
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_756_1, r_756_0 z, r_756_1 z, r_756_2 z] <;> rfl
 #a w_756_1
 theorem h_756_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_756_1 z).shape = [256, 64] := by
   unfold v_756_1
   exact bw_linear_3d_snd_shape 1 8 256 64 (v_755_0 z) (v_516_0 z) (z 916) (h_755_0 z z_) (h_516_0 z z_) (i_72 z z_)
 #a h_756_1
 attribute [local irreducible] v_756_1
 attribute [local irreducible] s_757
 theorem r_757_0 (z : Store) : (s_757 z) 1081 = (v_756_0 z) := w_756_0 z
 #a r_757_0
 theorem r_757_1 (z : Store) : (s_757 z) 1078 = (v_515_0 z) := pR (k_756 z) (pR (n_752_756 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (n_516_520 z) (r_516_0 z))))))))))
 #a r_757_1
 theorem r_757_2 (z : Store) : (s_757 z) 914 = (z 914) := pR (k_756 z) (pR (n_752_756 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (n_516_520 z) (r_516_1 z))))))))))
 #a r_757_2
 theorem r_757_3 (z : Store) : (s_757 z) 915 = (z 915) := pR (k_756 z) (pR (n_752_756 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_528_544 z) (pR (n_520_528 z) (pR (n_516_520 z) (r_516_2 z))))))))))
 #a r_757_3
 def v_757_0 (z : Store) : Tensor := (bw_layernorm (v_756_0 z) (v_515_0 z) (z 914) (z 915)).1
 def v_757_1 (z : Store) : Tensor := (bw_layernorm (v_756_0 z) (v_515_0 z) (z 914) (z 915)).2.1
 def v_757_2 (z : Store) : Tensor := (bw_layernorm (v_756_0 z) (v_515_0 z) (z 914) (z 915)).2.2
 def s_758 (z : Store) : Store := storeSet (s_757 z) [(1080, (bw_layernorm ((s_757 z) 1081) ((s_757 z) 1078) ((s_757 z) 914) ((s_757 z) 915)).1), (944, (bw_layernorm ((s_757 z) 1081) ((s_757 z) 1078) ((s_757 z) 914) ((s_757 z) 915)).2.1), (946, (bw_layernorm ((s_757 z) 1081) ((s_757 z) 1078) ((s_757 z) 914) ((s_757 z) 915)).2.2)]
 theorem t_757 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_875) (pmPeers pmNode_875) (s_757 z) pmNode_875 none = some (s_758 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_757
 theorem k_757 (z : Store) (tid : Tid) (h : tid ∉ [1080, 944, 946]) : (s_758 z) tid = (s_757 z) tid := by
   unfold s_758
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_757
 theorem w_757_0 (z : Store) : (s_758 z) 1080 = v_757_0 z := by
   unfold s_758
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_757_0, r_757_0 z, r_757_1 z, r_757_2 z, r_757_3 z] <;> rfl
 #a w_757_0
 theorem h_757_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_757_0 z).shape = [1, 8, 64] := by
   unfold v_757_0
   rw [bw_layernorm_dx_shape (v_756_0 z) (v_515_0 z) (z 914) (z 915) 64 [8, 1] (by rw [h_515_0 z z_]; rfl)]
   exact h_515_0 z z_
 #a h_757_0
 attribute [local irreducible] v_757_0
 theorem w_757_1 (z : Store) : (s_758 z) 944 = v_757_1 z := by
   unfold s_758
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_757_1, r_757_0 z, r_757_1 z, r_757_2 z, r_757_3 z] <;> rfl
 #a w_757_1
 theorem h_757_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_757_1 z).shape = [64] := by
   unfold v_757_1
   rw [bw_layernorm_dw_shape (v_756_0 z) (v_515_0 z) (z 914) (z 915) 64 [8, 1] (by rw [h_515_0 z z_]; rfl)]
   exact i_70 z z_
 #a h_757_1
 attribute [local irreducible] v_757_1
 theorem w_757_2 (z : Store) : (s_758 z) 946 = v_757_2 z := by
   unfold s_758
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_757_2, r_757_0 z, r_757_1 z, r_757_2 z, r_757_3 z] <;> rfl
 #a w_757_2
 theorem h_757_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_757_2 z).shape = [64] := by
   unfold v_757_2
   rw [bw_layernorm_db_shape (v_756_0 z) (v_515_0 z) (z 914) (z 915) 64 [8, 1] (by rw [h_515_0 z z_]; rfl)]
   exact i_71 z z_
 #a h_757_2
 attribute [local irreducible] v_757_2
 attribute [local irreducible] s_758
 theorem r_758_0 (z : Store) : (s_758 z) 777 = (v_752_0 z) := pR (k_757 z) (pR (k_756 z) (pR (k_755 z) (pR (k_754 z) (pR (k_753 z) (w_752_0 z)))))
 #a r_758_0
 theorem r_758_1 (z : Store) : (s_758 z) 1080 = (v_757_0 z) := w_757_0 z
 #a r_758_1
 def v_758_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_752_0 z), (v_757_0 z)]
 theorem g_758 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_640) (s_758 z) pmNode_640 1 2 896 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_640, r_758_0 z, r_758_1 z, h_752_0 z z_, h_757_0 z z_]
 #a g_758
 def s_759 (z : Store) : Store := pL [2, 3] (s_758 z) pmNode_640 1 2
 theorem t_758 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_640) (pmPeers pmNode_640) (s_758 z) pmNode_640 none = some (s_759 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_640) (s_758 z) pmNode_640).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 896 (by decide) (g_758 z z_)]
   rfl
 #a t_758
 theorem k_758 (z : Store) (tid : Tid) (h : tid ∉ [896]) : (s_759 z) tid = (s_758 z) tid := by
   unfold s_759
   dsimp only [pL, pmNode_640, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_758
 theorem w_758_0 (z : Store) : (s_759 z) 896 = v_758_0 z := by
   unfold s_759
   dsimp only [pL, pmNode_640, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_758_0, r_758_0 z, r_758_1 z] <;> rfl
 #a w_758_0
 theorem h_758_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_758_0 z).shape = [1, 16, 32] := by
   unfold v_758_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_752_0 z z_]
 #a h_758_0
 attribute [local irreducible] v_758_0
 attribute [local irreducible] s_759
 theorem r_759_0 (z : Store) : (s_759 z) 896 = (v_758_0 z) := w_758_0 z
 #a r_759_0
 theorem r_759_1 (z : Store) : (s_759 z) 788 = (v_744_0 z) := pR (k_758 z) (pR (k_757 z) (pR (k_756 z) (pR (n_752_756 z) (pR (n_748_752 z) (pR (k_747 z) (pR (k_746 z) (pR (k_745 z) (w_744_0 z))))))))
 #a r_759_1
 def v_759_0 (z : Store) : Tensor := tensorSum [(v_758_0 z), (v_744_0 z)]
 def s_760 (z : Store) : Store := storeSet (s_759 z) [(774, tensorSum [((s_759 z) 896), ((s_759 z) 788)])]
 theorem t_759 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_641) (pmPeers pmNode_641) (s_759 z) pmNode_641 none = some (s_760 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_759
 theorem k_759 (z : Store) (tid : Tid) (h : tid ∉ [774]) : (s_760 z) tid = (s_759 z) tid := by
   unfold s_760
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_759
 theorem w_759_0 (z : Store) : (s_760 z) 774 = v_759_0 z := by
   unfold s_760
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_759_0, r_759_0 z, r_759_1 z] <;> rfl
 #a w_759_0
 theorem h_759_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_759_0 z).shape = [1, 16, 32] := by
   unfold v_759_0
   rw [tensorSum_shape]
   exact h_758_0 z z_
 #a h_759_0
 attribute [local irreducible] v_759_0
 attribute [local irreducible] s_760
 theorem n_756_760 (z : Store) (tid : Tid) (h : tid ∉ ([1081, 948, 1080, 944, 946, 896, 774] : List Tid)) : (s_760 z) tid = (s_756 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_756 z) (k_757 z)) (pF _ _ _ _ _ (k_758 z) (k_759 z)) tid h
 #a n_756_760
 theorem n_752_760 (z : Store) (tid : Tid) (h : tid ∉ ([777, 641, 643, 1087, 1085, 950, 1083, 1081, 948, 1080, 944, 946, 896, 774] : List Tid)) : (s_760 z) tid = (s_752 z) tid := by
   exact pF _ _ _ _ _ (n_752_756 z) (n_756_760 z) tid h
 #a n_752_760
 theorem r_760_0 (z : Store) : (s_760 z) 774 = (v_759_0 z) := w_759_0 z
 #a r_760_0
 theorem r_760_1 (z : Store) : (s_760 z) 769 = (v_432_1 z) := pR (n_752_760 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (n_508_512 z) (pR (k_507 z) (pR (k_506 z) (pR (k_505 z) (r_505_0 z)))))))))
 #a r_760_1
 theorem r_760_2 (z : Store) : (s_760 z) 770 = (v_504_0 z) := pR (n_752_760 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (n_508_512 z) (pR (k_507 z) (pR (k_506 z) (pR (k_505 z) (r_505_1 z)))))))))
 #a r_760_2
 def v_760_0 (z : Store) : Tensor := (bw_add2 (v_759_0 z) (v_432_1 z) (v_504_0 z)).1
 def v_760_1 (z : Store) : Tensor := (bw_add2 (v_759_0 z) (v_432_1 z) (v_504_0 z)).2
 def s_761 (z : Store) : Store := storeSet (s_760 z) [(772, (bw_add2 ((s_760 z) 774) ((s_760 z) 769) ((s_760 z) 770)).1), (773, (bw_add2 ((s_760 z) 774) ((s_760 z) 769) ((s_760 z) 770)).2)]
 theorem t_760 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_642) (pmPeers pmNode_642) (s_760 z) pmNode_642 none = some (s_761 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_760
 theorem k_760 (z : Store) (tid : Tid) (h : tid ∉ [772, 773]) : (s_761 z) tid = (s_760 z) tid := by
   unfold s_761
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_760
 theorem w_760_0 (z : Store) : (s_761 z) 772 = v_760_0 z := by
   unfold s_761
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_760_0, r_760_0 z, r_760_1 z, r_760_2 z] <;> rfl
 #a w_760_0
 theorem h_760_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_760_0 z).shape = [1, 16, 32] := by
   unfold v_760_0
   exact h_432_1 z z_
 #a h_760_0
 attribute [local irreducible] v_760_0
 theorem w_760_1 (z : Store) : (s_761 z) 773 = v_760_1 z := by
   unfold s_761
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_760_1, r_760_0 z, r_760_1 z, r_760_2 z] <;> rfl
 #a w_760_1
 theorem h_760_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_760_1 z).shape = [1, 16, 32] := by
   unfold v_760_1
   exact h_504_0 z z_
 #a h_760_1
 attribute [local irreducible] v_760_1
 attribute [local irreducible] s_761
 theorem r_761_0 (z : Store) : (s_761 z) 777 = (v_752_0 z) := pR (k_760 z) (pR (k_759 z) (pR (k_758 z) (r_758_0 z)))
 #a r_761_0
 theorem r_761_1 (z : Store) : (s_761 z) 1080 = (v_757_0 z) := pR (k_760 z) (pR (k_759 z) (pR (k_758 z) (r_758_1 z)))
 #a r_761_1
 def v_761_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_752_0 z), (v_757_0 z)]
 theorem g_761 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_876) (s_761 z) pmNode_876 1 2 1199 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_876, r_761_0 z, r_761_1 z, h_752_0 z z_, h_757_0 z z_]
 #a g_761
 def s_762 (z : Store) : Store := pL [2, 3] (s_761 z) pmNode_876 1 2
 theorem t_761 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_876) (pmPeers pmNode_876) (s_761 z) pmNode_876 none = some (s_762 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_876) (s_761 z) pmNode_876).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1199 (by decide) (g_761 z z_)]
   rfl
 #a t_761
 theorem k_761 (z : Store) (tid : Tid) (h : tid ∉ [1199]) : (s_762 z) tid = (s_761 z) tid := by
   unfold s_762
   dsimp only [pL, pmNode_876, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_761
 theorem w_761_0 (z : Store) : (s_762 z) 1199 = v_761_0 z := by
   unfold s_762
   dsimp only [pL, pmNode_876, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_761_0, r_761_0 z, r_761_1 z] <;> rfl
 #a w_761_0
 theorem h_761_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_761_0 z).shape = [1, 16, 32] := by
   unfold v_761_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_752_0 z z_]
 #a h_761_0
 attribute [local irreducible] v_761_0
 attribute [local irreducible] s_762
 theorem r_762_0 (z : Store) : (s_762 z) 1199 = (v_761_0 z) := w_761_0 z
 #a r_762_0
 theorem r_762_1 (z : Store) : (s_762 z) 1091 = (v_747_0 z) := pR (k_761 z) (pR (k_760 z) (pR (n_752_760 z) (pR (n_748_752 z) (w_747_0 z))))
 #a r_762_1
 def v_762_0 (z : Store) : Tensor := tensorSum [(v_761_0 z), (v_747_0 z)]
 def s_763 (z : Store) : Store := storeSet (s_762 z) [(1077, tensorSum [((s_762 z) 1199), ((s_762 z) 1091)])]
 theorem t_762 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_877) (pmPeers pmNode_877) (s_762 z) pmNode_877 none = some (s_763 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_762
 theorem k_762 (z : Store) (tid : Tid) (h : tid ∉ [1077]) : (s_763 z) tid = (s_762 z) tid := by
   unfold s_763
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_762
 theorem w_762_0 (z : Store) : (s_763 z) 1077 = v_762_0 z := by
   unfold s_763
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_762_0, r_762_0 z, r_762_1 z] <;> rfl
 #a w_762_0
 theorem h_762_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_762_0 z).shape = [1, 16, 32] := by
   unfold v_762_0
   rw [tensorSum_shape]
   exact h_761_0 z z_
 #a h_762_0
 attribute [local irreducible] v_762_0
 attribute [local irreducible] s_763
 record_prefix_opacity v_756_0 v_756_1 s_757 v_757_0 v_757_1 v_757_2 s_758 v_758_0 s_759 v_759_0 s_760 v_760_0 v_760_1 s_761 v_761_0 s_762 v_762_0 s_763

 end
 end TrainVerify.Denote.RuntimeWorld
