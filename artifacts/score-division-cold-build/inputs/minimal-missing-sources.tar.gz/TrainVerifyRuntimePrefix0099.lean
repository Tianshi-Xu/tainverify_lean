import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0098
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_778_0 (z : Store) : (s_778 z) 1061 = (v_777_0 z) := w_777_0 z
 #a r_778_0
 theorem r_778_1 (z : Store) : (s_778 z) 1056 = (v_493_0 z) := pR (k_777 z) (pR (k_776 z) (pR (n_768_776 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (k_495 z) (pR (k_494 z) (r_494_0 z)))))))
 #a r_778_1
 def v_778_0 (z : Store) : Tensor := transposeAxes 1 2 (v_777_0 z)
 def s_779 (z : Store) : Store := storeSet (s_778 z) [(1059, transposeAxes 1 2 ((s_778 z) 1061))]
 theorem t_778 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_885) (pmPeers pmNode_885) (s_778 z) pmNode_885 none = some (s_779 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_778
 theorem k_778 (z : Store) (tid : Tid) (h : tid ∉ [1059]) : (s_779 z) tid = (s_778 z) tid := by
   unfold s_779
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_778
 theorem w_778_0 (z : Store) : (s_779 z) 1059 = v_778_0 z := by
   unfold s_779
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_778_0, r_778_0 z, r_778_1 z] <;> rfl
 #a w_778_0
 theorem h_778_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_778_0 z).shape = [1, 4, 8, 16] := by
   unfold v_778_0
   change listSwapAt _ _ _ = _
   rw [h_777_0 z z_]
   rfl
 #a h_778_0
 attribute [local irreducible] v_778_0
 attribute [local irreducible] s_779
 theorem r_779_0 (z : Store) : (s_779 z) 1059 = (v_778_0 z) := w_778_0 z
 #a r_779_0
 theorem r_779_1 (z : Store) : (s_779 z) 1055 = (v_492_0 z) := pR (k_778 z) (pR (k_777 z) (pR (k_776 z) (pR (n_768_776 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (k_495 z) (pR (k_494 z) (pR (k_493 z) (r_493_0 z)))))))))
 #a r_779_1
 theorem r_779_2 (z : Store) : (s_779 z) 987 = (v_491_0 z) := pR (k_778 z) (pR (k_777 z) (pR (k_776 z) (pR (n_768_776 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (k_495 z) (pR (k_494 z) (pR (k_493 z) (r_493_1 z)))))))))
 #a r_779_2
 def v_779_0 (z : Store) : Tensor := (batchedMatmulBwd (v_778_0 z) (v_492_0 z) (v_491_0 z)).1
 def v_779_1 (z : Store) : Tensor := (batchedMatmulBwd (v_778_0 z) (v_492_0 z) (v_491_0 z)).2
 def s_780 (z : Store) : Store := storeSet (s_779 z) [(1058, (batchedMatmulBwd ((s_779 z) 1059) ((s_779 z) 1055) ((s_779 z) 987)).1), (1057, (batchedMatmulBwd ((s_779 z) 1059) ((s_779 z) 1055) ((s_779 z) 987)).2)]
 theorem t_779 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_886) (pmPeers pmNode_886) (s_779 z) pmNode_886 none = some (s_780 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_779
 theorem k_779 (z : Store) (tid : Tid) (h : tid ∉ [1058, 1057]) : (s_780 z) tid = (s_779 z) tid := by
   unfold s_780
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_779
 theorem w_779_0 (z : Store) : (s_780 z) 1058 = v_779_0 z := by
   unfold s_780
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_779_0, r_779_0 z, r_779_1 z, r_779_2 z] <;> rfl
 #a w_779_0
 theorem h_779_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_779_0 z).shape = [1, 4, 8, 16] := by
   unfold v_779_0
   change (batchedMatmul (v_778_0 z) (transpose2d (v_491_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_778_0 z z_, h_491_0 z z_]
   rfl
 #a h_779_0
 attribute [local irreducible] v_779_0
 theorem w_779_1 (z : Store) : (s_780 z) 1057 = v_779_1 z := by
   unfold s_780
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_779_1, r_779_0 z, r_779_1 z, r_779_2 z] <;> rfl
 #a w_779_1
 theorem h_779_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_779_1 z).shape = [1, 4, 16, 16] := by
   unfold v_779_1
   change (batchedMatmul (transpose2d (v_492_0 z)) (v_778_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_778_0 z z_, h_492_0 z z_]
   rfl
 #a h_779_1
 attribute [local irreducible] v_779_1
 attribute [local irreducible] s_780
 theorem n_776_780 (z : Store) (tid : Tid) (h : tid ∉ ([1063, 1061, 1059, 1058, 1057] : List Tid)) : (s_780 z) tid = (s_776 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_776 z) (k_777 z)) (pF _ _ _ _ _ (k_778 z) (k_779 z)) tid h
 #a n_776_780
 theorem r_780_0 (z : Store) : (s_780 z) 754 = (v_775_0 z) := pR (n_776_780 z) (w_775_0 z)
 #a r_780_0
 theorem r_780_1 (z : Store) : (s_780 z) 1058 = (v_779_0 z) := w_779_0 z
 #a r_780_1
 def v_780_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_775_0 z), (v_779_0 z)]
 theorem g_780 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_651) (s_780 z) pmNode_651 2 1 751 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_651, r_780_0 z, r_780_1 z, h_775_0 z z_, h_779_0 z z_]
 #a g_780
 def s_781 (z : Store) : Store := pL [2, 3] (s_780 z) pmNode_651 2 1
 theorem t_780 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_651) (pmPeers pmNode_651) (s_780 z) pmNode_651 none = some (s_781 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_651) (s_780 z) pmNode_651).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 751 (by decide) (g_780 z z_)]
   rfl
 #a t_780
 theorem k_780 (z : Store) (tid : Tid) (h : tid ∉ [751]) : (s_781 z) tid = (s_780 z) tid := by
   unfold s_781
   dsimp only [pL, pmNode_651, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_780
 theorem w_780_0 (z : Store) : (s_781 z) 751 = v_780_0 z := by
   unfold s_781
   dsimp only [pL, pmNode_651, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_780_0, r_780_0 z, r_780_1 z] <;> rfl
 #a w_780_0
 theorem h_780_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_780_0 z).shape = [1, 2, 16, 16] := by
   unfold v_780_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_775_0 z z_]
 #a h_780_0
 attribute [local irreducible] v_780_0
 attribute [local irreducible] s_781
 theorem r_781_0 (z : Store) : (s_781 z) 756 = (v_775_1 z) := pR (k_780 z) (pR (n_776_780 z) (w_775_1 z))
 #a r_781_0
 theorem r_781_1 (z : Store) : (s_781 z) 1057 = (v_779_1 z) := pR (k_780 z) (w_779_1 z)
 #a r_781_1
 def v_781_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 0 [(v_775_1 z), (v_779_1 z)]
 def s_782 (z : Store) : Store := storeSet (s_781 z) [(735, reduceScatterPrimDimN 2 2 0 [((s_781 z) 756), ((s_781 z) 1057)])]
 theorem t_781 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_652) (pmPeers pmNode_652) (s_781 z) pmNode_652 none = some (s_782 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_781 z) pmNode_652 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_781
 theorem k_781 (z : Store) (tid : Tid) (h : tid ∉ [735]) : (s_782 z) tid = (s_781 z) tid := by
   unfold s_782
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_781
 theorem w_781_0 (z : Store) : (s_782 z) 735 = v_781_0 z := by
   unfold s_782
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_781_0, r_781_0 z, r_781_1 z] <;> rfl
 #a w_781_0
 theorem h_781_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_781_0 z).shape = [1, 4, 8, 16] := by
   unfold v_781_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 0 _ [1, 4, 16, 16]
   · rw [allReducePrim_shape _ _ _ (v_775_1 z) rfl]
     exact h_775_1 z z_
   · decide
 #a h_781_0
 attribute [local irreducible] v_781_0
 attribute [local irreducible] s_782
 theorem r_782_0 (z : Store) : (s_782 z) 751 = (v_780_0 z) := pR (k_781 z) (w_780_0 z)
 #a r_782_0
 theorem r_782_1 (z : Store) : (s_782 z) 748 = (v_482_0 z) := pR (k_781 z) (pR (k_780 z) (pR (n_776_780 z) (pR (n_768_776 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (n_488_496 z) (pR (n_484_488 z) (pR (k_483 z) (r_483_0 z)))))))))
 #a r_782_1
 def v_782_0 (z : Store) : Tensor := bw_softmax (v_780_0 z) (v_482_0 z)
 def s_783 (z : Store) : Store := storeSet (s_782 z) [(750, bw_softmax ((s_782 z) 751) ((s_782 z) 748))]
 theorem t_782 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_653) (pmPeers pmNode_653) (s_782 z) pmNode_653 none = some (s_783 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_782
 theorem k_782 (z : Store) (tid : Tid) (h : tid ∉ [750]) : (s_783 z) tid = (s_782 z) tid := by
   unfold s_783
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_782
 theorem w_782_0 (z : Store) : (s_783 z) 750 = v_782_0 z := by
   unfold s_783
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_782_0, r_782_0 z, r_782_1 z] <;> rfl
 #a w_782_0
 theorem h_782_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_782_0 z).shape = [1, 2, 16, 16] := by
   unfold v_782_0
   unfold bw_softmax softmaxBwd softmaxBwdFromOutput softmax
   rw [h_482_0 z z_]
   rfl
 #a h_782_0
 attribute [local irreducible] v_782_0
 attribute [local irreducible] s_783
 theorem r_783_0 (z : Store) : (s_783 z) 754 = (v_775_0 z) := pR (k_782 z) (pR (k_781 z) (pR (k_780 z) (r_780_0 z)))
 #a r_783_0
 theorem r_783_1 (z : Store) : (s_783 z) 1058 = (v_779_0 z) := pR (k_782 z) (pR (k_781 z) (pR (k_780 z) (r_780_1 z)))
 #a r_783_1
 def v_783_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_775_0 z), (v_779_0 z)]
 theorem g_783 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_887) (s_783 z) pmNode_887 2 1 1054 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_887, r_783_0 z, r_783_1 z, h_775_0 z z_, h_779_0 z z_]
 #a g_783
 def s_784 (z : Store) : Store := pL [2, 3] (s_783 z) pmNode_887 2 1
 theorem t_783 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_887) (pmPeers pmNode_887) (s_783 z) pmNode_887 none = some (s_784 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_887) (s_783 z) pmNode_887).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1054 (by decide) (g_783 z z_)]
   rfl
 #a t_783
 theorem k_783 (z : Store) (tid : Tid) (h : tid ∉ [1054]) : (s_784 z) tid = (s_783 z) tid := by
   unfold s_784
   dsimp only [pL, pmNode_887, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_783
 theorem w_783_0 (z : Store) : (s_784 z) 1054 = v_783_0 z := by
   unfold s_784
   dsimp only [pL, pmNode_887, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_783_0, r_783_0 z, r_783_1 z] <;> rfl
 #a w_783_0
 theorem h_783_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_783_0 z).shape = [1, 2, 16, 16] := by
   unfold v_783_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_775_0 z z_]
 #a h_783_0
 attribute [local irreducible] v_783_0
 attribute [local irreducible] s_784
 theorem r_784_0 (z : Store) : (s_784 z) 756 = (v_775_1 z) := pR (k_783 z) (pR (k_782 z) (pR (k_781 z) (r_781_0 z)))
 #a r_784_0
 theorem r_784_1 (z : Store) : (s_784 z) 1057 = (v_779_1 z) := pR (k_783 z) (pR (k_782 z) (pR (k_781 z) (r_781_1 z)))
 #a r_784_1
 def v_784_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 1 [(v_775_1 z), (v_779_1 z)]
 def s_785 (z : Store) : Store := storeSet (s_784 z) [(1038, reduceScatterPrimDimN 2 2 1 [((s_784 z) 756), ((s_784 z) 1057)])]
 theorem t_784 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_888) (pmPeers pmNode_888) (s_784 z) pmNode_888 none = some (s_785 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_784 z) pmNode_888 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_784
 theorem k_784 (z : Store) (tid : Tid) (h : tid ∉ [1038]) : (s_785 z) tid = (s_784 z) tid := by
   unfold s_785
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_784
 theorem w_784_0 (z : Store) : (s_785 z) 1038 = v_784_0 z := by
   unfold s_785
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_784_0, r_784_0 z, r_784_1 z] <;> rfl
 #a w_784_0
 theorem h_784_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_784_0 z).shape = [1, 4, 8, 16] := by
   unfold v_784_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 1 _ [1, 4, 16, 16]
   · rw [allReducePrim_shape _ _ _ (v_775_1 z) rfl]
     exact h_775_1 z z_
   · decide
 #a h_784_0
 attribute [local irreducible] v_784_0
 attribute [local irreducible] s_785
 theorem n_780_784 (z : Store) (tid : Tid) (h : tid ∉ ([751, 735, 750, 1054] : List Tid)) : (s_784 z) tid = (s_780 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_780 z) (k_781 z)) (pF _ _ _ _ _ (k_782 z) (k_783 z)) tid h
 #a n_780_784
 theorem n_776_784 (z : Store) (tid : Tid) (h : tid ∉ ([1063, 1061, 1059, 1058, 1057, 751, 735, 750, 1054] : List Tid)) : (s_784 z) tid = (s_776 z) tid := by
   exact pF _ _ _ _ _ (n_776_780 z) (n_780_784 z) tid h
 #a n_776_784
 theorem n_768_784 (z : Store) (tid : Tid) (h : tid ∉ ([764, 763, 1067, 1066, 760, 758, 755, 754, 756, 1063, 1061, 1059, 1058, 1057, 751, 735, 750, 1054] : List Tid)) : (s_784 z) tid = (s_768 z) tid := by
   exact pF _ _ _ _ _ (n_768_776 z) (n_776_784 z) tid h
 #a n_768_784
 theorem r_785_0 (z : Store) : (s_785 z) 1054 = (v_783_0 z) := pR (k_784 z) (w_783_0 z)
 #a r_785_0
 theorem r_785_1 (z : Store) : (s_785 z) 1051 = (v_485_0 z) := pR (k_784 z) (pR (n_768_784 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (n_488_496 z) (pR (k_487 z) (pR (k_486 z) (r_486_0 z)))))))
 #a r_785_1
 def v_785_0 (z : Store) : Tensor := bw_softmax (v_783_0 z) (v_485_0 z)
 def s_786 (z : Store) : Store := storeSet (s_785 z) [(1053, bw_softmax ((s_785 z) 1054) ((s_785 z) 1051))]
 theorem t_785 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_889) (pmPeers pmNode_889) (s_785 z) pmNode_889 none = some (s_786 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_785
 theorem k_785 (z : Store) (tid : Tid) (h : tid ∉ [1053]) : (s_786 z) tid = (s_785 z) tid := by
   unfold s_786
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_785
 theorem w_785_0 (z : Store) : (s_786 z) 1053 = v_785_0 z := by
   unfold s_786
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_785_0, r_785_0 z, r_785_1 z] <;> rfl
 #a w_785_0
 theorem h_785_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_785_0 z).shape = [1, 2, 16, 16] := by
   unfold v_785_0
   unfold bw_softmax softmaxBwd softmaxBwdFromOutput softmax
   rw [h_485_0 z z_]
   rfl
 #a h_785_0
 attribute [local irreducible] v_785_0
 attribute [local irreducible] s_786
 record_prefix_opacity v_778_0 s_779 v_779_0 v_779_1 s_780 v_780_0 s_781 v_781_0 s_782 v_782_0 s_783 v_783_0 s_784 v_784_0 s_785 v_785_0 s_786

 end
 end TrainVerify.Denote.RuntimeWorld
