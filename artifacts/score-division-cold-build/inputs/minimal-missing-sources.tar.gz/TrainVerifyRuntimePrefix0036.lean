import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0035
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_277_0 (z : Store) : (s_277 z) 223 = (v_276_0 z) := w_276_0 z
 #a r_277_0
 theorem r_277_1 (z : Store) : (s_277 z) 211 = (v_135_0 z) := pR (k_276 z) (pR (n_272_276 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_144_160 z) (r_144_0 z))))))
 #a r_277_1
 def v_277_0 (z : Store) : Tensor := transposeAxes 2 3 (v_276_0 z)
 def s_278 (z : Store) : Store := storeSet (s_277 z) [(213, transposeAxes 2 3 ((s_277 z) 223))]
 theorem t_277 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_139) (pmPeers pmNode_139) (s_277 z) pmNode_139 none = some (s_278 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_277
 theorem k_277 (z : Store) (tid : Tid) (h : tid ∉ [213]) : (s_278 z) tid = (s_277 z) tid := by
   unfold s_278
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_277
 theorem w_277_0 (z : Store) : (s_278 z) 213 = v_277_0 z := by
   unfold s_278
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_277_0, r_277_0 z, r_277_1 z] <;> rfl
 #a w_277_0
 theorem h_277_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_277_0 z).shape = [1, 4, 16, 8] := by
   unfold v_277_0
   change listSwapAt _ _ _ = _
   rw [h_276_0 z z_]
   rfl
 #a h_277_0
 attribute [local irreducible] v_277_0
 attribute [local irreducible] s_278
 theorem r_278_0 (z : Store) : (s_278 z) 221 = (v_264_0 z) := pR (k_277 z) (pR (k_276 z) (pR (n_272_276 z) (pR (n_268_272 z) (pR (k_267 z) (pR (k_266 z) (pR (k_265 z) (w_264_0 z)))))))
 #a r_278_0
 theorem r_278_1 (z : Store) : (s_278 z) 218 = (v_142_0 z) := pR (k_277 z) (pR (k_276 z) (pR (n_272_276 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_144_160 z) (pR (k_143 z) (r_143_0 z))))))))
 #a r_278_1
 def v_278_0 (z : Store) : Tensor := transposeAxes 1 2 (v_264_0 z)
 def s_279 (z : Store) : Store := storeSet (s_278 z) [(220, transposeAxes 1 2 ((s_278 z) 221))]
 theorem t_278 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_140) (pmPeers pmNode_140) (s_278 z) pmNode_140 none = some (s_279 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_278
 theorem k_278 (z : Store) (tid : Tid) (h : tid ∉ [220]) : (s_279 z) tid = (s_278 z) tid := by
   unfold s_279
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_278
 theorem w_278_0 (z : Store) : (s_279 z) 220 = v_278_0 z := by
   unfold s_279
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_278_0, r_278_0 z, r_278_1 z] <;> rfl
 #a w_278_0
 theorem h_278_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_278_0 z).shape = [1, 8, 4, 16] := by
   unfold v_278_0
   change listSwapAt _ _ _ = _
   rw [h_264_0 z z_]
   rfl
 #a h_278_0
 attribute [local irreducible] v_278_0
 attribute [local irreducible] s_279
 theorem r_279_0 (z : Store) : (s_279 z) 226 = (v_273_1 z) := pR (k_278 z) (pR (k_277 z) (pR (k_276 z) (r_276_0 z)))
 #a r_279_0
 theorem r_279_1 (z : Store) : (s_279 z) 529 = (v_275_1 z) := pR (k_278 z) (pR (k_277 z) (pR (k_276 z) (r_276_1 z)))
 #a r_279_1
 def v_279_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_273_1 z), (v_275_1 z)]
 theorem g_279 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_374) (s_279 z) pmNode_374 1 2 526 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_374, r_279_0 z, r_279_1 z, h_273_1 z z_, h_275_1 z z_]
 #a g_279
 def s_280 (z : Store) : Store := pL [0, 1] (s_279 z) pmNode_374 1 2
 theorem t_279 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_374) (pmPeers pmNode_374) (s_279 z) pmNode_374 none = some (s_280 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_374) (s_279 z) pmNode_374).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 526 (by decide) (g_279 z z_)]
   rfl
 #a t_279
 theorem k_279 (z : Store) (tid : Tid) (h : tid ∉ [526]) : (s_280 z) tid = (s_279 z) tid := by
   unfold s_280
   dsimp only [pL, pmNode_374, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_279
 theorem w_279_0 (z : Store) : (s_280 z) 526 = v_279_0 z := by
   unfold s_280
   dsimp only [pL, pmNode_374, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_279_0, r_279_0 z, r_279_1 z] <;> rfl
 #a w_279_0
 theorem h_279_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_279_0 z).shape = [1, 4, 8, 16] := by
   unfold v_279_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_273_1 z z_]
 #a h_279_0
 attribute [local irreducible] v_279_0
 attribute [local irreducible] s_280
 theorem n_276_280 (z : Store) (tid : Tid) (h : tid ∉ ([223, 213, 220, 526] : List Tid)) : (s_280 z) tid = (s_276 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_276 z) (k_277 z)) (pF _ _ _ _ _ (k_278 z) (k_279 z)) tid h
 #a n_276_280
 theorem n_272_280 (z : Store) (tid : Tid) (h : tid ∉ ([227, 205, 226, 530, 508, 529, 223, 213, 220, 526] : List Tid)) : (s_280 z) tid = (s_272 z) tid := by
   exact pF _ _ _ _ _ (n_272_276 z) (n_276_280 z) tid h
 #a n_272_280
 theorem r_280_0 (z : Store) : (s_280 z) 526 = (v_279_0 z) := w_279_0 z
 #a r_280_0
 theorem r_280_1 (z : Store) : (s_280 z) 514 = (v_139_0 z) := pR (n_272_280 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_152_160 z) (pR (n_148_152 z) (pR (k_147 z) (r_147_0 z)))))))
 #a r_280_1
 def v_280_0 (z : Store) : Tensor := transposeAxes 2 3 (v_279_0 z)
 def s_281 (z : Store) : Store := storeSet (s_280 z) [(516, transposeAxes 2 3 ((s_280 z) 526))]
 theorem t_280 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_375) (pmPeers pmNode_375) (s_280 z) pmNode_375 none = some (s_281 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_280
 theorem k_280 (z : Store) (tid : Tid) (h : tid ∉ [516]) : (s_281 z) tid = (s_280 z) tid := by
   unfold s_281
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_280
 theorem w_280_0 (z : Store) : (s_281 z) 516 = v_280_0 z := by
   unfold s_281
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_280_0, r_280_0 z, r_280_1 z] <;> rfl
 #a w_280_0
 theorem h_280_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_280_0 z).shape = [1, 4, 16, 8] := by
   unfold v_280_0
   change listSwapAt _ _ _ = _
   rw [h_279_0 z z_]
   rfl
 #a h_280_0
 attribute [local irreducible] v_280_0
 attribute [local irreducible] s_281
 theorem r_281_0 (z : Store) : (s_281 z) 524 = (v_266_0 z) := pR (k_280 z) (pR (n_272_280 z) (pR (n_268_272 z) (pR (k_267 z) (w_266_0 z))))
 #a r_281_0
 theorem r_281_1 (z : Store) : (s_281 z) 521 = (v_145_0 z) := pR (k_280 z) (pR (n_272_280 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_152_160 z) (pR (n_148_152 z) (pR (k_147 z) (pR (k_146 z) (r_146_0 z)))))))))
 #a r_281_1
 def v_281_0 (z : Store) : Tensor := transposeAxes 1 2 (v_266_0 z)
 def s_282 (z : Store) : Store := storeSet (s_281 z) [(523, transposeAxes 1 2 ((s_281 z) 524))]
 theorem t_281 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_376) (pmPeers pmNode_376) (s_281 z) pmNode_376 none = some (s_282 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_281
 theorem k_281 (z : Store) (tid : Tid) (h : tid ∉ [523]) : (s_282 z) tid = (s_281 z) tid := by
   unfold s_282
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_281
 theorem w_281_0 (z : Store) : (s_282 z) 523 = v_281_0 z := by
   unfold s_282
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_281_0, r_281_0 z, r_281_1 z] <;> rfl
 #a w_281_0
 theorem h_281_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_281_0 z).shape = [1, 8, 4, 16] := by
   unfold v_281_0
   change listSwapAt _ _ _ = _
   rw [h_266_0 z z_]
   rfl
 #a h_281_0
 attribute [local irreducible] v_281_0
 attribute [local irreducible] s_282
 theorem r_282_0 (z : Store) : (s_282 z) 220 = (v_278_0 z) := pR (k_281 z) (pR (k_280 z) (pR (k_279 z) (w_278_0 z)))
 #a r_282_0
 theorem r_282_1 (z : Store) : (s_282 z) 523 = (v_281_0 z) := w_281_0 z
 #a r_282_1
 def v_282_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_278_0 z), (v_281_0 z)]
 theorem g_282 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_141) (s_282 z) pmNode_141 1 2 217 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_141, r_282_0 z, r_282_1 z, h_278_0 z z_, h_281_0 z z_]
 #a g_282
 def s_283 (z : Store) : Store := pL [0, 1] (s_282 z) pmNode_141 1 2
 theorem t_282 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_141) (pmPeers pmNode_141) (s_282 z) pmNode_141 none = some (s_283 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_141) (s_282 z) pmNode_141).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 217 (by decide) (g_282 z z_)]
   rfl
 #a t_282
 theorem k_282 (z : Store) (tid : Tid) (h : tid ∉ [217]) : (s_283 z) tid = (s_282 z) tid := by
   unfold s_283
   dsimp only [pL, pmNode_141, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_282
 theorem w_282_0 (z : Store) : (s_283 z) 217 = v_282_0 z := by
   unfold s_283
   dsimp only [pL, pmNode_141, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_282_0, r_282_0 z, r_282_1 z] <;> rfl
 #a w_282_0
 theorem h_282_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_282_0 z).shape = [1, 16, 2, 16] := by
   unfold v_282_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_278_0 z z_]
 #a h_282_0
 attribute [local irreducible] v_282_0
 attribute [local irreducible] s_283
 theorem r_283_0 (z : Store) : (s_283 z) 217 = (v_282_0 z) := w_282_0 z
 #a r_283_0
 theorem r_283_1 (z : Store) : (s_283 z) 214 = (v_136_0 z) := pR (k_282 z) (pR (k_281 z) (pR (k_280 z) (pR (n_272_280 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_144_160 z) (pR (n_140_144 z) (pR (k_139 z) (pR (k_138 z) (pR (k_137 z) (r_137_0 z))))))))))))
 #a r_283_1
 def v_283_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_282_0 z)
 def s_284 (z : Store) : Store := storeSet (s_283 z) [(216, fw_view [1, 16, 32] ((s_283 z) 217))]
 theorem t_283 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_142) (pmPeers pmNode_142) (s_283 z) pmNode_142 none = some (s_284 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_283
 theorem k_283 (z : Store) (tid : Tid) (h : tid ∉ [216]) : (s_284 z) tid = (s_283 z) tid := by
   unfold s_284
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_283
 theorem w_283_0 (z : Store) : (s_284 z) 216 = v_283_0 z := by
   unfold s_284
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_283_0, r_283_0 z, r_283_1 z] <;> rfl
 #a w_283_0
 theorem h_283_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_283_0 z).shape = [1, 16, 32] := by
   unfold v_283_0
   rfl
 #a h_283_0
 attribute [local irreducible] v_283_0
 attribute [local irreducible] s_284
 theorem r_284_0 (z : Store) : (s_284 z) 220 = (v_278_0 z) := pR (k_283 z) (pR (k_282 z) (r_282_0 z))
 #a r_284_0
 theorem r_284_1 (z : Store) : (s_284 z) 523 = (v_281_0 z) := pR (k_283 z) (pR (k_282 z) (r_282_1 z))
 #a r_284_1
 def v_284_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_278_0 z), (v_281_0 z)]
 theorem g_284 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_377) (s_284 z) pmNode_377 1 2 520 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_377, r_284_0 z, r_284_1 z, h_278_0 z z_, h_281_0 z z_]
 #a g_284
 def s_285 (z : Store) : Store := pL [0, 1] (s_284 z) pmNode_377 1 2
 theorem t_284 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_377) (pmPeers pmNode_377) (s_284 z) pmNode_377 none = some (s_285 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_377) (s_284 z) pmNode_377).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 520 (by decide) (g_284 z z_)]
   rfl
 #a t_284
 theorem k_284 (z : Store) (tid : Tid) (h : tid ∉ [520]) : (s_285 z) tid = (s_284 z) tid := by
   unfold s_285
   dsimp only [pL, pmNode_377, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_284
 theorem w_284_0 (z : Store) : (s_285 z) 520 = v_284_0 z := by
   unfold s_285
   dsimp only [pL, pmNode_377, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_284_0, r_284_0 z, r_284_1 z] <;> rfl
 #a w_284_0
 theorem h_284_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_284_0 z).shape = [1, 16, 2, 16] := by
   unfold v_284_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_278_0 z z_]
 #a h_284_0
 attribute [local irreducible] v_284_0
 attribute [local irreducible] s_285
 theorem n_280_284 (z : Store) (tid : Tid) (h : tid ∉ ([516, 523, 217, 216] : List Tid)) : (s_284 z) tid = (s_280 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_280 z) (k_281 z)) (pF _ _ _ _ _ (k_282 z) (k_283 z)) tid h
 #a n_280_284
 theorem r_285_0 (z : Store) : (s_285 z) 520 = (v_284_0 z) := w_284_0 z
 #a r_285_0
 theorem r_285_1 (z : Store) : (s_285 z) 517 = (v_140_0 z) := pR (k_284 z) (pR (n_280_284 z) (pR (n_272_280 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_144_160 z) (pR (k_143 z) (pR (k_142 z) (pR (k_141 z) (r_141_0 z))))))))))
 #a r_285_1
 def v_285_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_284_0 z)
 def s_286 (z : Store) : Store := storeSet (s_285 z) [(519, fw_view [1, 16, 32] ((s_285 z) 520))]
 theorem t_285 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_378) (pmPeers pmNode_378) (s_285 z) pmNode_378 none = some (s_286 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_285
 theorem k_285 (z : Store) (tid : Tid) (h : tid ∉ [519]) : (s_286 z) tid = (s_285 z) tid := by
   unfold s_286
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_285
 theorem w_285_0 (z : Store) : (s_286 z) 519 = v_285_0 z := by
   unfold s_286
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_285_0, r_285_0 z, r_285_1 z] <;> rfl
 #a w_285_0
 theorem h_285_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_285_0 z).shape = [1, 16, 32] := by
   unfold v_285_0
   rfl
 #a h_285_0
 attribute [local irreducible] v_285_0
 attribute [local irreducible] s_286
 record_prefix_opacity v_277_0 s_278 v_278_0 s_279 v_279_0 s_280 v_280_0 s_281 v_281_0 s_282 v_282_0 s_283 v_283_0 s_284 v_284_0 s_285 v_285_0 s_286

 end
 end TrainVerify.Denote.RuntimeWorld
