import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0117
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_917_0 (z : Store) : (s_917 z) 354 = (v_309_1 z) := pR (k_916 z) (pR (n_912_916 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_320_384 z) (pR (n_312_320 z) (pR (k_311 z) (pR (k_310 z) (w_309_1 z))))))))))
 #a r_917_0
 theorem r_917_1 (z : Store) : (s_917 z) 960 = (v_731_1 z) := pR (k_916 z) (pR (n_912_916 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_736_768 z) (pR (n_732_736 z) (w_731_1 z))))))
 #a r_917_1
 def v_917_0 (z : Store) : Tensor := cross_dp_wred [(v_309_1 z), (v_731_1 z)]
 theorem g_917 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_470) (s_917 z) pmNode_470 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_470, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_917_1 z, r_917_0 z]
     exact (h_731_1 z z_).trans (h_309_1 z z_).symm
 #a g_917
 def s_918 (z : Store) : Store := storeSet (s_917 z) [(355, cross_dp_wred [((s_917 z) 354), ((s_917 z) 960)])]
 theorem t_917 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_470) (pmPeers pmNode_470) (s_917 z) pmNode_470 none = some (s_918 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_470) (s_917 z) pmNode_470 = _
   rw [wredStep, if_pos ⟨by decide, g_917 z z_⟩]
   rfl
 #a t_917
 theorem k_917 (z : Store) (tid : Tid) (h : tid ∉ [355]) : (s_918 z) tid = (s_917 z) tid := by
   unfold s_918
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_917
 theorem w_917_0 (z : Store) : (s_918 z) 355 = v_917_0 z := by
   unfold s_918
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_917_0, r_917_0 z, r_917_1 z] <;> rfl
 #a w_917_0
 theorem h_917_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_917_0 z).shape = [64, 32] := by
   unfold v_917_0
   rw [tensorSum_shape]
   exact h_309_1 z z_
 #a h_917_0
 attribute [local irreducible] v_917_0
 attribute [local irreducible] s_918
 theorem r_918_0 (z : Store) : (s_918 z) 357 = (v_305_1 z) := pR (k_917 z) (pR (k_916 z) (pR (n_912_916 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_320_384 z) (pR (n_312_320 z) (pR (n_308_312 z) (pR (k_307 z) (pR (k_306 z) (w_305_1 z))))))))))))
 #a r_918_0
 theorem r_918_1 (z : Store) : (s_918 z) 963 = (v_727_1 z) := pR (k_917 z) (pR (k_916 z) (pR (n_912_916 z) (pR (n_896_912 z) (pR (n_768_896 z) (pR (n_736_768 z) (pR (n_728_736 z) (w_727_1 z)))))))
 #a r_918_1
 def v_918_0 (z : Store) : Tensor := cross_dp_wred [(v_305_1 z), (v_727_1 z)]
 theorem g_918 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [1, 3] (pmPeers pmNode_471) (s_918 z) pmNode_471 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_471, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_918_1 z, r_918_0 z]
     exact (h_727_1 z z_).trans (h_305_1 z z_).symm
 #a g_918
 def s_919 (z : Store) : Store := storeSet (s_918 z) [(358, cross_dp_wred [((s_918 z) 357), ((s_918 z) 963)])]
 theorem t_918 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_471) (pmPeers pmNode_471) (s_918 z) pmNode_471 none = some (s_919 z) := by
   change wredStep pmGraph (some [1, 3]) (pmPeers pmNode_471) (s_918 z) pmNode_471 = _
   rw [wredStep, if_pos ⟨by decide, g_918 z z_⟩]
   rfl
 #a t_918
 theorem k_918 (z : Store) (tid : Tid) (h : tid ∉ [358]) : (s_919 z) tid = (s_918 z) tid := by
   unfold s_919
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_918
 theorem w_918_0 (z : Store) : (s_919 z) 358 = v_918_0 z := by
   unfold s_919
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_918_0, r_918_0 z, r_918_1 z] <;> rfl
 #a w_918_0
 theorem h_918_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_918_0 z).shape = [64, 32] := by
   unfold v_918_0
   rw [tensorSum_shape]
   exact h_305_1 z z_
 #a h_918_0
 attribute [local irreducible] v_918_0
 attribute [local irreducible] s_919
 theorem r_919_0 (z : Store) : (s_919 z) 19 = (v_417_0 z) := pR (k_918 z) (pR (k_917 z) (pR (k_916 z) (pR (n_912_916 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (n_884_888 z) (r_884_0 z)))))))
 #a r_919_0
 theorem r_919_1 (z : Store) : (s_919 z) 322 = (v_420_0 z) := pR (k_918 z) (pR (k_917 z) (pR (k_916 z) (pR (n_912_916 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (n_884_888 z) (r_884_1 z)))))))
 #a r_919_1
 theorem r_919_2 (z : Store) : (s_919 z) 625 = (v_839_0 z) := pR (k_918 z) (pR (k_917 z) (pR (k_916 z) (pR (n_912_916 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (n_884_888 z) (r_884_2 z)))))))
 #a r_919_2
 theorem r_919_3 (z : Store) : (s_919 z) 928 = (v_842_0 z) := pR (k_918 z) (pR (k_917 z) (pR (k_916 z) (pR (n_912_916 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (n_884_888 z) (r_884_3 z)))))))
 #a r_919_3
 def v_919_0 (z : Store) : Tensor := cross_dp_wred [(v_417_0 z), (v_420_0 z), (v_839_0 z), (v_842_0 z)]
 theorem g_919 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_919) (s_919 z) pmNode_919 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_919, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_919_1 z, r_919_0 z]
     exact (h_420_0 z z_).trans (h_417_0 z z_).symm
   · rw [r_919_2 z, r_919_0 z]
     exact (h_839_0 z z_).trans (h_417_0 z z_).symm
   · rw [r_919_3 z, r_919_0 z]
     exact (h_842_0 z z_).trans (h_417_0 z z_).symm
 #a g_919
 def s_920 (z : Store) : Store := storeSet (s_919 z) [(929, cross_dp_wred [((s_919 z) 19), ((s_919 z) 322), ((s_919 z) 625), ((s_919 z) 928)])]
 theorem t_919 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_919) (pmPeers pmNode_919) (s_919 z) pmNode_919 none = some (s_920 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_919) (s_919 z) pmNode_919 = _
   rw [wredStep, if_pos ⟨by decide, g_919 z z_⟩]
   rfl
 #a t_919
 theorem k_919 (z : Store) (tid : Tid) (h : tid ∉ [929]) : (s_920 z) tid = (s_919 z) tid := by
   unfold s_920
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_919
 theorem w_919_0 (z : Store) : (s_920 z) 929 = v_919_0 z := by
   unfold s_920
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_919_0, r_919_0 z, r_919_1 z, r_919_2 z, r_919_3 z] <;> rfl
 #a w_919_0
 theorem h_919_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_919_0 z).shape = [16, 64] := by
   unfold v_919_0
   rw [tensorSum_shape]
   exact h_417_0 z z_
 #a h_919_0
 attribute [local irreducible] v_919_0
 attribute [local irreducible] s_920
 theorem n_916_920 (z : Store) (tid : Tid) (h : tid ∉ ([352, 355, 358, 929] : List Tid)) : (s_920 z) tid = (s_916 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_916 z) (k_917 z)) (pF _ _ _ _ _ (k_918 z) (k_919 z)) tid h
 #a n_916_920
 theorem n_912_920 (z : Store) (tid : Tid) (h : tid ∉ ([332, 368, 335, 377, 352, 355, 358, 929] : List Tid)) : (s_920 z) tid = (s_912 z) tid := by
   exact pF _ _ _ _ _ (n_912_916 z) (n_916_920 z) tid h
 #a n_912_920
 theorem r_920_0 (z : Store) : (s_920 z) 21 = (v_405_1 z) := pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (pR (k_886 z) (pR (k_885 z) (r_885_0 z))))))
 #a r_920_0
 theorem r_920_1 (z : Store) : (s_920 z) 324 = (v_409_1 z) := pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (pR (k_886 z) (pR (k_885 z) (r_885_1 z))))))
 #a r_920_1
 theorem r_920_2 (z : Store) : (s_920 z) 627 = (v_827_1 z) := pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (pR (k_886 z) (pR (k_885 z) (r_885_2 z))))))
 #a r_920_2
 theorem r_920_3 (z : Store) : (s_920 z) 930 = (v_831_1 z) := pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (pR (k_886 z) (pR (k_885 z) (r_885_3 z))))))
 #a r_920_3
 def v_920_0 (z : Store) : Tensor := cross_dp_wred [(v_405_1 z), (v_409_1 z), (v_827_1 z), (v_831_1 z)]
 theorem g_920 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_920) (s_920 z) pmNode_920 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_920, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_920_1 z, r_920_0 z]
     exact (h_409_1 z z_).trans (h_405_1 z z_).symm
   · rw [r_920_2 z, r_920_0 z]
     exact (h_827_1 z z_).trans (h_405_1 z z_).symm
   · rw [r_920_3 z, r_920_0 z]
     exact (h_831_1 z z_).trans (h_405_1 z z_).symm
 #a g_920
 def s_921 (z : Store) : Store := storeSet (s_920 z) [(931, cross_dp_wred [((s_920 z) 21), ((s_920 z) 324), ((s_920 z) 627), ((s_920 z) 930)])]
 theorem t_920 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_920) (pmPeers pmNode_920) (s_920 z) pmNode_920 none = some (s_921 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_920) (s_920 z) pmNode_920 = _
   rw [wredStep, if_pos ⟨by decide, g_920 z z_⟩]
   rfl
 #a t_920
 theorem k_920 (z : Store) (tid : Tid) (h : tid ∉ [931]) : (s_921 z) tid = (s_920 z) tid := by
   unfold s_921
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_920
 theorem w_920_0 (z : Store) : (s_921 z) 931 = v_920_0 z := by
   unfold s_921
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_920_0, r_920_0 z, r_920_1 z, r_920_2 z, r_920_3 z] <;> rfl
 #a w_920_0
 theorem h_920_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_920_0 z).shape = [64] := by
   unfold v_920_0
   rw [tensorSum_shape]
   exact h_405_1 z z_
 #a h_920_0
 attribute [local irreducible] v_920_0
 attribute [local irreducible] s_921
 theorem r_921_0 (z : Store) : (s_921 z) 23 = (v_405_2 z) := pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (pR (k_886 z) (r_886_0 z))))))
 #a r_921_0
 theorem r_921_1 (z : Store) : (s_921 z) 326 = (v_409_2 z) := pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (pR (k_886 z) (r_886_1 z))))))
 #a r_921_1
 theorem r_921_2 (z : Store) : (s_921 z) 629 = (v_827_2 z) := pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (pR (k_886 z) (r_886_2 z))))))
 #a r_921_2
 theorem r_921_3 (z : Store) : (s_921 z) 932 = (v_831_2 z) := pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (pR (k_886 z) (r_886_3 z))))))
 #a r_921_3
 def v_921_0 (z : Store) : Tensor := cross_dp_wred [(v_405_2 z), (v_409_2 z), (v_827_2 z), (v_831_2 z)]
 theorem g_921 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_921) (s_921 z) pmNode_921 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_921, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_921_1 z, r_921_0 z]
     exact (h_409_2 z z_).trans (h_405_2 z z_).symm
   · rw [r_921_2 z, r_921_0 z]
     exact (h_827_2 z z_).trans (h_405_2 z z_).symm
   · rw [r_921_3 z, r_921_0 z]
     exact (h_831_2 z z_).trans (h_405_2 z z_).symm
 #a g_921
 def s_922 (z : Store) : Store := storeSet (s_921 z) [(933, cross_dp_wred [((s_921 z) 23), ((s_921 z) 326), ((s_921 z) 629), ((s_921 z) 932)])]
 theorem t_921 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_921) (pmPeers pmNode_921) (s_921 z) pmNode_921 none = some (s_922 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_921) (s_921 z) pmNode_921 = _
   rw [wredStep, if_pos ⟨by decide, g_921 z z_⟩]
   rfl
 #a t_921
 theorem k_921 (z : Store) (tid : Tid) (h : tid ∉ [933]) : (s_922 z) tid = (s_921 z) tid := by
   unfold s_922
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_921
 theorem w_921_0 (z : Store) : (s_922 z) 933 = v_921_0 z := by
   unfold s_922
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_921_0, r_921_0 z, r_921_1 z, r_921_2 z, r_921_3 z] <;> rfl
 #a w_921_0
 theorem h_921_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_921_0 z).shape = [64] := by
   unfold v_921_0
   rw [tensorSum_shape]
   exact h_405_2 z z_
 #a h_921_0
 attribute [local irreducible] v_921_0
 attribute [local irreducible] s_922
 theorem r_922_0 (z : Store) : (s_922 z) 59 = (v_237_1 z) := pR (k_921 z) (pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (r_887_0 z))))))
 #a r_922_0
 theorem r_922_1 (z : Store) : (s_922 z) 362 = (v_239_1 z) := pR (k_921 z) (pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (r_887_1 z))))))
 #a r_922_1
 theorem r_922_2 (z : Store) : (s_922 z) 665 = (v_659_1 z) := pR (k_921 z) (pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (r_887_2 z))))))
 #a r_922_2
 theorem r_922_3 (z : Store) : (s_922 z) 968 = (v_661_1 z) := pR (k_921 z) (pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (pR (k_887 z) (r_887_3 z))))))
 #a r_922_3
 def v_922_0 (z : Store) : Tensor := cross_dp_wred [(v_237_1 z), (v_239_1 z), (v_659_1 z), (v_661_1 z)]
 theorem g_922 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_922) (s_922 z) pmNode_922 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_922, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_922_1 z, r_922_0 z]
     exact (h_239_1 z z_).trans (h_237_1 z z_).symm
   · rw [r_922_2 z, r_922_0 z]
     exact (h_659_1 z z_).trans (h_237_1 z z_).symm
   · rw [r_922_3 z, r_922_0 z]
     exact (h_661_1 z z_).trans (h_237_1 z z_).symm
 #a g_922
 def s_923 (z : Store) : Store := storeSet (s_922 z) [(969, cross_dp_wred [((s_922 z) 59), ((s_922 z) 362), ((s_922 z) 665), ((s_922 z) 968)])]
 theorem t_922 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_922) (pmPeers pmNode_922) (s_922 z) pmNode_922 none = some (s_923 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_922) (s_922 z) pmNode_922 = _
   rw [wredStep, if_pos ⟨by decide, g_922 z z_⟩]
   rfl
 #a t_922
 theorem k_922 (z : Store) (tid : Tid) (h : tid ∉ [969]) : (s_923 z) tid = (s_922 z) tid := by
   unfold s_923
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_922
 theorem w_922_0 (z : Store) : (s_923 z) 969 = v_922_0 z := by
   unfold s_923
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_922_0, r_922_0 z, r_922_1 z, r_922_2 z, r_922_3 z] <;> rfl
 #a w_922_0
 theorem h_922_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_922_0 z).shape = [64] := by
   unfold v_922_0
   rw [tensorSum_shape]
   exact h_237_1 z z_
 #a h_922_0
 attribute [local irreducible] v_922_0
 attribute [local irreducible] s_923
 theorem r_923_0 (z : Store) : (s_923 z) 25 = (v_403_1 z) := pR (k_922 z) (pR (k_921 z) (pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (r_888_0 z))))))
 #a r_923_0
 theorem r_923_1 (z : Store) : (s_923 z) 328 = (v_407_1 z) := pR (k_922 z) (pR (k_921 z) (pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (r_888_1 z))))))
 #a r_923_1
 theorem r_923_2 (z : Store) : (s_923 z) 631 = (v_825_1 z) := pR (k_922 z) (pR (k_921 z) (pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (r_888_2 z))))))
 #a r_923_2
 theorem r_923_3 (z : Store) : (s_923 z) 934 = (v_829_1 z) := pR (k_922 z) (pR (k_921 z) (pR (k_920 z) (pR (n_912_920 z) (pR (n_896_912 z) (pR (n_888_896 z) (r_888_3 z))))))
 #a r_923_3
 def v_923_0 (z : Store) : Tensor := cross_dp_wred [(v_403_1 z), (v_407_1 z), (v_825_1 z), (v_829_1 z)]
 theorem g_923 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_923) (s_923 z) pmNode_923 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_923, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_923_1 z, r_923_0 z]
     exact (h_407_1 z z_).trans (h_403_1 z z_).symm
   · rw [r_923_2 z, r_923_0 z]
     exact (h_825_1 z z_).trans (h_403_1 z z_).symm
   · rw [r_923_3 z, r_923_0 z]
     exact (h_829_1 z z_).trans (h_403_1 z z_).symm
 #a g_923
 def s_924 (z : Store) : Store := storeSet (s_923 z) [(935, cross_dp_wred [((s_923 z) 25), ((s_923 z) 328), ((s_923 z) 631), ((s_923 z) 934)])]
 theorem t_923 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_923) (pmPeers pmNode_923) (s_923 z) pmNode_923 none = some (s_924 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_923) (s_923 z) pmNode_923 = _
   rw [wredStep, if_pos ⟨by decide, g_923 z z_⟩]
   rfl
 #a t_923
 theorem k_923 (z : Store) (tid : Tid) (h : tid ∉ [935]) : (s_924 z) tid = (s_923 z) tid := by
   unfold s_924
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_923
 theorem w_923_0 (z : Store) : (s_924 z) 935 = v_923_0 z := by
   unfold s_924
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_923_0, r_923_0 z, r_923_1 z, r_923_2 z, r_923_3 z] <;> rfl
 #a w_923_0
 theorem h_923_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_923_0 z).shape = [64, 64] := by
   unfold v_923_0
   rw [tensorSum_shape]
   exact h_403_1 z z_
 #a h_923_0
 attribute [local irreducible] v_923_0
 attribute [local irreducible] s_924
 theorem n_920_924 (z : Store) (tid : Tid) (h : tid ∉ ([931, 933, 969, 935] : List Tid)) : (s_924 z) tid = (s_920 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_920 z) (k_921 z)) (pF _ _ _ _ _ (k_922 z) (k_923 z)) tid h
 #a n_920_924
 record_prefix_opacity v_917_0 s_918 v_918_0 s_919 v_919_0 s_920 v_920_0 s_921 v_921_0 s_922 v_922_0 s_923 v_923_0 s_924

 end
 end TrainVerify.Denote.RuntimeWorld
