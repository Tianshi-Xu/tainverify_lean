import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0022
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_174_0 (z : Store) : (s_174 z) 248 = (v_173_0 z) := w_173_0 z
 #a r_174_0
 theorem r_174_1 (z : Store) : (s_174 z) 56 = (z 56) := pR (k_173 z) (pR (k_172 z) (pR (n_168_172 z) (pR (n_160_168 z) (pR (n_128_160 z) (pR (n_0_128 z) (e_34 z))))))
 #a r_174_1
 def v_174_0 (z : Store) : Tensor := fw_linear (v_173_0 z) (z 56)
 def s_175 (z : Store) : Store := storeSet (s_174 z) [(251, fw_linear ((s_174 z) 248) ((s_174 z) 56))]
 theorem t_174 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_88) (pmPeers pmNode_88) (s_174 z) pmNode_88 none = some (s_175 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_174
 theorem k_174 (z : Store) (tid : Tid) (h : tid ∉ [251]) : (s_175 z) tid = (s_174 z) tid := by
   unfold s_175
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_174
 theorem w_174_0 (z : Store) : (s_175 z) 251 = v_174_0 z := by
   unfold s_175
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_174_0, r_174_0 z, r_174_1 z] <;> rfl
 #a w_174_0
 theorem h_174_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_174_0 z).shape = [1, 16, 64] := by
   unfold v_174_0
   exact fw_linear_3d_shape 1 16 32 64 (v_173_0 z) (z 56) (h_173_0 z z_) (i_34 z z_)
 #a h_174_0
 attribute [local irreducible] v_174_0
 attribute [local irreducible] s_175
 theorem r_175_0 (z : Store) : (s_175 z) 244 = (v_169_0 z) := pR (k_174 z) (pR (k_173 z) (pR (k_172 z) (r_172_0 z)))
 #a r_175_0
 theorem r_175_1 (z : Store) : (s_175 z) 547 = (v_171_0 z) := pR (k_174 z) (pR (k_173 z) (pR (k_172 z) (r_172_1 z)))
 #a r_175_1
 def v_175_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_169_0 z), (v_171_0 z)]
 theorem g_175 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_322) (s_175 z) pmNode_322 1 2 550 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_322, r_175_0 z, r_175_1 z, h_169_0 z z_, h_171_0 z z_]
 #a g_175
 def s_176 (z : Store) : Store := pL [0, 1] (s_175 z) pmNode_322 1 2
 theorem t_175 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_322) (pmPeers pmNode_322) (s_175 z) pmNode_322 none = some (s_176 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_322) (s_175 z) pmNode_322).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 550 (by decide) (g_175 z z_)]
   rfl
 #a t_175
 theorem k_175 (z : Store) (tid : Tid) (h : tid ∉ [550]) : (s_176 z) tid = (s_175 z) tid := by
   unfold s_176
   dsimp only [pL, pmNode_322, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_175
 theorem w_175_0 (z : Store) : (s_176 z) 550 = v_175_0 z := by
   unfold s_176
   dsimp only [pL, pmNode_322, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_175_0, r_175_0 z, r_175_1 z] <;> rfl
 #a w_175_0
 theorem h_175_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_175_0 z).shape = [1, 16, 2, 16] := by
   unfold v_175_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_169_0 z z_]
 #a h_175_0
 attribute [local irreducible] v_175_0
 attribute [local irreducible] s_176
 theorem r_176_0 (z : Store) : (s_176 z) 550 = (v_175_0 z) := w_175_0 z
 #a r_176_0
 def v_176_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_175_0 z)
 def s_177 (z : Store) : Store := storeSet (s_176 z) [(551, fw_view [1, 16, 32] ((s_176 z) 550))]
 theorem t_176 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_323) (pmPeers pmNode_323) (s_176 z) pmNode_323 none = some (s_177 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_176
 theorem k_176 (z : Store) (tid : Tid) (h : tid ∉ [551]) : (s_177 z) tid = (s_176 z) tid := by
   unfold s_177
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_176
 theorem w_176_0 (z : Store) : (s_177 z) 551 = v_176_0 z := by
   unfold s_177
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_176_0, r_176_0 z] <;> rfl
 #a w_176_0
 theorem h_176_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_176_0 z).shape = [1, 16, 32] := by
   unfold v_176_0
   rfl
 #a h_176_0
 attribute [local irreducible] v_176_0
 attribute [local irreducible] s_177
 theorem n_172_176 (z : Store) (tid : Tid) (h : tid ∉ ([247, 248, 251, 550] : List Tid)) : (s_176 z) tid = (s_172 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_172 z) (k_173 z)) (pF _ _ _ _ _ (k_174 z) (k_175 z)) tid h
 #a n_172_176
 theorem n_168_176 (z : Store) (tid : Tid) (h : tid ∉ ([243, 244, 546, 547, 247, 248, 251, 550] : List Tid)) : (s_176 z) tid = (s_168 z) tid := by
   exact pF _ _ _ _ _ (n_168_172 z) (n_172_176 z) tid h
 #a n_168_176
 theorem n_160_176 (z : Store) (tid : Tid) (h : tid ∉ ([535, 536, 382, 539, 239, 240, 542, 543, 243, 244, 546, 547, 247, 248, 251, 550] : List Tid)) : (s_176 z) tid = (s_160 z) tid := by
   exact pF _ _ _ _ _ (n_160_168 z) (n_168_176 z) tid h
 #a n_160_176
 theorem r_177_0 (z : Store) : (s_177 z) 551 = (v_176_0 z) := w_176_0 z
 #a r_177_0
 theorem r_177_1 (z : Store) : (s_177 z) 359 = (z 359) := pR (k_176 z) (pR (n_160_176 z) (pR (n_128_160 z) (pR (n_0_128 z) (e_35 z))))
 #a r_177_1
 def v_177_0 (z : Store) : Tensor := fw_linear (v_176_0 z) (z 359)
 def s_178 (z : Store) : Store := storeSet (s_177 z) [(554, fw_linear ((s_177 z) 551) ((s_177 z) 359))]
 theorem t_177 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_324) (pmPeers pmNode_324) (s_177 z) pmNode_324 none = some (s_178 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_177
 theorem k_177 (z : Store) (tid : Tid) (h : tid ∉ [554]) : (s_178 z) tid = (s_177 z) tid := by
   unfold s_178
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_177
 theorem w_177_0 (z : Store) : (s_178 z) 554 = v_177_0 z := by
   unfold s_178
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_177_0, r_177_0 z, r_177_1 z] <;> rfl
 #a w_177_0
 theorem h_177_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_177_0 z).shape = [1, 16, 64] := by
   unfold v_177_0
   exact fw_linear_3d_shape 1 16 32 64 (v_176_0 z) (z 359) (h_176_0 z z_) (i_35 z z_)
 #a h_177_0
 attribute [local irreducible] v_177_0
 attribute [local irreducible] s_178
 theorem r_178_0 (z : Store) : (s_178 z) 251 = (v_174_0 z) := pR (k_177 z) (pR (k_176 z) (pR (k_175 z) (w_174_0 z)))
 #a r_178_0
 theorem r_178_1 (z : Store) : (s_178 z) 554 = (v_177_0 z) := w_177_0 z
 #a r_178_1
 def v_178_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 0 [(v_174_0 z), (v_177_0 z)]
 def s_179 (z : Store) : Store := storeSet (s_178 z) [(253, reduceScatterPrimDimN 2 2 0 [((s_178 z) 251), ((s_178 z) 554)])]
 theorem t_178 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_89) (pmPeers pmNode_89) (s_178 z) pmNode_89 none = some (s_179 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_178 z) pmNode_89 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_178
 theorem k_178 (z : Store) (tid : Tid) (h : tid ∉ [253]) : (s_179 z) tid = (s_178 z) tid := by
   unfold s_179
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_178
 theorem w_178_0 (z : Store) : (s_179 z) 253 = v_178_0 z := by
   unfold s_179
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_178_0, r_178_0 z, r_178_1 z] <;> rfl
 #a w_178_0
 theorem h_178_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_178_0 z).shape = [1, 16, 32] := by
   unfold v_178_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_174_0 z) rfl]
     exact h_174_0 z z_
   · decide
 #a h_178_0
 attribute [local irreducible] v_178_0
 attribute [local irreducible] s_179
 theorem r_179_0 (z : Store) : (s_179 z) 252 = (v_100_1 z) := pR (k_178 z) (pR (k_177 z) (pR (k_176 z) (pR (n_160_176 z) (pR (n_128_160 z) (pR (n_112_128 z) (pR (n_104_112 z) (pR (k_103 z) (pR (k_102 z) (pR (k_101 z) (w_100_1 z))))))))))
 #a r_179_0
 theorem r_179_1 (z : Store) : (s_179 z) 253 = (v_178_0 z) := w_178_0 z
 #a r_179_1
 def v_179_0 (z : Store) : Tensor := elemwiseAdd (v_100_1 z) (v_178_0 z)
 def s_180 (z : Store) : Store := storeSet (s_179 z) [(254, elemwiseAdd ((s_179 z) 252) ((s_179 z) 253))]
 theorem t_179 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_90) (pmPeers pmNode_90) (s_179 z) pmNode_90 none = some (s_180 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_179
 theorem k_179 (z : Store) (tid : Tid) (h : tid ∉ [254]) : (s_180 z) tid = (s_179 z) tid := by
   unfold s_180
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_179
 theorem w_179_0 (z : Store) : (s_180 z) 254 = v_179_0 z := by
   unfold s_180
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_179_0, r_179_0 z, r_179_1 z] <;> rfl
 #a w_179_0
 theorem h_179_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_179_0 z).shape = [1, 16, 32] := by
   unfold v_179_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_100_1 z z_, h_178_0 z z_]
 #a h_179_0
 attribute [local irreducible] v_179_0
 attribute [local irreducible] s_180
 theorem r_180_0 (z : Store) : (s_180 z) 254 = (v_179_0 z) := w_179_0 z
 #a r_180_0
 def v_180_0 (z : Store) : Tensor := (v_179_0 z)
 def v_180_1 (z : Store) : Tensor := (v_179_0 z)
 def s_181 (z : Store) : Store := storeSet (s_180 z) [(299, ((s_180 z) 254)), (301, ((s_180 z) 254))]
 theorem t_180 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_91) (pmPeers pmNode_91) (s_180 z) pmNode_91 none = some (s_181 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_180
 theorem k_180 (z : Store) (tid : Tid) (h : tid ∉ [299, 301]) : (s_181 z) tid = (s_180 z) tid := by
   unfold s_181
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_180
 theorem w_180_0 (z : Store) : (s_181 z) 299 = v_180_0 z := by
   unfold s_181
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_180_0, r_180_0 z] <;> rfl
 #a w_180_0
 theorem h_180_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_180_0 z).shape = [1, 16, 32] := by
   unfold v_180_0
   exact h_179_0 z z_
 #a h_180_0
 attribute [local irreducible] v_180_0
 theorem w_180_1 (z : Store) : (s_181 z) 301 = v_180_1 z := by
   unfold s_181
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_180_1, r_180_0 z] <;> rfl
 #a w_180_1
 theorem h_180_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_180_1 z).shape = [1, 16, 32] := by
   unfold v_180_1
   exact h_179_0 z z_
 #a h_180_1
 attribute [local irreducible] v_180_1
 attribute [local irreducible] s_181
 theorem r_181_0 (z : Store) : (s_181 z) 251 = (v_174_0 z) := pR (k_180 z) (pR (k_179 z) (pR (k_178 z) (r_178_0 z)))
 #a r_181_0
 theorem r_181_1 (z : Store) : (s_181 z) 554 = (v_177_0 z) := pR (k_180 z) (pR (k_179 z) (pR (k_178 z) (r_178_1 z)))
 #a r_181_1
 def v_181_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 1 [(v_174_0 z), (v_177_0 z)]
 def s_182 (z : Store) : Store := storeSet (s_181 z) [(556, reduceScatterPrimDimN 2 2 1 [((s_181 z) 251), ((s_181 z) 554)])]
 theorem t_181 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_325) (pmPeers pmNode_325) (s_181 z) pmNode_325 none = some (s_182 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_181 z) pmNode_325 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_181
 theorem k_181 (z : Store) (tid : Tid) (h : tid ∉ [556]) : (s_182 z) tid = (s_181 z) tid := by
   unfold s_182
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_181
 theorem w_181_0 (z : Store) : (s_182 z) 556 = v_181_0 z := by
   unfold s_182
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_181_0, r_181_0 z, r_181_1 z] <;> rfl
 #a w_181_0
 theorem h_181_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_181_0 z).shape = [1, 16, 32] := by
   unfold v_181_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_174_0 z) rfl]
     exact h_174_0 z z_
   · decide
 #a h_181_0
 attribute [local irreducible] v_181_0
 attribute [local irreducible] s_182
 theorem n_176_180 (z : Store) (tid : Tid) (h : tid ∉ ([551, 554, 253, 254] : List Tid)) : (s_180 z) tid = (s_176 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_176 z) (k_177 z)) (pF _ _ _ _ _ (k_178 z) (k_179 z)) tid h
 #a n_176_180
 theorem r_182_0 (z : Store) : (s_182 z) 555 = (v_103_1 z) := pR (k_181 z) (pR (k_180 z) (pR (n_176_180 z) (pR (n_160_176 z) (pR (n_128_160 z) (pR (n_112_128 z) (pR (n_104_112 z) (w_103_1 z)))))))
 #a r_182_0
 theorem r_182_1 (z : Store) : (s_182 z) 556 = (v_181_0 z) := w_181_0 z
 #a r_182_1
 def v_182_0 (z : Store) : Tensor := elemwiseAdd (v_103_1 z) (v_181_0 z)
 def s_183 (z : Store) : Store := storeSet (s_182 z) [(557, elemwiseAdd ((s_182 z) 555) ((s_182 z) 556))]
 theorem t_182 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_326) (pmPeers pmNode_326) (s_182 z) pmNode_326 none = some (s_183 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_182
 theorem k_182 (z : Store) (tid : Tid) (h : tid ∉ [557]) : (s_183 z) tid = (s_182 z) tid := by
   unfold s_183
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_182
 theorem w_182_0 (z : Store) : (s_183 z) 557 = v_182_0 z := by
   unfold s_183
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_182_0, r_182_0 z, r_182_1 z] <;> rfl
 #a w_182_0
 theorem h_182_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_182_0 z).shape = [1, 16, 32] := by
   unfold v_182_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_103_1 z z_, h_181_0 z z_]
 #a h_182_0
 attribute [local irreducible] v_182_0
 attribute [local irreducible] s_183
 record_prefix_opacity v_174_0 s_175 v_175_0 s_176 v_176_0 s_177 v_177_0 s_178 v_178_0 s_179 v_179_0 s_180 v_180_0 v_180_1 s_181 v_181_0 s_182 v_182_0 s_183

 end
 end TrainVerify.Denote.RuntimeWorld
