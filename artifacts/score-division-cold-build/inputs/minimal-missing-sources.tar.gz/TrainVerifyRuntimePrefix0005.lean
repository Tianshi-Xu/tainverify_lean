import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0004
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_17_0 (z : Store) : (s_17 z) 102 = (v_16_0 z) := w_16_0 z
 #a r_17_0
 theorem r_17_1 (z : Store) : (s_17 z) 3 = (z 3) := pR (k_16 z) (pR (n_0_16 z) (e_6 z))
 #a r_17_1
 def v_17_0 (z : Store) : Tensor := fw_linear (v_16_0 z) (z 3)
 def s_18 (z : Store) : Store := storeSet (s_17 z) [(103, fw_linear ((s_17 z) 102) ((s_17 z) 3))]
 theorem t_17 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_10) (pmPeers pmNode_10) (s_17 z) pmNode_10 none = some (s_18 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_17
 theorem k_17 (z : Store) (tid : Tid) (h : tid ∉ [103]) : (s_18 z) tid = (s_17 z) tid := by
   unfold s_18
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_17
 theorem w_17_0 (z : Store) : (s_18 z) 103 = v_17_0 z := by
   unfold s_18
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_17_0, r_17_0 z, r_17_1 z] <;> rfl
 #a w_17_0
 theorem h_17_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_17_0 z).shape = [1, 8, 64] := by
   unfold v_17_0
   exact fw_linear_3d_shape 1 8 64 64 (v_16_0 z) (z 3) (h_16_0 z z_) (i_6 z z_)
 #a h_17_0
 attribute [local irreducible] v_17_0
 attribute [local irreducible] s_18
 theorem r_18_0 (z : Store) : (s_18 z) 283 = (v_10_0 z) := pR (k_17 z) (pR (k_16 z) (pR (k_15 z) (pR (k_14 z) (r_14_0 z))))
 #a r_18_0
 theorem r_18_1 (z : Store) : (s_18 z) 586 = (v_13_0 z) := pR (k_17 z) (pR (k_16 z) (pR (k_15 z) (pR (k_14 z) (r_14_1 z))))
 #a r_18_1
 def v_18_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_10_0 z), (v_13_0 z)]
 theorem g_18 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_243) (s_18 z) pmNode_243 2 1 401 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_243, r_18_0 z, r_18_1 z, h_10_0 z z_, h_13_0 z z_]
 #a g_18
 def s_19 (z : Store) : Store := pL [0, 1] (s_18 z) pmNode_243 2 1
 theorem t_18 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_243) (pmPeers pmNode_243) (s_18 z) pmNode_243 none = some (s_19 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_243) (s_18 z) pmNode_243).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 401 (by decide) (g_18 z z_)]
   rfl
 #a t_18
 theorem k_18 (z : Store) (tid : Tid) (h : tid ∉ [401]) : (s_19 z) tid = (s_18 z) tid := by
   unfold s_19
   dsimp only [pL, pmNode_243, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_18
 theorem w_18_0 (z : Store) : (s_19 z) 401 = v_18_0 z := by
   unfold s_19
   dsimp only [pL, pmNode_243, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_18_0, r_18_0 z, r_18_1 z] <;> rfl
 #a w_18_0
 theorem h_18_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_18_0 z).shape = [1, 8, 64] := by
   unfold v_18_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_10_0 z z_]
 #a h_18_0
 attribute [local irreducible] v_18_0
 attribute [local irreducible] s_19
 theorem r_19_0 (z : Store) : (s_19 z) 401 = (v_18_0 z) := w_18_0 z
 #a r_19_0
 theorem r_19_1 (z : Store) : (s_19 z) 304 = (z 304) := pR (k_18 z) (pR (k_17 z) (pR (k_16 z) (pR (n_0_16 z) (e_7 z))))
 #a r_19_1
 theorem r_19_2 (z : Store) : (s_19 z) 305 = (z 305) := pR (k_18 z) (pR (k_17 z) (pR (k_16 z) (pR (n_0_16 z) (e_8 z))))
 #a r_19_2
 def v_19_0 (z : Store) : Tensor := fw_layernorm (v_18_0 z) (z 304) (z 305)
 def s_20 (z : Store) : Store := storeSet (s_19 z) [(402, fw_layernorm ((s_19 z) 401) ((s_19 z) 304) ((s_19 z) 305))]
 theorem t_19 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_244) (pmPeers pmNode_244) (s_19 z) pmNode_244 none = some (s_20 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_19
 theorem k_19 (z : Store) (tid : Tid) (h : tid ∉ [402]) : (s_20 z) tid = (s_19 z) tid := by
   unfold s_20
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_19
 theorem w_19_0 (z : Store) : (s_20 z) 402 = v_19_0 z := by
   unfold s_20
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_19_0, r_19_0 z, r_19_1 z, r_19_2 z] <;> rfl
 #a w_19_0
 theorem h_19_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_19_0 z).shape = [1, 8, 64] := by
   unfold v_19_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_18_0 z z_
 #a h_19_0
 attribute [local irreducible] v_19_0
 attribute [local irreducible] s_20
 theorem r_20_0 (z : Store) : (s_20 z) 402 = (v_19_0 z) := w_19_0 z
 #a r_20_0
 def v_20_0 (z : Store) : Tensor := (v_19_0 z)
 def v_20_1 (z : Store) : Tensor := (v_19_0 z)
 def v_20_2 (z : Store) : Tensor := (v_19_0 z)
 def s_21 (z : Store) : Store := storeSet (s_20 z) [(405, ((s_20 z) 402)), (588, ((s_20 z) 402)), (590, ((s_20 z) 402))]
 theorem t_20 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_245) (pmPeers pmNode_245) (s_20 z) pmNode_245 none = some (s_21 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_20
 theorem k_20 (z : Store) (tid : Tid) (h : tid ∉ [405, 588, 590]) : (s_21 z) tid = (s_20 z) tid := by
   unfold s_21
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_20
 theorem w_20_0 (z : Store) : (s_21 z) 405 = v_20_0 z := by
   unfold s_21
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_20_0, r_20_0 z] <;> rfl
 #a w_20_0
 theorem h_20_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_20_0 z).shape = [1, 8, 64] := by
   unfold v_20_0
   exact h_19_0 z z_
 #a h_20_0
 attribute [local irreducible] v_20_0
 theorem w_20_1 (z : Store) : (s_21 z) 588 = v_20_1 z := by
   unfold s_21
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_20_1, r_20_0 z] <;> rfl
 #a w_20_1
 theorem h_20_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_20_1 z).shape = [1, 8, 64] := by
   unfold v_20_1
   exact h_19_0 z z_
 #a h_20_1
 attribute [local irreducible] v_20_1
 theorem w_20_2 (z : Store) : (s_21 z) 590 = v_20_2 z := by
   unfold s_21
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_20_2, r_20_0 z] <;> rfl
 #a w_20_2
 theorem h_20_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_20_2 z).shape = [1, 8, 64] := by
   unfold v_20_2
   exact h_19_0 z z_
 #a h_20_2
 attribute [local irreducible] v_20_2
 attribute [local irreducible] s_21
 theorem r_21_0 (z : Store) : (s_21 z) 285 = (v_16_1 z) := pR (k_20 z) (pR (k_19 z) (pR (k_18 z) (pR (k_17 z) (w_16_1 z))))
 #a r_21_0
 theorem r_21_1 (z : Store) : (s_21 z) 588 = (v_20_1 z) := w_20_1 z
 #a r_21_1
 def v_21_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_16_1 z), (v_20_1 z)]
 def s_22 (z : Store) : Store := storeSet (s_21 z) [(86, allGatherPrimDimN 1 2 0 [((s_21 z) 285), ((s_21 z) 588)])]
 theorem t_21 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_11) (pmPeers pmNode_11) (s_21 z) pmNode_11 none = some (s_22 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_21 z) pmNode_11 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_21
 theorem k_21 (z : Store) (tid : Tid) (h : tid ∉ [86]) : (s_22 z) tid = (s_21 z) tid := by
   unfold s_22
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_21
 theorem w_21_0 (z : Store) : (s_22 z) 86 = v_21_0 z := by
   unfold s_22
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_21_0, r_21_0 z, r_21_1 z] <;> rfl
 #a w_21_0
 theorem h_21_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_21_0 z).shape = [1, 16, 64] := by
   unfold v_21_0
   exact allGatherPrimDimN_shape 1 2 [(v_16_1 z), (v_20_1 z)] [1, 8, 64] (h_16_1 z z_)
 #a h_21_0
 attribute [local irreducible] v_21_0
 attribute [local irreducible] s_22
 theorem n_16_20 (z : Store) (tid : Tid) (h : tid ∉ ([102, 285, 287, 103, 401, 402] : List Tid)) : (s_20 z) tid = (s_16 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_16 z) (k_17 z)) (pF _ _ _ _ _ (k_18 z) (k_19 z)) tid h
 #a n_16_20
 theorem r_22_0 (z : Store) : (s_22 z) 86 = (v_21_0 z) := w_21_0 z
 #a r_22_0
 theorem r_22_1 (z : Store) : (s_22 z) 27 = (z 27) := pR (k_21 z) (pR (k_20 z) (pR (n_16_20 z) (pR (n_0_16 z) (e_9 z))))
 #a r_22_1
 def v_22_0 (z : Store) : Tensor := fw_linear (v_21_0 z) (z 27)
 def s_23 (z : Store) : Store := storeSet (s_22 z) [(106, fw_linear ((s_22 z) 86) ((s_22 z) 27))]
 theorem t_22 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_12) (pmPeers pmNode_12) (s_22 z) pmNode_12 none = some (s_23 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_22
 theorem k_22 (z : Store) (tid : Tid) (h : tid ∉ [106]) : (s_23 z) tid = (s_22 z) tid := by
   unfold s_23
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_22
 theorem w_22_0 (z : Store) : (s_23 z) 106 = v_22_0 z := by
   unfold s_23
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_22_0, r_22_0 z, r_22_1 z] <;> rfl
 #a w_22_0
 theorem h_22_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_22_0 z).shape = [1, 16, 32] := by
   unfold v_22_0
   exact fw_linear_3d_shape 1 16 64 32 (v_21_0 z) (z 27) (h_21_0 z z_) (i_9 z z_)
 #a h_22_0
 attribute [local irreducible] v_22_0
 attribute [local irreducible] s_23
 theorem r_23_0 (z : Store) : (s_23 z) 287 = (v_16_2 z) := pR (k_22 z) (pR (k_21 z) (pR (k_20 z) (pR (k_19 z) (pR (k_18 z) (pR (k_17 z) (w_16_2 z))))))
 #a r_23_0
 theorem r_23_1 (z : Store) : (s_23 z) 590 = (v_20_2 z) := pR (k_22 z) (pR (k_21 z) (w_20_2 z))
 #a r_23_1
 def v_23_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_16_2 z), (v_20_2 z)]
 def s_24 (z : Store) : Store := storeSet (s_23 z) [(87, allGatherPrimDimN 1 2 0 [((s_23 z) 287), ((s_23 z) 590)])]
 theorem t_23 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_13) (pmPeers pmNode_13) (s_23 z) pmNode_13 none = some (s_24 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_23 z) pmNode_13 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_23
 theorem k_23 (z : Store) (tid : Tid) (h : tid ∉ [87]) : (s_24 z) tid = (s_23 z) tid := by
   unfold s_24
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_23
 theorem w_23_0 (z : Store) : (s_24 z) 87 = v_23_0 z := by
   unfold s_24
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_23_0, r_23_0 z, r_23_1 z] <;> rfl
 #a w_23_0
 theorem h_23_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_23_0 z).shape = [1, 16, 64] := by
   unfold v_23_0
   exact allGatherPrimDimN_shape 1 2 [(v_16_2 z), (v_20_2 z)] [1, 8, 64] (h_16_2 z z_)
 #a h_23_0
 attribute [local irreducible] v_23_0
 attribute [local irreducible] s_24
 theorem n_20_24 (z : Store) (tid : Tid) (h : tid ∉ ([405, 588, 590, 86, 106, 87] : List Tid)) : (s_24 z) tid = (s_20 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_20 z) (k_21 z)) (pF _ _ _ _ _ (k_22 z) (k_23 z)) tid h
 #a n_20_24
 theorem n_16_24 (z : Store) (tid : Tid) (h : tid ∉ ([102, 285, 287, 103, 401, 402, 405, 588, 590, 86, 106, 87] : List Tid)) : (s_24 z) tid = (s_16 z) tid := by
   exact pF _ _ _ _ _ (n_16_20 z) (n_20_24 z) tid h
 #a n_16_24
 theorem r_24_0 (z : Store) : (s_24 z) 87 = (v_23_0 z) := w_23_0 z
 #a r_24_0
 theorem r_24_1 (z : Store) : (s_24 z) 30 = (z 30) := pR (n_16_24 z) (pR (n_0_16 z) (e_10 z))
 #a r_24_1
 def v_24_0 (z : Store) : Tensor := fw_linear (v_23_0 z) (z 30)
 def s_25 (z : Store) : Store := storeSet (s_24 z) [(109, fw_linear ((s_24 z) 87) ((s_24 z) 30))]
 theorem t_24 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_14) (pmPeers pmNode_14) (s_24 z) pmNode_14 none = some (s_25 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_24
 theorem k_24 (z : Store) (tid : Tid) (h : tid ∉ [109]) : (s_25 z) tid = (s_24 z) tid := by
   unfold s_25
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_24
 theorem w_24_0 (z : Store) : (s_25 z) 109 = v_24_0 z := by
   unfold s_25
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_24_0, r_24_0 z, r_24_1 z] <;> rfl
 #a w_24_0
 theorem h_24_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_24_0 z).shape = [1, 16, 32] := by
   unfold v_24_0
   exact fw_linear_3d_shape 1 16 64 32 (v_23_0 z) (z 30) (h_23_0 z z_) (i_10 z z_)
 #a h_24_0
 attribute [local irreducible] v_24_0
 attribute [local irreducible] s_25
 record_prefix_opacity v_17_0 s_18 v_18_0 s_19 v_19_0 s_20 v_20_0 v_20_1 v_20_2 s_21 v_21_0 s_22 v_22_0 s_23 v_23_0 s_24 v_24_0 s_25

 end
 end TrainVerify.Denote.RuntimeWorld
