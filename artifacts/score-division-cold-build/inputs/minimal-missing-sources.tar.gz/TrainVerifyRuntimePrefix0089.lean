import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0088
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_704_0 (z : Store) : (s_704 z) 826 = (v_700_0 z) := pR (k_703 z) (pR (k_702 z) (pR (k_701 z) (w_700_0 z)))
 #a r_704_0
 theorem r_704_1 (z : Store) : (s_704 z) 1129 = (v_703_0 z) := w_703_0 z
 #a r_704_1
 def v_704_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_700_0 z), (v_703_0 z)]
 theorem g_704 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_613) (s_704 z) pmNode_613 1 2 823 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_613, r_704_0 z, r_704_1 z, h_700_0 z z_, h_703_0 z z_]
 #a g_704
 def s_705 (z : Store) : Store := pL [2, 3] (s_704 z) pmNode_613 1 2
 theorem t_704 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_613) (pmPeers pmNode_613) (s_704 z) pmNode_613 none = some (s_705 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_613) (s_704 z) pmNode_613).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 823 (by decide) (g_704 z z_)]
   rfl
 #a t_704
 theorem k_704 (z : Store) (tid : Tid) (h : tid ∉ [823]) : (s_705 z) tid = (s_704 z) tid := by
   unfold s_705
   dsimp only [pL, pmNode_613, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_704
 theorem w_704_0 (z : Store) : (s_705 z) 823 = v_704_0 z := by
   unfold s_705
   dsimp only [pL, pmNode_613, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_704_0, r_704_0 z, r_704_1 z] <;> rfl
 #a w_704_0
 theorem h_704_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_704_0 z).shape = [1, 16, 2, 16] := by
   unfold v_704_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_700_0 z z_]
 #a h_704_0
 attribute [local irreducible] v_704_0
 attribute [local irreducible] s_705
 theorem n_700_704 (z : Store) (tid : Tid) (h : tid ∉ ([826, 1132, 1122, 1129] : List Tid)) : (s_704 z) tid = (s_700 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_700 z) (k_701 z)) (pF _ _ _ _ _ (k_702 z) (k_703 z)) tid h
 #a n_700_704
 theorem n_696_704 (z : Store) (tid : Tid) (h : tid ∉ ([1136, 1114, 1135, 829, 819, 826, 1132, 1122, 1129] : List Tid)) : (s_704 z) tid = (s_696 z) tid := by
   exact pF _ _ _ _ _ (n_696_700 z) (n_700_704 z) tid h
 #a n_696_704
 theorem n_688_704 (z : Store) (tid : Tid) (h : tid ∉ ([1130, 1143, 837, 836, 1140, 1139, 833, 811, 832, 1136, 1114, 1135, 829, 819, 826, 1132, 1122, 1129] : List Tid)) : (s_704 z) tid = (s_688 z) tid := by
   exact pF _ _ _ _ _ (n_688_696 z) (n_696_704 z) tid h
 #a n_688_704
 theorem n_672_704 (z : Store) (tid : Tid) (h : tid ∉ ([1159, 966, 1158, 852, 851, 1155, 1154, 848, 847, 1151, 1150, 843, 841, 844, 1147, 1144, 1146, 827, 840, 1130, 1143, 837, 836, 1140, 1139, 833, 811, 832, 1136, 1114, 1135, 829, 819, 826, 1132, 1122, 1129] : List Tid)) : (s_704 z) tid = (s_672 z) tid := by
   exact pF _ _ _ _ _ (n_672_688 z) (n_688_704 z) tid h
 #a n_672_704
 theorem n_640_704 (z : Store) (tid : Tid) (h : tid ∉ ([1188, 1187, 982, 882, 880, 674, 676, 879, 876, 1185, 1183, 977, 979, 1182, 1179, 908, 874, 672, 873, 1211, 1177, 975, 1176, 691, 870, 670, 994, 1173, 973, 867, 866, 665, 667, 1170, 1169, 968, 970, 906, 863, 861, 862, 1209, 1166, 1164, 1165, 690, 856, 663, 855, 993, 1159, 966, 1158, 852, 851, 1155, 1154, 848, 847, 1151, 1150, 843, 841, 844, 1147, 1144, 1146, 827, 840, 1130, 1143, 837, 836, 1140, 1139, 833, 811, 832, 1136, 1114, 1135, 829, 819, 826, 1132, 1122, 1129] : List Tid)) : (s_704 z) tid = (s_640 z) tid := by
   exact pF _ _ _ _ _ (n_640_672 z) (n_672_704 z) tid h
 #a n_640_704
 theorem r_705_0 (z : Store) : (s_705 z) 823 = (v_704_0 z) := w_704_0 z
 #a r_705_0
 theorem r_705_1 (z : Store) : (s_705 z) 820 = (v_558_0 z) := pR (k_704 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_560_576 z) (pR (k_559 z) (r_559_0 z)))))
 #a r_705_1
 def v_705_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_704_0 z)
 def s_706 (z : Store) : Store := storeSet (s_705 z) [(822, fw_view [1, 16, 32] ((s_705 z) 823))]
 theorem t_705 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_614) (pmPeers pmNode_614) (s_705 z) pmNode_614 none = some (s_706 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_705
 theorem k_705 (z : Store) (tid : Tid) (h : tid ∉ [822]) : (s_706 z) tid = (s_705 z) tid := by
   unfold s_706
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_705
 theorem w_705_0 (z : Store) : (s_706 z) 822 = v_705_0 z := by
   unfold s_706
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_705_0, r_705_0 z, r_705_1 z] <;> rfl
 #a w_705_0
 theorem h_705_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_705_0 z).shape = [1, 16, 32] := by
   unfold v_705_0
   rfl
 #a h_705_0
 attribute [local irreducible] v_705_0
 attribute [local irreducible] s_706
 theorem r_706_0 (z : Store) : (s_706 z) 826 = (v_700_0 z) := pR (k_705 z) (pR (k_704 z) (r_704_0 z))
 #a r_706_0
 theorem r_706_1 (z : Store) : (s_706 z) 1129 = (v_703_0 z) := pR (k_705 z) (pR (k_704 z) (r_704_1 z))
 #a r_706_1
 def v_706_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_700_0 z), (v_703_0 z)]
 theorem g_706 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_849) (s_706 z) pmNode_849 1 2 1126 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_849, r_706_0 z, r_706_1 z, h_700_0 z z_, h_703_0 z z_]
 #a g_706
 def s_707 (z : Store) : Store := pL [2, 3] (s_706 z) pmNode_849 1 2
 theorem t_706 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_849) (pmPeers pmNode_849) (s_706 z) pmNode_849 none = some (s_707 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_849) (s_706 z) pmNode_849).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1126 (by decide) (g_706 z z_)]
   rfl
 #a t_706
 theorem k_706 (z : Store) (tid : Tid) (h : tid ∉ [1126]) : (s_707 z) tid = (s_706 z) tid := by
   unfold s_707
   dsimp only [pL, pmNode_849, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_706
 theorem w_706_0 (z : Store) : (s_707 z) 1126 = v_706_0 z := by
   unfold s_707
   dsimp only [pL, pmNode_849, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_706_0, r_706_0 z, r_706_1 z] <;> rfl
 #a w_706_0
 theorem h_706_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_706_0 z).shape = [1, 16, 2, 16] := by
   unfold v_706_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_700_0 z z_]
 #a h_706_0
 attribute [local irreducible] v_706_0
 attribute [local irreducible] s_707
 theorem r_707_0 (z : Store) : (s_707 z) 1126 = (v_706_0 z) := w_706_0 z
 #a r_707_0
 theorem r_707_1 (z : Store) : (s_707 z) 1123 = (v_562_0 z) := pR (k_706 z) (pR (k_705 z) (pR (k_704 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_568_576 z) (pR (n_564_568 z) (pR (k_563 z) (r_563_0 z))))))))
 #a r_707_1
 def v_707_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_706_0 z)
 def s_708 (z : Store) : Store := storeSet (s_707 z) [(1125, fw_view [1, 16, 32] ((s_707 z) 1126))]
 theorem t_707 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_850) (pmPeers pmNode_850) (s_707 z) pmNode_850 none = some (s_708 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_707
 theorem k_707 (z : Store) (tid : Tid) (h : tid ∉ [1125]) : (s_708 z) tid = (s_707 z) tid := by
   unfold s_708
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_707
 theorem w_707_0 (z : Store) : (s_708 z) 1125 = v_707_0 z := by
   unfold s_708
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_707_0, r_707_0 z, r_707_1 z] <;> rfl
 #a w_707_0
 theorem h_707_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_707_0 z).shape = [1, 16, 32] := by
   unfold v_707_0
   rfl
 #a h_707_0
 attribute [local irreducible] v_707_0
 attribute [local irreducible] s_708
 theorem r_708_0 (z : Store) : (s_708 z) 822 = (v_705_0 z) := pR (k_707 z) (pR (k_706 z) (w_705_0 z))
 #a r_708_0
 theorem r_708_1 (z : Store) : (s_708 z) 1125 = (v_707_0 z) := w_707_0 z
 #a r_708_1
 def v_708_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 0 [(v_705_0 z), (v_707_0 z)]
 def s_709 (z : Store) : Store := storeSet (s_708 z) [(689, allGatherPrimDimN 2 2 0 [((s_708 z) 822), ((s_708 z) 1125)])]
 theorem t_708 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_615) (pmPeers pmNode_615) (s_708 z) pmNode_615 none = some (s_709 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_708 z) pmNode_615 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_708
 theorem k_708 (z : Store) (tid : Tid) (h : tid ∉ [689]) : (s_709 z) tid = (s_708 z) tid := by
   unfold s_709
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_708
 theorem w_708_0 (z : Store) : (s_709 z) 689 = v_708_0 z := by
   unfold s_709
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_708_0, r_708_0 z, r_708_1 z] <;> rfl
 #a w_708_0
 theorem h_708_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_708_0 z).shape = [1, 16, 64] := by
   unfold v_708_0
   exact allGatherPrimDimN_shape 2 2 [(v_705_0 z), (v_707_0 z)] [1, 16, 32] (h_705_0 z z_)
 #a h_708_0
 attribute [local irreducible] v_708_0
 attribute [local irreducible] s_709
 theorem n_704_708 (z : Store) (tid : Tid) (h : tid ∉ ([823, 822, 1126, 1125] : List Tid)) : (s_708 z) tid = (s_704 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_704 z) (k_705 z)) (pF _ _ _ _ _ (k_706 z) (k_707 z)) tid h
 #a n_704_708
 theorem r_709_0 (z : Store) : (s_709 z) 819 = (v_699_0 z) := pR (k_708 z) (pR (n_704_708 z) (pR (n_700_704 z) (w_699_0 z)))
 #a r_709_0
 theorem r_709_1 (z : Store) : (s_709 z) 816 = (v_556_0 z) := pR (k_708 z) (pR (n_704_708 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_560_576 z) (pR (k_559 z) (pR (k_558 z) (pR (k_557 z) (r_557_0 z))))))))
 #a r_709_1
 def v_709_0 (z : Store) : Tensor := transposeAxes 1 2 (v_699_0 z)
 def s_710 (z : Store) : Store := storeSet (s_709 z) [(818, transposeAxes 1 2 ((s_709 z) 819))]
 theorem t_709 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_616) (pmPeers pmNode_616) (s_709 z) pmNode_616 none = some (s_710 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_709
 theorem k_709 (z : Store) (tid : Tid) (h : tid ∉ [818]) : (s_710 z) tid = (s_709 z) tid := by
   unfold s_710
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_709
 theorem w_709_0 (z : Store) : (s_710 z) 818 = v_709_0 z := by
   unfold s_710
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_709_0, r_709_0 z, r_709_1 z] <;> rfl
 #a w_709_0
 theorem h_709_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_709_0 z).shape = [1, 16, 4, 8] := by
   unfold v_709_0
   change listSwapAt _ _ _ = _
   rw [h_699_0 z z_]
   rfl
 #a h_709_0
 attribute [local irreducible] v_709_0
 attribute [local irreducible] s_710
 theorem r_710_0 (z : Store) : (s_710 z) 822 = (v_705_0 z) := pR (k_709 z) (pR (k_708 z) (r_708_0 z))
 #a r_710_0
 theorem r_710_1 (z : Store) : (s_710 z) 1125 = (v_707_0 z) := pR (k_709 z) (pR (k_708 z) (r_708_1 z))
 #a r_710_1
 def v_710_0 (z : Store) : Tensor := allGatherPrimDimN 2 2 1 [(v_705_0 z), (v_707_0 z)]
 def s_711 (z : Store) : Store := storeSet (s_710 z) [(992, allGatherPrimDimN 2 2 1 [((s_710 z) 822), ((s_710 z) 1125)])]
 theorem t_710 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_851) (pmPeers pmNode_851) (s_710 z) pmNode_851 none = some (s_711 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_710 z) pmNode_851 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_710
 theorem k_710 (z : Store) (tid : Tid) (h : tid ∉ [992]) : (s_711 z) tid = (s_710 z) tid := by
   unfold s_711
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_710
 theorem w_710_0 (z : Store) : (s_711 z) 992 = v_710_0 z := by
   unfold s_711
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_710_0, r_710_0 z, r_710_1 z] <;> rfl
 #a w_710_0
 theorem h_710_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_710_0 z).shape = [1, 16, 64] := by
   unfold v_710_0
   exact allGatherPrimDimN_shape 2 2 [(v_705_0 z), (v_707_0 z)] [1, 16, 32] (h_705_0 z z_)
 #a h_710_0
 attribute [local irreducible] v_710_0
 attribute [local irreducible] s_711
 theorem r_711_0 (z : Store) : (s_711 z) 1122 = (v_702_0 z) := pR (k_710 z) (pR (k_709 z) (pR (k_708 z) (pR (n_704_708 z) (pR (k_703 z) (w_702_0 z)))))
 #a r_711_0
 theorem r_711_1 (z : Store) : (s_711 z) 1119 = (v_560_0 z) := pR (k_710 z) (pR (k_709 z) (pR (k_708 z) (pR (n_704_708 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_568_576 z) (pR (n_564_568 z) (pR (k_563 z) (pR (k_562 z) (pR (k_561 z) (r_561_0 z)))))))))))
 #a r_711_1
 def v_711_0 (z : Store) : Tensor := transposeAxes 1 2 (v_702_0 z)
 def s_712 (z : Store) : Store := storeSet (s_711 z) [(1121, transposeAxes 1 2 ((s_711 z) 1122))]
 theorem t_711 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_852) (pmPeers pmNode_852) (s_711 z) pmNode_852 none = some (s_712 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_711
 theorem k_711 (z : Store) (tid : Tid) (h : tid ∉ [1121]) : (s_712 z) tid = (s_711 z) tid := by
   unfold s_712
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_711
 theorem w_711_0 (z : Store) : (s_712 z) 1121 = v_711_0 z := by
   unfold s_712
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_711_0, r_711_0 z, r_711_1 z] <;> rfl
 #a w_711_0
 theorem h_711_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_711_0 z).shape = [1, 16, 4, 8] := by
   unfold v_711_0
   change listSwapAt _ _ _ = _
   rw [h_702_0 z z_]
   rfl
 #a h_711_0
 attribute [local irreducible] v_711_0
 attribute [local irreducible] s_712
 record_prefix_opacity v_704_0 s_705 v_705_0 s_706 v_706_0 s_707 v_707_0 s_708 v_708_0 s_709 v_709_0 s_710 v_710_0 s_711 v_711_0 s_712

 end
 end TrainVerify.Denote.RuntimeWorld
