import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0041
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_324_0 (z : Store) : (s_324 z) 595 = (v_323_0 z) := w_323_0 z
 #a r_324_0
 theorem r_324_1 (z : Store) : (s_324 z) 558 = (v_245_0 z) := pR (n_320_324 z) (pR (n_256_320 z) (pR (n_248_256 z) (pR (k_247 z) (pR (k_246 z) (w_245_0 z)))))
 #a r_324_1
 def v_324_0 (z : Store) : Tensor := tensorSum [(v_323_0 z), (v_245_0 z)]
 def s_325 (z : Store) : Store := storeSet (s_324 z) [(487, tensorSum [((s_324 z) 595), ((s_324 z) 558)])]
 theorem t_324 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_397) (pmPeers pmNode_397) (s_324 z) pmNode_397 none = some (s_325 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_324
 theorem k_324 (z : Store) (tid : Tid) (h : tid ∉ [487]) : (s_325 z) tid = (s_324 z) tid := by
   unfold s_325
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_324
 theorem w_324_0 (z : Store) : (s_325 z) 487 = v_324_0 z := by
   unfold s_325
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_324_0, r_324_0 z, r_324_1 z] <;> rfl
 #a w_324_0
 theorem h_324_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_324_0 z).shape = [1, 16, 32] := by
   unfold v_324_0
   rw [tensorSum_shape]
   exact h_323_0 z z_
 #a h_324_0
 attribute [local irreducible] v_324_0
 attribute [local irreducible] s_325
 theorem r_325_0 (z : Store) : (s_325 z) 487 = (v_324_0 z) := w_324_0 z
 #a r_325_0
 theorem r_325_1 (z : Store) : (s_325 z) 482 = (v_87_1 z) := pR (k_324 z) (pR (n_320_324 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_104_112 z) (pR (k_103 z) (pR (k_102 z) (r_102_0 z))))))))
 #a r_325_1
 theorem r_325_2 (z : Store) : (s_325 z) 483 = (v_101_0 z) := pR (k_324 z) (pR (n_320_324 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_112_128 z) (pR (n_104_112 z) (pR (k_103 z) (pR (k_102 z) (r_102_1 z))))))))
 #a r_325_2
 def v_325_0 (z : Store) : Tensor := (bw_add2 (v_324_0 z) (v_87_1 z) (v_101_0 z)).1
 def v_325_1 (z : Store) : Tensor := (bw_add2 (v_324_0 z) (v_87_1 z) (v_101_0 z)).2
 def s_326 (z : Store) : Store := storeSet (s_325 z) [(485, (bw_add2 ((s_325 z) 487) ((s_325 z) 482) ((s_325 z) 483)).1), (486, (bw_add2 ((s_325 z) 487) ((s_325 z) 482) ((s_325 z) 483)).2)]
 theorem t_325 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_398) (pmPeers pmNode_398) (s_325 z) pmNode_398 none = some (s_326 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_325
 theorem k_325 (z : Store) (tid : Tid) (h : tid ∉ [485, 486]) : (s_326 z) tid = (s_325 z) tid := by
   unfold s_326
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_325
 theorem w_325_0 (z : Store) : (s_326 z) 485 = v_325_0 z := by
   unfold s_326
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_325_0, r_325_0 z, r_325_1 z, r_325_2 z] <;> rfl
 #a w_325_0
 theorem h_325_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_325_0 z).shape = [1, 16, 32] := by
   unfold v_325_0
   exact h_87_1 z z_
 #a h_325_0
 attribute [local irreducible] v_325_0
 theorem w_325_1 (z : Store) : (s_326 z) 486 = v_325_1 z := by
   unfold s_326
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_325_1, r_325_0 z, r_325_1 z, r_325_2 z] <;> rfl
 #a w_325_1
 theorem h_325_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_325_1 z).shape = [1, 16, 32] := by
   unfold v_325_1
   exact h_101_0 z z_
 #a h_325_1
 attribute [local irreducible] v_325_1
 attribute [local irreducible] s_326
 theorem r_326_0 (z : Store) : (s_326 z) 183 = (v_322_1 z) := pR (k_325 z) (pR (k_324 z) (pR (k_323 z) (w_322_1 z)))
 #a r_326_0
 theorem r_326_1 (z : Store) : (s_326 z) 486 = (v_325_1 z) := w_325_1 z
 #a r_326_1
 def v_326_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_322_1 z), (v_325_1 z)]
 theorem g_326 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_163) (s_326 z) pmNode_163 2 1 178 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_163, r_326_0 z, r_326_1 z, h_322_1 z z_, h_325_1 z z_]
 #a g_326
 def s_327 (z : Store) : Store := pL [0, 1] (s_326 z) pmNode_163 2 1
 theorem t_326 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_163) (pmPeers pmNode_163) (s_326 z) pmNode_163 none = some (s_327 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_163) (s_326 z) pmNode_163).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 178 (by decide) (g_326 z z_)]
   rfl
 #a t_326
 theorem k_326 (z : Store) (tid : Tid) (h : tid ∉ [178]) : (s_327 z) tid = (s_326 z) tid := by
   unfold s_327
   dsimp only [pL, pmNode_163, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_326
 theorem w_326_0 (z : Store) : (s_327 z) 178 = v_326_0 z := by
   unfold s_327
   dsimp only [pL, pmNode_163, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_326_0, r_326_0 z, r_326_1 z] <;> rfl
 #a w_326_0
 theorem h_326_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_326_0 z).shape = [1, 8, 64] := by
   unfold v_326_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_322_1 z z_]
 #a h_326_0
 attribute [local irreducible] v_326_0
 attribute [local irreducible] s_327
 theorem r_327_0 (z : Store) : (s_327 z) 178 = (v_326_0 z) := w_326_0 z
 #a r_327_0
 theorem r_327_1 (z : Store) : (s_327 z) 175 = (v_91_0 z) := pR (k_326 z) (pR (k_325 z) (pR (k_324 z) (pR (n_320_324 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_92_96 z) (r_92_0 z))))))))
 #a r_327_1
 theorem r_327_2 (z : Store) : (s_327 z) 8 = (z 8) := pR (k_326 z) (pR (k_325 z) (pR (k_324 z) (pR (n_320_324 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_92_96 z) (r_92_1 z))))))))
 #a r_327_2
 def v_327_0 (z : Store) : Tensor := (bw_linear (v_326_0 z) (v_91_0 z) (z 8)).1
 def v_327_1 (z : Store) : Tensor := (bw_linear (v_326_0 z) (v_91_0 z) (z 8)).2
 def s_328 (z : Store) : Store := storeSet (s_327 z) [(176, (bw_linear ((s_327 z) 178) ((s_327 z) 175) ((s_327 z) 8)).1), (41, (bw_linear ((s_327 z) 178) ((s_327 z) 175) ((s_327 z) 8)).2)]
 theorem t_327 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_164) (pmPeers pmNode_164) (s_327 z) pmNode_164 none = some (s_328 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_327
 theorem k_327 (z : Store) (tid : Tid) (h : tid ∉ [176, 41]) : (s_328 z) tid = (s_327 z) tid := by
   unfold s_328
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_327
 theorem w_327_0 (z : Store) : (s_328 z) 176 = v_327_0 z := by
   unfold s_328
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_327_0, r_327_0 z, r_327_1 z, r_327_2 z] <;> rfl
 #a w_327_0
 theorem h_327_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_327_0 z).shape = [1, 8, 256] := by
   unfold v_327_0
   exact bw_linear_3d_fst_shape 1 8 64 256 (v_326_0 z) (v_91_0 z) (z 8) (h_326_0 z z_) (h_91_0 z z_) (i_19 z z_)
 #a h_327_0
 attribute [local irreducible] v_327_0
 theorem w_327_1 (z : Store) : (s_328 z) 41 = v_327_1 z := by
   unfold s_328
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_327_1, r_327_0 z, r_327_1 z, r_327_2 z] <;> rfl
 #a w_327_1
 theorem h_327_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_327_1 z).shape = [64, 256] := by
   unfold v_327_1
   exact bw_linear_3d_snd_shape 1 8 64 256 (v_326_0 z) (v_91_0 z) (z 8) (h_326_0 z z_) (h_91_0 z z_) (i_19 z z_)
 #a h_327_1
 attribute [local irreducible] v_327_1
 attribute [local irreducible] s_328
 theorem n_324_328 (z : Store) (tid : Tid) (h : tid ∉ ([487, 485, 486, 178, 176, 41] : List Tid)) : (s_328 z) tid = (s_324 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_324 z) (k_325 z)) (pF _ _ _ _ _ (k_326 z) (k_327 z)) tid h
 #a n_324_328
 theorem n_320_328 (z : Store) (tid : Tid) (h : tid ∉ ([292, 184, 182, 183, 595, 487, 485, 486, 178, 176, 41] : List Tid)) : (s_328 z) tid = (s_320 z) tid := by
   exact pF _ _ _ _ _ (n_320_324 z) (n_324_328 z) tid h
 #a n_320_328
 theorem r_328_0 (z : Store) : (s_328 z) 176 = (v_327_0 z) := w_327_0 z
 #a r_328_0
 theorem r_328_1 (z : Store) : (s_328 z) 173 = (v_90_0 z) := pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_92_96 z) (pR (k_91 z) (r_91_0 z))))))
 #a r_328_1
 def v_328_0 (z : Store) : Tensor := bw_gelu (v_327_0 z) (v_90_0 z)
 def s_329 (z : Store) : Store := storeSet (s_328 z) [(174, bw_gelu ((s_328 z) 176) ((s_328 z) 173))]
 theorem t_328 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_165) (pmPeers pmNode_165) (s_328 z) pmNode_165 none = some (s_329 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_328
 theorem k_328 (z : Store) (tid : Tid) (h : tid ∉ [174]) : (s_329 z) tid = (s_328 z) tid := by
   unfold s_329
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_328
 theorem w_328_0 (z : Store) : (s_329 z) 174 = v_328_0 z := by
   unfold s_329
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_328_0, r_328_0 z, r_328_1 z] <;> rfl
 #a w_328_0
 theorem h_328_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_328_0 z).shape = [1, 8, 256] := by
   unfold v_328_0
   exact h_90_0 z z_
 #a h_328_0
 attribute [local irreducible] v_328_0
 attribute [local irreducible] s_329
 theorem r_329_0 (z : Store) : (s_329 z) 174 = (v_328_0 z) := w_328_0 z
 #a r_329_0
 theorem r_329_1 (z : Store) : (s_329 z) 170 = (v_89_0 z) := pR (k_328 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_92_96 z) (pR (k_91 z) (pR (k_90 z) (r_90_0 z))))))))
 #a r_329_1
 theorem r_329_2 (z : Store) : (s_329 z) 7 = (z 7) := pR (k_328 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_92_96 z) (pR (k_91 z) (pR (k_90 z) (r_90_1 z))))))))
 #a r_329_2
 def v_329_0 (z : Store) : Tensor := (bw_linear (v_328_0 z) (v_89_0 z) (z 7)).1
 def v_329_1 (z : Store) : Tensor := (bw_linear (v_328_0 z) (v_89_0 z) (z 7)).2
 def s_330 (z : Store) : Store := storeSet (s_329 z) [(172, (bw_linear ((s_329 z) 174) ((s_329 z) 170) ((s_329 z) 7)).1), (39, (bw_linear ((s_329 z) 174) ((s_329 z) 170) ((s_329 z) 7)).2)]
 theorem t_329 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_166) (pmPeers pmNode_166) (s_329 z) pmNode_166 none = some (s_330 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_329
 theorem k_329 (z : Store) (tid : Tid) (h : tid ∉ [172, 39]) : (s_330 z) tid = (s_329 z) tid := by
   unfold s_330
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_329
 theorem w_329_0 (z : Store) : (s_330 z) 172 = v_329_0 z := by
   unfold s_330
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_329_0, r_329_0 z, r_329_1 z, r_329_2 z] <;> rfl
 #a w_329_0
 theorem h_329_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_329_0 z).shape = [1, 8, 64] := by
   unfold v_329_0
   exact bw_linear_3d_fst_shape 1 8 256 64 (v_328_0 z) (v_89_0 z) (z 7) (h_328_0 z z_) (h_89_0 z z_) (i_18 z z_)
 #a h_329_0
 attribute [local irreducible] v_329_0
 theorem w_329_1 (z : Store) : (s_330 z) 39 = v_329_1 z := by
   unfold s_330
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_329_1, r_329_0 z, r_329_1 z, r_329_2 z] <;> rfl
 #a w_329_1
 theorem h_329_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_329_1 z).shape = [256, 64] := by
   unfold v_329_1
   exact bw_linear_3d_snd_shape 1 8 256 64 (v_328_0 z) (v_89_0 z) (z 7) (h_328_0 z z_) (h_89_0 z z_) (i_18 z z_)
 #a h_329_1
 attribute [local irreducible] v_329_1
 attribute [local irreducible] s_330
 theorem r_330_0 (z : Store) : (s_330 z) 172 = (v_329_0 z) := w_329_0 z
 #a r_330_0
 theorem r_330_1 (z : Store) : (s_330 z) 169 = (v_88_0 z) := pR (k_329 z) (pR (k_328 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_92_96 z) (pR (k_91 z) (pR (k_90 z) (pR (k_89 z) (r_89_0 z))))))))))
 #a r_330_1
 theorem r_330_2 (z : Store) : (s_330 z) 5 = (z 5) := pR (k_329 z) (pR (k_328 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_92_96 z) (pR (k_91 z) (pR (k_90 z) (pR (k_89 z) (r_89_1 z))))))))))
 #a r_330_2
 theorem r_330_3 (z : Store) : (s_330 z) 6 = (z 6) := pR (k_329 z) (pR (k_328 z) (pR (n_320_328 z) (pR (n_256_320 z) (pR (n_128_256 z) (pR (n_96_128 z) (pR (n_92_96 z) (pR (k_91 z) (pR (k_90 z) (pR (k_89 z) (r_89_2 z))))))))))
 #a r_330_3
 def v_330_0 (z : Store) : Tensor := (bw_layernorm (v_329_0 z) (v_88_0 z) (z 5) (z 6)).1
 def v_330_1 (z : Store) : Tensor := (bw_layernorm (v_329_0 z) (v_88_0 z) (z 5) (z 6)).2.1
 def v_330_2 (z : Store) : Tensor := (bw_layernorm (v_329_0 z) (v_88_0 z) (z 5) (z 6)).2.2
 def s_331 (z : Store) : Store := storeSet (s_330 z) [(171, (bw_layernorm ((s_330 z) 172) ((s_330 z) 169) ((s_330 z) 5) ((s_330 z) 6)).1), (35, (bw_layernorm ((s_330 z) 172) ((s_330 z) 169) ((s_330 z) 5) ((s_330 z) 6)).2.1), (37, (bw_layernorm ((s_330 z) 172) ((s_330 z) 169) ((s_330 z) 5) ((s_330 z) 6)).2.2)]
 theorem t_330 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_167) (pmPeers pmNode_167) (s_330 z) pmNode_167 none = some (s_331 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_330
 theorem k_330 (z : Store) (tid : Tid) (h : tid ∉ [171, 35, 37]) : (s_331 z) tid = (s_330 z) tid := by
   unfold s_331
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_330
 theorem w_330_0 (z : Store) : (s_331 z) 171 = v_330_0 z := by
   unfold s_331
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_330_0, r_330_0 z, r_330_1 z, r_330_2 z, r_330_3 z] <;> rfl
 #a w_330_0
 theorem h_330_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_330_0 z).shape = [1, 8, 64] := by
   unfold v_330_0
   rw [bw_layernorm_dx_shape (v_329_0 z) (v_88_0 z) (z 5) (z 6) 64 [8, 1] (by rw [h_88_0 z z_]; rfl)]
   exact h_88_0 z z_
 #a h_330_0
 attribute [local irreducible] v_330_0
 theorem w_330_1 (z : Store) : (s_331 z) 35 = v_330_1 z := by
   unfold s_331
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_330_1, r_330_0 z, r_330_1 z, r_330_2 z, r_330_3 z] <;> rfl
 #a w_330_1
 theorem h_330_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_330_1 z).shape = [64] := by
   unfold v_330_1
   rw [bw_layernorm_dw_shape (v_329_0 z) (v_88_0 z) (z 5) (z 6) 64 [8, 1] (by rw [h_88_0 z z_]; rfl)]
   exact i_16 z z_
 #a h_330_1
 attribute [local irreducible] v_330_1
 theorem w_330_2 (z : Store) : (s_331 z) 37 = v_330_2 z := by
   unfold s_331
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_330_2, r_330_0 z, r_330_1 z, r_330_2 z, r_330_3 z] <;> rfl
 #a w_330_2
 theorem h_330_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_330_2 z).shape = [64] := by
   unfold v_330_2
   rw [bw_layernorm_db_shape (v_329_0 z) (v_88_0 z) (z 5) (z 6) 64 [8, 1] (by rw [h_88_0 z z_]; rfl)]
   exact i_17 z z_
 #a h_330_2
 attribute [local irreducible] v_330_2
 attribute [local irreducible] s_331
 record_prefix_opacity v_324_0 s_325 v_325_0 v_325_1 s_326 v_326_0 s_327 v_327_0 v_327_1 s_328 v_328_0 s_329 v_329_0 v_329_1 s_330 v_330_0 v_330_1 v_330_2 s_331

 end
 end TrainVerify.Denote.RuntimeWorld
