import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0124
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
open SourceScopedEval
set_option maxHeartbeats 500000
set_option maxRecDepth 4096
restore_prefix_opacity
theorem smSeededWholeFold (rows : List InputRequest)
    (h : ∀ row ∈ rows, ∀ s, (fun row s => stepWithInputs smGraph (smScope row.1) (smPeers row.1) s row.1 row.2) row s = some (smSeededWholeAdvance s row)) (s : Store) :
    runUsing (fun row s => stepWithInputs smGraph (smScope row.1) (smPeers row.1) s row.1 row.2) rows (some s) = some (rows.foldl smSeededWholeAdvance s) := by
  induction rows generalizing s with
  | nil => rfl
  | cons row rest ih =>
    change runUsing (fun row s => stepWithInputs smGraph (smScope row.1) (smPeers row.1) s row.1 row.2) rest ((fun row s => stepWithInputs smGraph (smScope row.1) (smPeers row.1) s row.1 row.2) row s) = _
    rw [h row (List.mem_cons_self ..) s]
    exact ih (fun next hn => h next (List.mem_cons_of_mem _ hn)) _
#print axioms smSeededWholeFold

theorem smSeededWholeStep_0 (s : Store) : stepWithInputs smGraph (smScope smNode_0) (smPeers smNode_0) s smNode_0 (some smNode_0_feed) =
    some (smSeededWholeAdvance s (smNode_0, some smNode_0_feed)) := smNode_0_scoped_step s
#print axioms smSeededWholeStep_0

theorem smSeededWholeStep_1 (s : Store) : stepWithInputs smGraph (smScope smNode_1) (smPeers smNode_1) s smNode_1 (none) =
    some (smSeededWholeAdvance s (smNode_1, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_1

theorem smSeededWholeStep_2 (s : Store) : stepWithInputs smGraph (smScope smNode_2) (smPeers smNode_2) s smNode_2 (none) =
    some (smSeededWholeAdvance s (smNode_2, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_2

theorem smSeededWholeStep_3 (s : Store) : stepWithInputs smGraph (smScope smNode_3) (smPeers smNode_3) s smNode_3 (none) =
    some (smSeededWholeAdvance s (smNode_3, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_3

theorem smSeededWholeStep_4 (s : Store) : stepWithInputs smGraph (smScope smNode_4) (smPeers smNode_4) s smNode_4 (none) =
    some (smSeededWholeAdvance s (smNode_4, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_4

theorem smSeededWholeStep_5 (s : Store) : stepWithInputs smGraph (smScope smNode_5) (smPeers smNode_5) s smNode_5 (none) =
    some (smSeededWholeAdvance s (smNode_5, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_5

theorem smSeededWholeStep_6 (s : Store) : stepWithInputs smGraph (smScope smNode_6) (smPeers smNode_6) s smNode_6 (none) =
    some (smSeededWholeAdvance s (smNode_6, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_6

theorem smSeededWholeStep_7 (s : Store) : stepWithInputs smGraph (smScope smNode_7) (smPeers smNode_7) s smNode_7 (none) =
    some (smSeededWholeAdvance s (smNode_7, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_7

theorem smSeededWholeStep_8 (s : Store) : stepWithInputs smGraph (smScope smNode_8) (smPeers smNode_8) s smNode_8 (none) =
    some (smSeededWholeAdvance s (smNode_8, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_8

theorem smSeededWholeStep_9 (s : Store) : stepWithInputs smGraph (smScope smNode_9) (smPeers smNode_9) s smNode_9 (none) =
    some (smSeededWholeAdvance s (smNode_9, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_9

theorem smSeededWholeStep_10 (s : Store) : stepWithInputs smGraph (smScope smNode_10) (smPeers smNode_10) s smNode_10 (none) =
    some (smSeededWholeAdvance s (smNode_10, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_10

theorem smSeededWholeStep_11 (s : Store) : stepWithInputs smGraph (smScope smNode_11) (smPeers smNode_11) s smNode_11 (none) =
    some (smSeededWholeAdvance s (smNode_11, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_11

theorem smSeededWholeStep_12 (s : Store) : stepWithInputs smGraph (smScope smNode_12) (smPeers smNode_12) s smNode_12 (none) =
    some (smSeededWholeAdvance s (smNode_12, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_12

theorem smSeededWholeStep_13 (s : Store) : stepWithInputs smGraph (smScope smNode_13) (smPeers smNode_13) s smNode_13 (none) =
    some (smSeededWholeAdvance s (smNode_13, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_13

theorem smSeededWholeStep_14 (s : Store) : stepWithInputs smGraph (smScope smNode_14) (smPeers smNode_14) s smNode_14 (none) =
    some (smSeededWholeAdvance s (smNode_14, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_14

theorem smSeededWholeStep_15 (s : Store) : stepWithInputs smGraph (smScope smNode_15) (smPeers smNode_15) s smNode_15 (none) =
    some (smSeededWholeAdvance s (smNode_15, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_15

theorem smSeededWholeStep_16 (s : Store) : stepWithInputs smGraph (smScope smNode_16) (smPeers smNode_16) s smNode_16 (none) =
    some (smSeededWholeAdvance s (smNode_16, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_16

theorem smSeededWholeStep_17 (s : Store) : stepWithInputs smGraph (smScope smNode_17) (smPeers smNode_17) s smNode_17 (none) =
    some (smSeededWholeAdvance s (smNode_17, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_17

theorem smSeededWholeStep_18 (s : Store) : stepWithInputs smGraph (smScope smNode_18) (smPeers smNode_18) s smNode_18 (none) =
    some (smSeededWholeAdvance s (smNode_18, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_18

theorem smSeededWholeStep_19 (s : Store) : stepWithInputs smGraph (smScope smNode_19) (smPeers smNode_19) s smNode_19 (none) =
    some (smSeededWholeAdvance s (smNode_19, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_19

theorem smSeededWholeStep_20 (s : Store) : stepWithInputs smGraph (smScope smNode_20) (smPeers smNode_20) s smNode_20 (none) =
    some (smSeededWholeAdvance s (smNode_20, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_20

theorem smSeededWholeStep_21 (s : Store) : stepWithInputs smGraph (smScope smNode_21) (smPeers smNode_21) s smNode_21 (none) =
    some (smSeededWholeAdvance s (smNode_21, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_21

theorem smSeededWholeStep_22 (s : Store) : stepWithInputs smGraph (smScope smNode_22) (smPeers smNode_22) s smNode_22 (none) =
    some (smSeededWholeAdvance s (smNode_22, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_22

theorem smSeededWholeStep_23 (s : Store) : stepWithInputs smGraph (smScope smNode_23) (smPeers smNode_23) s smNode_23 (none) =
    some (smSeededWholeAdvance s (smNode_23, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_23

theorem smSeededWholeStep_24 (s : Store) : stepWithInputs smGraph (smScope smNode_24) (smPeers smNode_24) s smNode_24 (none) =
    some (smSeededWholeAdvance s (smNode_24, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_24

theorem smSeededWholeStep_25 (s : Store) : stepWithInputs smGraph (smScope smNode_25) (smPeers smNode_25) s smNode_25 (none) =
    some (smSeededWholeAdvance s (smNode_25, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_25

theorem smSeededWholeStep_26 (s : Store) : stepWithInputs smGraph (smScope smNode_26) (smPeers smNode_26) s smNode_26 (none) =
    some (smSeededWholeAdvance s (smNode_26, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_26

theorem smSeededWholeStep_27 (s : Store) : stepWithInputs smGraph (smScope smNode_27) (smPeers smNode_27) s smNode_27 (none) =
    some (smSeededWholeAdvance s (smNode_27, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_27

theorem smSeededWholeStep_28 (s : Store) : stepWithInputs smGraph (smScope smNode_28) (smPeers smNode_28) s smNode_28 (none) =
    some (smSeededWholeAdvance s (smNode_28, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_28

theorem smSeededWholeStep_29 (s : Store) : stepWithInputs smGraph (smScope smNode_29) (smPeers smNode_29) s smNode_29 (none) =
    some (smSeededWholeAdvance s (smNode_29, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_29

theorem smSeededWholeStep_30 (s : Store) : stepWithInputs smGraph (smScope smNode_30) (smPeers smNode_30) s smNode_30 (none) =
    some (smSeededWholeAdvance s (smNode_30, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_30

theorem smSeededWholeStep_31 (s : Store) : stepWithInputs smGraph (smScope smNode_31) (smPeers smNode_31) s smNode_31 (none) =
    some (smSeededWholeAdvance s (smNode_31, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_31

theorem smSeededWholeStep_32 (s : Store) : stepWithInputs smGraph (smScope smNode_32) (smPeers smNode_32) s smNode_32 (none) =
    some (smSeededWholeAdvance s (smNode_32, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_32

theorem smSeededWholeStep_33 (s : Store) : stepWithInputs smGraph (smScope smNode_33) (smPeers smNode_33) s smNode_33 (none) =
    some (smSeededWholeAdvance s (smNode_33, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_33

theorem smSeededWholeStep_34 (s : Store) : stepWithInputs smGraph (smScope smNode_34) (smPeers smNode_34) s smNode_34 (none) =
    some (smSeededWholeAdvance s (smNode_34, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_34

theorem smSeededWholeStep_35 (s : Store) : stepWithInputs smGraph (smScope smNode_35) (smPeers smNode_35) s smNode_35 (none) =
    some (smSeededWholeAdvance s (smNode_35, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_35

theorem smSeededWholeStep_36 (s : Store) : stepWithInputs smGraph (smScope smNode_36) (smPeers smNode_36) s smNode_36 (none) =
    some (smSeededWholeAdvance s (smNode_36, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_36

theorem smSeededWholeStep_37 (s : Store) : stepWithInputs smGraph (smScope smNode_37) (smPeers smNode_37) s smNode_37 (none) =
    some (smSeededWholeAdvance s (smNode_37, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_37

theorem smSeededWholeStep_38 (s : Store) : stepWithInputs smGraph (smScope smNode_38) (smPeers smNode_38) s smNode_38 (none) =
    some (smSeededWholeAdvance s (smNode_38, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_38

theorem smSeededWholeStep_39 (s : Store) : stepWithInputs smGraph (smScope smNode_39) (smPeers smNode_39) s smNode_39 (none) =
    some (smSeededWholeAdvance s (smNode_39, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_39

theorem smSeededWholeStep_40 (s : Store) : stepWithInputs smGraph (smScope smNode_40) (smPeers smNode_40) s smNode_40 (none) =
    some (smSeededWholeAdvance s (smNode_40, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_40

theorem smSeededWholeStep_41 (s : Store) : stepWithInputs smGraph (smScope smNode_41) (smPeers smNode_41) s smNode_41 (none) =
    some (smSeededWholeAdvance s (smNode_41, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_41

theorem smSeededWholeStep_42 (s : Store) : stepWithInputs smGraph (smScope smNode_42) (smPeers smNode_42) s smNode_42 (none) =
    some (smSeededWholeAdvance s (smNode_42, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_42

theorem smSeededWholeStep_43 (s : Store) : stepWithInputs smGraph (smScope smNode_43) (smPeers smNode_43) s smNode_43 (none) =
    some (smSeededWholeAdvance s (smNode_43, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_43

theorem smSeededWholeStep_44 (s : Store) : stepWithInputs smGraph (smScope smNode_44) (smPeers smNode_44) s smNode_44 (none) =
    some (smSeededWholeAdvance s (smNode_44, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_44

theorem smSeededWholeStep_45 (s : Store) : stepWithInputs smGraph (smScope smNode_45) (smPeers smNode_45) s smNode_45 (none) =
    some (smSeededWholeAdvance s (smNode_45, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_45

theorem smSeededWholeStep_46 (s : Store) : stepWithInputs smGraph (smScope smNode_46) (smPeers smNode_46) s smNode_46 (none) =
    some (smSeededWholeAdvance s (smNode_46, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_46

theorem smSeededWholeStep_47 (s : Store) : stepWithInputs smGraph (smScope smNode_47) (smPeers smNode_47) s smNode_47 (none) =
    some (smSeededWholeAdvance s (smNode_47, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_47

theorem smSeededWholeStep_48 (s : Store) : stepWithInputs smGraph (smScope smNode_48) (smPeers smNode_48) s smNode_48 (none) =
    some (smSeededWholeAdvance s (smNode_48, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_48

theorem smSeededWholeStep_49 (s : Store) : stepWithInputs smGraph (smScope smNode_49) (smPeers smNode_49) s smNode_49 (none) =
    some (smSeededWholeAdvance s (smNode_49, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_49

theorem smSeededWholeStep_50 (s : Store) : stepWithInputs smGraph (smScope smNode_50) (smPeers smNode_50) s smNode_50 (none) =
    some (smSeededWholeAdvance s (smNode_50, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_50

theorem smSeededWholeStep_51 (s : Store) : stepWithInputs smGraph (smScope smNode_51) (smPeers smNode_51) s smNode_51 (none) =
    some (smSeededWholeAdvance s (smNode_51, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_51

theorem smSeededWholeStep_52 (s : Store) : stepWithInputs smGraph (smScope smNode_52) (smPeers smNode_52) s smNode_52 (none) =
    some (smSeededWholeAdvance s (smNode_52, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_52

theorem smSeededWholeStep_53 (s : Store) : stepWithInputs smGraph (smScope smNode_53) (smPeers smNode_53) s smNode_53 (none) =
    some (smSeededWholeAdvance s (smNode_53, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_53

theorem smSeededWholeStep_54 (s : Store) : stepWithInputs smGraph (smScope smNode_54) (smPeers smNode_54) s smNode_54 (none) =
    some (smSeededWholeAdvance s (smNode_54, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_54

theorem smSeededWholeStep_55 (s : Store) : stepWithInputs smGraph (smScope smNode_55) (smPeers smNode_55) s smNode_55 (none) =
    some (smSeededWholeAdvance s (smNode_55, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_55

theorem smSeededWholeStep_56 (s : Store) : stepWithInputs smGraph (smScope smNode_56) (smPeers smNode_56) s smNode_56 (none) =
    some (smSeededWholeAdvance s (smNode_56, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_56

theorem smSeededWholeStep_57 (s : Store) : stepWithInputs smGraph (smScope smNode_57) (smPeers smNode_57) s smNode_57 (none) =
    some (smSeededWholeAdvance s (smNode_57, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_57

theorem smSeededWholeStep_58 (s : Store) : stepWithInputs smGraph (smScope smNode_58) (smPeers smNode_58) s smNode_58 (none) =
    some (smSeededWholeAdvance s (smNode_58, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_58

theorem smSeededWholeStep_59 (s : Store) : stepWithInputs smGraph (smScope smNode_59) (smPeers smNode_59) s smNode_59 (none) =
    some (smSeededWholeAdvance s (smNode_59, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_59

theorem smSeededWholeStep_60 (s : Store) : stepWithInputs smGraph (smScope smNode_60) (smPeers smNode_60) s smNode_60 (none) =
    some (smSeededWholeAdvance s (smNode_60, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_60

theorem smSeededWholeStep_61 (s : Store) : stepWithInputs smGraph (smScope smNode_61) (smPeers smNode_61) s smNode_61 (none) =
    some (smSeededWholeAdvance s (smNode_61, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_61

theorem smSeededWholeStep_62 (s : Store) : stepWithInputs smGraph (smScope smNode_62) (smPeers smNode_62) s smNode_62 (none) =
    some (smSeededWholeAdvance s (smNode_62, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_62

theorem smSeededWholeStep_63 (s : Store) : stepWithInputs smGraph (smScope smNode_63) (smPeers smNode_63) s smNode_63 (none) =
    some (smSeededWholeAdvance s (smNode_63, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_63

theorem smSeededWholeStep_64 (s : Store) : stepWithInputs smGraph (smScope smNode_64) (smPeers smNode_64) s smNode_64 (none) =
    some (smSeededWholeAdvance s (smNode_64, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_64

theorem smSeededWholeStep_65 (s : Store) : stepWithInputs smGraph (smScope smNode_65) (smPeers smNode_65) s smNode_65 (none) =
    some (smSeededWholeAdvance s (smNode_65, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_65

theorem smSeededWholeStep_66 (s : Store) : stepWithInputs smGraph (smScope smNode_66) (smPeers smNode_66) s smNode_66 (none) =
    some (smSeededWholeAdvance s (smNode_66, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_66

theorem smSeededWholeStep_67 (s : Store) : stepWithInputs smGraph (smScope smNode_67) (smPeers smNode_67) s smNode_67 (none) =
    some (smSeededWholeAdvance s (smNode_67, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_67

theorem smSeededWholeStep_68 (s : Store) : stepWithInputs smGraph (smScope smNode_68) (smPeers smNode_68) s smNode_68 (none) =
    some (smSeededWholeAdvance s (smNode_68, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_68

theorem smSeededWholeStep_69 (s : Store) : stepWithInputs smGraph (smScope smNode_69) (smPeers smNode_69) s smNode_69 (none) =
    some (smSeededWholeAdvance s (smNode_69, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_69

theorem smSeededWholeStep_70 (s : Store) : stepWithInputs smGraph (smScope smNode_70) (smPeers smNode_70) s smNode_70 (none) =
    some (smSeededWholeAdvance s (smNode_70, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_70

theorem smSeededWholeStep_71 (s : Store) : stepWithInputs smGraph (smScope smNode_71) (smPeers smNode_71) s smNode_71 (none) =
    some (smSeededWholeAdvance s (smNode_71, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_71

theorem smSeededWholeStep_72 (s : Store) : stepWithInputs smGraph (smScope smNode_72) (smPeers smNode_72) s smNode_72 (none) =
    some (smSeededWholeAdvance s (smNode_72, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_72

theorem smSeededWholeStep_73 (s : Store) : stepWithInputs smGraph (smScope smNode_73) (smPeers smNode_73) s smNode_73 (none) =
    some (smSeededWholeAdvance s (smNode_73, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_73

theorem smSeededWholeStep_74 (s : Store) : stepWithInputs smGraph (smScope smNode_74) (smPeers smNode_74) s smNode_74 (none) =
    some (smSeededWholeAdvance s (smNode_74, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_74

theorem smSeededWholeStep_75 (s : Store) : stepWithInputs smGraph (smScope smNode_75) (smPeers smNode_75) s smNode_75 (none) =
    some (smSeededWholeAdvance s (smNode_75, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_75

theorem smSeededWholeStep_76 (s : Store) : stepWithInputs smGraph (smScope smNode_76) (smPeers smNode_76) s smNode_76 (none) =
    some (smSeededWholeAdvance s (smNode_76, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_76

theorem smSeededWholeStep_77 (s : Store) : stepWithInputs smGraph (smScope smNode_77) (smPeers smNode_77) s smNode_77 (none) =
    some (smSeededWholeAdvance s (smNode_77, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_77

theorem smSeededWholeStep_78 (s : Store) : stepWithInputs smGraph (smScope smNode_78) (smPeers smNode_78) s smNode_78 (none) =
    some (smSeededWholeAdvance s (smNode_78, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_78

end
end TrainVerify.Denote.RuntimeWorld
