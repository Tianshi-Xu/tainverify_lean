import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0064
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_510_0 (z : Store) : (s_510 z) 895 = (v_506_0 z) := pR (k_509 z) (pR (k_508 z) (pR (k_507 z) (w_506_0 z)))
 #a r_510_0
 theorem r_510_1 (z : Store) : (s_510 z) 1198 = (v_509_0 z) := w_509_0 z
 #a r_510_1
 def v_510_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_506_0 z), (v_509_0 z)]
 theorem g_510 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_516) (s_510 z) pmNode_516 2 1 775 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_516, r_510_0 z, r_510_1 z, h_506_0 z z_, h_509_0 z z_]
 #a g_510
 def s_511 (z : Store) : Store := pL [2, 3] (s_510 z) pmNode_516 2 1
 theorem t_510 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_516) (pmPeers pmNode_516) (s_510 z) pmNode_516 none = some (s_511 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_516) (s_510 z) pmNode_516).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 775 (by decide) (g_510 z z_)]
   rfl
 #a t_510
 theorem k_510 (z : Store) (tid : Tid) (h : tid ∉ [775]) : (s_511 z) tid = (s_510 z) tid := by
   unfold s_511
   dsimp only [pL, pmNode_516, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_510
 theorem w_510_0 (z : Store) : (s_511 z) 775 = v_510_0 z := by
   unfold s_511
   dsimp only [pL, pmNode_516, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_510_0, r_510_0 z, r_510_1 z] <;> rfl
 #a w_510_0
 theorem h_510_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_510_0 z).shape = [1, 8, 64] := by
   unfold v_510_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_506_0 z z_]
 #a h_510_0
 attribute [local irreducible] v_510_0
 attribute [local irreducible] s_511
 theorem r_511_0 (z : Store) : (s_511 z) 775 = (v_510_0 z) := w_510_0 z
 #a r_511_0
 theorem r_511_1 (z : Store) : (s_511 z) 611 = (z 611) := pR (k_510 z) (pR (k_509 z) (pR (k_508 z) (pR (n_504_508 z) (pR (n_496_504 z) (pR (n_480_496 z) (pR (n_448_480 z) (pR (n_384_448 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_66 z))))))))))
 #a r_511_1
 theorem r_511_2 (z : Store) : (s_511 z) 612 = (z 612) := pR (k_510 z) (pR (k_509 z) (pR (k_508 z) (pR (n_504_508 z) (pR (n_496_504 z) (pR (n_480_496 z) (pR (n_448_480 z) (pR (n_384_448 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_67 z))))))))))
 #a r_511_2
 def v_511_0 (z : Store) : Tensor := fw_layernorm (v_510_0 z) (z 611) (z 612)
 def s_512 (z : Store) : Store := storeSet (s_511 z) [(776, fw_layernorm ((s_511 z) 775) ((s_511 z) 611) ((s_511 z) 612))]
 theorem t_511 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_517) (pmPeers pmNode_517) (s_511 z) pmNode_517 none = some (s_512 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_511
 theorem k_511 (z : Store) (tid : Tid) (h : tid ∉ [776]) : (s_512 z) tid = (s_511 z) tid := by
   unfold s_512
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_511
 theorem w_511_0 (z : Store) : (s_512 z) 776 = v_511_0 z := by
   unfold s_512
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_511_0, r_511_0 z, r_511_1 z, r_511_2 z] <;> rfl
 #a w_511_0
 theorem h_511_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_511_0 z).shape = [1, 8, 64] := by
   unfold v_511_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_510_0 z z_
 #a h_511_0
 attribute [local irreducible] v_511_0
 attribute [local irreducible] s_512
 theorem n_508_512 (z : Store) (tid : Tid) (h : tid ∉ ([1074, 1198, 1088, 775, 776] : List Tid)) : (s_512 z) tid = (s_508 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_508 z) (k_509 z)) (pF _ _ _ _ _ (k_510 z) (k_511 z)) tid h
 #a n_508_512
 theorem n_504_512 (z : Store) (tid : Tid) (h : tid ∉ ([770, 771, 895, 785, 1073, 1074, 1198, 1088, 775, 776] : List Tid)) : (s_512 z) tid = (s_504 z) tid := by
   exact pF _ _ _ _ _ (n_504_508 z) (n_508_512 z) tid h
 #a n_504_512
 theorem n_496_512 (z : Store) (tid : Tid) (h : tid ∉ ([761, 762, 1064, 1065, 765, 766, 1068, 1069, 770, 771, 895, 785, 1073, 1074, 1198, 1088, 775, 776] : List Tid)) : (s_512 z) tid = (s_496 z) tid := by
   exact pF _ _ _ _ _ (n_496_504 z) (n_504_512 z) tid h
 #a n_496_512
 theorem n_480_512 (z : Store) (tid : Tid) (h : tid ∉ ([1047, 1048, 748, 749, 684, 1051, 1052, 752, 753, 757, 759, 987, 1055, 1056, 1060, 1062, 761, 762, 1064, 1065, 765, 766, 1068, 1069, 770, 771, 895, 785, 1073, 1074, 1198, 1088, 775, 776] : List Tid)) : (s_512 z) tid = (s_480 z) tid := by
   exact pF _ _ _ _ _ (n_480_496 z) (n_496_512 z) tid h
 #a n_480_512
 theorem n_448_512 (z : Store) (tid : Tid) (h : tid ∉ ([1012, 995, 1015, 996, 1018, 1021, 720, 721, 724, 1023, 1024, 1027, 726, 727, 730, 731, 734, 736, 738, 1029, 1030, 1033, 1034, 1037, 1039, 739, 740, 1041, 1042, 1043, 744, 745, 1047, 1048, 748, 749, 684, 1051, 1052, 752, 753, 757, 759, 987, 1055, 1056, 1060, 1062, 761, 762, 1064, 1065, 765, 766, 1068, 1069, 770, 771, 895, 785, 1073, 1074, 1198, 1088, 775, 776] : List Tid)) : (s_512 z) tid = (s_448 z) tid := by
   exact pF _ _ _ _ _ (n_448_480 z) (n_480_512 z) tid h
 #a n_448_512
 theorem n_384_512 (z : Store) (tid : Tid) (h : tid ∉ ([414, 425, 119, 107, 116, 422, 411, 419, 113, 105, 111, 31, 416, 408, 413, 334, 288, 108, 28, 591, 410, 331, 286, 104, 25, 101, 100, 21, 23, 589, 407, 328, 404, 403, 324, 326, 284, 97, 90, 96, 587, 400, 393, 399, 93, 19, 17, 396, 322, 320, 681, 682, 695, 697, 698, 984, 985, 998, 1000, 1001, 700, 701, 889, 769, 1003, 1004, 1192, 1072, 704, 705, 708, 891, 893, 709, 1007, 1008, 1011, 1194, 1196, 692, 712, 693, 715, 718, 1012, 995, 1015, 996, 1018, 1021, 720, 721, 724, 1023, 1024, 1027, 726, 727, 730, 731, 734, 736, 738, 1029, 1030, 1033, 1034, 1037, 1039, 739, 740, 1041, 1042, 1043, 744, 745, 1047, 1048, 748, 749, 684, 1051, 1052, 752, 753, 757, 759, 987, 1055, 1056, 1060, 1062, 761, 762, 1064, 1065, 765, 766, 1068, 1069, 770, 771, 895, 785, 1073, 1074, 1198, 1088, 775, 776] : List Tid)) : (s_512 z) tid = (s_384 z) tid := by
   exact pF _ _ _ _ _ (n_384_448 z) (n_448_512 z) tid h
 #a n_384_512
 theorem n_256_512 (z : Store) (tid : Tid) (h : tid ∉ ([242, 241, 545, 544, 237, 235, 238, 541, 538, 540, 221, 234, 524, 537, 231, 230, 534, 533, 227, 205, 226, 530, 508, 529, 223, 213, 220, 526, 516, 523, 217, 216, 520, 519, 83, 212, 386, 515, 209, 208, 512, 511, 82, 204, 385, 507, 201, 200, 504, 503, 190, 197, 54, 494, 500, 357, 298, 194, 51, 601, 497, 354, 296, 191, 48, 599, 493, 351, 294, 188, 187, 43, 45, 597, 491, 490, 346, 348, 292, 184, 182, 183, 595, 487, 485, 486, 178, 176, 41, 174, 172, 39, 171, 35, 37, 481, 479, 344, 477, 475, 342, 474, 338, 340, 290, 168, 166, 167, 593, 471, 469, 470, 162, 161, 33, 465, 464, 336, 158, 157, 461, 460, 154, 152, 149, 148, 150, 457, 455, 453, 452, 451, 145, 129, 144, 448, 432, 447, 141, 140, 444, 443, 137, 135, 136, 440, 438, 439, 131, 117, 123, 127, 126, 434, 420, 426, 430, 429, 110, 122, 414, 425, 119, 107, 116, 422, 411, 419, 113, 105, 111, 31, 416, 408, 413, 334, 288, 108, 28, 591, 410, 331, 286, 104, 25, 101, 100, 21, 23, 589, 407, 328, 404, 403, 324, 326, 284, 97, 90, 96, 587, 400, 393, 399, 93, 19, 17, 396, 322, 320, 681, 682, 695, 697, 698, 984, 985, 998, 1000, 1001, 700, 701, 889, 769, 1003, 1004, 1192, 1072, 704, 705, 708, 891, 893, 709, 1007, 1008, 1011, 1194, 1196, 692, 712, 693, 715, 718, 1012, 995, 1015, 996, 1018, 1021, 720, 721, 724, 1023, 1024, 1027, 726, 727, 730, 731, 734, 736, 738, 1029, 1030, 1033, 1034, 1037, 1039, 739, 740, 1041, 1042, 1043, 744, 745, 1047, 1048, 748, 749, 684, 1051, 1052, 752, 753, 757, 759, 987, 1055, 1056, 1060, 1062, 761, 762, 1064, 1065, 765, 766, 1068, 1069, 770, 771, 895, 785, 1073, 1074, 1198, 1088, 775, 776] : List Tid)) : (s_512 z) tid = (s_256 z) tid := by
   exact pF _ _ _ _ _ (n_256_384 z) (n_384_512 z) tid h
 #a n_256_512
 theorem n_0_512 (z : Store) (tid : Tid) (h : tid ∉ ([75, 76, 89, 91, 92, 378, 379, 392, 394, 395, 94, 95, 283, 163, 397, 398, 586, 466, 98, 99, 102, 285, 287, 103, 401, 402, 405, 588, 590, 86, 106, 87, 109, 112, 406, 389, 409, 390, 412, 415, 114, 115, 118, 417, 418, 421, 120, 121, 124, 125, 128, 130, 132, 423, 424, 427, 428, 431, 433, 133, 134, 435, 436, 437, 138, 139, 441, 442, 142, 143, 78, 445, 446, 146, 147, 151, 153, 381, 449, 450, 454, 456, 155, 156, 458, 459, 159, 160, 462, 463, 164, 165, 289, 179, 467, 468, 592, 482, 169, 170, 173, 175, 177, 472, 473, 476, 478, 480, 180, 181, 291, 252, 483, 484, 594, 555, 185, 186, 293, 295, 297, 488, 489, 596, 598, 600, 88, 189, 192, 193, 195, 196, 391, 492, 198, 199, 495, 496, 498, 499, 501, 502, 202, 203, 206, 207, 505, 506, 509, 510, 210, 211, 214, 215, 513, 514, 517, 518, 218, 219, 222, 521, 522, 525, 224, 225, 527, 528, 228, 229, 531, 532, 232, 233, 79, 236, 535, 536, 382, 539, 239, 240, 542, 543, 243, 244, 546, 547, 247, 248, 251, 550, 551, 554, 253, 254, 299, 301, 556, 557, 602, 604, 258, 259, 561, 562, 262, 263, 565, 566, 265, 266, 269, 271, 272, 275, 568, 569, 572, 574, 575, 578, 80, 277, 383, 580, 280, 281, 583, 584, 77, 282, 380, 585, 278, 279, 73, 582, 581, 376, 276, 274, 68, 70, 273, 270, 579, 577, 371, 373, 576, 573, 302, 268, 66, 267, 605, 571, 369, 570, 85, 264, 64, 388, 567, 367, 261, 260, 59, 61, 564, 563, 362, 364, 300, 257, 255, 256, 603, 560, 558, 559, 84, 250, 57, 249, 387, 553, 360, 552, 246, 245, 549, 548, 242, 241, 545, 544, 237, 235, 238, 541, 538, 540, 221, 234, 524, 537, 231, 230, 534, 533, 227, 205, 226, 530, 508, 529, 223, 213, 220, 526, 516, 523, 217, 216, 520, 519, 83, 212, 386, 515, 209, 208, 512, 511, 82, 204, 385, 507, 201, 200, 504, 503, 190, 197, 54, 494, 500, 357, 298, 194, 51, 601, 497, 354, 296, 191, 48, 599, 493, 351, 294, 188, 187, 43, 45, 597, 491, 490, 346, 348, 292, 184, 182, 183, 595, 487, 485, 486, 178, 176, 41, 174, 172, 39, 171, 35, 37, 481, 479, 344, 477, 475, 342, 474, 338, 340, 290, 168, 166, 167, 593, 471, 469, 470, 162, 161, 33, 465, 464, 336, 158, 157, 461, 460, 154, 152, 149, 148, 150, 457, 455, 453, 452, 451, 145, 129, 144, 448, 432, 447, 141, 140, 444, 443, 137, 135, 136, 440, 438, 439, 131, 117, 123, 127, 126, 434, 420, 426, 430, 429, 110, 122, 414, 425, 119, 107, 116, 422, 411, 419, 113, 105, 111, 31, 416, 408, 413, 334, 288, 108, 28, 591, 410, 331, 286, 104, 25, 101, 100, 21, 23, 589, 407, 328, 404, 403, 324, 326, 284, 97, 90, 96, 587, 400, 393, 399, 93, 19, 17, 396, 322, 320, 681, 682, 695, 697, 698, 984, 985, 998, 1000, 1001, 700, 701, 889, 769, 1003, 1004, 1192, 1072, 704, 705, 708, 891, 893, 709, 1007, 1008, 1011, 1194, 1196, 692, 712, 693, 715, 718, 1012, 995, 1015, 996, 1018, 1021, 720, 721, 724, 1023, 1024, 1027, 726, 727, 730, 731, 734, 736, 738, 1029, 1030, 1033, 1034, 1037, 1039, 739, 740, 1041, 1042, 1043, 744, 745, 1047, 1048, 748, 749, 684, 1051, 1052, 752, 753, 757, 759, 987, 1055, 1056, 1060, 1062, 761, 762, 1064, 1065, 765, 766, 1068, 1069, 770, 771, 895, 785, 1073, 1074, 1198, 1088, 775, 776] : List Tid)) : (s_512 z) tid = (s_0 z) tid := by
   exact pF _ _ _ _ _ (n_0_256 z) (n_256_512 z) tid h
 #a n_0_512
 theorem r_512_0 (z : Store) : (s_512 z) 776 = (v_511_0 z) := w_511_0 z
 #a r_512_0
 theorem r_512_1 (z : Store) : (s_512 z) 613 = (z 613) := pR (n_0_512 z) (e_68 z)
 #a r_512_1
 def v_512_0 (z : Store) : Tensor := fw_linear (v_511_0 z) (z 613)
 def s_513 (z : Store) : Store := storeSet (s_512 z) [(779, fw_linear ((s_512 z) 776) ((s_512 z) 613))]
 theorem t_512 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_518) (pmPeers pmNode_518) (s_512 z) pmNode_518 none = some (s_513 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_512
 theorem k_512 (z : Store) (tid : Tid) (h : tid ∉ [779]) : (s_513 z) tid = (s_512 z) tid := by
   unfold s_513
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_512
 theorem w_512_0 (z : Store) : (s_513 z) 779 = v_512_0 z := by
   unfold s_513
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_512_0, r_512_0 z, r_512_1 z] <;> rfl
 #a w_512_0
 theorem h_512_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_512_0 z).shape = [1, 8, 256] := by
   unfold v_512_0
   exact fw_linear_3d_shape 1 8 64 256 (v_511_0 z) (z 613) (h_511_0 z z_) (i_68 z z_)
 #a h_512_0
 attribute [local irreducible] v_512_0
 attribute [local irreducible] s_513
 theorem r_513_0 (z : Store) : (s_513 z) 779 = (v_512_0 z) := w_512_0 z
 #a r_513_0
 def v_513_0 (z : Store) : Tensor := fw_gelu (v_512_0 z)
 def s_514 (z : Store) : Store := storeSet (s_513 z) [(781, fw_gelu ((s_513 z) 779))]
 theorem t_513 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_519) (pmPeers pmNode_519) (s_513 z) pmNode_519 none = some (s_514 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_513
 theorem k_513 (z : Store) (tid : Tid) (h : tid ∉ [781]) : (s_514 z) tid = (s_513 z) tid := by
   unfold s_514
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_513
 theorem w_513_0 (z : Store) : (s_514 z) 781 = v_513_0 z := by
   unfold s_514
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_513_0, r_513_0 z] <;> rfl
 #a w_513_0
 theorem h_513_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_513_0 z).shape = [1, 8, 256] := by
   unfold v_513_0
   exact h_512_0 z z_
 #a h_513_0
 attribute [local irreducible] v_513_0
 attribute [local irreducible] s_514
 theorem r_514_0 (z : Store) : (s_514 z) 781 = (v_513_0 z) := w_513_0 z
 #a r_514_0
 theorem r_514_1 (z : Store) : (s_514 z) 614 = (z 614) := pR (k_513 z) (pR (k_512 z) (pR (n_0_512 z) (e_69 z)))
 #a r_514_1
 def v_514_0 (z : Store) : Tensor := fw_linear (v_513_0 z) (z 614)
 def s_515 (z : Store) : Store := storeSet (s_514 z) [(783, fw_linear ((s_514 z) 781) ((s_514 z) 614))]
 theorem t_514 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_520) (pmPeers pmNode_520) (s_514 z) pmNode_520 none = some (s_515 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_514
 theorem k_514 (z : Store) (tid : Tid) (h : tid ∉ [783]) : (s_515 z) tid = (s_514 z) tid := by
   unfold s_515
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_514
 theorem w_514_0 (z : Store) : (s_515 z) 783 = v_514_0 z := by
   unfold s_515
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_514_0, r_514_0 z, r_514_1 z] <;> rfl
 #a w_514_0
 theorem h_514_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_514_0 z).shape = [1, 8, 64] := by
   unfold v_514_0
   exact fw_linear_3d_shape 1 8 256 64 (v_513_0 z) (z 614) (h_513_0 z z_) (i_69 z z_)
 #a h_514_0
 attribute [local irreducible] v_514_0
 attribute [local irreducible] s_515
 theorem r_515_0 (z : Store) : (s_515 z) 895 = (v_506_0 z) := pR (k_514 z) (pR (k_513 z) (pR (k_512 z) (pR (k_511 z) (pR (k_510 z) (r_510_0 z)))))
 #a r_515_0
 theorem r_515_1 (z : Store) : (s_515 z) 1198 = (v_509_0 z) := pR (k_514 z) (pR (k_513 z) (pR (k_512 z) (pR (k_511 z) (pR (k_510 z) (r_510_1 z)))))
 #a r_515_1
 def v_515_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_506_0 z), (v_509_0 z)]
 theorem g_515 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_752) (s_515 z) pmNode_752 2 1 1078 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_752, r_515_0 z, r_515_1 z, h_506_0 z z_, h_509_0 z z_]
 #a g_515
 def s_516 (z : Store) : Store := pL [2, 3] (s_515 z) pmNode_752 2 1
 theorem t_515 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_752) (pmPeers pmNode_752) (s_515 z) pmNode_752 none = some (s_516 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_752) (s_515 z) pmNode_752).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1078 (by decide) (g_515 z z_)]
   rfl
 #a t_515
 theorem k_515 (z : Store) (tid : Tid) (h : tid ∉ [1078]) : (s_516 z) tid = (s_515 z) tid := by
   unfold s_516
   dsimp only [pL, pmNode_752, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_515
 theorem w_515_0 (z : Store) : (s_516 z) 1078 = v_515_0 z := by
   unfold s_516
   dsimp only [pL, pmNode_752, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_515_0, r_515_0 z, r_515_1 z] <;> rfl
 #a w_515_0
 theorem h_515_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_515_0 z).shape = [1, 8, 64] := by
   unfold v_515_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_506_0 z z_]
 #a h_515_0
 attribute [local irreducible] v_515_0
 attribute [local irreducible] s_516
 theorem n_512_516 (z : Store) (tid : Tid) (h : tid ∉ ([779, 781, 783, 1078] : List Tid)) : (s_516 z) tid = (s_512 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_512 z) (k_513 z)) (pF _ _ _ _ _ (k_514 z) (k_515 z)) tid h
 #a n_512_516
 theorem r_516_0 (z : Store) : (s_516 z) 1078 = (v_515_0 z) := w_515_0 z
 #a r_516_0
 theorem r_516_1 (z : Store) : (s_516 z) 914 = (z 914) := pR (n_512_516 z) (pR (n_0_512 z) (e_70 z))
 #a r_516_1
 theorem r_516_2 (z : Store) : (s_516 z) 915 = (z 915) := pR (n_512_516 z) (pR (n_0_512 z) (e_71 z))
 #a r_516_2
 def v_516_0 (z : Store) : Tensor := fw_layernorm (v_515_0 z) (z 914) (z 915)
 def s_517 (z : Store) : Store := storeSet (s_516 z) [(1079, fw_layernorm ((s_516 z) 1078) ((s_516 z) 914) ((s_516 z) 915))]
 theorem t_516 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_753) (pmPeers pmNode_753) (s_516 z) pmNode_753 none = some (s_517 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_516
 theorem k_516 (z : Store) (tid : Tid) (h : tid ∉ [1079]) : (s_517 z) tid = (s_516 z) tid := by
   unfold s_517
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_516
 theorem w_516_0 (z : Store) : (s_517 z) 1079 = v_516_0 z := by
   unfold s_517
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_516_0, r_516_0 z, r_516_1 z, r_516_2 z] <;> rfl
 #a w_516_0
 theorem h_516_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_516_0 z).shape = [1, 8, 64] := by
   unfold v_516_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_515_0 z z_
 #a h_516_0
 attribute [local irreducible] v_516_0
 attribute [local irreducible] s_517
 theorem r_517_0 (z : Store) : (s_517 z) 1079 = (v_516_0 z) := w_516_0 z
 #a r_517_0
 theorem r_517_1 (z : Store) : (s_517 z) 916 = (z 916) := pR (k_516 z) (pR (n_512_516 z) (pR (n_0_512 z) (e_72 z)))
 #a r_517_1
 def v_517_0 (z : Store) : Tensor := fw_linear (v_516_0 z) (z 916)
 def s_518 (z : Store) : Store := storeSet (s_517 z) [(1082, fw_linear ((s_517 z) 1079) ((s_517 z) 916))]
 theorem t_517 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_754) (pmPeers pmNode_754) (s_517 z) pmNode_754 none = some (s_518 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_517
 theorem k_517 (z : Store) (tid : Tid) (h : tid ∉ [1082]) : (s_518 z) tid = (s_517 z) tid := by
   unfold s_518
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_517
 theorem w_517_0 (z : Store) : (s_518 z) 1082 = v_517_0 z := by
   unfold s_518
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_517_0, r_517_0 z, r_517_1 z] <;> rfl
 #a w_517_0
 theorem h_517_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_517_0 z).shape = [1, 8, 256] := by
   unfold v_517_0
   exact fw_linear_3d_shape 1 8 64 256 (v_516_0 z) (z 916) (h_516_0 z z_) (i_72 z z_)
 #a h_517_0
 attribute [local irreducible] v_517_0
 attribute [local irreducible] s_518
 record_prefix_opacity v_510_0 s_511 v_511_0 s_512 v_512_0 s_513 v_513_0 s_514 v_514_0 s_515 v_515_0 s_516 v_516_0 s_517 v_517_0 s_518

 end
 end TrainVerify.Denote.RuntimeWorld
