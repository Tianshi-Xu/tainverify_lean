import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0005
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_25_0 (z : Store) : (s_25 z) 103 = (v_17_0 z) := pR (k_24 z) (pR (n_20_24 z) (pR (k_19 z) (pR (k_18 z) (w_17_0 z))))
 #a r_25_0
 def v_25_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_17_0 z)
 def s_26 (z : Store) : Store := storeSet (s_25 z) [(112, fw_view [1, 8, 4, 16] ((s_25 z) 103))]
 theorem t_25 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_15) (pmPeers pmNode_15) (s_25 z) pmNode_15 none = some (s_26 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_25
 theorem k_25 (z : Store) (tid : Tid) (h : tid ∉ [112]) : (s_26 z) tid = (s_25 z) tid := by
   unfold s_26
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_25
 theorem w_25_0 (z : Store) : (s_26 z) 112 = v_25_0 z := by
   unfold s_26
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_25_0, r_25_0 z] <;> rfl
 #a w_25_0
 theorem h_25_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_25_0 z).shape = [1, 8, 4, 16] := by
   unfold v_25_0
   rfl
 #a h_25_0
 attribute [local irreducible] v_25_0
 attribute [local irreducible] s_26
 theorem r_26_0 (z : Store) : (s_26 z) 405 = (v_20_0 z) := pR (k_25 z) (pR (k_24 z) (pR (k_23 z) (pR (k_22 z) (pR (k_21 z) (w_20_0 z)))))
 #a r_26_0
 theorem r_26_1 (z : Store) : (s_26 z) 306 = (z 306) := pR (k_25 z) (pR (k_24 z) (pR (n_16_24 z) (pR (n_0_16 z) (e_11 z))))
 #a r_26_1
 def v_26_0 (z : Store) : Tensor := fw_linear (v_20_0 z) (z 306)
 def s_27 (z : Store) : Store := storeSet (s_26 z) [(406, fw_linear ((s_26 z) 405) ((s_26 z) 306))]
 theorem t_26 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_246) (pmPeers pmNode_246) (s_26 z) pmNode_246 none = some (s_27 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_26
 theorem k_26 (z : Store) (tid : Tid) (h : tid ∉ [406]) : (s_27 z) tid = (s_26 z) tid := by
   unfold s_27
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_26
 theorem w_26_0 (z : Store) : (s_27 z) 406 = v_26_0 z := by
   unfold s_27
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_26_0, r_26_0 z, r_26_1 z] <;> rfl
 #a w_26_0
 theorem h_26_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_26_0 z).shape = [1, 8, 64] := by
   unfold v_26_0
   exact fw_linear_3d_shape 1 8 64 64 (v_20_0 z) (z 306) (h_20_0 z z_) (i_11 z z_)
 #a h_26_0
 attribute [local irreducible] v_26_0
 attribute [local irreducible] s_27
 theorem r_27_0 (z : Store) : (s_27 z) 285 = (v_16_1 z) := pR (k_26 z) (pR (k_25 z) (pR (k_24 z) (pR (k_23 z) (pR (k_22 z) (pR (k_21 z) (r_21_0 z))))))
 #a r_27_0
 theorem r_27_1 (z : Store) : (s_27 z) 588 = (v_20_1 z) := pR (k_26 z) (pR (k_25 z) (pR (k_24 z) (pR (k_23 z) (pR (k_22 z) (pR (k_21 z) (r_21_1 z))))))
 #a r_27_1
 def v_27_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_16_1 z), (v_20_1 z)]
 def s_28 (z : Store) : Store := storeSet (s_27 z) [(389, allGatherPrimDimN 1 2 1 [((s_27 z) 285), ((s_27 z) 588)])]
 theorem t_27 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_247) (pmPeers pmNode_247) (s_27 z) pmNode_247 none = some (s_28 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_27 z) pmNode_247 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_27
 theorem k_27 (z : Store) (tid : Tid) (h : tid ∉ [389]) : (s_28 z) tid = (s_27 z) tid := by
   unfold s_28
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_27
 theorem w_27_0 (z : Store) : (s_28 z) 389 = v_27_0 z := by
   unfold s_28
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_27_0, r_27_0 z, r_27_1 z] <;> rfl
 #a w_27_0
 theorem h_27_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_27_0 z).shape = [1, 16, 64] := by
   unfold v_27_0
   exact allGatherPrimDimN_shape 1 2 [(v_16_1 z), (v_20_1 z)] [1, 8, 64] (h_16_1 z z_)
 #a h_27_0
 attribute [local irreducible] v_27_0
 attribute [local irreducible] s_28
 theorem n_24_28 (z : Store) (tid : Tid) (h : tid ∉ ([109, 112, 406, 389] : List Tid)) : (s_28 z) tid = (s_24 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_24 z) (k_25 z)) (pF _ _ _ _ _ (k_26 z) (k_27 z)) tid h
 #a n_24_28
 theorem r_28_0 (z : Store) : (s_28 z) 389 = (v_27_0 z) := w_27_0 z
 #a r_28_0
 theorem r_28_1 (z : Store) : (s_28 z) 330 = (z 330) := pR (n_24_28 z) (pR (n_16_24 z) (pR (n_0_16 z) (e_12 z)))
 #a r_28_1
 def v_28_0 (z : Store) : Tensor := fw_linear (v_27_0 z) (z 330)
 def s_29 (z : Store) : Store := storeSet (s_28 z) [(409, fw_linear ((s_28 z) 389) ((s_28 z) 330))]
 theorem t_28 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_248) (pmPeers pmNode_248) (s_28 z) pmNode_248 none = some (s_29 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_28
 theorem k_28 (z : Store) (tid : Tid) (h : tid ∉ [409]) : (s_29 z) tid = (s_28 z) tid := by
   unfold s_29
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_28
 theorem w_28_0 (z : Store) : (s_29 z) 409 = v_28_0 z := by
   unfold s_29
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_28_0, r_28_0 z, r_28_1 z] <;> rfl
 #a w_28_0
 theorem h_28_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_28_0 z).shape = [1, 16, 32] := by
   unfold v_28_0
   exact fw_linear_3d_shape 1 16 64 32 (v_27_0 z) (z 330) (h_27_0 z z_) (i_12 z z_)
 #a h_28_0
 attribute [local irreducible] v_28_0
 attribute [local irreducible] s_29
 theorem r_29_0 (z : Store) : (s_29 z) 287 = (v_16_2 z) := pR (k_28 z) (pR (n_24_28 z) (pR (k_23 z) (r_23_0 z)))
 #a r_29_0
 theorem r_29_1 (z : Store) : (s_29 z) 590 = (v_20_2 z) := pR (k_28 z) (pR (n_24_28 z) (pR (k_23 z) (r_23_1 z)))
 #a r_29_1
 def v_29_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_16_2 z), (v_20_2 z)]
 def s_30 (z : Store) : Store := storeSet (s_29 z) [(390, allGatherPrimDimN 1 2 1 [((s_29 z) 287), ((s_29 z) 590)])]
 theorem t_29 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_249) (pmPeers pmNode_249) (s_29 z) pmNode_249 none = some (s_30 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_29 z) pmNode_249 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_29
 theorem k_29 (z : Store) (tid : Tid) (h : tid ∉ [390]) : (s_30 z) tid = (s_29 z) tid := by
   unfold s_30
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_29
 theorem w_29_0 (z : Store) : (s_30 z) 390 = v_29_0 z := by
   unfold s_30
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_29_0, r_29_0 z, r_29_1 z] <;> rfl
 #a w_29_0
 theorem h_29_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_29_0 z).shape = [1, 16, 64] := by
   unfold v_29_0
   exact allGatherPrimDimN_shape 1 2 [(v_16_2 z), (v_20_2 z)] [1, 8, 64] (h_16_2 z z_)
 #a h_29_0
 attribute [local irreducible] v_29_0
 attribute [local irreducible] s_30
 theorem r_30_0 (z : Store) : (s_30 z) 390 = (v_29_0 z) := w_29_0 z
 #a r_30_0
 theorem r_30_1 (z : Store) : (s_30 z) 333 = (z 333) := pR (k_29 z) (pR (k_28 z) (pR (n_24_28 z) (pR (n_16_24 z) (pR (n_0_16 z) (e_13 z)))))
 #a r_30_1
 def v_30_0 (z : Store) : Tensor := fw_linear (v_29_0 z) (z 333)
 def s_31 (z : Store) : Store := storeSet (s_30 z) [(412, fw_linear ((s_30 z) 390) ((s_30 z) 333))]
 theorem t_30 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_250) (pmPeers pmNode_250) (s_30 z) pmNode_250 none = some (s_31 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_30
 theorem k_30 (z : Store) (tid : Tid) (h : tid ∉ [412]) : (s_31 z) tid = (s_30 z) tid := by
   unfold s_31
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_30
 theorem w_30_0 (z : Store) : (s_31 z) 412 = v_30_0 z := by
   unfold s_31
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_30_0, r_30_0 z, r_30_1 z] <;> rfl
 #a w_30_0
 theorem h_30_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_30_0 z).shape = [1, 16, 32] := by
   unfold v_30_0
   exact fw_linear_3d_shape 1 16 64 32 (v_29_0 z) (z 333) (h_29_0 z z_) (i_13 z z_)
 #a h_30_0
 attribute [local irreducible] v_30_0
 attribute [local irreducible] s_31
 theorem r_31_0 (z : Store) : (s_31 z) 406 = (v_26_0 z) := pR (k_30 z) (pR (k_29 z) (pR (k_28 z) (pR (k_27 z) (w_26_0 z))))
 #a r_31_0
 def v_31_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_26_0 z)
 def s_32 (z : Store) : Store := storeSet (s_31 z) [(415, fw_view [1, 8, 4, 16] ((s_31 z) 406))]
 theorem t_31 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_251) (pmPeers pmNode_251) (s_31 z) pmNode_251 none = some (s_32 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_31
 theorem k_31 (z : Store) (tid : Tid) (h : tid ∉ [415]) : (s_32 z) tid = (s_31 z) tid := by
   unfold s_32
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_31
 theorem w_31_0 (z : Store) : (s_32 z) 415 = v_31_0 z := by
   unfold s_32
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_31_0, r_31_0 z] <;> rfl
 #a w_31_0
 theorem h_31_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_31_0 z).shape = [1, 8, 4, 16] := by
   unfold v_31_0
   rfl
 #a h_31_0
 attribute [local irreducible] v_31_0
 attribute [local irreducible] s_32
 theorem n_28_32 (z : Store) (tid : Tid) (h : tid ∉ ([409, 390, 412, 415] : List Tid)) : (s_32 z) tid = (s_28 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_28 z) (k_29 z)) (pF _ _ _ _ _ (k_30 z) (k_31 z)) tid h
 #a n_28_32
 theorem r_32_0 (z : Store) : (s_32 z) 112 = (v_25_0 z) := pR (n_28_32 z) (pR (k_27 z) (pR (k_26 z) (w_25_0 z)))
 #a r_32_0
 theorem r_32_1 (z : Store) : (s_32 z) 415 = (v_31_0 z) := w_31_0 z
 #a r_32_1
 def v_32_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_25_0 z), (v_31_0 z)]
 theorem g_32 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_16) (s_32 z) pmNode_16 1 3 114 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_16, r_32_0 z, r_32_1 z, h_25_0 z z_, h_31_0 z z_]
 #a g_32
 def s_33 (z : Store) : Store := pL [0, 1] (s_32 z) pmNode_16 1 3
 theorem t_32 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_16) (pmPeers pmNode_16) (s_32 z) pmNode_16 none = some (s_33 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_16) (s_32 z) pmNode_16).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 114 (by decide) (g_32 z z_)]
   rfl
 #a t_32
 theorem k_32 (z : Store) (tid : Tid) (h : tid ∉ [114]) : (s_33 z) tid = (s_32 z) tid := by
   unfold s_33
   dsimp only [pL, pmNode_16, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_32
 theorem w_32_0 (z : Store) : (s_33 z) 114 = v_32_0 z := by
   unfold s_33
   dsimp only [pL, pmNode_16, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_32_0, r_32_0 z, r_32_1 z] <;> rfl
 #a w_32_0
 theorem h_32_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_32_0 z).shape = [1, 16, 4, 8] := by
   unfold v_32_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_25_0 z z_]
 #a h_32_0
 attribute [local irreducible] v_32_0
 attribute [local irreducible] s_33
 theorem r_33_0 (z : Store) : (s_33 z) 114 = (v_32_0 z) := w_32_0 z
 #a r_33_0
 def v_33_0 (z : Store) : Tensor := transposeAxes 1 2 (v_32_0 z)
 def s_34 (z : Store) : Store := storeSet (s_33 z) [(115, transposeAxes 1 2 ((s_33 z) 114))]
 theorem t_33 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_17) (pmPeers pmNode_17) (s_33 z) pmNode_17 none = some (s_34 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_33
 theorem k_33 (z : Store) (tid : Tid) (h : tid ∉ [115]) : (s_34 z) tid = (s_33 z) tid := by
   unfold s_34
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_33
 theorem w_33_0 (z : Store) : (s_34 z) 115 = v_33_0 z := by
   unfold s_34
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_33_0, r_33_0 z] <;> rfl
 #a w_33_0
 theorem h_33_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_33_0 z).shape = [1, 4, 16, 8] := by
   unfold v_33_0
   change listSwapAt _ _ _ = _
   rw [h_32_0 z z_]
   rfl
 #a h_33_0
 attribute [local irreducible] v_33_0
 attribute [local irreducible] s_34
 theorem n_24_32 (z : Store) (tid : Tid) (h : tid ∉ ([109, 112, 406, 389, 409, 390, 412, 415] : List Tid)) : (s_32 z) tid = (s_24 z) tid := by
   exact pF _ _ _ _ _ (n_24_28 z) (n_28_32 z) tid h
 #a n_24_32
 theorem r_34_0 (z : Store) : (s_34 z) 106 = (v_22_0 z) := pR (k_33 z) (pR (k_32 z) (pR (n_24_32 z) (pR (k_23 z) (w_22_0 z))))
 #a r_34_0
 def v_34_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_22_0 z)
 def s_35 (z : Store) : Store := storeSet (s_34 z) [(118, fw_view [1, 16, 2, 16] ((s_34 z) 106))]
 theorem t_34 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_18) (pmPeers pmNode_18) (s_34 z) pmNode_18 none = some (s_35 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_34
 theorem k_34 (z : Store) (tid : Tid) (h : tid ∉ [118]) : (s_35 z) tid = (s_34 z) tid := by
   unfold s_35
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_34
 theorem w_34_0 (z : Store) : (s_35 z) 118 = v_34_0 z := by
   unfold s_35
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_34_0, r_34_0 z] <;> rfl
 #a w_34_0
 theorem h_34_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_34_0 z).shape = [1, 16, 2, 16] := by
   unfold v_34_0
   rfl
 #a h_34_0
 attribute [local irreducible] v_34_0
 attribute [local irreducible] s_35
 record_prefix_opacity v_25_0 s_26 v_26_0 s_27 v_27_0 s_28 v_28_0 s_29 v_29_0 s_30 v_30_0 s_31 v_31_0 s_32 v_32_0 s_33 v_33_0 s_34 v_34_0 s_35

 end
 end TrainVerify.Denote.RuntimeWorld
