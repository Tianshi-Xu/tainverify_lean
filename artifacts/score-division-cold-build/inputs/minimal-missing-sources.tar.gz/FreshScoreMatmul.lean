import FreshMiddleExchange
import denote.SourceMatmulRead
import denote.SourceMatmulUnit
-- UNCOMPILED: parent owns imports, predecessors, frame, aggregate costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierScoreMatmulRead_sm_1304 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1304 = fw_matmul (t 1298) (t 1303) := by
  apply SourceMatmulRead.matmul_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 45) (smInputRequests.drop 46) smNode_45
    0 1298 1303 1304 s t rfl ?_ rfl ?_ ?_ h
  · calc
      smInputRequests = smInputRequests.take 45 ++ smInputRequests.drop 45 := (List.take_append_drop 45 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 45, 1298 ∉ row.1.outs
    decide
  · change ∀ row ∈ smInputRequests.drop 45, 1303 ∉ row.1.outs
    decide
#print axioms frontierScoreMatmulRead_sm_1304
theorem frontierScoreMatmulRead_pm_225 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 225 = fw_matmul (t 203) (t 224) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 149) (pmInputRequests.drop 150) pmNode_75
    0 203 224 225 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 149 ++ pmInputRequests.drop 149 := (List.take_append_drop 149 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 149, 203 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 149, 224 ∉ row.1.outs
    decide
#print axioms frontierScoreMatmulRead_pm_225
theorem frontierScoreMatmulRead_pm_528 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 528 = fw_matmul (t 506) (t 527) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 151) (pmInputRequests.drop 152) pmNode_311
    1 506 527 528 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 151 ++ pmInputRequests.drop 151 := (List.take_append_drop 151 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 151, 506 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 151, 527 ∉ row.1.outs
    decide
#print axioms frontierScoreMatmulRead_pm_528
theorem frontierScoreMatmulUnitFacts_1304_0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1304).shape = [2, 4, 16, 16] ∧
    (∀ z ∈ [q 225, q 528], z.shape = [1, 2, 16, 16]) ∧
    chunkPrimDimN 0 2 0 (t 1304) = allGatherPrimDimN 1 2 0 [q 225, q 528] := by
  have left := frontierProjectionTransposeUnitFacts_1298_0_slot0 s p t q hs hp hvalues
  have right := frontierMiddleExchangeUnitFacts_1303_0_slot0 s p t q hs hp hvalues
  have outputs : [q 225, q 528] = List.zipWith fw_matmul [q 203, q 506] [q 224, q 527] := by
    change [q 225, q 528] = [fw_matmul (q 203) (q 224), fw_matmul (q 506) (q 527)]
    exact congrArg₂ List.cons (frontierScoreMatmulRead_pm_225 p q hp) (congrArg₂ List.cons (frontierScoreMatmulRead_pm_528 p q hp) (rfl))
  exact TrainVerify.Denote.source_matmul_unit_output_reconstruct 2 2 1 2 16 16 16 0
    (t 1298) (t 1303) (t 1304) [q 203, q 506] [q 224, q 527] [q 225, q 528]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    left.1 right.1 rfl rfl left.2.1 right.2.1 left.2.2 right.2.2
    (frontierScoreMatmulRead_sm_1304 s t hs) outputs
#print axioms frontierScoreMatmulUnitFacts_1304_0
theorem frontierScoreMatmulRead_pm_831 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 831 = fw_matmul (t 809) (t 830) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 571) (pmInputRequests.drop 572) pmNode_547
    2 809 830 831 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 571 ++ pmInputRequests.drop 571 := (List.take_append_drop 571 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 571, 809 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 571, 830 ∉ row.1.outs
    decide
#print axioms frontierScoreMatmulRead_pm_831
theorem frontierScoreMatmulRead_pm_1134 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1134 = fw_matmul (t 1112) (t 1133) := by
  apply SourceMatmulRead.matmul_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 573) (pmInputRequests.drop 574) pmNode_783
    3 1112 1133 1134 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 573 ++ pmInputRequests.drop 573 := (List.take_append_drop 573 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 573, 1112 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 573, 1133 ∉ row.1.outs
    decide
#print axioms frontierScoreMatmulRead_pm_1134
theorem frontierScoreMatmulUnitFacts_1304_1 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1304).shape = [2, 4, 16, 16] ∧
    (∀ z ∈ [q 831, q 1134], z.shape = [1, 2, 16, 16]) ∧
    chunkPrimDimN 0 2 1 (t 1304) = allGatherPrimDimN 1 2 0 [q 831, q 1134] := by
  have left := frontierProjectionTransposeUnitFacts_1298_1_slot0 s p t q hs hp hvalues
  have right := frontierMiddleExchangeUnitFacts_1303_1_slot0 s p t q hs hp hvalues
  have outputs : [q 831, q 1134] = List.zipWith fw_matmul [q 809, q 1112] [q 830, q 1133] := by
    change [q 831, q 1134] = [fw_matmul (q 809) (q 830), fw_matmul (q 1112) (q 1133)]
    exact congrArg₂ List.cons (frontierScoreMatmulRead_pm_831 p q hp) (congrArg₂ List.cons (frontierScoreMatmulRead_pm_1134 p q hp) (rfl))
  exact TrainVerify.Denote.source_matmul_unit_output_reconstruct 2 2 1 2 16 16 16 1
    (t 1298) (t 1303) (t 1304) [q 809, q 1112] [q 830, q 1133] [q 831, q 1134]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    left.1 right.1 rfl rfl left.2.1 right.2.1 left.2.2 right.2.2
    (frontierScoreMatmulRead_sm_1304 s t hs) outputs
#print axioms frontierScoreMatmulUnitFacts_1304_1
end
end TrainVerify.Denote.RuntimeWorld
