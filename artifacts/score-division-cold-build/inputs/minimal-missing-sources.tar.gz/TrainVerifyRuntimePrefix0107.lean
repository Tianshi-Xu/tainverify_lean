import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0106
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_839_0 (z : Store) : (s_839 z) 699 = (v_838_0 z) := w_838_0 z
 #a r_839_0
 theorem r_839_1 (z : Store) : (s_839 z) 697 = (v_424_0 z) := pR (k_838 z) (pR (k_837 z) (pR (k_836 z) (pR (n_832_836 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (n_428_432 z) (pR (k_427 z) (pR (k_426 z) (pR (k_425 z) (r_425_0 z))))))))))))
 #a r_839_1
 theorem r_839_2 (z : Store) : (s_839 z) 606 = (z 606) := pR (k_838 z) (pR (k_837 z) (pR (k_836 z) (pR (n_832_836 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (n_428_432 z) (pR (k_427 z) (pR (k_426 z) (pR (k_425 z) (r_425_1 z))))))))))))
 #a r_839_2
 def v_839_0 (z : Store) : Tensor := bw_embedding (v_838_0 z) (v_424_0 z) (z 606)
 def s_840 (z : Store) : Store := storeSet (s_839 z) [(625, bw_embedding ((s_839 z) 699) ((s_839 z) 697) ((s_839 z) 606))]
 theorem t_839 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_681) (pmPeers pmNode_681) (s_839 z) pmNode_681 none = some (s_840 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_839
 theorem k_839 (z : Store) (tid : Tid) (h : tid ∉ [625]) : (s_840 z) tid = (s_839 z) tid := by
   unfold s_840
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_839
 theorem w_839_0 (z : Store) : (s_840 z) 625 = v_839_0 z := by
   unfold s_840
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_839_0, r_839_0 z, r_839_1 z, r_839_2 z] <;> rfl
 #a w_839_0
 theorem h_839_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_839_0 z).shape = [16, 64] := by
   unfold v_839_0
   exact i_51 z z_
 #a h_839_0
 attribute [local irreducible] v_839_0
 attribute [local irreducible] s_840
 theorem n_836_840 (z : Store) (tid : Tid) (h : tid ∉ ([1006, 999, 1005, 699, 625] : List Tid)) : (s_840 z) tid = (s_836 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_836 z) (k_837 z)) (pF _ _ _ _ _ (k_838 z) (k_839 z)) tid h
 #a n_836_840
 theorem n_832_840 (z : Store) (tid : Tid) (h : tid ∉ ([890, 703, 696, 702, 1193, 1006, 999, 1005, 699, 625] : List Tid)) : (s_840 z) tid = (s_832 z) tid := by
   exact pF _ _ _ _ _ (n_832_836 z) (n_836_840 z) tid h
 #a n_832_840
 theorem r_840_0 (z : Store) : (s_840 z) 696 = (v_834_0 z) := pR (n_836_840 z) (pR (k_835 z) (w_834_0 z))
 #a r_840_0
 theorem r_840_1 (z : Store) : (s_840 z) 681 = (v_422_0 z) := pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (n_424_432 z) (pR (k_423 z) (r_423_0 z)))))))
 #a r_840_1
 theorem r_840_2 (z : Store) : (s_840 z) 622 = (z 622) := pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (n_424_432 z) (pR (k_423 z) (r_423_1 z)))))))
 #a r_840_2
 def v_840_0 (z : Store) : Tensor := bw_embedding (v_834_0 z) (v_422_0 z) (z 622)
 def s_841 (z : Store) : Store := storeSet (s_840 z) [(623, bw_embedding ((s_840 z) 696) ((s_840 z) 681) ((s_840 z) 622))]
 theorem t_840 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_682) (pmPeers pmNode_682) (s_840 z) pmNode_682 none = some (s_841 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_840
 theorem k_840 (z : Store) (tid : Tid) (h : tid ∉ [623]) : (s_841 z) tid = (s_840 z) tid := by
   unfold s_841
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_840
 theorem w_840_0 (z : Store) : (s_841 z) 623 = v_840_0 z := by
   unfold s_841
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_840_0, r_840_0 z, r_840_1 z, r_840_2 z] <;> rfl
 #a w_840_0
 theorem h_840_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_840_0 z).shape = [256, 32] := by
   unfold v_840_0
   exact i_50 z z_
 #a h_840_0
 attribute [local irreducible] v_840_0
 attribute [local irreducible] s_841
 theorem r_841_0 (z : Store) : (s_841 z) 702 = (v_834_1 z) := pR (k_840 z) (pR (k_839 z) (pR (k_838 z) (r_838_0 z)))
 #a r_841_0
 theorem r_841_1 (z : Store) : (s_841 z) 1005 = (v_837_1 z) := pR (k_840 z) (pR (k_839 z) (pR (k_838 z) (r_838_1 z)))
 #a r_841_1
 def v_841_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_834_1 z), (v_837_1 z)]
 theorem g_841 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_916) (s_841 z) pmNode_916 2 1 1002 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_916, r_841_0 z, r_841_1 z, h_834_1 z z_, h_837_1 z z_]
 #a g_841
 def s_842 (z : Store) : Store := pL [2, 3] (s_841 z) pmNode_916 2 1
 theorem t_841 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_916) (pmPeers pmNode_916) (s_841 z) pmNode_916 none = some (s_842 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_916) (s_841 z) pmNode_916).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1002 (by decide) (g_841 z z_)]
   rfl
 #a t_841
 theorem k_841 (z : Store) (tid : Tid) (h : tid ∉ [1002]) : (s_842 z) tid = (s_841 z) tid := by
   unfold s_842
   dsimp only [pL, pmNode_916, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_841
 theorem w_841_0 (z : Store) : (s_842 z) 1002 = v_841_0 z := by
   unfold s_842
   dsimp only [pL, pmNode_916, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_841_0, r_841_0 z, r_841_1 z] <;> rfl
 #a w_841_0
 theorem h_841_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_841_0 z).shape = [1, 8, 64] := by
   unfold v_841_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_834_1 z z_]
 #a h_841_0
 attribute [local irreducible] v_841_0
 attribute [local irreducible] s_842
 theorem r_842_0 (z : Store) : (s_842 z) 1002 = (v_841_0 z) := w_841_0 z
 #a r_842_0
 theorem r_842_1 (z : Store) : (s_842 z) 1000 = (v_428_0 z) := pR (k_841 z) (pR (k_840 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (k_431 z) (pR (k_430 z) (pR (k_429 z) (r_429_0 z))))))))))
 #a r_842_1
 theorem r_842_2 (z : Store) : (s_842 z) 909 = (z 909) := pR (k_841 z) (pR (k_840 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (k_431 z) (pR (k_430 z) (pR (k_429 z) (r_429_1 z))))))))))
 #a r_842_2
 def v_842_0 (z : Store) : Tensor := bw_embedding (v_841_0 z) (v_428_0 z) (z 909)
 def s_843 (z : Store) : Store := storeSet (s_842 z) [(928, bw_embedding ((s_842 z) 1002) ((s_842 z) 1000) ((s_842 z) 909))]
 theorem t_842 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_917) (pmPeers pmNode_917) (s_842 z) pmNode_917 none = some (s_843 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_842
 theorem k_842 (z : Store) (tid : Tid) (h : tid ∉ [928]) : (s_843 z) tid = (s_842 z) tid := by
   unfold s_843
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_842
 theorem w_842_0 (z : Store) : (s_843 z) 928 = v_842_0 z := by
   unfold s_843
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_842_0, r_842_0 z, r_842_1 z, r_842_2 z] <;> rfl
 #a w_842_0
 theorem h_842_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_842_0 z).shape = [16, 64] := by
   unfold v_842_0
   exact i_53 z z_
 #a h_842_0
 attribute [local irreducible] v_842_0
 attribute [local irreducible] s_843
 theorem r_843_0 (z : Store) : (s_843 z) 19 = (v_417_0 z) := pR (k_842 z) (pR (k_841 z) (pR (k_840 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (n_424_432 z) (pR (n_420_424 z) (pR (k_419 z) (pR (k_418 z) (w_417_0 z))))))))))))
 #a r_843_0
 theorem r_843_1 (z : Store) : (s_843 z) 322 = (v_420_0 z) := pR (k_842 z) (pR (k_841 z) (pR (k_840 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (n_424_432 z) (pR (k_423 z) (pR (k_422 z) (pR (k_421 z) (w_420_0 z))))))))))))
 #a r_843_1
 theorem r_843_2 (z : Store) : (s_843 z) 625 = (v_839_0 z) := pR (k_842 z) (pR (k_841 z) (pR (k_840 z) (w_839_0 z)))
 #a r_843_2
 theorem r_843_3 (z : Store) : (s_843 z) 928 = (v_842_0 z) := w_842_0 z
 #a r_843_3
 def v_843_0 (z : Store) : Tensor := cross_dp_wred [(v_417_0 z), (v_420_0 z), (v_839_0 z), (v_842_0 z)]
 theorem g_843 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_211) (s_843 z) pmNode_211 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_211, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_843_1 z, r_843_0 z]
     exact (h_420_0 z z_).trans (h_417_0 z z_).symm
   · rw [r_843_2 z, r_843_0 z]
     exact (h_839_0 z z_).trans (h_417_0 z z_).symm
   · rw [r_843_3 z, r_843_0 z]
     exact (h_842_0 z z_).trans (h_417_0 z z_).symm
 #a g_843
 def s_844 (z : Store) : Store := storeSet (s_843 z) [(20, cross_dp_wred [((s_843 z) 19), ((s_843 z) 322), ((s_843 z) 625), ((s_843 z) 928)])]
 theorem t_843 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_211) (pmPeers pmNode_211) (s_843 z) pmNode_211 none = some (s_844 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_211) (s_843 z) pmNode_211 = _
   rw [wredStep, if_pos ⟨by decide, g_843 z z_⟩]
   rfl
 #a t_843
 theorem k_843 (z : Store) (tid : Tid) (h : tid ∉ [20]) : (s_844 z) tid = (s_843 z) tid := by
   unfold s_844
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_843
 theorem w_843_0 (z : Store) : (s_844 z) 20 = v_843_0 z := by
   unfold s_844
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_843_0, r_843_0 z, r_843_1 z, r_843_2 z, r_843_3 z] <;> rfl
 #a w_843_0
 theorem h_843_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_843_0 z).shape = [16, 64] := by
   unfold v_843_0
   rw [tensorSum_shape]
   exact h_417_0 z z_
 #a h_843_0
 attribute [local irreducible] v_843_0
 attribute [local irreducible] s_844
 theorem n_840_844 (z : Store) (tid : Tid) (h : tid ∉ ([623, 1002, 928, 20] : List Tid)) : (s_844 z) tid = (s_840 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_840 z) (k_841 z)) (pF _ _ _ _ _ (k_842 z) (k_843 z)) tid h
 #a n_840_844
 theorem r_844_0 (z : Store) : (s_844 z) 21 = (v_405_1 z) := pR (n_840_844 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_416_448 z) (pR (n_408_416 z) (pR (k_407 z) (pR (k_406 z) (w_405_1 z)))))))))
 #a r_844_0
 theorem r_844_1 (z : Store) : (s_844 z) 324 = (v_409_1 z) := pR (n_840_844 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_416_448 z) (pR (n_412_416 z) (pR (k_411 z) (pR (k_410 z) (w_409_1 z)))))))))
 #a r_844_1
 theorem r_844_2 (z : Store) : (s_844 z) 627 = (v_827_1 z) := pR (n_840_844 z) (pR (n_832_840 z) (pR (n_828_832 z) (w_827_1 z)))
 #a r_844_2
 theorem r_844_3 (z : Store) : (s_844 z) 930 = (v_831_1 z) := pR (n_840_844 z) (pR (n_832_840 z) (w_831_1 z))
 #a r_844_3
 def v_844_0 (z : Store) : Tensor := cross_dp_wred [(v_405_1 z), (v_409_1 z), (v_827_1 z), (v_831_1 z)]
 theorem g_844 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_212) (s_844 z) pmNode_212 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_212, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_844_1 z, r_844_0 z]
     exact (h_409_1 z z_).trans (h_405_1 z z_).symm
   · rw [r_844_2 z, r_844_0 z]
     exact (h_827_1 z z_).trans (h_405_1 z z_).symm
   · rw [r_844_3 z, r_844_0 z]
     exact (h_831_1 z z_).trans (h_405_1 z z_).symm
 #a g_844
 def s_845 (z : Store) : Store := storeSet (s_844 z) [(22, cross_dp_wred [((s_844 z) 21), ((s_844 z) 324), ((s_844 z) 627), ((s_844 z) 930)])]
 theorem t_844 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_212) (pmPeers pmNode_212) (s_844 z) pmNode_212 none = some (s_845 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_212) (s_844 z) pmNode_212 = _
   rw [wredStep, if_pos ⟨by decide, g_844 z z_⟩]
   rfl
 #a t_844
 theorem k_844 (z : Store) (tid : Tid) (h : tid ∉ [22]) : (s_845 z) tid = (s_844 z) tid := by
   unfold s_845
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_844
 theorem w_844_0 (z : Store) : (s_845 z) 22 = v_844_0 z := by
   unfold s_845
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_844_0, r_844_0 z, r_844_1 z, r_844_2 z, r_844_3 z] <;> rfl
 #a w_844_0
 theorem h_844_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_844_0 z).shape = [64] := by
   unfold v_844_0
   rw [tensorSum_shape]
   exact h_405_1 z z_
 #a h_844_0
 attribute [local irreducible] v_844_0
 attribute [local irreducible] s_845
 theorem r_845_0 (z : Store) : (s_845 z) 23 = (v_405_2 z) := pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_416_448 z) (pR (n_408_416 z) (pR (k_407 z) (pR (k_406 z) (w_405_2 z))))))))))
 #a r_845_0
 theorem r_845_1 (z : Store) : (s_845 z) 326 = (v_409_2 z) := pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_416_448 z) (pR (n_412_416 z) (pR (k_411 z) (pR (k_410 z) (w_409_2 z))))))))))
 #a r_845_1
 theorem r_845_2 (z : Store) : (s_845 z) 629 = (v_827_2 z) := pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (pR (n_828_832 z) (w_827_2 z))))
 #a r_845_2
 theorem r_845_3 (z : Store) : (s_845 z) 932 = (v_831_2 z) := pR (k_844 z) (pR (n_840_844 z) (pR (n_832_840 z) (w_831_2 z)))
 #a r_845_3
 def v_845_0 (z : Store) : Tensor := cross_dp_wred [(v_405_2 z), (v_409_2 z), (v_827_2 z), (v_831_2 z)]
 theorem g_845 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_213) (s_845 z) pmNode_213 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_213, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_845_1 z, r_845_0 z]
     exact (h_409_2 z z_).trans (h_405_2 z z_).symm
   · rw [r_845_2 z, r_845_0 z]
     exact (h_827_2 z z_).trans (h_405_2 z z_).symm
   · rw [r_845_3 z, r_845_0 z]
     exact (h_831_2 z z_).trans (h_405_2 z z_).symm
 #a g_845
 def s_846 (z : Store) : Store := storeSet (s_845 z) [(24, cross_dp_wred [((s_845 z) 23), ((s_845 z) 326), ((s_845 z) 629), ((s_845 z) 932)])]
 theorem t_845 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_213) (pmPeers pmNode_213) (s_845 z) pmNode_213 none = some (s_846 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_213) (s_845 z) pmNode_213 = _
   rw [wredStep, if_pos ⟨by decide, g_845 z z_⟩]
   rfl
 #a t_845
 theorem k_845 (z : Store) (tid : Tid) (h : tid ∉ [24]) : (s_846 z) tid = (s_845 z) tid := by
   unfold s_846
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_845
 theorem w_845_0 (z : Store) : (s_846 z) 24 = v_845_0 z := by
   unfold s_846
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_845_0, r_845_0 z, r_845_1 z, r_845_2 z, r_845_3 z] <;> rfl
 #a w_845_0
 theorem h_845_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_845_0 z).shape = [64] := by
   unfold v_845_0
   rw [tensorSum_shape]
   exact h_405_2 z z_
 #a h_845_0
 attribute [local irreducible] v_845_0
 attribute [local irreducible] s_846
 record_prefix_opacity v_839_0 s_840 v_840_0 s_841 v_841_0 s_842 v_842_0 s_843 v_843_0 s_844 v_844_0 s_845 v_845_0 s_846

 end
 end TrainVerify.Denote.RuntimeWorld
