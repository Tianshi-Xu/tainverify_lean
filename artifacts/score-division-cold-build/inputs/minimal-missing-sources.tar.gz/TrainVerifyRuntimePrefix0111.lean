import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0110
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_867_0 (z : Store) : (s_867 z) 54 = (v_303_1 z) := pR (k_866 z) (pR (k_865 z) (pR (k_864 z) (pR (n_832_864 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_320_384 z) (pR (n_304_320 z) (w_303_1 z)))))))))
 #a r_867_0
 theorem r_867_1 (z : Store) : (s_867 z) 660 = (v_725_1 z) := pR (k_866 z) (pR (k_865 z) (pR (k_864 z) (pR (n_832_864 z) (pR (n_768_832 z) (pR (n_736_768 z) (pR (n_728_736 z) (pR (k_727 z) (pR (k_726 z) (w_725_1 z)))))))))
 #a r_867_1
 def v_867_0 (z : Store) : Tensor := cross_dp_wred [(v_303_1 z), (v_725_1 z)]
 theorem g_867 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_235) (s_867 z) pmNode_235 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_235, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_867_1 z, r_867_0 z]
     exact (h_725_1 z z_).trans (h_303_1 z z_).symm
 #a g_867
 def s_868 (z : Store) : Store := storeSet (s_867 z) [(55, cross_dp_wred [((s_867 z) 54), ((s_867 z) 660)])]
 theorem t_867 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_235) (pmPeers pmNode_235) (s_867 z) pmNode_235 none = some (s_868 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_235) (s_867 z) pmNode_235 = _
   rw [wredStep, if_pos ⟨by decide, g_867 z z_⟩]
   rfl
 #a t_867
 theorem k_867 (z : Store) (tid : Tid) (h : tid ∉ [55]) : (s_868 z) tid = (s_867 z) tid := by
   unfold s_868
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_867
 theorem w_867_0 (z : Store) : (s_868 z) 55 = v_867_0 z := by
   unfold s_868
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_867_0, r_867_0 z, r_867_1 z] <;> rfl
 #a w_867_0
 theorem h_867_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_867_0 z).shape = [64, 32] := by
   unfold v_867_0
   rw [tensorSum_shape]
   exact h_303_1 z z_
 #a h_867_0
 attribute [local irreducible] v_867_0
 attribute [local irreducible] s_868
 theorem n_864_868 (z : Store) (tid : Tid) (h : tid ∉ ([74, 49, 52, 55] : List Tid)) : (s_868 z) tid = (s_864 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_864 z) (k_865 z)) (pF _ _ _ _ _ (k_866 z) (k_867 z)) tid h
 #a n_864_868
 theorem r_868_0 (z : Store) : (s_868 z) 19 = (v_417_0 z) := pR (n_864_868 z) (pR (n_848_864 z) (pR (n_844_848 z) (pR (k_843 z) (r_843_0 z))))
 #a r_868_0
 theorem r_868_1 (z : Store) : (s_868 z) 322 = (v_420_0 z) := pR (n_864_868 z) (pR (n_848_864 z) (pR (n_844_848 z) (pR (k_843 z) (r_843_1 z))))
 #a r_868_1
 theorem r_868_2 (z : Store) : (s_868 z) 625 = (v_839_0 z) := pR (n_864_868 z) (pR (n_848_864 z) (pR (n_844_848 z) (pR (k_843 z) (r_843_2 z))))
 #a r_868_2
 theorem r_868_3 (z : Store) : (s_868 z) 928 = (v_842_0 z) := pR (n_864_868 z) (pR (n_848_864 z) (pR (n_844_848 z) (pR (k_843 z) (r_843_3 z))))
 #a r_868_3
 def v_868_0 (z : Store) : Tensor := cross_dp_wred [(v_417_0 z), (v_420_0 z), (v_839_0 z), (v_842_0 z)]
 theorem g_868 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_447) (s_868 z) pmNode_447 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_447, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_868_1 z, r_868_0 z]
     exact (h_420_0 z z_).trans (h_417_0 z z_).symm
   · rw [r_868_2 z, r_868_0 z]
     exact (h_839_0 z z_).trans (h_417_0 z z_).symm
   · rw [r_868_3 z, r_868_0 z]
     exact (h_842_0 z z_).trans (h_417_0 z z_).symm
 #a g_868
 def s_869 (z : Store) : Store := storeSet (s_868 z) [(323, cross_dp_wred [((s_868 z) 19), ((s_868 z) 322), ((s_868 z) 625), ((s_868 z) 928)])]
 theorem t_868 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_447) (pmPeers pmNode_447) (s_868 z) pmNode_447 none = some (s_869 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_447) (s_868 z) pmNode_447 = _
   rw [wredStep, if_pos ⟨by decide, g_868 z z_⟩]
   rfl
 #a t_868
 theorem k_868 (z : Store) (tid : Tid) (h : tid ∉ [323]) : (s_869 z) tid = (s_868 z) tid := by
   unfold s_869
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_868
 theorem w_868_0 (z : Store) : (s_869 z) 323 = v_868_0 z := by
   unfold s_869
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_868_0, r_868_0 z, r_868_1 z, r_868_2 z, r_868_3 z] <;> rfl
 #a w_868_0
 theorem h_868_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_868_0 z).shape = [16, 64] := by
   unfold v_868_0
   rw [tensorSum_shape]
   exact h_417_0 z z_
 #a h_868_0
 attribute [local irreducible] v_868_0
 attribute [local irreducible] s_869
 theorem r_869_0 (z : Store) : (s_869 z) 21 = (v_405_1 z) := pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (n_844_848 z) (r_844_0 z))))
 #a r_869_0
 theorem r_869_1 (z : Store) : (s_869 z) 324 = (v_409_1 z) := pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (n_844_848 z) (r_844_1 z))))
 #a r_869_1
 theorem r_869_2 (z : Store) : (s_869 z) 627 = (v_827_1 z) := pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (n_844_848 z) (r_844_2 z))))
 #a r_869_2
 theorem r_869_3 (z : Store) : (s_869 z) 930 = (v_831_1 z) := pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (n_844_848 z) (r_844_3 z))))
 #a r_869_3
 def v_869_0 (z : Store) : Tensor := cross_dp_wred [(v_405_1 z), (v_409_1 z), (v_827_1 z), (v_831_1 z)]
 theorem g_869 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_448) (s_869 z) pmNode_448 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_448, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_869_1 z, r_869_0 z]
     exact (h_409_1 z z_).trans (h_405_1 z z_).symm
   · rw [r_869_2 z, r_869_0 z]
     exact (h_827_1 z z_).trans (h_405_1 z z_).symm
   · rw [r_869_3 z, r_869_0 z]
     exact (h_831_1 z z_).trans (h_405_1 z z_).symm
 #a g_869
 def s_870 (z : Store) : Store := storeSet (s_869 z) [(325, cross_dp_wred [((s_869 z) 21), ((s_869 z) 324), ((s_869 z) 627), ((s_869 z) 930)])]
 theorem t_869 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_448) (pmPeers pmNode_448) (s_869 z) pmNode_448 none = some (s_870 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_448) (s_869 z) pmNode_448 = _
   rw [wredStep, if_pos ⟨by decide, g_869 z z_⟩]
   rfl
 #a t_869
 theorem k_869 (z : Store) (tid : Tid) (h : tid ∉ [325]) : (s_870 z) tid = (s_869 z) tid := by
   unfold s_870
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_869
 theorem w_869_0 (z : Store) : (s_870 z) 325 = v_869_0 z := by
   unfold s_870
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_869_0, r_869_0 z, r_869_1 z, r_869_2 z, r_869_3 z] <;> rfl
 #a w_869_0
 theorem h_869_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_869_0 z).shape = [64] := by
   unfold v_869_0
   rw [tensorSum_shape]
   exact h_405_1 z z_
 #a h_869_0
 attribute [local irreducible] v_869_0
 attribute [local irreducible] s_870
 theorem r_870_0 (z : Store) : (s_870 z) 23 = (v_405_2 z) := pR (k_869 z) (pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (k_847 z) (pR (k_846 z) (pR (k_845 z) (r_845_0 z)))))))
 #a r_870_0
 theorem r_870_1 (z : Store) : (s_870 z) 326 = (v_409_2 z) := pR (k_869 z) (pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (k_847 z) (pR (k_846 z) (pR (k_845 z) (r_845_1 z)))))))
 #a r_870_1
 theorem r_870_2 (z : Store) : (s_870 z) 629 = (v_827_2 z) := pR (k_869 z) (pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (k_847 z) (pR (k_846 z) (pR (k_845 z) (r_845_2 z)))))))
 #a r_870_2
 theorem r_870_3 (z : Store) : (s_870 z) 932 = (v_831_2 z) := pR (k_869 z) (pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (k_847 z) (pR (k_846 z) (pR (k_845 z) (r_845_3 z)))))))
 #a r_870_3
 def v_870_0 (z : Store) : Tensor := cross_dp_wred [(v_405_2 z), (v_409_2 z), (v_827_2 z), (v_831_2 z)]
 theorem g_870 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_449) (s_870 z) pmNode_449 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_449, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_870_1 z, r_870_0 z]
     exact (h_409_2 z z_).trans (h_405_2 z z_).symm
   · rw [r_870_2 z, r_870_0 z]
     exact (h_827_2 z z_).trans (h_405_2 z z_).symm
   · rw [r_870_3 z, r_870_0 z]
     exact (h_831_2 z z_).trans (h_405_2 z z_).symm
 #a g_870
 def s_871 (z : Store) : Store := storeSet (s_870 z) [(327, cross_dp_wred [((s_870 z) 23), ((s_870 z) 326), ((s_870 z) 629), ((s_870 z) 932)])]
 theorem t_870 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_449) (pmPeers pmNode_449) (s_870 z) pmNode_449 none = some (s_871 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_449) (s_870 z) pmNode_449 = _
   rw [wredStep, if_pos ⟨by decide, g_870 z z_⟩]
   rfl
 #a t_870
 theorem k_870 (z : Store) (tid : Tid) (h : tid ∉ [327]) : (s_871 z) tid = (s_870 z) tid := by
   unfold s_871
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_870
 theorem w_870_0 (z : Store) : (s_871 z) 327 = v_870_0 z := by
   unfold s_871
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_870_0, r_870_0 z, r_870_1 z, r_870_2 z, r_870_3 z] <;> rfl
 #a w_870_0
 theorem h_870_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_870_0 z).shape = [64] := by
   unfold v_870_0
   rw [tensorSum_shape]
   exact h_405_2 z z_
 #a h_870_0
 attribute [local irreducible] v_870_0
 attribute [local irreducible] s_871
 theorem r_871_0 (z : Store) : (s_871 z) 59 = (v_237_1 z) := pR (k_870 z) (pR (k_869 z) (pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (k_847 z) (pR (k_846 z) (r_846_0 z)))))))
 #a r_871_0
 theorem r_871_1 (z : Store) : (s_871 z) 362 = (v_239_1 z) := pR (k_870 z) (pR (k_869 z) (pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (k_847 z) (pR (k_846 z) (r_846_1 z)))))))
 #a r_871_1
 theorem r_871_2 (z : Store) : (s_871 z) 665 = (v_659_1 z) := pR (k_870 z) (pR (k_869 z) (pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (k_847 z) (pR (k_846 z) (r_846_2 z)))))))
 #a r_871_2
 theorem r_871_3 (z : Store) : (s_871 z) 968 = (v_661_1 z) := pR (k_870 z) (pR (k_869 z) (pR (k_868 z) (pR (n_864_868 z) (pR (n_848_864 z) (pR (k_847 z) (pR (k_846 z) (r_846_3 z)))))))
 #a r_871_3
 def v_871_0 (z : Store) : Tensor := cross_dp_wred [(v_237_1 z), (v_239_1 z), (v_659_1 z), (v_661_1 z)]
 theorem g_871 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_450) (s_871 z) pmNode_450 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_450, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_871_1 z, r_871_0 z]
     exact (h_239_1 z z_).trans (h_237_1 z z_).symm
   · rw [r_871_2 z, r_871_0 z]
     exact (h_659_1 z z_).trans (h_237_1 z z_).symm
   · rw [r_871_3 z, r_871_0 z]
     exact (h_661_1 z z_).trans (h_237_1 z z_).symm
 #a g_871
 def s_872 (z : Store) : Store := storeSet (s_871 z) [(363, cross_dp_wred [((s_871 z) 59), ((s_871 z) 362), ((s_871 z) 665), ((s_871 z) 968)])]
 theorem t_871 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_450) (pmPeers pmNode_450) (s_871 z) pmNode_450 none = some (s_872 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_450) (s_871 z) pmNode_450 = _
   rw [wredStep, if_pos ⟨by decide, g_871 z z_⟩]
   rfl
 #a t_871
 theorem k_871 (z : Store) (tid : Tid) (h : tid ∉ [363]) : (s_872 z) tid = (s_871 z) tid := by
   unfold s_872
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_871
 theorem w_871_0 (z : Store) : (s_872 z) 363 = v_871_0 z := by
   unfold s_872
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_871_0, r_871_0 z, r_871_1 z, r_871_2 z, r_871_3 z] <;> rfl
 #a w_871_0
 theorem h_871_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_871_0 z).shape = [64] := by
   unfold v_871_0
   rw [tensorSum_shape]
   exact h_237_1 z z_
 #a h_871_0
 attribute [local irreducible] v_871_0
 attribute [local irreducible] s_872
 theorem n_868_872 (z : Store) (tid : Tid) (h : tid ∉ ([323, 325, 327, 363] : List Tid)) : (s_872 z) tid = (s_868 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_868 z) (k_869 z)) (pF _ _ _ _ _ (k_870 z) (k_871 z)) tid h
 #a n_868_872
 theorem n_864_872 (z : Store) (tid : Tid) (h : tid ∉ ([74, 49, 52, 55, 323, 325, 327, 363] : List Tid)) : (s_872 z) tid = (s_864 z) tid := by
   exact pF _ _ _ _ _ (n_864_868 z) (n_868_872 z) tid h
 #a n_864_872
 theorem r_872_0 (z : Store) : (s_872 z) 25 = (v_403_1 z) := pR (n_864_872 z) (pR (n_848_864 z) (pR (k_847 z) (r_847_0 z)))
 #a r_872_0
 theorem r_872_1 (z : Store) : (s_872 z) 328 = (v_407_1 z) := pR (n_864_872 z) (pR (n_848_864 z) (pR (k_847 z) (r_847_1 z)))
 #a r_872_1
 theorem r_872_2 (z : Store) : (s_872 z) 631 = (v_825_1 z) := pR (n_864_872 z) (pR (n_848_864 z) (pR (k_847 z) (r_847_2 z)))
 #a r_872_2
 theorem r_872_3 (z : Store) : (s_872 z) 934 = (v_829_1 z) := pR (n_864_872 z) (pR (n_848_864 z) (pR (k_847 z) (r_847_3 z)))
 #a r_872_3
 def v_872_0 (z : Store) : Tensor := cross_dp_wred [(v_403_1 z), (v_407_1 z), (v_825_1 z), (v_829_1 z)]
 theorem g_872 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_451) (s_872 z) pmNode_451 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_451, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_872_1 z, r_872_0 z]
     exact (h_407_1 z z_).trans (h_403_1 z z_).symm
   · rw [r_872_2 z, r_872_0 z]
     exact (h_825_1 z z_).trans (h_403_1 z z_).symm
   · rw [r_872_3 z, r_872_0 z]
     exact (h_829_1 z z_).trans (h_403_1 z z_).symm
 #a g_872
 def s_873 (z : Store) : Store := storeSet (s_872 z) [(329, cross_dp_wred [((s_872 z) 25), ((s_872 z) 328), ((s_872 z) 631), ((s_872 z) 934)])]
 theorem t_872 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_451) (pmPeers pmNode_451) (s_872 z) pmNode_451 none = some (s_873 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_451) (s_872 z) pmNode_451 = _
   rw [wredStep, if_pos ⟨by decide, g_872 z z_⟩]
   rfl
 #a t_872
 theorem k_872 (z : Store) (tid : Tid) (h : tid ∉ [329]) : (s_873 z) tid = (s_872 z) tid := by
   unfold s_873
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_872
 theorem w_872_0 (z : Store) : (s_873 z) 329 = v_872_0 z := by
   unfold s_873
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_872_0, r_872_0 z, r_872_1 z, r_872_2 z, r_872_3 z] <;> rfl
 #a w_872_0
 theorem h_872_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_872_0 z).shape = [64, 64] := by
   unfold v_872_0
   rw [tensorSum_shape]
   exact h_403_1 z z_
 #a h_872_0
 attribute [local irreducible] v_872_0
 attribute [local irreducible] s_873
 theorem r_873_0 (z : Store) : (s_873 z) 61 = (v_237_2 z) := pR (k_872 z) (pR (n_864_872 z) (pR (n_848_864 z) (r_848_0 z)))
 #a r_873_0
 theorem r_873_1 (z : Store) : (s_873 z) 364 = (v_239_2 z) := pR (k_872 z) (pR (n_864_872 z) (pR (n_848_864 z) (r_848_1 z)))
 #a r_873_1
 theorem r_873_2 (z : Store) : (s_873 z) 667 = (v_659_2 z) := pR (k_872 z) (pR (n_864_872 z) (pR (n_848_864 z) (r_848_2 z)))
 #a r_873_2
 theorem r_873_3 (z : Store) : (s_873 z) 970 = (v_661_2 z) := pR (k_872 z) (pR (n_864_872 z) (pR (n_848_864 z) (r_848_3 z)))
 #a r_873_3
 def v_873_0 (z : Store) : Tensor := cross_dp_wred [(v_237_2 z), (v_239_2 z), (v_659_2 z), (v_661_2 z)]
 theorem g_873 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_452) (s_873 z) pmNode_452 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_452, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_873_1 z, r_873_0 z]
     exact (h_239_2 z z_).trans (h_237_2 z z_).symm
   · rw [r_873_2 z, r_873_0 z]
     exact (h_659_2 z z_).trans (h_237_2 z z_).symm
   · rw [r_873_3 z, r_873_0 z]
     exact (h_661_2 z z_).trans (h_237_2 z z_).symm
 #a g_873
 def s_874 (z : Store) : Store := storeSet (s_873 z) [(365, cross_dp_wred [((s_873 z) 61), ((s_873 z) 364), ((s_873 z) 667), ((s_873 z) 970)])]
 theorem t_873 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_452) (pmPeers pmNode_452) (s_873 z) pmNode_452 none = some (s_874 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_452) (s_873 z) pmNode_452 = _
   rw [wredStep, if_pos ⟨by decide, g_873 z z_⟩]
   rfl
 #a t_873
 theorem k_873 (z : Store) (tid : Tid) (h : tid ∉ [365]) : (s_874 z) tid = (s_873 z) tid := by
   unfold s_874
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_873
 theorem w_873_0 (z : Store) : (s_874 z) 365 = v_873_0 z := by
   unfold s_874
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_873_0, r_873_0 z, r_873_1 z, r_873_2 z, r_873_3 z] <;> rfl
 #a w_873_0
 theorem h_873_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_873_0 z).shape = [64] := by
   unfold v_873_0
   rw [tensorSum_shape]
   exact h_237_2 z z_
 #a h_873_0
 attribute [local irreducible] v_873_0
 attribute [local irreducible] s_874
 record_prefix_opacity v_867_0 s_868 v_868_0 s_869 v_869_0 s_870 v_870_0 s_871 v_871_0 s_872 v_872_0 s_873 v_873_0 s_874

 end
 end TrainVerify.Denote.RuntimeWorld
