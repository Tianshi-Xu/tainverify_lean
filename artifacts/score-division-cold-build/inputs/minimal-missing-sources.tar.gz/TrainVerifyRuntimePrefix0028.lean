import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0027
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_217_0 (z : Store) : (s_217 z) 278 = (v_216_0 z) := w_216_0 z
 #a r_217_0
 theorem r_217_1 (z : Store) : (s_217 z) 80 = (v_204_0 z) := pR (k_216 z) (pR (n_208_216 z) (pR (k_207 z) (pR (k_206 z) (pR (k_205 z) (r_205_0 z)))))
 #a r_217_1
 theorem r_217_2 (z : Store) : (s_217 z) 72 = (z 72) := pR (k_216 z) (pR (n_208_216 z) (pR (k_207 z) (pR (k_206 z) (pR (k_205 z) (r_205_1 z)))))
 #a r_217_2
 def v_217_0 (z : Store) : Tensor := (bw_linear (v_216_0 z) (v_204_0 z) (z 72)).1
 def v_217_1 (z : Store) : Tensor := (bw_linear (v_216_0 z) (v_204_0 z) (z 72)).2
 def s_218 (z : Store) : Store := storeSet (s_217 z) [(279, (bw_linear ((s_217 z) 278) ((s_217 z) 80) ((s_217 z) 72)).1), (73, (bw_linear ((s_217 z) 278) ((s_217 z) 80) ((s_217 z) 72)).2)]
 theorem t_217 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_109) (pmPeers pmNode_109) (s_217 z) pmNode_109 none = some (s_218 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_217
 theorem k_217 (z : Store) (tid : Tid) (h : tid ∉ [279, 73]) : (s_218 z) tid = (s_217 z) tid := by
   unfold s_218
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_217
 theorem w_217_0 (z : Store) : (s_218 z) 279 = v_217_0 z := by
   unfold s_218
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_217_0, r_217_0 z, r_217_1 z, r_217_2 z] <;> rfl
 #a w_217_0
 theorem h_217_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_217_0 z).shape = [1, 16, 64] := by
   unfold v_217_0
   exact bw_linear_3d_fst_shape 1 16 128 64 (v_216_0 z) (v_204_0 z) (z 72) (h_216_0 z z_) (h_204_0 z z_) (i_48 z z_)
 #a h_217_0
 attribute [local irreducible] v_217_0
 theorem w_217_1 (z : Store) : (s_218 z) 73 = v_217_1 z := by
   unfold s_218
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_217_1, r_217_0 z, r_217_1 z, r_217_2 z] <;> rfl
 #a w_217_1
 theorem h_217_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_217_1 z).shape = [128, 64] := by
   unfold v_217_1
   exact bw_linear_3d_snd_shape 1 16 128 64 (v_216_0 z) (v_204_0 z) (z 72) (h_216_0 z z_) (h_204_0 z z_) (i_48 z z_)
 #a h_217_1
 attribute [local irreducible] v_217_1
 attribute [local irreducible] s_218
 theorem r_218_0 (z : Store) : (s_218 z) 282 = (v_213_0 z) := pR (k_217 z) (pR (k_216 z) (r_216_0 z))
 #a r_218_0
 theorem r_218_1 (z : Store) : (s_218 z) 585 = (v_215_0 z) := pR (k_217 z) (pR (k_216 z) (r_216_1 z))
 #a r_218_1
 def v_218_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_213_0 z), (v_215_0 z)]
 theorem g_218 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_344) (s_218 z) pmNode_344 1 2 582 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 256], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_344, r_218_0 z, r_218_1 z, h_213_0 z z_, h_215_0 z z_]
 #a g_218
 def s_219 (z : Store) : Store := pL [0, 1] (s_218 z) pmNode_344 1 2
 theorem t_218 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_344) (pmPeers pmNode_344) (s_218 z) pmNode_344 none = some (s_219 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_344) (s_218 z) pmNode_344).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 582 (by decide) (g_218 z z_)]
   rfl
 #a t_218
 theorem k_218 (z : Store) (tid : Tid) (h : tid ∉ [582]) : (s_219 z) tid = (s_218 z) tid := by
   unfold s_219
   dsimp only [pL, pmNode_344, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_218
 theorem w_218_0 (z : Store) : (s_219 z) 582 = v_218_0 z := by
   unfold s_219
   dsimp only [pL, pmNode_344, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_218_0, r_218_0 z, r_218_1 z] <;> rfl
 #a w_218_0
 theorem h_218_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_218_0 z).shape = [1, 16, 128] := by
   unfold v_218_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_213_0 z z_]
 #a h_218_0
 attribute [local irreducible] v_218_0
 attribute [local irreducible] s_219
 theorem r_219_0 (z : Store) : (s_219 z) 582 = (v_218_0 z) := w_218_0 z
 #a r_219_0
 theorem r_219_1 (z : Store) : (s_219 z) 383 = (v_206_0 z) := pR (k_218 z) (pR (k_217 z) (pR (k_216 z) (pR (n_208_216 z) (pR (k_207 z) (r_207_0 z)))))
 #a r_219_1
 theorem r_219_2 (z : Store) : (s_219 z) 375 = (z 375) := pR (k_218 z) (pR (k_217 z) (pR (k_216 z) (pR (n_208_216 z) (pR (k_207 z) (r_207_1 z)))))
 #a r_219_2
 def v_219_0 (z : Store) : Tensor := (bw_linear (v_218_0 z) (v_206_0 z) (z 375)).1
 def v_219_1 (z : Store) : Tensor := (bw_linear (v_218_0 z) (v_206_0 z) (z 375)).2
 def s_220 (z : Store) : Store := storeSet (s_219 z) [(581, (bw_linear ((s_219 z) 582) ((s_219 z) 383) ((s_219 z) 375)).1), (376, (bw_linear ((s_219 z) 582) ((s_219 z) 383) ((s_219 z) 375)).2)]
 theorem t_219 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_345) (pmPeers pmNode_345) (s_219 z) pmNode_345 none = some (s_220 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_219
 theorem k_219 (z : Store) (tid : Tid) (h : tid ∉ [581, 376]) : (s_220 z) tid = (s_219 z) tid := by
   unfold s_220
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_219
 theorem w_219_0 (z : Store) : (s_220 z) 581 = v_219_0 z := by
   unfold s_220
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_219_0, r_219_0 z, r_219_1 z, r_219_2 z] <;> rfl
 #a w_219_0
 theorem h_219_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_219_0 z).shape = [1, 16, 64] := by
   unfold v_219_0
   exact bw_linear_3d_fst_shape 1 16 128 64 (v_218_0 z) (v_206_0 z) (z 375) (h_218_0 z z_) (h_206_0 z z_) (i_49 z z_)
 #a h_219_0
 attribute [local irreducible] v_219_0
 theorem w_219_1 (z : Store) : (s_220 z) 376 = v_219_1 z := by
   unfold s_220
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_219_1, r_219_0 z, r_219_1 z, r_219_2 z] <;> rfl
 #a w_219_1
 theorem h_219_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_219_1 z).shape = [128, 64] := by
   unfold v_219_1
   exact bw_linear_3d_snd_shape 1 16 128 64 (v_218_0 z) (v_206_0 z) (z 375) (h_218_0 z z_) (h_206_0 z z_) (i_49 z z_)
 #a h_219_1
 attribute [local irreducible] v_219_1
 attribute [local irreducible] s_220
 theorem r_220_0 (z : Store) : (s_220 z) 279 = (v_217_0 z) := pR (k_219 z) (pR (k_218 z) (w_217_0 z))
 #a r_220_0
 theorem r_220_1 (z : Store) : (s_220 z) 581 = (v_219_0 z) := w_219_0 z
 #a r_220_1
 def v_220_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_217_0 z), (v_219_0 z)]
 def s_221 (z : Store) : Store := storeSet (s_220 z) [(276, reduceScatterPrimDimN 1 2 0 [((s_220 z) 279), ((s_220 z) 581)])]
 theorem t_220 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_110) (pmPeers pmNode_110) (s_220 z) pmNode_110 none = some (s_221 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_220 z) pmNode_110 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_220
 theorem k_220 (z : Store) (tid : Tid) (h : tid ∉ [276]) : (s_221 z) tid = (s_220 z) tid := by
   unfold s_221
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_220
 theorem w_220_0 (z : Store) : (s_221 z) 276 = v_220_0 z := by
   unfold s_221
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_220_0, r_220_0 z, r_220_1 z] <;> rfl
 #a w_220_0
 theorem h_220_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_220_0 z).shape = [1, 8, 64] := by
   unfold v_220_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_217_0 z) rfl]
     exact h_217_0 z z_
   · decide
 #a h_220_0
 attribute [local irreducible] v_220_0
 attribute [local irreducible] s_221
 theorem n_216_220 (z : Store) (tid : Tid) (h : tid ∉ ([278, 279, 73, 582, 581, 376] : List Tid)) : (s_220 z) tid = (s_216 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_216 z) (k_217 z)) (pF _ _ _ _ _ (k_218 z) (k_219 z)) tid h
 #a n_216_220
 theorem r_221_0 (z : Store) : (s_221 z) 276 = (v_220_0 z) := w_220_0 z
 #a r_221_0
 theorem r_221_1 (z : Store) : (s_221 z) 272 = (v_196_0 z) := pR (k_220 z) (pR (n_216_220 z) (pR (n_208_216 z) (pR (n_200_208 z) (pR (k_199 z) (pR (k_198 z) (pR (k_197 z) (r_197_0 z)))))))
 #a r_221_1
 theorem r_221_2 (z : Store) : (s_221 z) 14 = (z 14) := pR (k_220 z) (pR (n_216_220 z) (pR (n_208_216 z) (pR (n_200_208 z) (pR (k_199 z) (pR (k_198 z) (pR (k_197 z) (r_197_1 z)))))))
 #a r_221_2
 theorem r_221_3 (z : Store) : (s_221 z) 15 = (z 15) := pR (k_220 z) (pR (n_216_220 z) (pR (n_208_216 z) (pR (n_200_208 z) (pR (k_199 z) (pR (k_198 z) (pR (k_197 z) (r_197_2 z)))))))
 #a r_221_3
 def v_221_0 (z : Store) : Tensor := (bw_layernorm (v_220_0 z) (v_196_0 z) (z 14) (z 15)).1
 def v_221_1 (z : Store) : Tensor := (bw_layernorm (v_220_0 z) (v_196_0 z) (z 14) (z 15)).2.1
 def v_221_2 (z : Store) : Tensor := (bw_layernorm (v_220_0 z) (v_196_0 z) (z 14) (z 15)).2.2
 def s_222 (z : Store) : Store := storeSet (s_221 z) [(274, (bw_layernorm ((s_221 z) 276) ((s_221 z) 272) ((s_221 z) 14) ((s_221 z) 15)).1), (68, (bw_layernorm ((s_221 z) 276) ((s_221 z) 272) ((s_221 z) 14) ((s_221 z) 15)).2.1), (70, (bw_layernorm ((s_221 z) 276) ((s_221 z) 272) ((s_221 z) 14) ((s_221 z) 15)).2.2)]
 theorem t_221 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_111) (pmPeers pmNode_111) (s_221 z) pmNode_111 none = some (s_222 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_221
 theorem k_221 (z : Store) (tid : Tid) (h : tid ∉ [274, 68, 70]) : (s_222 z) tid = (s_221 z) tid := by
   unfold s_222
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_221
 theorem w_221_0 (z : Store) : (s_222 z) 274 = v_221_0 z := by
   unfold s_222
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_221_0, r_221_0 z, r_221_1 z, r_221_2 z, r_221_3 z] <;> rfl
 #a w_221_0
 theorem h_221_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_221_0 z).shape = [1, 8, 64] := by
   unfold v_221_0
   rw [bw_layernorm_dx_shape (v_220_0 z) (v_196_0 z) (z 14) (z 15) 64 [8, 1] (by rw [h_196_0 z z_]; rfl)]
   exact h_196_0 z z_
 #a h_221_0
 attribute [local irreducible] v_221_0
 theorem w_221_1 (z : Store) : (s_222 z) 68 = v_221_1 z := by
   unfold s_222
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_221_1, r_221_0 z, r_221_1 z, r_221_2 z, r_221_3 z] <;> rfl
 #a w_221_1
 theorem h_221_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_221_1 z).shape = [64] := by
   unfold v_221_1
   rw [bw_layernorm_dw_shape (v_220_0 z) (v_196_0 z) (z 14) (z 15) 64 [8, 1] (by rw [h_196_0 z z_]; rfl)]
   exact i_43 z z_
 #a h_221_1
 attribute [local irreducible] v_221_1
 theorem w_221_2 (z : Store) : (s_222 z) 70 = v_221_2 z := by
   unfold s_222
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_221_2, r_221_0 z, r_221_1 z, r_221_2 z, r_221_3 z] <;> rfl
 #a w_221_2
 theorem h_221_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_221_2 z).shape = [64] := by
   unfold v_221_2
   rw [bw_layernorm_db_shape (v_220_0 z) (v_196_0 z) (z 14) (z 15) 64 [8, 1] (by rw [h_196_0 z z_]; rfl)]
   exact i_44 z z_
 #a h_221_2
 attribute [local irreducible] v_221_2
 attribute [local irreducible] s_222
 theorem r_222_0 (z : Store) : (s_222 z) 274 = (v_221_0 z) := w_221_0 z
 #a r_222_0
 theorem r_222_1 (z : Store) : (s_222 z) 271 = (v_195_0 z) := pR (k_221 z) (pR (k_220 z) (pR (n_216_220 z) (pR (n_208_216 z) (pR (n_200_208 z) (pR (n_196_200 z) (r_196_0 z))))))
 #a r_222_1
 theorem r_222_2 (z : Store) : (s_222 z) 269 = (v_194_0 z) := pR (k_221 z) (pR (k_220 z) (pR (n_216_220 z) (pR (n_208_216 z) (pR (n_200_208 z) (pR (n_196_200 z) (r_196_1 z))))))
 #a r_222_2
 def v_222_0 (z : Store) : Tensor := (bw_add2 (v_221_0 z) (v_195_0 z) (v_194_0 z)).1
 def v_222_1 (z : Store) : Tensor := (bw_add2 (v_221_0 z) (v_195_0 z) (v_194_0 z)).2
 def s_223 (z : Store) : Store := storeSet (s_222 z) [(273, (bw_add2 ((s_222 z) 274) ((s_222 z) 271) ((s_222 z) 269)).1), (270, (bw_add2 ((s_222 z) 274) ((s_222 z) 271) ((s_222 z) 269)).2)]
 theorem t_222 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_112) (pmPeers pmNode_112) (s_222 z) pmNode_112 none = some (s_223 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_222
 theorem k_222 (z : Store) (tid : Tid) (h : tid ∉ [273, 270]) : (s_223 z) tid = (s_222 z) tid := by
   unfold s_223
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_222
 theorem w_222_0 (z : Store) : (s_223 z) 273 = v_222_0 z := by
   unfold s_223
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_222_0, r_222_0 z, r_222_1 z, r_222_2 z] <;> rfl
 #a w_222_0
 theorem h_222_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_222_0 z).shape = [1, 8, 64] := by
   unfold v_222_0
   exact h_195_0 z z_
 #a h_222_0
 attribute [local irreducible] v_222_0
 theorem w_222_1 (z : Store) : (s_223 z) 270 = v_222_1 z := by
   unfold s_223
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_222_1, r_222_0 z, r_222_1 z, r_222_2 z] <;> rfl
 #a w_222_1
 theorem h_222_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_222_1 z).shape = [1, 8, 64] := by
   unfold v_222_1
   exact h_194_0 z z_
 #a h_222_1
 attribute [local irreducible] v_222_1
 attribute [local irreducible] s_223
 theorem r_223_0 (z : Store) : (s_223 z) 279 = (v_217_0 z) := pR (k_222 z) (pR (k_221 z) (pR (k_220 z) (r_220_0 z)))
 #a r_223_0
 theorem r_223_1 (z : Store) : (s_223 z) 581 = (v_219_0 z) := pR (k_222 z) (pR (k_221 z) (pR (k_220 z) (r_220_1 z)))
 #a r_223_1
 def v_223_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_217_0 z), (v_219_0 z)]
 def s_224 (z : Store) : Store := storeSet (s_223 z) [(579, reduceScatterPrimDimN 1 2 1 [((s_223 z) 279), ((s_223 z) 581)])]
 theorem t_223 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_346) (pmPeers pmNode_346) (s_223 z) pmNode_346 none = some (s_224 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_223 z) pmNode_346 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_223
 theorem k_223 (z : Store) (tid : Tid) (h : tid ∉ [579]) : (s_224 z) tid = (s_223 z) tid := by
   unfold s_224
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_223
 theorem w_223_0 (z : Store) : (s_224 z) 579 = v_223_0 z := by
   unfold s_224
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_223_0, r_223_0 z, r_223_1 z] <;> rfl
 #a w_223_0
 theorem h_223_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_223_0 z).shape = [1, 8, 64] := by
   unfold v_223_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_217_0 z) rfl]
     exact h_217_0 z z_
   · decide
 #a h_223_0
 attribute [local irreducible] v_223_0
 attribute [local irreducible] s_224
 theorem n_220_224 (z : Store) (tid : Tid) (h : tid ∉ ([276, 274, 68, 70, 273, 270, 579] : List Tid)) : (s_224 z) tid = (s_220 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_220 z) (k_221 z)) (pF _ _ _ _ _ (k_222 z) (k_223 z)) tid h
 #a n_220_224
 theorem n_216_224 (z : Store) (tid : Tid) (h : tid ∉ ([278, 279, 73, 582, 581, 376, 276, 274, 68, 70, 273, 270, 579] : List Tid)) : (s_224 z) tid = (s_216 z) tid := by
   exact pF _ _ _ _ _ (n_216_220 z) (n_220_224 z) tid h
 #a n_216_224
 record_prefix_opacity v_217_0 v_217_1 s_218 v_218_0 s_219 v_219_0 v_219_1 s_220 v_220_0 s_221 v_221_0 v_221_1 v_221_2 s_222 v_222_0 v_222_1 s_223 v_223_0 s_224

 end
 end TrainVerify.Denote.RuntimeWorld
