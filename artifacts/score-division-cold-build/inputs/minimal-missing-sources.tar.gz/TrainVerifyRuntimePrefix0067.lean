import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0066
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_526_0 (z : Store) : (s_526 z) 897 = (v_522_0 z) := pR (k_525 z) (pR (k_524 z) (pR (k_523 z) (w_522_0 z)))
 #a r_526_0
 theorem r_526_1 (z : Store) : (s_526 z) 1200 = (v_525_0 z) := w_525_0 z
 #a r_526_1
 def v_526_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_522_0 z), (v_525_0 z)]
 theorem g_526 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_524) (s_526 z) pmNode_524 2 1 791 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_524, r_526_0 z, r_526_1 z, h_522_0 z z_, h_525_0 z z_]
 #a g_526
 def s_527 (z : Store) : Store := pL [2, 3] (s_526 z) pmNode_524 2 1
 theorem t_526 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_524) (pmPeers pmNode_524) (s_526 z) pmNode_524 none = some (s_527 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_524) (s_526 z) pmNode_524).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 791 (by decide) (g_526 z z_)]
   rfl
 #a t_526
 theorem k_526 (z : Store) (tid : Tid) (h : tid ∉ [791]) : (s_527 z) tid = (s_526 z) tid := by
   unfold s_527
   dsimp only [pL, pmNode_524, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_526
 theorem w_526_0 (z : Store) : (s_527 z) 791 = v_526_0 z := by
   unfold s_527
   dsimp only [pL, pmNode_524, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_526_0, r_526_0 z, r_526_1 z] <;> rfl
 #a w_526_0
 theorem h_526_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_526_0 z).shape = [1, 8, 64] := by
   unfold v_526_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_522_0 z z_]
 #a h_526_0
 attribute [local irreducible] v_526_0
 attribute [local irreducible] s_527
 theorem r_527_0 (z : Store) : (s_527 z) 791 = (v_526_0 z) := w_526_0 z
 #a r_527_0
 theorem r_527_1 (z : Store) : (s_527 z) 615 = (z 615) := pR (k_526 z) (pR (k_525 z) (pR (k_524 z) (pR (n_520_524 z) (pR (n_512_520 z) (pR (n_0_512 z) (e_74 z))))))
 #a r_527_1
 theorem r_527_2 (z : Store) : (s_527 z) 616 = (z 616) := pR (k_526 z) (pR (k_525 z) (pR (k_524 z) (pR (n_520_524 z) (pR (n_512_520 z) (pR (n_0_512 z) (e_75 z))))))
 #a r_527_2
 def v_527_0 (z : Store) : Tensor := fw_layernorm (v_526_0 z) (z 615) (z 616)
 def s_528 (z : Store) : Store := storeSet (s_527 z) [(792, fw_layernorm ((s_527 z) 791) ((s_527 z) 615) ((s_527 z) 616))]
 theorem t_527 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_525) (pmPeers pmNode_525) (s_527 z) pmNode_525 none = some (s_528 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_527
 theorem k_527 (z : Store) (tid : Tid) (h : tid ∉ [792]) : (s_528 z) tid = (s_527 z) tid := by
   unfold s_528
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_527
 theorem w_527_0 (z : Store) : (s_528 z) 792 = v_527_0 z := by
   unfold s_528
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_527_0, r_527_0 z, r_527_1 z, r_527_2 z] <;> rfl
 #a w_527_0
 theorem h_527_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_527_0 z).shape = [1, 8, 64] := by
   unfold v_527_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_526_0 z z_
 #a h_527_0
 attribute [local irreducible] v_527_0
 attribute [local irreducible] s_528
 theorem r_528_0 (z : Store) : (s_528 z) 792 = (v_527_0 z) := w_527_0 z
 #a r_528_0
 def v_528_0 (z : Store) : Tensor := (v_527_0 z)
 def v_528_1 (z : Store) : Tensor := (v_527_0 z)
 def v_528_2 (z : Store) : Tensor := (v_527_0 z)
 def s_529 (z : Store) : Store := storeSet (s_528 z) [(899, ((s_528 z) 792)), (901, ((s_528 z) 792)), (903, ((s_528 z) 792))]
 theorem t_528 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_526) (pmPeers pmNode_526) (s_528 z) pmNode_526 none = some (s_529 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_528
 theorem k_528 (z : Store) (tid : Tid) (h : tid ∉ [899, 901, 903]) : (s_529 z) tid = (s_528 z) tid := by
   unfold s_529
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_528
 theorem w_528_0 (z : Store) : (s_529 z) 899 = v_528_0 z := by
   unfold s_529
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_528_0, r_528_0 z] <;> rfl
 #a w_528_0
 theorem h_528_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_528_0 z).shape = [1, 8, 64] := by
   unfold v_528_0
   exact h_527_0 z z_
 #a h_528_0
 attribute [local irreducible] v_528_0
 theorem w_528_1 (z : Store) : (s_529 z) 901 = v_528_1 z := by
   unfold s_529
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_528_1, r_528_0 z] <;> rfl
 #a w_528_1
 theorem h_528_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_528_1 z).shape = [1, 8, 64] := by
   unfold v_528_1
   exact h_527_0 z z_
 #a h_528_1
 attribute [local irreducible] v_528_1
 theorem w_528_2 (z : Store) : (s_529 z) 903 = v_528_2 z := by
   unfold s_529
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_528_2, r_528_0 z] <;> rfl
 #a w_528_2
 theorem h_528_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_528_2 z).shape = [1, 8, 64] := by
   unfold v_528_2
   exact h_527_0 z z_
 #a h_528_2
 attribute [local irreducible] v_528_2
 attribute [local irreducible] s_529
 theorem r_529_0 (z : Store) : (s_529 z) 897 = (v_522_0 z) := pR (k_528 z) (pR (k_527 z) (pR (k_526 z) (r_526_0 z)))
 #a r_529_0
 theorem r_529_1 (z : Store) : (s_529 z) 1200 = (v_525_0 z) := pR (k_528 z) (pR (k_527 z) (pR (k_526 z) (r_526_1 z)))
 #a r_529_1
 def v_529_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_522_0 z), (v_525_0 z)]
 theorem g_529 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_760) (s_529 z) pmNode_760 2 1 1094 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_760, r_529_0 z, r_529_1 z, h_522_0 z z_, h_525_0 z z_]
 #a g_529
 def s_530 (z : Store) : Store := pL [2, 3] (s_529 z) pmNode_760 2 1
 theorem t_529 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_760) (pmPeers pmNode_760) (s_529 z) pmNode_760 none = some (s_530 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_760) (s_529 z) pmNode_760).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1094 (by decide) (g_529 z z_)]
   rfl
 #a t_529
 theorem k_529 (z : Store) (tid : Tid) (h : tid ∉ [1094]) : (s_530 z) tid = (s_529 z) tid := by
   unfold s_530
   dsimp only [pL, pmNode_760, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_529
 theorem w_529_0 (z : Store) : (s_530 z) 1094 = v_529_0 z := by
   unfold s_530
   dsimp only [pL, pmNode_760, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_529_0, r_529_0 z, r_529_1 z] <;> rfl
 #a w_529_0
 theorem h_529_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_529_0 z).shape = [1, 8, 64] := by
   unfold v_529_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_522_0 z z_]
 #a h_529_0
 attribute [local irreducible] v_529_0
 attribute [local irreducible] s_530
 theorem n_524_528 (z : Store) (tid : Tid) (h : tid ∉ ([1090, 1200, 1161, 791, 792] : List Tid)) : (s_528 z) tid = (s_524 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_524 z) (k_525 z)) (pF _ _ _ _ _ (k_526 z) (k_527 z)) tid h
 #a n_524_528
 theorem n_520_528 (z : Store) (tid : Tid) (h : tid ∉ ([786, 787, 897, 858, 1089, 1090, 1200, 1161, 791, 792] : List Tid)) : (s_528 z) tid = (s_520 z) tid := by
   exact pF _ _ _ _ _ (n_520_524 z) (n_524_528 z) tid h
 #a n_520_528
 theorem n_512_528 (z : Store) (tid : Tid) (h : tid ∉ ([779, 781, 783, 1078, 1079, 1082, 1084, 1086, 786, 787, 897, 858, 1089, 1090, 1200, 1161, 791, 792] : List Tid)) : (s_528 z) tid = (s_512 z) tid := by
   exact pF _ _ _ _ _ (n_512_520 z) (n_520_528 z) tid h
 #a n_512_528
 theorem r_530_0 (z : Store) : (s_530 z) 1094 = (v_529_0 z) := w_529_0 z
 #a r_530_0
 theorem r_530_1 (z : Store) : (s_530 z) 918 = (z 918) := pR (k_529 z) (pR (k_528 z) (pR (n_512_528 z) (pR (n_0_512 z) (e_76 z))))
 #a r_530_1
 theorem r_530_2 (z : Store) : (s_530 z) 919 = (z 919) := pR (k_529 z) (pR (k_528 z) (pR (n_512_528 z) (pR (n_0_512 z) (e_77 z))))
 #a r_530_2
 def v_530_0 (z : Store) : Tensor := fw_layernorm (v_529_0 z) (z 918) (z 919)
 def s_531 (z : Store) : Store := storeSet (s_530 z) [(1095, fw_layernorm ((s_530 z) 1094) ((s_530 z) 918) ((s_530 z) 919))]
 theorem t_530 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_761) (pmPeers pmNode_761) (s_530 z) pmNode_761 none = some (s_531 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_530
 theorem k_530 (z : Store) (tid : Tid) (h : tid ∉ [1095]) : (s_531 z) tid = (s_530 z) tid := by
   unfold s_531
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_530
 theorem w_530_0 (z : Store) : (s_531 z) 1095 = v_530_0 z := by
   unfold s_531
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_530_0, r_530_0 z, r_530_1 z, r_530_2 z] <;> rfl
 #a w_530_0
 theorem h_530_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_530_0 z).shape = [1, 8, 64] := by
   unfold v_530_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_529_0 z z_
 #a h_530_0
 attribute [local irreducible] v_530_0
 attribute [local irreducible] s_531
 theorem r_531_0 (z : Store) : (s_531 z) 1095 = (v_530_0 z) := w_530_0 z
 #a r_531_0
 def v_531_0 (z : Store) : Tensor := (v_530_0 z)
 def v_531_1 (z : Store) : Tensor := (v_530_0 z)
 def v_531_2 (z : Store) : Tensor := (v_530_0 z)
 def s_532 (z : Store) : Store := storeSet (s_531 z) [(1202, ((s_531 z) 1095)), (1204, ((s_531 z) 1095)), (1206, ((s_531 z) 1095))]
 theorem t_531 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_762) (pmPeers pmNode_762) (s_531 z) pmNode_762 none = some (s_532 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_531
 theorem k_531 (z : Store) (tid : Tid) (h : tid ∉ [1202, 1204, 1206]) : (s_532 z) tid = (s_531 z) tid := by
   unfold s_532
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_531
 theorem w_531_0 (z : Store) : (s_532 z) 1202 = v_531_0 z := by
   unfold s_532
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_531_0, r_531_0 z] <;> rfl
 #a w_531_0
 theorem h_531_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_531_0 z).shape = [1, 8, 64] := by
   unfold v_531_0
   exact h_530_0 z z_
 #a h_531_0
 attribute [local irreducible] v_531_0
 theorem w_531_1 (z : Store) : (s_532 z) 1204 = v_531_1 z := by
   unfold s_532
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_531_1, r_531_0 z] <;> rfl
 #a w_531_1
 theorem h_531_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_531_1 z).shape = [1, 8, 64] := by
   unfold v_531_1
   exact h_530_0 z z_
 #a h_531_1
 attribute [local irreducible] v_531_1
 theorem w_531_2 (z : Store) : (s_532 z) 1206 = v_531_2 z := by
   unfold s_532
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_531_2, r_531_0 z] <;> rfl
 #a w_531_2
 theorem h_531_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_531_2 z).shape = [1, 8, 64] := by
   unfold v_531_2
   exact h_530_0 z z_
 #a h_531_2
 attribute [local irreducible] v_531_2
 attribute [local irreducible] s_532
 theorem r_532_0 (z : Store) : (s_532 z) 899 = (v_528_0 z) := pR (k_531 z) (pR (k_530 z) (pR (k_529 z) (w_528_0 z)))
 #a r_532_0
 theorem r_532_1 (z : Store) : (s_532 z) 1202 = (v_531_0 z) := w_531_0 z
 #a r_532_1
 def v_532_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_528_0 z), (v_531_0 z)]
 def s_533 (z : Store) : Store := storeSet (s_532 z) [(694, allGatherPrimDimN 1 2 0 [((s_532 z) 899), ((s_532 z) 1202)])]
 theorem t_532 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_527) (pmPeers pmNode_527) (s_532 z) pmNode_527 none = some (s_533 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_532 z) pmNode_527 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_532
 theorem k_532 (z : Store) (tid : Tid) (h : tid ∉ [694]) : (s_533 z) tid = (s_532 z) tid := by
   unfold s_533
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_532
 theorem w_532_0 (z : Store) : (s_533 z) 694 = v_532_0 z := by
   unfold s_533
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_532_0, r_532_0 z, r_532_1 z] <;> rfl
 #a w_532_0
 theorem h_532_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_532_0 z).shape = [1, 16, 64] := by
   unfold v_532_0
   exact allGatherPrimDimN_shape 1 2 [(v_528_0 z), (v_531_0 z)] [1, 8, 64] (h_528_0 z z_)
 #a h_532_0
 attribute [local irreducible] v_532_0
 attribute [local irreducible] s_533
 theorem n_528_532 (z : Store) (tid : Tid) (h : tid ∉ ([899, 901, 903, 1094, 1095, 1202, 1204, 1206] : List Tid)) : (s_532 z) tid = (s_528 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_528 z) (k_529 z)) (pF _ _ _ _ _ (k_530 z) (k_531 z)) tid h
 #a n_528_532
 record_prefix_opacity v_526_0 s_527 v_527_0 s_528 v_528_0 v_528_1 v_528_2 s_529 v_529_0 s_530 v_530_0 s_531 v_531_0 v_531_1 v_531_2 s_532 v_532_0 s_533

 end
 end TrainVerify.Denote.RuntimeWorld
