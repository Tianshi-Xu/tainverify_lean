import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0007
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_44_0 (z : Store) : (s_44 z) 115 = (v_33_0 z) := pR (n_40_44 z) (pR (n_36_40 z) (pR (k_35 z) (pR (k_34 z) (w_33_0 z))))
 #a r_44_0
 theorem r_44_1 (z : Store) : (s_44 z) 418 = (v_36_0 z) := pR (n_40_44 z) (pR (k_39 z) (pR (k_38 z) (pR (k_37 z) (w_36_0 z))))
 #a r_44_1
 def v_44_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_33_0 z), (v_36_0 z)]
 theorem g_44 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_25) (s_44 z) pmNode_25 3 1 132 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_25, r_44_0 z, r_44_1 z, h_33_0 z z_, h_36_0 z z_]
 #a g_44
 def s_45 (z : Store) : Store := pL [0, 1] (s_44 z) pmNode_25 3 1
 theorem t_44 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_25) (pmPeers pmNode_25) (s_44 z) pmNode_25 none = some (s_45 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_25) (s_44 z) pmNode_25).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 132 (by decide) (g_44 z z_)]
   rfl
 #a t_44
 theorem k_44 (z : Store) (tid : Tid) (h : tid ∉ [132]) : (s_45 z) tid = (s_44 z) tid := by
   unfold s_45
   dsimp only [pL, pmNode_25, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_44
 theorem w_44_0 (z : Store) : (s_45 z) 132 = v_44_0 z := by
   unfold s_45
   dsimp only [pL, pmNode_25, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_44_0, r_44_0 z, r_44_1 z] <;> rfl
 #a w_44_0
 theorem h_44_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_44_0 z).shape = [1, 2, 16, 16] := by
   unfold v_44_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_33_0 z z_]
 #a h_44_0
 attribute [local irreducible] v_44_0
 attribute [local irreducible] s_45
 theorem r_45_0 (z : Store) : (s_45 z) 118 = (v_34_0 z) := pR (k_44 z) (pR (n_40_44 z) (pR (k_39 z) (pR (k_38 z) (r_38_0 z))))
 #a r_45_0
 theorem r_45_1 (z : Store) : (s_45 z) 421 = (v_37_0 z) := pR (k_44 z) (pR (n_40_44 z) (pR (k_39 z) (pR (k_38 z) (r_38_1 z))))
 #a r_45_1
 def v_45_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 3 [(v_34_0 z), (v_37_0 z)]
 theorem g_45 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_255) (s_45 z) pmNode_255 2 3 423 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_255, r_45_0 z, r_45_1 z, h_34_0 z z_, h_37_0 z z_]
 #a g_45
 def s_46 (z : Store) : Store := pL [0, 1] (s_45 z) pmNode_255 2 3
 theorem t_45 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_255) (pmPeers pmNode_255) (s_45 z) pmNode_255 none = some (s_46 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_255) (s_45 z) pmNode_255).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 3 423 (by decide) (g_45 z z_)]
   rfl
 #a t_45
 theorem k_45 (z : Store) (tid : Tid) (h : tid ∉ [423]) : (s_46 z) tid = (s_45 z) tid := by
   unfold s_46
   dsimp only [pL, pmNode_255, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_45
 theorem w_45_0 (z : Store) : (s_46 z) 423 = v_45_0 z := by
   unfold s_46
   dsimp only [pL, pmNode_255, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_45_0, r_45_0 z, r_45_1 z] <;> rfl
 #a w_45_0
 theorem h_45_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_45_0 z).shape = [1, 16, 4, 8] := by
   unfold v_45_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_34_0 z z_]
 #a h_45_0
 attribute [local irreducible] v_45_0
 attribute [local irreducible] s_46
 theorem r_46_0 (z : Store) : (s_46 z) 423 = (v_45_0 z) := w_45_0 z
 #a r_46_0
 def v_46_0 (z : Store) : Tensor := transposeAxes 1 2 (v_45_0 z)
 def s_47 (z : Store) : Store := storeSet (s_46 z) [(424, transposeAxes 1 2 ((s_46 z) 423))]
 theorem t_46 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_256) (pmPeers pmNode_256) (s_46 z) pmNode_256 none = some (s_47 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_46
 theorem k_46 (z : Store) (tid : Tid) (h : tid ∉ [424]) : (s_47 z) tid = (s_46 z) tid := by
   unfold s_47
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_46
 theorem w_46_0 (z : Store) : (s_47 z) 424 = v_46_0 z := by
   unfold s_47
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_46_0, r_46_0 z] <;> rfl
 #a w_46_0
 theorem h_46_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_46_0 z).shape = [1, 4, 16, 8] := by
   unfold v_46_0
   change listSwapAt _ _ _ = _
   rw [h_45_0 z z_]
   rfl
 #a h_46_0
 attribute [local irreducible] v_46_0
 attribute [local irreducible] s_47
 theorem r_47_0 (z : Store) : (s_47 z) 109 = (v_24_0 z) := pR (k_46 z) (pR (k_45 z) (pR (k_44 z) (pR (n_40_44 z) (r_40_0 z))))
 #a r_47_0
 theorem r_47_1 (z : Store) : (s_47 z) 412 = (v_30_0 z) := pR (k_46 z) (pR (k_45 z) (pR (k_44 z) (pR (n_40_44 z) (r_40_1 z))))
 #a r_47_1
 def v_47_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_24_0 z), (v_30_0 z)]
 theorem g_47 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_257) (s_47 z) pmNode_257 2 1 427 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_257, r_47_0 z, r_47_1 z, h_24_0 z z_, h_30_0 z z_]
 #a g_47
 def s_48 (z : Store) : Store := pL [0, 1] (s_47 z) pmNode_257 2 1
 theorem t_47 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_257) (pmPeers pmNode_257) (s_47 z) pmNode_257 none = some (s_48 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_257) (s_47 z) pmNode_257).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 427 (by decide) (g_47 z z_)]
   rfl
 #a t_47
 theorem k_47 (z : Store) (tid : Tid) (h : tid ∉ [427]) : (s_48 z) tid = (s_47 z) tid := by
   unfold s_48
   dsimp only [pL, pmNode_257, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_47
 theorem w_47_0 (z : Store) : (s_48 z) 427 = v_47_0 z := by
   unfold s_48
   dsimp only [pL, pmNode_257, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_47_0, r_47_0 z, r_47_1 z] <;> rfl
 #a w_47_0
 theorem h_47_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_47_0 z).shape = [1, 8, 64] := by
   unfold v_47_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_24_0 z z_]
 #a h_47_0
 attribute [local irreducible] v_47_0
 attribute [local irreducible] s_48
 theorem r_48_0 (z : Store) : (s_48 z) 427 = (v_47_0 z) := w_47_0 z
 #a r_48_0
 def v_48_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_47_0 z)
 def s_49 (z : Store) : Store := storeSet (s_48 z) [(428, fw_view [1, 8, 4, 16] ((s_48 z) 427))]
 theorem t_48 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_258) (pmPeers pmNode_258) (s_48 z) pmNode_258 none = some (s_49 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_48
 theorem k_48 (z : Store) (tid : Tid) (h : tid ∉ [428]) : (s_49 z) tid = (s_48 z) tid := by
   unfold s_49
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_48
 theorem w_48_0 (z : Store) : (s_49 z) 428 = v_48_0 z := by
   unfold s_49
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_48_0, r_48_0 z] <;> rfl
 #a w_48_0
 theorem h_48_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_48_0 z).shape = [1, 8, 4, 16] := by
   unfold v_48_0
   rfl
 #a h_48_0
 attribute [local irreducible] v_48_0
 attribute [local irreducible] s_49
 theorem r_49_0 (z : Store) : (s_49 z) 428 = (v_48_0 z) := w_48_0 z
 #a r_49_0
 def v_49_0 (z : Store) : Tensor := transposeAxes 1 2 (v_48_0 z)
 def s_50 (z : Store) : Store := storeSet (s_49 z) [(431, transposeAxes 1 2 ((s_49 z) 428))]
 theorem t_49 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_259) (pmPeers pmNode_259) (s_49 z) pmNode_259 none = some (s_50 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_49
 theorem k_49 (z : Store) (tid : Tid) (h : tid ∉ [431]) : (s_50 z) tid = (s_49 z) tid := by
   unfold s_50
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_49
 theorem w_49_0 (z : Store) : (s_50 z) 431 = v_49_0 z := by
   unfold s_50
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_49_0, r_49_0 z] <;> rfl
 #a w_49_0
 theorem h_49_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_49_0 z).shape = [1, 4, 8, 16] := by
   unfold v_49_0
   change listSwapAt _ _ _ = _
   rw [h_48_0 z z_]
   rfl
 #a h_49_0
 attribute [local irreducible] v_49_0
 attribute [local irreducible] s_50
 theorem r_50_0 (z : Store) : (s_50 z) 424 = (v_46_0 z) := pR (k_49 z) (pR (k_48 z) (pR (k_47 z) (w_46_0 z)))
 #a r_50_0
 def v_50_0 (z : Store) : Tensor := transposeAxes 2 3 (v_46_0 z)
 def s_51 (z : Store) : Store := storeSet (s_50 z) [(433, transposeAxes 2 3 ((s_50 z) 424))]
 theorem t_50 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_260) (pmPeers pmNode_260) (s_50 z) pmNode_260 none = some (s_51 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_50
 theorem k_50 (z : Store) (tid : Tid) (h : tid ∉ [433]) : (s_51 z) tid = (s_50 z) tid := by
   unfold s_51
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_50
 theorem w_50_0 (z : Store) : (s_51 z) 433 = v_50_0 z := by
   unfold s_51
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_50_0, r_50_0 z] <;> rfl
 #a w_50_0
 theorem h_50_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_50_0 z).shape = [1, 4, 8, 16] := by
   unfold v_50_0
   change listSwapAt _ _ _ = _
   rw [h_46_0 z z_]
   rfl
 #a h_50_0
 attribute [local irreducible] v_50_0
 attribute [local irreducible] s_51
 theorem n_44_48 (z : Store) (tid : Tid) (h : tid ∉ ([132, 423, 424, 427] : List Tid)) : (s_48 z) tid = (s_44 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_44 z) (k_45 z)) (pF _ _ _ _ _ (k_46 z) (k_47 z)) tid h
 #a n_44_48
 theorem r_51_0 (z : Store) : (s_51 z) 130 = (v_43_0 z) := pR (k_50 z) (pR (k_49 z) (pR (k_48 z) (pR (n_44_48 z) (w_43_0 z))))
 #a r_51_0
 theorem r_51_1 (z : Store) : (s_51 z) 433 = (v_50_0 z) := w_50_0 z
 #a r_51_1
 def v_51_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_43_0 z), (v_50_0 z)]
 theorem g_51 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_26) (s_51 z) pmNode_26 2 1 133 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_26, r_51_0 z, r_51_1 z, h_43_0 z z_, h_50_0 z z_]
 #a g_51
 def s_52 (z : Store) : Store := pL [0, 1] (s_51 z) pmNode_26 2 1
 theorem t_51 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_26) (pmPeers pmNode_26) (s_51 z) pmNode_26 none = some (s_52 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_26) (s_51 z) pmNode_26).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 133 (by decide) (g_51 z z_)]
   rfl
 #a t_51
 theorem k_51 (z : Store) (tid : Tid) (h : tid ∉ [133]) : (s_52 z) tid = (s_51 z) tid := by
   unfold s_52
   dsimp only [pL, pmNode_26, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_51
 theorem w_51_0 (z : Store) : (s_52 z) 133 = v_51_0 z := by
   unfold s_52
   dsimp only [pL, pmNode_26, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_51_0, r_51_0 z, r_51_1 z] <;> rfl
 #a w_51_0
 theorem h_51_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_51_0 z).shape = [1, 2, 16, 16] := by
   unfold v_51_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_43_0 z z_]
 #a h_51_0
 attribute [local irreducible] v_51_0
 attribute [local irreducible] s_52
 theorem n_48_52 (z : Store) (tid : Tid) (h : tid ∉ ([428, 431, 433, 133] : List Tid)) : (s_52 z) tid = (s_48 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_48 z) (k_49 z)) (pF _ _ _ _ _ (k_50 z) (k_51 z)) tid h
 #a n_48_52
 theorem r_52_0 (z : Store) : (s_52 z) 132 = (v_44_0 z) := pR (n_48_52 z) (pR (k_47 z) (pR (k_46 z) (pR (k_45 z) (w_44_0 z))))
 #a r_52_0
 theorem r_52_1 (z : Store) : (s_52 z) 133 = (v_51_0 z) := w_51_0 z
 #a r_52_1
 def v_52_0 (z : Store) : Tensor := fw_matmul (v_44_0 z) (v_51_0 z)
 def s_53 (z : Store) : Store := storeSet (s_52 z) [(134, fw_matmul ((s_52 z) 132) ((s_52 z) 133))]
 theorem t_52 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_27) (pmPeers pmNode_27) (s_52 z) pmNode_27 none = some (s_53 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_52
 theorem k_52 (z : Store) (tid : Tid) (h : tid ∉ [134]) : (s_53 z) tid = (s_52 z) tid := by
   unfold s_53
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_52
 theorem w_52_0 (z : Store) : (s_53 z) 134 = v_52_0 z := by
   unfold s_53
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_52_0, r_52_0 z, r_52_1 z] <;> rfl
 #a w_52_0
 theorem h_52_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_52_0 z).shape = [1, 2, 16, 16] := by
   unfold v_52_0
   unfold fw_matmul batchedMatmul
   rw [h_44_0 z z_, h_51_0 z z_]
   rfl
 #a h_52_0
 attribute [local irreducible] v_52_0
 attribute [local irreducible] s_53
 record_prefix_opacity v_44_0 s_45 v_45_0 s_46 v_46_0 s_47 v_47_0 s_48 v_48_0 s_49 v_49_0 s_50 v_50_0 s_51 v_51_0 s_52 v_52_0 s_53

 end
 end TrainVerify.Denote.RuntimeWorld
