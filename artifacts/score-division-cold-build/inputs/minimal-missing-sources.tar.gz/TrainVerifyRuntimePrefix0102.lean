import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0101
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_802_0 (z : Store) : (s_802 z) 1038 = (v_784_0 z) := pR (k_801 z) (pR (k_800 z) (pR (n_792_800 z) (pR (n_788_792 z) (pR (k_787 z) (pR (k_786 z) (pR (k_785 z) (w_784_0 z)))))))
 #a r_802_0
 theorem r_802_1 (z : Store) : (s_802 z) 1034 = (v_470_0 z) := pR (k_801 z) (pR (k_800 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_472_480 z) (pR (k_471 z) (r_471_0 z)))))))
 #a r_802_1
 def v_802_0 (z : Store) : Tensor := transposeAxes 1 2 (v_784_0 z)
 def s_803 (z : Store) : Store := storeSet (s_802 z) [(1036, transposeAxes 1 2 ((s_802 z) 1038))]
 theorem t_802 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_897) (pmPeers pmNode_897) (s_802 z) pmNode_897 none = some (s_803 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_802
 theorem k_802 (z : Store) (tid : Tid) (h : tid ∉ [1036]) : (s_803 z) tid = (s_802 z) tid := by
   unfold s_803
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_802
 theorem w_802_0 (z : Store) : (s_803 z) 1036 = v_802_0 z := by
   unfold s_803
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_802_0, r_802_0 z, r_802_1 z] <;> rfl
 #a w_802_0
 theorem h_802_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_802_0 z).shape = [1, 8, 4, 16] := by
   unfold v_802_0
   change listSwapAt _ _ _ = _
   rw [h_784_0 z z_]
   rfl
 #a h_802_0
 attribute [local irreducible] v_802_0
 attribute [local irreducible] s_803
 theorem r_803_0 (z : Store) : (s_803 z) 1036 = (v_802_0 z) := w_802_0 z
 #a r_803_0
 theorem r_803_1 (z : Store) : (s_803 z) 1033 = (v_469_0 z) := pR (k_802 z) (pR (k_801 z) (pR (k_800 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_472_480 z) (pR (k_471 z) (pR (k_470 z) (r_470_0 z)))))))))
 #a r_803_1
 def v_803_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_802_0 z)
 def s_804 (z : Store) : Store := storeSet (s_803 z) [(1035, fw_view [1, 8, 64] ((s_803 z) 1036))]
 theorem t_803 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_898) (pmPeers pmNode_898) (s_803 z) pmNode_898 none = some (s_804 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_803
 theorem k_803 (z : Store) (tid : Tid) (h : tid ∉ [1035]) : (s_804 z) tid = (s_803 z) tid := by
   unfold s_804
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_803
 theorem w_803_0 (z : Store) : (s_804 z) 1035 = v_803_0 z := by
   unfold s_804
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_803_0, r_803_0 z, r_803_1 z] <;> rfl
 #a w_803_0
 theorem h_803_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_803_0 z).shape = [1, 8, 64] := by
   unfold v_803_0
   rfl
 #a h_803_0
 attribute [local irreducible] v_803_0
 attribute [local irreducible] s_804
 theorem n_800_804 (z : Store) (tid : Tid) (h : tid ∉ ([1026, 1032, 1036, 1035] : List Tid)) : (s_804 z) tid = (s_800 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_800 z) (k_801 z)) (pF _ _ _ _ _ (k_802 z) (k_803 z)) tid h
 #a n_800_804
 theorem r_804_0 (z : Store) : (s_804 z) 732 = (v_798_0 z) := pR (n_800_804 z) (pR (k_799 z) (w_798_0 z))
 #a r_804_0
 theorem r_804_1 (z : Store) : (s_804 z) 1035 = (v_803_0 z) := w_803_0 z
 #a r_804_1
 def v_804_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_798_0 z), (v_803_0 z)]
 theorem g_804 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_663) (s_804 z) pmNode_663 1 2 716 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_663, r_804_0 z, r_804_1 z, h_798_0 z z_, h_803_0 z z_]
 #a g_804
 def s_805 (z : Store) : Store := pL [2, 3] (s_804 z) pmNode_663 1 2
 theorem t_804 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_663) (pmPeers pmNode_663) (s_804 z) pmNode_663 none = some (s_805 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_663) (s_804 z) pmNode_663).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 716 (by decide) (g_804 z z_)]
   rfl
 #a t_804
 theorem k_804 (z : Store) (tid : Tid) (h : tid ∉ [716]) : (s_805 z) tid = (s_804 z) tid := by
   unfold s_805
   dsimp only [pL, pmNode_663, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_804
 theorem w_804_0 (z : Store) : (s_805 z) 716 = v_804_0 z := by
   unfold s_805
   dsimp only [pL, pmNode_663, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_804_0, r_804_0 z, r_804_1 z] <;> rfl
 #a w_804_0
 theorem h_804_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_804_0 z).shape = [1, 16, 32] := by
   unfold v_804_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_798_0 z z_]
 #a h_804_0
 attribute [local irreducible] v_804_0
 attribute [local irreducible] s_805
 theorem r_805_0 (z : Store) : (s_805 z) 729 = (v_796_0 z) := pR (k_804 z) (pR (n_800_804 z) (pR (k_799 z) (pR (k_798 z) (pR (k_797 z) (w_796_0 z)))))
 #a r_805_0
 theorem r_805_1 (z : Store) : (s_805 z) 726 = (v_460_0 z) := pR (k_804 z) (pR (n_800_804 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (k_463 z) (pR (k_462 z) (pR (k_461 z) (r_461_0 z)))))))))
 #a r_805_1
 def v_805_0 (z : Store) : Tensor := transposeAxes 1 2 (v_796_0 z)
 def s_806 (z : Store) : Store := storeSet (s_805 z) [(728, transposeAxes 1 2 ((s_805 z) 729))]
 theorem t_805 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_664) (pmPeers pmNode_664) (s_805 z) pmNode_664 none = some (s_806 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_805
 theorem k_805 (z : Store) (tid : Tid) (h : tid ∉ [728]) : (s_806 z) tid = (s_805 z) tid := by
   unfold s_806
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_805
 theorem w_805_0 (z : Store) : (s_806 z) 728 = v_805_0 z := by
   unfold s_806
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_805_0, r_805_0 z, r_805_1 z] <;> rfl
 #a w_805_0
 theorem h_805_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_805_0 z).shape = [1, 16, 4, 8] := by
   unfold v_805_0
   change listSwapAt _ _ _ = _
   rw [h_796_0 z z_]
   rfl
 #a h_805_0
 attribute [local irreducible] v_805_0
 attribute [local irreducible] s_806
 theorem r_806_0 (z : Store) : (s_806 z) 732 = (v_798_0 z) := pR (k_805 z) (pR (k_804 z) (r_804_0 z))
 #a r_806_0
 theorem r_806_1 (z : Store) : (s_806 z) 1035 = (v_803_0 z) := pR (k_805 z) (pR (k_804 z) (r_804_1 z))
 #a r_806_1
 def v_806_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_798_0 z), (v_803_0 z)]
 theorem g_806 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_899) (s_806 z) pmNode_899 1 2 1020 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_899, r_806_0 z, r_806_1 z, h_798_0 z z_, h_803_0 z z_]
 #a g_806
 def s_807 (z : Store) : Store := pL [2, 3] (s_806 z) pmNode_899 1 2
 theorem t_806 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_899) (pmPeers pmNode_899) (s_806 z) pmNode_899 none = some (s_807 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_899) (s_806 z) pmNode_899).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1020 (by decide) (g_806 z z_)]
   rfl
 #a t_806
 theorem k_806 (z : Store) (tid : Tid) (h : tid ∉ [1020]) : (s_807 z) tid = (s_806 z) tid := by
   unfold s_807
   dsimp only [pL, pmNode_899, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_806
 theorem w_806_0 (z : Store) : (s_807 z) 1020 = v_806_0 z := by
   unfold s_807
   dsimp only [pL, pmNode_899, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_806_0, r_806_0 z, r_806_1 z] <;> rfl
 #a w_806_0
 theorem h_806_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_806_0 z).shape = [1, 16, 32] := by
   unfold v_806_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_798_0 z z_]
 #a h_806_0
 attribute [local irreducible] v_806_0
 attribute [local irreducible] s_807
 theorem r_807_0 (z : Store) : (s_807 z) 1032 = (v_801_0 z) := pR (k_806 z) (pR (k_805 z) (pR (k_804 z) (pR (k_803 z) (pR (k_802 z) (w_801_0 z)))))
 #a r_807_0
 theorem r_807_1 (z : Store) : (s_807 z) 1029 = (v_467_0 z) := pR (k_806 z) (pR (k_805 z) (pR (k_804 z) (pR (n_800_804 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_472_480 z) (pR (n_468_472 z) (r_468_0 z)))))))))
 #a r_807_1
 def v_807_0 (z : Store) : Tensor := transposeAxes 1 2 (v_801_0 z)
 def s_808 (z : Store) : Store := storeSet (s_807 z) [(1031, transposeAxes 1 2 ((s_807 z) 1032))]
 theorem t_807 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_900) (pmPeers pmNode_900) (s_807 z) pmNode_900 none = some (s_808 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_807
 theorem k_807 (z : Store) (tid : Tid) (h : tid ∉ [1031]) : (s_808 z) tid = (s_807 z) tid := by
   unfold s_808
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_807
 theorem w_807_0 (z : Store) : (s_808 z) 1031 = v_807_0 z := by
   unfold s_808
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_807_0, r_807_0 z, r_807_1 z] <;> rfl
 #a w_807_0
 theorem h_807_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_807_0 z).shape = [1, 16, 4, 8] := by
   unfold v_807_0
   change listSwapAt _ _ _ = _
   rw [h_801_0 z z_]
   rfl
 #a h_807_0
 attribute [local irreducible] v_807_0
 attribute [local irreducible] s_808
 theorem r_808_0 (z : Store) : (s_808 z) 728 = (v_805_0 z) := pR (k_807 z) (pR (k_806 z) (w_805_0 z))
 #a r_808_0
 theorem r_808_1 (z : Store) : (s_808 z) 1031 = (v_807_0 z) := w_807_0 z
 #a r_808_1
 def v_808_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 2 [(v_805_0 z), (v_807_0 z)]
 theorem g_808 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_665) (s_808 z) pmNode_665 3 2 725 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_665, r_808_0 z, r_808_1 z, h_805_0 z z_, h_807_0 z z_]
 #a g_808
 def s_809 (z : Store) : Store := pL [2, 3] (s_808 z) pmNode_665 3 2
 theorem t_808 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_665) (pmPeers pmNode_665) (s_808 z) pmNode_665 none = some (s_809 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_665) (s_808 z) pmNode_665).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 2 725 (by decide) (g_808 z z_)]
   rfl
 #a t_808
 theorem k_808 (z : Store) (tid : Tid) (h : tid ∉ [725]) : (s_809 z) tid = (s_808 z) tid := by
   unfold s_809
   dsimp only [pL, pmNode_665, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_808
 theorem w_808_0 (z : Store) : (s_809 z) 725 = v_808_0 z := by
   unfold s_809
   dsimp only [pL, pmNode_665, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_808_0, r_808_0 z, r_808_1 z] <;> rfl
 #a w_808_0
 theorem h_808_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_808_0 z).shape = [1, 16, 2, 16] := by
   unfold v_808_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_805_0 z z_]
 #a h_808_0
 attribute [local irreducible] v_808_0
 attribute [local irreducible] s_809
 theorem n_804_808 (z : Store) (tid : Tid) (h : tid ∉ ([716, 728, 1020, 1031] : List Tid)) : (s_808 z) tid = (s_804 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_804 z) (k_805 z)) (pF _ _ _ _ _ (k_806 z) (k_807 z)) tid h
 #a n_804_808
 theorem n_800_808 (z : Store) (tid : Tid) (h : tid ∉ ([1026, 1032, 1036, 1035, 716, 728, 1020, 1031] : List Tid)) : (s_808 z) tid = (s_800 z) tid := by
   exact pF _ _ _ _ _ (n_800_804 z) (n_804_808 z) tid h
 #a n_800_808
 theorem r_809_0 (z : Store) : (s_809 z) 725 = (v_808_0 z) := w_808_0 z
 #a r_809_0
 theorem r_809_1 (z : Store) : (s_809 z) 712 = (v_444_0 z) := pR (k_808 z) (pR (n_800_808 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (n_456_464 z) (r_456_0 z)))))))
 #a r_809_1
 def v_809_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_808_0 z)
 def s_810 (z : Store) : Store := storeSet (s_809 z) [(713, fw_view [1, 16, 32] ((s_809 z) 725))]
 theorem t_809 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_666) (pmPeers pmNode_666) (s_809 z) pmNode_666 none = some (s_810 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_809
 theorem k_809 (z : Store) (tid : Tid) (h : tid ∉ [713]) : (s_810 z) tid = (s_809 z) tid := by
   unfold s_810
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_809
 theorem w_809_0 (z : Store) : (s_810 z) 713 = v_809_0 z := by
   unfold s_810
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_809_0, r_809_0 z, r_809_1 z] <;> rfl
 #a w_809_0
 theorem h_809_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_809_0 z).shape = [1, 16, 32] := by
   unfold v_809_0
   rfl
 #a h_809_0
 attribute [local irreducible] v_809_0
 attribute [local irreducible] s_810
 theorem r_810_0 (z : Store) : (s_810 z) 723 = (v_795_0 z) := pR (k_809 z) (pR (k_808 z) (pR (n_800_808 z) (pR (n_796_800 z) (w_795_0 z))))
 #a r_810_0
 theorem r_810_1 (z : Store) : (s_810 z) 720 = (v_454_0 z) := pR (k_809 z) (pR (k_808 z) (pR (n_800_808 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (n_456_464 z) (pR (k_455 z) (r_455_0 z)))))))))
 #a r_810_1
 def v_810_0 (z : Store) : Tensor := transposeAxes 1 2 (v_795_0 z)
 def s_811 (z : Store) : Store := storeSet (s_810 z) [(722, transposeAxes 1 2 ((s_810 z) 723))]
 theorem t_810 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_667) (pmPeers pmNode_667) (s_810 z) pmNode_667 none = some (s_811 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_810
 theorem k_810 (z : Store) (tid : Tid) (h : tid ∉ [722]) : (s_811 z) tid = (s_810 z) tid := by
   unfold s_811
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_810
 theorem w_810_0 (z : Store) : (s_811 z) 722 = v_810_0 z := by
   unfold s_811
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_810_0, r_810_0 z, r_810_1 z] <;> rfl
 #a w_810_0
 theorem h_810_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_810_0 z).shape = [1, 16, 4, 8] := by
   unfold v_810_0
   change listSwapAt _ _ _ = _
   rw [h_795_0 z z_]
   rfl
 #a h_810_0
 attribute [local irreducible] v_810_0
 attribute [local irreducible] s_811
 record_prefix_opacity v_802_0 s_803 v_803_0 s_804 v_804_0 s_805 v_805_0 s_806 v_806_0 s_807 v_807_0 s_808 v_808_0 s_809 v_809_0 s_810 v_810_0 s_811

 end
 end TrainVerify.Denote.RuntimeWorld
