import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0104
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_826_0 (z : Store) : (s_826 z) 710 = (v_825_0 z) := w_825_0 z
 #a r_826_0
 theorem r_826_1 (z : Store) : (s_826 z) 892 = (v_824_0 z) := pR (k_825 z) (w_824_0 z)
 #a r_826_1
 theorem r_826_2 (z : Store) : (s_826 z) 894 = (v_820_0 z) := pR (k_825 z) (pR (k_824 z) (pR (k_823 z) (pR (k_822 z) (pR (k_821 z) (w_820_0 z)))))
 #a r_826_2
 def v_826_0 (z : Store) : Tensor := tensorSum [(v_825_0 z), (v_824_0 z), (v_820_0 z)]
 def s_827 (z : Store) : Store := storeSet (s_826 z) [(707, tensorSum [((s_826 z) 710), ((s_826 z) 892), ((s_826 z) 894)])]
 theorem t_826 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_675) (pmPeers pmNode_675) (s_826 z) pmNode_675 none = some (s_827 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_826
 theorem k_826 (z : Store) (tid : Tid) (h : tid ∉ [707]) : (s_827 z) tid = (s_826 z) tid := by
   unfold s_827
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_826
 theorem w_826_0 (z : Store) : (s_827 z) 707 = v_826_0 z := by
   unfold s_827
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_826_0, r_826_0 z, r_826_1 z, r_826_2 z] <;> rfl
 #a w_826_0
 theorem h_826_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_826_0 z).shape = [1, 8, 64] := by
   unfold v_826_0
   rw [tensorSum_shape]
   exact h_825_0 z z_
 #a h_826_0
 attribute [local irreducible] v_826_0
 attribute [local irreducible] s_827
 theorem r_827_0 (z : Store) : (s_827 z) 707 = (v_826_0 z) := w_826_0 z
 #a r_827_0
 theorem r_827_1 (z : Store) : (s_827 z) 704 = (v_436_0 z) := pR (k_826 z) (pR (k_825 z) (pR (k_824 z) (pR (n_816_824 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_440_448 z) (pR (k_439 z) (pR (k_438 z) (pR (k_437 z) (r_437_0 z))))))))))))
 #a r_827_1
 theorem r_827_2 (z : Store) : (s_827 z) 607 = (z 607) := pR (k_826 z) (pR (k_825 z) (pR (k_824 z) (pR (n_816_824 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_440_448 z) (pR (k_439 z) (pR (k_438 z) (pR (k_437 z) (r_437_1 z))))))))))))
 #a r_827_2
 theorem r_827_3 (z : Store) : (s_827 z) 608 = (z 608) := pR (k_826 z) (pR (k_825 z) (pR (k_824 z) (pR (n_816_824 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_440_448 z) (pR (k_439 z) (pR (k_438 z) (pR (k_437 z) (r_437_2 z))))))))))))
 #a r_827_3
 def v_827_0 (z : Store) : Tensor := (bw_layernorm (v_826_0 z) (v_436_0 z) (z 607) (z 608)).1
 def v_827_1 (z : Store) : Tensor := (bw_layernorm (v_826_0 z) (v_436_0 z) (z 607) (z 608)).2.1
 def v_827_2 (z : Store) : Tensor := (bw_layernorm (v_826_0 z) (v_436_0 z) (z 607) (z 608)).2.2
 def s_828 (z : Store) : Store := storeSet (s_827 z) [(706, (bw_layernorm ((s_827 z) 707) ((s_827 z) 704) ((s_827 z) 607) ((s_827 z) 608)).1), (627, (bw_layernorm ((s_827 z) 707) ((s_827 z) 704) ((s_827 z) 607) ((s_827 z) 608)).2.1), (629, (bw_layernorm ((s_827 z) 707) ((s_827 z) 704) ((s_827 z) 607) ((s_827 z) 608)).2.2)]
 theorem t_827 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_676) (pmPeers pmNode_676) (s_827 z) pmNode_676 none = some (s_828 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_827
 theorem k_827 (z : Store) (tid : Tid) (h : tid ∉ [706, 627, 629]) : (s_828 z) tid = (s_827 z) tid := by
   unfold s_828
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_827
 theorem w_827_0 (z : Store) : (s_828 z) 706 = v_827_0 z := by
   unfold s_828
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_827_0, r_827_0 z, r_827_1 z, r_827_2 z, r_827_3 z] <;> rfl
 #a w_827_0
 theorem h_827_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_827_0 z).shape = [1, 8, 64] := by
   unfold v_827_0
   rw [bw_layernorm_dx_shape (v_826_0 z) (v_436_0 z) (z 607) (z 608) 64 [8, 1] (by rw [h_436_0 z z_]; rfl)]
   exact h_436_0 z z_
 #a h_827_0
 attribute [local irreducible] v_827_0
 theorem w_827_1 (z : Store) : (s_828 z) 627 = v_827_1 z := by
   unfold s_828
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_827_1, r_827_0 z, r_827_1 z, r_827_2 z, r_827_3 z] <;> rfl
 #a w_827_1
 theorem h_827_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_827_1 z).shape = [64] := by
   unfold v_827_1
   rw [bw_layernorm_dw_shape (v_826_0 z) (v_436_0 z) (z 607) (z 608) 64 [8, 1] (by rw [h_436_0 z z_]; rfl)]
   exact i_54 z z_
 #a h_827_1
 attribute [local irreducible] v_827_1
 theorem w_827_2 (z : Store) : (s_828 z) 629 = v_827_2 z := by
   unfold s_828
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_827_2, r_827_0 z, r_827_1 z, r_827_2 z, r_827_3 z] <;> rfl
 #a w_827_2
 theorem h_827_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_827_2 z).shape = [64] := by
   unfold v_827_2
   rw [bw_layernorm_db_shape (v_826_0 z) (v_436_0 z) (z 607) (z 608) 64 [8, 1] (by rw [h_436_0 z z_]; rfl)]
   exact i_55 z z_
 #a h_827_2
 attribute [local irreducible] v_827_2
 attribute [local irreducible] s_828
 theorem n_824_828 (z : Store) (tid : Tid) (h : tid ∉ ([892, 710, 631, 707, 706, 627, 629] : List Tid)) : (s_828 z) tid = (s_824 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_824 z) (k_825 z)) (pF _ _ _ _ _ (k_826 z) (k_827 z)) tid h
 #a n_824_828
 theorem r_828_0 (z : Store) : (s_828 z) 714 = (v_821_0 z) := pR (n_824_828 z) (r_824_0 z)
 #a r_828_0
 theorem r_828_1 (z : Store) : (s_828 z) 1016 = (v_823_0 z) := pR (n_824_828 z) (r_824_1 z)
 #a r_828_1
 def v_828_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_821_0 z), (v_823_0 z)]
 def s_829 (z : Store) : Store := storeSet (s_828 z) [(1195, reduceScatterPrimDimN 1 2 1 [((s_828 z) 714), ((s_828 z) 1016)])]
 theorem t_828 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_909) (pmPeers pmNode_909) (s_828 z) pmNode_909 none = some (s_829 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_828 z) pmNode_909 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_828
 theorem k_828 (z : Store) (tid : Tid) (h : tid ∉ [1195]) : (s_829 z) tid = (s_828 z) tid := by
   unfold s_829
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_828
 theorem w_828_0 (z : Store) : (s_829 z) 1195 = v_828_0 z := by
   unfold s_829
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_828_0, r_828_0 z, r_828_1 z] <;> rfl
 #a w_828_0
 theorem h_828_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_828_0 z).shape = [1, 8, 64] := by
   unfold v_828_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_821_0 z) rfl]
     exact h_821_0 z z_
   · decide
 #a h_828_0
 attribute [local irreducible] v_828_0
 attribute [local irreducible] s_829
 theorem r_829_0 (z : Store) : (s_829 z) 1014 = (v_818_0 z) := pR (k_828 z) (pR (n_824_828 z) (pR (n_820_824 z) (pR (k_819 z) (w_818_0 z))))
 #a r_829_0
 theorem r_829_1 (z : Store) : (s_829 z) 1011 = (v_442_0 z) := pR (k_828 z) (pR (n_824_828 z) (pR (n_816_824 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (r_448_0 z)))))))
 #a r_829_1
 theorem r_829_2 (z : Store) : (s_829 z) 912 = (z 912) := pR (k_828 z) (pR (n_824_828 z) (pR (n_816_824 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (r_448_1 z)))))))
 #a r_829_2
 def v_829_0 (z : Store) : Tensor := (bw_linear (v_818_0 z) (v_442_0 z) (z 912)).1
 def v_829_1 (z : Store) : Tensor := (bw_linear (v_818_0 z) (v_442_0 z) (z 912)).2
 def s_830 (z : Store) : Store := storeSet (s_829 z) [(1013, (bw_linear ((s_829 z) 1014) ((s_829 z) 1011) ((s_829 z) 912)).1), (934, (bw_linear ((s_829 z) 1014) ((s_829 z) 1011) ((s_829 z) 912)).2)]
 theorem t_829 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_910) (pmPeers pmNode_910) (s_829 z) pmNode_910 none = some (s_830 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_829
 theorem k_829 (z : Store) (tid : Tid) (h : tid ∉ [1013, 934]) : (s_830 z) tid = (s_829 z) tid := by
   unfold s_830
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_829
 theorem w_829_0 (z : Store) : (s_830 z) 1013 = v_829_0 z := by
   unfold s_830
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_829_0, r_829_0 z, r_829_1 z, r_829_2 z] <;> rfl
 #a w_829_0
 theorem h_829_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_829_0 z).shape = [1, 8, 64] := by
   unfold v_829_0
   exact bw_linear_3d_fst_shape 1 8 64 64 (v_818_0 z) (v_442_0 z) (z 912) (h_818_0 z z_) (h_442_0 z z_) (i_61 z z_)
 #a h_829_0
 attribute [local irreducible] v_829_0
 theorem w_829_1 (z : Store) : (s_830 z) 934 = v_829_1 z := by
   unfold s_830
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_829_1, r_829_0 z, r_829_1 z, r_829_2 z] <;> rfl
 #a w_829_1
 theorem h_829_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_829_1 z).shape = [64, 64] := by
   unfold v_829_1
   exact bw_linear_3d_snd_shape 1 8 64 64 (v_818_0 z) (v_442_0 z) (z 912) (h_818_0 z z_) (h_442_0 z z_) (i_61 z z_)
 #a h_829_1
 attribute [local irreducible] v_829_1
 attribute [local irreducible] s_830
 theorem r_830_0 (z : Store) : (s_830 z) 1013 = (v_829_0 z) := w_829_0 z
 #a r_830_0
 theorem r_830_1 (z : Store) : (s_830 z) 1195 = (v_828_0 z) := pR (k_829 z) (w_828_0 z)
 #a r_830_1
 theorem r_830_2 (z : Store) : (s_830 z) 1197 = (v_822_0 z) := pR (k_829 z) (pR (k_828 z) (pR (n_824_828 z) (pR (k_823 z) (w_822_0 z))))
 #a r_830_2
 def v_830_0 (z : Store) : Tensor := tensorSum [(v_829_0 z), (v_828_0 z), (v_822_0 z)]
 def s_831 (z : Store) : Store := storeSet (s_830 z) [(1010, tensorSum [((s_830 z) 1013), ((s_830 z) 1195), ((s_830 z) 1197)])]
 theorem t_830 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_911) (pmPeers pmNode_911) (s_830 z) pmNode_911 none = some (s_831 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_830
 theorem k_830 (z : Store) (tid : Tid) (h : tid ∉ [1010]) : (s_831 z) tid = (s_830 z) tid := by
   unfold s_831
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_830
 theorem w_830_0 (z : Store) : (s_831 z) 1010 = v_830_0 z := by
   unfold s_831
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_830_0, r_830_0 z, r_830_1 z, r_830_2 z] <;> rfl
 #a w_830_0
 theorem h_830_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_830_0 z).shape = [1, 8, 64] := by
   unfold v_830_0
   rw [tensorSum_shape]
   exact h_829_0 z z_
 #a h_830_0
 attribute [local irreducible] v_830_0
 attribute [local irreducible] s_831
 theorem r_831_0 (z : Store) : (s_831 z) 1010 = (v_830_0 z) := w_830_0 z
 #a r_831_0
 theorem r_831_1 (z : Store) : (s_831 z) 1007 = (v_440_0 z) := pR (k_830 z) (pR (k_829 z) (pR (k_828 z) (pR (n_824_828 z) (pR (n_816_824 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_444_448 z) (pR (k_443 z) (pR (k_442 z) (pR (k_441 z) (r_441_0 z)))))))))))))
 #a r_831_1
 theorem r_831_2 (z : Store) : (s_831 z) 910 = (z 910) := pR (k_830 z) (pR (k_829 z) (pR (k_828 z) (pR (n_824_828 z) (pR (n_816_824 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_444_448 z) (pR (k_443 z) (pR (k_442 z) (pR (k_441 z) (r_441_1 z)))))))))))))
 #a r_831_2
 theorem r_831_3 (z : Store) : (s_831 z) 911 = (z 911) := pR (k_830 z) (pR (k_829 z) (pR (k_828 z) (pR (n_824_828 z) (pR (n_816_824 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_444_448 z) (pR (k_443 z) (pR (k_442 z) (pR (k_441 z) (r_441_2 z)))))))))))))
 #a r_831_3
 def v_831_0 (z : Store) : Tensor := (bw_layernorm (v_830_0 z) (v_440_0 z) (z 910) (z 911)).1
 def v_831_1 (z : Store) : Tensor := (bw_layernorm (v_830_0 z) (v_440_0 z) (z 910) (z 911)).2.1
 def v_831_2 (z : Store) : Tensor := (bw_layernorm (v_830_0 z) (v_440_0 z) (z 910) (z 911)).2.2
 def s_832 (z : Store) : Store := storeSet (s_831 z) [(1009, (bw_layernorm ((s_831 z) 1010) ((s_831 z) 1007) ((s_831 z) 910) ((s_831 z) 911)).1), (930, (bw_layernorm ((s_831 z) 1010) ((s_831 z) 1007) ((s_831 z) 910) ((s_831 z) 911)).2.1), (932, (bw_layernorm ((s_831 z) 1010) ((s_831 z) 1007) ((s_831 z) 910) ((s_831 z) 911)).2.2)]
 theorem t_831 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_912) (pmPeers pmNode_912) (s_831 z) pmNode_912 none = some (s_832 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_831
 theorem k_831 (z : Store) (tid : Tid) (h : tid ∉ [1009, 930, 932]) : (s_832 z) tid = (s_831 z) tid := by
   unfold s_832
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_831
 theorem w_831_0 (z : Store) : (s_832 z) 1009 = v_831_0 z := by
   unfold s_832
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_831_0, r_831_0 z, r_831_1 z, r_831_2 z, r_831_3 z] <;> rfl
 #a w_831_0
 theorem h_831_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_831_0 z).shape = [1, 8, 64] := by
   unfold v_831_0
   rw [bw_layernorm_dx_shape (v_830_0 z) (v_440_0 z) (z 910) (z 911) 64 [8, 1] (by rw [h_440_0 z z_]; rfl)]
   exact h_440_0 z z_
 #a h_831_0
 attribute [local irreducible] v_831_0
 theorem w_831_1 (z : Store) : (s_832 z) 930 = v_831_1 z := by
   unfold s_832
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_831_1, r_831_0 z, r_831_1 z, r_831_2 z, r_831_3 z] <;> rfl
 #a w_831_1
 theorem h_831_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_831_1 z).shape = [64] := by
   unfold v_831_1
   rw [bw_layernorm_dw_shape (v_830_0 z) (v_440_0 z) (z 910) (z 911) 64 [8, 1] (by rw [h_440_0 z z_]; rfl)]
   exact i_57 z z_
 #a h_831_1
 attribute [local irreducible] v_831_1
 theorem w_831_2 (z : Store) : (s_832 z) 932 = v_831_2 z := by
   unfold s_832
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_831_2, r_831_0 z, r_831_1 z, r_831_2 z, r_831_3 z] <;> rfl
 #a w_831_2
 theorem h_831_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_831_2 z).shape = [64] := by
   unfold v_831_2
   rw [bw_layernorm_db_shape (v_830_0 z) (v_440_0 z) (z 910) (z 911) 64 [8, 1] (by rw [h_440_0 z z_]; rfl)]
   exact i_58 z z_
 #a h_831_2
 attribute [local irreducible] v_831_2
 attribute [local irreducible] s_832
 theorem n_828_832 (z : Store) (tid : Tid) (h : tid ∉ ([1195, 1013, 934, 1010, 1009, 930, 932] : List Tid)) : (s_832 z) tid = (s_828 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_828 z) (k_829 z)) (pF _ _ _ _ _ (k_830 z) (k_831 z)) tid h
 #a n_828_832
 record_prefix_opacity v_826_0 s_827 v_827_0 v_827_1 v_827_2 s_828 v_828_0 s_829 v_829_0 v_829_1 s_830 v_830_0 s_831 v_831_0 v_831_1 v_831_2 s_832

 end
 end TrainVerify.Denote.RuntimeWorld
