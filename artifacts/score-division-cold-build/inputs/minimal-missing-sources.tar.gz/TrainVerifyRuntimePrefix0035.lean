import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0034
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_269_0 (z : Store) : (s_269 z) 231 = (v_268_0 z) := w_268_0 z
 #a r_269_0
 theorem r_269_1 (z : Store) : (s_269 z) 228 = (v_152_0 z) := pR (k_268 z) (pR (n_264_268 z) (pR (n_256_264 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_156_160 z) (pR (k_155 z) (pR (k_154 z) (pR (k_153 z) (r_153_0 z)))))))))
 #a r_269_1
 def v_269_0 (z : Store) : Tensor := bw_div ((4 : Nat) : Scalar) (v_268_0 z)
 def s_270 (z : Store) : Store := storeSet (s_269 z) [(230, bw_div ((4 : Nat) : Scalar) ((s_269 z) 231))]
 theorem t_269 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_135) (pmPeers pmNode_135) (s_269 z) pmNode_135 none = some (s_270 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_269
 theorem k_269 (z : Store) (tid : Tid) (h : tid ∉ [230]) : (s_270 z) tid = (s_269 z) tid := by
   unfold s_270
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_269
 theorem w_269_0 (z : Store) : (s_270 z) 230 = v_269_0 z := by
   unfold s_270
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_269_0, r_269_0 z, r_269_1 z] <;> rfl
 #a w_269_0
 theorem h_269_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_269_0 z).shape = [1, 4, 16, 8] := by
   unfold v_269_0
   exact h_268_0 z z_
 #a h_269_0
 attribute [local irreducible] v_269_0
 attribute [local irreducible] s_270
 theorem r_270_0 (z : Store) : (s_270 z) 234 = (v_265_0 z) := pR (k_269 z) (pR (k_268 z) (r_268_0 z))
 #a r_270_0
 theorem r_270_1 (z : Store) : (s_270 z) 537 = (v_267_0 z) := pR (k_269 z) (pR (k_268 z) (r_268_1 z))
 #a r_270_1
 def v_270_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 3 [(v_265_0 z), (v_267_0 z)]
 theorem g_270 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_370) (s_270 z) pmNode_370 2 3 534 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_370, r_270_0 z, r_270_1 z, h_265_0 z z_, h_267_0 z z_]
 #a g_270
 def s_271 (z : Store) : Store := pL [0, 1] (s_270 z) pmNode_370 2 3
 theorem t_270 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_370) (pmPeers pmNode_370) (s_270 z) pmNode_370 none = some (s_271 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_370) (s_270 z) pmNode_370).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 3 534 (by decide) (g_270 z z_)]
   rfl
 #a t_270
 theorem k_270 (z : Store) (tid : Tid) (h : tid ∉ [534]) : (s_271 z) tid = (s_270 z) tid := by
   unfold s_271
   dsimp only [pL, pmNode_370, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_270
 theorem w_270_0 (z : Store) : (s_271 z) 534 = v_270_0 z := by
   unfold s_271
   dsimp only [pL, pmNode_370, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_270_0, r_270_0 z, r_270_1 z] <;> rfl
 #a w_270_0
 theorem h_270_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_270_0 z).shape = [1, 4, 16, 8] := by
   unfold v_270_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_265_0 z z_]
 #a h_270_0
 attribute [local irreducible] v_270_0
 attribute [local irreducible] s_271
 theorem r_271_0 (z : Store) : (s_271 z) 534 = (v_270_0 z) := w_270_0 z
 #a r_271_0
 theorem r_271_1 (z : Store) : (s_271 z) 531 = (v_154_0 z) := pR (k_270 z) (pR (k_269 z) (pR (k_268 z) (pR (n_264_268 z) (pR (n_256_264 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_156_160 z) (pR (k_155 z) (r_155_0 z)))))))))
 #a r_271_1
 def v_271_0 (z : Store) : Tensor := bw_div ((4 : Nat) : Scalar) (v_270_0 z)
 def s_272 (z : Store) : Store := storeSet (s_271 z) [(533, bw_div ((4 : Nat) : Scalar) ((s_271 z) 534))]
 theorem t_271 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_371) (pmPeers pmNode_371) (s_271 z) pmNode_371 none = some (s_272 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_271
 theorem k_271 (z : Store) (tid : Tid) (h : tid ∉ [533]) : (s_272 z) tid = (s_271 z) tid := by
   unfold s_272
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_271
 theorem w_271_0 (z : Store) : (s_272 z) 533 = v_271_0 z := by
   unfold s_272
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_271_0, r_271_0 z, r_271_1 z] <;> rfl
 #a w_271_0
 theorem h_271_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_271_0 z).shape = [1, 4, 16, 8] := by
   unfold v_271_0
   exact h_270_0 z z_
 #a h_271_0
 attribute [local irreducible] v_271_0
 attribute [local irreducible] s_272
 theorem r_272_0 (z : Store) : (s_272 z) 230 = (v_269_0 z) := pR (k_271 z) (pR (k_270 z) (w_269_0 z))
 #a r_272_0
 theorem r_272_1 (z : Store) : (s_272 z) 533 = (v_271_0 z) := w_271_0 z
 #a r_272_1
 def v_272_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_269_0 z), (v_271_0 z)]
 theorem g_272 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_136) (s_272 z) pmNode_136 3 1 227 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_136, r_272_0 z, r_272_1 z, h_269_0 z z_, h_271_0 z z_]
 #a g_272
 def s_273 (z : Store) : Store := pL [0, 1] (s_272 z) pmNode_136 3 1
 theorem t_272 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_136) (pmPeers pmNode_136) (s_272 z) pmNode_136 none = some (s_273 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_136) (s_272 z) pmNode_136).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 227 (by decide) (g_272 z z_)]
   rfl
 #a t_272
 theorem k_272 (z : Store) (tid : Tid) (h : tid ∉ [227]) : (s_273 z) tid = (s_272 z) tid := by
   unfold s_273
   dsimp only [pL, pmNode_136, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_272
 theorem w_272_0 (z : Store) : (s_273 z) 227 = v_272_0 z := by
   unfold s_273
   dsimp only [pL, pmNode_136, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_272_0, r_272_0 z, r_272_1 z] <;> rfl
 #a w_272_0
 theorem h_272_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_272_0 z).shape = [1, 2, 16, 16] := by
   unfold v_272_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_269_0 z z_]
 #a h_272_0
 attribute [local irreducible] v_272_0
 attribute [local irreducible] s_273
 theorem n_268_272 (z : Store) (tid : Tid) (h : tid ∉ ([231, 230, 534, 533] : List Tid)) : (s_272 z) tid = (s_268 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_268 z) (k_269 z)) (pF _ _ _ _ _ (k_270 z) (k_271 z)) tid h
 #a n_268_272
 theorem n_264_272 (z : Store) (tid : Tid) (h : tid ∉ ([221, 234, 524, 537, 231, 230, 534, 533] : List Tid)) : (s_272 z) tid = (s_264 z) tid := by
   exact pF _ _ _ _ _ (n_264_268 z) (n_268_272 z) tid h
 #a n_264_272
 theorem n_256_272 (z : Store) (tid : Tid) (h : tid ∉ ([242, 241, 545, 544, 237, 235, 238, 541, 538, 540, 221, 234, 524, 537, 231, 230, 534, 533] : List Tid)) : (s_272 z) tid = (s_256 z) tid := by
   exact pF _ _ _ _ _ (n_256_264 z) (n_264_272 z) tid h
 #a n_256_272
 theorem r_273_0 (z : Store) : (s_273 z) 227 = (v_272_0 z) := w_272_0 z
 #a r_273_0
 theorem r_273_1 (z : Store) : (s_273 z) 203 = (v_127_0 z) := pR (k_272 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_152_160 z) (pR (k_151 z) (pR (k_150 z) (pR (k_149 z) (r_149_0 z))))))))
 #a r_273_1
 theorem r_273_2 (z : Store) : (s_273 z) 224 = (v_148_0 z) := pR (k_272 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_152_160 z) (pR (k_151 z) (pR (k_150 z) (pR (k_149 z) (r_149_1 z))))))))
 #a r_273_2
 def v_273_0 (z : Store) : Tensor := (batchedMatmulBwd (v_272_0 z) (v_127_0 z) (v_148_0 z)).1
 def v_273_1 (z : Store) : Tensor := (batchedMatmulBwd (v_272_0 z) (v_127_0 z) (v_148_0 z)).2
 def s_274 (z : Store) : Store := storeSet (s_273 z) [(205, (batchedMatmulBwd ((s_273 z) 227) ((s_273 z) 203) ((s_273 z) 224)).1), (226, (batchedMatmulBwd ((s_273 z) 227) ((s_273 z) 203) ((s_273 z) 224)).2)]
 theorem t_273 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_137) (pmPeers pmNode_137) (s_273 z) pmNode_137 none = some (s_274 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_273
 theorem k_273 (z : Store) (tid : Tid) (h : tid ∉ [205, 226]) : (s_274 z) tid = (s_273 z) tid := by
   unfold s_274
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_273
 theorem w_273_0 (z : Store) : (s_274 z) 205 = v_273_0 z := by
   unfold s_274
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_273_0, r_273_0 z, r_273_1 z, r_273_2 z] <;> rfl
 #a w_273_0
 theorem h_273_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_273_0 z).shape = [1, 2, 16, 16] := by
   unfold v_273_0
   change (batchedMatmul (v_272_0 z) (transpose2d (v_148_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_272_0 z z_, h_148_0 z z_]
   rfl
 #a h_273_0
 attribute [local irreducible] v_273_0
 theorem w_273_1 (z : Store) : (s_274 z) 226 = v_273_1 z := by
   unfold s_274
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_273_1, r_273_0 z, r_273_1 z, r_273_2 z] <;> rfl
 #a w_273_1
 theorem h_273_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_273_1 z).shape = [1, 2, 16, 16] := by
   unfold v_273_1
   change (batchedMatmul (transpose2d (v_127_0 z)) (v_272_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_272_0 z z_, h_127_0 z z_]
   rfl
 #a h_273_1
 attribute [local irreducible] v_273_1
 attribute [local irreducible] s_274
 theorem r_274_0 (z : Store) : (s_274 z) 230 = (v_269_0 z) := pR (k_273 z) (pR (k_272 z) (r_272_0 z))
 #a r_274_0
 theorem r_274_1 (z : Store) : (s_274 z) 533 = (v_271_0 z) := pR (k_273 z) (pR (k_272 z) (r_272_1 z))
 #a r_274_1
 def v_274_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_269_0 z), (v_271_0 z)]
 theorem g_274 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_372) (s_274 z) pmNode_372 3 1 530 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_372, r_274_0 z, r_274_1 z, h_269_0 z z_, h_271_0 z z_]
 #a g_274
 def s_275 (z : Store) : Store := pL [0, 1] (s_274 z) pmNode_372 3 1
 theorem t_274 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_372) (pmPeers pmNode_372) (s_274 z) pmNode_372 none = some (s_275 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_372) (s_274 z) pmNode_372).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 530 (by decide) (g_274 z z_)]
   rfl
 #a t_274
 theorem k_274 (z : Store) (tid : Tid) (h : tid ∉ [530]) : (s_275 z) tid = (s_274 z) tid := by
   unfold s_275
   dsimp only [pL, pmNode_372, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_274
 theorem w_274_0 (z : Store) : (s_275 z) 530 = v_274_0 z := by
   unfold s_275
   dsimp only [pL, pmNode_372, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_274_0, r_274_0 z, r_274_1 z] <;> rfl
 #a w_274_0
 theorem h_274_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_274_0 z).shape = [1, 2, 16, 16] := by
   unfold v_274_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_269_0 z z_]
 #a h_274_0
 attribute [local irreducible] v_274_0
 attribute [local irreducible] s_275
 theorem r_275_0 (z : Store) : (s_275 z) 530 = (v_274_0 z) := w_274_0 z
 #a r_275_0
 theorem r_275_1 (z : Store) : (s_275 z) 506 = (v_131_0 z) := pR (k_274 z) (pR (k_273 z) (pR (k_272 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_152_160 z) (pR (k_151 z) (r_151_0 z))))))))
 #a r_275_1
 theorem r_275_2 (z : Store) : (s_275 z) 527 = (v_150_0 z) := pR (k_274 z) (pR (k_273 z) (pR (k_272 z) (pR (n_256_272 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_152_160 z) (pR (k_151 z) (r_151_1 z))))))))
 #a r_275_2
 def v_275_0 (z : Store) : Tensor := (batchedMatmulBwd (v_274_0 z) (v_131_0 z) (v_150_0 z)).1
 def v_275_1 (z : Store) : Tensor := (batchedMatmulBwd (v_274_0 z) (v_131_0 z) (v_150_0 z)).2
 def s_276 (z : Store) : Store := storeSet (s_275 z) [(508, (batchedMatmulBwd ((s_275 z) 530) ((s_275 z) 506) ((s_275 z) 527)).1), (529, (batchedMatmulBwd ((s_275 z) 530) ((s_275 z) 506) ((s_275 z) 527)).2)]
 theorem t_275 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_373) (pmPeers pmNode_373) (s_275 z) pmNode_373 none = some (s_276 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_275
 theorem k_275 (z : Store) (tid : Tid) (h : tid ∉ [508, 529]) : (s_276 z) tid = (s_275 z) tid := by
   unfold s_276
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_275
 theorem w_275_0 (z : Store) : (s_276 z) 508 = v_275_0 z := by
   unfold s_276
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_275_0, r_275_0 z, r_275_1 z, r_275_2 z] <;> rfl
 #a w_275_0
 theorem h_275_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_275_0 z).shape = [1, 2, 16, 16] := by
   unfold v_275_0
   change (batchedMatmul (v_274_0 z) (transpose2d (v_150_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_274_0 z z_, h_150_0 z z_]
   rfl
 #a h_275_0
 attribute [local irreducible] v_275_0
 theorem w_275_1 (z : Store) : (s_276 z) 529 = v_275_1 z := by
   unfold s_276
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_275_1, r_275_0 z, r_275_1 z, r_275_2 z] <;> rfl
 #a w_275_1
 theorem h_275_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_275_1 z).shape = [1, 2, 16, 16] := by
   unfold v_275_1
   change (batchedMatmul (transpose2d (v_131_0 z)) (v_274_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_274_0 z z_, h_131_0 z z_]
   rfl
 #a h_275_1
 attribute [local irreducible] v_275_1
 attribute [local irreducible] s_276
 theorem r_276_0 (z : Store) : (s_276 z) 226 = (v_273_1 z) := pR (k_275 z) (pR (k_274 z) (w_273_1 z))
 #a r_276_0
 theorem r_276_1 (z : Store) : (s_276 z) 529 = (v_275_1 z) := w_275_1 z
 #a r_276_1
 def v_276_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_273_1 z), (v_275_1 z)]
 theorem g_276 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_138) (s_276 z) pmNode_138 1 2 223 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_138, r_276_0 z, r_276_1 z, h_273_1 z z_, h_275_1 z z_]
 #a g_276
 def s_277 (z : Store) : Store := pL [0, 1] (s_276 z) pmNode_138 1 2
 theorem t_276 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_138) (pmPeers pmNode_138) (s_276 z) pmNode_138 none = some (s_277 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_138) (s_276 z) pmNode_138).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 223 (by decide) (g_276 z z_)]
   rfl
 #a t_276
 theorem k_276 (z : Store) (tid : Tid) (h : tid ∉ [223]) : (s_277 z) tid = (s_276 z) tid := by
   unfold s_277
   dsimp only [pL, pmNode_138, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_276
 theorem w_276_0 (z : Store) : (s_277 z) 223 = v_276_0 z := by
   unfold s_277
   dsimp only [pL, pmNode_138, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_276_0, r_276_0 z, r_276_1 z] <;> rfl
 #a w_276_0
 theorem h_276_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_276_0 z).shape = [1, 4, 8, 16] := by
   unfold v_276_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_273_1 z z_]
 #a h_276_0
 attribute [local irreducible] v_276_0
 attribute [local irreducible] s_277
 theorem n_272_276 (z : Store) (tid : Tid) (h : tid ∉ ([227, 205, 226, 530, 508, 529] : List Tid)) : (s_276 z) tid = (s_272 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_272 z) (k_273 z)) (pF _ _ _ _ _ (k_274 z) (k_275 z)) tid h
 #a n_272_276
 record_prefix_opacity v_269_0 s_270 v_270_0 s_271 v_271_0 s_272 v_272_0 s_273 v_273_0 v_273_1 s_274 v_274_0 s_275 v_275_0 v_275_1 s_276 v_276_0 s_277

 end
 end TrainVerify.Denote.RuntimeWorld
