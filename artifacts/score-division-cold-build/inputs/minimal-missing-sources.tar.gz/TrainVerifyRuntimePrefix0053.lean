import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0052
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_408_0 (z : Store) : (s_408 z) 407 = (v_407_0 z) := w_407_0 z
 #a r_408_0
 theorem r_408_1 (z : Store) : (s_408 z) 589 = (v_406_0 z) := pR (k_407 z) (w_406_0 z)
 #a r_408_1
 theorem r_408_2 (z : Store) : (s_408 z) 591 = (v_400_0 z) := pR (n_404_408 z) (pR (k_403 z) (pR (k_402 z) (pR (k_401 z) (w_400_0 z))))
 #a r_408_2
 def v_408_0 (z : Store) : Tensor := tensorSum [(v_407_0 z), (v_406_0 z), (v_400_0 z)]
 def s_409 (z : Store) : Store := storeSet (s_408 z) [(404, tensorSum [((s_408 z) 407), ((s_408 z) 589), ((s_408 z) 591)])]
 theorem t_408 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_439) (pmPeers pmNode_439) (s_408 z) pmNode_439 none = some (s_409 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_408
 theorem k_408 (z : Store) (tid : Tid) (h : tid ∉ [404]) : (s_409 z) tid = (s_408 z) tid := by
   unfold s_409
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_408
 theorem w_408_0 (z : Store) : (s_409 z) 404 = v_408_0 z := by
   unfold s_409
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_408_0, r_408_0 z, r_408_1 z, r_408_2 z] <;> rfl
 #a w_408_0
 theorem h_408_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_408_0 z).shape = [1, 8, 64] := by
   unfold v_408_0
   rw [tensorSum_shape]
   exact h_407_0 z z_
 #a h_408_0
 attribute [local irreducible] v_408_0
 attribute [local irreducible] s_409
 theorem n_400_408 (z : Store) (tid : Tid) (h : tid ∉ ([591, 410, 331, 286, 104, 25, 101, 100, 21, 23, 589, 407, 328] : List Tid)) : (s_408 z) tid = (s_400 z) tid := by
   exact pF _ _ _ _ _ (n_400_404 z) (n_404_408 z) tid h
 #a n_400_408
 theorem r_409_0 (z : Store) : (s_409 z) 404 = (v_408_0 z) := w_408_0 z
 #a r_409_0
 theorem r_409_1 (z : Store) : (s_409 z) 401 = (v_18_0 z) := pR (k_408 z) (pR (n_400_408 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_24_32 z) (pR (n_20_24 z) (pR (k_19 z) (r_19_0 z))))))))))
 #a r_409_1
 theorem r_409_2 (z : Store) : (s_409 z) 304 = (z 304) := pR (k_408 z) (pR (n_400_408 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_24_32 z) (pR (n_20_24 z) (pR (k_19 z) (r_19_1 z))))))))))
 #a r_409_2
 theorem r_409_3 (z : Store) : (s_409 z) 305 = (z 305) := pR (k_408 z) (pR (n_400_408 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_24_32 z) (pR (n_20_24 z) (pR (k_19 z) (r_19_2 z))))))))))
 #a r_409_3
 def v_409_0 (z : Store) : Tensor := (bw_layernorm (v_408_0 z) (v_18_0 z) (z 304) (z 305)).1
 def v_409_1 (z : Store) : Tensor := (bw_layernorm (v_408_0 z) (v_18_0 z) (z 304) (z 305)).2.1
 def v_409_2 (z : Store) : Tensor := (bw_layernorm (v_408_0 z) (v_18_0 z) (z 304) (z 305)).2.2
 def s_410 (z : Store) : Store := storeSet (s_409 z) [(403, (bw_layernorm ((s_409 z) 404) ((s_409 z) 401) ((s_409 z) 304) ((s_409 z) 305)).1), (324, (bw_layernorm ((s_409 z) 404) ((s_409 z) 401) ((s_409 z) 304) ((s_409 z) 305)).2.1), (326, (bw_layernorm ((s_409 z) 404) ((s_409 z) 401) ((s_409 z) 304) ((s_409 z) 305)).2.2)]
 theorem t_409 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_440) (pmPeers pmNode_440) (s_409 z) pmNode_440 none = some (s_410 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_409
 theorem k_409 (z : Store) (tid : Tid) (h : tid ∉ [403, 324, 326]) : (s_410 z) tid = (s_409 z) tid := by
   unfold s_410
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_409
 theorem w_409_0 (z : Store) : (s_410 z) 403 = v_409_0 z := by
   unfold s_410
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_409_0, r_409_0 z, r_409_1 z, r_409_2 z, r_409_3 z] <;> rfl
 #a w_409_0
 theorem h_409_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_409_0 z).shape = [1, 8, 64] := by
   unfold v_409_0
   rw [bw_layernorm_dx_shape (v_408_0 z) (v_18_0 z) (z 304) (z 305) 64 [8, 1] (by rw [h_18_0 z z_]; rfl)]
   exact h_18_0 z z_
 #a h_409_0
 attribute [local irreducible] v_409_0
 theorem w_409_1 (z : Store) : (s_410 z) 324 = v_409_1 z := by
   unfold s_410
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_409_1, r_409_0 z, r_409_1 z, r_409_2 z, r_409_3 z] <;> rfl
 #a w_409_1
 theorem h_409_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_409_1 z).shape = [64] := by
   unfold v_409_1
   rw [bw_layernorm_dw_shape (v_408_0 z) (v_18_0 z) (z 304) (z 305) 64 [8, 1] (by rw [h_18_0 z z_]; rfl)]
   exact i_7 z z_
 #a h_409_1
 attribute [local irreducible] v_409_1
 theorem w_409_2 (z : Store) : (s_410 z) 326 = v_409_2 z := by
   unfold s_410
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_409_2, r_409_0 z, r_409_1 z, r_409_2 z, r_409_3 z] <;> rfl
 #a w_409_2
 theorem h_409_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_409_2 z).shape = [64] := by
   unfold v_409_2
   rw [bw_layernorm_db_shape (v_408_0 z) (v_18_0 z) (z 304) (z 305) 64 [8, 1] (by rw [h_18_0 z z_]; rfl)]
   exact i_8 z z_
 #a h_409_2
 attribute [local irreducible] v_409_2
 attribute [local irreducible] s_410
 theorem r_410_0 (z : Store) : (s_410 z) 100 = (v_405_0 z) := pR (k_409 z) (pR (k_408 z) (pR (k_407 z) (pR (k_406 z) (w_405_0 z))))
 #a r_410_0
 theorem r_410_1 (z : Store) : (s_410 z) 403 = (v_409_0 z) := w_409_0 z
 #a r_410_1
 def v_410_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_405_0 z), (v_409_0 z)]
 theorem g_410 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_205) (s_410 z) pmNode_205 1 2 284 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_205, r_410_0 z, r_410_1 z, h_405_0 z z_, h_409_0 z z_]
 #a g_410
 def s_411 (z : Store) : Store := pL [0, 1] (s_410 z) pmNode_205 1 2
 theorem t_410 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_205) (pmPeers pmNode_205) (s_410 z) pmNode_205 none = some (s_411 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_205) (s_410 z) pmNode_205).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 284 (by decide) (g_410 z z_)]
   rfl
 #a t_410
 theorem k_410 (z : Store) (tid : Tid) (h : tid ∉ [284]) : (s_411 z) tid = (s_410 z) tid := by
   unfold s_411
   dsimp only [pL, pmNode_205, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_410
 theorem w_410_0 (z : Store) : (s_411 z) 284 = v_410_0 z := by
   unfold s_411
   dsimp only [pL, pmNode_205, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_410_0, r_410_0 z, r_410_1 z] <;> rfl
 #a w_410_0
 theorem h_410_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_410_0 z).shape = [1, 16, 32] := by
   unfold v_410_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_405_0 z z_]
 #a h_410_0
 attribute [local irreducible] v_410_0
 attribute [local irreducible] s_411
 theorem r_411_0 (z : Store) : (s_411 z) 284 = (v_410_0 z) := w_410_0 z
 #a r_411_0
 theorem r_411_1 (z : Store) : (s_411 z) 166 = (v_338_0 z) := pR (k_410 z) (pR (k_409 z) (pR (k_408 z) (pR (n_400_408 z) (pR (n_384_400 z) (pR (n_352_384 z) (pR (n_344_352 z) (pR (n_340_344 z) (pR (k_339 z) (w_338_0 z)))))))))
 #a r_411_1
 def v_411_0 (z : Store) : Tensor := tensorSum [(v_410_0 z), (v_338_0 z)]
 def s_412 (z : Store) : Store := storeSet (s_411 z) [(97, tensorSum [((s_411 z) 284), ((s_411 z) 166)])]
 theorem t_411 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_206) (pmPeers pmNode_206) (s_411 z) pmNode_206 none = some (s_412 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_411
 theorem k_411 (z : Store) (tid : Tid) (h : tid ∉ [97]) : (s_412 z) tid = (s_411 z) tid := by
   unfold s_412
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_411
 theorem w_411_0 (z : Store) : (s_412 z) 97 = v_411_0 z := by
   unfold s_412
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_411_0, r_411_0 z, r_411_1 z] <;> rfl
 #a w_411_0
 theorem h_411_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_411_0 z).shape = [1, 16, 32] := by
   unfold v_411_0
   rw [tensorSum_shape]
   exact h_410_0 z z_
 #a h_411_0
 attribute [local irreducible] v_411_0
 attribute [local irreducible] s_412
 theorem n_408_412 (z : Store) (tid : Tid) (h : tid ∉ ([404, 403, 324, 326, 284, 97] : List Tid)) : (s_412 z) tid = (s_408 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_408 z) (k_409 z)) (pF _ _ _ _ _ (k_410 z) (k_411 z)) tid h
 #a n_408_412
 theorem r_412_0 (z : Store) : (s_412 z) 97 = (v_411_0 z) := w_411_0 z
 #a r_412_0
 theorem r_412_1 (z : Store) : (s_412 z) 89 = (v_1_0 z) := pR (n_408_412 z) (pR (n_400_408 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_12_16 z) (pR (k_11 z) (pR (k_10 z) (pR (k_9 z) (r_9_0 z))))))))))))
 #a r_412_1
 theorem r_412_2 (z : Store) : (s_412 z) 94 = (v_8_0 z) := pR (n_408_412 z) (pR (n_400_408 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_12_16 z) (pR (k_11 z) (pR (k_10 z) (pR (k_9 z) (r_9_1 z))))))))))))
 #a r_412_2
 def v_412_0 (z : Store) : Tensor := (bw_add2 (v_411_0 z) (v_1_0 z) (v_8_0 z)).1
 def v_412_1 (z : Store) : Tensor := (bw_add2 (v_411_0 z) (v_1_0 z) (v_8_0 z)).2
 def s_413 (z : Store) : Store := storeSet (s_412 z) [(90, (bw_add2 ((s_412 z) 97) ((s_412 z) 89) ((s_412 z) 94)).1), (96, (bw_add2 ((s_412 z) 97) ((s_412 z) 89) ((s_412 z) 94)).2)]
 theorem t_412 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_207) (pmPeers pmNode_207) (s_412 z) pmNode_207 none = some (s_413 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_412
 theorem k_412 (z : Store) (tid : Tid) (h : tid ∉ [90, 96]) : (s_413 z) tid = (s_412 z) tid := by
   unfold s_413
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_412
 theorem w_412_0 (z : Store) : (s_413 z) 90 = v_412_0 z := by
   unfold s_413
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_412_0, r_412_0 z, r_412_1 z, r_412_2 z] <;> rfl
 #a w_412_0
 theorem h_412_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_412_0 z).shape = [1, 16, 32] := by
   unfold v_412_0
   exact h_1_0 z z_
 #a h_412_0
 attribute [local irreducible] v_412_0
 theorem w_412_1 (z : Store) : (s_413 z) 96 = v_412_1 z := by
   unfold s_413
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_412_1, r_412_0 z, r_412_1 z, r_412_2 z] <;> rfl
 #a w_412_1
 theorem h_412_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_412_1 z).shape = [1, 16, 32] := by
   unfold v_412_1
   exact h_8_0 z z_
 #a h_412_1
 attribute [local irreducible] v_412_1
 attribute [local irreducible] s_413
 theorem r_413_0 (z : Store) : (s_413 z) 100 = (v_405_0 z) := pR (k_412 z) (pR (k_411 z) (pR (k_410 z) (r_410_0 z)))
 #a r_413_0
 theorem r_413_1 (z : Store) : (s_413 z) 403 = (v_409_0 z) := pR (k_412 z) (pR (k_411 z) (pR (k_410 z) (r_410_1 z)))
 #a r_413_1
 def v_413_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_405_0 z), (v_409_0 z)]
 theorem g_413 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_441) (s_413 z) pmNode_441 1 2 587 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_441, r_413_0 z, r_413_1 z, h_405_0 z z_, h_409_0 z z_]
 #a g_413
 def s_414 (z : Store) : Store := pL [0, 1] (s_413 z) pmNode_441 1 2
 theorem t_413 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_441) (pmPeers pmNode_441) (s_413 z) pmNode_441 none = some (s_414 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_441) (s_413 z) pmNode_441).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 587 (by decide) (g_413 z z_)]
   rfl
 #a t_413
 theorem k_413 (z : Store) (tid : Tid) (h : tid ∉ [587]) : (s_414 z) tid = (s_413 z) tid := by
   unfold s_414
   dsimp only [pL, pmNode_441, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_413
 theorem w_413_0 (z : Store) : (s_414 z) 587 = v_413_0 z := by
   unfold s_414
   dsimp only [pL, pmNode_441, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_413_0, r_413_0 z, r_413_1 z] <;> rfl
 #a w_413_0
 theorem h_413_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_413_0 z).shape = [1, 16, 32] := by
   unfold v_413_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_405_0 z z_]
 #a h_413_0
 attribute [local irreducible] v_413_0
 attribute [local irreducible] s_414
 theorem r_414_0 (z : Store) : (s_414 z) 587 = (v_413_0 z) := w_413_0 z
 #a r_414_0
 theorem r_414_1 (z : Store) : (s_414 z) 469 = (v_341_0 z) := pR (k_413 z) (pR (k_412 z) (pR (n_408_412 z) (pR (n_400_408 z) (pR (n_384_400 z) (pR (n_352_384 z) (pR (n_344_352 z) (pR (k_343 z) (pR (k_342 z) (w_341_0 z)))))))))
 #a r_414_1
 def v_414_0 (z : Store) : Tensor := tensorSum [(v_413_0 z), (v_341_0 z)]
 def s_415 (z : Store) : Store := storeSet (s_414 z) [(400, tensorSum [((s_414 z) 587), ((s_414 z) 469)])]
 theorem t_414 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_442) (pmPeers pmNode_442) (s_414 z) pmNode_442 none = some (s_415 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_414
 theorem k_414 (z : Store) (tid : Tid) (h : tid ∉ [400]) : (s_415 z) tid = (s_414 z) tid := by
   unfold s_415
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_414
 theorem w_414_0 (z : Store) : (s_415 z) 400 = v_414_0 z := by
   unfold s_415
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_414_0, r_414_0 z, r_414_1 z] <;> rfl
 #a w_414_0
 theorem h_414_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_414_0 z).shape = [1, 16, 32] := by
   unfold v_414_0
   rw [tensorSum_shape]
   exact h_413_0 z z_
 #a h_414_0
 attribute [local irreducible] v_414_0
 attribute [local irreducible] s_415
 record_prefix_opacity v_408_0 s_409 v_409_0 v_409_1 v_409_2 s_410 v_410_0 s_411 v_411_0 s_412 v_412_0 v_412_1 s_413 v_413_0 s_414 v_414_0 s_415

 end
 end TrainVerify.Denote.RuntimeWorld
