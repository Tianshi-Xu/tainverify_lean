import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0111
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_874_0 (z : Store) : (s_874 z) 66 = (v_227_1 z) := pR (k_873 z) (pR (k_872 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (pR (k_850 z) (pR (k_849 z) (r_849_0 z))))))))
 #a r_874_0
 theorem r_874_1 (z : Store) : (s_874 z) 369 = (v_230_1 z) := pR (k_873 z) (pR (k_872 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (pR (k_850 z) (pR (k_849 z) (r_849_1 z))))))))
 #a r_874_1
 theorem r_874_2 (z : Store) : (s_874 z) 672 = (v_649_1 z) := pR (k_873 z) (pR (k_872 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (pR (k_850 z) (pR (k_849 z) (r_849_2 z))))))))
 #a r_874_2
 theorem r_874_3 (z : Store) : (s_874 z) 975 = (v_652_1 z) := pR (k_873 z) (pR (k_872 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (pR (k_850 z) (pR (k_849 z) (r_849_3 z))))))))
 #a r_874_3
 def v_874_0 (z : Store) : Tensor := cross_dp_wred [(v_227_1 z), (v_230_1 z), (v_649_1 z), (v_652_1 z)]
 theorem g_874 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_453) (s_874 z) pmNode_453 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_453, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_874_1 z, r_874_0 z]
     exact (h_230_1 z z_).trans (h_227_1 z z_).symm
   · rw [r_874_2 z, r_874_0 z]
     exact (h_649_1 z z_).trans (h_227_1 z z_).symm
   · rw [r_874_3 z, r_874_0 z]
     exact (h_652_1 z z_).trans (h_227_1 z z_).symm
 #a g_874
 def s_875 (z : Store) : Store := storeSet (s_874 z) [(370, cross_dp_wred [((s_874 z) 66), ((s_874 z) 369), ((s_874 z) 672), ((s_874 z) 975)])]
 theorem t_874 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_453) (pmPeers pmNode_453) (s_874 z) pmNode_453 none = some (s_875 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_453) (s_874 z) pmNode_453 = _
   rw [wredStep, if_pos ⟨by decide, g_874 z z_⟩]
   rfl
 #a t_874
 theorem k_874 (z : Store) (tid : Tid) (h : tid ∉ [370]) : (s_875 z) tid = (s_874 z) tid := by
   unfold s_875
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_874
 theorem w_874_0 (z : Store) : (s_875 z) 370 = v_874_0 z := by
   unfold s_875
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_874_0, r_874_0 z, r_874_1 z, r_874_2 z, r_874_3 z] <;> rfl
 #a w_874_0
 theorem h_874_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_874_0 z).shape = [64, 256] := by
   unfold v_874_0
   rw [tensorSum_shape]
   exact h_227_1 z z_
 #a h_874_0
 attribute [local irreducible] v_874_0
 attribute [local irreducible] s_875
 theorem r_875_0 (z : Store) : (s_875 z) 68 = (v_221_1 z) := pR (k_874 z) (pR (k_873 z) (pR (k_872 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (pR (k_850 z) (r_850_0 z))))))))
 #a r_875_0
 theorem r_875_1 (z : Store) : (s_875 z) 371 = (v_224_1 z) := pR (k_874 z) (pR (k_873 z) (pR (k_872 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (pR (k_850 z) (r_850_1 z))))))))
 #a r_875_1
 theorem r_875_2 (z : Store) : (s_875 z) 674 = (v_643_1 z) := pR (k_874 z) (pR (k_873 z) (pR (k_872 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (pR (k_850 z) (r_850_2 z))))))))
 #a r_875_2
 theorem r_875_3 (z : Store) : (s_875 z) 977 = (v_646_1 z) := pR (k_874 z) (pR (k_873 z) (pR (k_872 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (pR (k_850 z) (r_850_3 z))))))))
 #a r_875_3
 def v_875_0 (z : Store) : Tensor := cross_dp_wred [(v_221_1 z), (v_224_1 z), (v_643_1 z), (v_646_1 z)]
 theorem g_875 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_454) (s_875 z) pmNode_454 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_454, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_875_1 z, r_875_0 z]
     exact (h_224_1 z z_).trans (h_221_1 z z_).symm
   · rw [r_875_2 z, r_875_0 z]
     exact (h_643_1 z z_).trans (h_221_1 z z_).symm
   · rw [r_875_3 z, r_875_0 z]
     exact (h_646_1 z z_).trans (h_221_1 z z_).symm
 #a g_875
 def s_876 (z : Store) : Store := storeSet (s_875 z) [(372, cross_dp_wred [((s_875 z) 68), ((s_875 z) 371), ((s_875 z) 674), ((s_875 z) 977)])]
 theorem t_875 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_454) (pmPeers pmNode_454) (s_875 z) pmNode_454 none = some (s_876 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_454) (s_875 z) pmNode_454 = _
   rw [wredStep, if_pos ⟨by decide, g_875 z z_⟩]
   rfl
 #a t_875
 theorem k_875 (z : Store) (tid : Tid) (h : tid ∉ [372]) : (s_876 z) tid = (s_875 z) tid := by
   unfold s_876
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_875
 theorem w_875_0 (z : Store) : (s_876 z) 372 = v_875_0 z := by
   unfold s_876
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_875_0, r_875_0 z, r_875_1 z, r_875_2 z, r_875_3 z] <;> rfl
 #a w_875_0
 theorem h_875_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_875_0 z).shape = [64] := by
   unfold v_875_0
   rw [tensorSum_shape]
   exact h_221_1 z z_
 #a h_875_0
 attribute [local irreducible] v_875_0
 attribute [local irreducible] s_876
 theorem n_872_876 (z : Store) (tid : Tid) (h : tid ∉ ([329, 365, 370, 372] : List Tid)) : (s_876 z) tid = (s_872 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_872 z) (k_873 z)) (pF _ _ _ _ _ (k_874 z) (k_875 z)) tid h
 #a n_872_876
 theorem r_876_0 (z : Store) : (s_876 z) 70 = (v_221_2 z) := pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (r_851_0 z)))))
 #a r_876_0
 theorem r_876_1 (z : Store) : (s_876 z) 373 = (v_224_2 z) := pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (r_851_1 z)))))
 #a r_876_1
 theorem r_876_2 (z : Store) : (s_876 z) 676 = (v_643_2 z) := pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (r_851_2 z)))))
 #a r_876_2
 theorem r_876_3 (z : Store) : (s_876 z) 979 = (v_646_2 z) := pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (pR (k_851 z) (r_851_3 z)))))
 #a r_876_3
 def v_876_0 (z : Store) : Tensor := cross_dp_wred [(v_221_2 z), (v_224_2 z), (v_643_2 z), (v_646_2 z)]
 theorem g_876 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_455) (s_876 z) pmNode_455 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_455, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_876_1 z, r_876_0 z]
     exact (h_224_2 z z_).trans (h_221_2 z z_).symm
   · rw [r_876_2 z, r_876_0 z]
     exact (h_643_2 z z_).trans (h_221_2 z z_).symm
   · rw [r_876_3 z, r_876_0 z]
     exact (h_646_2 z z_).trans (h_221_2 z z_).symm
 #a g_876
 def s_877 (z : Store) : Store := storeSet (s_876 z) [(374, cross_dp_wred [((s_876 z) 70), ((s_876 z) 373), ((s_876 z) 676), ((s_876 z) 979)])]
 theorem t_876 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_455) (pmPeers pmNode_455) (s_876 z) pmNode_455 none = some (s_877 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_455) (s_876 z) pmNode_455 = _
   rw [wredStep, if_pos ⟨by decide, g_876 z z_⟩]
   rfl
 #a t_876
 theorem k_876 (z : Store) (tid : Tid) (h : tid ∉ [374]) : (s_877 z) tid = (s_876 z) tid := by
   unfold s_877
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_876
 theorem w_876_0 (z : Store) : (s_877 z) 374 = v_876_0 z := by
   unfold s_877
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_876_0, r_876_0 z, r_876_1 z, r_876_2 z, r_876_3 z] <;> rfl
 #a w_876_0
 theorem h_876_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_876_0 z).shape = [64] := by
   unfold v_876_0
   rw [tensorSum_shape]
   exact h_221_2 z z_
 #a h_876_0
 attribute [local irreducible] v_876_0
 attribute [local irreducible] s_877
 theorem r_877_0 (z : Store) : (s_877 z) 33 = (v_343_1 z) := pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (r_852_0 z)))))
 #a r_877_0
 theorem r_877_1 (z : Store) : (s_877 z) 336 = (v_345_1 z) := pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (r_852_1 z)))))
 #a r_877_1
 theorem r_877_2 (z : Store) : (s_877 z) 639 = (v_765_1 z) := pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (r_852_2 z)))))
 #a r_877_2
 theorem r_877_3 (z : Store) : (s_877 z) 942 = (v_767_1 z) := pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (n_852_856 z) (r_852_3 z)))))
 #a r_877_3
 def v_877_0 (z : Store) : Tensor := cross_dp_wred [(v_343_1 z), (v_345_1 z), (v_765_1 z), (v_767_1 z)]
 theorem g_877 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_456) (s_877 z) pmNode_456 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_456, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_877_1 z, r_877_0 z]
     exact (h_345_1 z z_).trans (h_343_1 z z_).symm
   · rw [r_877_2 z, r_877_0 z]
     exact (h_765_1 z z_).trans (h_343_1 z z_).symm
   · rw [r_877_3 z, r_877_0 z]
     exact (h_767_1 z z_).trans (h_343_1 z z_).symm
 #a g_877
 def s_878 (z : Store) : Store := storeSet (s_877 z) [(337, cross_dp_wred [((s_877 z) 33), ((s_877 z) 336), ((s_877 z) 639), ((s_877 z) 942)])]
 theorem t_877 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_456) (pmPeers pmNode_456) (s_877 z) pmNode_456 none = some (s_878 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_456) (s_877 z) pmNode_456 = _
   rw [wredStep, if_pos ⟨by decide, g_877 z z_⟩]
   rfl
 #a t_877
 theorem k_877 (z : Store) (tid : Tid) (h : tid ∉ [337]) : (s_878 z) tid = (s_877 z) tid := by
   unfold s_878
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_877
 theorem w_877_0 (z : Store) : (s_878 z) 337 = v_877_0 z := by
   unfold s_878
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_877_0, r_877_0 z, r_877_1 z, r_877_2 z, r_877_3 z] <;> rfl
 #a w_877_0
 theorem h_877_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_877_0 z).shape = [64, 64] := by
   unfold v_877_0
   rw [tensorSum_shape]
   exact h_343_1 z z_
 #a h_877_0
 attribute [local irreducible] v_877_0
 attribute [local irreducible] s_878
 theorem r_878_0 (z : Store) : (s_878 z) 35 = (v_330_1 z) := pR (k_877 z) (pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (k_855 z) (pR (k_854 z) (pR (k_853 z) (r_853_0 z))))))))
 #a r_878_0
 theorem r_878_1 (z : Store) : (s_878 z) 338 = (v_335_1 z) := pR (k_877 z) (pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (k_855 z) (pR (k_854 z) (pR (k_853 z) (r_853_1 z))))))))
 #a r_878_1
 theorem r_878_2 (z : Store) : (s_878 z) 641 = (v_752_1 z) := pR (k_877 z) (pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (k_855 z) (pR (k_854 z) (pR (k_853 z) (r_853_2 z))))))))
 #a r_878_2
 theorem r_878_3 (z : Store) : (s_878 z) 944 = (v_757_1 z) := pR (k_877 z) (pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (k_855 z) (pR (k_854 z) (pR (k_853 z) (r_853_3 z))))))))
 #a r_878_3
 def v_878_0 (z : Store) : Tensor := cross_dp_wred [(v_330_1 z), (v_335_1 z), (v_752_1 z), (v_757_1 z)]
 theorem g_878 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_457) (s_878 z) pmNode_457 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_457, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_878_1 z, r_878_0 z]
     exact (h_335_1 z z_).trans (h_330_1 z z_).symm
   · rw [r_878_2 z, r_878_0 z]
     exact (h_752_1 z z_).trans (h_330_1 z z_).symm
   · rw [r_878_3 z, r_878_0 z]
     exact (h_757_1 z z_).trans (h_330_1 z z_).symm
 #a g_878
 def s_879 (z : Store) : Store := storeSet (s_878 z) [(339, cross_dp_wred [((s_878 z) 35), ((s_878 z) 338), ((s_878 z) 641), ((s_878 z) 944)])]
 theorem t_878 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_457) (pmPeers pmNode_457) (s_878 z) pmNode_457 none = some (s_879 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_457) (s_878 z) pmNode_457 = _
   rw [wredStep, if_pos ⟨by decide, g_878 z z_⟩]
   rfl
 #a t_878
 theorem k_878 (z : Store) (tid : Tid) (h : tid ∉ [339]) : (s_879 z) tid = (s_878 z) tid := by
   unfold s_879
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_878
 theorem w_878_0 (z : Store) : (s_879 z) 339 = v_878_0 z := by
   unfold s_879
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_878_0, r_878_0 z, r_878_1 z, r_878_2 z, r_878_3 z] <;> rfl
 #a w_878_0
 theorem h_878_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_878_0 z).shape = [64] := by
   unfold v_878_0
   rw [tensorSum_shape]
   exact h_330_1 z z_
 #a h_878_0
 attribute [local irreducible] v_878_0
 attribute [local irreducible] s_879
 theorem r_879_0 (z : Store) : (s_879 z) 37 = (v_330_2 z) := pR (k_878 z) (pR (k_877 z) (pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (k_855 z) (pR (k_854 z) (r_854_0 z))))))))
 #a r_879_0
 theorem r_879_1 (z : Store) : (s_879 z) 340 = (v_335_2 z) := pR (k_878 z) (pR (k_877 z) (pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (k_855 z) (pR (k_854 z) (r_854_1 z))))))))
 #a r_879_1
 theorem r_879_2 (z : Store) : (s_879 z) 643 = (v_752_2 z) := pR (k_878 z) (pR (k_877 z) (pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (k_855 z) (pR (k_854 z) (r_854_2 z))))))))
 #a r_879_2
 theorem r_879_3 (z : Store) : (s_879 z) 946 = (v_757_2 z) := pR (k_878 z) (pR (k_877 z) (pR (k_876 z) (pR (n_872_876 z) (pR (n_864_872 z) (pR (n_856_864 z) (pR (k_855 z) (pR (k_854 z) (r_854_3 z))))))))
 #a r_879_3
 def v_879_0 (z : Store) : Tensor := cross_dp_wred [(v_330_2 z), (v_335_2 z), (v_752_2 z), (v_757_2 z)]
 theorem g_879 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_458) (s_879 z) pmNode_458 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_458, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_879_1 z, r_879_0 z]
     exact (h_335_2 z z_).trans (h_330_2 z z_).symm
   · rw [r_879_2 z, r_879_0 z]
     exact (h_752_2 z z_).trans (h_330_2 z z_).symm
   · rw [r_879_3 z, r_879_0 z]
     exact (h_757_2 z z_).trans (h_330_2 z z_).symm
 #a g_879
 def s_880 (z : Store) : Store := storeSet (s_879 z) [(341, cross_dp_wred [((s_879 z) 37), ((s_879 z) 340), ((s_879 z) 643), ((s_879 z) 946)])]
 theorem t_879 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_458) (pmPeers pmNode_458) (s_879 z) pmNode_458 none = some (s_880 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_458) (s_879 z) pmNode_458 = _
   rw [wredStep, if_pos ⟨by decide, g_879 z z_⟩]
   rfl
 #a t_879
 theorem k_879 (z : Store) (tid : Tid) (h : tid ∉ [341]) : (s_880 z) tid = (s_879 z) tid := by
   unfold s_880
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_879
 theorem w_879_0 (z : Store) : (s_880 z) 341 = v_879_0 z := by
   unfold s_880
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_879_0, r_879_0 z, r_879_1 z, r_879_2 z, r_879_3 z] <;> rfl
 #a w_879_0
 theorem h_879_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_879_0 z).shape = [64] := by
   unfold v_879_0
   rw [tensorSum_shape]
   exact h_330_2 z z_
 #a h_879_0
 attribute [local irreducible] v_879_0
 attribute [local irreducible] s_880
 theorem n_876_880 (z : Store) (tid : Tid) (h : tid ∉ ([374, 337, 339, 341] : List Tid)) : (s_880 z) tid = (s_876 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_876 z) (k_877 z)) (pF _ _ _ _ _ (k_878 z) (k_879 z)) tid h
 #a n_876_880
 theorem n_872_880 (z : Store) (tid : Tid) (h : tid ∉ ([329, 365, 370, 372, 374, 337, 339, 341] : List Tid)) : (s_880 z) tid = (s_872 z) tid := by
   exact pF _ _ _ _ _ (n_872_876 z) (n_876_880 z) tid h
 #a n_872_880
 theorem n_864_880 (z : Store) (tid : Tid) (h : tid ∉ ([74, 49, 52, 55, 323, 325, 327, 363, 329, 365, 370, 372, 374, 337, 339, 341] : List Tid)) : (s_880 z) tid = (s_864 z) tid := by
   exact pF _ _ _ _ _ (n_864_872 z) (n_872_880 z) tid h
 #a n_864_880
 record_prefix_opacity v_874_0 s_875 v_875_0 s_876 v_876_0 s_877 v_877_0 s_878 v_878_0 s_879 v_879_0 s_880

 end
 end TrainVerify.Denote.RuntimeWorld
