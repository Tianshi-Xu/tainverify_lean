import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0053
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_415_0 (z : Store) : (s_415 z) 400 = (v_414_0 z) := w_414_0 z
 #a r_415_0
 theorem r_415_1 (z : Store) : (s_415 z) 392 = (v_5_0 z) := pR (k_414 z) (pR (k_413 z) (pR (k_412 z) (pR (n_408_412 z) (pR (n_400_408 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_12_16 z) (r_12_0 z))))))))))))
 #a r_415_1
 theorem r_415_2 (z : Store) : (s_415 z) 397 = (v_11_0 z) := pR (k_414 z) (pR (k_413 z) (pR (k_412 z) (pR (n_408_412 z) (pR (n_400_408 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_12_16 z) (r_12_1 z))))))))))))
 #a r_415_2
 def v_415_0 (z : Store) : Tensor := (bw_add2 (v_414_0 z) (v_5_0 z) (v_11_0 z)).1
 def v_415_1 (z : Store) : Tensor := (bw_add2 (v_414_0 z) (v_5_0 z) (v_11_0 z)).2
 def s_416 (z : Store) : Store := storeSet (s_415 z) [(393, (bw_add2 ((s_415 z) 400) ((s_415 z) 392) ((s_415 z) 397)).1), (399, (bw_add2 ((s_415 z) 400) ((s_415 z) 392) ((s_415 z) 397)).2)]
 theorem t_415 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_443) (pmPeers pmNode_443) (s_415 z) pmNode_443 none = some (s_416 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_415
 theorem k_415 (z : Store) (tid : Tid) (h : tid ∉ [393, 399]) : (s_416 z) tid = (s_415 z) tid := by
   unfold s_416
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_415
 theorem w_415_0 (z : Store) : (s_416 z) 393 = v_415_0 z := by
   unfold s_416
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_415_0, r_415_0 z, r_415_1 z, r_415_2 z] <;> rfl
 #a w_415_0
 theorem h_415_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_415_0 z).shape = [1, 16, 32] := by
   unfold v_415_0
   exact h_5_0 z z_
 #a h_415_0
 attribute [local irreducible] v_415_0
 theorem w_415_1 (z : Store) : (s_416 z) 399 = v_415_1 z := by
   unfold s_416
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_415_1, r_415_0 z, r_415_1 z, r_415_2 z] <;> rfl
 #a w_415_1
 theorem h_415_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_415_1 z).shape = [1, 16, 32] := by
   unfold v_415_1
   exact h_11_0 z z_
 #a h_415_1
 attribute [local irreducible] v_415_1
 attribute [local irreducible] s_416
 theorem r_416_0 (z : Store) : (s_416 z) 96 = (v_412_1 z) := pR (k_415 z) (pR (k_414 z) (pR (k_413 z) (w_412_1 z)))
 #a r_416_0
 theorem r_416_1 (z : Store) : (s_416 z) 399 = (v_415_1 z) := w_415_1 z
 #a r_416_1
 def v_416_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_412_1 z), (v_415_1 z)]
 theorem g_416 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_208) (s_416 z) pmNode_208 2 1 93 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_208, r_416_0 z, r_416_1 z, h_412_1 z z_, h_415_1 z z_]
 #a g_416
 def s_417 (z : Store) : Store := pL [0, 1] (s_416 z) pmNode_208 2 1
 theorem t_416 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_208) (pmPeers pmNode_208) (s_416 z) pmNode_208 none = some (s_417 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_208) (s_416 z) pmNode_208).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 93 (by decide) (g_416 z z_)]
   rfl
 #a t_416
 theorem k_416 (z : Store) (tid : Tid) (h : tid ∉ [93]) : (s_417 z) tid = (s_416 z) tid := by
   unfold s_417
   dsimp only [pL, pmNode_208, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_416
 theorem w_416_0 (z : Store) : (s_417 z) 93 = v_416_0 z := by
   unfold s_417
   dsimp only [pL, pmNode_208, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_416_0, r_416_0 z, r_416_1 z] <;> rfl
 #a w_416_0
 theorem h_416_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_416_0 z).shape = [1, 8, 64] := by
   unfold v_416_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_412_1 z z_]
 #a h_416_0
 attribute [local irreducible] v_416_0
 attribute [local irreducible] s_417
 theorem n_412_416 (z : Store) (tid : Tid) (h : tid ∉ ([90, 96, 587, 400, 393, 399] : List Tid)) : (s_416 z) tid = (s_412 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_412 z) (k_413 z)) (pF _ _ _ _ _ (k_414 z) (k_415 z)) tid h
 #a n_412_416
 theorem n_408_416 (z : Store) (tid : Tid) (h : tid ∉ ([404, 403, 324, 326, 284, 97, 90, 96, 587, 400, 393, 399] : List Tid)) : (s_416 z) tid = (s_408 z) tid := by
   exact pF _ _ _ _ _ (n_408_412 z) (n_412_416 z) tid h
 #a n_408_416
 theorem n_400_416 (z : Store) (tid : Tid) (h : tid ∉ ([591, 410, 331, 286, 104, 25, 101, 100, 21, 23, 589, 407, 328, 404, 403, 324, 326, 284, 97, 90, 96, 587, 400, 393, 399] : List Tid)) : (s_416 z) tid = (s_400 z) tid := by
   exact pF _ _ _ _ _ (n_400_408 z) (n_408_416 z) tid h
 #a n_400_416
 theorem n_384_416 (z : Store) (tid : Tid) (h : tid ∉ ([414, 425, 119, 107, 116, 422, 411, 419, 113, 105, 111, 31, 416, 408, 413, 334, 288, 108, 28, 591, 410, 331, 286, 104, 25, 101, 100, 21, 23, 589, 407, 328, 404, 403, 324, 326, 284, 97, 90, 96, 587, 400, 393, 399] : List Tid)) : (s_416 z) tid = (s_384 z) tid := by
   exact pF _ _ _ _ _ (n_384_400 z) (n_400_416 z) tid h
 #a n_384_416
 theorem r_417_0 (z : Store) : (s_417 z) 93 = (v_416_0 z) := w_416_0 z
 #a r_417_0
 theorem r_417_1 (z : Store) : (s_417 z) 91 = (v_2_0 z) := pR (k_416 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_8_16 z) (pR (n_4_8 z) (pR (k_3 z) (r_3_0 z))))))))))
 #a r_417_1
 theorem r_417_2 (z : Store) : (s_417 z) 0 = (z 0) := pR (k_416 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_8_16 z) (pR (n_4_8 z) (pR (k_3 z) (r_3_1 z))))))))))
 #a r_417_2
 def v_417_0 (z : Store) : Tensor := bw_embedding (v_416_0 z) (v_2_0 z) (z 0)
 def s_418 (z : Store) : Store := storeSet (s_417 z) [(19, bw_embedding ((s_417 z) 93) ((s_417 z) 91) ((s_417 z) 0))]
 theorem t_417 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_209) (pmPeers pmNode_209) (s_417 z) pmNode_209 none = some (s_418 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_417
 theorem k_417 (z : Store) (tid : Tid) (h : tid ∉ [19]) : (s_418 z) tid = (s_417 z) tid := by
   unfold s_418
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_417
 theorem w_417_0 (z : Store) : (s_418 z) 19 = v_417_0 z := by
   unfold s_418
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_417_0, r_417_0 z, r_417_1 z, r_417_2 z] <;> rfl
 #a w_417_0
 theorem h_417_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_417_0 z).shape = [16, 64] := by
   unfold v_417_0
   exact i_1 z z_
 #a h_417_0
 attribute [local irreducible] v_417_0
 attribute [local irreducible] s_418
 theorem r_418_0 (z : Store) : (s_418 z) 90 = (v_412_0 z) := pR (k_417 z) (pR (k_416 z) (pR (k_415 z) (pR (k_414 z) (pR (k_413 z) (w_412_0 z)))))
 #a r_418_0
 theorem r_418_1 (z : Store) : (s_418 z) 75 = (v_0_0 z) := pR (k_417 z) (pR (k_416 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_8_16 z) (pR (n_4_8 z) (pR (k_3 z) (pR (k_2 z) (pR (k_1 z) (r_1_0 z)))))))))))))
 #a r_418_1
 theorem r_418_2 (z : Store) : (s_418 z) 16 = (z 16) := pR (k_417 z) (pR (k_416 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_8_16 z) (pR (n_4_8 z) (pR (k_3 z) (pR (k_2 z) (pR (k_1 z) (r_1_1 z)))))))))))))
 #a r_418_2
 def v_418_0 (z : Store) : Tensor := bw_embedding (v_412_0 z) (v_0_0 z) (z 16)
 def s_419 (z : Store) : Store := storeSet (s_418 z) [(17, bw_embedding ((s_418 z) 90) ((s_418 z) 75) ((s_418 z) 16))]
 theorem t_418 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_210) (pmPeers pmNode_210) (s_418 z) pmNode_210 none = some (s_419 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_418
 theorem k_418 (z : Store) (tid : Tid) (h : tid ∉ [17]) : (s_419 z) tid = (s_418 z) tid := by
   unfold s_419
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_418
 theorem w_418_0 (z : Store) : (s_419 z) 17 = v_418_0 z := by
   unfold s_419
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_418_0, r_418_0 z, r_418_1 z, r_418_2 z] <;> rfl
 #a w_418_0
 theorem h_418_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_418_0 z).shape = [256, 32] := by
   unfold v_418_0
   exact i_0 z z_
 #a h_418_0
 attribute [local irreducible] v_418_0
 attribute [local irreducible] s_419
 theorem r_419_0 (z : Store) : (s_419 z) 96 = (v_412_1 z) := pR (k_418 z) (pR (k_417 z) (pR (k_416 z) (r_416_0 z)))
 #a r_419_0
 theorem r_419_1 (z : Store) : (s_419 z) 399 = (v_415_1 z) := pR (k_418 z) (pR (k_417 z) (pR (k_416 z) (r_416_1 z)))
 #a r_419_1
 def v_419_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_412_1 z), (v_415_1 z)]
 theorem g_419 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_444) (s_419 z) pmNode_444 2 1 396 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_444, r_419_0 z, r_419_1 z, h_412_1 z z_, h_415_1 z z_]
 #a g_419
 def s_420 (z : Store) : Store := pL [0, 1] (s_419 z) pmNode_444 2 1
 theorem t_419 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_444) (pmPeers pmNode_444) (s_419 z) pmNode_444 none = some (s_420 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_444) (s_419 z) pmNode_444).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 396 (by decide) (g_419 z z_)]
   rfl
 #a t_419
 theorem k_419 (z : Store) (tid : Tid) (h : tid ∉ [396]) : (s_420 z) tid = (s_419 z) tid := by
   unfold s_420
   dsimp only [pL, pmNode_444, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_419
 theorem w_419_0 (z : Store) : (s_420 z) 396 = v_419_0 z := by
   unfold s_420
   dsimp only [pL, pmNode_444, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_419_0, r_419_0 z, r_419_1 z] <;> rfl
 #a w_419_0
 theorem h_419_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_419_0 z).shape = [1, 8, 64] := by
   unfold v_419_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_412_1 z z_]
 #a h_419_0
 attribute [local irreducible] v_419_0
 attribute [local irreducible] s_420
 theorem n_416_420 (z : Store) (tid : Tid) (h : tid ∉ ([93, 19, 17, 396] : List Tid)) : (s_420 z) tid = (s_416 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_416 z) (k_417 z)) (pF _ _ _ _ _ (k_418 z) (k_419 z)) tid h
 #a n_416_420
 theorem r_420_0 (z : Store) : (s_420 z) 396 = (v_419_0 z) := w_419_0 z
 #a r_420_0
 theorem r_420_1 (z : Store) : (s_420 z) 394 = (v_6_0 z) := pR (n_416_420 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_8_16 z) (pR (k_7 z) (r_7_0 z)))))))))
 #a r_420_1
 theorem r_420_2 (z : Store) : (s_420 z) 303 = (z 303) := pR (n_416_420 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_8_16 z) (pR (k_7 z) (r_7_1 z)))))))))
 #a r_420_2
 def v_420_0 (z : Store) : Tensor := bw_embedding (v_419_0 z) (v_6_0 z) (z 303)
 def s_421 (z : Store) : Store := storeSet (s_420 z) [(322, bw_embedding ((s_420 z) 396) ((s_420 z) 394) ((s_420 z) 303))]
 theorem t_420 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_445) (pmPeers pmNode_445) (s_420 z) pmNode_445 none = some (s_421 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_420
 theorem k_420 (z : Store) (tid : Tid) (h : tid ∉ [322]) : (s_421 z) tid = (s_420 z) tid := by
   unfold s_421
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_420
 theorem w_420_0 (z : Store) : (s_421 z) 322 = v_420_0 z := by
   unfold s_421
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_420_0, r_420_0 z, r_420_1 z, r_420_2 z] <;> rfl
 #a w_420_0
 theorem h_420_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_420_0 z).shape = [16, 64] := by
   unfold v_420_0
   exact i_3 z z_
 #a h_420_0
 attribute [local irreducible] v_420_0
 attribute [local irreducible] s_421
 theorem r_421_0 (z : Store) : (s_421 z) 393 = (v_415_0 z) := pR (k_420 z) (pR (n_416_420 z) (w_415_0 z))
 #a r_421_0
 theorem r_421_1 (z : Store) : (s_421 z) 378 = (v_4_0 z) := pR (k_420 z) (pR (n_416_420 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_8_16 z) (pR (k_7 z) (pR (k_6 z) (pR (k_5 z) (r_5_0 z))))))))))))
 #a r_421_1
 theorem r_421_2 (z : Store) : (s_421 z) 319 = (z 319) := pR (k_420 z) (pR (n_416_420 z) (pR (n_384_416 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_8_16 z) (pR (k_7 z) (pR (k_6 z) (pR (k_5 z) (r_5_1 z))))))))))))
 #a r_421_2
 def v_421_0 (z : Store) : Tensor := bw_embedding (v_415_0 z) (v_4_0 z) (z 319)
 def s_422 (z : Store) : Store := storeSet (s_421 z) [(320, bw_embedding ((s_421 z) 393) ((s_421 z) 378) ((s_421 z) 319))]
 theorem t_421 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_446) (pmPeers pmNode_446) (s_421 z) pmNode_446 none = some (s_422 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_421
 theorem k_421 (z : Store) (tid : Tid) (h : tid ∉ [320]) : (s_422 z) tid = (s_421 z) tid := by
   unfold s_422
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_421
 theorem w_421_0 (z : Store) : (s_422 z) 320 = v_421_0 z := by
   unfold s_422
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_421_0, r_421_0 z, r_421_1 z, r_421_2 z] <;> rfl
 #a w_421_0
 theorem h_421_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_421_0 z).shape = [256, 32] := by
   unfold v_421_0
   exact i_2 z z_
 #a h_421_0
 attribute [local irreducible] v_421_0
 attribute [local irreducible] s_422
 def v_422_0 (z : Store) : Tensor := pmNode_472_port0
 def v_422_1 (z : Store) : Tensor := pmNode_472_port1
 def s_423 (z : Store) : Store := storeSet (s_422 z) pmNode_472_feed
 theorem t_422 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_472) (pmPeers pmNode_472) (s_422 z) pmNode_472 (some pmNode_472_feed) = some (s_423 z) := by
   exact pmNode_472_scoped_step (s_422 z)
 #a t_422
 theorem k_422 (z : Store) (tid : Tid) (h : tid ∉ [681, 682]) : (s_423 z) tid = (s_422 z) tid := by
   unfold s_423
   dsimp only [pmNode_472_feed]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_422
 theorem w_422_0 (z : Store) : (s_423 z) 681 = v_422_0 z := by
   unfold s_423
   dsimp only [pmNode_472_feed]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_422_0] <;> rfl
 #a w_422_0
 theorem h_422_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_422_0 z).shape = [1, 16] := by
   unfold v_422_0
   simp [pmNode_472_port0, Tensor.mkShape]
 #a h_422_0
 attribute [local irreducible] v_422_0
 theorem w_422_1 (z : Store) : (s_423 z) 682 = v_422_1 z := by
   unfold s_423
   dsimp only [pmNode_472_feed]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_422_1] <;> rfl
 #a w_422_1
 theorem h_422_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_422_1 z).shape = [1, 16] := by
   unfold v_422_1
   simp [pmNode_472_port1, Tensor.mkShape]
 #a h_422_1
 attribute [local irreducible] v_422_1
 attribute [local irreducible] s_423
 record_prefix_opacity v_415_0 v_415_1 s_416 v_416_0 s_417 v_417_0 s_418 v_418_0 s_419 v_419_0 s_420 v_420_0 s_421 v_421_0 s_422 v_422_0 v_422_1 s_423

 end
 end TrainVerify.Denote.RuntimeWorld
