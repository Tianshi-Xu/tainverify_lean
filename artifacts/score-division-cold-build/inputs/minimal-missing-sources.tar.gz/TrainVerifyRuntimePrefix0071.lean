import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0070
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_560_0 (z : Store) : (s_560 z) 813 = (v_551_0 z) := pR (n_556_560 z) (r_556_0 z)
 #a r_560_0
 theorem r_560_1 (z : Store) : (s_560 z) 1116 = (v_555_0 z) := pR (n_556_560 z) (r_556_1 z)
 #a r_560_1
 def v_560_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_551_0 z), (v_555_0 z)]
 theorem g_560 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_775) (s_560 z) pmNode_775 1 3 1119 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_775, r_560_0 z, r_560_1 z, h_551_0 z z_, h_555_0 z z_]
 #a g_560
 def s_561 (z : Store) : Store := pL [2, 3] (s_560 z) pmNode_775 1 3
 theorem t_560 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_775) (pmPeers pmNode_775) (s_560 z) pmNode_775 none = some (s_561 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_775) (s_560 z) pmNode_775).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 1119 (by decide) (g_560 z z_)]
   rfl
 #a t_560
 theorem k_560 (z : Store) (tid : Tid) (h : tid ∉ [1119]) : (s_561 z) tid = (s_560 z) tid := by
   unfold s_561
   dsimp only [pL, pmNode_775, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_560
 theorem w_560_0 (z : Store) : (s_561 z) 1119 = v_560_0 z := by
   unfold s_561
   dsimp only [pL, pmNode_775, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_560_0, r_560_0 z, r_560_1 z] <;> rfl
 #a w_560_0
 theorem h_560_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_560_0 z).shape = [1, 16, 4, 8] := by
   unfold v_560_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_551_0 z z_]
 #a h_560_0
 attribute [local irreducible] v_560_0
 attribute [local irreducible] s_561
 theorem r_561_0 (z : Store) : (s_561 z) 1119 = (v_560_0 z) := w_560_0 z
 #a r_561_0
 def v_561_0 (z : Store) : Tensor := transposeAxes 1 2 (v_560_0 z)
 def s_562 (z : Store) : Store := storeSet (s_561 z) [(1120, transposeAxes 1 2 ((s_561 z) 1119))]
 theorem t_561 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_776) (pmPeers pmNode_776) (s_561 z) pmNode_776 none = some (s_562 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_561
 theorem k_561 (z : Store) (tid : Tid) (h : tid ∉ [1120]) : (s_562 z) tid = (s_561 z) tid := by
   unfold s_562
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_561
 theorem w_561_0 (z : Store) : (s_562 z) 1120 = v_561_0 z := by
   unfold s_562
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_561_0, r_561_0 z] <;> rfl
 #a w_561_0
 theorem h_561_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_561_0 z).shape = [1, 4, 16, 8] := by
   unfold v_561_0
   change listSwapAt _ _ _ = _
   rw [h_560_0 z z_]
   rfl
 #a h_561_0
 attribute [local irreducible] v_561_0
 attribute [local irreducible] s_562
 theorem r_562_0 (z : Store) : (s_562 z) 802 = (v_537_0 z) := pR (k_561 z) (pR (k_560 z) (pR (k_559 z) (pR (k_558 z) (r_558_0 z))))
 #a r_562_0
 theorem r_562_1 (z : Store) : (s_562 z) 1105 = (v_545_0 z) := pR (k_561 z) (pR (k_560 z) (pR (k_559 z) (pR (k_558 z) (r_558_1 z))))
 #a r_562_1
 def v_562_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 1 [(v_537_0 z), (v_545_0 z)]
 def s_563 (z : Store) : Store := storeSet (s_562 z) [(1123, reduceScatterPrimDimN 2 2 1 [((s_562 z) 802), ((s_562 z) 1105)])]
 theorem t_562 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_777) (pmPeers pmNode_777) (s_562 z) pmNode_777 none = some (s_563 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_562 z) pmNode_777 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_562
 theorem k_562 (z : Store) (tid : Tid) (h : tid ∉ [1123]) : (s_563 z) tid = (s_562 z) tid := by
   unfold s_563
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_562
 theorem w_562_0 (z : Store) : (s_563 z) 1123 = v_562_0 z := by
   unfold s_563
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_562_0, r_562_0 z, r_562_1 z] <;> rfl
 #a w_562_0
 theorem h_562_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_562_0 z).shape = [1, 16, 32] := by
   unfold v_562_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_537_0 z) rfl]
     exact h_537_0 z z_
   · decide
 #a h_562_0
 attribute [local irreducible] v_562_0
 attribute [local irreducible] s_563
 theorem r_563_0 (z : Store) : (s_563 z) 1123 = (v_562_0 z) := w_562_0 z
 #a r_563_0
 def v_563_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_562_0 z)
 def s_564 (z : Store) : Store := storeSet (s_563 z) [(1124, fw_view [1, 16, 2, 16] ((s_563 z) 1123))]
 theorem t_563 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_778) (pmPeers pmNode_778) (s_563 z) pmNode_778 none = some (s_564 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_563
 theorem k_563 (z : Store) (tid : Tid) (h : tid ∉ [1124]) : (s_564 z) tid = (s_563 z) tid := by
   unfold s_564
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_563
 theorem w_563_0 (z : Store) : (s_564 z) 1124 = v_563_0 z := by
   unfold s_564
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_563_0, r_563_0 z] <;> rfl
 #a w_563_0
 theorem h_563_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_563_0 z).shape = [1, 16, 2, 16] := by
   unfold v_563_0
   rfl
 #a h_563_0
 attribute [local irreducible] v_563_0
 attribute [local irreducible] s_564
 theorem n_560_564 (z : Store) (tid : Tid) (h : tid ∉ ([1119, 1120, 1123, 1124] : List Tid)) : (s_564 z) tid = (s_560 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_560 z) (k_561 z)) (pF _ _ _ _ _ (k_562 z) (k_563 z)) tid h
 #a n_560_564
 theorem r_564_0 (z : Store) : (s_564 z) 821 = (v_559_0 z) := pR (n_560_564 z) (w_559_0 z)
 #a r_564_0
 theorem r_564_1 (z : Store) : (s_564 z) 1124 = (v_563_0 z) := w_563_0 z
 #a r_564_1
 def v_564_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_559_0 z), (v_563_0 z)]
 theorem g_564 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_543) (s_564 z) pmNode_543 2 1 824 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_543, r_564_0 z, r_564_1 z, h_559_0 z z_, h_563_0 z z_]
 #a g_564
 def s_565 (z : Store) : Store := pL [2, 3] (s_564 z) pmNode_543 2 1
 theorem t_564 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_543) (pmPeers pmNode_543) (s_564 z) pmNode_543 none = some (s_565 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_543) (s_564 z) pmNode_543).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 824 (by decide) (g_564 z z_)]
   rfl
 #a t_564
 theorem k_564 (z : Store) (tid : Tid) (h : tid ∉ [824]) : (s_565 z) tid = (s_564 z) tid := by
   unfold s_565
   dsimp only [pL, pmNode_543, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_564
 theorem w_564_0 (z : Store) : (s_565 z) 824 = v_564_0 z := by
   unfold s_565
   dsimp only [pL, pmNode_543, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_564_0, r_564_0 z, r_564_1 z] <;> rfl
 #a w_564_0
 theorem h_564_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_564_0 z).shape = [1, 8, 4, 16] := by
   unfold v_564_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_559_0 z z_]
 #a h_564_0
 attribute [local irreducible] v_564_0
 attribute [local irreducible] s_565
 theorem r_565_0 (z : Store) : (s_565 z) 824 = (v_564_0 z) := w_564_0 z
 #a r_565_0
 def v_565_0 (z : Store) : Tensor := transposeAxes 1 2 (v_564_0 z)
 def s_566 (z : Store) : Store := storeSet (s_565 z) [(825, transposeAxes 1 2 ((s_565 z) 824))]
 theorem t_565 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_544) (pmPeers pmNode_544) (s_565 z) pmNode_544 none = some (s_566 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_565
 theorem k_565 (z : Store) (tid : Tid) (h : tid ∉ [825]) : (s_566 z) tid = (s_565 z) tid := by
   unfold s_566
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_565
 theorem w_565_0 (z : Store) : (s_566 z) 825 = v_565_0 z := by
   unfold s_566
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_565_0, r_565_0 z] <;> rfl
 #a w_565_0
 theorem h_565_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_565_0 z).shape = [1, 4, 8, 16] := by
   unfold v_565_0
   change listSwapAt _ _ _ = _
   rw [h_564_0 z z_]
   rfl
 #a h_565_0
 attribute [local irreducible] v_565_0
 attribute [local irreducible] s_566
 theorem r_566_0 (z : Store) : (s_566 z) 817 = (v_557_0 z) := pR (k_565 z) (pR (k_564 z) (pR (n_560_564 z) (pR (k_559 z) (pR (k_558 z) (w_557_0 z)))))
 #a r_566_0
 def v_566_0 (z : Store) : Tensor := transposeAxes 2 3 (v_557_0 z)
 def s_567 (z : Store) : Store := storeSet (s_566 z) [(828, transposeAxes 2 3 ((s_566 z) 817))]
 theorem t_566 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_545) (pmPeers pmNode_545) (s_566 z) pmNode_545 none = some (s_567 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_566
 theorem k_566 (z : Store) (tid : Tid) (h : tid ∉ [828]) : (s_567 z) tid = (s_566 z) tid := by
   unfold s_567
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_566
 theorem w_566_0 (z : Store) : (s_567 z) 828 = v_566_0 z := by
   unfold s_567
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_566_0, r_566_0 z] <;> rfl
 #a w_566_0
 theorem h_566_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_566_0 z).shape = [1, 4, 8, 16] := by
   unfold v_566_0
   change listSwapAt _ _ _ = _
   rw [h_557_0 z z_]
   rfl
 #a h_566_0
 attribute [local irreducible] v_566_0
 attribute [local irreducible] s_567
 theorem r_567_0 (z : Store) : (s_567 z) 821 = (v_559_0 z) := pR (k_566 z) (pR (k_565 z) (pR (k_564 z) (r_564_0 z)))
 #a r_567_0
 theorem r_567_1 (z : Store) : (s_567 z) 1124 = (v_563_0 z) := pR (k_566 z) (pR (k_565 z) (pR (k_564 z) (r_564_1 z)))
 #a r_567_1
 def v_567_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_559_0 z), (v_563_0 z)]
 theorem g_567 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_779) (s_567 z) pmNode_779 2 1 1127 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_779, r_567_0 z, r_567_1 z, h_559_0 z z_, h_563_0 z z_]
 #a g_567
 def s_568 (z : Store) : Store := pL [2, 3] (s_567 z) pmNode_779 2 1
 theorem t_567 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_779) (pmPeers pmNode_779) (s_567 z) pmNode_779 none = some (s_568 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_779) (s_567 z) pmNode_779).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1127 (by decide) (g_567 z z_)]
   rfl
 #a t_567
 theorem k_567 (z : Store) (tid : Tid) (h : tid ∉ [1127]) : (s_568 z) tid = (s_567 z) tid := by
   unfold s_568
   dsimp only [pL, pmNode_779, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_567
 theorem w_567_0 (z : Store) : (s_568 z) 1127 = v_567_0 z := by
   unfold s_568
   dsimp only [pL, pmNode_779, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_567_0, r_567_0 z, r_567_1 z] <;> rfl
 #a w_567_0
 theorem h_567_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_567_0 z).shape = [1, 8, 4, 16] := by
   unfold v_567_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_559_0 z z_]
 #a h_567_0
 attribute [local irreducible] v_567_0
 attribute [local irreducible] s_568
 theorem r_568_0 (z : Store) : (s_568 z) 1127 = (v_567_0 z) := w_567_0 z
 #a r_568_0
 def v_568_0 (z : Store) : Tensor := transposeAxes 1 2 (v_567_0 z)
 def s_569 (z : Store) : Store := storeSet (s_568 z) [(1128, transposeAxes 1 2 ((s_568 z) 1127))]
 theorem t_568 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_780) (pmPeers pmNode_780) (s_568 z) pmNode_780 none = some (s_569 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_568
 theorem k_568 (z : Store) (tid : Tid) (h : tid ∉ [1128]) : (s_569 z) tid = (s_568 z) tid := by
   unfold s_569
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_568
 theorem w_568_0 (z : Store) : (s_569 z) 1128 = v_568_0 z := by
   unfold s_569
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_568_0, r_568_0 z] <;> rfl
 #a w_568_0
 theorem h_568_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_568_0 z).shape = [1, 4, 8, 16] := by
   unfold v_568_0
   change listSwapAt _ _ _ = _
   rw [h_567_0 z z_]
   rfl
 #a h_568_0
 attribute [local irreducible] v_568_0
 attribute [local irreducible] s_569
 theorem n_564_568 (z : Store) (tid : Tid) (h : tid ∉ ([824, 825, 828, 1127] : List Tid)) : (s_568 z) tid = (s_564 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_564 z) (k_565 z)) (pF _ _ _ _ _ (k_566 z) (k_567 z)) tid h
 #a n_564_568
 theorem r_569_0 (z : Store) : (s_569 z) 1120 = (v_561_0 z) := pR (k_568 z) (pR (n_564_568 z) (pR (k_563 z) (pR (k_562 z) (w_561_0 z))))
 #a r_569_0
 def v_569_0 (z : Store) : Tensor := transposeAxes 2 3 (v_561_0 z)
 def s_570 (z : Store) : Store := storeSet (s_569 z) [(1131, transposeAxes 2 3 ((s_569 z) 1120))]
 theorem t_569 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_781) (pmPeers pmNode_781) (s_569 z) pmNode_781 none = some (s_570 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_569
 theorem k_569 (z : Store) (tid : Tid) (h : tid ∉ [1131]) : (s_570 z) tid = (s_569 z) tid := by
   unfold s_570
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_569
 theorem w_569_0 (z : Store) : (s_570 z) 1131 = v_569_0 z := by
   unfold s_570
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_569_0, r_569_0 z] <;> rfl
 #a w_569_0
 theorem h_569_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_569_0 z).shape = [1, 4, 8, 16] := by
   unfold v_569_0
   change listSwapAt _ _ _ = _
   rw [h_561_0 z z_]
   rfl
 #a h_569_0
 attribute [local irreducible] v_569_0
 attribute [local irreducible] s_570
 record_prefix_opacity v_560_0 s_561 v_561_0 s_562 v_562_0 s_563 v_563_0 s_564 v_564_0 s_565 v_565_0 s_566 v_566_0 s_567 v_567_0 s_568 v_568_0 s_569 v_569_0 s_570

 end
 end TrainVerify.Denote.RuntimeWorld
