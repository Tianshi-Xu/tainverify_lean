import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0037
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_295_0 (z : Store) : (s_295 z) 205 = (v_273_0 z) := pR (k_294 z) (pR (k_293 z) (pR (k_292 z) (pR (n_288_292 z) (pR (n_280_288 z) (pR (n_276_280 z) (pR (k_275 z) (pR (k_274 z) (w_273_0 z))))))))
 #a r_295_0
 theorem r_295_1 (z : Store) : (s_295 z) 202 = (v_126_0 z) := pR (k_294 z) (pR (k_293 z) (pR (k_292 z) (pR (n_288_292 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (k_127 z) (r_127_0 z)))))))
 #a r_295_1
 def v_295_0 (z : Store) : Tensor := transposeAxes 1 2 (v_273_0 z)
 def s_296 (z : Store) : Store := storeSet (s_295 z) [(204, transposeAxes 1 2 ((s_295 z) 205))]
 theorem t_295 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_148) (pmPeers pmNode_148) (s_295 z) pmNode_148 none = some (s_296 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_295
 theorem k_295 (z : Store) (tid : Tid) (h : tid ∉ [204]) : (s_296 z) tid = (s_295 z) tid := by
   unfold s_296
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_295
 theorem w_295_0 (z : Store) : (s_296 z) 204 = v_295_0 z := by
   unfold s_296
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_295_0, r_295_0 z, r_295_1 z] <;> rfl
 #a w_295_0
 theorem h_295_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_295_0 z).shape = [1, 16, 2, 16] := by
   unfold v_295_0
   change listSwapAt _ _ _ = _
   rw [h_273_0 z z_]
   rfl
 #a h_295_0
 attribute [local irreducible] v_295_0
 attribute [local irreducible] s_296
 theorem r_296_0 (z : Store) : (s_296 z) 208 = (v_291_0 z) := pR (k_295 z) (pR (k_294 z) (r_294_0 z))
 #a r_296_0
 theorem r_296_1 (z : Store) : (s_296 z) 511 = (v_293_0 z) := pR (k_295 z) (pR (k_294 z) (r_294_1 z))
 #a r_296_1
 def v_296_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_291_0 z), (v_293_0 z)]
 def s_297 (z : Store) : Store := storeSet (s_296 z) [(385, allGatherPrimDimN 1 2 1 [((s_296 z) 208), ((s_296 z) 511)])]
 theorem t_296 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_383) (pmPeers pmNode_383) (s_296 z) pmNode_383 none = some (s_297 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_296 z) pmNode_383 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_296
 theorem k_296 (z : Store) (tid : Tid) (h : tid ∉ [385]) : (s_297 z) tid = (s_296 z) tid := by
   unfold s_297
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_296
 theorem w_296_0 (z : Store) : (s_297 z) 385 = v_296_0 z := by
   unfold s_297
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_296_0, r_296_0 z, r_296_1 z] <;> rfl
 #a w_296_0
 theorem h_296_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_296_0 z).shape = [1, 16, 64] := by
   unfold v_296_0
   exact allGatherPrimDimN_shape 1 2 [(v_291_0 z), (v_293_0 z)] [1, 8, 64] (h_291_0 z z_)
 #a h_296_0
 attribute [local irreducible] v_296_0
 attribute [local irreducible] s_297
 theorem n_292_296 (z : Store) (tid : Tid) (h : tid ∉ ([512, 511, 82, 204] : List Tid)) : (s_296 z) tid = (s_292 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_292 z) (k_293 z)) (pF _ _ _ _ _ (k_294 z) (k_295 z)) tid h
 #a n_292_296
 theorem n_288_296 (z : Store) (tid : Tid) (h : tid ∉ ([386, 515, 209, 208, 512, 511, 82, 204] : List Tid)) : (s_296 z) tid = (s_288 z) tid := by
   exact pF _ _ _ _ _ (n_288_292 z) (n_292_296 z) tid h
 #a n_288_296
 theorem r_297_0 (z : Store) : (s_297 z) 508 = (v_275_0 z) := pR (k_296 z) (pR (n_288_296 z) (pR (n_280_288 z) (pR (n_276_280 z) (w_275_0 z))))
 #a r_297_0
 theorem r_297_1 (z : Store) : (s_297 z) 505 = (v_130_0 z) := pR (k_296 z) (pR (n_288_296 z) (pR (n_256_288 z) (pR (n_192_256 z) (pR (n_160_192 z) (pR (n_144_160 z) (pR (n_136_144 z) (pR (n_132_136 z) (pR (k_131 z) (r_131_0 z)))))))))
 #a r_297_1
 def v_297_0 (z : Store) : Tensor := transposeAxes 1 2 (v_275_0 z)
 def s_298 (z : Store) : Store := storeSet (s_297 z) [(507, transposeAxes 1 2 ((s_297 z) 508))]
 theorem t_297 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_384) (pmPeers pmNode_384) (s_297 z) pmNode_384 none = some (s_298 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_297
 theorem k_297 (z : Store) (tid : Tid) (h : tid ∉ [507]) : (s_298 z) tid = (s_297 z) tid := by
   unfold s_298
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_297
 theorem w_297_0 (z : Store) : (s_298 z) 507 = v_297_0 z := by
   unfold s_298
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_297_0, r_297_0 z, r_297_1 z] <;> rfl
 #a w_297_0
 theorem h_297_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_297_0 z).shape = [1, 16, 2, 16] := by
   unfold v_297_0
   change listSwapAt _ _ _ = _
   rw [h_275_0 z z_]
   rfl
 #a h_297_0
 attribute [local irreducible] v_297_0
 attribute [local irreducible] s_298
 theorem r_298_0 (z : Store) : (s_298 z) 204 = (v_295_0 z) := pR (k_297 z) (pR (k_296 z) (w_295_0 z))
 #a r_298_0
 theorem r_298_1 (z : Store) : (s_298 z) 507 = (v_297_0 z) := w_297_0 z
 #a r_298_1
 def v_298_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_295_0 z), (v_297_0 z)]
 theorem g_298 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_149) (s_298 z) pmNode_149 2 1 201 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_149, r_298_0 z, r_298_1 z, h_295_0 z z_, h_297_0 z z_]
 #a g_298
 def s_299 (z : Store) : Store := pL [0, 1] (s_298 z) pmNode_149 2 1
 theorem t_298 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_149) (pmPeers pmNode_149) (s_298 z) pmNode_149 none = some (s_299 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_149) (s_298 z) pmNode_149).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 201 (by decide) (g_298 z z_)]
   rfl
 #a t_298
 theorem k_298 (z : Store) (tid : Tid) (h : tid ∉ [201]) : (s_299 z) tid = (s_298 z) tid := by
   unfold s_299
   dsimp only [pL, pmNode_149, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_298
 theorem w_298_0 (z : Store) : (s_299 z) 201 = v_298_0 z := by
   unfold s_299
   dsimp only [pL, pmNode_149, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_298_0, r_298_0 z, r_298_1 z] <;> rfl
 #a w_298_0
 theorem h_298_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_298_0 z).shape = [1, 8, 4, 16] := by
   unfold v_298_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_295_0 z z_]
 #a h_298_0
 attribute [local irreducible] v_298_0
 attribute [local irreducible] s_299
 theorem r_299_0 (z : Store) : (s_299 z) 201 = (v_298_0 z) := w_298_0 z
 #a r_299_0
 theorem r_299_1 (z : Store) : (s_299 z) 198 = (v_118_0 z) := pR (k_298 z) (pR (k_297 z) (pR (k_296 z) (pR (n_288_296 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (n_120_128 z) (pR (k_119 z) (r_119_0 z))))))))
 #a r_299_1
 def v_299_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_298_0 z)
 def s_300 (z : Store) : Store := storeSet (s_299 z) [(200, fw_view [1, 8, 64] ((s_299 z) 201))]
 theorem t_299 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_150) (pmPeers pmNode_150) (s_299 z) pmNode_150 none = some (s_300 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_299
 theorem k_299 (z : Store) (tid : Tid) (h : tid ∉ [200]) : (s_300 z) tid = (s_299 z) tid := by
   unfold s_300
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_299
 theorem w_299_0 (z : Store) : (s_300 z) 200 = v_299_0 z := by
   unfold s_300
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_299_0, r_299_0 z, r_299_1 z] <;> rfl
 #a w_299_0
 theorem h_299_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_299_0 z).shape = [1, 8, 64] := by
   unfold v_299_0
   rfl
 #a h_299_0
 attribute [local irreducible] v_299_0
 attribute [local irreducible] s_300
 theorem r_300_0 (z : Store) : (s_300 z) 204 = (v_295_0 z) := pR (k_299 z) (pR (k_298 z) (r_298_0 z))
 #a r_300_0
 theorem r_300_1 (z : Store) : (s_300 z) 507 = (v_297_0 z) := pR (k_299 z) (pR (k_298 z) (r_298_1 z))
 #a r_300_1
 def v_300_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_295_0 z), (v_297_0 z)]
 theorem g_300 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_385) (s_300 z) pmNode_385 2 1 504 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_385, r_300_0 z, r_300_1 z, h_295_0 z z_, h_297_0 z z_]
 #a g_300
 def s_301 (z : Store) : Store := pL [0, 1] (s_300 z) pmNode_385 2 1
 theorem t_300 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_385) (pmPeers pmNode_385) (s_300 z) pmNode_385 none = some (s_301 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_385) (s_300 z) pmNode_385).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 504 (by decide) (g_300 z z_)]
   rfl
 #a t_300
 theorem k_300 (z : Store) (tid : Tid) (h : tid ∉ [504]) : (s_301 z) tid = (s_300 z) tid := by
   unfold s_301
   dsimp only [pL, pmNode_385, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_300
 theorem w_300_0 (z : Store) : (s_301 z) 504 = v_300_0 z := by
   unfold s_301
   dsimp only [pL, pmNode_385, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_300_0, r_300_0 z, r_300_1 z] <;> rfl
 #a w_300_0
 theorem h_300_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_300_0 z).shape = [1, 8, 4, 16] := by
   unfold v_300_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_295_0 z z_]
 #a h_300_0
 attribute [local irreducible] v_300_0
 attribute [local irreducible] s_301
 theorem n_296_300 (z : Store) (tid : Tid) (h : tid ∉ ([385, 507, 201, 200] : List Tid)) : (s_300 z) tid = (s_296 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_296 z) (k_297 z)) (pF _ _ _ _ _ (k_298 z) (k_299 z)) tid h
 #a n_296_300
 theorem r_301_0 (z : Store) : (s_301 z) 504 = (v_300_0 z) := w_300_0 z
 #a r_301_0
 theorem r_301_1 (z : Store) : (s_301 z) 501 = (v_124_0 z) := pR (k_300 z) (pR (n_296_300 z) (pR (n_288_296 z) (pR (n_256_288 z) (pR (n_128_256 z) (pR (k_127 z) (pR (k_126 z) (pR (k_125 z) (r_125_0 z))))))))
 #a r_301_1
 def v_301_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_300_0 z)
 def s_302 (z : Store) : Store := storeSet (s_301 z) [(503, fw_view [1, 8, 64] ((s_301 z) 504))]
 theorem t_301 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_386) (pmPeers pmNode_386) (s_301 z) pmNode_386 none = some (s_302 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_301
 theorem k_301 (z : Store) (tid : Tid) (h : tid ∉ [503]) : (s_302 z) tid = (s_301 z) tid := by
   unfold s_302
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_301
 theorem w_301_0 (z : Store) : (s_302 z) 503 = v_301_0 z := by
   unfold s_302
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_301_0, r_301_0 z, r_301_1 z] <;> rfl
 #a w_301_0
 theorem h_301_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_301_0 z).shape = [1, 8, 64] := by
   unfold v_301_0
   rfl
 #a h_301_0
 attribute [local irreducible] v_301_0
 attribute [local irreducible] s_302
 theorem r_302_0 (z : Store) : (s_302 z) 200 = (v_299_0 z) := pR (k_301 z) (pR (k_300 z) (w_299_0 z))
 #a r_302_0
 theorem r_302_1 (z : Store) : (s_302 z) 503 = (v_301_0 z) := w_301_0 z
 #a r_302_1
 def v_302_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_299_0 z), (v_301_0 z)]
 theorem g_302 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_151) (s_302 z) pmNode_151 1 2 190 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_151, r_302_0 z, r_302_1 z, h_299_0 z z_, h_301_0 z z_]
 #a g_302
 def s_303 (z : Store) : Store := pL [0, 1] (s_302 z) pmNode_151 1 2
 theorem t_302 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_151) (pmPeers pmNode_151) (s_302 z) pmNode_151 none = some (s_303 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_151) (s_302 z) pmNode_151).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 190 (by decide) (g_302 z z_)]
   rfl
 #a t_302
 theorem k_302 (z : Store) (tid : Tid) (h : tid ∉ [190]) : (s_303 z) tid = (s_302 z) tid := by
   unfold s_303
   dsimp only [pL, pmNode_151, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_302
 theorem w_302_0 (z : Store) : (s_303 z) 190 = v_302_0 z := by
   unfold s_303
   dsimp only [pL, pmNode_151, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_302_0, r_302_0 z, r_302_1 z] <;> rfl
 #a w_302_0
 theorem h_302_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_302_0 z).shape = [1, 16, 32] := by
   unfold v_302_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_299_0 z z_]
 #a h_302_0
 attribute [local irreducible] v_302_0
 attribute [local irreducible] s_303
 record_prefix_opacity v_295_0 s_296 v_296_0 s_297 v_297_0 s_298 v_298_0 s_299 v_299_0 s_300 v_300_0 s_301 v_301_0 s_302 v_302_0 s_303

 end
 end TrainVerify.Denote.RuntimeWorld
