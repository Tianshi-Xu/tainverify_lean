import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0102
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_811_0 (z : Store) : (s_811 z) 728 = (v_805_0 z) := pR (k_810 z) (pR (k_809 z) (pR (k_808 z) (r_808_0 z)))
 #a r_811_0
 theorem r_811_1 (z : Store) : (s_811 z) 1031 = (v_807_0 z) := pR (k_810 z) (pR (k_809 z) (pR (k_808 z) (r_808_1 z)))
 #a r_811_1
 def v_811_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 2 [(v_805_0 z), (v_807_0 z)]
 theorem g_811 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_901) (s_811 z) pmNode_901 3 2 1028 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_901, r_811_0 z, r_811_1 z, h_805_0 z z_, h_807_0 z z_]
 #a g_811
 def s_812 (z : Store) : Store := pL [2, 3] (s_811 z) pmNode_901 3 2
 theorem t_811 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_901) (pmPeers pmNode_901) (s_811 z) pmNode_901 none = some (s_812 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_901) (s_811 z) pmNode_901).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 2 1028 (by decide) (g_811 z z_)]
   rfl
 #a t_811
 theorem k_811 (z : Store) (tid : Tid) (h : tid ∉ [1028]) : (s_812 z) tid = (s_811 z) tid := by
   unfold s_812
   dsimp only [pL, pmNode_901, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_811
 theorem w_811_0 (z : Store) : (s_812 z) 1028 = v_811_0 z := by
   unfold s_812
   dsimp only [pL, pmNode_901, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_811_0, r_811_0 z, r_811_1 z] <;> rfl
 #a w_811_0
 theorem h_811_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_811_0 z).shape = [1, 16, 2, 16] := by
   unfold v_811_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_805_0 z z_]
 #a h_811_0
 attribute [local irreducible] v_811_0
 attribute [local irreducible] s_812
 theorem n_808_812 (z : Store) (tid : Tid) (h : tid ∉ ([725, 713, 722, 1028] : List Tid)) : (s_812 z) tid = (s_808 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_808 z) (k_809 z)) (pF _ _ _ _ _ (k_810 z) (k_811 z)) tid h
 #a n_808_812
 theorem r_812_0 (z : Store) : (s_812 z) 1028 = (v_811_0 z) := w_811_0 z
 #a r_812_0
 theorem r_812_1 (z : Store) : (s_812 z) 1015 = (v_450_0 z) := pR (n_808_812 z) (pR (n_800_808 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (n_460_464 z) (pR (k_459 z) (r_459_0 z))))))))
 #a r_812_1
 def v_812_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_811_0 z)
 def s_813 (z : Store) : Store := storeSet (s_812 z) [(1017, fw_view [1, 16, 32] ((s_812 z) 1028))]
 theorem t_812 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_902) (pmPeers pmNode_902) (s_812 z) pmNode_902 none = some (s_813 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_812
 theorem k_812 (z : Store) (tid : Tid) (h : tid ∉ [1017]) : (s_813 z) tid = (s_812 z) tid := by
   unfold s_813
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_812
 theorem w_812_0 (z : Store) : (s_813 z) 1017 = v_812_0 z := by
   unfold s_813
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_812_0, r_812_0 z, r_812_1 z] <;> rfl
 #a w_812_0
 theorem h_812_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_812_0 z).shape = [1, 16, 32] := by
   unfold v_812_0
   rfl
 #a h_812_0
 attribute [local irreducible] v_812_0
 attribute [local irreducible] s_813
 theorem r_813_0 (z : Store) : (s_813 z) 1026 = (v_800_0 z) := pR (k_812 z) (pR (n_808_812 z) (pR (n_804_808 z) (pR (k_803 z) (pR (k_802 z) (pR (k_801 z) (w_800_0 z))))))
 #a r_813_0
 theorem r_813_1 (z : Store) : (s_813 z) 1023 = (v_457_0 z) := pR (k_812 z) (pR (n_808_812 z) (pR (n_800_808 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (n_460_464 z) (pR (k_459 z) (pR (k_458 z) (r_458_0 z))))))))))
 #a r_813_1
 def v_813_0 (z : Store) : Tensor := transposeAxes 1 2 (v_800_0 z)
 def s_814 (z : Store) : Store := storeSet (s_813 z) [(1025, transposeAxes 1 2 ((s_813 z) 1026))]
 theorem t_813 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_903) (pmPeers pmNode_903) (s_813 z) pmNode_903 none = some (s_814 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_813
 theorem k_813 (z : Store) (tid : Tid) (h : tid ∉ [1025]) : (s_814 z) tid = (s_813 z) tid := by
   unfold s_814
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_813
 theorem w_813_0 (z : Store) : (s_814 z) 1025 = v_813_0 z := by
   unfold s_814
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_813_0, r_813_0 z, r_813_1 z] <;> rfl
 #a w_813_0
 theorem h_813_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_813_0 z).shape = [1, 16, 4, 8] := by
   unfold v_813_0
   change listSwapAt _ _ _ = _
   rw [h_800_0 z z_]
   rfl
 #a h_813_0
 attribute [local irreducible] v_813_0
 attribute [local irreducible] s_814
 theorem r_814_0 (z : Store) : (s_814 z) 722 = (v_810_0 z) := pR (k_813 z) (pR (k_812 z) (pR (k_811 z) (w_810_0 z)))
 #a r_814_0
 theorem r_814_1 (z : Store) : (s_814 z) 1025 = (v_813_0 z) := w_813_0 z
 #a r_814_1
 def v_814_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 3 1 [(v_810_0 z), (v_813_0 z)]
 theorem g_814 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_668) (s_814 z) pmNode_668 3 1 719 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_668, r_814_0 z, r_814_1 z, h_810_0 z z_, h_813_0 z z_]
 #a g_814
 def s_815 (z : Store) : Store := pL [2, 3] (s_814 z) pmNode_668 3 1
 theorem t_814 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_668) (pmPeers pmNode_668) (s_814 z) pmNode_668 none = some (s_815 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_668) (s_814 z) pmNode_668).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 719 (by decide) (g_814 z z_)]
   rfl
 #a t_814
 theorem k_814 (z : Store) (tid : Tid) (h : tid ∉ [719]) : (s_815 z) tid = (s_814 z) tid := by
   unfold s_815
   dsimp only [pL, pmNode_668, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_814
 theorem w_814_0 (z : Store) : (s_815 z) 719 = v_814_0 z := by
   unfold s_815
   dsimp only [pL, pmNode_668, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_814_0, r_814_0 z, r_814_1 z] <;> rfl
 #a w_814_0
 theorem h_814_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_814_0 z).shape = [1, 8, 4, 16] := by
   unfold v_814_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_810_0 z z_]
 #a h_814_0
 attribute [local irreducible] v_814_0
 attribute [local irreducible] s_815
 theorem r_815_0 (z : Store) : (s_815 z) 719 = (v_814_0 z) := w_814_0 z
 #a r_815_0
 theorem r_815_1 (z : Store) : (s_815 z) 709 = (v_439_0 z) := pR (k_814 z) (pR (k_813 z) (pR (k_812 z) (pR (n_808_812 z) (pR (n_800_808 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (k_447 z) (r_447_0 z)))))))))
 #a r_815_1
 def v_815_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_814_0 z)
 def s_816 (z : Store) : Store := storeSet (s_815 z) [(711, fw_view [1, 8, 64] ((s_815 z) 719))]
 theorem t_815 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_669) (pmPeers pmNode_669) (s_815 z) pmNode_669 none = some (s_816 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_815
 theorem k_815 (z : Store) (tid : Tid) (h : tid ∉ [711]) : (s_816 z) tid = (s_815 z) tid := by
   unfold s_816
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_815
 theorem w_815_0 (z : Store) : (s_816 z) 711 = v_815_0 z := by
   unfold s_816
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_815_0, r_815_0 z, r_815_1 z] <;> rfl
 #a w_815_0
 theorem h_815_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_815_0 z).shape = [1, 8, 64] := by
   unfold v_815_0
   rfl
 #a h_815_0
 attribute [local irreducible] v_815_0
 attribute [local irreducible] s_816
 theorem n_812_816 (z : Store) (tid : Tid) (h : tid ∉ ([1017, 1025, 719, 711] : List Tid)) : (s_816 z) tid = (s_812 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_812 z) (k_813 z)) (pF _ _ _ _ _ (k_814 z) (k_815 z)) tid h
 #a n_812_816
 theorem n_808_816 (z : Store) (tid : Tid) (h : tid ∉ ([725, 713, 722, 1028, 1017, 1025, 719, 711] : List Tid)) : (s_816 z) tid = (s_808 z) tid := by
   exact pF _ _ _ _ _ (n_808_812 z) (n_812_816 z) tid h
 #a n_808_816
 theorem n_800_816 (z : Store) (tid : Tid) (h : tid ∉ ([1026, 1032, 1036, 1035, 716, 728, 1020, 1031, 725, 713, 722, 1028, 1017, 1025, 719, 711] : List Tid)) : (s_816 z) tid = (s_800 z) tid := by
   exact pF _ _ _ _ _ (n_800_808 z) (n_808_816 z) tid h
 #a n_800_816
 theorem r_816_0 (z : Store) : (s_816 z) 716 = (v_804_0 z) := pR (n_808_816 z) (pR (k_807 z) (pR (k_806 z) (pR (k_805 z) (w_804_0 z))))
 #a r_816_0
 theorem r_816_1 (z : Store) : (s_816 z) 693 = (v_445_0 z) := pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (k_447 z) (pR (k_446 z) (r_446_0 z))))))
 #a r_816_1
 theorem r_816_2 (z : Store) : (s_816 z) 636 = (z 636) := pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (k_447 z) (pR (k_446 z) (r_446_1 z))))))
 #a r_816_2
 def v_816_0 (z : Store) : Tensor := (bw_linear (v_804_0 z) (v_445_0 z) (z 636)).1
 def v_816_1 (z : Store) : Tensor := (bw_linear (v_804_0 z) (v_445_0 z) (z 636)).2
 def s_817 (z : Store) : Store := storeSet (s_816 z) [(717, (bw_linear ((s_816 z) 716) ((s_816 z) 693) ((s_816 z) 636)).1), (637, (bw_linear ((s_816 z) 716) ((s_816 z) 693) ((s_816 z) 636)).2)]
 theorem t_816 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_670) (pmPeers pmNode_670) (s_816 z) pmNode_670 none = some (s_817 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_816
 theorem k_816 (z : Store) (tid : Tid) (h : tid ∉ [717, 637]) : (s_817 z) tid = (s_816 z) tid := by
   unfold s_817
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_816
 theorem w_816_0 (z : Store) : (s_817 z) 717 = v_816_0 z := by
   unfold s_817
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_816_0, r_816_0 z, r_816_1 z, r_816_2 z] <;> rfl
 #a w_816_0
 theorem h_816_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_816_0 z).shape = [1, 16, 64] := by
   unfold v_816_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_804_0 z) (v_445_0 z) (z 636) (h_804_0 z z_) (h_445_0 z z_) (i_60 z z_)
 #a h_816_0
 attribute [local irreducible] v_816_0
 theorem w_816_1 (z : Store) : (s_817 z) 637 = v_816_1 z := by
   unfold s_817
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_816_1, r_816_0 z, r_816_1 z, r_816_2 z] <;> rfl
 #a w_816_1
 theorem h_816_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_816_1 z).shape = [32, 64] := by
   unfold v_816_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_804_0 z) (v_445_0 z) (z 636) (h_804_0 z z_) (h_445_0 z z_) (i_60 z z_)
 #a h_816_1
 attribute [local irreducible] v_816_1
 attribute [local irreducible] s_817
 theorem r_817_0 (z : Store) : (s_817 z) 722 = (v_810_0 z) := pR (k_816 z) (pR (k_815 z) (pR (k_814 z) (r_814_0 z)))
 #a r_817_0
 theorem r_817_1 (z : Store) : (s_817 z) 1025 = (v_813_0 z) := pR (k_816 z) (pR (k_815 z) (pR (k_814 z) (r_814_1 z)))
 #a r_817_1
 def v_817_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_810_0 z), (v_813_0 z)]
 theorem g_817 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_904) (s_817 z) pmNode_904 3 1 1022 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 4, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_904, r_817_0 z, r_817_1 z, h_810_0 z z_, h_813_0 z z_]
 #a g_817
 def s_818 (z : Store) : Store := pL [2, 3] (s_817 z) pmNode_904 3 1
 theorem t_817 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_904) (pmPeers pmNode_904) (s_817 z) pmNode_904 none = some (s_818 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_904) (s_817 z) pmNode_904).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 1022 (by decide) (g_817 z z_)]
   rfl
 #a t_817
 theorem k_817 (z : Store) (tid : Tid) (h : tid ∉ [1022]) : (s_818 z) tid = (s_817 z) tid := by
   unfold s_818
   dsimp only [pL, pmNode_904, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_817
 theorem w_817_0 (z : Store) : (s_818 z) 1022 = v_817_0 z := by
   unfold s_818
   dsimp only [pL, pmNode_904, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_817_0, r_817_0 z, r_817_1 z] <;> rfl
 #a w_817_0
 theorem h_817_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_817_0 z).shape = [1, 8, 4, 16] := by
   unfold v_817_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_810_0 z z_]
 #a h_817_0
 attribute [local irreducible] v_817_0
 attribute [local irreducible] s_818
 theorem r_818_0 (z : Store) : (s_818 z) 1022 = (v_817_0 z) := w_817_0 z
 #a r_818_0
 theorem r_818_1 (z : Store) : (s_818 z) 1012 = (v_448_0 z) := pR (k_817 z) (pR (k_816 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (n_456_464 z) (pR (k_455 z) (pR (k_454 z) (pR (k_453 z) (r_453_0 z)))))))))))
 #a r_818_1
 def v_818_0 (z : Store) : Tensor := fw_view [1, 8, 64] (v_817_0 z)
 def s_819 (z : Store) : Store := storeSet (s_818 z) [(1014, fw_view [1, 8, 64] ((s_818 z) 1022))]
 theorem t_818 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_905) (pmPeers pmNode_905) (s_818 z) pmNode_905 none = some (s_819 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_818
 theorem k_818 (z : Store) (tid : Tid) (h : tid ∉ [1014]) : (s_819 z) tid = (s_818 z) tid := by
   unfold s_819
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_818
 theorem w_818_0 (z : Store) : (s_819 z) 1014 = v_818_0 z := by
   unfold s_819
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_818_0, r_818_0 z, r_818_1 z] <;> rfl
 #a w_818_0
 theorem h_818_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_818_0 z).shape = [1, 8, 64] := by
   unfold v_818_0
   rfl
 #a h_818_0
 attribute [local irreducible] v_818_0
 attribute [local irreducible] s_819
 record_prefix_opacity v_811_0 s_812 v_812_0 s_813 v_813_0 s_814 v_814_0 s_815 v_815_0 s_816 v_816_0 v_816_1 s_817 v_817_0 s_818 v_818_0 s_819

 end
 end TrainVerify.Denote.RuntimeWorld
