import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0026
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_209_0 (z : Store) : (s_209 z) 280 = (v_208_0 z) := w_208_0 z
 #a r_209_0
 def v_209_0 (z : Store) : Tensor := fw_sum (v_208_0 z)
 def s_210 (z : Store) : Store := storeSet (s_209 z) [(281, fw_sum ((s_209 z) 280))]
 theorem t_209 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_105) (pmPeers pmNode_105) (s_209 z) pmNode_105 none = some (s_210 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_209
 theorem k_209 (z : Store) (tid : Tid) (h : tid ∉ [281]) : (s_210 z) tid = (s_209 z) tid := by
   unfold s_210
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_209
 theorem w_209_0 (z : Store) : (s_210 z) 281 = v_209_0 z := by
   unfold s_210
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_209_0, r_209_0 z] <;> rfl
 #a w_209_0
 theorem h_209_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_209_0 z).shape = [1] := by
   unfold v_209_0
   rfl
 #a h_209_0
 attribute [local irreducible] v_209_0
 attribute [local irreducible] s_210
 theorem r_210_0 (z : Store) : (s_210 z) 277 = (v_205_0 z) := pR (k_209 z) (pR (k_208 z) (r_208_0 z))
 #a r_210_0
 theorem r_210_1 (z : Store) : (s_210 z) 580 = (v_207_0 z) := pR (k_209 z) (pR (k_208 z) (r_208_1 z))
 #a r_210_1
 def v_210_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_205_0 z), (v_207_0 z)]
 theorem g_210 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_340) (s_210 z) pmNode_340 2 1 583 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 128], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_340, r_210_0 z, r_210_1 z, h_205_0 z z_, h_207_0 z z_]
 #a g_210
 def s_211 (z : Store) : Store := pL [0, 1] (s_210 z) pmNode_340 2 1
 theorem t_210 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_340) (pmPeers pmNode_340) (s_210 z) pmNode_340 none = some (s_211 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_340) (s_210 z) pmNode_340).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 583 (by decide) (g_210 z z_)]
   rfl
 #a t_210
 theorem k_210 (z : Store) (tid : Tid) (h : tid ∉ [583]) : (s_211 z) tid = (s_210 z) tid := by
   unfold s_211
   dsimp only [pL, pmNode_340, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_210
 theorem w_210_0 (z : Store) : (s_211 z) 583 = v_210_0 z := by
   unfold s_211
   dsimp only [pL, pmNode_340, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_210_0, r_210_0 z, r_210_1 z] <;> rfl
 #a w_210_0
 theorem h_210_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_210_0 z).shape = [1, 8, 256] := by
   unfold v_210_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_205_0 z z_]
 #a h_210_0
 attribute [local irreducible] v_210_0
 attribute [local irreducible] s_211
 theorem r_211_0 (z : Store) : (s_211 z) 583 = (v_210_0 z) := w_210_0 z
 #a r_211_0
 def v_211_0 (z : Store) : Tensor := fw_sum (v_210_0 z)
 def s_212 (z : Store) : Store := storeSet (s_211 z) [(584, fw_sum ((s_211 z) 583))]
 theorem t_211 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_341) (pmPeers pmNode_341) (s_211 z) pmNode_341 none = some (s_212 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_211
 theorem k_211 (z : Store) (tid : Tid) (h : tid ∉ [584]) : (s_212 z) tid = (s_211 z) tid := by
   unfold s_212
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_211
 theorem w_211_0 (z : Store) : (s_212 z) 584 = v_211_0 z := by
   unfold s_212
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_211_0, r_211_0 z] <;> rfl
 #a w_211_0
 theorem h_211_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_211_0 z).shape = [1] := by
   unfold v_211_0
   rfl
 #a h_211_0
 attribute [local irreducible] v_211_0
 attribute [local irreducible] s_212
 theorem r_212_0 (z : Store) : (s_212 z) 281 = (v_209_0 z) := pR (k_211 z) (pR (k_210 z) (w_209_0 z))
 #a r_212_0
 theorem r_212_1 (z : Store) : (s_212 z) 584 = (v_211_0 z) := w_211_0 z
 #a r_212_1
 def v_212_0 (z : Store) : Tensor := allReducePrim 2 0 [(v_209_0 z), (v_211_0 z)]
 def s_213 (z : Store) : Store := storeSet (s_212 z) [(77, allReducePrim 2 0 [((s_212 z) 281), ((s_212 z) 584)])]
 theorem t_212 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_106) (pmPeers pmNode_106) (s_212 z) pmNode_106 none = some (s_213 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_212 z) pmNode_106 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_212
 theorem k_212 (z : Store) (tid : Tid) (h : tid ∉ [77]) : (s_213 z) tid = (s_212 z) tid := by
   unfold s_213
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_212
 theorem w_212_0 (z : Store) : (s_213 z) 77 = v_212_0 z := by
   unfold s_213
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_212_0, r_212_0 z, r_212_1 z] <;> rfl
 #a w_212_0
 theorem h_212_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_212_0 z).shape = [1] := by
   unfold v_212_0
   rw [allReducePrim_shape _ _ _ (v_209_0 z) rfl]
   exact h_209_0 z z_
 #a h_212_0
 attribute [local irreducible] v_212_0
 attribute [local irreducible] s_213
 theorem n_208_212 (z : Store) (tid : Tid) (h : tid ∉ ([280, 281, 583, 584] : List Tid)) : (s_212 z) tid = (s_208 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_208 z) (k_209 z)) (pF _ _ _ _ _ (k_210 z) (k_211 z)) tid h
 #a n_208_212
 theorem n_204_208 (z : Store) (tid : Tid) (h : tid ∉ ([80, 277, 383, 580] : List Tid)) : (s_208 z) tid = (s_204 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_204 z) (k_205 z)) (pF _ _ _ _ _ (k_206 z) (k_207 z)) tid h
 #a n_204_208
 theorem n_200_208 (z : Store) (tid : Tid) (h : tid ∉ ([572, 574, 575, 578, 80, 277, 383, 580] : List Tid)) : (s_208 z) tid = (s_200 z) tid := by
   exact pF _ _ _ _ _ (n_200_204 z) (n_204_208 z) tid h
 #a n_200_208
 theorem n_192_208 (z : Store) (tid : Tid) (h : tid ∉ ([265, 266, 269, 271, 272, 275, 568, 569, 572, 574, 575, 578, 80, 277, 383, 580] : List Tid)) : (s_208 z) tid = (s_192 z) tid := by
   exact pF _ _ _ _ _ (n_192_200 z) (n_200_208 z) tid h
 #a n_192_208
 theorem r_213_0 (z : Store) : (s_213 z) 81 = unitSeed := pR (k_212 z) (pR (n_208_212 z) (pR (n_192_208 z) (pR (n_128_192 z) (pR (n_0_128 z) (pmInitialWithSeeds_seed_0 z)))))
 #a r_213_0
 theorem r_213_1 (z : Store) : (s_213 z) 280 = (v_208_0 z) := pR (k_212 z) (pR (k_211 z) (pR (k_210 z) (pR (k_209 z) (r_209_0 z))))
 #a r_213_1
 def v_213_0 (z : Store) : Tensor := bw_sum unitSeed (v_208_0 z)
 def s_214 (z : Store) : Store := storeSet (s_213 z) [(282, bw_sum ((s_213 z) 81) ((s_213 z) 280))]
 theorem t_213 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_107) (pmPeers pmNode_107) (s_213 z) pmNode_107 none = some (s_214 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_213
 theorem k_213 (z : Store) (tid : Tid) (h : tid ∉ [282]) : (s_214 z) tid = (s_213 z) tid := by
   unfold s_214
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_213
 theorem w_213_0 (z : Store) : (s_214 z) 282 = v_213_0 z := by
   unfold s_214
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_213_0, r_213_0 z, r_213_1 z] <;> rfl
 #a w_213_0
 theorem h_213_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_213_0 z).shape = [1, 8, 256] := by
   unfold v_213_0
   exact h_208_0 z z_
 #a h_213_0
 attribute [local irreducible] v_213_0
 attribute [local irreducible] s_214
 theorem r_214_0 (z : Store) : (s_214 z) 281 = (v_209_0 z) := pR (k_213 z) (pR (k_212 z) (r_212_0 z))
 #a r_214_0
 theorem r_214_1 (z : Store) : (s_214 z) 584 = (v_211_0 z) := pR (k_213 z) (pR (k_212 z) (r_212_1 z))
 #a r_214_1
 def v_214_0 (z : Store) : Tensor := allReducePrim 2 1 [(v_209_0 z), (v_211_0 z)]
 def s_215 (z : Store) : Store := storeSet (s_214 z) [(380, allReducePrim 2 1 [((s_214 z) 281), ((s_214 z) 584)])]
 theorem t_214 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_342) (pmPeers pmNode_342) (s_214 z) pmNode_342 none = some (s_215 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_214 z) pmNode_342 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_214
 theorem k_214 (z : Store) (tid : Tid) (h : tid ∉ [380]) : (s_215 z) tid = (s_214 z) tid := by
   unfold s_215
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_214
 theorem w_214_0 (z : Store) : (s_215 z) 380 = v_214_0 z := by
   unfold s_215
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_214_0, r_214_0 z, r_214_1 z] <;> rfl
 #a w_214_0
 theorem h_214_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_214_0 z).shape = [1] := by
   unfold v_214_0
   rw [allReducePrim_shape _ _ _ (v_209_0 z) rfl]
   exact h_209_0 z z_
 #a h_214_0
 attribute [local irreducible] v_214_0
 attribute [local irreducible] s_215
 theorem r_215_0 (z : Store) : (s_215 z) 384 = unitSeed := pR (k_214 z) (pR (k_213 z) (pR (k_212 z) (pR (n_208_212 z) (pR (n_192_208 z) (pR (n_128_192 z) (pR (n_0_128 z) (pmInitialWithSeeds_seed_1 z)))))))
 #a r_215_0
 theorem r_215_1 (z : Store) : (s_215 z) 583 = (v_210_0 z) := pR (k_214 z) (pR (k_213 z) (pR (k_212 z) (pR (k_211 z) (r_211_0 z))))
 #a r_215_1
 def v_215_0 (z : Store) : Tensor := bw_sum unitSeed (v_210_0 z)
 def s_216 (z : Store) : Store := storeSet (s_215 z) [(585, bw_sum ((s_215 z) 384) ((s_215 z) 583))]
 theorem t_215 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_343) (pmPeers pmNode_343) (s_215 z) pmNode_343 none = some (s_216 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_215
 theorem k_215 (z : Store) (tid : Tid) (h : tid ∉ [585]) : (s_216 z) tid = (s_215 z) tid := by
   unfold s_216
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_215
 theorem w_215_0 (z : Store) : (s_216 z) 585 = v_215_0 z := by
   unfold s_216
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_215_0, r_215_0 z, r_215_1 z] <;> rfl
 #a w_215_0
 theorem h_215_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_215_0 z).shape = [1, 8, 256] := by
   unfold v_215_0
   exact h_210_0 z z_
 #a h_215_0
 attribute [local irreducible] v_215_0
 attribute [local irreducible] s_216
 theorem r_216_0 (z : Store) : (s_216 z) 282 = (v_213_0 z) := pR (k_215 z) (pR (k_214 z) (w_213_0 z))
 #a r_216_0
 theorem r_216_1 (z : Store) : (s_216 z) 585 = (v_215_0 z) := w_215_0 z
 #a r_216_1
 def v_216_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_213_0 z), (v_215_0 z)]
 theorem g_216 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_108) (s_216 z) pmNode_108 1 2 278 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 256], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_108, r_216_0 z, r_216_1 z, h_213_0 z z_, h_215_0 z z_]
 #a g_216
 def s_217 (z : Store) : Store := pL [0, 1] (s_216 z) pmNode_108 1 2
 theorem t_216 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_108) (pmPeers pmNode_108) (s_216 z) pmNode_108 none = some (s_217 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_108) (s_216 z) pmNode_108).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 278 (by decide) (g_216 z z_)]
   rfl
 #a t_216
 theorem k_216 (z : Store) (tid : Tid) (h : tid ∉ [278]) : (s_217 z) tid = (s_216 z) tid := by
   unfold s_217
   dsimp only [pL, pmNode_108, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_216
 theorem w_216_0 (z : Store) : (s_217 z) 278 = v_216_0 z := by
   unfold s_217
   dsimp only [pL, pmNode_108, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_216_0, r_216_0 z, r_216_1 z] <;> rfl
 #a w_216_0
 theorem h_216_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_216_0 z).shape = [1, 16, 128] := by
   unfold v_216_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_213_0 z z_]
 #a h_216_0
 attribute [local irreducible] v_216_0
 attribute [local irreducible] s_217
 theorem n_212_216 (z : Store) (tid : Tid) (h : tid ∉ ([77, 282, 380, 585] : List Tid)) : (s_216 z) tid = (s_212 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_212 z) (k_213 z)) (pF _ _ _ _ _ (k_214 z) (k_215 z)) tid h
 #a n_212_216
 theorem n_208_216 (z : Store) (tid : Tid) (h : tid ∉ ([280, 281, 583, 584, 77, 282, 380, 585] : List Tid)) : (s_216 z) tid = (s_208 z) tid := by
   exact pF _ _ _ _ _ (n_208_212 z) (n_212_216 z) tid h
 #a n_208_216
 record_prefix_opacity v_209_0 s_210 v_210_0 s_211 v_211_0 s_212 v_212_0 s_213 v_213_0 s_214 v_214_0 s_215 v_215_0 s_216 v_216_0 s_217

 end
 end TrainVerify.Denote.RuntimeWorld
