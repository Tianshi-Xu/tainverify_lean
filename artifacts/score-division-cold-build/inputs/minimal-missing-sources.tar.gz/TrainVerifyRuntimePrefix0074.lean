import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0073
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_588_0 (z : Store) : (s_588 z) 842 = (v_581_0 z) := pR (k_587 z) (pR (k_586 z) (r_586_0 z))
 #a r_588_0
 theorem r_588_1 (z : Store) : (s_588 z) 1145 = (v_585_0 z) := pR (k_587 z) (pR (k_586 z) (r_586_1 z))
 #a r_588_1
 def v_588_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_581_0 z), (v_585_0 z)]
 theorem g_588 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_790) (s_588 z) pmNode_790 2 1 1148 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 8, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_790, r_588_0 z, r_588_1 z, h_581_0 z z_, h_585_0 z z_]
 #a g_588
 def s_589 (z : Store) : Store := pL [2, 3] (s_588 z) pmNode_790 2 1
 theorem t_588 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_790) (pmPeers pmNode_790) (s_588 z) pmNode_790 none = some (s_589 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_790) (s_588 z) pmNode_790).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1148 (by decide) (g_588 z z_)]
   rfl
 #a t_588
 theorem k_588 (z : Store) (tid : Tid) (h : tid ∉ [1148]) : (s_589 z) tid = (s_588 z) tid := by
   unfold s_589
   dsimp only [pL, pmNode_790, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_588
 theorem w_588_0 (z : Store) : (s_589 z) 1148 = v_588_0 z := by
   unfold s_589
   dsimp only [pL, pmNode_790, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_588_0, r_588_0 z, r_588_1 z] <;> rfl
 #a w_588_0
 theorem h_588_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_588_0 z).shape = [1, 2, 16, 16] := by
   unfold v_588_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_581_0 z z_]
 #a h_588_0
 attribute [local irreducible] v_588_0
 attribute [local irreducible] s_589
 theorem r_589_0 (z : Store) : (s_589 z) 1148 = (v_588_0 z) := w_588_0 z
 #a r_589_0
 def v_589_0 (z : Store) : Tensor := transposeAxes 1 2 (v_588_0 z)
 def s_590 (z : Store) : Store := storeSet (s_589 z) [(1149, transposeAxes 1 2 ((s_589 z) 1148))]
 theorem t_589 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_791) (pmPeers pmNode_791) (s_589 z) pmNode_791 none = some (s_590 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_589
 theorem k_589 (z : Store) (tid : Tid) (h : tid ∉ [1149]) : (s_590 z) tid = (s_589 z) tid := by
   unfold s_590
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_589
 theorem w_589_0 (z : Store) : (s_590 z) 1149 = v_589_0 z := by
   unfold s_590
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_589_0, r_589_0 z] <;> rfl
 #a w_589_0
 theorem h_589_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_589_0 z).shape = [1, 16, 2, 16] := by
   unfold v_589_0
   change listSwapAt _ _ _ = _
   rw [h_588_0 z z_]
   rfl
 #a h_589_0
 attribute [local irreducible] v_589_0
 attribute [local irreducible] s_590
 theorem r_590_0 (z : Store) : (s_590 z) 846 = (v_587_0 z) := pR (k_589 z) (pR (k_588 z) (w_587_0 z))
 #a r_590_0
 theorem r_590_1 (z : Store) : (s_590 z) 1149 = (v_589_0 z) := w_589_0 z
 #a r_590_1
 def v_590_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_587_0 z), (v_589_0 z)]
 theorem g_590 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_556) (s_590 z) pmNode_556 2 1 849 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_556, r_590_0 z, r_590_1 z, h_587_0 z z_, h_589_0 z z_]
 #a g_590
 def s_591 (z : Store) : Store := pL [2, 3] (s_590 z) pmNode_556 2 1
 theorem t_590 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_556) (pmPeers pmNode_556) (s_590 z) pmNode_556 none = some (s_591 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_556) (s_590 z) pmNode_556).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 849 (by decide) (g_590 z z_)]
   rfl
 #a t_590
 theorem k_590 (z : Store) (tid : Tid) (h : tid ∉ [849]) : (s_591 z) tid = (s_590 z) tid := by
   unfold s_591
   dsimp only [pL, pmNode_556, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_590
 theorem w_590_0 (z : Store) : (s_591 z) 849 = v_590_0 z := by
   unfold s_591
   dsimp only [pL, pmNode_556, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_590_0, r_590_0 z, r_590_1 z] <;> rfl
 #a w_590_0
 theorem h_590_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_590_0 z).shape = [1, 8, 4, 16] := by
   unfold v_590_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_587_0 z z_]
 #a h_590_0
 attribute [local irreducible] v_590_0
 attribute [local irreducible] s_591
 theorem r_591_0 (z : Store) : (s_591 z) 849 = (v_590_0 z) := w_590_0 z
 #a r_591_0
 def v_591_0 (z : Store) : Tensor := (v_590_0 z)
 def s_592 (z : Store) : Store := storeSet (s_591 z) [(850, ((s_591 z) 849))]
 theorem t_591 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_557) (pmPeers pmNode_557) (s_591 z) pmNode_557 none = some (s_592 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_591
 theorem k_591 (z : Store) (tid : Tid) (h : tid ∉ [850]) : (s_592 z) tid = (s_591 z) tid := by
   unfold s_592
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_591
 theorem w_591_0 (z : Store) : (s_592 z) 850 = v_591_0 z := by
   unfold s_592
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_591_0, r_591_0 z] <;> rfl
 #a w_591_0
 theorem h_591_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_591_0 z).shape = [1, 8, 4, 16] := by
   unfold v_591_0
   exact h_590_0 z z_
 #a h_591_0
 attribute [local irreducible] v_591_0
 attribute [local irreducible] s_592
 theorem r_592_0 (z : Store) : (s_592 z) 846 = (v_587_0 z) := pR (k_591 z) (pR (k_590 z) (r_590_0 z))
 #a r_592_0
 theorem r_592_1 (z : Store) : (s_592 z) 1149 = (v_589_0 z) := pR (k_591 z) (pR (k_590 z) (r_590_1 z))
 #a r_592_1
 def v_592_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_587_0 z), (v_589_0 z)]
 theorem g_592 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_792) (s_592 z) pmNode_792 2 1 1152 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_792, r_592_0 z, r_592_1 z, h_587_0 z z_, h_589_0 z z_]
 #a g_592
 def s_593 (z : Store) : Store := pL [2, 3] (s_592 z) pmNode_792 2 1
 theorem t_592 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_792) (pmPeers pmNode_792) (s_592 z) pmNode_792 none = some (s_593 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_792) (s_592 z) pmNode_792).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1152 (by decide) (g_592 z z_)]
   rfl
 #a t_592
 theorem k_592 (z : Store) (tid : Tid) (h : tid ∉ [1152]) : (s_593 z) tid = (s_592 z) tid := by
   unfold s_593
   dsimp only [pL, pmNode_792, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_592
 theorem w_592_0 (z : Store) : (s_593 z) 1152 = v_592_0 z := by
   unfold s_593
   dsimp only [pL, pmNode_792, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_592_0, r_592_0 z, r_592_1 z] <;> rfl
 #a w_592_0
 theorem h_592_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_592_0 z).shape = [1, 8, 4, 16] := by
   unfold v_592_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_587_0 z z_]
 #a h_592_0
 attribute [local irreducible] v_592_0
 attribute [local irreducible] s_593
 theorem r_593_0 (z : Store) : (s_593 z) 1152 = (v_592_0 z) := w_592_0 z
 #a r_593_0
 def v_593_0 (z : Store) : Tensor := (v_592_0 z)
 def s_594 (z : Store) : Store := storeSet (s_593 z) [(1153, ((s_593 z) 1152))]
 theorem t_593 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_793) (pmPeers pmNode_793) (s_593 z) pmNode_793 none = some (s_594 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_593
 theorem k_593 (z : Store) (tid : Tid) (h : tid ∉ [1153]) : (s_594 z) tid = (s_593 z) tid := by
   unfold s_594
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_593
 theorem w_593_0 (z : Store) : (s_594 z) 1153 = v_593_0 z := by
   unfold s_594
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_593_0, r_593_0 z] <;> rfl
 #a w_593_0
 theorem h_593_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_593_0 z).shape = [1, 8, 4, 16] := by
   unfold v_593_0
   exact h_592_0 z z_
 #a h_593_0
 attribute [local irreducible] v_593_0
 attribute [local irreducible] s_594
 theorem r_594_0 (z : Store) : (s_594 z) 850 = (v_591_0 z) := pR (k_593 z) (pR (k_592 z) (w_591_0 z))
 #a r_594_0
 theorem r_594_1 (z : Store) : (s_594 z) 1153 = (v_593_0 z) := w_593_0 z
 #a r_594_1
 def v_594_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_591_0 z), (v_593_0 z)]
 theorem g_594 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_558) (s_594 z) pmNode_558 1 2 853 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_558, r_594_0 z, r_594_1 z, h_591_0 z z_, h_593_0 z z_]
 #a g_594
 def s_595 (z : Store) : Store := pL [2, 3] (s_594 z) pmNode_558 1 2
 theorem t_594 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_558) (pmPeers pmNode_558) (s_594 z) pmNode_558 none = some (s_595 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_558) (s_594 z) pmNode_558).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 853 (by decide) (g_594 z z_)]
   rfl
 #a t_594
 theorem k_594 (z : Store) (tid : Tid) (h : tid ∉ [853]) : (s_595 z) tid = (s_594 z) tid := by
   unfold s_595
   dsimp only [pL, pmNode_558, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_594
 theorem w_594_0 (z : Store) : (s_595 z) 853 = v_594_0 z := by
   unfold s_595
   dsimp only [pL, pmNode_558, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_594_0, r_594_0 z, r_594_1 z] <;> rfl
 #a w_594_0
 theorem h_594_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_594_0 z).shape = [1, 16, 2, 16] := by
   unfold v_594_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_591_0 z z_]
 #a h_594_0
 attribute [local irreducible] v_594_0
 attribute [local irreducible] s_595
 theorem r_595_0 (z : Store) : (s_595 z) 853 = (v_594_0 z) := w_594_0 z
 #a r_595_0
 def v_595_0 (z : Store) : Tensor := fw_view [1, 16, 32] (v_594_0 z)
 def s_596 (z : Store) : Store := storeSet (s_595 z) [(854, fw_view [1, 16, 32] ((s_595 z) 853))]
 theorem t_595 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_559) (pmPeers pmNode_559) (s_595 z) pmNode_559 none = some (s_596 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_595
 theorem k_595 (z : Store) (tid : Tid) (h : tid ∉ [854]) : (s_596 z) tid = (s_595 z) tid := by
   unfold s_596
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_595
 theorem w_595_0 (z : Store) : (s_596 z) 854 = v_595_0 z := by
   unfold s_596
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_595_0, r_595_0 z] <;> rfl
 #a w_595_0
 theorem h_595_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_595_0 z).shape = [1, 16, 32] := by
   unfold v_595_0
   rfl
 #a h_595_0
 attribute [local irreducible] v_595_0
 attribute [local irreducible] s_596
 theorem n_592_596 (z : Store) (tid : Tid) (h : tid ∉ ([1152, 1153, 853, 854] : List Tid)) : (s_596 z) tid = (s_592 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_592 z) (k_593 z)) (pF _ _ _ _ _ (k_594 z) (k_595 z)) tid h
 #a n_592_596
 theorem n_576_584 (z : Store) (tid : Tid) (h : tid ∉ ([1137, 1138, 838, 839, 685, 842, 1141, 1142] : List Tid)) : (s_584 z) tid = (s_576 z) tid := by
   exact pF _ _ _ _ _ (n_576_580 z) (n_580_584 z) tid h
 #a n_576_584
 theorem n_584_588 (z : Store) (tid : Tid) (h : tid ∉ ([988, 1145, 845, 846] : List Tid)) : (s_588 z) tid = (s_584 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_584 z) (k_585 z)) (pF _ _ _ _ _ (k_586 z) (k_587 z)) tid h
 #a n_584_588
 theorem n_588_592 (z : Store) (tid : Tid) (h : tid ∉ ([1148, 1149, 849, 850] : List Tid)) : (s_592 z) tid = (s_588 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_588 z) (k_589 z)) (pF _ _ _ _ _ (k_590 z) (k_591 z)) tid h
 #a n_588_592
 theorem n_584_592 (z : Store) (tid : Tid) (h : tid ∉ ([988, 1145, 845, 846, 1148, 1149, 849, 850] : List Tid)) : (s_592 z) tid = (s_584 z) tid := by
   exact pF _ _ _ _ _ (n_584_588 z) (n_588_592 z) tid h
 #a n_584_592
 theorem n_576_592 (z : Store) (tid : Tid) (h : tid ∉ ([1137, 1138, 838, 839, 685, 842, 1141, 1142, 988, 1145, 845, 846, 1148, 1149, 849, 850] : List Tid)) : (s_592 z) tid = (s_576 z) tid := by
   exact pF _ _ _ _ _ (n_576_584 z) (n_584_592 z) tid h
 #a n_576_592
 theorem n_544_560 (z : Store) (tid : Tid) (h : tid ∉ ([1104, 1105, 1107, 1108, 808, 809, 812, 813, 1111, 1112, 1115, 1116, 816, 817, 820, 821] : List Tid)) : (s_560 z) tid = (s_544 z) tid := by
   exact pF _ _ _ _ _ (n_544_552 z) (n_552_560 z) tid h
 #a n_544_560
 theorem n_560_576 (z : Store) (tid : Tid) (h : tid ∉ ([1119, 1120, 1123, 1124, 824, 825, 828, 1127, 1128, 1131, 830, 831, 1133, 1134, 834, 835] : List Tid)) : (s_576 z) tid = (s_560 z) tid := by
   exact pF _ _ _ _ _ (n_560_568 z) (n_568_576 z) tid h
 #a n_560_576
 theorem n_544_576 (z : Store) (tid : Tid) (h : tid ∉ ([1104, 1105, 1107, 1108, 808, 809, 812, 813, 1111, 1112, 1115, 1116, 816, 817, 820, 821, 1119, 1120, 1123, 1124, 824, 825, 828, 1127, 1128, 1131, 830, 831, 1133, 1134, 834, 835] : List Tid)) : (s_576 z) tid = (s_544 z) tid := by
   exact pF _ _ _ _ _ (n_544_560 z) (n_560_576 z) tid h
 #a n_544_576
 theorem n_512_576 (z : Store) (tid : Tid) (h : tid ∉ ([779, 781, 783, 1078, 1079, 1082, 1084, 1086, 786, 787, 897, 858, 1089, 1090, 1200, 1161, 791, 792, 899, 901, 903, 1094, 1095, 1202, 1204, 1206, 694, 795, 798, 799, 801, 802, 997, 1098, 804, 805, 1101, 1102, 1104, 1105, 1107, 1108, 808, 809, 812, 813, 1111, 1112, 1115, 1116, 816, 817, 820, 821, 1119, 1120, 1123, 1124, 824, 825, 828, 1127, 1128, 1131, 830, 831, 1133, 1134, 834, 835] : List Tid)) : (s_576 z) tid = (s_512 z) tid := by
   exact pF _ _ _ _ _ (n_512_544 z) (n_544_576 z) tid h
 #a n_512_576
 record_prefix_opacity v_588_0 s_589 v_589_0 s_590 v_590_0 s_591 v_591_0 s_592 v_592_0 s_593 v_593_0 s_594 v_594_0 s_595 v_595_0 s_596

 end
 end TrainVerify.Denote.RuntimeWorld
