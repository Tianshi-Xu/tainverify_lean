import FreshScoreDiv
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
theorem projectionFrontierJoint (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    ((t 1305).shape = [2, 4, 16, 16] ∧ (∀ y ∈ [q 229, q 532], y.shape = [1, 4, 16, 8]) ∧ chunkPrimDimN 0 2 0 (t 1305) = allGatherPrimDimN 3 2 0 [q 229, q 532]) ∧
    ((t 1302).shape = [2, 4, 16, 16] ∧ (∀ y ∈ [q 79, q 382], y.shape = [1, 4, 16, 16]) ∧ (∀ y ∈ [q 79, q 382], y = chunkPrimDimN 0 2 0 (t 1302))) ∧
    ((t 1391).shape = [2, 16, 64] ∧ (∀ y ∈ [q 252, q 555], y.shape = [1, 16, 32]) ∧ chunkPrimDimN 0 2 0 (t 1391) = allGatherPrimDimN 2 2 0 [q 252, q 555]) ∧
    ((t 1305).shape = [2, 4, 16, 16] ∧ (∀ y ∈ [q 835, q 1138], y.shape = [1, 4, 16, 8]) ∧ chunkPrimDimN 0 2 1 (t 1305) = allGatherPrimDimN 3 2 0 [q 835, q 1138]) ∧
    ((t 1302).shape = [2, 4, 16, 16] ∧ (∀ y ∈ [q 685, q 988], y.shape = [1, 4, 16, 16]) ∧ (∀ y ∈ [q 685, q 988], y = chunkPrimDimN 0 2 1 (t 1302))) ∧
    ((t 1391).shape = [2, 16, 64] ∧ (∀ y ∈ [q 858, q 1161], y.shape = [1, 16, 32]) ∧ chunkPrimDimN 0 2 1 (t 1391) = allGatherPrimDimN 2 2 0 [q 858, q 1161]) := by
  exact ⟨frontierScoreDivUnitFacts_1305_0 s p t q hs hp hvalues, frontierPostTransposeUnitFacts_1302_0_slot0 s p t q hs hp hvalues, frontierAliasFacts_1391_0 s p t q hs hp hvalues, frontierScoreDivUnitFacts_1305_1 s p t q hs hp hvalues, frontierPostTransposeUnitFacts_1302_1_slot0 s p t q hs hp hvalues, frontierAliasFacts_1391_1 s p t q hs hp hvalues⟩
#print axioms projectionFrontierJoint
end
end TrainVerify.Denote.RuntimeWorld
