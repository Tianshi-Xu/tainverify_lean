import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0108
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_852_0 (z : Store) : (s_852 z) 33 = (v_343_1 z) := pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_352_384 z) (pR (n_344_352 z) (w_343_1 z)))))))
 #a r_852_0
 theorem r_852_1 (z : Store) : (s_852 z) 336 = (v_345_1 z) := pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_352_384 z) (pR (n_348_352 z) (pR (k_347 z) (pR (k_346 z) (w_345_1 z)))))))))
 #a r_852_1
 theorem r_852_2 (z : Store) : (s_852 z) 639 = (v_765_1 z) := pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (k_767 z) (pR (k_766 z) (w_765_1 z)))))
 #a r_852_2
 theorem r_852_3 (z : Store) : (s_852 z) 942 = (v_767_1 z) := pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (w_767_1 z)))
 #a r_852_3
 def v_852_0 (z : Store) : Tensor := cross_dp_wred [(v_343_1 z), (v_345_1 z), (v_765_1 z), (v_767_1 z)]
 theorem g_852 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_220) (s_852 z) pmNode_220 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_220, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_852_1 z, r_852_0 z]
     exact (h_345_1 z z_).trans (h_343_1 z z_).symm
   · rw [r_852_2 z, r_852_0 z]
     exact (h_765_1 z z_).trans (h_343_1 z z_).symm
   · rw [r_852_3 z, r_852_0 z]
     exact (h_767_1 z z_).trans (h_343_1 z z_).symm
 #a g_852
 def s_853 (z : Store) : Store := storeSet (s_852 z) [(34, cross_dp_wred [((s_852 z) 33), ((s_852 z) 336), ((s_852 z) 639), ((s_852 z) 942)])]
 theorem t_852 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_220) (pmPeers pmNode_220) (s_852 z) pmNode_220 none = some (s_853 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_220) (s_852 z) pmNode_220 = _
   rw [wredStep, if_pos ⟨by decide, g_852 z z_⟩]
   rfl
 #a t_852
 theorem k_852 (z : Store) (tid : Tid) (h : tid ∉ [34]) : (s_853 z) tid = (s_852 z) tid := by
   unfold s_853
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_852
 theorem w_852_0 (z : Store) : (s_853 z) 34 = v_852_0 z := by
   unfold s_853
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_852_0, r_852_0 z, r_852_1 z, r_852_2 z, r_852_3 z] <;> rfl
 #a w_852_0
 theorem h_852_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_852_0 z).shape = [64, 64] := by
   unfold v_852_0
   rw [tensorSum_shape]
   exact h_343_1 z z_
 #a h_852_0
 attribute [local irreducible] v_852_0
 attribute [local irreducible] s_853
 theorem r_853_0 (z : Store) : (s_853 z) 35 = (v_330_1 z) := pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_352_384 z) (pR (n_336_352 z) (pR (n_332_336 z) (pR (k_331 z) (w_330_1 z))))))))))
 #a r_853_0
 theorem r_853_1 (z : Store) : (s_853 z) 338 = (v_335_1 z) := pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_352_384 z) (pR (n_336_352 z) (w_335_1 z))))))))
 #a r_853_1
 theorem r_853_2 (z : Store) : (s_853 z) 641 = (v_752_1 z) := pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_760_768 z) (pR (n_756_760 z) (pR (k_755 z) (pR (k_754 z) (pR (k_753 z) (w_752_1 z)))))))))
 #a r_853_2
 theorem r_853_3 (z : Store) : (s_853 z) 944 = (v_757_1 z) := pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_760_768 z) (pR (k_759 z) (pR (k_758 z) (w_757_1 z)))))))
 #a r_853_3
 def v_853_0 (z : Store) : Tensor := cross_dp_wred [(v_330_1 z), (v_335_1 z), (v_752_1 z), (v_757_1 z)]
 theorem g_853 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_221) (s_853 z) pmNode_221 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_221, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_853_1 z, r_853_0 z]
     exact (h_335_1 z z_).trans (h_330_1 z z_).symm
   · rw [r_853_2 z, r_853_0 z]
     exact (h_752_1 z z_).trans (h_330_1 z z_).symm
   · rw [r_853_3 z, r_853_0 z]
     exact (h_757_1 z z_).trans (h_330_1 z z_).symm
 #a g_853
 def s_854 (z : Store) : Store := storeSet (s_853 z) [(36, cross_dp_wred [((s_853 z) 35), ((s_853 z) 338), ((s_853 z) 641), ((s_853 z) 944)])]
 theorem t_853 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_221) (pmPeers pmNode_221) (s_853 z) pmNode_221 none = some (s_854 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_221) (s_853 z) pmNode_221 = _
   rw [wredStep, if_pos ⟨by decide, g_853 z z_⟩]
   rfl
 #a t_853
 theorem k_853 (z : Store) (tid : Tid) (h : tid ∉ [36]) : (s_854 z) tid = (s_853 z) tid := by
   unfold s_854
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_853
 theorem w_853_0 (z : Store) : (s_854 z) 36 = v_853_0 z := by
   unfold s_854
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_853_0, r_853_0 z, r_853_1 z, r_853_2 z, r_853_3 z] <;> rfl
 #a w_853_0
 theorem h_853_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_853_0 z).shape = [64] := by
   unfold v_853_0
   rw [tensorSum_shape]
   exact h_330_1 z z_
 #a h_853_0
 attribute [local irreducible] v_853_0
 attribute [local irreducible] s_854
 theorem r_854_0 (z : Store) : (s_854 z) 37 = (v_330_2 z) := pR (k_853 z) (pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_352_384 z) (pR (n_336_352 z) (pR (n_332_336 z) (pR (k_331 z) (w_330_2 z)))))))))))
 #a r_854_0
 theorem r_854_1 (z : Store) : (s_854 z) 340 = (v_335_2 z) := pR (k_853 z) (pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_352_384 z) (pR (n_336_352 z) (w_335_2 z)))))))))
 #a r_854_1
 theorem r_854_2 (z : Store) : (s_854 z) 643 = (v_752_2 z) := pR (k_853 z) (pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_760_768 z) (pR (n_756_760 z) (pR (k_755 z) (pR (k_754 z) (pR (k_753 z) (w_752_2 z))))))))))
 #a r_854_2
 theorem r_854_3 (z : Store) : (s_854 z) 946 = (v_757_2 z) := pR (k_853 z) (pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_760_768 z) (pR (k_759 z) (pR (k_758 z) (w_757_2 z))))))))
 #a r_854_3
 def v_854_0 (z : Store) : Tensor := cross_dp_wred [(v_330_2 z), (v_335_2 z), (v_752_2 z), (v_757_2 z)]
 theorem g_854 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_222) (s_854 z) pmNode_222 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_222, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_854_1 z, r_854_0 z]
     exact (h_335_2 z z_).trans (h_330_2 z z_).symm
   · rw [r_854_2 z, r_854_0 z]
     exact (h_752_2 z z_).trans (h_330_2 z z_).symm
   · rw [r_854_3 z, r_854_0 z]
     exact (h_757_2 z z_).trans (h_330_2 z z_).symm
 #a g_854
 def s_855 (z : Store) : Store := storeSet (s_854 z) [(38, cross_dp_wred [((s_854 z) 37), ((s_854 z) 340), ((s_854 z) 643), ((s_854 z) 946)])]
 theorem t_854 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_222) (pmPeers pmNode_222) (s_854 z) pmNode_222 none = some (s_855 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_222) (s_854 z) pmNode_222 = _
   rw [wredStep, if_pos ⟨by decide, g_854 z z_⟩]
   rfl
 #a t_854
 theorem k_854 (z : Store) (tid : Tid) (h : tid ∉ [38]) : (s_855 z) tid = (s_854 z) tid := by
   unfold s_855
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_854
 theorem w_854_0 (z : Store) : (s_855 z) 38 = v_854_0 z := by
   unfold s_855
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_854_0, r_854_0 z, r_854_1 z, r_854_2 z, r_854_3 z] <;> rfl
 #a w_854_0
 theorem h_854_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_854_0 z).shape = [64] := by
   unfold v_854_0
   rw [tensorSum_shape]
   exact h_330_2 z z_
 #a h_854_0
 attribute [local irreducible] v_854_0
 attribute [local irreducible] s_855
 theorem r_855_0 (z : Store) : (s_855 z) 39 = (v_329_1 z) := pR (k_854 z) (pR (k_853 z) (pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_352_384 z) (pR (n_336_352 z) (pR (n_332_336 z) (pR (k_331 z) (pR (k_330 z) (w_329_1 z)))))))))))))
 #a r_855_0
 theorem r_855_1 (z : Store) : (s_855 z) 342 = (v_334_1 z) := pR (k_854 z) (pR (k_853 z) (pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_352_384 z) (pR (n_336_352 z) (pR (k_335 z) (w_334_1 z)))))))))))
 #a r_855_1
 theorem r_855_2 (z : Store) : (s_855 z) 645 = (v_751_1 z) := pR (k_854 z) (pR (k_853 z) (pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_752_768 z) (w_751_1 z)))))))
 #a r_855_2
 theorem r_855_3 (z : Store) : (s_855 z) 948 = (v_756_1 z) := pR (k_854 z) (pR (k_853 z) (pR (k_852 z) (pR (n_848_852 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_760_768 z) (pR (k_759 z) (pR (k_758 z) (pR (k_757 z) (w_756_1 z))))))))))
 #a r_855_3
 def v_855_0 (z : Store) : Tensor := cross_dp_wred [(v_329_1 z), (v_334_1 z), (v_751_1 z), (v_756_1 z)]
 theorem g_855 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_223) (s_855 z) pmNode_223 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_223, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_855_1 z, r_855_0 z]
     exact (h_334_1 z z_).trans (h_329_1 z z_).symm
   · rw [r_855_2 z, r_855_0 z]
     exact (h_751_1 z z_).trans (h_329_1 z z_).symm
   · rw [r_855_3 z, r_855_0 z]
     exact (h_756_1 z z_).trans (h_329_1 z z_).symm
 #a g_855
 def s_856 (z : Store) : Store := storeSet (s_855 z) [(40, cross_dp_wred [((s_855 z) 39), ((s_855 z) 342), ((s_855 z) 645), ((s_855 z) 948)])]
 theorem t_855 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_223) (pmPeers pmNode_223) (s_855 z) pmNode_223 none = some (s_856 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_223) (s_855 z) pmNode_223 = _
   rw [wredStep, if_pos ⟨by decide, g_855 z z_⟩]
   rfl
 #a t_855
 theorem k_855 (z : Store) (tid : Tid) (h : tid ∉ [40]) : (s_856 z) tid = (s_855 z) tid := by
   unfold s_856
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_855
 theorem w_855_0 (z : Store) : (s_856 z) 40 = v_855_0 z := by
   unfold s_856
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_855_0, r_855_0 z, r_855_1 z, r_855_2 z, r_855_3 z] <;> rfl
 #a w_855_0
 theorem h_855_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_855_0 z).shape = [256, 64] := by
   unfold v_855_0
   rw [tensorSum_shape]
   exact h_329_1 z z_
 #a h_855_0
 attribute [local irreducible] v_855_0
 attribute [local irreducible] s_856
 theorem n_852_856 (z : Store) (tid : Tid) (h : tid ∉ ([34, 36, 38, 40] : List Tid)) : (s_856 z) tid = (s_852 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_852 z) (k_853 z)) (pF _ _ _ _ _ (k_854 z) (k_855 z)) tid h
 #a n_852_856
 theorem n_848_856 (z : Store) (tid : Tid) (h : tid ∉ ([62, 67, 69, 71, 34, 36, 38, 40] : List Tid)) : (s_856 z) tid = (s_848 z) tid := by
   exact pF _ _ _ _ _ (n_848_852 z) (n_852_856 z) tid h
 #a n_848_856
 theorem r_856_0 (z : Store) : (s_856 z) 41 = (v_327_1 z) := pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_352_384 z) (pR (n_336_352 z) (pR (n_328_336 z) (w_327_1 z))))))))
 #a r_856_0
 theorem r_856_1 (z : Store) : (s_856 z) 344 = (v_332_1 z) := pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_352_384 z) (pR (n_336_352 z) (pR (k_335 z) (pR (k_334 z) (pR (k_333 z) (w_332_1 z))))))))))
 #a r_856_1
 theorem r_856_2 (z : Store) : (s_856 z) 647 = (v_749_1 z) := pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_752_768 z) (pR (k_751 z) (pR (k_750 z) (w_749_1 z))))))
 #a r_856_2
 theorem r_856_3 (z : Store) : (s_856 z) 950 = (v_754_1 z) := pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_760_768 z) (pR (n_756_760 z) (pR (k_755 z) (w_754_1 z))))))
 #a r_856_3
 def v_856_0 (z : Store) : Tensor := cross_dp_wred [(v_327_1 z), (v_332_1 z), (v_749_1 z), (v_754_1 z)]
 theorem g_856 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_224) (s_856 z) pmNode_224 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_224, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_856_1 z, r_856_0 z]
     exact (h_332_1 z z_).trans (h_327_1 z z_).symm
   · rw [r_856_2 z, r_856_0 z]
     exact (h_749_1 z z_).trans (h_327_1 z z_).symm
   · rw [r_856_3 z, r_856_0 z]
     exact (h_754_1 z z_).trans (h_327_1 z z_).symm
 #a g_856
 def s_857 (z : Store) : Store := storeSet (s_856 z) [(42, cross_dp_wred [((s_856 z) 41), ((s_856 z) 344), ((s_856 z) 647), ((s_856 z) 950)])]
 theorem t_856 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_224) (pmPeers pmNode_224) (s_856 z) pmNode_224 none = some (s_857 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_224) (s_856 z) pmNode_224 = _
   rw [wredStep, if_pos ⟨by decide, g_856 z z_⟩]
   rfl
 #a t_856
 theorem k_856 (z : Store) (tid : Tid) (h : tid ∉ [42]) : (s_857 z) tid = (s_856 z) tid := by
   unfold s_857
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_856
 theorem w_856_0 (z : Store) : (s_857 z) 42 = v_856_0 z := by
   unfold s_857
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_856_0, r_856_0 z, r_856_1 z, r_856_2 z, r_856_3 z] <;> rfl
 #a w_856_0
 theorem h_856_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_856_0 z).shape = [64, 256] := by
   unfold v_856_0
   rw [tensorSum_shape]
   exact h_327_1 z z_
 #a h_856_0
 attribute [local irreducible] v_856_0
 attribute [local irreducible] s_857
 theorem r_857_0 (z : Store) : (s_857 z) 43 = (v_316_1 z) := pR (k_856 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_320_384 z) (pR (k_319 z) (pR (k_318 z) (pR (k_317 z) (w_316_1 z))))))))))
 #a r_857_0
 theorem r_857_1 (z : Store) : (s_857 z) 346 = (v_319_1 z) := pR (k_856 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_320_384 z) (w_319_1 z)))))))
 #a r_857_1
 theorem r_857_2 (z : Store) : (s_857 z) 649 = (v_738_1 z) := pR (k_856 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_752_768 z) (pR (n_744_752 z) (pR (n_740_744 z) (pR (k_739 z) (w_738_1 z))))))))
 #a r_857_2
 theorem r_857_3 (z : Store) : (s_857 z) 952 = (v_741_1 z) := pR (k_856 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_752_768 z) (pR (n_744_752 z) (pR (k_743 z) (pR (k_742 z) (w_741_1 z))))))))
 #a r_857_3
 def v_857_0 (z : Store) : Tensor := cross_dp_wred [(v_316_1 z), (v_319_1 z), (v_738_1 z), (v_741_1 z)]
 theorem g_857 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_225) (s_857 z) pmNode_225 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_225, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_857_1 z, r_857_0 z]
     exact (h_319_1 z z_).trans (h_316_1 z z_).symm
   · rw [r_857_2 z, r_857_0 z]
     exact (h_738_1 z z_).trans (h_316_1 z z_).symm
   · rw [r_857_3 z, r_857_0 z]
     exact (h_741_1 z z_).trans (h_316_1 z z_).symm
 #a g_857
 def s_858 (z : Store) : Store := storeSet (s_857 z) [(44, cross_dp_wred [((s_857 z) 43), ((s_857 z) 346), ((s_857 z) 649), ((s_857 z) 952)])]
 theorem t_857 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_225) (pmPeers pmNode_225) (s_857 z) pmNode_225 none = some (s_858 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_225) (s_857 z) pmNode_225 = _
   rw [wredStep, if_pos ⟨by decide, g_857 z z_⟩]
   rfl
 #a t_857
 theorem k_857 (z : Store) (tid : Tid) (h : tid ∉ [44]) : (s_858 z) tid = (s_857 z) tid := by
   unfold s_858
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_857
 theorem w_857_0 (z : Store) : (s_858 z) 44 = v_857_0 z := by
   unfold s_858
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_857_0, r_857_0 z, r_857_1 z, r_857_2 z, r_857_3 z] <;> rfl
 #a w_857_0
 theorem h_857_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_857_0 z).shape = [64] := by
   unfold v_857_0
   rw [tensorSum_shape]
   exact h_316_1 z z_
 #a h_857_0
 attribute [local irreducible] v_857_0
 attribute [local irreducible] s_858
 theorem r_858_0 (z : Store) : (s_858 z) 45 = (v_316_2 z) := pR (k_857 z) (pR (k_856 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_320_384 z) (pR (k_319 z) (pR (k_318 z) (pR (k_317 z) (w_316_2 z)))))))))))
 #a r_858_0
 theorem r_858_1 (z : Store) : (s_858 z) 348 = (v_319_2 z) := pR (k_857 z) (pR (k_856 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_320_384 z) (w_319_2 z))))))))
 #a r_858_1
 theorem r_858_2 (z : Store) : (s_858 z) 651 = (v_738_2 z) := pR (k_857 z) (pR (k_856 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_752_768 z) (pR (n_744_752 z) (pR (n_740_744 z) (pR (k_739 z) (w_738_2 z)))))))))
 #a r_858_2
 theorem r_858_3 (z : Store) : (s_858 z) 954 = (v_741_2 z) := pR (k_857 z) (pR (k_856 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_752_768 z) (pR (n_744_752 z) (pR (k_743 z) (pR (k_742 z) (w_741_2 z)))))))))
 #a r_858_3
 def v_858_0 (z : Store) : Tensor := cross_dp_wred [(v_316_2 z), (v_319_2 z), (v_738_2 z), (v_741_2 z)]
 theorem g_858 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 1, 2, 3] (pmPeers pmNode_226) (s_858 z) pmNode_226 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_226, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl | rfl | rfl
   · rfl
   · rw [r_858_1 z, r_858_0 z]
     exact (h_319_2 z z_).trans (h_316_2 z z_).symm
   · rw [r_858_2 z, r_858_0 z]
     exact (h_738_2 z z_).trans (h_316_2 z z_).symm
   · rw [r_858_3 z, r_858_0 z]
     exact (h_741_2 z z_).trans (h_316_2 z z_).symm
 #a g_858
 def s_859 (z : Store) : Store := storeSet (s_858 z) [(46, cross_dp_wred [((s_858 z) 45), ((s_858 z) 348), ((s_858 z) 651), ((s_858 z) 954)])]
 theorem t_858 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_226) (pmPeers pmNode_226) (s_858 z) pmNode_226 none = some (s_859 z) := by
   change wredStep pmGraph (some [0, 1, 2, 3]) (pmPeers pmNode_226) (s_858 z) pmNode_226 = _
   rw [wredStep, if_pos ⟨by decide, g_858 z z_⟩]
   rfl
 #a t_858
 theorem k_858 (z : Store) (tid : Tid) (h : tid ∉ [46]) : (s_859 z) tid = (s_858 z) tid := by
   unfold s_859
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_858
 theorem w_858_0 (z : Store) : (s_859 z) 46 = v_858_0 z := by
   unfold s_859
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_858_0, r_858_0 z, r_858_1 z, r_858_2 z, r_858_3 z] <;> rfl
 #a w_858_0
 theorem h_858_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_858_0 z).shape = [64] := by
   unfold v_858_0
   rw [tensorSum_shape]
   exact h_316_2 z z_
 #a h_858_0
 attribute [local irreducible] v_858_0
 attribute [local irreducible] s_859
 record_prefix_opacity v_852_0 s_853 v_853_0 s_854 v_854_0 s_855 v_855_0 s_856 v_856_0 s_857 v_857_0 s_858 v_858_0 s_859

 end
 end TrainVerify.Denote.RuntimeWorld
