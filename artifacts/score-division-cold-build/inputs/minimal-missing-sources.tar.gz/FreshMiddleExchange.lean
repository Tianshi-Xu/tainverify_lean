import FreshPostTranspose
import denote.SourceRank4MiddleExchange
-- UNCOMPILED: parent owns imports, predecessors, frame, aggregate costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierMiddleExchangeRead_pm_224 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 224 = AllToAllSourceFaithful.tensor 2 0 2 1 (([222, 525] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 148) (pmInputRequests.drop 149) pmNode_74 0 [0, 1] [222, 525] 224 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 148 ++ pmInputRequests.drop 148 := (List.take_append_drop 148 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([222, 525] : List Tid), ∀ row ∈ pmInputRequests.drop 148, tid ∉ row.1.outs
    decide
#print axioms frontierMiddleExchangeRead_pm_224
theorem frontierMiddleExchangeRead_pm_527 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 527 = AllToAllSourceFaithful.tensor 2 1 2 1 (([222, 525] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 150) (pmInputRequests.drop 151) pmNode_310 1 [0, 1] [222, 525] 527 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 150 ++ pmInputRequests.drop 150 := (List.take_append_drop 150 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([222, 525] : List Tid), ∀ row ∈ pmInputRequests.drop 150, tid ∉ row.1.outs
    decide
#print axioms frontierMiddleExchangeRead_pm_527
theorem frontierMiddleExchangeUnitFacts_1303_0_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1303).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 224, q 527], y.shape = [1, 2, 16, 16]) ∧
    chunkPrimDimN 0 2 0 (t 1303) = allGatherPrimDimN 1 2 0 [q 224, q 527] := by
  have predecessor := frontierPostTransposeUnitFacts_1303_0_slot0 s p t q hs hp hvalues
  have outputs : [q 224, q 527] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 2 1 [q 222, q 525]) := by
    change [q 224, q 527] = [AllToAllSourceFaithful.tensor 2 0 2 1 [q 222, q 525], AllToAllSourceFaithful.tensor 2 1 2 1 [q 222, q 525]]
    exact congrArg₂ List.cons (frontierMiddleExchangeRead_pm_224 p q hp) (congrArg₂ List.cons (frontierMiddleExchangeRead_pm_527 p q hp) (rfl))
  exact SourceRank4MiddleExchange.axis2_output_facts 2 0 2 1 2 8 16 (t 1303) [q 222, q 525] [q 224, q 527]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierMiddleExchangeUnitFacts_1303_0_slot0
theorem frontierMiddleExchangeRead_pm_830 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 830 = AllToAllSourceFaithful.tensor 2 0 2 1 (([828, 1131] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 570) (pmInputRequests.drop 571) pmNode_546 2 [2, 3] [828, 1131] 830 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 570 ++ pmInputRequests.drop 570 := (List.take_append_drop 570 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([828, 1131] : List Tid), ∀ row ∈ pmInputRequests.drop 570, tid ∉ row.1.outs
    decide
#print axioms frontierMiddleExchangeRead_pm_830
theorem frontierMiddleExchangeRead_pm_1133 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1133 = AllToAllSourceFaithful.tensor 2 1 2 1 (([828, 1131] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 572) (pmInputRequests.drop 573) pmNode_782 3 [2, 3] [828, 1131] 1133 2 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 572 ++ pmInputRequests.drop 572 := (List.take_append_drop 572 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([828, 1131] : List Tid), ∀ row ∈ pmInputRequests.drop 572, tid ∉ row.1.outs
    decide
#print axioms frontierMiddleExchangeRead_pm_1133
theorem frontierMiddleExchangeUnitFacts_1303_1_slot0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1303).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 830, q 1133], y.shape = [1, 2, 16, 16]) ∧
    chunkPrimDimN 0 2 1 (t 1303) = allGatherPrimDimN 1 2 0 [q 830, q 1133] := by
  have predecessor := frontierPostTransposeUnitFacts_1303_1_slot0 s p t q hs hp hvalues
  have outputs : [q 830, q 1133] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 2 1 [q 828, q 1131]) := by
    change [q 830, q 1133] = [AllToAllSourceFaithful.tensor 2 0 2 1 [q 828, q 1131], AllToAllSourceFaithful.tensor 2 1 2 1 [q 828, q 1131]]
    exact congrArg₂ List.cons (frontierMiddleExchangeRead_pm_830 p q hp) (congrArg₂ List.cons (frontierMiddleExchangeRead_pm_1133 p q hp) (rfl))
  exact SourceRank4MiddleExchange.axis2_output_facts 2 1 2 1 2 8 16 (t 1303) [q 828, q 1131] [q 830, q 1133]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierMiddleExchangeUnitFacts_1303_1_slot0
end
end TrainVerify.Denote.RuntimeWorld
