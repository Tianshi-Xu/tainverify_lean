import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0097
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_770_0 (z : Store) : (s_770 z) 767 = (v_765_0 z) := pR (k_769 z) (pR (k_768 z) (r_768_0 z))
 #a r_770_0
 theorem r_770_1 (z : Store) : (s_770 z) 1070 = (v_767_0 z) := pR (k_769 z) (pR (k_768 z) (r_768_1 z))
 #a r_770_1
 def v_770_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_765_0 z), (v_767_0 z)]
 theorem g_770 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_881) (s_770 z) pmNode_881 1 2 1067 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_881, r_770_0 z, r_770_1 z, h_765_0 z z_, h_767_0 z z_]
 #a g_770
 def s_771 (z : Store) : Store := pL [2, 3] (s_770 z) pmNode_881 1 2
 theorem t_770 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_881) (pmPeers pmNode_881) (s_770 z) pmNode_881 none = some (s_771 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_881) (s_770 z) pmNode_881).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1067 (by decide) (g_770 z z_)]
   rfl
 #a t_770
 theorem k_770 (z : Store) (tid : Tid) (h : tid ∉ [1067]) : (s_771 z) tid = (s_770 z) tid := by
   unfold s_771
   dsimp only [pL, pmNode_881, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_770
 theorem w_770_0 (z : Store) : (s_771 z) 1067 = v_770_0 z := by
   unfold s_771
   dsimp only [pL, pmNode_881, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_770_0, r_770_0 z, r_770_1 z] <;> rfl
 #a w_770_0
 theorem h_770_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_770_0 z).shape = [1, 16, 32] := by
   unfold v_770_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_765_0 z z_]
 #a h_770_0
 attribute [local irreducible] v_770_0
 attribute [local irreducible] s_771
 theorem r_771_0 (z : Store) : (s_771 z) 1067 = (v_770_0 z) := w_770_0 z
 #a r_771_0
 theorem r_771_1 (z : Store) : (s_771 z) 1064 = (v_498_0 z) := pR (k_770 z) (pR (k_769 z) (pR (k_768 z) (pR (n_512_768 z) (pR (n_504_512 z) (pR (n_500_504 z) (pR (k_499 z) (r_499_0 z)))))))
 #a r_771_1
 def v_771_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_770_0 z)
 def s_772 (z : Store) : Store := storeSet (s_771 z) [(1066, fw_view [1, 16, 2, 16] ((s_771 z) 1067))]
 theorem t_771 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_882) (pmPeers pmNode_882) (s_771 z) pmNode_882 none = some (s_772 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_771
 theorem k_771 (z : Store) (tid : Tid) (h : tid ∉ [1066]) : (s_772 z) tid = (s_771 z) tid := by
   unfold s_772
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_771
 theorem w_771_0 (z : Store) : (s_772 z) 1066 = v_771_0 z := by
   unfold s_772
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_771_0, r_771_0 z, r_771_1 z] <;> rfl
 #a w_771_0
 theorem h_771_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_771_0 z).shape = [1, 16, 2, 16] := by
   unfold v_771_0
   rfl
 #a h_771_0
 attribute [local irreducible] v_771_0
 attribute [local irreducible] s_772
 theorem r_772_0 (z : Store) : (s_772 z) 763 = (v_769_0 z) := pR (k_771 z) (pR (k_770 z) (w_769_0 z))
 #a r_772_0
 theorem r_772_1 (z : Store) : (s_772 z) 1066 = (v_771_0 z) := w_771_0 z
 #a r_772_1
 def v_772_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_769_0 z), (v_771_0 z)]
 theorem g_772 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_647) (s_772 z) pmNode_647 2 1 760 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_647, r_772_0 z, r_772_1 z, h_769_0 z z_, h_771_0 z z_]
 #a g_772
 def s_773 (z : Store) : Store := pL [2, 3] (s_772 z) pmNode_647 2 1
 theorem t_772 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_647) (pmPeers pmNode_647) (s_772 z) pmNode_647 none = some (s_773 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_647) (s_772 z) pmNode_647).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 760 (by decide) (g_772 z z_)]
   rfl
 #a t_772
 theorem k_772 (z : Store) (tid : Tid) (h : tid ∉ [760]) : (s_773 z) tid = (s_772 z) tid := by
   unfold s_773
   dsimp only [pL, pmNode_647, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_772
 theorem w_772_0 (z : Store) : (s_773 z) 760 = v_772_0 z := by
   unfold s_773
   dsimp only [pL, pmNode_647, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_772_0, r_772_0 z, r_772_1 z] <;> rfl
 #a w_772_0
 theorem h_772_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_772_0 z).shape = [1, 8, 4, 16] := by
   unfold v_772_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_769_0 z z_]
 #a h_772_0
 attribute [local irreducible] v_772_0
 attribute [local irreducible] s_773
 theorem n_768_772 (z : Store) (tid : Tid) (h : tid ∉ ([764, 763, 1067, 1066] : List Tid)) : (s_772 z) tid = (s_768 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_768 z) (k_769 z)) (pF _ _ _ _ _ (k_770 z) (k_771 z)) tid h
 #a n_768_772
 theorem r_773_0 (z : Store) : (s_773 z) 760 = (v_772_0 z) := w_772_0 z
 #a r_773_0
 theorem r_773_1 (z : Store) : (s_773 z) 757 = (v_489_0 z) := pR (k_772 z) (pR (n_768_772 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (n_492_496 z) (pR (k_491 z) (pR (k_490 z) (r_490_0 z)))))))
 #a r_773_1
 def v_773_0 (z : Store) : Tensor := (v_772_0 z)
 def s_774 (z : Store) : Store := storeSet (s_773 z) [(758, ((s_773 z) 760))]
 theorem t_773 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_648) (pmPeers pmNode_648) (s_773 z) pmNode_648 none = some (s_774 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_773
 theorem k_773 (z : Store) (tid : Tid) (h : tid ∉ [758]) : (s_774 z) tid = (s_773 z) tid := by
   unfold s_774
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_773
 theorem w_773_0 (z : Store) : (s_774 z) 758 = v_773_0 z := by
   unfold s_774
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_773_0, r_773_0 z, r_773_1 z] <;> rfl
 #a w_773_0
 theorem h_773_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_773_0 z).shape = [1, 8, 4, 16] := by
   unfold v_773_0
   exact h_772_0 z z_
 #a h_773_0
 attribute [local irreducible] v_773_0
 attribute [local irreducible] s_774
 theorem r_774_0 (z : Store) : (s_774 z) 758 = (v_773_0 z) := w_773_0 z
 #a r_774_0
 theorem r_774_1 (z : Store) : (s_774 z) 753 = (v_488_0 z) := pR (k_773 z) (pR (k_772 z) (pR (n_768_772 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (n_492_496 z) (pR (k_491 z) (pR (k_490 z) (pR (k_489 z) (r_489_0 z)))))))))
 #a r_774_1
 def v_774_0 (z : Store) : Tensor := transposeAxes 1 2 (v_773_0 z)
 def s_775 (z : Store) : Store := storeSet (s_774 z) [(755, transposeAxes 1 2 ((s_774 z) 758))]
 theorem t_774 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_649) (pmPeers pmNode_649) (s_774 z) pmNode_649 none = some (s_775 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_774
 theorem k_774 (z : Store) (tid : Tid) (h : tid ∉ [755]) : (s_775 z) tid = (s_774 z) tid := by
   unfold s_775
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_774
 theorem w_774_0 (z : Store) : (s_775 z) 755 = v_774_0 z := by
   unfold s_775
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_774_0, r_774_0 z, r_774_1 z] <;> rfl
 #a w_774_0
 theorem h_774_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_774_0 z).shape = [1, 4, 8, 16] := by
   unfold v_774_0
   change listSwapAt _ _ _ = _
   rw [h_773_0 z z_]
   rfl
 #a h_774_0
 attribute [local irreducible] v_774_0
 attribute [local irreducible] s_775
 theorem r_775_0 (z : Store) : (s_775 z) 755 = (v_774_0 z) := w_774_0 z
 #a r_775_0
 theorem r_775_1 (z : Store) : (s_775 z) 752 = (v_487_0 z) := pR (k_774 z) (pR (k_773 z) (pR (k_772 z) (pR (n_768_772 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (n_488_496 z) (r_488_0 z)))))))
 #a r_775_1
 theorem r_775_2 (z : Store) : (s_775 z) 684 = (v_484_0 z) := pR (k_774 z) (pR (k_773 z) (pR (k_772 z) (pR (n_768_772 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (n_488_496 z) (r_488_1 z)))))))
 #a r_775_2
 def v_775_0 (z : Store) : Tensor := (batchedMatmulBwd (v_774_0 z) (v_487_0 z) (v_484_0 z)).1
 def v_775_1 (z : Store) : Tensor := (batchedMatmulBwd (v_774_0 z) (v_487_0 z) (v_484_0 z)).2
 def s_776 (z : Store) : Store := storeSet (s_775 z) [(754, (batchedMatmulBwd ((s_775 z) 755) ((s_775 z) 752) ((s_775 z) 684)).1), (756, (batchedMatmulBwd ((s_775 z) 755) ((s_775 z) 752) ((s_775 z) 684)).2)]
 theorem t_775 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_650) (pmPeers pmNode_650) (s_775 z) pmNode_650 none = some (s_776 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_775
 theorem k_775 (z : Store) (tid : Tid) (h : tid ∉ [754, 756]) : (s_776 z) tid = (s_775 z) tid := by
   unfold s_776
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_775
 theorem w_775_0 (z : Store) : (s_776 z) 754 = v_775_0 z := by
   unfold s_776
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_775_0, r_775_0 z, r_775_1 z, r_775_2 z] <;> rfl
 #a w_775_0
 theorem h_775_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_775_0 z).shape = [1, 4, 8, 16] := by
   unfold v_775_0
   change (batchedMatmul (v_774_0 z) (transpose2d (v_484_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_774_0 z z_, h_484_0 z z_]
   rfl
 #a h_775_0
 attribute [local irreducible] v_775_0
 theorem w_775_1 (z : Store) : (s_776 z) 756 = v_775_1 z := by
   unfold s_776
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_775_1, r_775_0 z, r_775_1 z, r_775_2 z] <;> rfl
 #a w_775_1
 theorem h_775_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_775_1 z).shape = [1, 4, 16, 16] := by
   unfold v_775_1
   change (batchedMatmul (transpose2d (v_487_0 z)) (v_774_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_774_0 z z_, h_487_0 z z_]
   rfl
 #a h_775_1
 attribute [local irreducible] v_775_1
 attribute [local irreducible] s_776
 theorem n_772_776 (z : Store) (tid : Tid) (h : tid ∉ ([760, 758, 755, 754, 756] : List Tid)) : (s_776 z) tid = (s_772 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_772 z) (k_773 z)) (pF _ _ _ _ _ (k_774 z) (k_775 z)) tid h
 #a n_772_776
 theorem r_776_0 (z : Store) : (s_776 z) 763 = (v_769_0 z) := pR (n_772_776 z) (r_772_0 z)
 #a r_776_0
 theorem r_776_1 (z : Store) : (s_776 z) 1066 = (v_771_0 z) := pR (n_772_776 z) (r_772_1 z)
 #a r_776_1
 def v_776_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_769_0 z), (v_771_0 z)]
 theorem g_776 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_883) (s_776 z) pmNode_883 2 1 1063 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_883, r_776_0 z, r_776_1 z, h_769_0 z z_, h_771_0 z z_]
 #a g_776
 def s_777 (z : Store) : Store := pL [2, 3] (s_776 z) pmNode_883 2 1
 theorem t_776 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_883) (pmPeers pmNode_883) (s_776 z) pmNode_883 none = some (s_777 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_883) (s_776 z) pmNode_883).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1063 (by decide) (g_776 z z_)]
   rfl
 #a t_776
 theorem k_776 (z : Store) (tid : Tid) (h : tid ∉ [1063]) : (s_777 z) tid = (s_776 z) tid := by
   unfold s_777
   dsimp only [pL, pmNode_883, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_776
 theorem w_776_0 (z : Store) : (s_777 z) 1063 = v_776_0 z := by
   unfold s_777
   dsimp only [pL, pmNode_883, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_776_0, r_776_0 z, r_776_1 z] <;> rfl
 #a w_776_0
 theorem h_776_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_776_0 z).shape = [1, 8, 4, 16] := by
   unfold v_776_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_769_0 z z_]
 #a h_776_0
 attribute [local irreducible] v_776_0
 attribute [local irreducible] s_777
 theorem n_768_776 (z : Store) (tid : Tid) (h : tid ∉ ([764, 763, 1067, 1066, 760, 758, 755, 754, 756] : List Tid)) : (s_776 z) tid = (s_768 z) tid := by
   exact pF _ _ _ _ _ (n_768_772 z) (n_772_776 z) tid h
 #a n_768_776
 theorem r_777_0 (z : Store) : (s_777 z) 1063 = (v_776_0 z) := w_776_0 z
 #a r_777_0
 theorem r_777_1 (z : Store) : (s_777 z) 1060 = (v_494_0 z) := pR (k_776 z) (pR (n_768_776 z) (pR (n_512_768 z) (pR (n_496_512 z) (pR (k_495 z) (r_495_0 z)))))
 #a r_777_1
 def v_777_0 (z : Store) : Tensor := (v_776_0 z)
 def s_778 (z : Store) : Store := storeSet (s_777 z) [(1061, ((s_777 z) 1063))]
 theorem t_777 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_884) (pmPeers pmNode_884) (s_777 z) pmNode_884 none = some (s_778 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_777
 theorem k_777 (z : Store) (tid : Tid) (h : tid ∉ [1061]) : (s_778 z) tid = (s_777 z) tid := by
   unfold s_778
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_777
 theorem w_777_0 (z : Store) : (s_778 z) 1061 = v_777_0 z := by
   unfold s_778
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_777_0, r_777_0 z, r_777_1 z] <;> rfl
 #a w_777_0
 theorem h_777_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_777_0 z).shape = [1, 8, 4, 16] := by
   unfold v_777_0
   exact h_776_0 z z_
 #a h_777_0
 attribute [local irreducible] v_777_0
 attribute [local irreducible] s_778
 record_prefix_opacity v_770_0 s_771 v_771_0 s_772 v_772_0 s_773 v_773_0 s_774 v_774_0 s_775 v_775_0 v_775_1 s_776 v_776_0 s_777 v_777_0 s_778

 end
 end TrainVerify.Denote.RuntimeWorld
