import FreshScoreMatmul
import denote.SourceRank4Exchange
-- UNCOMPILED: parent owns imports, predecessors, frame, aggregate costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierScoreExchangeRead_pm_228 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 228 = AllToAllSourceFaithful.tensor 2 0 1 3 (([225, 528] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 152) (pmInputRequests.drop 153) pmNode_76 0 [0, 1] [225, 528] 228 1 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 152 ++ pmInputRequests.drop 152 := (List.take_append_drop 152 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([225, 528] : List Tid), ∀ row ∈ pmInputRequests.drop 152, tid ∉ row.1.outs
    decide
#print axioms frontierScoreExchangeRead_pm_228
theorem frontierScoreExchangeRead_pm_531 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 531 = AllToAllSourceFaithful.tensor 2 1 1 3 (([225, 528] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 154) (pmInputRequests.drop 155) pmNode_312 1 [0, 1] [225, 528] 531 1 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 154 ++ pmInputRequests.drop 154 := (List.take_append_drop 154 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([225, 528] : List Tid), ∀ row ∈ pmInputRequests.drop 154, tid ∉ row.1.outs
    decide
#print axioms frontierScoreExchangeRead_pm_531
theorem frontierScoreExchangeUnitFacts_1304_0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1304).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 228, q 531], y.shape = [1, 4, 16, 8]) ∧
    chunkPrimDimN 0 2 0 (t 1304) = allGatherPrimDimN 3 2 0 [q 228, q 531] := by
  have predecessor := frontierScoreMatmulUnitFacts_1304_0 s p t q hs hp hvalues
  have outputs : [q 228, q 531] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 1 3 [q 225, q 528]) := by
    change [q 228, q 531] = [AllToAllSourceFaithful.tensor 2 0 1 3 [q 225, q 528], AllToAllSourceFaithful.tensor 2 1 1 3 [q 225, q 528]]
    exact congrArg₂ List.cons (frontierScoreExchangeRead_pm_228 p q hp) (congrArg₂ List.cons (frontierScoreExchangeRead_pm_531 p q hp) (rfl))
  exact SourceRank4Exchange.axis1_output_facts 2 0 2 1 2 16 8 (t 1304) [q 225, q 528] [q 228, q 531]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierScoreExchangeUnitFacts_1304_0
theorem frontierScoreExchangeRead_pm_834 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 834 = AllToAllSourceFaithful.tensor 2 0 1 3 (([831, 1134] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 574) (pmInputRequests.drop 575) pmNode_548 2 [2, 3] [831, 1134] 834 1 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 574 ++ pmInputRequests.drop 574 := (List.take_append_drop 574 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([831, 1134] : List Tid), ∀ row ∈ pmInputRequests.drop 574, tid ∉ row.1.outs
    decide
#print axioms frontierScoreExchangeRead_pm_834
theorem frontierScoreExchangeRead_pm_1137 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1137 = AllToAllSourceFaithful.tensor 2 1 1 3 (([831, 1134] : List Tid).map t) := by
  apply SourcePrimitiveRead.allToAll_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 576) (pmInputRequests.drop 577) pmNode_784 3 [2, 3] [831, 1134] 1137 1 3 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 576 ++ pmInputRequests.drop 576 := (List.take_append_drop 576 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([831, 1134] : List Tid), ∀ row ∈ pmInputRequests.drop 576, tid ∉ row.1.outs
    decide
#print axioms frontierScoreExchangeRead_pm_1137
theorem frontierScoreExchangeUnitFacts_1304_1 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1304).shape = [2, 4, 16, 16] ∧
    (∀ y ∈ [q 834, q 1137], y.shape = [1, 4, 16, 8]) ∧
    chunkPrimDimN 0 2 1 (t 1304) = allGatherPrimDimN 3 2 0 [q 834, q 1137] := by
  have predecessor := frontierScoreMatmulUnitFacts_1304_1 s p t q hs hp hvalues
  have outputs : [q 834, q 1137] = List.ofFn (fun dst : Fin 2 => AllToAllSourceFaithful.tensor 2 dst.val 1 3 [q 831, q 1134]) := by
    change [q 834, q 1137] = [AllToAllSourceFaithful.tensor 2 0 1 3 [q 831, q 1134], AllToAllSourceFaithful.tensor 2 1 1 3 [q 831, q 1134]]
    exact congrArg₂ List.cons (frontierScoreExchangeRead_pm_834 p q hp) (congrArg₂ List.cons (frontierScoreExchangeRead_pm_1137 p q hp) (rfl))
  exact SourceRank4Exchange.axis1_output_facts 2 1 2 1 2 16 8 (t 1304) [q 831, q 1134] [q 834, q 1137]
    (by decide) (by decide) (by decide) (by decide) (by decide) rfl predecessor.2.1 predecessor.1 predecessor.2.2 outputs
#print axioms frontierScoreExchangeUnitFacts_1304_1
end
end TrainVerify.Denote.RuntimeWorld
