import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0014
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_104_0 (z : Store) : (s_104 z) 291 = (v_100_0 z) := pR (k_103 z) (pR (k_102 z) (pR (k_101 z) (w_100_0 z)))
 #a r_104_0
 theorem r_104_1 (z : Store) : (s_104 z) 594 = (v_103_0 z) := w_103_0 z
 #a r_104_1
 def v_104_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_100_0 z), (v_103_0 z)]
 theorem g_104 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_52) (s_104 z) pmNode_52 2 1 185 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_52, r_104_0 z, r_104_1 z, h_100_0 z z_, h_103_0 z z_]
 #a g_104
 def s_105 (z : Store) : Store := pL [0, 1] (s_104 z) pmNode_52 2 1
 theorem t_104 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_52) (pmPeers pmNode_52) (s_104 z) pmNode_52 none = some (s_105 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_52) (s_104 z) pmNode_52).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 185 (by decide) (g_104 z z_)]
   rfl
 #a t_104
 theorem k_104 (z : Store) (tid : Tid) (h : tid ∉ [185]) : (s_105 z) tid = (s_104 z) tid := by
   unfold s_105
   dsimp only [pL, pmNode_52, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_104
 theorem w_104_0 (z : Store) : (s_105 z) 185 = v_104_0 z := by
   unfold s_105
   dsimp only [pL, pmNode_52, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_104_0, r_104_0 z, r_104_1 z] <;> rfl
 #a w_104_0
 theorem h_104_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_104_0 z).shape = [1, 8, 64] := by
   unfold v_104_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_100_0 z z_]
 #a h_104_0
 attribute [local irreducible] v_104_0
 attribute [local irreducible] s_105
 theorem n_100_104 (z : Store) (tid : Tid) (h : tid ∉ ([291, 252, 483, 484, 594, 555] : List Tid)) : (s_104 z) tid = (s_100 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_100 z) (k_101 z)) (pF _ _ _ _ _ (k_102 z) (k_103 z)) tid h
 #a n_100_104
 theorem n_96_104 (z : Store) (tid : Tid) (h : tid ∉ ([478, 480, 180, 181, 291, 252, 483, 484, 594, 555] : List Tid)) : (s_104 z) tid = (s_96 z) tid := by
   exact pF _ _ _ _ _ (n_96_100 z) (n_100_104 z) tid h
 #a n_96_104
 theorem r_105_0 (z : Store) : (s_105 z) 185 = (v_104_0 z) := w_104_0 z
 #a r_105_0
 theorem r_105_1 (z : Store) : (s_105 z) 9 = (z 9) := pR (k_104 z) (pR (n_96_104 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_24 z))))
 #a r_105_1
 theorem r_105_2 (z : Store) : (s_105 z) 10 = (z 10) := pR (k_104 z) (pR (n_96_104 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_25 z))))
 #a r_105_2
 def v_105_0 (z : Store) : Tensor := fw_layernorm (v_104_0 z) (z 9) (z 10)
 def s_106 (z : Store) : Store := storeSet (s_105 z) [(186, fw_layernorm ((s_105 z) 185) ((s_105 z) 9) ((s_105 z) 10))]
 theorem t_105 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_53) (pmPeers pmNode_53) (s_105 z) pmNode_53 none = some (s_106 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_105
 theorem k_105 (z : Store) (tid : Tid) (h : tid ∉ [186]) : (s_106 z) tid = (s_105 z) tid := by
   unfold s_106
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_105
 theorem w_105_0 (z : Store) : (s_106 z) 186 = v_105_0 z := by
   unfold s_106
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_105_0, r_105_0 z, r_105_1 z, r_105_2 z] <;> rfl
 #a w_105_0
 theorem h_105_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_105_0 z).shape = [1, 8, 64] := by
   unfold v_105_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_104_0 z z_
 #a h_105_0
 attribute [local irreducible] v_105_0
 attribute [local irreducible] s_106
 theorem r_106_0 (z : Store) : (s_106 z) 186 = (v_105_0 z) := w_105_0 z
 #a r_106_0
 def v_106_0 (z : Store) : Tensor := (v_105_0 z)
 def v_106_1 (z : Store) : Tensor := (v_105_0 z)
 def v_106_2 (z : Store) : Tensor := (v_105_0 z)
 def s_107 (z : Store) : Store := storeSet (s_106 z) [(293, ((s_106 z) 186)), (295, ((s_106 z) 186)), (297, ((s_106 z) 186))]
 theorem t_106 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_54) (pmPeers pmNode_54) (s_106 z) pmNode_54 none = some (s_107 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_106
 theorem k_106 (z : Store) (tid : Tid) (h : tid ∉ [293, 295, 297]) : (s_107 z) tid = (s_106 z) tid := by
   unfold s_107
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_106
 theorem w_106_0 (z : Store) : (s_107 z) 293 = v_106_0 z := by
   unfold s_107
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_106_0, r_106_0 z] <;> rfl
 #a w_106_0
 theorem h_106_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_106_0 z).shape = [1, 8, 64] := by
   unfold v_106_0
   exact h_105_0 z z_
 #a h_106_0
 attribute [local irreducible] v_106_0
 theorem w_106_1 (z : Store) : (s_107 z) 295 = v_106_1 z := by
   unfold s_107
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_106_1, r_106_0 z] <;> rfl
 #a w_106_1
 theorem h_106_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_106_1 z).shape = [1, 8, 64] := by
   unfold v_106_1
   exact h_105_0 z z_
 #a h_106_1
 attribute [local irreducible] v_106_1
 theorem w_106_2 (z : Store) : (s_107 z) 297 = v_106_2 z := by
   unfold s_107
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_106_2, r_106_0 z] <;> rfl
 #a w_106_2
 theorem h_106_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_106_2 z).shape = [1, 8, 64] := by
   unfold v_106_2
   exact h_105_0 z z_
 #a h_106_2
 attribute [local irreducible] v_106_2
 attribute [local irreducible] s_107
 theorem r_107_0 (z : Store) : (s_107 z) 291 = (v_100_0 z) := pR (k_106 z) (pR (k_105 z) (pR (k_104 z) (r_104_0 z)))
 #a r_107_0
 theorem r_107_1 (z : Store) : (s_107 z) 594 = (v_103_0 z) := pR (k_106 z) (pR (k_105 z) (pR (k_104 z) (r_104_1 z)))
 #a r_107_1
 def v_107_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_100_0 z), (v_103_0 z)]
 theorem g_107 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_288) (s_107 z) pmNode_288 2 1 488 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_288, r_107_0 z, r_107_1 z, h_100_0 z z_, h_103_0 z z_]
 #a g_107
 def s_108 (z : Store) : Store := pL [0, 1] (s_107 z) pmNode_288 2 1
 theorem t_107 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_288) (pmPeers pmNode_288) (s_107 z) pmNode_288 none = some (s_108 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_288) (s_107 z) pmNode_288).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 488 (by decide) (g_107 z z_)]
   rfl
 #a t_107
 theorem k_107 (z : Store) (tid : Tid) (h : tid ∉ [488]) : (s_108 z) tid = (s_107 z) tid := by
   unfold s_108
   dsimp only [pL, pmNode_288, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_107
 theorem w_107_0 (z : Store) : (s_108 z) 488 = v_107_0 z := by
   unfold s_108
   dsimp only [pL, pmNode_288, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_107_0, r_107_0 z, r_107_1 z] <;> rfl
 #a w_107_0
 theorem h_107_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_107_0 z).shape = [1, 8, 64] := by
   unfold v_107_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_100_0 z z_]
 #a h_107_0
 attribute [local irreducible] v_107_0
 attribute [local irreducible] s_108
 theorem n_104_108 (z : Store) (tid : Tid) (h : tid ∉ ([185, 186, 293, 295, 297, 488] : List Tid)) : (s_108 z) tid = (s_104 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_104 z) (k_105 z)) (pF _ _ _ _ _ (k_106 z) (k_107 z)) tid h
 #a n_104_108
 theorem r_108_0 (z : Store) : (s_108 z) 488 = (v_107_0 z) := w_107_0 z
 #a r_108_0
 theorem r_108_1 (z : Store) : (s_108 z) 312 = (z 312) := pR (n_104_108 z) (pR (n_96_104 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_26 z))))
 #a r_108_1
 theorem r_108_2 (z : Store) : (s_108 z) 313 = (z 313) := pR (n_104_108 z) (pR (n_96_104 z) (pR (n_64_96 z) (pR (n_0_64 z) (e_27 z))))
 #a r_108_2
 def v_108_0 (z : Store) : Tensor := fw_layernorm (v_107_0 z) (z 312) (z 313)
 def s_109 (z : Store) : Store := storeSet (s_108 z) [(489, fw_layernorm ((s_108 z) 488) ((s_108 z) 312) ((s_108 z) 313))]
 theorem t_108 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_289) (pmPeers pmNode_289) (s_108 z) pmNode_289 none = some (s_109 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_108
 theorem k_108 (z : Store) (tid : Tid) (h : tid ∉ [489]) : (s_109 z) tid = (s_108 z) tid := by
   unfold s_109
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_108
 theorem w_108_0 (z : Store) : (s_109 z) 489 = v_108_0 z := by
   unfold s_109
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_108_0, r_108_0 z, r_108_1 z, r_108_2 z] <;> rfl
 #a w_108_0
 theorem h_108_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_108_0 z).shape = [1, 8, 64] := by
   unfold v_108_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_107_0 z z_
 #a h_108_0
 attribute [local irreducible] v_108_0
 attribute [local irreducible] s_109
 theorem r_109_0 (z : Store) : (s_109 z) 489 = (v_108_0 z) := w_108_0 z
 #a r_109_0
 def v_109_0 (z : Store) : Tensor := (v_108_0 z)
 def v_109_1 (z : Store) : Tensor := (v_108_0 z)
 def v_109_2 (z : Store) : Tensor := (v_108_0 z)
 def s_110 (z : Store) : Store := storeSet (s_109 z) [(596, ((s_109 z) 489)), (598, ((s_109 z) 489)), (600, ((s_109 z) 489))]
 theorem t_109 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_290) (pmPeers pmNode_290) (s_109 z) pmNode_290 none = some (s_110 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_109
 theorem k_109 (z : Store) (tid : Tid) (h : tid ∉ [596, 598, 600]) : (s_110 z) tid = (s_109 z) tid := by
   unfold s_110
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_109
 theorem w_109_0 (z : Store) : (s_110 z) 596 = v_109_0 z := by
   unfold s_110
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_109_0, r_109_0 z] <;> rfl
 #a w_109_0
 theorem h_109_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_109_0 z).shape = [1, 8, 64] := by
   unfold v_109_0
   exact h_108_0 z z_
 #a h_109_0
 attribute [local irreducible] v_109_0
 theorem w_109_1 (z : Store) : (s_110 z) 598 = v_109_1 z := by
   unfold s_110
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_109_1, r_109_0 z] <;> rfl
 #a w_109_1
 theorem h_109_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_109_1 z).shape = [1, 8, 64] := by
   unfold v_109_1
   exact h_108_0 z z_
 #a h_109_1
 attribute [local irreducible] v_109_1
 theorem w_109_2 (z : Store) : (s_110 z) 600 = v_109_2 z := by
   unfold s_110
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_109_2, r_109_0 z] <;> rfl
 #a w_109_2
 theorem h_109_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_109_2 z).shape = [1, 8, 64] := by
   unfold v_109_2
   exact h_108_0 z z_
 #a h_109_2
 attribute [local irreducible] v_109_2
 attribute [local irreducible] s_110
 theorem r_110_0 (z : Store) : (s_110 z) 293 = (v_106_0 z) := pR (k_109 z) (pR (k_108 z) (pR (k_107 z) (w_106_0 z)))
 #a r_110_0
 theorem r_110_1 (z : Store) : (s_110 z) 596 = (v_109_0 z) := w_109_0 z
 #a r_110_1
 def v_110_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 0 [(v_106_0 z), (v_109_0 z)]
 def s_111 (z : Store) : Store := storeSet (s_110 z) [(88, allGatherPrimDimN 1 2 0 [((s_110 z) 293), ((s_110 z) 596)])]
 theorem t_110 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_55) (pmPeers pmNode_55) (s_110 z) pmNode_55 none = some (s_111 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_110 z) pmNode_55 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_110
 theorem k_110 (z : Store) (tid : Tid) (h : tid ∉ [88]) : (s_111 z) tid = (s_110 z) tid := by
   unfold s_111
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_110
 theorem w_110_0 (z : Store) : (s_111 z) 88 = v_110_0 z := by
   unfold s_111
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_110_0, r_110_0 z, r_110_1 z] <;> rfl
 #a w_110_0
 theorem h_110_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_110_0 z).shape = [1, 16, 64] := by
   unfold v_110_0
   exact allGatherPrimDimN_shape 1 2 [(v_106_0 z), (v_109_0 z)] [1, 8, 64] (h_106_0 z z_)
 #a h_110_0
 attribute [local irreducible] v_110_0
 attribute [local irreducible] s_111
 record_prefix_opacity v_104_0 s_105 v_105_0 s_106 v_106_0 v_106_1 v_106_2 s_107 v_107_0 s_108 v_108_0 s_109 v_109_0 v_109_1 v_109_2 s_110 v_110_0 s_111

 end
 end TrainVerify.Denote.RuntimeWorld
