import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0003
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_10_0 (z : Store) : (s_10 z) 95 = (v_9_0 z) := w_9_0 z
 #a r_10_0
 def v_10_0 (z : Store) : Tensor := (v_9_0 z)
 def v_10_1 (z : Store) : Tensor := (v_9_0 z)
 def s_11 (z : Store) : Store := storeSet (s_10 z) [(283, ((s_10 z) 95)), (163, ((s_10 z) 95))]
 theorem t_10 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_6) (pmPeers pmNode_6) (s_10 z) pmNode_6 none = some (s_11 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_10
 theorem k_10 (z : Store) (tid : Tid) (h : tid ∉ [283, 163]) : (s_11 z) tid = (s_10 z) tid := by
   unfold s_11
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_10
 theorem w_10_0 (z : Store) : (s_11 z) 283 = v_10_0 z := by
   unfold s_11
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_10_0, r_10_0 z] <;> rfl
 #a w_10_0
 theorem h_10_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_10_0 z).shape = [1, 16, 32] := by
   unfold v_10_0
   exact h_9_0 z z_
 #a h_10_0
 attribute [local irreducible] v_10_0
 theorem w_10_1 (z : Store) : (s_11 z) 163 = v_10_1 z := by
   unfold s_11
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_10_1, r_10_0 z] <;> rfl
 #a w_10_1
 theorem h_10_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_10_1 z).shape = [1, 16, 32] := by
   unfold v_10_1
   exact h_9_0 z z_
 #a h_10_1
 attribute [local irreducible] v_10_1
 attribute [local irreducible] s_11
 theorem r_11_0 (z : Store) : (s_11 z) 92 = (v_3_0 z) := pR (k_10 z) (pR (k_9 z) (pR (k_8 z) (r_8_0 z)))
 #a r_11_0
 theorem r_11_1 (z : Store) : (s_11 z) 395 = (v_7_0 z) := pR (k_10 z) (pR (k_9 z) (pR (k_8 z) (r_8_1 z)))
 #a r_11_1
 def v_11_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_3_0 z), (v_7_0 z)]
 theorem g_11 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_240) (s_11 z) pmNode_240 1 2 397 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_240, r_11_0 z, r_11_1 z, h_3_0 z z_, h_7_0 z z_]
 #a g_11
 def s_12 (z : Store) : Store := pL [0, 1] (s_11 z) pmNode_240 1 2
 theorem t_11 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_240) (pmPeers pmNode_240) (s_11 z) pmNode_240 none = some (s_12 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_240) (s_11 z) pmNode_240).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 397 (by decide) (g_11 z z_)]
   rfl
 #a t_11
 theorem k_11 (z : Store) (tid : Tid) (h : tid ∉ [397]) : (s_12 z) tid = (s_11 z) tid := by
   unfold s_12
   dsimp only [pL, pmNode_240, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_11
 theorem w_11_0 (z : Store) : (s_12 z) 397 = v_11_0 z := by
   unfold s_12
   dsimp only [pL, pmNode_240, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_11_0, r_11_0 z, r_11_1 z] <;> rfl
 #a w_11_0
 theorem h_11_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_11_0 z).shape = [1, 16, 32] := by
   unfold v_11_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_3_0 z z_]
 #a h_11_0
 attribute [local irreducible] v_11_0
 attribute [local irreducible] s_12
 theorem n_8_12 (z : Store) (tid : Tid) (h : tid ∉ ([94, 95, 283, 163, 397] : List Tid)) : (s_12 z) tid = (s_8 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_8 z) (k_9 z)) (pF _ _ _ _ _ (k_10 z) (k_11 z)) tid h
 #a n_8_12
 theorem r_12_0 (z : Store) : (s_12 z) 392 = (v_5_0 z) := pR (n_8_12 z) (pR (k_7 z) (pR (k_6 z) (w_5_0 z)))
 #a r_12_0
 theorem r_12_1 (z : Store) : (s_12 z) 397 = (v_11_0 z) := w_11_0 z
 #a r_12_1
 def v_12_0 (z : Store) : Tensor := elemwiseAdd (v_5_0 z) (v_11_0 z)
 def s_13 (z : Store) : Store := storeSet (s_12 z) [(398, elemwiseAdd ((s_12 z) 392) ((s_12 z) 397))]
 theorem t_12 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_241) (pmPeers pmNode_241) (s_12 z) pmNode_241 none = some (s_13 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_12
 theorem k_12 (z : Store) (tid : Tid) (h : tid ∉ [398]) : (s_13 z) tid = (s_12 z) tid := by
   unfold s_13
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_12
 theorem w_12_0 (z : Store) : (s_13 z) 398 = v_12_0 z := by
   unfold s_13
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_12_0, r_12_0 z, r_12_1 z] <;> rfl
 #a w_12_0
 theorem h_12_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_12_0 z).shape = [1, 16, 32] := by
   unfold v_12_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_5_0 z z_, h_11_0 z z_]
 #a h_12_0
 attribute [local irreducible] v_12_0
 attribute [local irreducible] s_13
 theorem r_13_0 (z : Store) : (s_13 z) 398 = (v_12_0 z) := w_12_0 z
 #a r_13_0
 def v_13_0 (z : Store) : Tensor := (v_12_0 z)
 def v_13_1 (z : Store) : Tensor := (v_12_0 z)
 def s_14 (z : Store) : Store := storeSet (s_13 z) [(586, ((s_13 z) 398)), (466, ((s_13 z) 398))]
 theorem t_13 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_242) (pmPeers pmNode_242) (s_13 z) pmNode_242 none = some (s_14 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_13
 theorem k_13 (z : Store) (tid : Tid) (h : tid ∉ [586, 466]) : (s_14 z) tid = (s_13 z) tid := by
   unfold s_14
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_13
 theorem w_13_0 (z : Store) : (s_14 z) 586 = v_13_0 z := by
   unfold s_14
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_13_0, r_13_0 z] <;> rfl
 #a w_13_0
 theorem h_13_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_13_0 z).shape = [1, 16, 32] := by
   unfold v_13_0
   exact h_12_0 z z_
 #a h_13_0
 attribute [local irreducible] v_13_0
 theorem w_13_1 (z : Store) : (s_14 z) 466 = v_13_1 z := by
   unfold s_14
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_13_1, r_13_0 z] <;> rfl
 #a w_13_1
 theorem h_13_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_13_1 z).shape = [1, 16, 32] := by
   unfold v_13_1
   exact h_12_0 z z_
 #a h_13_1
 attribute [local irreducible] v_13_1
 attribute [local irreducible] s_14
 theorem r_14_0 (z : Store) : (s_14 z) 283 = (v_10_0 z) := pR (k_13 z) (pR (k_12 z) (pR (k_11 z) (w_10_0 z)))
 #a r_14_0
 theorem r_14_1 (z : Store) : (s_14 z) 586 = (v_13_0 z) := w_13_0 z
 #a r_14_1
 def v_14_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_10_0 z), (v_13_0 z)]
 theorem g_14 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_7) (s_14 z) pmNode_7 2 1 98 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_7, r_14_0 z, r_14_1 z, h_10_0 z z_, h_13_0 z z_]
 #a g_14
 def s_15 (z : Store) : Store := pL [0, 1] (s_14 z) pmNode_7 2 1
 theorem t_14 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_7) (pmPeers pmNode_7) (s_14 z) pmNode_7 none = some (s_15 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_7) (s_14 z) pmNode_7).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 98 (by decide) (g_14 z z_)]
   rfl
 #a t_14
 theorem k_14 (z : Store) (tid : Tid) (h : tid ∉ [98]) : (s_15 z) tid = (s_14 z) tid := by
   unfold s_15
   dsimp only [pL, pmNode_7, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_14
 theorem w_14_0 (z : Store) : (s_15 z) 98 = v_14_0 z := by
   unfold s_15
   dsimp only [pL, pmNode_7, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_14_0, r_14_0 z, r_14_1 z] <;> rfl
 #a w_14_0
 theorem h_14_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_14_0 z).shape = [1, 8, 64] := by
   unfold v_14_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_10_0 z z_]
 #a h_14_0
 attribute [local irreducible] v_14_0
 attribute [local irreducible] s_15
 theorem n_0_8 (z : Store) (tid : Tid) (h : tid ∉ ([75, 76, 89, 91, 92, 378, 379, 392, 394, 395] : List Tid)) : (s_8 z) tid = (s_0 z) tid := by
   exact pF _ _ _ _ _ (n_0_4 z) (n_4_8 z) tid h
 #a n_0_8
 theorem r_15_0 (z : Store) : (s_15 z) 98 = (v_14_0 z) := w_14_0 z
 #a r_15_0
 theorem r_15_1 (z : Store) : (s_15 z) 1 = (z 1) := pR (k_14 z) (pR (k_13 z) (pR (k_12 z) (pR (n_8_12 z) (pR (n_0_8 z) (e_4 z)))))
 #a r_15_1
 theorem r_15_2 (z : Store) : (s_15 z) 2 = (z 2) := pR (k_14 z) (pR (k_13 z) (pR (k_12 z) (pR (n_8_12 z) (pR (n_0_8 z) (e_5 z)))))
 #a r_15_2
 def v_15_0 (z : Store) : Tensor := fw_layernorm (v_14_0 z) (z 1) (z 2)
 def s_16 (z : Store) : Store := storeSet (s_15 z) [(99, fw_layernorm ((s_15 z) 98) ((s_15 z) 1) ((s_15 z) 2))]
 theorem t_15 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_8) (pmPeers pmNode_8) (s_15 z) pmNode_8 none = some (s_16 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_15
 theorem k_15 (z : Store) (tid : Tid) (h : tid ∉ [99]) : (s_16 z) tid = (s_15 z) tid := by
   unfold s_16
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_15
 theorem w_15_0 (z : Store) : (s_16 z) 99 = v_15_0 z := by
   unfold s_16
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_15_0, r_15_0 z, r_15_1 z, r_15_2 z] <;> rfl
 #a w_15_0
 theorem h_15_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_15_0 z).shape = [1, 8, 64] := by
   unfold v_15_0
   rw [SourceScopedPrefix.layernorm_shape]
   exact h_14_0 z z_
 #a h_15_0
 attribute [local irreducible] v_15_0
 attribute [local irreducible] s_16
 theorem r_16_0 (z : Store) : (s_16 z) 99 = (v_15_0 z) := w_15_0 z
 #a r_16_0
 def v_16_0 (z : Store) : Tensor := (v_15_0 z)
 def v_16_1 (z : Store) : Tensor := (v_15_0 z)
 def v_16_2 (z : Store) : Tensor := (v_15_0 z)
 def s_17 (z : Store) : Store := storeSet (s_16 z) [(102, ((s_16 z) 99)), (285, ((s_16 z) 99)), (287, ((s_16 z) 99))]
 theorem t_16 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_9) (pmPeers pmNode_9) (s_16 z) pmNode_9 none = some (s_17 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_16
 theorem k_16 (z : Store) (tid : Tid) (h : tid ∉ [102, 285, 287]) : (s_17 z) tid = (s_16 z) tid := by
   unfold s_17
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_16
 theorem w_16_0 (z : Store) : (s_17 z) 102 = v_16_0 z := by
   unfold s_17
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_16_0, r_16_0 z] <;> rfl
 #a w_16_0
 theorem h_16_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_16_0 z).shape = [1, 8, 64] := by
   unfold v_16_0
   exact h_15_0 z z_
 #a h_16_0
 attribute [local irreducible] v_16_0
 theorem w_16_1 (z : Store) : (s_17 z) 285 = v_16_1 z := by
   unfold s_17
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_16_1, r_16_0 z] <;> rfl
 #a w_16_1
 theorem h_16_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_16_1 z).shape = [1, 8, 64] := by
   unfold v_16_1
   exact h_15_0 z z_
 #a h_16_1
 attribute [local irreducible] v_16_1
 theorem w_16_2 (z : Store) : (s_17 z) 287 = v_16_2 z := by
   unfold s_17
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_16_2, r_16_0 z] <;> rfl
 #a w_16_2
 theorem h_16_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_16_2 z).shape = [1, 8, 64] := by
   unfold v_16_2
   exact h_15_0 z z_
 #a h_16_2
 attribute [local irreducible] v_16_2
 attribute [local irreducible] s_17
 theorem n_12_16 (z : Store) (tid : Tid) (h : tid ∉ ([398, 586, 466, 98, 99] : List Tid)) : (s_16 z) tid = (s_12 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_12 z) (k_13 z)) (pF _ _ _ _ _ (k_14 z) (k_15 z)) tid h
 #a n_12_16
 theorem n_8_16 (z : Store) (tid : Tid) (h : tid ∉ ([94, 95, 283, 163, 397, 398, 586, 466, 98, 99] : List Tid)) : (s_16 z) tid = (s_8 z) tid := by
   exact pF _ _ _ _ _ (n_8_12 z) (n_12_16 z) tid h
 #a n_8_16
 theorem n_0_16 (z : Store) (tid : Tid) (h : tid ∉ ([75, 76, 89, 91, 92, 378, 379, 392, 394, 395, 94, 95, 283, 163, 397, 398, 586, 466, 98, 99] : List Tid)) : (s_16 z) tid = (s_0 z) tid := by
   exact pF _ _ _ _ _ (n_0_8 z) (n_8_16 z) tid h
 #a n_0_16
 record_prefix_opacity v_10_0 v_10_1 s_11 v_11_0 s_12 v_12_0 s_13 v_13_0 v_13_1 s_14 v_14_0 s_15 v_15_0 s_16 v_16_0 v_16_1 v_16_2 s_17

 end
 end TrainVerify.Denote.RuntimeWorld
