import RuntimeWorld
-- UNCOMPILED: parent owns imports, predecessors, frame, costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierSequenceMultirefRead_sm_1394 (s t : Store) (h : smDenoteWithInputs s = some t) :
    ∀ output ∈ ([1394, 1395, 1396] : List Tid), t output = t 1293 := by
  intro output houtput
  apply SourceMultirefRead.multiref_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 34) (smInputRequests.drop 35) smNode_34
    0 1293 [1394, 1395, 1396] output s t rfl ?_ rfl ?_ houtput h
  · calc
      smInputRequests = smInputRequests.take 34 ++ smInputRequests.drop 34 := (List.take_append_drop 34 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 34, 1293 ∉ row.1.outs
    decide
#print axioms frontierSequenceMultirefRead_sm_1394
theorem frontierSequenceMultirefRead_pm_293 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    ∀ output ∈ ([293, 295, 297] : List Tid), t output = t 186 := by
  intro output houtput
  apply SourceMultirefRead.multiref_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 106) (pmInputRequests.drop 107) pmNode_54
    0 186 [293, 295, 297] output s t rfl ?_ rfl ?_ houtput h
  · calc
      pmInputRequests = pmInputRequests.take 106 ++ pmInputRequests.drop 106 := (List.take_append_drop 106 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 106, 186 ∉ row.1.outs
    decide
#print axioms frontierSequenceMultirefRead_pm_293
theorem frontierSequenceMultirefRead_pm_596 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    ∀ output ∈ ([596, 598, 600] : List Tid), t output = t 489 := by
  intro output houtput
  apply SourceMultirefRead.multiref_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 109) (pmInputRequests.drop 110) pmNode_290
    1 489 [596, 598, 600] output s t rfl ?_ rfl ?_ houtput h
  · calc
      pmInputRequests = pmInputRequests.take 109 ++ pmInputRequests.drop 109 := (List.take_append_drop 109 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 109, 489 ∉ row.1.outs
    decide
#print axioms frontierSequenceMultirefRead_pm_596
theorem frontierSequenceAliasFacts_1394_0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1394).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 293, q 596], y.shape = [1, 8, 64]) ∧
    chunkPrimDimN 0 2 0 (t 1394) = allGatherPrimDimN 1 2 0 [q 293, q 596] := by
  rw [frontierSequenceMultirefRead_sm_1394 s t hs 1394 List.mem_cons_self, frontierSequenceMultirefRead_pm_293 p q hp 293 List.mem_cons_self, frontierSequenceMultirefRead_pm_596 p q hp 596 List.mem_cons_self]
  exact frontierLayernormUnitFacts_1293_0 s p t q hs hp hvalues
#print axioms frontierSequenceAliasFacts_1394_0
theorem frontierSequenceAliasFacts_1395_0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1395).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 295, q 598], y.shape = [1, 8, 64]) ∧
    chunkPrimDimN 0 2 0 (t 1395) = allGatherPrimDimN 1 2 0 [q 295, q 598] := by
  rw [frontierSequenceMultirefRead_sm_1394 s t hs 1395 (List.mem_cons_of_mem _ List.mem_cons_self), frontierSequenceMultirefRead_pm_293 p q hp 295 (List.mem_cons_of_mem _ List.mem_cons_self), frontierSequenceMultirefRead_pm_596 p q hp 598 (List.mem_cons_of_mem _ List.mem_cons_self)]
  exact frontierLayernormUnitFacts_1293_0 s p t q hs hp hvalues
#print axioms frontierSequenceAliasFacts_1395_0
theorem frontierSequenceAliasFacts_1396_0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1396).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 297, q 600], y.shape = [1, 8, 64]) ∧
    chunkPrimDimN 0 2 0 (t 1396) = allGatherPrimDimN 1 2 0 [q 297, q 600] := by
  rw [frontierSequenceMultirefRead_sm_1394 s t hs 1396 (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self)), frontierSequenceMultirefRead_pm_293 p q hp 297 (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self)), frontierSequenceMultirefRead_pm_596 p q hp 600 (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self))]
  exact frontierLayernormUnitFacts_1293_0 s p t q hs hp hvalues
#print axioms frontierSequenceAliasFacts_1396_0
theorem frontierSequenceMultirefRead_pm_899 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    ∀ output ∈ ([899, 901, 903] : List Tid), t output = t 792 := by
  intro output houtput
  apply SourceMultirefRead.multiref_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 528) (pmInputRequests.drop 529) pmNode_526
    2 792 [899, 901, 903] output s t rfl ?_ rfl ?_ houtput h
  · calc
      pmInputRequests = pmInputRequests.take 528 ++ pmInputRequests.drop 528 := (List.take_append_drop 528 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 528, 792 ∉ row.1.outs
    decide
#print axioms frontierSequenceMultirefRead_pm_899
theorem frontierSequenceMultirefRead_pm_1202 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    ∀ output ∈ ([1202, 1204, 1206] : List Tid), t output = t 1095 := by
  intro output houtput
  apply SourceMultirefRead.multiref_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 531) (pmInputRequests.drop 532) pmNode_762
    3 1095 [1202, 1204, 1206] output s t rfl ?_ rfl ?_ houtput h
  · calc
      pmInputRequests = pmInputRequests.take 531 ++ pmInputRequests.drop 531 := (List.take_append_drop 531 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 531, 1095 ∉ row.1.outs
    decide
#print axioms frontierSequenceMultirefRead_pm_1202
theorem frontierSequenceAliasFacts_1394_1 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1394).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 899, q 1202], y.shape = [1, 8, 64]) ∧
    chunkPrimDimN 0 2 1 (t 1394) = allGatherPrimDimN 1 2 0 [q 899, q 1202] := by
  rw [frontierSequenceMultirefRead_sm_1394 s t hs 1394 List.mem_cons_self, frontierSequenceMultirefRead_pm_899 p q hp 899 List.mem_cons_self, frontierSequenceMultirefRead_pm_1202 p q hp 1202 List.mem_cons_self]
  exact frontierLayernormUnitFacts_1293_1 s p t q hs hp hvalues
#print axioms frontierSequenceAliasFacts_1394_1
theorem frontierSequenceAliasFacts_1395_1 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1395).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 901, q 1204], y.shape = [1, 8, 64]) ∧
    chunkPrimDimN 0 2 1 (t 1395) = allGatherPrimDimN 1 2 0 [q 901, q 1204] := by
  rw [frontierSequenceMultirefRead_sm_1394 s t hs 1395 (List.mem_cons_of_mem _ List.mem_cons_self), frontierSequenceMultirefRead_pm_899 p q hp 901 (List.mem_cons_of_mem _ List.mem_cons_self), frontierSequenceMultirefRead_pm_1202 p q hp 1204 (List.mem_cons_of_mem _ List.mem_cons_self)]
  exact frontierLayernormUnitFacts_1293_1 s p t q hs hp hvalues
#print axioms frontierSequenceAliasFacts_1395_1
theorem frontierSequenceAliasFacts_1396_1 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1396).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 903, q 1206], y.shape = [1, 8, 64]) ∧
    chunkPrimDimN 0 2 1 (t 1396) = allGatherPrimDimN 1 2 0 [q 903, q 1206] := by
  rw [frontierSequenceMultirefRead_sm_1394 s t hs 1396 (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self)), frontierSequenceMultirefRead_pm_899 p q hp 903 (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self)), frontierSequenceMultirefRead_pm_1202 p q hp 1206 (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self))]
  exact frontierLayernormUnitFacts_1293_1 s p t q hs hp hvalues
#print axioms frontierSequenceAliasFacts_1396_1
end
end TrainVerify.Denote.RuntimeWorld
