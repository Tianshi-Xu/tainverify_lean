import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0087
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_696_0 (z : Store) : (s_696 z) 836 = (v_691_0 z) := pR (k_695 z) (pR (k_694 z) (r_694_0 z))
 #a r_696_0
 theorem r_696_1 (z : Store) : (s_696 z) 1139 = (v_693_0 z) := pR (k_695 z) (pR (k_694 z) (r_694_1 z))
 #a r_696_1
 def v_696_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 3 1 [(v_691_0 z), (v_693_0 z)]
 theorem g_696 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_844) (s_696 z) pmNode_844 3 1 1136 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 4, 16, 8], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_844, r_696_0 z, r_696_1 z, h_691_0 z z_, h_693_0 z z_]
 #a g_696
 def s_697 (z : Store) : Store := pL [2, 3] (s_696 z) pmNode_844 3 1
 theorem t_696 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_844) (pmPeers pmNode_844) (s_696 z) pmNode_844 none = some (s_697 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_844) (s_696 z) pmNode_844).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 3 1 1136 (by decide) (g_696 z z_)]
   rfl
 #a t_696
 theorem k_696 (z : Store) (tid : Tid) (h : tid ∉ [1136]) : (s_697 z) tid = (s_696 z) tid := by
   unfold s_697
   dsimp only [pL, pmNode_844, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_696
 theorem w_696_0 (z : Store) : (s_697 z) 1136 = v_696_0 z := by
   unfold s_697
   dsimp only [pL, pmNode_844, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_696_0, r_696_0 z, r_696_1 z] <;> rfl
 #a w_696_0
 theorem h_696_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_696_0 z).shape = [1, 2, 16, 16] := by
   unfold v_696_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_691_0 z z_]
 #a h_696_0
 attribute [local irreducible] v_696_0
 attribute [local irreducible] s_697
 theorem n_692_696 (z : Store) (tid : Tid) (h : tid ∉ ([1140, 1139, 833, 811, 832] : List Tid)) : (s_696 z) tid = (s_692 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_692 z) (k_693 z)) (pF _ _ _ _ _ (k_694 z) (k_695 z)) tid h
 #a n_692_696
 theorem n_688_696 (z : Store) (tid : Tid) (h : tid ∉ ([1130, 1143, 837, 836, 1140, 1139, 833, 811, 832] : List Tid)) : (s_696 z) tid = (s_688 z) tid := by
   exact pF _ _ _ _ _ (n_688_692 z) (n_692_696 z) tid h
 #a n_688_696
 theorem r_697_0 (z : Store) : (s_697 z) 1136 = (v_696_0 z) := w_696_0 z
 #a r_697_0
 theorem r_697_1 (z : Store) : (s_697 z) 1112 = (v_553_0 z) := pR (k_696 z) (pR (n_688_696 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_576_640 z) (pR (k_575 z) (pR (k_574 z) (pR (k_573 z) (r_573_0 z))))))))
 #a r_697_1
 theorem r_697_2 (z : Store) : (s_697 z) 1133 = (v_572_0 z) := pR (k_696 z) (pR (n_688_696 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_576_640 z) (pR (k_575 z) (pR (k_574 z) (pR (k_573 z) (r_573_1 z))))))))
 #a r_697_2
 def v_697_0 (z : Store) : Tensor := (batchedMatmulBwd (v_696_0 z) (v_553_0 z) (v_572_0 z)).1
 def v_697_1 (z : Store) : Tensor := (batchedMatmulBwd (v_696_0 z) (v_553_0 z) (v_572_0 z)).2
 def s_698 (z : Store) : Store := storeSet (s_697 z) [(1114, (batchedMatmulBwd ((s_697 z) 1136) ((s_697 z) 1112) ((s_697 z) 1133)).1), (1135, (batchedMatmulBwd ((s_697 z) 1136) ((s_697 z) 1112) ((s_697 z) 1133)).2)]
 theorem t_697 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_845) (pmPeers pmNode_845) (s_697 z) pmNode_845 none = some (s_698 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_697
 theorem k_697 (z : Store) (tid : Tid) (h : tid ∉ [1114, 1135]) : (s_698 z) tid = (s_697 z) tid := by
   unfold s_698
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_697
 theorem w_697_0 (z : Store) : (s_698 z) 1114 = v_697_0 z := by
   unfold s_698
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_697_0, r_697_0 z, r_697_1 z, r_697_2 z] <;> rfl
 #a w_697_0
 theorem h_697_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_697_0 z).shape = [1, 2, 16, 16] := by
   unfold v_697_0
   change (batchedMatmul (v_696_0 z) (transpose2d (v_572_0 z))).shape = _
   unfold batchedMatmul transpose2d
   rw [h_696_0 z z_, h_572_0 z z_]
   rfl
 #a h_697_0
 attribute [local irreducible] v_697_0
 theorem w_697_1 (z : Store) : (s_698 z) 1135 = v_697_1 z := by
   unfold s_698
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_697_1, r_697_0 z, r_697_1 z, r_697_2 z] <;> rfl
 #a w_697_1
 theorem h_697_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_697_1 z).shape = [1, 2, 16, 16] := by
   unfold v_697_1
   change (batchedMatmul (transpose2d (v_553_0 z)) (v_696_0 z)).shape = _
   unfold batchedMatmul transpose2d
   rw [h_696_0 z z_, h_553_0 z z_]
   rfl
 #a h_697_1
 attribute [local irreducible] v_697_1
 attribute [local irreducible] s_698
 theorem r_698_0 (z : Store) : (s_698 z) 832 = (v_695_1 z) := pR (k_697 z) (pR (k_696 z) (w_695_1 z))
 #a r_698_0
 theorem r_698_1 (z : Store) : (s_698 z) 1135 = (v_697_1 z) := w_697_1 z
 #a r_698_1
 def v_698_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_695_1 z), (v_697_1 z)]
 theorem g_698 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_610) (s_698 z) pmNode_610 1 2 829 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_610, r_698_0 z, r_698_1 z, h_695_1 z z_, h_697_1 z z_]
 #a g_698
 def s_699 (z : Store) : Store := pL [2, 3] (s_698 z) pmNode_610 1 2
 theorem t_698 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_610) (pmPeers pmNode_610) (s_698 z) pmNode_610 none = some (s_699 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_610) (s_698 z) pmNode_610).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 829 (by decide) (g_698 z z_)]
   rfl
 #a t_698
 theorem k_698 (z : Store) (tid : Tid) (h : tid ∉ [829]) : (s_699 z) tid = (s_698 z) tid := by
   unfold s_699
   dsimp only [pL, pmNode_610, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_698
 theorem w_698_0 (z : Store) : (s_699 z) 829 = v_698_0 z := by
   unfold s_699
   dsimp only [pL, pmNode_610, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_698_0, r_698_0 z, r_698_1 z] <;> rfl
 #a w_698_0
 theorem h_698_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_698_0 z).shape = [1, 4, 8, 16] := by
   unfold v_698_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_695_1 z z_]
 #a h_698_0
 attribute [local irreducible] v_698_0
 attribute [local irreducible] s_699
 theorem r_699_0 (z : Store) : (s_699 z) 829 = (v_698_0 z) := w_698_0 z
 #a r_699_0
 theorem r_699_1 (z : Store) : (s_699 z) 817 = (v_557_0 z) := pR (k_698 z) (pR (k_697 z) (pR (k_696 z) (pR (n_688_696 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_576_640 z) (pR (n_568_576 z) (pR (k_567 z) (pR (k_566 z) (r_566_0 z))))))))))
 #a r_699_1
 def v_699_0 (z : Store) : Tensor := transposeAxes 2 3 (v_698_0 z)
 def s_700 (z : Store) : Store := storeSet (s_699 z) [(819, transposeAxes 2 3 ((s_699 z) 829))]
 theorem t_699 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_611) (pmPeers pmNode_611) (s_699 z) pmNode_611 none = some (s_700 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_699
 theorem k_699 (z : Store) (tid : Tid) (h : tid ∉ [819]) : (s_700 z) tid = (s_699 z) tid := by
   unfold s_700
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_699
 theorem w_699_0 (z : Store) : (s_700 z) 819 = v_699_0 z := by
   unfold s_700
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_699_0, r_699_0 z, r_699_1 z] <;> rfl
 #a w_699_0
 theorem h_699_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_699_0 z).shape = [1, 4, 16, 8] := by
   unfold v_699_0
   change listSwapAt _ _ _ = _
   rw [h_698_0 z z_]
   rfl
 #a h_699_0
 attribute [local irreducible] v_699_0
 attribute [local irreducible] s_700
 theorem n_696_700 (z : Store) (tid : Tid) (h : tid ∉ ([1136, 1114, 1135, 829, 819] : List Tid)) : (s_700 z) tid = (s_696 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_696 z) (k_697 z)) (pF _ _ _ _ _ (k_698 z) (k_699 z)) tid h
 #a n_696_700
 theorem r_700_0 (z : Store) : (s_700 z) 827 = (v_686_0 z) := pR (n_696_700 z) (pR (n_688_696 z) (pR (k_687 z) (w_686_0 z)))
 #a r_700_0
 theorem r_700_1 (z : Store) : (s_700 z) 824 = (v_564_0 z) := pR (n_696_700 z) (pR (n_688_696 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_576_640 z) (pR (n_568_576 z) (pR (k_567 z) (pR (k_566 z) (pR (k_565 z) (r_565_0 z)))))))))
 #a r_700_1
 def v_700_0 (z : Store) : Tensor := transposeAxes 1 2 (v_686_0 z)
 def s_701 (z : Store) : Store := storeSet (s_700 z) [(826, transposeAxes 1 2 ((s_700 z) 827))]
 theorem t_700 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_612) (pmPeers pmNode_612) (s_700 z) pmNode_612 none = some (s_701 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_700
 theorem k_700 (z : Store) (tid : Tid) (h : tid ∉ [826]) : (s_701 z) tid = (s_700 z) tid := by
   unfold s_701
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_700
 theorem w_700_0 (z : Store) : (s_701 z) 826 = v_700_0 z := by
   unfold s_701
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_700_0, r_700_0 z, r_700_1 z] <;> rfl
 #a w_700_0
 theorem h_700_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_700_0 z).shape = [1, 8, 4, 16] := by
   unfold v_700_0
   change listSwapAt _ _ _ = _
   rw [h_686_0 z z_]
   rfl
 #a h_700_0
 attribute [local irreducible] v_700_0
 attribute [local irreducible] s_701
 theorem r_701_0 (z : Store) : (s_701 z) 832 = (v_695_1 z) := pR (k_700 z) (pR (k_699 z) (pR (k_698 z) (r_698_0 z)))
 #a r_701_0
 theorem r_701_1 (z : Store) : (s_701 z) 1135 = (v_697_1 z) := pR (k_700 z) (pR (k_699 z) (pR (k_698 z) (r_698_1 z)))
 #a r_701_1
 def v_701_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_695_1 z), (v_697_1 z)]
 theorem g_701 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_846) (s_701 z) pmNode_846 1 2 1132 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 2, 16, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_846, r_701_0 z, r_701_1 z, h_695_1 z z_, h_697_1 z z_]
 #a g_701
 def s_702 (z : Store) : Store := pL [2, 3] (s_701 z) pmNode_846 1 2
 theorem t_701 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_846) (pmPeers pmNode_846) (s_701 z) pmNode_846 none = some (s_702 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_846) (s_701 z) pmNode_846).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1132 (by decide) (g_701 z z_)]
   rfl
 #a t_701
 theorem k_701 (z : Store) (tid : Tid) (h : tid ∉ [1132]) : (s_702 z) tid = (s_701 z) tid := by
   unfold s_702
   dsimp only [pL, pmNode_846, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_701
 theorem w_701_0 (z : Store) : (s_702 z) 1132 = v_701_0 z := by
   unfold s_702
   dsimp only [pL, pmNode_846, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_701_0, r_701_0 z, r_701_1 z] <;> rfl
 #a w_701_0
 theorem h_701_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_701_0 z).shape = [1, 4, 8, 16] := by
   unfold v_701_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_695_1 z z_]
 #a h_701_0
 attribute [local irreducible] v_701_0
 attribute [local irreducible] s_702
 theorem r_702_0 (z : Store) : (s_702 z) 1132 = (v_701_0 z) := w_701_0 z
 #a r_702_0
 theorem r_702_1 (z : Store) : (s_702 z) 1120 = (v_561_0 z) := pR (k_701 z) (pR (k_700 z) (pR (n_696_700 z) (pR (n_688_696 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_576_640 z) (pR (n_572_576 z) (pR (k_571 z) (pR (k_570 z) (pR (k_569 z) (r_569_0 z)))))))))))
 #a r_702_1
 def v_702_0 (z : Store) : Tensor := transposeAxes 2 3 (v_701_0 z)
 def s_703 (z : Store) : Store := storeSet (s_702 z) [(1122, transposeAxes 2 3 ((s_702 z) 1132))]
 theorem t_702 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_847) (pmPeers pmNode_847) (s_702 z) pmNode_847 none = some (s_703 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_702
 theorem k_702 (z : Store) (tid : Tid) (h : tid ∉ [1122]) : (s_703 z) tid = (s_702 z) tid := by
   unfold s_703
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_702
 theorem w_702_0 (z : Store) : (s_703 z) 1122 = v_702_0 z := by
   unfold s_703
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_702_0, r_702_0 z, r_702_1 z] <;> rfl
 #a w_702_0
 theorem h_702_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_702_0 z).shape = [1, 4, 16, 8] := by
   unfold v_702_0
   change listSwapAt _ _ _ = _
   rw [h_701_0 z z_]
   rfl
 #a h_702_0
 attribute [local irreducible] v_702_0
 attribute [local irreducible] s_703
 theorem r_703_0 (z : Store) : (s_703 z) 1130 = (v_688_0 z) := pR (k_702 z) (pR (k_701 z) (pR (k_700 z) (pR (n_696_700 z) (pR (n_692_696 z) (pR (k_691 z) (pR (k_690 z) (pR (k_689 z) (w_688_0 z))))))))
 #a r_703_0
 theorem r_703_1 (z : Store) : (s_703 z) 1127 = (v_567_0 z) := pR (k_702 z) (pR (k_701 z) (pR (k_700 z) (pR (n_696_700 z) (pR (n_688_696 z) (pR (n_672_688 z) (pR (n_640_672 z) (pR (n_576_640 z) (pR (n_568_576 z) (r_568_0 z)))))))))
 #a r_703_1
 def v_703_0 (z : Store) : Tensor := transposeAxes 1 2 (v_688_0 z)
 def s_704 (z : Store) : Store := storeSet (s_703 z) [(1129, transposeAxes 1 2 ((s_703 z) 1130))]
 theorem t_703 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_848) (pmPeers pmNode_848) (s_703 z) pmNode_848 none = some (s_704 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_703
 theorem k_703 (z : Store) (tid : Tid) (h : tid ∉ [1129]) : (s_704 z) tid = (s_703 z) tid := by
   unfold s_704
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_703
 theorem w_703_0 (z : Store) : (s_704 z) 1129 = v_703_0 z := by
   unfold s_704
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_703_0, r_703_0 z, r_703_1 z] <;> rfl
 #a w_703_0
 theorem h_703_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_703_0 z).shape = [1, 8, 4, 16] := by
   unfold v_703_0
   change listSwapAt _ _ _ = _
   rw [h_688_0 z z_]
   rfl
 #a h_703_0
 attribute [local irreducible] v_703_0
 attribute [local irreducible] s_704
 record_prefix_opacity v_696_0 s_697 v_697_0 v_697_1 s_698 v_698_0 s_699 v_699_0 s_700 v_700_0 s_701 v_701_0 s_702 v_702_0 s_703 v_703_0 s_704

 end
 end TrainVerify.Denote.RuntimeWorld
