import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0103
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_819_0 (z : Store) : (s_819 z) 1020 = (v_806_0 z) := pR (k_818 z) (pR (k_817 z) (pR (k_816 z) (pR (n_808_816 z) (pR (k_807 z) (w_806_0 z)))))
 #a r_819_0
 theorem r_819_1 (z : Store) : (s_819 z) 996 = (v_451_0 z) := pR (k_818 z) (pR (k_817 z) (pR (k_816 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (n_456_464 z) (pR (n_452_456 z) (r_452_0 z))))))))))
 #a r_819_1
 theorem r_819_2 (z : Store) : (s_819 z) 939 = (z 939) := pR (k_818 z) (pR (k_817 z) (pR (k_816 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (n_456_464 z) (pR (n_452_456 z) (r_452_1 z))))))))))
 #a r_819_2
 def v_819_0 (z : Store) : Tensor := (bw_linear (v_806_0 z) (v_451_0 z) (z 939)).1
 def v_819_1 (z : Store) : Tensor := (bw_linear (v_806_0 z) (v_451_0 z) (z 939)).2
 def s_820 (z : Store) : Store := storeSet (s_819 z) [(1019, (bw_linear ((s_819 z) 1020) ((s_819 z) 996) ((s_819 z) 939)).1), (940, (bw_linear ((s_819 z) 1020) ((s_819 z) 996) ((s_819 z) 939)).2)]
 theorem t_819 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_906) (pmPeers pmNode_906) (s_819 z) pmNode_906 none = some (s_820 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_819
 theorem k_819 (z : Store) (tid : Tid) (h : tid ∉ [1019, 940]) : (s_820 z) tid = (s_819 z) tid := by
   unfold s_820
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_819
 theorem w_819_0 (z : Store) : (s_820 z) 1019 = v_819_0 z := by
   unfold s_820
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_819_0, r_819_0 z, r_819_1 z, r_819_2 z] <;> rfl
 #a w_819_0
 theorem h_819_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_819_0 z).shape = [1, 16, 64] := by
   unfold v_819_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_806_0 z) (v_451_0 z) (z 939) (h_806_0 z z_) (h_451_0 z z_) (i_63 z z_)
 #a h_819_0
 attribute [local irreducible] v_819_0
 theorem w_819_1 (z : Store) : (s_820 z) 940 = v_819_1 z := by
   unfold s_820
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_819_1, r_819_0 z, r_819_1 z, r_819_2 z] <;> rfl
 #a w_819_1
 theorem h_819_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_819_1 z).shape = [32, 64] := by
   unfold v_819_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_806_0 z) (v_451_0 z) (z 939) (h_806_0 z z_) (h_451_0 z z_) (i_63 z z_)
 #a h_819_1
 attribute [local irreducible] v_819_1
 attribute [local irreducible] s_820
 theorem r_820_0 (z : Store) : (s_820 z) 717 = (v_816_0 z) := pR (k_819 z) (pR (k_818 z) (pR (k_817 z) (w_816_0 z)))
 #a r_820_0
 theorem r_820_1 (z : Store) : (s_820 z) 1019 = (v_819_0 z) := w_819_0 z
 #a r_820_1
 def v_820_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_816_0 z), (v_819_0 z)]
 def s_821 (z : Store) : Store := storeSet (s_820 z) [(894, reduceScatterPrimDimN 1 2 0 [((s_820 z) 717), ((s_820 z) 1019)])]
 theorem t_820 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_671) (pmPeers pmNode_671) (s_820 z) pmNode_671 none = some (s_821 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_820 z) pmNode_671 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_820
 theorem k_820 (z : Store) (tid : Tid) (h : tid ∉ [894]) : (s_821 z) tid = (s_820 z) tid := by
   unfold s_821
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_820
 theorem w_820_0 (z : Store) : (s_821 z) 894 = v_820_0 z := by
   unfold s_821
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_820_0, r_820_0 z, r_820_1 z] <;> rfl
 #a w_820_0
 theorem h_820_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_820_0 z).shape = [1, 8, 64] := by
   unfold v_820_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_816_0 z) rfl]
     exact h_816_0 z z_
   · decide
 #a h_820_0
 attribute [local irreducible] v_820_0
 attribute [local irreducible] s_821
 theorem n_816_820 (z : Store) (tid : Tid) (h : tid ∉ ([717, 637, 1022, 1014, 1019, 940] : List Tid)) : (s_820 z) tid = (s_816 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_816 z) (k_817 z)) (pF _ _ _ _ _ (k_818 z) (k_819 z)) tid h
 #a n_816_820
 theorem r_821_0 (z : Store) : (s_821 z) 713 = (v_809_0 z) := pR (k_820 z) (pR (n_816_820 z) (pR (n_812_816 z) (pR (k_811 z) (pR (k_810 z) (w_809_0 z)))))
 #a r_821_0
 theorem r_821_1 (z : Store) : (s_821 z) 692 = (v_443_0 z) := pR (k_820 z) (pR (n_816_820 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_444_448 z) (r_444_0 z)))))))
 #a r_821_1
 theorem r_821_2 (z : Store) : (s_821 z) 633 = (z 633) := pR (k_820 z) (pR (n_816_820 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_444_448 z) (r_444_1 z)))))))
 #a r_821_2
 def v_821_0 (z : Store) : Tensor := (bw_linear (v_809_0 z) (v_443_0 z) (z 633)).1
 def v_821_1 (z : Store) : Tensor := (bw_linear (v_809_0 z) (v_443_0 z) (z 633)).2
 def s_822 (z : Store) : Store := storeSet (s_821 z) [(714, (bw_linear ((s_821 z) 713) ((s_821 z) 692) ((s_821 z) 633)).1), (634, (bw_linear ((s_821 z) 713) ((s_821 z) 692) ((s_821 z) 633)).2)]
 theorem t_821 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_672) (pmPeers pmNode_672) (s_821 z) pmNode_672 none = some (s_822 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_821
 theorem k_821 (z : Store) (tid : Tid) (h : tid ∉ [714, 634]) : (s_822 z) tid = (s_821 z) tid := by
   unfold s_822
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_821
 theorem w_821_0 (z : Store) : (s_822 z) 714 = v_821_0 z := by
   unfold s_822
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_821_0, r_821_0 z, r_821_1 z, r_821_2 z] <;> rfl
 #a w_821_0
 theorem h_821_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_821_0 z).shape = [1, 16, 64] := by
   unfold v_821_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_809_0 z) (v_443_0 z) (z 633) (h_809_0 z z_) (h_443_0 z z_) (i_59 z z_)
 #a h_821_0
 attribute [local irreducible] v_821_0
 theorem w_821_1 (z : Store) : (s_822 z) 634 = v_821_1 z := by
   unfold s_822
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_821_1, r_821_0 z, r_821_1 z, r_821_2 z] <;> rfl
 #a w_821_1
 theorem h_821_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_821_1 z).shape = [32, 64] := by
   unfold v_821_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_809_0 z) (v_443_0 z) (z 633) (h_809_0 z z_) (h_443_0 z z_) (i_59 z z_)
 #a h_821_1
 attribute [local irreducible] v_821_1
 attribute [local irreducible] s_822
 theorem r_822_0 (z : Store) : (s_822 z) 717 = (v_816_0 z) := pR (k_821 z) (pR (k_820 z) (r_820_0 z))
 #a r_822_0
 theorem r_822_1 (z : Store) : (s_822 z) 1019 = (v_819_0 z) := pR (k_821 z) (pR (k_820 z) (r_820_1 z))
 #a r_822_1
 def v_822_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_816_0 z), (v_819_0 z)]
 def s_823 (z : Store) : Store := storeSet (s_822 z) [(1197, reduceScatterPrimDimN 1 2 1 [((s_822 z) 717), ((s_822 z) 1019)])]
 theorem t_822 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_907) (pmPeers pmNode_907) (s_822 z) pmNode_907 none = some (s_823 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_822 z) pmNode_907 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_822
 theorem k_822 (z : Store) (tid : Tid) (h : tid ∉ [1197]) : (s_823 z) tid = (s_822 z) tid := by
   unfold s_823
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_822
 theorem w_822_0 (z : Store) : (s_823 z) 1197 = v_822_0 z := by
   unfold s_823
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_822_0, r_822_0 z, r_822_1 z] <;> rfl
 #a w_822_0
 theorem h_822_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_822_0 z).shape = [1, 8, 64] := by
   unfold v_822_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_816_0 z) rfl]
     exact h_816_0 z z_
   · decide
 #a h_822_0
 attribute [local irreducible] v_822_0
 attribute [local irreducible] s_823
 theorem r_823_0 (z : Store) : (s_823 z) 1017 = (v_812_0 z) := pR (k_822 z) (pR (k_821 z) (pR (k_820 z) (pR (n_816_820 z) (pR (k_815 z) (pR (k_814 z) (pR (k_813 z) (w_812_0 z)))))))
 #a r_823_0
 theorem r_823_1 (z : Store) : (s_823 z) 995 = (v_449_0 z) := pR (k_822 z) (pR (k_821 z) (pR (k_820 z) (pR (n_816_820 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (n_456_464 z) (pR (n_452_456 z) (pR (k_451 z) (pR (k_450 z) (r_450_0 z)))))))))))))
 #a r_823_1
 theorem r_823_2 (z : Store) : (s_823 z) 936 = (z 936) := pR (k_822 z) (pR (k_821 z) (pR (k_820 z) (pR (n_816_820 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_480_512 z) (pR (n_464_480 z) (pR (n_456_464 z) (pR (n_452_456 z) (pR (k_451 z) (pR (k_450 z) (r_450_1 z)))))))))))))
 #a r_823_2
 def v_823_0 (z : Store) : Tensor := (bw_linear (v_812_0 z) (v_449_0 z) (z 936)).1
 def v_823_1 (z : Store) : Tensor := (bw_linear (v_812_0 z) (v_449_0 z) (z 936)).2
 def s_824 (z : Store) : Store := storeSet (s_823 z) [(1016, (bw_linear ((s_823 z) 1017) ((s_823 z) 995) ((s_823 z) 936)).1), (937, (bw_linear ((s_823 z) 1017) ((s_823 z) 995) ((s_823 z) 936)).2)]
 theorem t_823 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_908) (pmPeers pmNode_908) (s_823 z) pmNode_908 none = some (s_824 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_823
 theorem k_823 (z : Store) (tid : Tid) (h : tid ∉ [1016, 937]) : (s_824 z) tid = (s_823 z) tid := by
   unfold s_824
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_823
 theorem w_823_0 (z : Store) : (s_824 z) 1016 = v_823_0 z := by
   unfold s_824
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_823_0, r_823_0 z, r_823_1 z, r_823_2 z] <;> rfl
 #a w_823_0
 theorem h_823_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_823_0 z).shape = [1, 16, 64] := by
   unfold v_823_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_812_0 z) (v_449_0 z) (z 936) (h_812_0 z z_) (h_449_0 z z_) (i_62 z z_)
 #a h_823_0
 attribute [local irreducible] v_823_0
 theorem w_823_1 (z : Store) : (s_824 z) 937 = v_823_1 z := by
   unfold s_824
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_823_1, r_823_0 z, r_823_1 z, r_823_2 z] <;> rfl
 #a w_823_1
 theorem h_823_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_823_1 z).shape = [32, 64] := by
   unfold v_823_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_812_0 z) (v_449_0 z) (z 936) (h_812_0 z z_) (h_449_0 z z_) (i_62 z z_)
 #a h_823_1
 attribute [local irreducible] v_823_1
 attribute [local irreducible] s_824
 theorem r_824_0 (z : Store) : (s_824 z) 714 = (v_821_0 z) := pR (k_823 z) (pR (k_822 z) (w_821_0 z))
 #a r_824_0
 theorem r_824_1 (z : Store) : (s_824 z) 1016 = (v_823_0 z) := w_823_0 z
 #a r_824_1
 def v_824_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_821_0 z), (v_823_0 z)]
 def s_825 (z : Store) : Store := storeSet (s_824 z) [(892, reduceScatterPrimDimN 1 2 0 [((s_824 z) 714), ((s_824 z) 1016)])]
 theorem t_824 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_673) (pmPeers pmNode_673) (s_824 z) pmNode_673 none = some (s_825 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_824 z) pmNode_673 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_824
 theorem k_824 (z : Store) (tid : Tid) (h : tid ∉ [892]) : (s_825 z) tid = (s_824 z) tid := by
   unfold s_825
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_824
 theorem w_824_0 (z : Store) : (s_825 z) 892 = v_824_0 z := by
   unfold s_825
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_824_0, r_824_0 z, r_824_1 z] <;> rfl
 #a w_824_0
 theorem h_824_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_824_0 z).shape = [1, 8, 64] := by
   unfold v_824_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_821_0 z) rfl]
     exact h_821_0 z z_
   · decide
 #a h_824_0
 attribute [local irreducible] v_824_0
 attribute [local irreducible] s_825
 theorem n_820_824 (z : Store) (tid : Tid) (h : tid ∉ ([894, 714, 634, 1197, 1016, 937] : List Tid)) : (s_824 z) tid = (s_820 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_820 z) (k_821 z)) (pF _ _ _ _ _ (k_822 z) (k_823 z)) tid h
 #a n_820_824
 theorem n_816_824 (z : Store) (tid : Tid) (h : tid ∉ ([717, 637, 1022, 1014, 1019, 940, 894, 714, 634, 1197, 1016, 937] : List Tid)) : (s_824 z) tid = (s_816 z) tid := by
   exact pF _ _ _ _ _ (n_816_820 z) (n_820_824 z) tid h
 #a n_816_824
 theorem r_825_0 (z : Store) : (s_825 z) 711 = (v_815_0 z) := pR (k_824 z) (pR (n_816_824 z) (w_815_0 z))
 #a r_825_0
 theorem r_825_1 (z : Store) : (s_825 z) 708 = (v_438_0 z) := pR (k_824 z) (pR (n_816_824 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_440_448 z) (pR (k_439 z) (r_439_0 z))))))))
 #a r_825_1
 theorem r_825_2 (z : Store) : (s_825 z) 609 = (z 609) := pR (k_824 z) (pR (n_816_824 z) (pR (n_800_816 z) (pR (n_768_800 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_440_448 z) (pR (k_439 z) (r_439_1 z))))))))
 #a r_825_2
 def v_825_0 (z : Store) : Tensor := (bw_linear (v_815_0 z) (v_438_0 z) (z 609)).1
 def v_825_1 (z : Store) : Tensor := (bw_linear (v_815_0 z) (v_438_0 z) (z 609)).2
 def s_826 (z : Store) : Store := storeSet (s_825 z) [(710, (bw_linear ((s_825 z) 711) ((s_825 z) 708) ((s_825 z) 609)).1), (631, (bw_linear ((s_825 z) 711) ((s_825 z) 708) ((s_825 z) 609)).2)]
 theorem t_825 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_674) (pmPeers pmNode_674) (s_825 z) pmNode_674 none = some (s_826 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_825
 theorem k_825 (z : Store) (tid : Tid) (h : tid ∉ [710, 631]) : (s_826 z) tid = (s_825 z) tid := by
   unfold s_826
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_825
 theorem w_825_0 (z : Store) : (s_826 z) 710 = v_825_0 z := by
   unfold s_826
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_825_0, r_825_0 z, r_825_1 z, r_825_2 z] <;> rfl
 #a w_825_0
 theorem h_825_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_825_0 z).shape = [1, 8, 64] := by
   unfold v_825_0
   exact bw_linear_3d_fst_shape 1 8 64 64 (v_815_0 z) (v_438_0 z) (z 609) (h_815_0 z z_) (h_438_0 z z_) (i_56 z z_)
 #a h_825_0
 attribute [local irreducible] v_825_0
 theorem w_825_1 (z : Store) : (s_826 z) 631 = v_825_1 z := by
   unfold s_826
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_825_1, r_825_0 z, r_825_1 z, r_825_2 z] <;> rfl
 #a w_825_1
 theorem h_825_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_825_1 z).shape = [64, 64] := by
   unfold v_825_1
   exact bw_linear_3d_snd_shape 1 8 64 64 (v_815_0 z) (v_438_0 z) (z 609) (h_815_0 z z_) (h_438_0 z z_) (i_56 z z_)
 #a h_825_1
 attribute [local irreducible] v_825_1
 attribute [local irreducible] s_826
 record_prefix_opacity v_819_0 v_819_1 s_820 v_820_0 s_821 v_821_0 v_821_1 s_822 v_822_0 s_823 v_823_0 v_823_1 s_824 v_824_0 s_825 v_825_0 v_825_1 s_826

 end
 end TrainVerify.Denote.RuntimeWorld
