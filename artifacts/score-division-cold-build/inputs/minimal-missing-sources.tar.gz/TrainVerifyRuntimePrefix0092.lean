import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0091
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_729_0 (z : Store) : (s_729 z) 688 = (v_716_0 z) := pR (k_728 z) (pR (n_720_728 z) (pR (k_719 z) (pR (k_718 z) (pR (k_717 z) (w_716_0 z)))))
 #a r_729_0
 theorem r_729_1 (z : Store) : (s_729 z) 798 = (v_534_0 z) := pR (k_728 z) (pR (n_720_728 z) (pR (n_704_720 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_536_544 z) (pR (k_535 z) (r_535_0 z))))))))
 #a r_729_1
 theorem r_729_2 (z : Store) : (s_729 z) 656 = (z 656) := pR (k_728 z) (pR (n_720_728 z) (pR (n_704_720 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_536_544 z) (pR (k_535 z) (r_535_1 z))))))))
 #a r_729_2
 def v_729_0 (z : Store) : Tensor := (bw_linear (v_716_0 z) (v_534_0 z) (z 656)).1
 def v_729_1 (z : Store) : Tensor := (bw_linear (v_716_0 z) (v_534_0 z) (z 656)).2
 def s_730 (z : Store) : Store := storeSet (s_729 z) [(800, (bw_linear ((s_729 z) 688) ((s_729 z) 798) ((s_729 z) 656)).1), (657, (bw_linear ((s_729 z) 688) ((s_729 z) 798) ((s_729 z) 656)).2)]
 theorem t_729 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_626) (pmPeers pmNode_626) (s_729 z) pmNode_626 none = some (s_730 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_729
 theorem k_729 (z : Store) (tid : Tid) (h : tid ∉ [800, 657]) : (s_730 z) tid = (s_729 z) tid := by
   unfold s_730
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_729
 theorem w_729_0 (z : Store) : (s_730 z) 800 = v_729_0 z := by
   unfold s_730
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_729_0, r_729_0 z, r_729_1 z, r_729_2 z] <;> rfl
 #a w_729_0
 theorem h_729_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_729_0 z).shape = [1, 16, 32] := by
   unfold v_729_0
   exact bw_linear_3d_fst_shape 1 16 64 32 (v_716_0 z) (v_534_0 z) (z 656) (h_716_0 z z_) (h_534_0 z z_) (i_79 z z_)
 #a h_729_0
 attribute [local irreducible] v_729_0
 theorem w_729_1 (z : Store) : (s_730 z) 657 = v_729_1 z := by
   unfold s_730
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_729_1, r_729_0 z, r_729_1 z, r_729_2 z] <;> rfl
 #a w_729_1
 theorem h_729_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_729_1 z).shape = [64, 32] := by
   unfold v_729_1
   exact bw_linear_3d_snd_shape 1 16 64 32 (v_716_0 z) (v_534_0 z) (z 656) (h_716_0 z z_) (h_534_0 z z_) (i_79 z z_)
 #a h_729_1
 attribute [local irreducible] v_729_1
 attribute [local irreducible] s_730
 theorem r_730_0 (z : Store) : (s_730 z) 803 = (v_725_0 z) := pR (k_729 z) (pR (k_728 z) (r_728_0 z))
 #a r_730_0
 theorem r_730_1 (z : Store) : (s_730 z) 1106 = (v_727_0 z) := pR (k_729 z) (pR (k_728 z) (r_728_1 z))
 #a r_730_1
 def v_730_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_725_0 z), (v_727_0 z)]
 theorem g_730 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_861) (s_730 z) pmNode_861 2 1 1207 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_861, r_730_0 z, r_730_1 z, h_725_0 z z_, h_727_0 z z_]
 #a g_730
 def s_731 (z : Store) : Store := pL [2, 3] (s_730 z) pmNode_861 2 1
 theorem t_730 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_861) (pmPeers pmNode_861) (s_730 z) pmNode_861 none = some (s_731 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_861) (s_730 z) pmNode_861).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1207 (by decide) (g_730 z z_)]
   rfl
 #a t_730
 theorem k_730 (z : Store) (tid : Tid) (h : tid ∉ [1207]) : (s_731 z) tid = (s_730 z) tid := by
   unfold s_731
   dsimp only [pL, pmNode_861, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_730
 theorem w_730_0 (z : Store) : (s_731 z) 1207 = v_730_0 z := by
   unfold s_731
   dsimp only [pL, pmNode_861, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_730_0, r_730_0 z, r_730_1 z] <;> rfl
 #a w_730_0
 theorem h_730_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_730_0 z).shape = [1, 8, 64] := by
   unfold v_730_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_725_0 z z_]
 #a h_730_0
 attribute [local irreducible] v_730_0
 attribute [local irreducible] s_731
 theorem r_731_0 (z : Store) : (s_731 z) 991 = (v_718_0 z) := pR (k_730 z) (pR (k_729 z) (pR (k_728 z) (pR (n_720_728 z) (pR (k_719 z) (w_718_0 z)))))
 #a r_731_0
 theorem r_731_1 (z : Store) : (s_731 z) 1101 = (v_542_0 z) := pR (k_730 z) (pR (k_729 z) (pR (k_728 z) (pR (n_720_728 z) (pR (n_704_720 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (k_543 z) (r_543_0 z)))))))))
 #a r_731_1
 theorem r_731_2 (z : Store) : (s_731 z) 959 = (z 959) := pR (k_730 z) (pR (k_729 z) (pR (k_728 z) (pR (n_720_728 z) (pR (n_704_720 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (k_543 z) (r_543_1 z)))))))))
 #a r_731_2
 def v_731_0 (z : Store) : Tensor := (bw_linear (v_718_0 z) (v_542_0 z) (z 959)).1
 def v_731_1 (z : Store) : Tensor := (bw_linear (v_718_0 z) (v_542_0 z) (z 959)).2
 def s_732 (z : Store) : Store := storeSet (s_731 z) [(1103, (bw_linear ((s_731 z) 991) ((s_731 z) 1101) ((s_731 z) 959)).1), (960, (bw_linear ((s_731 z) 991) ((s_731 z) 1101) ((s_731 z) 959)).2)]
 theorem t_731 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_862) (pmPeers pmNode_862) (s_731 z) pmNode_862 none = some (s_732 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_731
 theorem k_731 (z : Store) (tid : Tid) (h : tid ∉ [1103, 960]) : (s_732 z) tid = (s_731 z) tid := by
   unfold s_732
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_731
 theorem w_731_0 (z : Store) : (s_732 z) 1103 = v_731_0 z := by
   unfold s_732
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_731_0, r_731_0 z, r_731_1 z, r_731_2 z] <;> rfl
 #a w_731_0
 theorem h_731_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_731_0 z).shape = [1, 16, 32] := by
   unfold v_731_0
   exact bw_linear_3d_fst_shape 1 16 64 32 (v_718_0 z) (v_542_0 z) (z 959) (h_718_0 z z_) (h_542_0 z z_) (i_82 z z_)
 #a h_731_0
 attribute [local irreducible] v_731_0
 theorem w_731_1 (z : Store) : (s_732 z) 960 = v_731_1 z := by
   unfold s_732
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_731_1, r_731_0 z, r_731_1 z, r_731_2 z] <;> rfl
 #a w_731_1
 theorem h_731_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_731_1 z).shape = [64, 32] := by
   unfold v_731_1
   exact bw_linear_3d_snd_shape 1 16 64 32 (v_718_0 z) (v_542_0 z) (z 959) (h_718_0 z z_) (h_542_0 z z_) (i_82 z z_)
 #a h_731_1
 attribute [local irreducible] v_731_1
 attribute [local irreducible] s_732
 theorem r_732_0 (z : Store) : (s_732 z) 800 = (v_729_0 z) := pR (k_731 z) (pR (k_730 z) (w_729_0 z))
 #a r_732_0
 theorem r_732_1 (z : Store) : (s_732 z) 1103 = (v_731_0 z) := w_731_0 z
 #a r_732_1
 def v_732_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_729_0 z), (v_731_0 z)]
 theorem g_732 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_627) (s_732 z) pmNode_627 2 1 902 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_627, r_732_0 z, r_732_1 z, h_729_0 z z_, h_731_0 z z_]
 #a g_732
 def s_733 (z : Store) : Store := pL [2, 3] (s_732 z) pmNode_627 2 1
 theorem t_732 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_627) (pmPeers pmNode_627) (s_732 z) pmNode_627 none = some (s_733 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_627) (s_732 z) pmNode_627).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 902 (by decide) (g_732 z z_)]
   rfl
 #a t_732
 theorem k_732 (z : Store) (tid : Tid) (h : tid ∉ [902]) : (s_733 z) tid = (s_732 z) tid := by
   unfold s_733
   dsimp only [pL, pmNode_627, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_732
 theorem w_732_0 (z : Store) : (s_733 z) 902 = v_732_0 z := by
   unfold s_733
   dsimp only [pL, pmNode_627, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_732_0, r_732_0 z, r_732_1 z] <;> rfl
 #a w_732_0
 theorem h_732_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_732_0 z).shape = [1, 8, 64] := by
   unfold v_732_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_729_0 z z_]
 #a h_732_0
 attribute [local irreducible] v_732_0
 attribute [local irreducible] s_733
 theorem n_728_732 (z : Store) (tid : Tid) (h : tid ∉ ([904, 800, 657, 1207, 1103, 960] : List Tid)) : (s_732 z) tid = (s_728 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_728 z) (k_729 z)) (pF _ _ _ _ _ (k_730 z) (k_731 z)) tid h
 #a n_728_732
 theorem r_733_0 (z : Store) : (s_733 z) 796 = (v_724_0 z) := pR (k_732 z) (pR (n_728_732 z) (pR (k_727 z) (pR (k_726 z) (pR (k_725 z) (w_724_0 z)))))
 #a r_733_0
 theorem r_733_1 (z : Store) : (s_733 z) 694 = (v_532_0 z) := pR (k_732 z) (pR (n_728_732 z) (pR (n_720_728 z) (pR (n_704_720 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_536_544 z) (pR (k_535 z) (pR (k_534 z) (pR (k_533 z) (r_533_0 z)))))))))))
 #a r_733_1
 theorem r_733_2 (z : Store) : (s_733 z) 653 = (z 653) := pR (k_732 z) (pR (n_728_732 z) (pR (n_720_728 z) (pR (n_704_720 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_536_544 z) (pR (k_535 z) (pR (k_534 z) (pR (k_533 z) (r_533_1 z)))))))))))
 #a r_733_2
 def v_733_0 (z : Store) : Tensor := (bw_linear (v_724_0 z) (v_532_0 z) (z 653)).1
 def v_733_1 (z : Store) : Tensor := (bw_linear (v_724_0 z) (v_532_0 z) (z 653)).2
 def s_734 (z : Store) : Store := storeSet (s_733 z) [(797, (bw_linear ((s_733 z) 796) ((s_733 z) 694) ((s_733 z) 653)).1), (654, (bw_linear ((s_733 z) 796) ((s_733 z) 694) ((s_733 z) 653)).2)]
 theorem t_733 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_628) (pmPeers pmNode_628) (s_733 z) pmNode_628 none = some (s_734 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_733
 theorem k_733 (z : Store) (tid : Tid) (h : tid ∉ [797, 654]) : (s_734 z) tid = (s_733 z) tid := by
   unfold s_734
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_733
 theorem w_733_0 (z : Store) : (s_734 z) 797 = v_733_0 z := by
   unfold s_734
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_733_0, r_733_0 z, r_733_1 z, r_733_2 z] <;> rfl
 #a w_733_0
 theorem h_733_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_733_0 z).shape = [1, 16, 64] := by
   unfold v_733_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_724_0 z) (v_532_0 z) (z 653) (h_724_0 z z_) (h_532_0 z z_) (i_78 z z_)
 #a h_733_0
 attribute [local irreducible] v_733_0
 theorem w_733_1 (z : Store) : (s_734 z) 654 = v_733_1 z := by
   unfold s_734
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_733_1, r_733_0 z, r_733_1 z, r_733_2 z] <;> rfl
 #a w_733_1
 theorem h_733_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_733_1 z).shape = [32, 64] := by
   unfold v_733_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_724_0 z) (v_532_0 z) (z 653) (h_724_0 z z_) (h_532_0 z z_) (i_78 z z_)
 #a h_733_1
 attribute [local irreducible] v_733_1
 attribute [local irreducible] s_734
 theorem r_734_0 (z : Store) : (s_734 z) 800 = (v_729_0 z) := pR (k_733 z) (pR (k_732 z) (r_732_0 z))
 #a r_734_0
 theorem r_734_1 (z : Store) : (s_734 z) 1103 = (v_731_0 z) := pR (k_733 z) (pR (k_732 z) (r_732_1 z))
 #a r_734_1
 def v_734_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_729_0 z), (v_731_0 z)]
 theorem g_734 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_863) (s_734 z) pmNode_863 2 1 1205 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_863, r_734_0 z, r_734_1 z, h_729_0 z z_, h_731_0 z z_]
 #a g_734
 def s_735 (z : Store) : Store := pL [2, 3] (s_734 z) pmNode_863 2 1
 theorem t_734 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_863) (pmPeers pmNode_863) (s_734 z) pmNode_863 none = some (s_735 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_863) (s_734 z) pmNode_863).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1205 (by decide) (g_734 z z_)]
   rfl
 #a t_734
 theorem k_734 (z : Store) (tid : Tid) (h : tid ∉ [1205]) : (s_735 z) tid = (s_734 z) tid := by
   unfold s_735
   dsimp only [pL, pmNode_863, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_734
 theorem w_734_0 (z : Store) : (s_735 z) 1205 = v_734_0 z := by
   unfold s_735
   dsimp only [pL, pmNode_863, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_734_0, r_734_0 z, r_734_1 z] <;> rfl
 #a w_734_0
 theorem h_734_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_734_0 z).shape = [1, 8, 64] := by
   unfold v_734_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_729_0 z z_]
 #a h_734_0
 attribute [local irreducible] v_734_0
 attribute [local irreducible] s_735
 theorem r_735_0 (z : Store) : (s_735 z) 1100 = (v_726_0 z) := pR (k_734 z) (pR (k_733 z) (pR (k_732 z) (pR (n_728_732 z) (pR (k_727 z) (w_726_0 z)))))
 #a r_735_0
 theorem r_735_1 (z : Store) : (s_735 z) 997 = (v_538_0 z) := pR (k_734 z) (pR (k_733 z) (pR (k_732 z) (pR (n_728_732 z) (pR (n_720_728 z) (pR (n_704_720 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_540_544 z) (pR (k_539 z) (r_539_0 z)))))))))))
 #a r_735_1
 theorem r_735_2 (z : Store) : (s_735 z) 956 = (z 956) := pR (k_734 z) (pR (k_733 z) (pR (k_732 z) (pR (n_728_732 z) (pR (n_720_728 z) (pR (n_704_720 z) (pR (n_640_704 z) (pR (n_576_640 z) (pR (n_544_576 z) (pR (n_540_544 z) (pR (k_539 z) (r_539_1 z)))))))))))
 #a r_735_2
 def v_735_0 (z : Store) : Tensor := (bw_linear (v_726_0 z) (v_538_0 z) (z 956)).1
 def v_735_1 (z : Store) : Tensor := (bw_linear (v_726_0 z) (v_538_0 z) (z 956)).2
 def s_736 (z : Store) : Store := storeSet (s_735 z) [(1099, (bw_linear ((s_735 z) 1100) ((s_735 z) 997) ((s_735 z) 956)).1), (957, (bw_linear ((s_735 z) 1100) ((s_735 z) 997) ((s_735 z) 956)).2)]
 theorem t_735 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_864) (pmPeers pmNode_864) (s_735 z) pmNode_864 none = some (s_736 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_735
 theorem k_735 (z : Store) (tid : Tid) (h : tid ∉ [1099, 957]) : (s_736 z) tid = (s_735 z) tid := by
   unfold s_736
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_735
 theorem w_735_0 (z : Store) : (s_736 z) 1099 = v_735_0 z := by
   unfold s_736
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_735_0, r_735_0 z, r_735_1 z, r_735_2 z] <;> rfl
 #a w_735_0
 theorem h_735_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_735_0 z).shape = [1, 16, 64] := by
   unfold v_735_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_726_0 z) (v_538_0 z) (z 956) (h_726_0 z z_) (h_538_0 z z_) (i_81 z z_)
 #a h_735_0
 attribute [local irreducible] v_735_0
 theorem w_735_1 (z : Store) : (s_736 z) 957 = v_735_1 z := by
   unfold s_736
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_735_1, r_735_0 z, r_735_1 z, r_735_2 z] <;> rfl
 #a w_735_1
 theorem h_735_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_735_1 z).shape = [32, 64] := by
   unfold v_735_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_726_0 z) (v_538_0 z) (z 956) (h_726_0 z z_) (h_538_0 z z_) (i_81 z z_)
 #a h_735_1
 attribute [local irreducible] v_735_1
 attribute [local irreducible] s_736
 record_prefix_opacity v_729_0 v_729_1 s_730 v_730_0 s_731 v_731_0 v_731_1 s_732 v_732_0 s_733 v_733_0 v_733_1 s_734 v_734_0 s_735 v_735_0 v_735_1 s_736

 end
 end TrainVerify.Denote.RuntimeWorld
