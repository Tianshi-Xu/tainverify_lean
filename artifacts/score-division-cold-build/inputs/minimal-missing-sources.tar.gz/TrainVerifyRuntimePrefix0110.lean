import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0109
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_859_0 (z : Store) : (s_859 z) 17 = (v_418_0 z) := pR (k_858 z) (pR (k_857 z) (pR (k_856 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_432_448 z) (pR (n_424_432 z) (pR (n_420_424 z) (pR (k_419 z) (w_418_0 z))))))))))))
 #a r_859_0
 theorem r_859_1 (z : Store) : (s_859 z) 623 = (v_840_0 z) := pR (k_858 z) (pR (k_857 z) (pR (k_856 z) (pR (n_848_856 z) (pR (n_844_848 z) (pR (k_843 z) (pR (k_842 z) (pR (k_841 z) (w_840_0 z))))))))
 #a r_859_1
 def v_859_0 (z : Store) : Tensor := cross_dp_wred [(v_418_0 z), (v_840_0 z)]
 theorem g_859 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_227) (s_859 z) pmNode_227 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_227, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_859_1 z, r_859_0 z]
     exact (h_840_0 z z_).trans (h_418_0 z z_).symm
 #a g_859
 def s_860 (z : Store) : Store := storeSet (s_859 z) [(18, cross_dp_wred [((s_859 z) 17), ((s_859 z) 623)])]
 theorem t_859 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_227) (pmPeers pmNode_227) (s_859 z) pmNode_227 none = some (s_860 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_227) (s_859 z) pmNode_227 = _
   rw [wredStep, if_pos ⟨by decide, g_859 z z_⟩]
   rfl
 #a t_859
 theorem k_859 (z : Store) (tid : Tid) (h : tid ∉ [18]) : (s_860 z) tid = (s_859 z) tid := by
   unfold s_860
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_859
 theorem w_859_0 (z : Store) : (s_860 z) 18 = v_859_0 z := by
   unfold s_860
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_859_0, r_859_0 z, r_859_1 z] <;> rfl
 #a w_859_0
 theorem h_859_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_859_0 z).shape = [256, 32] := by
   unfold v_859_0
   rw [tensorSum_shape]
   exact h_418_0 z z_
 #a h_859_0
 attribute [local irreducible] v_859_0
 attribute [local irreducible] s_860
 theorem n_856_860 (z : Store) (tid : Tid) (h : tid ∉ ([42, 44, 46, 18] : List Tid)) : (s_860 z) tid = (s_856 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_856 z) (k_857 z)) (pF _ _ _ _ _ (k_858 z) (k_859 z)) tid h
 #a n_856_860
 theorem r_860_0 (z : Store) : (s_860 z) 57 = (v_247_1 z) := pR (n_856_860 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_248_256 z) (w_247_1 z)))))))
 #a r_860_0
 theorem r_860_1 (z : Store) : (s_860 z) 663 = (v_669_1 z) := pR (n_856_860 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (k_671 z) (pR (k_670 z) (w_669_1 z))))))))
 #a r_860_1
 def v_860_0 (z : Store) : Tensor := cross_dp_wred [(v_247_1 z), (v_669_1 z)]
 theorem g_860 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_228) (s_860 z) pmNode_228 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_228, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_860_1 z, r_860_0 z]
     exact (h_669_1 z z_).trans (h_247_1 z z_).symm
 #a g_860
 def s_861 (z : Store) : Store := storeSet (s_860 z) [(58, cross_dp_wred [((s_860 z) 57), ((s_860 z) 663)])]
 theorem t_860 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_228) (pmPeers pmNode_228) (s_860 z) pmNode_228 none = some (s_861 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_228) (s_860 z) pmNode_228 = _
   rw [wredStep, if_pos ⟨by decide, g_860 z z_⟩]
   rfl
 #a t_860
 theorem k_860 (z : Store) (tid : Tid) (h : tid ∉ [58]) : (s_861 z) tid = (s_860 z) tid := by
   unfold s_861
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_860
 theorem w_860_0 (z : Store) : (s_861 z) 58 = v_860_0 z := by
   unfold s_861
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_860_0, r_860_0 z, r_860_1 z] <;> rfl
 #a w_860_0
 theorem h_860_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_860_0 z).shape = [64, 32] := by
   unfold v_860_0
   rw [tensorSum_shape]
   exact h_247_1 z z_
 #a h_860_0
 attribute [local irreducible] v_860_0
 attribute [local irreducible] s_861
 theorem r_861_0 (z : Store) : (s_861 z) 28 = (v_399_1 z) := pR (k_860 z) (pR (n_856_860 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_416_448 z) (pR (n_400_416 z) (w_399_1 z)))))))))
 #a r_861_0
 theorem r_861_1 (z : Store) : (s_861 z) 634 = (v_821_1 z) := pR (k_860 z) (pR (n_856_860 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_824_832 z) (pR (k_823 z) (pR (k_822 z) (w_821_1 z)))))))
 #a r_861_1
 def v_861_0 (z : Store) : Tensor := cross_dp_wred [(v_399_1 z), (v_821_1 z)]
 theorem g_861 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_229) (s_861 z) pmNode_229 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_229, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_861_1 z, r_861_0 z]
     exact (h_821_1 z z_).trans (h_399_1 z z_).symm
 #a g_861
 def s_862 (z : Store) : Store := storeSet (s_861 z) [(29, cross_dp_wred [((s_861 z) 28), ((s_861 z) 634)])]
 theorem t_861 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_229) (pmPeers pmNode_229) (s_861 z) pmNode_229 none = some (s_862 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_229) (s_861 z) pmNode_229 = _
   rw [wredStep, if_pos ⟨by decide, g_861 z z_⟩]
   rfl
 #a t_861
 theorem k_861 (z : Store) (tid : Tid) (h : tid ∉ [29]) : (s_862 z) tid = (s_861 z) tid := by
   unfold s_862
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_861
 theorem w_861_0 (z : Store) : (s_862 z) 29 = v_861_0 z := by
   unfold s_862
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_861_0, r_861_0 z, r_861_1 z] <;> rfl
 #a w_861_0
 theorem h_861_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_861_0 z).shape = [32, 64] := by
   unfold v_861_0
   rw [tensorSum_shape]
   exact h_399_1 z z_
 #a h_861_0
 attribute [local irreducible] v_861_0
 attribute [local irreducible] s_862
 theorem r_862_0 (z : Store) : (s_862 z) 64 = (v_233_1 z) := pR (k_861 z) (pR (k_860 z) (pR (n_856_860 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_240_256 z) (pR (n_236_240 z) (pR (k_235 z) (pR (k_234 z) (w_233_1 z))))))))))))
 #a r_862_0
 theorem r_862_1 (z : Store) : (s_862 z) 670 = (v_655_1 z) := pR (k_861 z) (pR (k_860 z) (pR (n_856_860 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_704_768 z) (pR (n_672_704 z) (pR (n_656_672 z) (w_655_1 z)))))))))
 #a r_862_1
 def v_862_0 (z : Store) : Tensor := cross_dp_wred [(v_233_1 z), (v_655_1 z)]
 theorem g_862 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_230) (s_862 z) pmNode_230 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_230, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_862_1 z, r_862_0 z]
     exact (h_655_1 z z_).trans (h_233_1 z z_).symm
 #a g_862
 def s_863 (z : Store) : Store := storeSet (s_862 z) [(65, cross_dp_wred [((s_862 z) 64), ((s_862 z) 670)])]
 theorem t_862 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_230) (pmPeers pmNode_230) (s_862 z) pmNode_230 none = some (s_863 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_230) (s_862 z) pmNode_230 = _
   rw [wredStep, if_pos ⟨by decide, g_862 z z_⟩]
   rfl
 #a t_862
 theorem k_862 (z : Store) (tid : Tid) (h : tid ∉ [65]) : (s_863 z) tid = (s_862 z) tid := by
   unfold s_863
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_862
 theorem w_862_0 (z : Store) : (s_863 z) 65 = v_862_0 z := by
   unfold s_863
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_862_0, r_862_0 z, r_862_1 z] <;> rfl
 #a w_862_0
 theorem h_862_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_862_0 z).shape = [256, 32] := by
   unfold v_862_0
   rw [tensorSum_shape]
   exact h_233_1 z z_
 #a h_862_0
 attribute [local irreducible] v_862_0
 attribute [local irreducible] s_863
 theorem r_863_0 (z : Store) : (s_863 z) 31 = (v_394_1 z) := pR (k_862 z) (pR (k_861 z) (pR (k_860 z) (pR (n_856_860 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_448_512 z) (pR (n_416_448 z) (pR (n_400_416 z) (pR (n_396_400 z) (pR (k_395 z) (w_394_1 z)))))))))))))
 #a r_863_0
 theorem r_863_1 (z : Store) : (s_863 z) 637 = (v_816_1 z) := pR (k_862 z) (pR (k_861 z) (pR (k_860 z) (pR (n_856_860 z) (pR (n_848_856 z) (pR (n_832_848 z) (pR (n_824_832 z) (pR (n_820_824 z) (pR (k_819 z) (pR (k_818 z) (pR (k_817 z) (w_816_1 z)))))))))))
 #a r_863_1
 def v_863_0 (z : Store) : Tensor := cross_dp_wred [(v_394_1 z), (v_816_1 z)]
 theorem g_863 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_231) (s_863 z) pmNode_231 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_231, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_863_1 z, r_863_0 z]
     exact (h_816_1 z z_).trans (h_394_1 z z_).symm
 #a g_863
 def s_864 (z : Store) : Store := storeSet (s_863 z) [(32, cross_dp_wred [((s_863 z) 31), ((s_863 z) 637)])]
 theorem t_863 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_231) (pmPeers pmNode_231) (s_863 z) pmNode_231 none = some (s_864 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_231) (s_863 z) pmNode_231 = _
   rw [wredStep, if_pos ⟨by decide, g_863 z z_⟩]
   rfl
 #a t_863
 theorem k_863 (z : Store) (tid : Tid) (h : tid ∉ [32]) : (s_864 z) tid = (s_863 z) tid := by
   unfold s_864
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_863
 theorem w_863_0 (z : Store) : (s_864 z) 32 = v_863_0 z := by
   unfold s_864
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_863_0, r_863_0 z, r_863_1 z] <;> rfl
 #a w_863_0
 theorem h_863_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_863_0 z).shape = [32, 64] := by
   unfold v_863_0
   rw [tensorSum_shape]
   exact h_394_1 z z_
 #a h_863_0
 attribute [local irreducible] v_863_0
 attribute [local irreducible] s_864
 theorem n_860_864 (z : Store) (tid : Tid) (h : tid ∉ ([58, 29, 65, 32] : List Tid)) : (s_864 z) tid = (s_860 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_860 z) (k_861 z)) (pF _ _ _ _ _ (k_862 z) (k_863 z)) tid h
 #a n_860_864
 theorem n_856_864 (z : Store) (tid : Tid) (h : tid ∉ ([42, 44, 46, 18, 58, 29, 65, 32] : List Tid)) : (s_864 z) tid = (s_856 z) tid := by
   exact pF _ _ _ _ _ (n_856_860 z) (n_860_864 z) tid h
 #a n_856_864
 theorem n_848_864 (z : Store) (tid : Tid) (h : tid ∉ ([62, 67, 69, 71, 34, 36, 38, 40, 42, 44, 46, 18, 58, 29, 65, 32] : List Tid)) : (s_864 z) tid = (s_848 z) tid := by
   exact pF _ _ _ _ _ (n_848_856 z) (n_856_864 z) tid h
 #a n_848_864
 theorem n_832_864 (z : Store) (tid : Tid) (h : tid ∉ ([890, 703, 696, 702, 1193, 1006, 999, 1005, 699, 625, 623, 1002, 928, 20, 22, 24, 60, 26, 62, 67, 69, 71, 34, 36, 38, 40, 42, 44, 46, 18, 58, 29, 65, 32] : List Tid)) : (s_864 z) tid = (s_832 z) tid := by
   exact pF _ _ _ _ _ (n_832_848 z) (n_848_864 z) tid h
 #a n_832_864
 theorem r_864_0 (z : Store) : (s_864 z) 73 = (v_217_1 z) := pR (n_832_864 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_256_512 z) (pR (n_224_256 z) (pR (n_220_224 z) (pR (k_219 z) (pR (k_218 z) (w_217_1 z))))))))
 #a r_864_0
 theorem r_864_1 (z : Store) : (s_864 z) 679 = (v_639_1 z) := pR (n_832_864 z) (pR (n_768_832 z) (pR (n_640_768 z) (w_639_1 z)))
 #a r_864_1
 def v_864_0 (z : Store) : Tensor := cross_dp_wred [(v_217_1 z), (v_639_1 z)]
 theorem g_864 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_232) (s_864 z) pmNode_232 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_232, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_864_1 z, r_864_0 z]
     exact (h_639_1 z z_).trans (h_217_1 z z_).symm
 #a g_864
 def s_865 (z : Store) : Store := storeSet (s_864 z) [(74, cross_dp_wred [((s_864 z) 73), ((s_864 z) 679)])]
 theorem t_864 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_232) (pmPeers pmNode_232) (s_864 z) pmNode_232 none = some (s_865 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_232) (s_864 z) pmNode_232 = _
   rw [wredStep, if_pos ⟨by decide, g_864 z z_⟩]
   rfl
 #a t_864
 theorem k_864 (z : Store) (tid : Tid) (h : tid ∉ [74]) : (s_865 z) tid = (s_864 z) tid := by
   unfold s_865
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_864
 theorem w_864_0 (z : Store) : (s_865 z) 74 = v_864_0 z := by
   unfold s_865
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_864_0, r_864_0 z, r_864_1 z] <;> rfl
 #a w_864_0
 theorem h_864_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_864_0 z).shape = [128, 64] := by
   unfold v_864_0
   rw [tensorSum_shape]
   exact h_217_1 z z_
 #a h_864_0
 attribute [local irreducible] v_864_0
 attribute [local irreducible] s_865
 theorem r_865_0 (z : Store) : (s_865 z) 48 = (v_311_1 z) := pR (k_864 z) (pR (n_832_864 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_320_384 z) (pR (n_312_320 z) (w_311_1 z)))))))
 #a r_865_0
 theorem r_865_1 (z : Store) : (s_865 z) 654 = (v_733_1 z) := pR (k_864 z) (pR (n_832_864 z) (pR (n_768_832 z) (pR (n_736_768 z) (pR (k_735 z) (pR (k_734 z) (w_733_1 z))))))
 #a r_865_1
 def v_865_0 (z : Store) : Tensor := cross_dp_wred [(v_311_1 z), (v_733_1 z)]
 theorem g_865 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_233) (s_865 z) pmNode_233 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_233, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_865_1 z, r_865_0 z]
     exact (h_733_1 z z_).trans (h_311_1 z z_).symm
 #a g_865
 def s_866 (z : Store) : Store := storeSet (s_865 z) [(49, cross_dp_wred [((s_865 z) 48), ((s_865 z) 654)])]
 theorem t_865 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_233) (pmPeers pmNode_233) (s_865 z) pmNode_233 none = some (s_866 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_233) (s_865 z) pmNode_233 = _
   rw [wredStep, if_pos ⟨by decide, g_865 z z_⟩]
   rfl
 #a t_865
 theorem k_865 (z : Store) (tid : Tid) (h : tid ∉ [49]) : (s_866 z) tid = (s_865 z) tid := by
   unfold s_866
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_865
 theorem w_865_0 (z : Store) : (s_866 z) 49 = v_865_0 z := by
   unfold s_866
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_865_0, r_865_0 z, r_865_1 z] <;> rfl
 #a w_865_0
 theorem h_865_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_865_0 z).shape = [32, 64] := by
   unfold v_865_0
   rw [tensorSum_shape]
   exact h_311_1 z z_
 #a h_865_0
 attribute [local irreducible] v_865_0
 attribute [local irreducible] s_866
 theorem r_866_0 (z : Store) : (s_866 z) 51 = (v_307_1 z) := pR (k_865 z) (pR (k_864 z) (pR (n_832_864 z) (pR (n_768_832 z) (pR (n_512_768 z) (pR (n_384_512 z) (pR (n_320_384 z) (pR (n_312_320 z) (pR (n_308_312 z) (w_307_1 z)))))))))
 #a r_866_0
 theorem r_866_1 (z : Store) : (s_866 z) 657 = (v_729_1 z) := pR (k_865 z) (pR (k_864 z) (pR (n_832_864 z) (pR (n_768_832 z) (pR (n_736_768 z) (pR (n_732_736 z) (pR (k_731 z) (pR (k_730 z) (w_729_1 z))))))))
 #a r_866_1
 def v_866_0 (z : Store) : Tensor := cross_dp_wred [(v_307_1 z), (v_729_1 z)]
 theorem g_866 (z : Store) (z_ : pmSeededPrefixInitShapes z) : WredContract [0, 2] (pmPeers pmNode_234) (s_866 z) pmNode_234 := by
   refine ⟨rfl, rfl, rfl, rfl, by decide, ?_⟩
   simp only [pmNode_234, List.headD_cons, List.mem_cons, List.not_mem_nil, or_false]
   intro tid ht
   rcases ht with rfl | rfl
   · rfl
   · rw [r_866_1 z, r_866_0 z]
     exact (h_729_1 z z_).trans (h_307_1 z z_).symm
 #a g_866
 def s_867 (z : Store) : Store := storeSet (s_866 z) [(52, cross_dp_wred [((s_866 z) 51), ((s_866 z) 657)])]
 theorem t_866 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_234) (pmPeers pmNode_234) (s_866 z) pmNode_234 none = some (s_867 z) := by
   change wredStep pmGraph (some [0, 2]) (pmPeers pmNode_234) (s_866 z) pmNode_234 = _
   rw [wredStep, if_pos ⟨by decide, g_866 z z_⟩]
   rfl
 #a t_866
 theorem k_866 (z : Store) (tid : Tid) (h : tid ∉ [52]) : (s_867 z) tid = (s_866 z) tid := by
   unfold s_867
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_866
 theorem w_866_0 (z : Store) : (s_867 z) 52 = v_866_0 z := by
   unfold s_867
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_866_0, r_866_0 z, r_866_1 z] <;> rfl
 #a w_866_0
 theorem h_866_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_866_0 z).shape = [64, 32] := by
   unfold v_866_0
   rw [tensorSum_shape]
   exact h_307_1 z z_
 #a h_866_0
 attribute [local irreducible] v_866_0
 attribute [local irreducible] s_867
 record_prefix_opacity v_859_0 s_860 v_860_0 s_861 v_861_0 s_862 v_862_0 s_863 v_863_0 s_864 v_864_0 s_865 v_865_0 s_866 v_866_0 s_867

 end
 end TrainVerify.Denote.RuntimeWorld
