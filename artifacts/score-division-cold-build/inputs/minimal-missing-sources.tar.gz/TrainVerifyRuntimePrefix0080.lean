import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0079
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_640_0 (z : Store) : (s_640 z) 888 = (v_635_0 z) := pR (k_639 z) (pR (k_638 z) (r_638_0 z))
 #a r_640_0
 theorem r_640_1 (z : Store) : (s_640 z) 1191 = (v_637_0 z) := pR (k_639 z) (pR (k_638 z) (r_638_1 z))
 #a r_640_1
 def v_640_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_635_0 z), (v_637_0 z)]
 theorem g_640 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_816) (s_640 z) pmNode_816 1 2 1188 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 256], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_816, r_640_0 z, r_640_1 z, h_635_0 z z_, h_637_0 z z_]
 #a g_640
 def s_641 (z : Store) : Store := pL [2, 3] (s_640 z) pmNode_816 1 2
 theorem t_640 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_816) (pmPeers pmNode_816) (s_640 z) pmNode_816 none = some (s_641 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_816) (s_640 z) pmNode_816).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 1188 (by decide) (g_640 z z_)]
   rfl
 #a t_640
 theorem k_640 (z : Store) (tid : Tid) (h : tid ∉ [1188]) : (s_641 z) tid = (s_640 z) tid := by
   unfold s_641
   dsimp only [pL, pmNode_816, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_640
 theorem w_640_0 (z : Store) : (s_641 z) 1188 = v_640_0 z := by
   unfold s_641
   dsimp only [pL, pmNode_816, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_640_0, r_640_0 z, r_640_1 z] <;> rfl
 #a w_640_0
 theorem h_640_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_640_0 z).shape = [1, 16, 128] := by
   unfold v_640_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_635_0 z z_]
 #a h_640_0
 attribute [local irreducible] v_640_0
 attribute [local irreducible] s_641
 theorem n_636_640 (z : Store) (tid : Tid) (h : tid ∉ ([986, 1191, 884, 885, 679] : List Tid)) : (s_640 z) tid = (s_636 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_636 z) (k_637 z)) (pF _ _ _ _ _ (k_638 z) (k_639 z)) tid h
 #a n_636_640
 theorem n_632_640 (z : Store) (tid : Tid) (h : tid ∉ ([1189, 1190, 683, 888, 986, 1191, 884, 885, 679] : List Tid)) : (s_640 z) tid = (s_632 z) tid := by
   exact pF _ _ _ _ _ (n_632_636 z) (n_636_640 z) tid h
 #a n_632_640
 theorem r_641_0 (z : Store) : (s_641 z) 1188 = (v_640_0 z) := w_640_0 z
 #a r_641_0
 theorem r_641_1 (z : Store) : (s_641 z) 989 = (v_628_0 z) := pR (k_640 z) (pR (n_632_640 z) (pR (k_631 z) (pR (k_630 z) (pR (k_629 z) (r_629_0 z)))))
 #a r_641_1
 theorem r_641_2 (z : Store) : (s_641 z) 981 = (z 981) := pR (k_640 z) (pR (n_632_640 z) (pR (k_631 z) (pR (k_630 z) (pR (k_629 z) (r_629_1 z)))))
 #a r_641_2
 def v_641_0 (z : Store) : Tensor := (bw_linear (v_640_0 z) (v_628_0 z) (z 981)).1
 def v_641_1 (z : Store) : Tensor := (bw_linear (v_640_0 z) (v_628_0 z) (z 981)).2
 def s_642 (z : Store) : Store := storeSet (s_641 z) [(1187, (bw_linear ((s_641 z) 1188) ((s_641 z) 989) ((s_641 z) 981)).1), (982, (bw_linear ((s_641 z) 1188) ((s_641 z) 989) ((s_641 z) 981)).2)]
 theorem t_641 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_817) (pmPeers pmNode_817) (s_641 z) pmNode_817 none = some (s_642 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_641
 theorem k_641 (z : Store) (tid : Tid) (h : tid ∉ [1187, 982]) : (s_642 z) tid = (s_641 z) tid := by
   unfold s_642
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_641
 theorem w_641_0 (z : Store) : (s_642 z) 1187 = v_641_0 z := by
   unfold s_642
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_641_0, r_641_0 z, r_641_1 z, r_641_2 z] <;> rfl
 #a w_641_0
 theorem h_641_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_641_0 z).shape = [1, 16, 64] := by
   unfold v_641_0
   exact bw_linear_3d_fst_shape 1 16 128 64 (v_640_0 z) (v_628_0 z) (z 981) (h_640_0 z z_) (h_628_0 z z_) (i_99 z z_)
 #a h_641_0
 attribute [local irreducible] v_641_0
 theorem w_641_1 (z : Store) : (s_642 z) 982 = v_641_1 z := by
   unfold s_642
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_641_1, r_641_0 z, r_641_1 z, r_641_2 z] <;> rfl
 #a w_641_1
 theorem h_641_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_641_1 z).shape = [128, 64] := by
   unfold v_641_1
   exact bw_linear_3d_snd_shape 1 16 128 64 (v_640_0 z) (v_628_0 z) (z 981) (h_640_0 z z_) (h_628_0 z z_) (i_99 z z_)
 #a h_641_1
 attribute [local irreducible] v_641_1
 attribute [local irreducible] s_642
 theorem r_642_0 (z : Store) : (s_642 z) 885 = (v_639_0 z) := pR (k_641 z) (pR (k_640 z) (w_639_0 z))
 #a r_642_0
 theorem r_642_1 (z : Store) : (s_642 z) 1187 = (v_641_0 z) := w_641_0 z
 #a r_642_1
 def v_642_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_639_0 z), (v_641_0 z)]
 def s_643 (z : Store) : Store := storeSet (s_642 z) [(882, reduceScatterPrimDimN 1 2 0 [((s_642 z) 885), ((s_642 z) 1187)])]
 theorem t_642 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_582) (pmPeers pmNode_582) (s_642 z) pmNode_582 none = some (s_643 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_642 z) pmNode_582 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_642
 theorem k_642 (z : Store) (tid : Tid) (h : tid ∉ [882]) : (s_643 z) tid = (s_642 z) tid := by
   unfold s_643
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_642
 theorem w_642_0 (z : Store) : (s_643 z) 882 = v_642_0 z := by
   unfold s_643
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_642_0, r_642_0 z, r_642_1 z] <;> rfl
 #a w_642_0
 theorem h_642_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_642_0 z).shape = [1, 8, 64] := by
   unfold v_642_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_639_0 z) rfl]
     exact h_639_0 z z_
   · decide
 #a h_642_0
 attribute [local irreducible] v_642_0
 attribute [local irreducible] s_643
 theorem n_624_640 (z : Store) (tid : Tid) (h : tid ∉ ([1181, 1184, 686, 883, 989, 1186, 886, 887, 1189, 1190, 683, 888, 986, 1191, 884, 885, 679] : List Tid)) : (s_640 z) tid = (s_624 z) tid := by
   exact pF _ _ _ _ _ (n_624_632 z) (n_632_640 z) tid h
 #a n_624_640
 theorem r_643_0 (z : Store) : (s_643 z) 882 = (v_642_0 z) := w_642_0 z
 #a r_643_0
 theorem r_643_1 (z : Store) : (s_643 z) 878 = (v_618_0 z) := pR (k_642 z) (pR (k_641 z) (pR (k_640 z) (pR (n_624_640 z) (pR (n_620_624 z) (pR (k_619 z) (r_619_0 z))))))
 #a r_643_1
 theorem r_643_2 (z : Store) : (s_643 z) 620 = (z 620) := pR (k_642 z) (pR (k_641 z) (pR (k_640 z) (pR (n_624_640 z) (pR (n_620_624 z) (pR (k_619 z) (r_619_1 z))))))
 #a r_643_2
 theorem r_643_3 (z : Store) : (s_643 z) 621 = (z 621) := pR (k_642 z) (pR (k_641 z) (pR (k_640 z) (pR (n_624_640 z) (pR (n_620_624 z) (pR (k_619 z) (r_619_2 z))))))
 #a r_643_3
 def v_643_0 (z : Store) : Tensor := (bw_layernorm (v_642_0 z) (v_618_0 z) (z 620) (z 621)).1
 def v_643_1 (z : Store) : Tensor := (bw_layernorm (v_642_0 z) (v_618_0 z) (z 620) (z 621)).2.1
 def v_643_2 (z : Store) : Tensor := (bw_layernorm (v_642_0 z) (v_618_0 z) (z 620) (z 621)).2.2
 def s_644 (z : Store) : Store := storeSet (s_643 z) [(880, (bw_layernorm ((s_643 z) 882) ((s_643 z) 878) ((s_643 z) 620) ((s_643 z) 621)).1), (674, (bw_layernorm ((s_643 z) 882) ((s_643 z) 878) ((s_643 z) 620) ((s_643 z) 621)).2.1), (676, (bw_layernorm ((s_643 z) 882) ((s_643 z) 878) ((s_643 z) 620) ((s_643 z) 621)).2.2)]
 theorem t_643 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_583) (pmPeers pmNode_583) (s_643 z) pmNode_583 none = some (s_644 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_643
 theorem k_643 (z : Store) (tid : Tid) (h : tid ∉ [880, 674, 676]) : (s_644 z) tid = (s_643 z) tid := by
   unfold s_644
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_643
 theorem w_643_0 (z : Store) : (s_644 z) 880 = v_643_0 z := by
   unfold s_644
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_643_0, r_643_0 z, r_643_1 z, r_643_2 z, r_643_3 z] <;> rfl
 #a w_643_0
 theorem h_643_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_643_0 z).shape = [1, 8, 64] := by
   unfold v_643_0
   rw [bw_layernorm_dx_shape (v_642_0 z) (v_618_0 z) (z 620) (z 621) 64 [8, 1] (by rw [h_618_0 z z_]; rfl)]
   exact h_618_0 z z_
 #a h_643_0
 attribute [local irreducible] v_643_0
 theorem w_643_1 (z : Store) : (s_644 z) 674 = v_643_1 z := by
   unfold s_644
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_643_1, r_643_0 z, r_643_1 z, r_643_2 z, r_643_3 z] <;> rfl
 #a w_643_1
 theorem h_643_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_643_1 z).shape = [64] := by
   unfold v_643_1
   rw [bw_layernorm_dw_shape (v_642_0 z) (v_618_0 z) (z 620) (z 621) 64 [8, 1] (by rw [h_618_0 z z_]; rfl)]
   exact i_93 z z_
 #a h_643_1
 attribute [local irreducible] v_643_1
 theorem w_643_2 (z : Store) : (s_644 z) 676 = v_643_2 z := by
   unfold s_644
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_643_2, r_643_0 z, r_643_1 z, r_643_2 z, r_643_3 z] <;> rfl
 #a w_643_2
 theorem h_643_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_643_2 z).shape = [64] := by
   unfold v_643_2
   rw [bw_layernorm_db_shape (v_642_0 z) (v_618_0 z) (z 620) (z 621) 64 [8, 1] (by rw [h_618_0 z z_]; rfl)]
   exact i_94 z z_
 #a h_643_2
 attribute [local irreducible] v_643_2
 attribute [local irreducible] s_644
 theorem n_640_644 (z : Store) (tid : Tid) (h : tid ∉ ([1188, 1187, 982, 882, 880, 674, 676] : List Tid)) : (s_644 z) tid = (s_640 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_640 z) (k_641 z)) (pF _ _ _ _ _ (k_642 z) (k_643 z)) tid h
 #a n_640_644
 theorem r_644_0 (z : Store) : (s_644 z) 880 = (v_643_0 z) := w_643_0 z
 #a r_644_0
 theorem r_644_1 (z : Store) : (s_644 z) 877 = (v_617_0 z) := pR (n_640_644 z) (pR (n_624_640 z) (pR (n_620_624 z) (pR (k_619 z) (pR (k_618 z) (r_618_0 z)))))
 #a r_644_1
 theorem r_644_2 (z : Store) : (s_644 z) 875 = (v_616_0 z) := pR (n_640_644 z) (pR (n_624_640 z) (pR (n_620_624 z) (pR (k_619 z) (pR (k_618 z) (r_618_1 z)))))
 #a r_644_2
 def v_644_0 (z : Store) : Tensor := (bw_add2 (v_643_0 z) (v_617_0 z) (v_616_0 z)).1
 def v_644_1 (z : Store) : Tensor := (bw_add2 (v_643_0 z) (v_617_0 z) (v_616_0 z)).2
 def s_645 (z : Store) : Store := storeSet (s_644 z) [(879, (bw_add2 ((s_644 z) 880) ((s_644 z) 877) ((s_644 z) 875)).1), (876, (bw_add2 ((s_644 z) 880) ((s_644 z) 877) ((s_644 z) 875)).2)]
 theorem t_644 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_584) (pmPeers pmNode_584) (s_644 z) pmNode_584 none = some (s_645 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_644
 theorem k_644 (z : Store) (tid : Tid) (h : tid ∉ [879, 876]) : (s_645 z) tid = (s_644 z) tid := by
   unfold s_645
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_644
 theorem w_644_0 (z : Store) : (s_645 z) 879 = v_644_0 z := by
   unfold s_645
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_644_0, r_644_0 z, r_644_1 z, r_644_2 z] <;> rfl
 #a w_644_0
 theorem h_644_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_644_0 z).shape = [1, 8, 64] := by
   unfold v_644_0
   exact h_617_0 z z_
 #a h_644_0
 attribute [local irreducible] v_644_0
 theorem w_644_1 (z : Store) : (s_645 z) 876 = v_644_1 z := by
   unfold s_645
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_644_1, r_644_0 z, r_644_1 z, r_644_2 z] <;> rfl
 #a w_644_1
 theorem h_644_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_644_1 z).shape = [1, 8, 64] := by
   unfold v_644_1
   exact h_616_0 z z_
 #a h_644_1
 attribute [local irreducible] v_644_1
 attribute [local irreducible] s_645
 theorem r_645_0 (z : Store) : (s_645 z) 885 = (v_639_0 z) := pR (k_644 z) (pR (k_643 z) (pR (k_642 z) (r_642_0 z)))
 #a r_645_0
 theorem r_645_1 (z : Store) : (s_645 z) 1187 = (v_641_0 z) := pR (k_644 z) (pR (k_643 z) (pR (k_642 z) (r_642_1 z)))
 #a r_645_1
 def v_645_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_639_0 z), (v_641_0 z)]
 def s_646 (z : Store) : Store := storeSet (s_645 z) [(1185, reduceScatterPrimDimN 1 2 1 [((s_645 z) 885), ((s_645 z) 1187)])]
 theorem t_645 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_818) (pmPeers pmNode_818) (s_645 z) pmNode_818 none = some (s_646 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_645 z) pmNode_818 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_645
 theorem k_645 (z : Store) (tid : Tid) (h : tid ∉ [1185]) : (s_646 z) tid = (s_645 z) tid := by
   unfold s_646
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_645
 theorem w_645_0 (z : Store) : (s_646 z) 1185 = v_645_0 z := by
   unfold s_646
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_645_0, r_645_0 z, r_645_1 z] <;> rfl
 #a w_645_0
 theorem h_645_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_645_0 z).shape = [1, 8, 64] := by
   unfold v_645_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_639_0 z) rfl]
     exact h_639_0 z z_
   · decide
 #a h_645_0
 attribute [local irreducible] v_645_0
 attribute [local irreducible] s_646
 record_prefix_opacity v_640_0 s_641 v_641_0 v_641_1 s_642 v_642_0 s_643 v_643_0 v_643_1 v_643_2 s_644 v_644_0 v_644_1 s_645 v_645_0 s_646

 end
 end TrainVerify.Denote.RuntimeWorld
