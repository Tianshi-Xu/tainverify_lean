import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0125
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
open SourceScopedEval
set_option maxHeartbeats 500000
set_option maxRecDepth 4096
restore_prefix_opacity
theorem smSeededWholeStep_79 (s : Store) : stepWithInputs smGraph (smScope smNode_79) (smPeers smNode_79) s smNode_79 (none) =
    some (smSeededWholeAdvance s (smNode_79, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_79

theorem smSeededWholeStep_80 (s : Store) : stepWithInputs smGraph (smScope smNode_80) (smPeers smNode_80) s smNode_80 (none) =
    some (smSeededWholeAdvance s (smNode_80, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_80

theorem smSeededWholeStep_81 (s : Store) : stepWithInputs smGraph (smScope smNode_81) (smPeers smNode_81) s smNode_81 (none) =
    some (smSeededWholeAdvance s (smNode_81, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_81

theorem smSeededWholeStep_82 (s : Store) : stepWithInputs smGraph (smScope smNode_82) (smPeers smNode_82) s smNode_82 (none) =
    some (smSeededWholeAdvance s (smNode_82, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_82

theorem smSeededWholeStep_83 (s : Store) : stepWithInputs smGraph (smScope smNode_83) (smPeers smNode_83) s smNode_83 (none) =
    some (smSeededWholeAdvance s (smNode_83, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_83

theorem smSeededWholeStep_84 (s : Store) : stepWithInputs smGraph (smScope smNode_84) (smPeers smNode_84) s smNode_84 (none) =
    some (smSeededWholeAdvance s (smNode_84, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_84

theorem smSeededWholeStep_85 (s : Store) : stepWithInputs smGraph (smScope smNode_85) (smPeers smNode_85) s smNode_85 (none) =
    some (smSeededWholeAdvance s (smNode_85, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_85

theorem smSeededWholeStep_86 (s : Store) : stepWithInputs smGraph (smScope smNode_86) (smPeers smNode_86) s smNode_86 (none) =
    some (smSeededWholeAdvance s (smNode_86, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_86

theorem smSeededWholeStep_87 (s : Store) : stepWithInputs smGraph (smScope smNode_87) (smPeers smNode_87) s smNode_87 (none) =
    some (smSeededWholeAdvance s (smNode_87, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_87

theorem smSeededWholeStep_88 (s : Store) : stepWithInputs smGraph (smScope smNode_88) (smPeers smNode_88) s smNode_88 (none) =
    some (smSeededWholeAdvance s (smNode_88, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_88

theorem smSeededWholeStep_89 (s : Store) : stepWithInputs smGraph (smScope smNode_89) (smPeers smNode_89) s smNode_89 (none) =
    some (smSeededWholeAdvance s (smNode_89, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_89

theorem smSeededWholeStep_90 (s : Store) : stepWithInputs smGraph (smScope smNode_90) (smPeers smNode_90) s smNode_90 (none) =
    some (smSeededWholeAdvance s (smNode_90, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_90

theorem smSeededWholeStep_91 (s : Store) : stepWithInputs smGraph (smScope smNode_91) (smPeers smNode_91) s smNode_91 (none) =
    some (smSeededWholeAdvance s (smNode_91, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_91

theorem smSeededWholeStep_92 (s : Store) : stepWithInputs smGraph (smScope smNode_92) (smPeers smNode_92) s smNode_92 (none) =
    some (smSeededWholeAdvance s (smNode_92, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_92

theorem smSeededWholeStep_93 (s : Store) : stepWithInputs smGraph (smScope smNode_93) (smPeers smNode_93) s smNode_93 (none) =
    some (smSeededWholeAdvance s (smNode_93, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_93

theorem smSeededWholeStep_94 (s : Store) : stepWithInputs smGraph (smScope smNode_94) (smPeers smNode_94) s smNode_94 (none) =
    some (smSeededWholeAdvance s (smNode_94, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_94

theorem smSeededWholeStep_95 (s : Store) : stepWithInputs smGraph (smScope smNode_95) (smPeers smNode_95) s smNode_95 (none) =
    some (smSeededWholeAdvance s (smNode_95, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_95

theorem smSeededWholeStep_96 (s : Store) : stepWithInputs smGraph (smScope smNode_96) (smPeers smNode_96) s smNode_96 (none) =
    some (smSeededWholeAdvance s (smNode_96, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_96

theorem smSeededWholeStep_97 (s : Store) : stepWithInputs smGraph (smScope smNode_97) (smPeers smNode_97) s smNode_97 (none) =
    some (smSeededWholeAdvance s (smNode_97, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_97

theorem smSeededWholeStep_98 (s : Store) : stepWithInputs smGraph (smScope smNode_98) (smPeers smNode_98) s smNode_98 (none) =
    some (smSeededWholeAdvance s (smNode_98, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_98

theorem smSeededWholeStep_99 (s : Store) : stepWithInputs smGraph (smScope smNode_99) (smPeers smNode_99) s smNode_99 (none) =
    some (smSeededWholeAdvance s (smNode_99, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_99

theorem smSeededWholeStep_100 (s : Store) : stepWithInputs smGraph (smScope smNode_100) (smPeers smNode_100) s smNode_100 (none) =
    some (smSeededWholeAdvance s (smNode_100, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_100

theorem smSeededWholeStep_101 (s : Store) : stepWithInputs smGraph (smScope smNode_101) (smPeers smNode_101) s smNode_101 (none) =
    some (smSeededWholeAdvance s (smNode_101, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_101

theorem smSeededWholeStep_102 (s : Store) : stepWithInputs smGraph (smScope smNode_102) (smPeers smNode_102) s smNode_102 (none) =
    some (smSeededWholeAdvance s (smNode_102, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_102

theorem smSeededWholeStep_103 (s : Store) : stepWithInputs smGraph (smScope smNode_103) (smPeers smNode_103) s smNode_103 (none) =
    some (smSeededWholeAdvance s (smNode_103, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_103

theorem smSeededWholeStep_104 (s : Store) : stepWithInputs smGraph (smScope smNode_104) (smPeers smNode_104) s smNode_104 (none) =
    some (smSeededWholeAdvance s (smNode_104, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_104

theorem smSeededWholeStep_105 (s : Store) : stepWithInputs smGraph (smScope smNode_105) (smPeers smNode_105) s smNode_105 (none) =
    some (smSeededWholeAdvance s (smNode_105, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_105

theorem smSeededWholeStep_106 (s : Store) : stepWithInputs smGraph (smScope smNode_106) (smPeers smNode_106) s smNode_106 (none) =
    some (smSeededWholeAdvance s (smNode_106, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_106

theorem smSeededWholeStep_107 (s : Store) : stepWithInputs smGraph (smScope smNode_107) (smPeers smNode_107) s smNode_107 (none) =
    some (smSeededWholeAdvance s (smNode_107, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_107

theorem smSeededWholeStep_108 (s : Store) : stepWithInputs smGraph (smScope smNode_108) (smPeers smNode_108) s smNode_108 (none) =
    some (smSeededWholeAdvance s (smNode_108, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_108

theorem smSeededWholeStep_109 (s : Store) : stepWithInputs smGraph (smScope smNode_109) (smPeers smNode_109) s smNode_109 (none) =
    some (smSeededWholeAdvance s (smNode_109, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_109

theorem smSeededWholeStep_110 (s : Store) : stepWithInputs smGraph (smScope smNode_110) (smPeers smNode_110) s smNode_110 (none) =
    some (smSeededWholeAdvance s (smNode_110, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_110

theorem smSeededWholeStep_111 (s : Store) : stepWithInputs smGraph (smScope smNode_111) (smPeers smNode_111) s smNode_111 (none) =
    some (smSeededWholeAdvance s (smNode_111, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_111

theorem smSeededWholeStep_112 (s : Store) : stepWithInputs smGraph (smScope smNode_112) (smPeers smNode_112) s smNode_112 (none) =
    some (smSeededWholeAdvance s (smNode_112, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_112

theorem smSeededWholeStep_113 (s : Store) : stepWithInputs smGraph (smScope smNode_113) (smPeers smNode_113) s smNode_113 (none) =
    some (smSeededWholeAdvance s (smNode_113, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_113

theorem smSeededWholeStep_114 (s : Store) : stepWithInputs smGraph (smScope smNode_114) (smPeers smNode_114) s smNode_114 (none) =
    some (smSeededWholeAdvance s (smNode_114, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_114

theorem smSeededWholeStep_115 (s : Store) : stepWithInputs smGraph (smScope smNode_115) (smPeers smNode_115) s smNode_115 (none) =
    some (smSeededWholeAdvance s (smNode_115, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_115

theorem smSeededWholeStep_116 (s : Store) : stepWithInputs smGraph (smScope smNode_116) (smPeers smNode_116) s smNode_116 (none) =
    some (smSeededWholeAdvance s (smNode_116, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_116

theorem smSeededWholeStep_117 (s : Store) : stepWithInputs smGraph (smScope smNode_117) (smPeers smNode_117) s smNode_117 (none) =
    some (smSeededWholeAdvance s (smNode_117, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_117

theorem smSeededWholeStep_118 (s : Store) : stepWithInputs smGraph (smScope smNode_118) (smPeers smNode_118) s smNode_118 (none) =
    some (smSeededWholeAdvance s (smNode_118, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_118

theorem smSeededWholeStep_119 (s : Store) : stepWithInputs smGraph (smScope smNode_119) (smPeers smNode_119) s smNode_119 (none) =
    some (smSeededWholeAdvance s (smNode_119, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_119

theorem smSeededWholeStep_120 (s : Store) : stepWithInputs smGraph (smScope smNode_120) (smPeers smNode_120) s smNode_120 (none) =
    some (smSeededWholeAdvance s (smNode_120, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_120

theorem smSeededWholeStep_121 (s : Store) : stepWithInputs smGraph (smScope smNode_121) (smPeers smNode_121) s smNode_121 (none) =
    some (smSeededWholeAdvance s (smNode_121, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_121

theorem smSeededWholeStep_122 (s : Store) : stepWithInputs smGraph (smScope smNode_122) (smPeers smNode_122) s smNode_122 (none) =
    some (smSeededWholeAdvance s (smNode_122, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_122

theorem smSeededWholeStep_123 (s : Store) : stepWithInputs smGraph (smScope smNode_123) (smPeers smNode_123) s smNode_123 (none) =
    some (smSeededWholeAdvance s (smNode_123, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_123

theorem smSeededWholeStep_124 (s : Store) : stepWithInputs smGraph (smScope smNode_124) (smPeers smNode_124) s smNode_124 (none) =
    some (smSeededWholeAdvance s (smNode_124, none)) := by
  change some (applyNode _ _ _) = _
  rfl
#print axioms smSeededWholeStep_124

theorem smSeededWholeSteps (row : InputRequest) (h : row ∈ smInputRequests) (s : Store) :
    (fun row s => stepWithInputs smGraph (smScope row.1) (smPeers row.1) s row.1 row.2) row s = some (smSeededWholeAdvance s row) := by
  simp only [smInputRequests, List.mem_cons, List.not_mem_nil, or_false] at h
  rcases h with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact smSeededWholeStep_0 s
  · exact smSeededWholeStep_1 s
  · exact smSeededWholeStep_2 s
  · exact smSeededWholeStep_3 s
  · exact smSeededWholeStep_4 s
  · exact smSeededWholeStep_5 s
  · exact smSeededWholeStep_6 s
  · exact smSeededWholeStep_7 s
  · exact smSeededWholeStep_8 s
  · exact smSeededWholeStep_9 s
  · exact smSeededWholeStep_10 s
  · exact smSeededWholeStep_11 s
  · exact smSeededWholeStep_12 s
  · exact smSeededWholeStep_13 s
  · exact smSeededWholeStep_14 s
  · exact smSeededWholeStep_15 s
  · exact smSeededWholeStep_16 s
  · exact smSeededWholeStep_17 s
  · exact smSeededWholeStep_18 s
  · exact smSeededWholeStep_19 s
  · exact smSeededWholeStep_20 s
  · exact smSeededWholeStep_21 s
  · exact smSeededWholeStep_22 s
  · exact smSeededWholeStep_23 s
  · exact smSeededWholeStep_24 s
  · exact smSeededWholeStep_25 s
  · exact smSeededWholeStep_26 s
  · exact smSeededWholeStep_27 s
  · exact smSeededWholeStep_28 s
  · exact smSeededWholeStep_29 s
  · exact smSeededWholeStep_30 s
  · exact smSeededWholeStep_31 s
  · exact smSeededWholeStep_32 s
  · exact smSeededWholeStep_33 s
  · exact smSeededWholeStep_34 s
  · exact smSeededWholeStep_35 s
  · exact smSeededWholeStep_36 s
  · exact smSeededWholeStep_37 s
  · exact smSeededWholeStep_38 s
  · exact smSeededWholeStep_39 s
  · exact smSeededWholeStep_40 s
  · exact smSeededWholeStep_41 s
  · exact smSeededWholeStep_42 s
  · exact smSeededWholeStep_43 s
  · exact smSeededWholeStep_44 s
  · exact smSeededWholeStep_45 s
  · exact smSeededWholeStep_46 s
  · exact smSeededWholeStep_47 s
  · exact smSeededWholeStep_48 s
  · exact smSeededWholeStep_49 s
  · exact smSeededWholeStep_50 s
  · exact smSeededWholeStep_51 s
  · exact smSeededWholeStep_52 s
  · exact smSeededWholeStep_53 s
  · exact smSeededWholeStep_54 s
  · exact smSeededWholeStep_55 s
  · exact smSeededWholeStep_56 s
  · exact smSeededWholeStep_57 s
  · exact smSeededWholeStep_58 s
  · exact smSeededWholeStep_59 s
  · exact smSeededWholeStep_60 s
  · exact smSeededWholeStep_61 s
  · exact smSeededWholeStep_62 s
  · exact smSeededWholeStep_63 s
  · exact smSeededWholeStep_64 s
  · exact smSeededWholeStep_65 s
  · exact smSeededWholeStep_66 s
  · exact smSeededWholeStep_67 s
  · exact smSeededWholeStep_68 s
  · exact smSeededWholeStep_69 s
  · exact smSeededWholeStep_70 s
  · exact smSeededWholeStep_71 s
  · exact smSeededWholeStep_72 s
  · exact smSeededWholeStep_73 s
  · exact smSeededWholeStep_74 s
  · exact smSeededWholeStep_75 s
  · exact smSeededWholeStep_76 s
  · exact smSeededWholeStep_77 s
  · exact smSeededWholeStep_78 s
  · exact smSeededWholeStep_79 s
  · exact smSeededWholeStep_80 s
  · exact smSeededWholeStep_81 s
  · exact smSeededWholeStep_82 s
  · exact smSeededWholeStep_83 s
  · exact smSeededWholeStep_84 s
  · exact smSeededWholeStep_85 s
  · exact smSeededWholeStep_86 s
  · exact smSeededWholeStep_87 s
  · exact smSeededWholeStep_88 s
  · exact smSeededWholeStep_89 s
  · exact smSeededWholeStep_90 s
  · exact smSeededWholeStep_91 s
  · exact smSeededWholeStep_92 s
  · exact smSeededWholeStep_93 s
  · exact smSeededWholeStep_94 s
  · exact smSeededWholeStep_95 s
  · exact smSeededWholeStep_96 s
  · exact smSeededWholeStep_97 s
  · exact smSeededWholeStep_98 s
  · exact smSeededWholeStep_99 s
  · exact smSeededWholeStep_100 s
  · exact smSeededWholeStep_101 s
  · exact smSeededWholeStep_102 s
  · exact smSeededWholeStep_103 s
  · exact smSeededWholeStep_104 s
  · exact smSeededWholeStep_105 s
  · exact smSeededWholeStep_106 s
  · exact smSeededWholeStep_107 s
  · exact smSeededWholeStep_108 s
  · exact smSeededWholeStep_109 s
  · exact smSeededWholeStep_110 s
  · exact smSeededWholeStep_111 s
  · exact smSeededWholeStep_112 s
  · exact smSeededWholeStep_113 s
  · exact smSeededWholeStep_114 s
  · exact smSeededWholeStep_115 s
  · exact smSeededWholeStep_116 s
  · exact smSeededWholeStep_117 s
  · exact smSeededWholeStep_118 s
  · exact smSeededWholeStep_119 s
  · exact smSeededWholeStep_120 s
  · exact smSeededWholeStep_121 s
  · exact smSeededWholeStep_122 s
  · exact smSeededWholeStep_123 s
  · exact smSeededWholeStep_124 s
#print axioms smSeededWholeSteps

def smSeededWholeState (init : Store) : Store := smInputRequests.foldl smSeededWholeAdvance (smInitialWithSeeds init)

end
end TrainVerify.Denote.RuntimeWorld
