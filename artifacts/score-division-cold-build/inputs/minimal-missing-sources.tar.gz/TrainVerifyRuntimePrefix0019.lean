import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0018
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_138_0 (z : Store) : (s_138 z) 207 = (v_129_0 z) := pR (k_137 z) (pR (k_136 z) (pR (k_135 z) (pR (k_134 z) (r_134_0 z))))
 #a r_138_0
 theorem r_138_1 (z : Store) : (s_138 z) 510 = (v_133_0 z) := pR (k_137 z) (pR (k_136 z) (pR (k_135 z) (pR (k_134 z) (r_134_1 z))))
 #a r_138_1
 def v_138_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_129_0 z), (v_133_0 z)]
 theorem g_138 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_303) (s_138 z) pmNode_303 1 3 513 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_303, r_138_0 z, r_138_1 z, h_129_0 z z_, h_133_0 z z_]
 #a g_138
 def s_139 (z : Store) : Store := pL [0, 1] (s_138 z) pmNode_303 1 3
 theorem t_138 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_303) (pmPeers pmNode_303) (s_138 z) pmNode_303 none = some (s_139 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_303) (s_138 z) pmNode_303).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 513 (by decide) (g_138 z z_)]
   rfl
 #a t_138
 theorem k_138 (z : Store) (tid : Tid) (h : tid ∉ [513]) : (s_139 z) tid = (s_138 z) tid := by
   unfold s_139
   dsimp only [pL, pmNode_303, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_138
 theorem w_138_0 (z : Store) : (s_139 z) 513 = v_138_0 z := by
   unfold s_139
   dsimp only [pL, pmNode_303, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_138_0, r_138_0 z, r_138_1 z] <;> rfl
 #a w_138_0
 theorem h_138_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_138_0 z).shape = [1, 16, 4, 8] := by
   unfold v_138_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_129_0 z z_]
 #a h_138_0
 attribute [local irreducible] v_138_0
 attribute [local irreducible] s_139
 theorem r_139_0 (z : Store) : (s_139 z) 513 = (v_138_0 z) := w_138_0 z
 #a r_139_0
 def v_139_0 (z : Store) : Tensor := transposeAxes 1 2 (v_138_0 z)
 def s_140 (z : Store) : Store := storeSet (s_139 z) [(514, transposeAxes 1 2 ((s_139 z) 513))]
 theorem t_139 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_304) (pmPeers pmNode_304) (s_139 z) pmNode_304 none = some (s_140 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_139
 theorem k_139 (z : Store) (tid : Tid) (h : tid ∉ [514]) : (s_140 z) tid = (s_139 z) tid := by
   unfold s_140
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_139
 theorem w_139_0 (z : Store) : (s_140 z) 514 = v_139_0 z := by
   unfold s_140
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_139_0, r_139_0 z] <;> rfl
 #a w_139_0
 theorem h_139_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_139_0 z).shape = [1, 4, 16, 8] := by
   unfold v_139_0
   change listSwapAt _ _ _ = _
   rw [h_138_0 z z_]
   rfl
 #a h_139_0
 attribute [local irreducible] v_139_0
 attribute [local irreducible] s_140
 theorem n_136_140 (z : Store) (tid : Tid) (h : tid ∉ ([214, 215, 513, 514] : List Tid)) : (s_140 z) tid = (s_136 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_136 z) (k_137 z)) (pF _ _ _ _ _ (k_138 z) (k_139 z)) tid h
 #a n_136_140
 theorem r_140_0 (z : Store) : (s_140 z) 196 = (v_115_0 z) := pR (n_136_140 z) (r_136_0 z)
 #a r_140_0
 theorem r_140_1 (z : Store) : (s_140 z) 499 = (v_123_0 z) := pR (n_136_140 z) (r_136_1 z)
 #a r_140_1
 def v_140_0 (z : Store) : Tensor := reduceScatterPrimDimN 2 2 1 [(v_115_0 z), (v_123_0 z)]
 def s_141 (z : Store) : Store := storeSet (s_140 z) [(517, reduceScatterPrimDimN 2 2 1 [((s_140 z) 196), ((s_140 z) 499)])]
 theorem t_140 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_305) (pmPeers pmNode_305) (s_140 z) pmNode_305 none = some (s_141 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_140 z) pmNode_305 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_140
 theorem k_140 (z : Store) (tid : Tid) (h : tid ∉ [517]) : (s_141 z) tid = (s_140 z) tid := by
   unfold s_141
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_140
 theorem w_140_0 (z : Store) : (s_141 z) 517 = v_140_0 z := by
   unfold s_141
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_140_0, r_140_0 z, r_140_1 z] <;> rfl
 #a w_140_0
 theorem h_140_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_140_0 z).shape = [1, 16, 32] := by
   unfold v_140_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 2 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_115_0 z) rfl]
     exact h_115_0 z z_
   · decide
 #a h_140_0
 attribute [local irreducible] v_140_0
 attribute [local irreducible] s_141
 theorem r_141_0 (z : Store) : (s_141 z) 517 = (v_140_0 z) := w_140_0 z
 #a r_141_0
 def v_141_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_140_0 z)
 def s_142 (z : Store) : Store := storeSet (s_141 z) [(518, fw_view [1, 16, 2, 16] ((s_141 z) 517))]
 theorem t_141 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_306) (pmPeers pmNode_306) (s_141 z) pmNode_306 none = some (s_142 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_141
 theorem k_141 (z : Store) (tid : Tid) (h : tid ∉ [518]) : (s_142 z) tid = (s_141 z) tid := by
   unfold s_142
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_141
 theorem w_141_0 (z : Store) : (s_142 z) 518 = v_141_0 z := by
   unfold s_142
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_141_0, r_141_0 z] <;> rfl
 #a w_141_0
 theorem h_141_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_141_0 z).shape = [1, 16, 2, 16] := by
   unfold v_141_0
   rfl
 #a h_141_0
 attribute [local irreducible] v_141_0
 attribute [local irreducible] s_142
 theorem r_142_0 (z : Store) : (s_142 z) 215 = (v_137_0 z) := pR (k_141 z) (pR (k_140 z) (pR (k_139 z) (pR (k_138 z) (w_137_0 z))))
 #a r_142_0
 theorem r_142_1 (z : Store) : (s_142 z) 518 = (v_141_0 z) := w_141_0 z
 #a r_142_1
 def v_142_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_137_0 z), (v_141_0 z)]
 theorem g_142 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_71) (s_142 z) pmNode_71 2 1 218 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_71, r_142_0 z, r_142_1 z, h_137_0 z z_, h_141_0 z z_]
 #a g_142
 def s_143 (z : Store) : Store := pL [0, 1] (s_142 z) pmNode_71 2 1
 theorem t_142 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_71) (pmPeers pmNode_71) (s_142 z) pmNode_71 none = some (s_143 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_71) (s_142 z) pmNode_71).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 218 (by decide) (g_142 z z_)]
   rfl
 #a t_142
 theorem k_142 (z : Store) (tid : Tid) (h : tid ∉ [218]) : (s_143 z) tid = (s_142 z) tid := by
   unfold s_143
   dsimp only [pL, pmNode_71, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_142
 theorem w_142_0 (z : Store) : (s_143 z) 218 = v_142_0 z := by
   unfold s_143
   dsimp only [pL, pmNode_71, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_142_0, r_142_0 z, r_142_1 z] <;> rfl
 #a w_142_0
 theorem h_142_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_142_0 z).shape = [1, 8, 4, 16] := by
   unfold v_142_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_137_0 z z_]
 #a h_142_0
 attribute [local irreducible] v_142_0
 attribute [local irreducible] s_143
 theorem r_143_0 (z : Store) : (s_143 z) 218 = (v_142_0 z) := w_142_0 z
 #a r_143_0
 def v_143_0 (z : Store) : Tensor := transposeAxes 1 2 (v_142_0 z)
 def s_144 (z : Store) : Store := storeSet (s_143 z) [(219, transposeAxes 1 2 ((s_143 z) 218))]
 theorem t_143 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_72) (pmPeers pmNode_72) (s_143 z) pmNode_72 none = some (s_144 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_143
 theorem k_143 (z : Store) (tid : Tid) (h : tid ∉ [219]) : (s_144 z) tid = (s_143 z) tid := by
   unfold s_144
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_143
 theorem w_143_0 (z : Store) : (s_144 z) 219 = v_143_0 z := by
   unfold s_144
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_143_0, r_143_0 z] <;> rfl
 #a w_143_0
 theorem h_143_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_143_0 z).shape = [1, 4, 8, 16] := by
   unfold v_143_0
   change listSwapAt _ _ _ = _
   rw [h_142_0 z z_]
   rfl
 #a h_143_0
 attribute [local irreducible] v_143_0
 attribute [local irreducible] s_144
 theorem n_140_144 (z : Store) (tid : Tid) (h : tid ∉ ([517, 518, 218, 219] : List Tid)) : (s_144 z) tid = (s_140 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_140 z) (k_141 z)) (pF _ _ _ _ _ (k_142 z) (k_143 z)) tid h
 #a n_140_144
 theorem n_136_144 (z : Store) (tid : Tid) (h : tid ∉ ([214, 215, 513, 514, 517, 518, 218, 219] : List Tid)) : (s_144 z) tid = (s_136 z) tid := by
   exact pF _ _ _ _ _ (n_136_140 z) (n_140_144 z) tid h
 #a n_136_144
 theorem r_144_0 (z : Store) : (s_144 z) 211 = (v_135_0 z) := pR (n_136_144 z) (w_135_0 z)
 #a r_144_0
 def v_144_0 (z : Store) : Tensor := transposeAxes 2 3 (v_135_0 z)
 def s_145 (z : Store) : Store := storeSet (s_144 z) [(222, transposeAxes 2 3 ((s_144 z) 211))]
 theorem t_144 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_73) (pmPeers pmNode_73) (s_144 z) pmNode_73 none = some (s_145 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_144
 theorem k_144 (z : Store) (tid : Tid) (h : tid ∉ [222]) : (s_145 z) tid = (s_144 z) tid := by
   unfold s_145
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_144
 theorem w_144_0 (z : Store) : (s_145 z) 222 = v_144_0 z := by
   unfold s_145
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_144_0, r_144_0 z] <;> rfl
 #a w_144_0
 theorem h_144_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_144_0 z).shape = [1, 4, 8, 16] := by
   unfold v_144_0
   change listSwapAt _ _ _ = _
   rw [h_135_0 z z_]
   rfl
 #a h_144_0
 attribute [local irreducible] v_144_0
 attribute [local irreducible] s_145
 theorem r_145_0 (z : Store) : (s_145 z) 215 = (v_137_0 z) := pR (k_144 z) (pR (k_143 z) (pR (k_142 z) (r_142_0 z)))
 #a r_145_0
 theorem r_145_1 (z : Store) : (s_145 z) 518 = (v_141_0 z) := pR (k_144 z) (pR (k_143 z) (pR (k_142 z) (r_142_1 z)))
 #a r_145_1
 def v_145_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_137_0 z), (v_141_0 z)]
 theorem g_145 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_307) (s_145 z) pmNode_307 2 1 521 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_307, r_145_0 z, r_145_1 z, h_137_0 z z_, h_141_0 z z_]
 #a g_145
 def s_146 (z : Store) : Store := pL [0, 1] (s_145 z) pmNode_307 2 1
 theorem t_145 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_307) (pmPeers pmNode_307) (s_145 z) pmNode_307 none = some (s_146 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_307) (s_145 z) pmNode_307).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 521 (by decide) (g_145 z z_)]
   rfl
 #a t_145
 theorem k_145 (z : Store) (tid : Tid) (h : tid ∉ [521]) : (s_146 z) tid = (s_145 z) tid := by
   unfold s_146
   dsimp only [pL, pmNode_307, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_145
 theorem w_145_0 (z : Store) : (s_146 z) 521 = v_145_0 z := by
   unfold s_146
   dsimp only [pL, pmNode_307, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_145_0, r_145_0 z, r_145_1 z] <;> rfl
 #a w_145_0
 theorem h_145_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_145_0 z).shape = [1, 8, 4, 16] := by
   unfold v_145_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_137_0 z z_]
 #a h_145_0
 attribute [local irreducible] v_145_0
 attribute [local irreducible] s_146
 theorem r_146_0 (z : Store) : (s_146 z) 521 = (v_145_0 z) := w_145_0 z
 #a r_146_0
 def v_146_0 (z : Store) : Tensor := transposeAxes 1 2 (v_145_0 z)
 def s_147 (z : Store) : Store := storeSet (s_146 z) [(522, transposeAxes 1 2 ((s_146 z) 521))]
 theorem t_146 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_308) (pmPeers pmNode_308) (s_146 z) pmNode_308 none = some (s_147 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_146
 theorem k_146 (z : Store) (tid : Tid) (h : tid ∉ [522]) : (s_147 z) tid = (s_146 z) tid := by
   unfold s_147
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_146
 theorem w_146_0 (z : Store) : (s_147 z) 522 = v_146_0 z := by
   unfold s_147
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_146_0, r_146_0 z] <;> rfl
 #a w_146_0
 theorem h_146_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_146_0 z).shape = [1, 4, 8, 16] := by
   unfold v_146_0
   change listSwapAt _ _ _ = _
   rw [h_145_0 z z_]
   rfl
 #a h_146_0
 attribute [local irreducible] v_146_0
 attribute [local irreducible] s_147
 theorem r_147_0 (z : Store) : (s_147 z) 514 = (v_139_0 z) := pR (k_146 z) (pR (k_145 z) (pR (k_144 z) (pR (n_140_144 z) (w_139_0 z))))
 #a r_147_0
 def v_147_0 (z : Store) : Tensor := transposeAxes 2 3 (v_139_0 z)
 def s_148 (z : Store) : Store := storeSet (s_147 z) [(525, transposeAxes 2 3 ((s_147 z) 514))]
 theorem t_147 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_309) (pmPeers pmNode_309) (s_147 z) pmNode_309 none = some (s_148 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_147
 theorem k_147 (z : Store) (tid : Tid) (h : tid ∉ [525]) : (s_148 z) tid = (s_147 z) tid := by
   unfold s_148
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_147
 theorem w_147_0 (z : Store) : (s_148 z) 525 = v_147_0 z := by
   unfold s_148
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_147_0, r_147_0 z] <;> rfl
 #a w_147_0
 theorem h_147_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_147_0 z).shape = [1, 4, 8, 16] := by
   unfold v_147_0
   change listSwapAt _ _ _ = _
   rw [h_139_0 z z_]
   rfl
 #a h_147_0
 attribute [local irreducible] v_147_0
 attribute [local irreducible] s_148
 record_prefix_opacity v_138_0 s_139 v_139_0 s_140 v_140_0 s_141 v_141_0 s_142 v_142_0 s_143 v_143_0 s_144 v_144_0 s_145 v_145_0 s_146 v_146_0 s_147 v_147_0 s_148

 end
 end TrainVerify.Denote.RuntimeWorld
