import FreshInputLinear
import denote.SourceAllGatherRead
-- UNCOMPILED: parent owns imports, canonical frame, aggregate costs and kernel gate.
namespace TrainVerify.Denote.RuntimeWorld
noncomputable section
set_option maxHeartbeats 500000
theorem frontierGatheredLinearRead_sm_1294 (s t : Store) (h : smDenoteWithInputs s = some t) :
    t 1294 = fw_linear (t 1394) (t 1226) := by
  apply SourceLinearRead.linear_value_of_split smGraph smScope smPeers smGraph.nodes
    smInputRequests (smInputRequests.take 35) (smInputRequests.drop 36) smNode_35
    0 1394 1226 1294 s t rfl ?_ rfl ?_ ?_ h
  · calc
      smInputRequests = smInputRequests.take 35 ++ smInputRequests.drop 35 := (List.take_append_drop 35 smInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ smInputRequests.drop 35, 1394 ∉ row.1.outs
    decide
  · change ∀ row ∈ smInputRequests.drop 35, 1226 ∉ row.1.outs
    decide
#print axioms frontierGatheredLinearRead_sm_1294
theorem frontierGatheredAllGatherRead_pm_88 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 88 = allGatherPrimDimN 1 2 0 [t 293, t 596] := by
  apply SourceAllGatherRead.allGather_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 110) (pmInputRequests.drop 111) pmNode_55
    0 [0, 1] [293, 596] 88 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 110 ++ pmInputRequests.drop 110 := (List.take_append_drop 110 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([293, 596] : List Tid), ∀ row ∈ pmInputRequests.drop 110, tid ∉ row.1.outs
    decide
#print axioms frontierGatheredAllGatherRead_pm_88
theorem frontierGatheredAllGatherRead_pm_391 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 391 = allGatherPrimDimN 1 2 1 [t 293, t 596] := by
  apply SourceAllGatherRead.allGather_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 116) (pmInputRequests.drop 117) pmNode_291
    1 [0, 1] [293, 596] 391 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 116 ++ pmInputRequests.drop 116 := (List.take_append_drop 116 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([293, 596] : List Tid), ∀ row ∈ pmInputRequests.drop 116, tid ∉ row.1.outs
    decide
#print axioms frontierGatheredAllGatherRead_pm_391
theorem frontierGatheredLinearRead_pm_189 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 189 = fw_linear (t 88) (t 47) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 111) (pmInputRequests.drop 112) pmNode_56
    0 88 47 189 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 111 ++ pmInputRequests.drop 111 := (List.take_append_drop 111 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 111, 88 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 111, 47 ∉ row.1.outs
    decide
#print axioms frontierGatheredLinearRead_pm_189
theorem frontierGatheredLinearRead_pm_492 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 492 = fw_linear (t 391) (t 350) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 117) (pmInputRequests.drop 118) pmNode_292
    1 391 350 492 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 117 ++ pmInputRequests.drop 117 := (List.take_append_drop 117 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 117, 391 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 117, 350 ∉ row.1.outs
    decide
#print axioms frontierGatheredLinearRead_pm_492
theorem frontierGatheredLinearUnitFacts_1294_0 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1294).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 189, q 492], y.shape = [1, 16, 32]) ∧
    chunkPrimDimN 0 2 0 (t 1294) = allGatherPrimDimN 2 2 0 [q 189, q 492] := by
  have predecessor := frontierSequenceAliasFacts_1394_0 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : RelationCompiler.ShardedRel (t 1226) [q 47, q 350] 0 [64, 64] [32, 64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have gathered0 : q 88 = (chunkPrimDimN 0 2 0 (t 1394)) :=
    (frontierGatheredAllGatherRead_pm_88 p q hp).trans predecessor.2.2.symm
  have local0 : q 189 = fw_linear (chunkPrimDimN 0 2 0 (t 1394)) (q 47) := by
    rw [frontierGatheredLinearRead_pm_189 p q hp, gathered0]
  have gathered1 : q 391 = (chunkPrimDimN 0 2 0 (t 1394)) :=
    (frontierGatheredAllGatherRead_pm_391 p q hp).trans predecessor.2.2.symm
  have local1 : q 492 = fw_linear (chunkPrimDimN 0 2 0 (t 1394)) (q 350) := by
    rw [frontierGatheredLinearRead_pm_492 p q hp, gathered1]
  have localReads : List.Forall₂ (fun w y => y = fw_linear (chunkPrimDimN 0 2 0 (t 1394)) w) [q 47, q 350] [q 189, q 492] :=
    List.Forall₂.cons local0 (List.Forall₂.cons local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_weight_unit_output_reconstruct 2 2 1 16 64 32 0
    (t 1394) (chunkPrimDimN 0 2 0 (t 1394)) (t 1226) (t 1294) [q 47, q 350] [q 189, q 492]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl weightRel.shard_shapes rfl weightRel.full_value
    (frontierGatheredLinearRead_sm_1294 s t hs) localReads
#print axioms frontierGatheredLinearUnitFacts_1294_0
theorem frontierGatheredAllGatherRead_pm_694 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 694 = allGatherPrimDimN 1 2 0 [t 899, t 1202] := by
  apply SourceAllGatherRead.allGather_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 532) (pmInputRequests.drop 533) pmNode_527
    2 [2, 3] [899, 1202] 694 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 532 ++ pmInputRequests.drop 532 := (List.take_append_drop 532 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([899, 1202] : List Tid), ∀ row ∈ pmInputRequests.drop 532, tid ∉ row.1.outs
    decide
#print axioms frontierGatheredAllGatherRead_pm_694
theorem frontierGatheredAllGatherRead_pm_997 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 997 = allGatherPrimDimN 1 2 1 [t 899, t 1202] := by
  apply SourceAllGatherRead.allGather_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 538) (pmInputRequests.drop 539) pmNode_763
    3 [2, 3] [899, 1202] 997 1 s t rfl ?_ rfl ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 538 ++ pmInputRequests.drop 538 := (List.take_append_drop 538 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ tid ∈ ([899, 1202] : List Tid), ∀ row ∈ pmInputRequests.drop 538, tid ∉ row.1.outs
    decide
#print axioms frontierGatheredAllGatherRead_pm_997
theorem frontierGatheredLinearRead_pm_795 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 795 = fw_linear (t 694) (t 653) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 533) (pmInputRequests.drop 534) pmNode_528
    2 694 653 795 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 533 ++ pmInputRequests.drop 533 := (List.take_append_drop 533 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 533, 694 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 533, 653 ∉ row.1.outs
    decide
#print axioms frontierGatheredLinearRead_pm_795
theorem frontierGatheredLinearRead_pm_1098 (s t : Store) (h : pmDenoteWithInputs s = some t) :
    t 1098 = fw_linear (t 997) (t 956) := by
  apply SourceLinearRead.linear_value_of_split pmGraph pmScope pmPeers pmGraph.nodes
    pmInputRequests (pmInputRequests.take 539) (pmInputRequests.drop 540) pmNode_764
    3 997 956 1098 s t rfl ?_ rfl ?_ ?_ h
  · calc
      pmInputRequests = pmInputRequests.take 539 ++ pmInputRequests.drop 539 := (List.take_append_drop 539 pmInputRequests).symm
      _ = _ := rfl
  · change ∀ row ∈ pmInputRequests.drop 539, 997 ∉ row.1.outs
    decide
  · change ∀ row ∈ pmInputRequests.drop 539, 956 ∉ row.1.outs
    decide
#print axioms frontierGatheredLinearRead_pm_1098
theorem frontierGatheredLinearUnitFacts_1294_1 (s p t q : Store)
    (hs : smDenoteWithInputs s = some t) (hp : pmDenoteWithInputs p = some q)
    (hvalues : InitialParameterValues s p) :
    (t 1294).shape = [2, 16, 64] ∧
    (∀ y ∈ [q 795, q 1098], y.shape = [1, 16, 32]) ∧
    chunkPrimDimN 0 2 1 (t 1294) = allGatherPrimDimN 2 2 0 [q 795, q 1098] := by
  have predecessor := frontierSequenceAliasFacts_1394_1 s p t q hs hp hvalues
  have hrels := initialParameterRelations_of_values t q (initialParameterValues_final s p t q hs hp hvalues)
  have weightRel : RelationCompiler.ShardedRel (t 1226) [q 653, q 956] 0 [64, 64] [32, 64] := hrels.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have gathered0 : q 694 = (chunkPrimDimN 0 2 1 (t 1394)) :=
    (frontierGatheredAllGatherRead_pm_694 p q hp).trans predecessor.2.2.symm
  have local0 : q 795 = fw_linear (chunkPrimDimN 0 2 1 (t 1394)) (q 653) := by
    rw [frontierGatheredLinearRead_pm_795 p q hp, gathered0]
  have gathered1 : q 997 = (chunkPrimDimN 0 2 1 (t 1394)) :=
    (frontierGatheredAllGatherRead_pm_997 p q hp).trans predecessor.2.2.symm
  have local1 : q 1098 = fw_linear (chunkPrimDimN 0 2 1 (t 1394)) (q 956) := by
    rw [frontierGatheredLinearRead_pm_1098 p q hp, gathered1]
  have localReads : List.Forall₂ (fun w y => y = fw_linear (chunkPrimDimN 0 2 1 (t 1394)) w) [q 653, q 956] [q 795, q 1098] :=
    List.Forall₂.cons local0 (List.Forall₂.cons local1 (List.Forall₂.nil))
  exact TrainVerify.Denote.source_linear_weight_unit_output_reconstruct 2 2 1 16 64 32 1
    (t 1394) (chunkPrimDimN 0 2 1 (t 1394)) (t 1226) (t 1294) [q 653, q 956] [q 795, q 1098]
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    predecessor.1 rfl weightRel.shard_shapes rfl weightRel.full_value
    (frontierGatheredLinearRead_sm_1294 s t hs) localReads
#print axioms frontierGatheredLinearUnitFacts_1294_1
end
end TrainVerify.Denote.RuntimeWorld
