import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0057
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_448_0 (z : Store) : (s_448 z) 1011 = (v_442_0 z) := pR (n_444_448 z) (pR (k_443 z) (w_442_0 z))
 #a r_448_0
 theorem r_448_1 (z : Store) : (s_448 z) 912 = (z 912) := pR (n_384_448 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_61 z)))
 #a r_448_1
 def v_448_0 (z : Store) : Tensor := fw_linear (v_442_0 z) (z 912)
 def s_449 (z : Store) : Store := storeSet (s_448 z) [(1012, fw_linear ((s_448 z) 1011) ((s_448 z) 912))]
 theorem t_448 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_718) (pmPeers pmNode_718) (s_448 z) pmNode_718 none = some (s_449 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_448
 theorem k_448 (z : Store) (tid : Tid) (h : tid ∉ [1012]) : (s_449 z) tid = (s_448 z) tid := by
   unfold s_449
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_448
 theorem w_448_0 (z : Store) : (s_449 z) 1012 = v_448_0 z := by
   unfold s_449
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_448_0, r_448_0 z, r_448_1 z] <;> rfl
 #a w_448_0
 theorem h_448_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_448_0 z).shape = [1, 8, 64] := by
   unfold v_448_0
   exact fw_linear_3d_shape 1 8 64 64 (v_442_0 z) (z 912) (h_442_0 z z_) (i_61 z z_)
 #a h_448_0
 attribute [local irreducible] v_448_0
 attribute [local irreducible] s_449
 theorem r_449_0 (z : Store) : (s_449 z) 891 = (v_438_1 z) := pR (k_448 z) (pR (n_444_448 z) (pR (k_443 z) (r_443_0 z)))
 #a r_449_0
 theorem r_449_1 (z : Store) : (s_449 z) 1194 = (v_442_1 z) := pR (k_448 z) (pR (n_444_448 z) (pR (k_443 z) (r_443_1 z)))
 #a r_449_1
 def v_449_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_438_1 z), (v_442_1 z)]
 def s_450 (z : Store) : Store := storeSet (s_449 z) [(995, allGatherPrimDimN 1 2 1 [((s_449 z) 891), ((s_449 z) 1194)])]
 theorem t_449 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_719) (pmPeers pmNode_719) (s_449 z) pmNode_719 none = some (s_450 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_449 z) pmNode_719 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_449
 theorem k_449 (z : Store) (tid : Tid) (h : tid ∉ [995]) : (s_450 z) tid = (s_449 z) tid := by
   unfold s_450
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_449
 theorem w_449_0 (z : Store) : (s_450 z) 995 = v_449_0 z := by
   unfold s_450
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_449_0, r_449_0 z, r_449_1 z] <;> rfl
 #a w_449_0
 theorem h_449_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_449_0 z).shape = [1, 16, 64] := by
   unfold v_449_0
   exact allGatherPrimDimN_shape 1 2 [(v_438_1 z), (v_442_1 z)] [1, 8, 64] (h_438_1 z z_)
 #a h_449_0
 attribute [local irreducible] v_449_0
 attribute [local irreducible] s_450
 theorem r_450_0 (z : Store) : (s_450 z) 995 = (v_449_0 z) := w_449_0 z
 #a r_450_0
 theorem r_450_1 (z : Store) : (s_450 z) 936 = (z 936) := pR (k_449 z) (pR (k_448 z) (pR (n_384_448 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_62 z)))))
 #a r_450_1
 def v_450_0 (z : Store) : Tensor := fw_linear (v_449_0 z) (z 936)
 def s_451 (z : Store) : Store := storeSet (s_450 z) [(1015, fw_linear ((s_450 z) 995) ((s_450 z) 936))]
 theorem t_450 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_720) (pmPeers pmNode_720) (s_450 z) pmNode_720 none = some (s_451 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_450
 theorem k_450 (z : Store) (tid : Tid) (h : tid ∉ [1015]) : (s_451 z) tid = (s_450 z) tid := by
   unfold s_451
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_450
 theorem w_450_0 (z : Store) : (s_451 z) 1015 = v_450_0 z := by
   unfold s_451
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_450_0, r_450_0 z, r_450_1 z] <;> rfl
 #a w_450_0
 theorem h_450_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_450_0 z).shape = [1, 16, 32] := by
   unfold v_450_0
   exact fw_linear_3d_shape 1 16 64 32 (v_449_0 z) (z 936) (h_449_0 z z_) (i_62 z z_)
 #a h_450_0
 attribute [local irreducible] v_450_0
 attribute [local irreducible] s_451
 theorem r_451_0 (z : Store) : (s_451 z) 893 = (v_438_2 z) := pR (k_450 z) (pR (k_449 z) (pR (k_448 z) (pR (k_447 z) (pR (k_446 z) (pR (k_445 z) (r_445_0 z))))))
 #a r_451_0
 theorem r_451_1 (z : Store) : (s_451 z) 1196 = (v_442_2 z) := pR (k_450 z) (pR (k_449 z) (pR (k_448 z) (pR (k_447 z) (pR (k_446 z) (pR (k_445 z) (r_445_1 z))))))
 #a r_451_1
 def v_451_0 (z : Store) : Tensor := allGatherPrimDimN 1 2 1 [(v_438_2 z), (v_442_2 z)]
 def s_452 (z : Store) : Store := storeSet (s_451 z) [(996, allGatherPrimDimN 1 2 1 [((s_451 z) 893), ((s_451 z) 1196)])]
 theorem t_451 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_721) (pmPeers pmNode_721) (s_451 z) pmNode_721 none = some (s_452 z) := by
   change GroupScopedEval.step pmGraph (.group (some [2, 3])) (s_451 z) pmNode_721 = _
   rw [GroupScopedEval.step_scoped _ _ _ [2, 3] (by decide) (by rfl)]
   rfl
 #a t_451
 theorem k_451 (z : Store) (tid : Tid) (h : tid ∉ [996]) : (s_452 z) tid = (s_451 z) tid := by
   unfold s_452
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_451
 theorem w_451_0 (z : Store) : (s_452 z) 996 = v_451_0 z := by
   unfold s_452
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_451_0, r_451_0 z, r_451_1 z] <;> rfl
 #a w_451_0
 theorem h_451_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_451_0 z).shape = [1, 16, 64] := by
   unfold v_451_0
   exact allGatherPrimDimN_shape 1 2 [(v_438_2 z), (v_442_2 z)] [1, 8, 64] (h_438_2 z z_)
 #a h_451_0
 attribute [local irreducible] v_451_0
 attribute [local irreducible] s_452
 theorem n_448_452 (z : Store) (tid : Tid) (h : tid ∉ ([1012, 995, 1015, 996] : List Tid)) : (s_452 z) tid = (s_448 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_448 z) (k_449 z)) (pF _ _ _ _ _ (k_450 z) (k_451 z)) tid h
 #a n_448_452
 theorem r_452_0 (z : Store) : (s_452 z) 996 = (v_451_0 z) := w_451_0 z
 #a r_452_0
 theorem r_452_1 (z : Store) : (s_452 z) 939 = (z 939) := pR (n_448_452 z) (pR (n_384_448 z) (pR (n_256_384 z) (pR (n_0_256 z) (e_63 z))))
 #a r_452_1
 def v_452_0 (z : Store) : Tensor := fw_linear (v_451_0 z) (z 939)
 def s_453 (z : Store) : Store := storeSet (s_452 z) [(1018, fw_linear ((s_452 z) 996) ((s_452 z) 939))]
 theorem t_452 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_722) (pmPeers pmNode_722) (s_452 z) pmNode_722 none = some (s_453 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_452
 theorem k_452 (z : Store) (tid : Tid) (h : tid ∉ [1018]) : (s_453 z) tid = (s_452 z) tid := by
   unfold s_453
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_452
 theorem w_452_0 (z : Store) : (s_453 z) 1018 = v_452_0 z := by
   unfold s_453
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_452_0, r_452_0 z, r_452_1 z] <;> rfl
 #a w_452_0
 theorem h_452_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_452_0 z).shape = [1, 16, 32] := by
   unfold v_452_0
   exact fw_linear_3d_shape 1 16 64 32 (v_451_0 z) (z 939) (h_451_0 z z_) (i_63 z z_)
 #a h_452_0
 attribute [local irreducible] v_452_0
 attribute [local irreducible] s_453
 theorem r_453_0 (z : Store) : (s_453 z) 1012 = (v_448_0 z) := pR (k_452 z) (pR (k_451 z) (pR (k_450 z) (pR (k_449 z) (w_448_0 z))))
 #a r_453_0
 def v_453_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_448_0 z)
 def s_454 (z : Store) : Store := storeSet (s_453 z) [(1021, fw_view [1, 8, 4, 16] ((s_453 z) 1012))]
 theorem t_453 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_723) (pmPeers pmNode_723) (s_453 z) pmNode_723 none = some (s_454 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_453
 theorem k_453 (z : Store) (tid : Tid) (h : tid ∉ [1021]) : (s_454 z) tid = (s_453 z) tid := by
   unfold s_454
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_453
 theorem w_453_0 (z : Store) : (s_454 z) 1021 = v_453_0 z := by
   unfold s_454
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_453_0, r_453_0 z] <;> rfl
 #a w_453_0
 theorem h_453_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_453_0 z).shape = [1, 8, 4, 16] := by
   unfold v_453_0
   rfl
 #a h_453_0
 attribute [local irreducible] v_453_0
 attribute [local irreducible] s_454
 theorem r_454_0 (z : Store) : (s_454 z) 718 = (v_447_0 z) := pR (k_453 z) (pR (k_452 z) (pR (n_448_452 z) (w_447_0 z)))
 #a r_454_0
 theorem r_454_1 (z : Store) : (s_454 z) 1021 = (v_453_0 z) := w_453_0 z
 #a r_454_1
 def v_454_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 3 [(v_447_0 z), (v_453_0 z)]
 theorem g_454 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_488) (s_454 z) pmNode_488 1 3 720 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_488, r_454_0 z, r_454_1 z, h_447_0 z z_, h_453_0 z z_]
 #a g_454
 def s_455 (z : Store) : Store := pL [2, 3] (s_454 z) pmNode_488 1 3
 theorem t_454 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_488) (pmPeers pmNode_488) (s_454 z) pmNode_488 none = some (s_455 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_488) (s_454 z) pmNode_488).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 720 (by decide) (g_454 z z_)]
   rfl
 #a t_454
 theorem k_454 (z : Store) (tid : Tid) (h : tid ∉ [720]) : (s_455 z) tid = (s_454 z) tid := by
   unfold s_455
   dsimp only [pL, pmNode_488, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_454
 theorem w_454_0 (z : Store) : (s_455 z) 720 = v_454_0 z := by
   unfold s_455
   dsimp only [pL, pmNode_488, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_454_0, r_454_0 z, r_454_1 z] <;> rfl
 #a w_454_0
 theorem h_454_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_454_0 z).shape = [1, 16, 4, 8] := by
   unfold v_454_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_447_0 z z_]
 #a h_454_0
 attribute [local irreducible] v_454_0
 attribute [local irreducible] s_455
 theorem r_455_0 (z : Store) : (s_455 z) 720 = (v_454_0 z) := w_454_0 z
 #a r_455_0
 def v_455_0 (z : Store) : Tensor := transposeAxes 1 2 (v_454_0 z)
 def s_456 (z : Store) : Store := storeSet (s_455 z) [(721, transposeAxes 1 2 ((s_455 z) 720))]
 theorem t_455 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_489) (pmPeers pmNode_489) (s_455 z) pmNode_489 none = some (s_456 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_455
 theorem k_455 (z : Store) (tid : Tid) (h : tid ∉ [721]) : (s_456 z) tid = (s_455 z) tid := by
   unfold s_456
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_455
 theorem w_455_0 (z : Store) : (s_456 z) 721 = v_455_0 z := by
   unfold s_456
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_455_0, r_455_0 z] <;> rfl
 #a w_455_0
 theorem h_455_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_455_0 z).shape = [1, 4, 16, 8] := by
   unfold v_455_0
   change listSwapAt _ _ _ = _
   rw [h_454_0 z z_]
   rfl
 #a h_455_0
 attribute [local irreducible] v_455_0
 attribute [local irreducible] s_456
 theorem n_452_456 (z : Store) (tid : Tid) (h : tid ∉ ([1018, 1021, 720, 721] : List Tid)) : (s_456 z) tid = (s_452 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_452 z) (k_453 z)) (pF _ _ _ _ _ (k_454 z) (k_455 z)) tid h
 #a n_452_456
 theorem n_448_456 (z : Store) (tid : Tid) (h : tid ∉ ([1012, 995, 1015, 996, 1018, 1021, 720, 721] : List Tid)) : (s_456 z) tid = (s_448 z) tid := by
   exact pF _ _ _ _ _ (n_448_452 z) (n_452_456 z) tid h
 #a n_448_456
 theorem r_456_0 (z : Store) : (s_456 z) 712 = (v_444_0 z) := pR (n_448_456 z) (pR (k_447 z) (pR (k_446 z) (pR (k_445 z) (w_444_0 z))))
 #a r_456_0
 def v_456_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_444_0 z)
 def s_457 (z : Store) : Store := storeSet (s_456 z) [(724, fw_view [1, 16, 2, 16] ((s_456 z) 712))]
 theorem t_456 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_490) (pmPeers pmNode_490) (s_456 z) pmNode_490 none = some (s_457 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_456
 theorem k_456 (z : Store) (tid : Tid) (h : tid ∉ [724]) : (s_457 z) tid = (s_456 z) tid := by
   unfold s_457
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_456
 theorem w_456_0 (z : Store) : (s_457 z) 724 = v_456_0 z := by
   unfold s_457
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_456_0, r_456_0 z] <;> rfl
 #a w_456_0
 theorem h_456_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_456_0 z).shape = [1, 16, 2, 16] := by
   unfold v_456_0
   rfl
 #a h_456_0
 attribute [local irreducible] v_456_0
 attribute [local irreducible] s_457
 record_prefix_opacity v_448_0 s_449 v_449_0 s_450 v_450_0 s_451 v_451_0 s_452 v_452_0 s_453 v_453_0 s_454 v_454_0 s_455 v_455_0 s_456 v_456_0 s_457

 end
 end TrainVerify.Denote.RuntimeWorld
