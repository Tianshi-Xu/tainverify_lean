import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0051
prefix_names pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_401_0 (z : Store) : (s_401 z) 411 = (v_390_0 z) := pR (k_400 z) (pR (n_392_400 z) (pR (k_391 z) (w_390_0 z)))
 #a r_401_0
 theorem r_401_1 (z : Store) : (s_401 z) 389 = (v_27_0 z) := pR (k_400 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_28_32 z) (r_28_0 z)))))))
 #a r_401_1
 theorem r_401_2 (z : Store) : (s_401 z) 330 = (z 330) := pR (k_400 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_28_32 z) (r_28_1 z)))))))
 #a r_401_2
 def v_401_0 (z : Store) : Tensor := (bw_linear (v_390_0 z) (v_27_0 z) (z 330)).1
 def v_401_1 (z : Store) : Tensor := (bw_linear (v_390_0 z) (v_27_0 z) (z 330)).2
 def s_402 (z : Store) : Store := storeSet (s_401 z) [(410, (bw_linear ((s_401 z) 411) ((s_401 z) 389) ((s_401 z) 330)).1), (331, (bw_linear ((s_401 z) 411) ((s_401 z) 389) ((s_401 z) 330)).2)]
 theorem t_401 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_436) (pmPeers pmNode_436) (s_401 z) pmNode_436 none = some (s_402 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_401
 theorem k_401 (z : Store) (tid : Tid) (h : tid ∉ [410, 331]) : (s_402 z) tid = (s_401 z) tid := by
   unfold s_402
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_401
 theorem w_401_0 (z : Store) : (s_402 z) 410 = v_401_0 z := by
   unfold s_402
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_401_0, r_401_0 z, r_401_1 z, r_401_2 z] <;> rfl
 #a w_401_0
 theorem h_401_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_401_0 z).shape = [1, 16, 64] := by
   unfold v_401_0
   exact bw_linear_3d_fst_shape 1 16 32 64 (v_390_0 z) (v_27_0 z) (z 330) (h_390_0 z z_) (h_27_0 z z_) (i_12 z z_)
 #a h_401_0
 attribute [local irreducible] v_401_0
 theorem w_401_1 (z : Store) : (s_402 z) 331 = v_401_1 z := by
   unfold s_402
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_401_1, r_401_0 z, r_401_1 z, r_401_2 z] <;> rfl
 #a w_401_1
 theorem h_401_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_401_1 z).shape = [32, 64] := by
   unfold v_401_1
   exact bw_linear_3d_snd_shape 1 16 32 64 (v_390_0 z) (v_27_0 z) (z 330) (h_390_0 z z_) (h_27_0 z z_) (i_12 z z_)
 #a h_401_1
 attribute [local irreducible] v_401_1
 attribute [local irreducible] s_402
 theorem r_402_0 (z : Store) : (s_402 z) 108 = (v_399_0 z) := pR (k_401 z) (pR (k_400 z) (w_399_0 z))
 #a r_402_0
 theorem r_402_1 (z : Store) : (s_402 z) 410 = (v_401_0 z) := w_401_0 z
 #a r_402_1
 def v_402_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 0 [(v_399_0 z), (v_401_0 z)]
 def s_403 (z : Store) : Store := storeSet (s_402 z) [(286, reduceScatterPrimDimN 1 2 0 [((s_402 z) 108), ((s_402 z) 410)])]
 theorem t_402 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_201) (pmPeers pmNode_201) (s_402 z) pmNode_201 none = some (s_403 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_402 z) pmNode_201 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_402
 theorem k_402 (z : Store) (tid : Tid) (h : tid ∉ [286]) : (s_403 z) tid = (s_402 z) tid := by
   unfold s_403
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_402
 theorem w_402_0 (z : Store) : (s_403 z) 286 = v_402_0 z := by
   unfold s_403
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_402_0, r_402_0 z, r_402_1 z] <;> rfl
 #a w_402_0
 theorem h_402_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_402_0 z).shape = [1, 8, 64] := by
   unfold v_402_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 0 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_399_0 z) rfl]
     exact h_399_0 z z_
   · decide
 #a h_402_0
 attribute [local irreducible] v_402_0
 attribute [local irreducible] s_403
 theorem r_403_0 (z : Store) : (s_403 z) 105 = (v_393_0 z) := pR (k_402 z) (pR (k_401 z) (pR (k_400 z) (pR (n_396_400 z) (pR (k_395 z) (pR (k_394 z) (w_393_0 z))))))
 #a r_403_0
 theorem r_403_1 (z : Store) : (s_403 z) 102 = (v_16_0 z) := pR (k_402 z) (pR (k_401 z) (pR (k_400 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_24_32 z) (pR (n_20_24 z) (pR (k_19 z) (pR (k_18 z) (pR (k_17 z) (r_17_0 z)))))))))))))
 #a r_403_1
 theorem r_403_2 (z : Store) : (s_403 z) 3 = (z 3) := pR (k_402 z) (pR (k_401 z) (pR (k_400 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_24_32 z) (pR (n_20_24 z) (pR (k_19 z) (pR (k_18 z) (pR (k_17 z) (r_17_1 z)))))))))))))
 #a r_403_2
 def v_403_0 (z : Store) : Tensor := (bw_linear (v_393_0 z) (v_16_0 z) (z 3)).1
 def v_403_1 (z : Store) : Tensor := (bw_linear (v_393_0 z) (v_16_0 z) (z 3)).2
 def s_404 (z : Store) : Store := storeSet (s_403 z) [(104, (bw_linear ((s_403 z) 105) ((s_403 z) 102) ((s_403 z) 3)).1), (25, (bw_linear ((s_403 z) 105) ((s_403 z) 102) ((s_403 z) 3)).2)]
 theorem t_403 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_202) (pmPeers pmNode_202) (s_403 z) pmNode_202 none = some (s_404 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_403
 theorem k_403 (z : Store) (tid : Tid) (h : tid ∉ [104, 25]) : (s_404 z) tid = (s_403 z) tid := by
   unfold s_404
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_403
 theorem w_403_0 (z : Store) : (s_404 z) 104 = v_403_0 z := by
   unfold s_404
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_403_0, r_403_0 z, r_403_1 z, r_403_2 z] <;> rfl
 #a w_403_0
 theorem h_403_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_403_0 z).shape = [1, 8, 64] := by
   unfold v_403_0
   exact bw_linear_3d_fst_shape 1 8 64 64 (v_393_0 z) (v_16_0 z) (z 3) (h_393_0 z z_) (h_16_0 z z_) (i_6 z z_)
 #a h_403_0
 attribute [local irreducible] v_403_0
 theorem w_403_1 (z : Store) : (s_404 z) 25 = v_403_1 z := by
   unfold s_404
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_403_1, r_403_0 z, r_403_1 z, r_403_2 z] <;> rfl
 #a w_403_1
 theorem h_403_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_403_1 z).shape = [64, 64] := by
   unfold v_403_1
   exact bw_linear_3d_snd_shape 1 8 64 64 (v_393_0 z) (v_16_0 z) (z 3) (h_393_0 z z_) (h_16_0 z z_) (i_6 z z_)
 #a h_403_1
 attribute [local irreducible] v_403_1
 attribute [local irreducible] s_404
 theorem n_400_404 (z : Store) (tid : Tid) (h : tid ∉ ([591, 410, 331, 286, 104, 25] : List Tid)) : (s_404 z) tid = (s_400 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_400 z) (k_401 z)) (pF _ _ _ _ _ (k_402 z) (k_403 z)) tid h
 #a n_400_404
 theorem r_404_0 (z : Store) : (s_404 z) 104 = (v_403_0 z) := w_403_0 z
 #a r_404_0
 theorem r_404_1 (z : Store) : (s_404 z) 286 = (v_402_0 z) := pR (k_403 z) (w_402_0 z)
 #a r_404_1
 theorem r_404_2 (z : Store) : (s_404 z) 288 = (v_398_0 z) := pR (n_400_404 z) (pR (k_399 z) (w_398_0 z))
 #a r_404_2
 def v_404_0 (z : Store) : Tensor := tensorSum [(v_403_0 z), (v_402_0 z), (v_398_0 z)]
 def s_405 (z : Store) : Store := storeSet (s_404 z) [(101, tensorSum [((s_404 z) 104), ((s_404 z) 286), ((s_404 z) 288)])]
 theorem t_404 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_203) (pmPeers pmNode_203) (s_404 z) pmNode_203 none = some (s_405 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_404
 theorem k_404 (z : Store) (tid : Tid) (h : tid ∉ [101]) : (s_405 z) tid = (s_404 z) tid := by
   unfold s_405
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_404
 theorem w_404_0 (z : Store) : (s_405 z) 101 = v_404_0 z := by
   unfold s_405
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_404_0, r_404_0 z, r_404_1 z, r_404_2 z] <;> rfl
 #a w_404_0
 theorem h_404_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_404_0 z).shape = [1, 8, 64] := by
   unfold v_404_0
   rw [tensorSum_shape]
   exact h_403_0 z z_
 #a h_404_0
 attribute [local irreducible] v_404_0
 attribute [local irreducible] s_405
 theorem r_405_0 (z : Store) : (s_405 z) 101 = (v_404_0 z) := w_404_0 z
 #a r_405_0
 theorem r_405_1 (z : Store) : (s_405 z) 98 = (v_14_0 z) := pR (k_404 z) (pR (n_400_404 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (k_15 z) (r_15_0 z)))))))))
 #a r_405_1
 theorem r_405_2 (z : Store) : (s_405 z) 1 = (z 1) := pR (k_404 z) (pR (n_400_404 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (k_15 z) (r_15_1 z)))))))))
 #a r_405_2
 theorem r_405_3 (z : Store) : (s_405 z) 2 = (z 2) := pR (k_404 z) (pR (n_400_404 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (k_15 z) (r_15_2 z)))))))))
 #a r_405_3
 def v_405_0 (z : Store) : Tensor := (bw_layernorm (v_404_0 z) (v_14_0 z) (z 1) (z 2)).1
 def v_405_1 (z : Store) : Tensor := (bw_layernorm (v_404_0 z) (v_14_0 z) (z 1) (z 2)).2.1
 def v_405_2 (z : Store) : Tensor := (bw_layernorm (v_404_0 z) (v_14_0 z) (z 1) (z 2)).2.2
 def s_406 (z : Store) : Store := storeSet (s_405 z) [(100, (bw_layernorm ((s_405 z) 101) ((s_405 z) 98) ((s_405 z) 1) ((s_405 z) 2)).1), (21, (bw_layernorm ((s_405 z) 101) ((s_405 z) 98) ((s_405 z) 1) ((s_405 z) 2)).2.1), (23, (bw_layernorm ((s_405 z) 101) ((s_405 z) 98) ((s_405 z) 1) ((s_405 z) 2)).2.2)]
 theorem t_405 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_204) (pmPeers pmNode_204) (s_405 z) pmNode_204 none = some (s_406 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_405
 theorem k_405 (z : Store) (tid : Tid) (h : tid ∉ [100, 21, 23]) : (s_406 z) tid = (s_405 z) tid := by
   unfold s_406
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_405
 theorem w_405_0 (z : Store) : (s_406 z) 100 = v_405_0 z := by
   unfold s_406
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_405_0, r_405_0 z, r_405_1 z, r_405_2 z, r_405_3 z] <;> rfl
 #a w_405_0
 theorem h_405_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_405_0 z).shape = [1, 8, 64] := by
   unfold v_405_0
   rw [bw_layernorm_dx_shape (v_404_0 z) (v_14_0 z) (z 1) (z 2) 64 [8, 1] (by rw [h_14_0 z z_]; rfl)]
   exact h_14_0 z z_
 #a h_405_0
 attribute [local irreducible] v_405_0
 theorem w_405_1 (z : Store) : (s_406 z) 21 = v_405_1 z := by
   unfold s_406
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_405_1, r_405_0 z, r_405_1 z, r_405_2 z, r_405_3 z] <;> rfl
 #a w_405_1
 theorem h_405_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_405_1 z).shape = [64] := by
   unfold v_405_1
   rw [bw_layernorm_dw_shape (v_404_0 z) (v_14_0 z) (z 1) (z 2) 64 [8, 1] (by rw [h_14_0 z z_]; rfl)]
   exact i_4 z z_
 #a h_405_1
 attribute [local irreducible] v_405_1
 theorem w_405_2 (z : Store) : (s_406 z) 23 = v_405_2 z := by
   unfold s_406
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_405_2, r_405_0 z, r_405_1 z, r_405_2 z, r_405_3 z] <;> rfl
 #a w_405_2
 theorem h_405_2 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_405_2 z).shape = [64] := by
   unfold v_405_2
   rw [bw_layernorm_db_shape (v_404_0 z) (v_14_0 z) (z 1) (z 2) 64 [8, 1] (by rw [h_14_0 z z_]; rfl)]
   exact i_5 z z_
 #a h_405_2
 attribute [local irreducible] v_405_2
 attribute [local irreducible] s_406
 theorem r_406_0 (z : Store) : (s_406 z) 108 = (v_399_0 z) := pR (k_405 z) (pR (k_404 z) (pR (k_403 z) (pR (k_402 z) (r_402_0 z))))
 #a r_406_0
 theorem r_406_1 (z : Store) : (s_406 z) 410 = (v_401_0 z) := pR (k_405 z) (pR (k_404 z) (pR (k_403 z) (pR (k_402 z) (r_402_1 z))))
 #a r_406_1
 def v_406_0 (z : Store) : Tensor := reduceScatterPrimDimN 1 2 1 [(v_399_0 z), (v_401_0 z)]
 def s_407 (z : Store) : Store := storeSet (s_406 z) [(589, reduceScatterPrimDimN 1 2 1 [((s_406 z) 108), ((s_406 z) 410)])]
 theorem t_406 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_437) (pmPeers pmNode_437) (s_406 z) pmNode_437 none = some (s_407 z) := by
   change GroupScopedEval.step pmGraph (.group (some [0, 1])) (s_406 z) pmNode_437 = _
   rw [GroupScopedEval.step_scoped _ _ _ [0, 1] (by decide) (by rfl)]
   rfl
 #a t_406
 theorem k_406 (z : Store) (tid : Tid) (h : tid ∉ [589]) : (s_407 z) tid = (s_406 z) tid := by
   unfold s_407
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_406
 theorem w_406_0 (z : Store) : (s_407 z) 589 = v_406_0 z := by
   unfold s_407
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_406_0, r_406_0 z, r_406_1 z] <;> rfl
 #a w_406_0
 theorem h_406_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_406_0 z).shape = [1, 8, 64] := by
   unfold v_406_0
   unfold reduceScatterPrimDimN
   apply chunkPrimDimN_shape 1 2 1 _ [1, 16, 64]
   · rw [allReducePrim_shape _ _ _ (v_399_0 z) rfl]
     exact h_399_0 z z_
   · decide
 #a h_406_0
 attribute [local irreducible] v_406_0
 attribute [local irreducible] s_407
 theorem r_407_0 (z : Store) : (s_407 z) 408 = (v_396_0 z) := pR (k_406 z) (pR (k_405 z) (pR (k_404 z) (pR (n_400_404 z) (pR (k_399 z) (pR (k_398 z) (pR (k_397 z) (w_396_0 z)))))))
 #a r_407_0
 theorem r_407_1 (z : Store) : (s_407 z) 405 = (v_20_0 z) := pR (k_406 z) (pR (k_405 z) (pR (k_404 z) (pR (n_400_404 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_28_32 z) (pR (k_27 z) (pR (k_26 z) (r_26_0 z))))))))))))
 #a r_407_1
 theorem r_407_2 (z : Store) : (s_407 z) 306 = (z 306) := pR (k_406 z) (pR (k_405 z) (pR (k_404 z) (pR (n_400_404 z) (pR (n_384_400 z) (pR (n_256_384 z) (pR (n_128_256 z) (pR (n_64_128 z) (pR (n_32_64 z) (pR (n_28_32 z) (pR (k_27 z) (pR (k_26 z) (r_26_1 z))))))))))))
 #a r_407_2
 def v_407_0 (z : Store) : Tensor := (bw_linear (v_396_0 z) (v_20_0 z) (z 306)).1
 def v_407_1 (z : Store) : Tensor := (bw_linear (v_396_0 z) (v_20_0 z) (z 306)).2
 def s_408 (z : Store) : Store := storeSet (s_407 z) [(407, (bw_linear ((s_407 z) 408) ((s_407 z) 405) ((s_407 z) 306)).1), (328, (bw_linear ((s_407 z) 408) ((s_407 z) 405) ((s_407 z) 306)).2)]
 theorem t_407 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_438) (pmPeers pmNode_438) (s_407 z) pmNode_438 none = some (s_408 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_407
 theorem k_407 (z : Store) (tid : Tid) (h : tid ∉ [407, 328]) : (s_408 z) tid = (s_407 z) tid := by
   unfold s_408
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_407
 theorem w_407_0 (z : Store) : (s_408 z) 407 = v_407_0 z := by
   unfold s_408
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_407_0, r_407_0 z, r_407_1 z, r_407_2 z] <;> rfl
 #a w_407_0
 theorem h_407_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_407_0 z).shape = [1, 8, 64] := by
   unfold v_407_0
   exact bw_linear_3d_fst_shape 1 8 64 64 (v_396_0 z) (v_20_0 z) (z 306) (h_396_0 z z_) (h_20_0 z z_) (i_11 z z_)
 #a h_407_0
 attribute [local irreducible] v_407_0
 theorem w_407_1 (z : Store) : (s_408 z) 328 = v_407_1 z := by
   unfold s_408
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_407_1, r_407_0 z, r_407_1 z, r_407_2 z] <;> rfl
 #a w_407_1
 theorem h_407_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_407_1 z).shape = [64, 64] := by
   unfold v_407_1
   exact bw_linear_3d_snd_shape 1 8 64 64 (v_396_0 z) (v_20_0 z) (z 306) (h_396_0 z z_) (h_20_0 z z_) (i_11 z z_)
 #a h_407_1
 attribute [local irreducible] v_407_1
 attribute [local irreducible] s_408
 theorem n_404_408 (z : Store) (tid : Tid) (h : tid ∉ ([101, 100, 21, 23, 589, 407, 328] : List Tid)) : (s_408 z) tid = (s_404 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_404 z) (k_405 z)) (pF _ _ _ _ _ (k_406 z) (k_407 z)) tid h
 #a n_404_408
 record_prefix_opacity v_401_0 v_401_1 s_402 v_402_0 s_403 v_403_0 v_403_1 s_404 v_404_0 s_405 v_405_0 v_405_1 v_405_2 s_406 v_406_0 s_407 v_407_0 v_407_1 s_408

 end
 end TrainVerify.Denote.RuntimeWorld
