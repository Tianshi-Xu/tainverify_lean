import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0011
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_79_0 (z : Store) : (s_79 z) 159 = (v_78_0 z) := w_78_0 z
 #a r_79_0
 theorem r_79_1 (z : Store) : (s_79 z) 4 = (z 4) := pR (k_78 z) (pR (k_77 z) (pR (k_76 z) (pR (n_72_76 z) (pR (n_64_72 z) (pR (n_0_64 z) (e_14 z))))))
 #a r_79_1
 def v_79_0 (z : Store) : Tensor := fw_linear (v_78_0 z) (z 4)
 def s_80 (z : Store) : Store := storeSet (s_79 z) [(160, fw_linear ((s_79 z) 159) ((s_79 z) 4))]
 theorem t_79 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_40) (pmPeers pmNode_40) (s_79 z) pmNode_40 none = some (s_80 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_79
 theorem k_79 (z : Store) (tid : Tid) (h : tid ∉ [160]) : (s_80 z) tid = (s_79 z) tid := by
   unfold s_80
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_79
 theorem w_79_0 (z : Store) : (s_80 z) 160 = v_79_0 z := by
   unfold s_80
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_79_0, r_79_0 z, r_79_1 z] <;> rfl
 #a w_79_0
 theorem h_79_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_79_0 z).shape = [1, 8, 64] := by
   unfold v_79_0
   exact fw_linear_3d_shape 1 8 64 64 (v_78_0 z) (z 4) (h_78_0 z z_) (i_14 z z_)
 #a h_79_0
 attribute [local irreducible] v_79_0
 attribute [local irreducible] s_80
 theorem r_80_0 (z : Store) : (s_80 z) 156 = (v_75_0 z) := pR (k_79 z) (pR (k_78 z) (r_78_0 z))
 #a r_80_0
 theorem r_80_1 (z : Store) : (s_80 z) 459 = (v_77_0 z) := pR (k_79 z) (pR (k_78 z) (r_78_1 z))
 #a r_80_1
 def v_80_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_75_0 z), (v_77_0 z)]
 theorem g_80 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_275) (s_80 z) pmNode_275 2 1 462 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_275, r_80_0 z, r_80_1 z, h_75_0 z z_, h_77_0 z z_]
 #a g_80
 def s_81 (z : Store) : Store := pL [0, 1] (s_80 z) pmNode_275 2 1
 theorem t_80 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_275) (pmPeers pmNode_275) (s_80 z) pmNode_275 none = some (s_81 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_275) (s_80 z) pmNode_275).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 462 (by decide) (g_80 z z_)]
   rfl
 #a t_80
 theorem k_80 (z : Store) (tid : Tid) (h : tid ∉ [462]) : (s_81 z) tid = (s_80 z) tid := by
   unfold s_81
   dsimp only [pL, pmNode_275, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_80
 theorem w_80_0 (z : Store) : (s_81 z) 462 = v_80_0 z := by
   unfold s_81
   dsimp only [pL, pmNode_275, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_80_0, r_80_0 z, r_80_1 z] <;> rfl
 #a w_80_0
 theorem h_80_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_80_0 z).shape = [1, 8, 64] := by
   unfold v_80_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_75_0 z z_]
 #a h_80_0
 attribute [local irreducible] v_80_0
 attribute [local irreducible] s_81
 theorem n_76_80 (z : Store) (tid : Tid) (h : tid ∉ ([458, 459, 159, 160] : List Tid)) : (s_80 z) tid = (s_76 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_76 z) (k_77 z)) (pF _ _ _ _ _ (k_78 z) (k_79 z)) tid h
 #a n_76_80
 theorem n_72_80 (z : Store) (tid : Tid) (h : tid ∉ ([454, 456, 155, 156, 458, 459, 159, 160] : List Tid)) : (s_80 z) tid = (s_72 z) tid := by
   exact pF _ _ _ _ _ (n_72_76 z) (n_76_80 z) tid h
 #a n_72_80
 theorem n_64_80 (z : Store) (tid : Tid) (h : tid ∉ ([446, 146, 147, 151, 153, 381, 449, 450, 454, 456, 155, 156, 458, 459, 159, 160] : List Tid)) : (s_80 z) tid = (s_64 z) tid := by
   exact pF _ _ _ _ _ (n_64_72 z) (n_72_80 z) tid h
 #a n_64_80
 theorem r_81_0 (z : Store) : (s_81 z) 462 = (v_80_0 z) := w_80_0 z
 #a r_81_0
 theorem r_81_1 (z : Store) : (s_81 z) 307 = (z 307) := pR (k_80 z) (pR (n_64_80 z) (pR (n_0_64 z) (e_15 z)))
 #a r_81_1
 def v_81_0 (z : Store) : Tensor := fw_linear (v_80_0 z) (z 307)
 def s_82 (z : Store) : Store := storeSet (s_81 z) [(463, fw_linear ((s_81 z) 462) ((s_81 z) 307))]
 theorem t_81 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_276) (pmPeers pmNode_276) (s_81 z) pmNode_276 none = some (s_82 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_81
 theorem k_81 (z : Store) (tid : Tid) (h : tid ∉ [463]) : (s_82 z) tid = (s_81 z) tid := by
   unfold s_82
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_81
 theorem w_81_0 (z : Store) : (s_82 z) 463 = v_81_0 z := by
   unfold s_82
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_81_0, r_81_0 z, r_81_1 z] <;> rfl
 #a w_81_0
 theorem h_81_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_81_0 z).shape = [1, 8, 64] := by
   unfold v_81_0
   exact fw_linear_3d_shape 1 8 64 64 (v_80_0 z) (z 307) (h_80_0 z z_) (i_15 z z_)
 #a h_81_0
 attribute [local irreducible] v_81_0
 attribute [local irreducible] s_82
 theorem r_82_0 (z : Store) : (s_82 z) 160 = (v_79_0 z) := pR (k_81 z) (pR (k_80 z) (w_79_0 z))
 #a r_82_0
 theorem r_82_1 (z : Store) : (s_82 z) 463 = (v_81_0 z) := w_81_0 z
 #a r_82_1
 def v_82_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_79_0 z), (v_81_0 z)]
 theorem g_82 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_41) (s_82 z) pmNode_41 1 2 164 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_41, r_82_0 z, r_82_1 z, h_79_0 z z_, h_81_0 z z_]
 #a g_82
 def s_83 (z : Store) : Store := pL [0, 1] (s_82 z) pmNode_41 1 2
 theorem t_82 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_41) (pmPeers pmNode_41) (s_82 z) pmNode_41 none = some (s_83 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_41) (s_82 z) pmNode_41).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 164 (by decide) (g_82 z z_)]
   rfl
 #a t_82
 theorem k_82 (z : Store) (tid : Tid) (h : tid ∉ [164]) : (s_83 z) tid = (s_82 z) tid := by
   unfold s_83
   dsimp only [pL, pmNode_41, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_82
 theorem w_82_0 (z : Store) : (s_83 z) 164 = v_82_0 z := by
   unfold s_83
   dsimp only [pL, pmNode_41, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_82_0, r_82_0 z, r_82_1 z] <;> rfl
 #a w_82_0
 theorem h_82_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_82_0 z).shape = [1, 16, 32] := by
   unfold v_82_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_79_0 z z_]
 #a h_82_0
 attribute [local irreducible] v_82_0
 attribute [local irreducible] s_83
 theorem r_83_0 (z : Store) : (s_83 z) 163 = (v_10_1 z) := pR (k_82 z) (pR (k_81 z) (pR (k_80 z) (pR (n_64_80 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (n_12_16 z) (pR (k_11 z) (w_10_1 z))))))))
 #a r_83_0
 theorem r_83_1 (z : Store) : (s_83 z) 164 = (v_82_0 z) := w_82_0 z
 #a r_83_1
 def v_83_0 (z : Store) : Tensor := elemwiseAdd (v_10_1 z) (v_82_0 z)
 def s_84 (z : Store) : Store := storeSet (s_83 z) [(165, elemwiseAdd ((s_83 z) 163) ((s_83 z) 164))]
 theorem t_83 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_42) (pmPeers pmNode_42) (s_83 z) pmNode_42 none = some (s_84 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_83
 theorem k_83 (z : Store) (tid : Tid) (h : tid ∉ [165]) : (s_84 z) tid = (s_83 z) tid := by
   unfold s_84
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_83
 theorem w_83_0 (z : Store) : (s_84 z) 165 = v_83_0 z := by
   unfold s_84
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_83_0, r_83_0 z, r_83_1 z] <;> rfl
 #a w_83_0
 theorem h_83_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_83_0 z).shape = [1, 16, 32] := by
   unfold v_83_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_10_1 z z_, h_82_0 z z_]
 #a h_83_0
 attribute [local irreducible] v_83_0
 attribute [local irreducible] s_84
 theorem r_84_0 (z : Store) : (s_84 z) 165 = (v_83_0 z) := w_83_0 z
 #a r_84_0
 def v_84_0 (z : Store) : Tensor := (v_83_0 z)
 def v_84_1 (z : Store) : Tensor := (v_83_0 z)
 def s_85 (z : Store) : Store := storeSet (s_84 z) [(289, ((s_84 z) 165)), (179, ((s_84 z) 165))]
 theorem t_84 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_43) (pmPeers pmNode_43) (s_84 z) pmNode_43 none = some (s_85 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_84
 theorem k_84 (z : Store) (tid : Tid) (h : tid ∉ [289, 179]) : (s_85 z) tid = (s_84 z) tid := by
   unfold s_85
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_84
 theorem w_84_0 (z : Store) : (s_85 z) 289 = v_84_0 z := by
   unfold s_85
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_84_0, r_84_0 z] <;> rfl
 #a w_84_0
 theorem h_84_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_84_0 z).shape = [1, 16, 32] := by
   unfold v_84_0
   exact h_83_0 z z_
 #a h_84_0
 attribute [local irreducible] v_84_0
 theorem w_84_1 (z : Store) : (s_85 z) 179 = v_84_1 z := by
   unfold s_85
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_84_1, r_84_0 z] <;> rfl
 #a w_84_1
 theorem h_84_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_84_1 z).shape = [1, 16, 32] := by
   unfold v_84_1
   exact h_83_0 z z_
 #a h_84_1
 attribute [local irreducible] v_84_1
 attribute [local irreducible] s_85
 theorem r_85_0 (z : Store) : (s_85 z) 160 = (v_79_0 z) := pR (k_84 z) (pR (k_83 z) (pR (k_82 z) (r_82_0 z)))
 #a r_85_0
 theorem r_85_1 (z : Store) : (s_85 z) 463 = (v_81_0 z) := pR (k_84 z) (pR (k_83 z) (pR (k_82 z) (r_82_1 z)))
 #a r_85_1
 def v_85_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 2 [(v_79_0 z), (v_81_0 z)]
 theorem g_85 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_277) (s_85 z) pmNode_277 1 2 467 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_277, r_85_0 z, r_85_1 z, h_79_0 z z_, h_81_0 z z_]
 #a g_85
 def s_86 (z : Store) : Store := pL [0, 1] (s_85 z) pmNode_277 1 2
 theorem t_85 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_277) (pmPeers pmNode_277) (s_85 z) pmNode_277 none = some (s_86 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_277) (s_85 z) pmNode_277).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 467 (by decide) (g_85 z z_)]
   rfl
 #a t_85
 theorem k_85 (z : Store) (tid : Tid) (h : tid ∉ [467]) : (s_86 z) tid = (s_85 z) tid := by
   unfold s_86
   dsimp only [pL, pmNode_277, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_85
 theorem w_85_0 (z : Store) : (s_86 z) 467 = v_85_0 z := by
   unfold s_86
   dsimp only [pL, pmNode_277, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_85_0, r_85_0 z, r_85_1 z] <;> rfl
 #a w_85_0
 theorem h_85_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_85_0 z).shape = [1, 16, 32] := by
   unfold v_85_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_79_0 z z_]
 #a h_85_0
 attribute [local irreducible] v_85_0
 attribute [local irreducible] s_86
 theorem n_80_84 (z : Store) (tid : Tid) (h : tid ∉ ([462, 463, 164, 165] : List Tid)) : (s_84 z) tid = (s_80 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_80 z) (k_81 z)) (pF _ _ _ _ _ (k_82 z) (k_83 z)) tid h
 #a n_80_84
 theorem r_86_0 (z : Store) : (s_86 z) 466 = (v_13_1 z) := pR (k_85 z) (pR (k_84 z) (pR (n_80_84 z) (pR (n_64_80 z) (pR (n_32_64 z) (pR (n_16_32 z) (pR (k_15 z) (pR (k_14 z) (w_13_1 z))))))))
 #a r_86_0
 theorem r_86_1 (z : Store) : (s_86 z) 467 = (v_85_0 z) := w_85_0 z
 #a r_86_1
 def v_86_0 (z : Store) : Tensor := elemwiseAdd (v_13_1 z) (v_85_0 z)
 def s_87 (z : Store) : Store := storeSet (s_86 z) [(468, elemwiseAdd ((s_86 z) 466) ((s_86 z) 467))]
 theorem t_86 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_278) (pmPeers pmNode_278) (s_86 z) pmNode_278 none = some (s_87 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_86
 theorem k_86 (z : Store) (tid : Tid) (h : tid ∉ [468]) : (s_87 z) tid = (s_86 z) tid := by
   unfold s_87
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_86
 theorem w_86_0 (z : Store) : (s_87 z) 468 = v_86_0 z := by
   unfold s_87
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_86_0, r_86_0 z, r_86_1 z] <;> rfl
 #a w_86_0
 theorem h_86_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_86_0 z).shape = [1, 16, 32] := by
   unfold v_86_0
   simp [elemwiseAdd, Tensor.mkShape, outShape2, h_13_1 z z_, h_85_0 z z_]
 #a h_86_0
 attribute [local irreducible] v_86_0
 attribute [local irreducible] s_87
 record_prefix_opacity v_79_0 s_80 v_80_0 s_81 v_81_0 s_82 v_82_0 s_83 v_83_0 s_84 v_84_0 v_84_1 s_85 v_85_0 s_86 v_86_0 s_87

 end
 end TrainVerify.Denote.RuntimeWorld
