import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0096
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_763_0 (z : Store) : (s_763 z) 1077 = (v_762_0 z) := w_762_0 z
 #a r_763_0
 theorem r_763_1 (z : Store) : (s_763 z) 1072 = (v_435_1 z) := pR (k_762 z) (pR (k_761 z) (pR (k_760 z) (pR (n_752_760 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (n_508_512 z) (r_508_0 z)))))))))
 #a r_763_1
 theorem r_763_2 (z : Store) : (s_763 z) 1073 = (v_507_0 z) := pR (k_762 z) (pR (k_761 z) (pR (k_760 z) (pR (n_752_760 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (n_508_512 z) (r_508_1 z)))))))))
 #a r_763_2
 def v_763_0 (z : Store) : Tensor := (bw_add2 (v_762_0 z) (v_435_1 z) (v_507_0 z)).1
 def v_763_1 (z : Store) : Tensor := (bw_add2 (v_762_0 z) (v_435_1 z) (v_507_0 z)).2
 def s_764 (z : Store) : Store := storeSet (s_763 z) [(1075, (bw_add2 ((s_763 z) 1077) ((s_763 z) 1072) ((s_763 z) 1073)).1), (1076, (bw_add2 ((s_763 z) 1077) ((s_763 z) 1072) ((s_763 z) 1073)).2)]
 theorem t_763 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_878) (pmPeers pmNode_878) (s_763 z) pmNode_878 none = some (s_764 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_763
 theorem k_763 (z : Store) (tid : Tid) (h : tid ∉ [1075, 1076]) : (s_764 z) tid = (s_763 z) tid := by
   unfold s_764
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_763
 theorem w_763_0 (z : Store) : (s_764 z) 1075 = v_763_0 z := by
   unfold s_764
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_763_0, r_763_0 z, r_763_1 z, r_763_2 z] <;> rfl
 #a w_763_0
 theorem h_763_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_763_0 z).shape = [1, 16, 32] := by
   unfold v_763_0
   exact h_435_1 z z_
 #a h_763_0
 attribute [local irreducible] v_763_0
 theorem w_763_1 (z : Store) : (s_764 z) 1076 = v_763_1 z := by
   unfold s_764
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_763_1, r_763_0 z, r_763_1 z, r_763_2 z] <;> rfl
 #a w_763_1
 theorem h_763_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_763_1 z).shape = [1, 16, 32] := by
   unfold v_763_1
   exact h_507_0 z z_
 #a h_763_1
 attribute [local irreducible] v_763_1
 attribute [local irreducible] s_764
 theorem r_764_0 (z : Store) : (s_764 z) 773 = (v_760_1 z) := pR (k_763 z) (pR (k_762 z) (pR (k_761 z) (w_760_1 z)))
 #a r_764_0
 theorem r_764_1 (z : Store) : (s_764 z) 1076 = (v_763_1 z) := w_763_1 z
 #a r_764_1
 def v_764_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_760_1 z), (v_763_1 z)]
 theorem g_764 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_643) (s_764 z) pmNode_643 2 1 768 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_643, r_764_0 z, r_764_1 z, h_760_1 z z_, h_763_1 z z_]
 #a g_764
 def s_765 (z : Store) : Store := pL [2, 3] (s_764 z) pmNode_643 2 1
 theorem t_764 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_643) (pmPeers pmNode_643) (s_764 z) pmNode_643 none = some (s_765 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_643) (s_764 z) pmNode_643).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 768 (by decide) (g_764 z z_)]
   rfl
 #a t_764
 theorem k_764 (z : Store) (tid : Tid) (h : tid ∉ [768]) : (s_765 z) tid = (s_764 z) tid := by
   unfold s_765
   dsimp only [pL, pmNode_643, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_764
 theorem w_764_0 (z : Store) : (s_765 z) 768 = v_764_0 z := by
   unfold s_765
   dsimp only [pL, pmNode_643, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_764_0, r_764_0 z, r_764_1 z] <;> rfl
 #a w_764_0
 theorem h_764_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_764_0 z).shape = [1, 8, 64] := by
   unfold v_764_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_760_1 z z_]
 #a h_764_0
 attribute [local irreducible] v_764_0
 attribute [local irreducible] s_765
 theorem n_760_764 (z : Store) (tid : Tid) (h : tid ∉ ([772, 773, 1199, 1077, 1075, 1076] : List Tid)) : (s_764 z) tid = (s_760 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_760 z) (k_761 z)) (pF _ _ _ _ _ (k_762 z) (k_763 z)) tid h
 #a n_760_764
 theorem r_765_0 (z : Store) : (s_765 z) 768 = (v_764_0 z) := w_764_0 z
 #a r_765_0
 theorem r_765_1 (z : Store) : (s_765 z) 765 = (v_500_0 z) := pR (k_764 z) (pR (n_760_764 z) (pR (n_752_760 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (n_504_512 z) (pR (k_503 z) (pR (k_502 z) (pR (k_501 z) (r_501_0 z)))))))))))
 #a r_765_1
 theorem r_765_2 (z : Store) : (s_765 z) 610 = (z 610) := pR (k_764 z) (pR (n_760_764 z) (pR (n_752_760 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (n_504_512 z) (pR (k_503 z) (pR (k_502 z) (pR (k_501 z) (r_501_1 z)))))))))))
 #a r_765_2
 def v_765_0 (z : Store) : Tensor := (bw_linear (v_764_0 z) (v_500_0 z) (z 610)).1
 def v_765_1 (z : Store) : Tensor := (bw_linear (v_764_0 z) (v_500_0 z) (z 610)).2
 def s_766 (z : Store) : Store := storeSet (s_765 z) [(767, (bw_linear ((s_765 z) 768) ((s_765 z) 765) ((s_765 z) 610)).1), (639, (bw_linear ((s_765 z) 768) ((s_765 z) 765) ((s_765 z) 610)).2)]
 theorem t_765 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_644) (pmPeers pmNode_644) (s_765 z) pmNode_644 none = some (s_766 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_765
 theorem k_765 (z : Store) (tid : Tid) (h : tid ∉ [767, 639]) : (s_766 z) tid = (s_765 z) tid := by
   unfold s_766
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_765
 theorem w_765_0 (z : Store) : (s_766 z) 767 = v_765_0 z := by
   unfold s_766
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_765_0, r_765_0 z, r_765_1 z, r_765_2 z] <;> rfl
 #a w_765_0
 theorem h_765_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_765_0 z).shape = [1, 8, 64] := by
   unfold v_765_0
   exact bw_linear_3d_fst_shape 1 8 64 64 (v_764_0 z) (v_500_0 z) (z 610) (h_764_0 z z_) (h_500_0 z z_) (i_64 z z_)
 #a h_765_0
 attribute [local irreducible] v_765_0
 theorem w_765_1 (z : Store) : (s_766 z) 639 = v_765_1 z := by
   unfold s_766
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_765_1, r_765_0 z, r_765_1 z, r_765_2 z] <;> rfl
 #a w_765_1
 theorem h_765_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_765_1 z).shape = [64, 64] := by
   unfold v_765_1
   exact bw_linear_3d_snd_shape 1 8 64 64 (v_764_0 z) (v_500_0 z) (z 610) (h_764_0 z z_) (h_500_0 z z_) (i_64 z z_)
 #a h_765_1
 attribute [local irreducible] v_765_1
 attribute [local irreducible] s_766
 theorem r_766_0 (z : Store) : (s_766 z) 773 = (v_760_1 z) := pR (k_765 z) (pR (k_764 z) (r_764_0 z))
 #a r_766_0
 theorem r_766_1 (z : Store) : (s_766 z) 1076 = (v_763_1 z) := pR (k_765 z) (pR (k_764 z) (r_764_1 z))
 #a r_766_1
 def v_766_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 2 1 [(v_760_1 z), (v_763_1 z)]
 theorem g_766 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_879) (s_766 z) pmNode_879 2 1 1071 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_879, r_766_0 z, r_766_1 z, h_760_1 z z_, h_763_1 z z_]
 #a g_766
 def s_767 (z : Store) : Store := pL [2, 3] (s_766 z) pmNode_879 2 1
 theorem t_766 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_879) (pmPeers pmNode_879) (s_766 z) pmNode_879 none = some (s_767 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_879) (s_766 z) pmNode_879).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 1071 (by decide) (g_766 z z_)]
   rfl
 #a t_766
 theorem k_766 (z : Store) (tid : Tid) (h : tid ∉ [1071]) : (s_767 z) tid = (s_766 z) tid := by
   unfold s_767
   dsimp only [pL, pmNode_879, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_766
 theorem w_766_0 (z : Store) : (s_767 z) 1071 = v_766_0 z := by
   unfold s_767
   dsimp only [pL, pmNode_879, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_766_0, r_766_0 z, r_766_1 z] <;> rfl
 #a w_766_0
 theorem h_766_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_766_0 z).shape = [1, 8, 64] := by
   unfold v_766_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_760_1 z z_]
 #a h_766_0
 attribute [local irreducible] v_766_0
 attribute [local irreducible] s_767
 theorem r_767_0 (z : Store) : (s_767 z) 1071 = (v_766_0 z) := w_766_0 z
 #a r_767_0
 theorem r_767_1 (z : Store) : (s_767 z) 1068 = (v_502_0 z) := pR (k_766 z) (pR (k_765 z) (pR (k_764 z) (pR (n_760_764 z) (pR (n_752_760 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (n_504_512 z) (pR (k_503 z) (r_503_0 z)))))))))))
 #a r_767_1
 theorem r_767_2 (z : Store) : (s_767 z) 913 = (z 913) := pR (k_766 z) (pR (k_765 z) (pR (k_764 z) (pR (n_760_764 z) (pR (n_752_760 z) (pR (n_736_752 z) (pR (n_704_736 z) (pR (n_640_704 z) (pR (n_512_640 z) (pR (n_504_512 z) (pR (k_503 z) (r_503_1 z)))))))))))
 #a r_767_2
 def v_767_0 (z : Store) : Tensor := (bw_linear (v_766_0 z) (v_502_0 z) (z 913)).1
 def v_767_1 (z : Store) : Tensor := (bw_linear (v_766_0 z) (v_502_0 z) (z 913)).2
 def s_768 (z : Store) : Store := storeSet (s_767 z) [(1070, (bw_linear ((s_767 z) 1071) ((s_767 z) 1068) ((s_767 z) 913)).1), (942, (bw_linear ((s_767 z) 1071) ((s_767 z) 1068) ((s_767 z) 913)).2)]
 theorem t_767 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_880) (pmPeers pmNode_880) (s_767 z) pmNode_880 none = some (s_768 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_767
 theorem k_767 (z : Store) (tid : Tid) (h : tid ∉ [1070, 942]) : (s_768 z) tid = (s_767 z) tid := by
   unfold s_768
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_767
 theorem w_767_0 (z : Store) : (s_768 z) 1070 = v_767_0 z := by
   unfold s_768
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_767_0, r_767_0 z, r_767_1 z, r_767_2 z] <;> rfl
 #a w_767_0
 theorem h_767_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_767_0 z).shape = [1, 8, 64] := by
   unfold v_767_0
   exact bw_linear_3d_fst_shape 1 8 64 64 (v_766_0 z) (v_502_0 z) (z 913) (h_766_0 z z_) (h_502_0 z z_) (i_65 z z_)
 #a h_767_0
 attribute [local irreducible] v_767_0
 theorem w_767_1 (z : Store) : (s_768 z) 942 = v_767_1 z := by
   unfold s_768
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_767_1, r_767_0 z, r_767_1 z, r_767_2 z] <;> rfl
 #a w_767_1
 theorem h_767_1 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_767_1 z).shape = [64, 64] := by
   unfold v_767_1
   exact bw_linear_3d_snd_shape 1 8 64 64 (v_766_0 z) (v_502_0 z) (z 913) (h_766_0 z z_) (h_502_0 z z_) (i_65 z z_)
 #a h_767_1
 attribute [local irreducible] v_767_1
 attribute [local irreducible] s_768
 theorem r_768_0 (z : Store) : (s_768 z) 767 = (v_765_0 z) := pR (k_767 z) (pR (k_766 z) (w_765_0 z))
 #a r_768_0
 theorem r_768_1 (z : Store) : (s_768 z) 1070 = (v_767_0 z) := w_767_0 z
 #a r_768_1
 def v_768_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 1 2 [(v_765_0 z), (v_767_0 z)]
 theorem g_768 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [2, 3] (pmPeers pmNode_645) (s_768 z) pmNode_645 1 2 764 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 64], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_645, r_768_0 z, r_768_1 z, h_765_0 z z_, h_767_0 z z_]
 #a g_768
 def s_769 (z : Store) : Store := pL [2, 3] (s_768 z) pmNode_645 1 2
 theorem t_768 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_645) (pmPeers pmNode_645) (s_768 z) pmNode_645 none = some (s_769 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [2, 3]) (pmPeers pmNode_645) (s_768 z) pmNode_645).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 2 764 (by decide) (g_768 z z_)]
   rfl
 #a t_768
 theorem k_768 (z : Store) (tid : Tid) (h : tid ∉ [764]) : (s_769 z) tid = (s_768 z) tid := by
   unfold s_769
   dsimp only [pL, pmNode_645, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_768
 theorem w_768_0 (z : Store) : (s_769 z) 764 = v_768_0 z := by
   unfold s_769
   dsimp only [pL, pmNode_645, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_768_0, r_768_0 z, r_768_1 z] <;> rfl
 #a w_768_0
 theorem h_768_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_768_0 z).shape = [1, 16, 32] := by
   unfold v_768_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_765_0 z z_]
 #a h_768_0
 attribute [local irreducible] v_768_0
 attribute [local irreducible] s_769
 theorem n_764_768 (z : Store) (tid : Tid) (h : tid ∉ ([768, 767, 639, 1071, 1070, 942] : List Tid)) : (s_768 z) tid = (s_764 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_764 z) (k_765 z)) (pF _ _ _ _ _ (k_766 z) (k_767 z)) tid h
 #a n_764_768
 theorem n_760_768 (z : Store) (tid : Tid) (h : tid ∉ ([772, 773, 1199, 1077, 1075, 1076, 768, 767, 639, 1071, 1070, 942] : List Tid)) : (s_768 z) tid = (s_760 z) tid := by
   exact pF _ _ _ _ _ (n_760_764 z) (n_764_768 z) tid h
 #a n_760_768
 theorem n_752_768 (z : Store) (tid : Tid) (h : tid ∉ ([777, 641, 643, 1087, 1085, 950, 1083, 1081, 948, 1080, 944, 946, 896, 774, 772, 773, 1199, 1077, 1075, 1076, 768, 767, 639, 1071, 1070, 942] : List Tid)) : (s_768 z) tid = (s_752 z) tid := by
   exact pF _ _ _ _ _ (n_752_760 z) (n_760_768 z) tid h
 #a n_752_768
 theorem n_736_768 (z : Store) (tid : Tid) (h : tid ∉ ([900, 794, 793, 649, 651, 1203, 1097, 1096, 952, 954, 898, 790, 788, 789, 1201, 1093, 1091, 1092, 784, 782, 647, 780, 778, 645, 777, 641, 643, 1087, 1085, 950, 1083, 1081, 948, 1080, 944, 946, 896, 774, 772, 773, 1199, 1077, 1075, 1076, 768, 767, 639, 1071, 1070, 942] : List Tid)) : (s_768 z) tid = (s_736 z) tid := by
   exact pF _ _ _ _ _ (n_736_752 z) (n_752_768 z) tid h
 #a n_736_768
 theorem n_704_768 (z : Store) (tid : Tid) (h : tid ∉ ([823, 822, 1126, 1125, 689, 818, 992, 1121, 815, 814, 1118, 1117, 688, 810, 991, 1113, 807, 806, 1110, 1109, 796, 803, 660, 1100, 1106, 963, 904, 800, 657, 1207, 1103, 960, 902, 797, 654, 1205, 1099, 957, 900, 794, 793, 649, 651, 1203, 1097, 1096, 952, 954, 898, 790, 788, 789, 1201, 1093, 1091, 1092, 784, 782, 647, 780, 778, 645, 777, 641, 643, 1087, 1085, 950, 1083, 1081, 948, 1080, 944, 946, 896, 774, 772, 773, 1199, 1077, 1075, 1076, 768, 767, 639, 1071, 1070, 942] : List Tid)) : (s_768 z) tid = (s_704 z) tid := by
   exact pF _ _ _ _ _ (n_704_736 z) (n_736_768 z) tid h
 #a n_704_768
 theorem n_640_768 (z : Store) (tid : Tid) (h : tid ∉ ([1188, 1187, 982, 882, 880, 674, 676, 879, 876, 1185, 1183, 977, 979, 1182, 1179, 908, 874, 672, 873, 1211, 1177, 975, 1176, 691, 870, 670, 994, 1173, 973, 867, 866, 665, 667, 1170, 1169, 968, 970, 906, 863, 861, 862, 1209, 1166, 1164, 1165, 690, 856, 663, 855, 993, 1159, 966, 1158, 852, 851, 1155, 1154, 848, 847, 1151, 1150, 843, 841, 844, 1147, 1144, 1146, 827, 840, 1130, 1143, 837, 836, 1140, 1139, 833, 811, 832, 1136, 1114, 1135, 829, 819, 826, 1132, 1122, 1129, 823, 822, 1126, 1125, 689, 818, 992, 1121, 815, 814, 1118, 1117, 688, 810, 991, 1113, 807, 806, 1110, 1109, 796, 803, 660, 1100, 1106, 963, 904, 800, 657, 1207, 1103, 960, 902, 797, 654, 1205, 1099, 957, 900, 794, 793, 649, 651, 1203, 1097, 1096, 952, 954, 898, 790, 788, 789, 1201, 1093, 1091, 1092, 784, 782, 647, 780, 778, 645, 777, 641, 643, 1087, 1085, 950, 1083, 1081, 948, 1080, 944, 946, 896, 774, 772, 773, 1199, 1077, 1075, 1076, 768, 767, 639, 1071, 1070, 942] : List Tid)) : (s_768 z) tid = (s_640 z) tid := by
   exact pF _ _ _ _ _ (n_640_704 z) (n_704_768 z) tid h
 #a n_640_768
 theorem n_512_768 (z : Store) (tid : Tid) (h : tid ∉ ([779, 781, 783, 1078, 1079, 1082, 1084, 1086, 786, 787, 897, 858, 1089, 1090, 1200, 1161, 791, 792, 899, 901, 903, 1094, 1095, 1202, 1204, 1206, 694, 795, 798, 799, 801, 802, 997, 1098, 804, 805, 1101, 1102, 1104, 1105, 1107, 1108, 808, 809, 812, 813, 1111, 1112, 1115, 1116, 816, 817, 820, 821, 1119, 1120, 1123, 1124, 824, 825, 828, 1127, 1128, 1131, 830, 831, 1133, 1134, 834, 835, 1137, 1138, 838, 839, 685, 842, 1141, 1142, 988, 1145, 845, 846, 1148, 1149, 849, 850, 1152, 1153, 853, 854, 857, 1156, 1157, 1160, 859, 860, 905, 907, 1162, 1163, 1208, 1210, 864, 865, 1167, 1168, 868, 869, 1171, 1172, 871, 872, 875, 877, 878, 881, 1174, 1175, 1178, 1180, 1181, 1184, 686, 883, 989, 1186, 886, 887, 1189, 1190, 683, 888, 986, 1191, 884, 885, 679, 1188, 1187, 982, 882, 880, 674, 676, 879, 876, 1185, 1183, 977, 979, 1182, 1179, 908, 874, 672, 873, 1211, 1177, 975, 1176, 691, 870, 670, 994, 1173, 973, 867, 866, 665, 667, 1170, 1169, 968, 970, 906, 863, 861, 862, 1209, 1166, 1164, 1165, 690, 856, 663, 855, 993, 1159, 966, 1158, 852, 851, 1155, 1154, 848, 847, 1151, 1150, 843, 841, 844, 1147, 1144, 1146, 827, 840, 1130, 1143, 837, 836, 1140, 1139, 833, 811, 832, 1136, 1114, 1135, 829, 819, 826, 1132, 1122, 1129, 823, 822, 1126, 1125, 689, 818, 992, 1121, 815, 814, 1118, 1117, 688, 810, 991, 1113, 807, 806, 1110, 1109, 796, 803, 660, 1100, 1106, 963, 904, 800, 657, 1207, 1103, 960, 902, 797, 654, 1205, 1099, 957, 900, 794, 793, 649, 651, 1203, 1097, 1096, 952, 954, 898, 790, 788, 789, 1201, 1093, 1091, 1092, 784, 782, 647, 780, 778, 645, 777, 641, 643, 1087, 1085, 950, 1083, 1081, 948, 1080, 944, 946, 896, 774, 772, 773, 1199, 1077, 1075, 1076, 768, 767, 639, 1071, 1070, 942] : List Tid)) : (s_768 z) tid = (s_512 z) tid := by
   exact pF _ _ _ _ _ (n_512_640 z) (n_640_768 z) tid h
 #a n_512_768
 theorem r_769_0 (z : Store) : (s_769 z) 764 = (v_768_0 z) := w_768_0 z
 #a r_769_0
 theorem r_769_1 (z : Store) : (s_769 z) 761 = (v_496_0 z) := pR (k_768 z) (pR (n_512_768 z) (pR (n_504_512 z) (pR (n_500_504 z) (pR (k_499 z) (pR (k_498 z) (pR (k_497 z) (r_497_0 z)))))))
 #a r_769_1
 def v_769_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_768_0 z)
 def s_770 (z : Store) : Store := storeSet (s_769 z) [(763, fw_view [1, 16, 2, 16] ((s_769 z) 764))]
 theorem t_769 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_646) (pmPeers pmNode_646) (s_769 z) pmNode_646 none = some (s_770 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_769
 theorem k_769 (z : Store) (tid : Tid) (h : tid ∉ [763]) : (s_770 z) tid = (s_769 z) tid := by
   unfold s_770
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_769
 theorem w_769_0 (z : Store) : (s_770 z) 763 = v_769_0 z := by
   unfold s_770
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_769_0, r_769_0 z, r_769_1 z] <;> rfl
 #a w_769_0
 theorem h_769_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_769_0 z).shape = [1, 16, 2, 16] := by
   unfold v_769_0
   rfl
 #a h_769_0
 attribute [local irreducible] v_769_0
 attribute [local irreducible] s_770
 record_prefix_opacity v_763_0 v_763_1 s_764 v_764_0 s_765 v_765_0 v_765_1 s_766 v_766_0 s_767 v_767_0 v_767_1 s_768 v_768_0 s_769 v_769_0 s_770

 end
 end TrainVerify.Denote.RuntimeWorld
