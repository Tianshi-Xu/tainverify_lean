import TrainVerifyRuntimeWorldData
import denote.SourceScopedPrefix
import TrainVerifyRuntimePrefixSupport
import TrainVerifyRuntimePrefix0006
import TrainVerifyRuntimePrefixNamesV3
prefix_names_v3 pmSeededPrefix + + ! where
 namespace TrainVerify.Denote.RuntimeWorld
 noncomputable section
 open SourceScopedEval
 set_option maxHeartbeats 500000
 set_option maxRecDepth 4096
 restore_prefix_opacity
 theorem r_35_0 (z : Store) : (s_35 z) 112 = (v_25_0 z) := pR (k_34 z) (pR (k_33 z) (pR (k_32 z) (r_32_0 z)))
 #a r_35_0
 theorem r_35_1 (z : Store) : (s_35 z) 415 = (v_31_0 z) := pR (k_34 z) (pR (k_33 z) (pR (k_32 z) (r_32_1 z)))
 #a r_35_1
 def v_35_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 1 1 3 [(v_25_0 z), (v_31_0 z)]
 theorem g_35 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_252) (s_35 z) pmNode_252 1 3 417 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 8, 4, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_252, r_35_0 z, r_35_1 z, h_25_0 z z_, h_31_0 z z_]
 #a g_35
 def s_36 (z : Store) : Store := pL [0, 1] (s_35 z) pmNode_252 1 3
 theorem t_35 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_252) (pmPeers pmNode_252) (s_35 z) pmNode_252 none = some (s_36 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_252) (s_35 z) pmNode_252).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 1 3 417 (by decide) (g_35 z z_)]
   rfl
 #a t_35
 theorem k_35 (z : Store) (tid : Tid) (h : tid ∉ [417]) : (s_36 z) tid = (s_35 z) tid := by
   unfold s_36
   dsimp only [pL, pmNode_252, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_35
 theorem w_35_0 (z : Store) : (s_36 z) 417 = v_35_0 z := by
   unfold s_36
   dsimp only [pL, pmNode_252, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_35_0, r_35_0 z, r_35_1 z] <;> rfl
 #a w_35_0
 theorem h_35_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_35_0 z).shape = [1, 16, 4, 8] := by
   unfold v_35_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_25_0 z z_]
 #a h_35_0
 attribute [local irreducible] v_35_0
 attribute [local irreducible] s_36
 theorem r_36_0 (z : Store) : (s_36 z) 417 = (v_35_0 z) := w_35_0 z
 #a r_36_0
 def v_36_0 (z : Store) : Tensor := transposeAxes 1 2 (v_35_0 z)
 def s_37 (z : Store) : Store := storeSet (s_36 z) [(418, transposeAxes 1 2 ((s_36 z) 417))]
 theorem t_36 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_253) (pmPeers pmNode_253) (s_36 z) pmNode_253 none = some (s_37 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_36
 theorem k_36 (z : Store) (tid : Tid) (h : tid ∉ [418]) : (s_37 z) tid = (s_36 z) tid := by
   unfold s_37
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_36
 theorem w_36_0 (z : Store) : (s_37 z) 418 = v_36_0 z := by
   unfold s_37
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_36_0, r_36_0 z] <;> rfl
 #a w_36_0
 theorem h_36_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_36_0 z).shape = [1, 4, 16, 8] := by
   unfold v_36_0
   change listSwapAt _ _ _ = _
   rw [h_35_0 z z_]
   rfl
 #a h_36_0
 attribute [local irreducible] v_36_0
 attribute [local irreducible] s_37
 theorem n_32_36 (z : Store) (tid : Tid) (h : tid ∉ ([114, 115, 118, 417] : List Tid)) : (s_36 z) tid = (s_32 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_32 z) (k_33 z)) (pF _ _ _ _ _ (k_34 z) (k_35 z)) tid h
 #a n_32_36
 theorem r_37_0 (z : Store) : (s_37 z) 409 = (v_28_0 z) := pR (k_36 z) (pR (n_32_36 z) (pR (k_31 z) (pR (k_30 z) (pR (k_29 z) (w_28_0 z)))))
 #a r_37_0
 def v_37_0 (z : Store) : Tensor := fw_view [1, 16, 2, 16] (v_28_0 z)
 def s_38 (z : Store) : Store := storeSet (s_37 z) [(421, fw_view [1, 16, 2, 16] ((s_37 z) 409))]
 theorem t_37 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_254) (pmPeers pmNode_254) (s_37 z) pmNode_254 none = some (s_38 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_37
 theorem k_37 (z : Store) (tid : Tid) (h : tid ∉ [421]) : (s_38 z) tid = (s_37 z) tid := by
   unfold s_38
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_37
 theorem w_37_0 (z : Store) : (s_38 z) 421 = v_37_0 z := by
   unfold s_38
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_37_0, r_37_0 z] <;> rfl
 #a w_37_0
 theorem h_37_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_37_0 z).shape = [1, 16, 2, 16] := by
   unfold v_37_0
   rfl
 #a h_37_0
 attribute [local irreducible] v_37_0
 attribute [local irreducible] s_38
 theorem r_38_0 (z : Store) : (s_38 z) 118 = (v_34_0 z) := pR (k_37 z) (pR (k_36 z) (pR (k_35 z) (w_34_0 z)))
 #a r_38_0
 theorem r_38_1 (z : Store) : (s_38 z) 421 = (v_37_0 z) := w_37_0 z
 #a r_38_1
 def v_38_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 3 [(v_34_0 z), (v_37_0 z)]
 theorem g_38 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_19) (s_38 z) pmNode_19 2 3 120 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 2, 16], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_19, r_38_0 z, r_38_1 z, h_34_0 z z_, h_37_0 z z_]
 #a g_38
 def s_39 (z : Store) : Store := pL [0, 1] (s_38 z) pmNode_19 2 3
 theorem t_38 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_19) (pmPeers pmNode_19) (s_38 z) pmNode_19 none = some (s_39 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_19) (s_38 z) pmNode_19).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 3 120 (by decide) (g_38 z z_)]
   rfl
 #a t_38
 theorem k_38 (z : Store) (tid : Tid) (h : tid ∉ [120]) : (s_39 z) tid = (s_38 z) tid := by
   unfold s_39
   dsimp only [pL, pmNode_19, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_38
 theorem w_38_0 (z : Store) : (s_39 z) 120 = v_38_0 z := by
   unfold s_39
   dsimp only [pL, pmNode_19, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_38_0, r_38_0 z, r_38_1 z] <;> rfl
 #a w_38_0
 theorem h_38_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_38_0 z).shape = [1, 16, 4, 8] := by
   unfold v_38_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_34_0 z z_]
 #a h_38_0
 attribute [local irreducible] v_38_0
 attribute [local irreducible] s_39
 theorem r_39_0 (z : Store) : (s_39 z) 120 = (v_38_0 z) := w_38_0 z
 #a r_39_0
 def v_39_0 (z : Store) : Tensor := transposeAxes 1 2 (v_38_0 z)
 def s_40 (z : Store) : Store := storeSet (s_39 z) [(121, transposeAxes 1 2 ((s_39 z) 120))]
 theorem t_39 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_20) (pmPeers pmNode_20) (s_39 z) pmNode_20 none = some (s_40 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_39
 theorem k_39 (z : Store) (tid : Tid) (h : tid ∉ [121]) : (s_40 z) tid = (s_39 z) tid := by
   unfold s_40
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_39
 theorem w_39_0 (z : Store) : (s_40 z) 121 = v_39_0 z := by
   unfold s_40
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_39_0, r_39_0 z] <;> rfl
 #a w_39_0
 theorem h_39_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_39_0 z).shape = [1, 4, 16, 8] := by
   unfold v_39_0
   change listSwapAt _ _ _ = _
   rw [h_38_0 z z_]
   rfl
 #a h_39_0
 attribute [local irreducible] v_39_0
 attribute [local irreducible] s_40
 theorem n_36_40 (z : Store) (tid : Tid) (h : tid ∉ ([418, 421, 120, 121] : List Tid)) : (s_40 z) tid = (s_36 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_36 z) (k_37 z)) (pF _ _ _ _ _ (k_38 z) (k_39 z)) tid h
 #a n_36_40
 theorem n_32_40 (z : Store) (tid : Tid) (h : tid ∉ ([114, 115, 118, 417, 418, 421, 120, 121] : List Tid)) : (s_40 z) tid = (s_32 z) tid := by
   exact pF _ _ _ _ _ (n_32_36 z) (n_36_40 z) tid h
 #a n_32_40
 theorem r_40_0 (z : Store) : (s_40 z) 109 = (v_24_0 z) := pR (n_32_40 z) (pR (n_28_32 z) (pR (k_27 z) (pR (k_26 z) (pR (k_25 z) (w_24_0 z)))))
 #a r_40_0
 theorem r_40_1 (z : Store) : (s_40 z) 412 = (v_30_0 z) := pR (n_32_40 z) (pR (k_31 z) (w_30_0 z))
 #a r_40_1
 def v_40_0 (z : Store) : Tensor := AllToAllSourceFaithful.tensor 2 0 2 1 [(v_24_0 z), (v_30_0 z)]
 theorem g_40 (z : Store) (z_ : pmSeededPrefixInitShapes z) : AllToAllSourceFaithful.NodeContract [0, 1] (pmPeers pmNode_21) (s_40 z) pmNode_21 2 1 124 := by
   refine ⟨rfl, rfl, rfl, rfl, ?_⟩
   refine ⟨by decide, rfl, [1, 16, 32], ?_, by decide, by decide, by decide, by decide⟩
   simp [pmNode_21, r_40_0 z, r_40_1 z, h_24_0 z z_, h_30_0 z z_]
 #a g_40
 def s_41 (z : Store) : Store := pL [0, 1] (s_40 z) pmNode_21 2 1
 theorem t_40 (z : Store) (z_ : pmSeededPrefixInitShapes z) : stepWithInputs pmGraph (pmScope pmNode_21) (pmPeers pmNode_21) (s_40 z) pmNode_21 none = some (s_41 z) := by
   change (AllToAllSourceFaithful.step pmGraph (some [0, 1]) (pmPeers pmNode_21) (s_40 z) pmNode_21).toOption = _
   rw [AllToAllSourceFaithful.step_valid _ _ _ _ _ 2 1 124 (by decide) (g_40 z z_)]
   rfl
 #a t_40
 theorem k_40 (z : Store) (tid : Tid) (h : tid ∉ [124]) : (s_41 z) tid = (s_40 z) tid := by
   unfold s_41
   dsimp only [pL, pmNode_21, List.zip, List.zipWith]
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_40
 theorem w_40_0 (z : Store) : (s_41 z) 124 = v_40_0 z := by
   unfold s_41
   dsimp only [pL, pmNode_21, List.zip, List.zipWith]
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_40_0, r_40_0 z, r_40_1 z] <;> rfl
 #a w_40_0
 theorem h_40_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_40_0 z).shape = [1, 8, 64] := by
   unfold v_40_0
   rw [AllToAllSourceFaithful.tensor_shape _ _ _ _ _ _ (by decide)]
   simp [h_24_0 z z_]
 #a h_40_0
 attribute [local irreducible] v_40_0
 attribute [local irreducible] s_41
 theorem r_41_0 (z : Store) : (s_41 z) 124 = (v_40_0 z) := w_40_0 z
 #a r_41_0
 def v_41_0 (z : Store) : Tensor := fw_view [1, 8, 4, 16] (v_40_0 z)
 def s_42 (z : Store) : Store := storeSet (s_41 z) [(125, fw_view [1, 8, 4, 16] ((s_41 z) 124))]
 theorem t_41 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_22) (pmPeers pmNode_22) (s_41 z) pmNode_22 none = some (s_42 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_41
 theorem k_41 (z : Store) (tid : Tid) (h : tid ∉ [125]) : (s_42 z) tid = (s_41 z) tid := by
   unfold s_42
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_41
 theorem w_41_0 (z : Store) : (s_42 z) 125 = v_41_0 z := by
   unfold s_42
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_41_0, r_41_0 z] <;> rfl
 #a w_41_0
 theorem h_41_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_41_0 z).shape = [1, 8, 4, 16] := by
   unfold v_41_0
   rfl
 #a h_41_0
 attribute [local irreducible] v_41_0
 attribute [local irreducible] s_42
 theorem r_42_0 (z : Store) : (s_42 z) 125 = (v_41_0 z) := w_41_0 z
 #a r_42_0
 def v_42_0 (z : Store) : Tensor := transposeAxes 1 2 (v_41_0 z)
 def s_43 (z : Store) : Store := storeSet (s_42 z) [(128, transposeAxes 1 2 ((s_42 z) 125))]
 theorem t_42 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_23) (pmPeers pmNode_23) (s_42 z) pmNode_23 none = some (s_43 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_42
 theorem k_42 (z : Store) (tid : Tid) (h : tid ∉ [128]) : (s_43 z) tid = (s_42 z) tid := by
   unfold s_43
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_42
 theorem w_42_0 (z : Store) : (s_43 z) 128 = v_42_0 z := by
   unfold s_43
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_42_0, r_42_0 z] <;> rfl
 #a w_42_0
 theorem h_42_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_42_0 z).shape = [1, 4, 8, 16] := by
   unfold v_42_0
   change listSwapAt _ _ _ = _
   rw [h_41_0 z z_]
   rfl
 #a h_42_0
 attribute [local irreducible] v_42_0
 attribute [local irreducible] s_43
 theorem r_43_0 (z : Store) : (s_43 z) 121 = (v_39_0 z) := pR (k_42 z) (pR (k_41 z) (pR (k_40 z) (w_39_0 z)))
 #a r_43_0
 def v_43_0 (z : Store) : Tensor := transposeAxes 2 3 (v_39_0 z)
 def s_44 (z : Store) : Store := storeSet (s_43 z) [(130, transposeAxes 2 3 ((s_43 z) 121))]
 theorem t_43 (z : Store) : stepWithInputs pmGraph (pmScope pmNode_24) (pmPeers pmNode_24) (s_43 z) pmNode_24 none = some (s_44 z) := by
   change some (applyNode _ _ _) = _
   rfl
 #a t_43
 theorem k_43 (z : Store) (tid : Tid) (h : tid ∉ [130]) : (s_44 z) tid = (s_43 z) tid := by
   unfold s_44
   exact pS _ _ _ (by simpa only [List.map] using h)
 #a k_43
 theorem w_43_0 (z : Store) : (s_44 z) 130 = v_43_0 z := by
   unfold s_44
   simp only [storeSet, List.find?, List.map, Nat.reduceEqDiff, decide_true, decide_false, v_43_0, r_43_0 z] <;> rfl
 #a w_43_0
 theorem h_43_0 (z : Store) (z_ : pmSeededPrefixInitShapes z) : (v_43_0 z).shape = [1, 4, 8, 16] := by
   unfold v_43_0
   change listSwapAt _ _ _ = _
   rw [h_39_0 z z_]
   rfl
 #a h_43_0
 attribute [local irreducible] v_43_0
 attribute [local irreducible] s_44
 theorem n_40_44 (z : Store) (tid : Tid) (h : tid ∉ ([124, 125, 128, 130] : List Tid)) : (s_44 z) tid = (s_40 z) tid := by
   exact pF _ _ _ _ _ (pF _ _ _ _ _ (k_40 z) (k_41 z)) (pF _ _ _ _ _ (k_42 z) (k_43 z)) tid h
 #a n_40_44
 record_prefix_opacity v_35_0 s_36 v_36_0 s_37 v_37_0 s_38 v_38_0 s_39 v_39_0 s_40 v_40_0 s_41 v_41_0 s_42 v_42_0 s_43 v_43_0 s_44

 end
 end TrainVerify.Denote.RuntimeWorld
